#!/usr/bin/env python3
"""Append byte-observation calls and prove exact reversal to the fixed oracles."""
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path(__file__).resolve().parent
FILES = ROOT / 'proposal/files'
sha = lambda b: hashlib.sha256(b).hexdigest()
helper = FILES / 'tests/integer_byte_evidence.py'
helper_sha = sha(helper.read_bytes())
proof = {'schema': 'heptatorch.integer-byte-observation-inverse.v1', 'helper_sha256': helper_sha, 'profiles': {}}


def observed(profile):
    original = (ROOT / 'baseline/tests' / (profile + '_oracle.py')).read_text()
    code = original
    additions = []

    def after(anchor, addition, label):
        nonlocal code
        assert code.count(anchor) == 1, (profile, label, code.count(anchor))
        text = addition
        assert text not in code
        code = code.replace(anchor, anchor + text)
        additions.append({'label': label, 'anchor': anchor, 'inserted': text, 'side': 'after'})

    def before(anchor, addition, label):
        nonlocal code
        assert code.count(anchor) == 1, (profile, label, code.count(anchor))
        assert addition not in code
        code = code.replace(anchor, addition + anchor)
        additions.append({'label': label, 'anchor': anchor, 'inserted': addition, 'side': 'before'})

    if profile == 'i64':
        init = (
            "    observer_path=Path(__file__).with_name('integer_byte_evidence.py')\n"
            f"    assert SHA(observer_path.read_bytes())=={helper_sha!r}\n"
            "    evidence=runpy.run_path(str(observer_path),run_name='integer_byte_observer')['Evidence'](\n"
            "        out,'i64',a.reference,a.source,compiler,Path(__file__),Path.cwd())\n"
        )
        after('    assert SHA(compiler.read_bytes())==COMPILER_SHA\n', init, 'initialize-pinned-observer')
        after("        (out / f'compiler-{generation}.stderr').write_bytes(run.stderr)\n",
              '        evidence.compile_result(generation,run)\n', 'compiler-bytes')
        before('        run=subprocess.run([str(exe)],input=wire,capture_output=True,\n',
               '        evidence.request(wire)\n', 'request-bytes')
        after("                           timeout=45,env={'PATH':''})\n",
              '        evidence.native_result(run)\n', 'response-bytes')
        after("        row={'case':name,'mode':mode,'count':len(pairs),'status':'FAIL','mismatches':[]}\n",
              '        evidence.begin_case(name)\n', 'case-start')
        after('            want=source_reference(mode,pairs)\n',
              "            evidence.reference_bytes('cpython',b''.join(struct.pack('<Q',v) for v in want))\n", 'cpython-reference-bytes')
        after('                want_t=[v&MASK for v in op(lhs,rhs).tolist()]\n',
              "                evidence.reference_bytes('pytorch',b''.join(struct.pack('<Q',v) for v in want_t))\n", 'actual-Torch-reference-bytes')
        after("            raw_expected=b''.join(struct.pack('<Q',v) for v in want)\n",
              "            evidence.expected_bytes(raw_expected,'payload','pytorch' if torch is not None and pairs else ('cpython' if torch is None else 'empty-no-framework-operation'))\n", 'selected-expected-bytes')
        after("        row={'case':'refuse-'+name,'status':'FAIL'}\n",
              "        evidence.begin_case('refuse-'+name)\n        evidence.expected_bytes(b'\\x01\\0\\0\\0','full-response','protocol-literal')\n", 'refusal-literal-bytes')
        after("    (out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\\n')\n",
              "    evidence.finalize(out/'report.json')\n", 'final-byte-inventory')
    else:
        init = (
            "    observer_path=Path(__file__).with_name('integer_byte_evidence.py')\n"
            f"    assert SHA(observer_path.read_bytes())=={helper_sha!r}\n"
            "    evidence=runpy.run_path(str(observer_path),run_name='integer_byte_observer')['Evidence'](\n"
            "        output,'i8',a.reference,source,compiler,Path(__file__),repo)\n"
        )
        after('    assert SHA(compiler.read_bytes())==COMPILER_SHA\n', init, 'initialize-pinned-observer')
        after("        (output/f'compiler-{i}.stderr').write_bytes(r.stderr)\n",
              '        evidence.compile_result(i,r)\n', 'compiler-bytes')
        before("        proc=subprocess.run([str(exe)],input=raw_input,capture_output=True,timeout=90,env={'PATH':''})\n",
               '        evidence.request(raw_input)\n', 'request-bytes')
        after("        proc=subprocess.run([str(exe)],input=raw_input,capture_output=True,timeout=90,env={'PATH':''})\n",
              '        evidence.native_result(proc)\n', 'response-bytes')
        after("        row={'case':name,'mode':mode,'count':len(pairs),'status':'FAIL'}\n",
              '        evidence.begin_case(name)\n', 'case-start')
        after('            expected=bytes(one(mode,x,y) for x,y in pairs)\n',
              "            evidence.reference_bytes('cpython',expected)\n", 'cpython-reference-bytes')
        after('                want=bytes(v&255 for v in ops[mode](left,right).tolist())\n',
              "                evidence.reference_bytes('pytorch',want)\n", 'actual-Torch-reference-bytes')
        after('                expected=want\n',
              "            evidence.expected_bytes(expected,'payload','pytorch' if torch is not None and pairs else ('cpython' if torch is None else 'empty-no-framework-operation'))\n", 'selected-expected-bytes')
        after("        row={'case':'refuse-'+name,'status':'FAIL'}\n",
              "        evidence.begin_case('refuse-'+name)\n        evidence.expected_bytes(b'\\x01\\x00\\x00\\x00','full-response','protocol-literal')\n", 'refusal-literal-bytes')
        after("    (output/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\\n')\n",
              "    evidence.finalize(output/'report.json')\n", 'final-byte-inventory')
    ast.parse(code)
    inverse = code
    for addition in reversed(additions):
        text = addition['inserted']
        assert inverse.count(text) == 1
        inverse = inverse.replace(text, '', 1)
    assert inverse == original
    assert ast.dump(ast.parse(inverse), include_attributes=True) == ast.dump(ast.parse(original), include_attributes=True)
    target = FILES / 'tests' / (profile + '_oracle.py')
    assert not target.exists()
    target.write_text(code)
    proof['profiles'][profile] = {
        'baseline_sha256': sha(original.encode()), 'observed_sha256': sha(code.encode()),
        'byte_exact_inverse': True, 'whole_original_ast_including_positions_restored': True,
        'insertions_only': additions,
        'numeric_formula_threshold_native_argv_and_existing_assertions_unchanged': True,
    }


for profile in ('i64', 'i8'):
    observed(profile)
(ROOT / 'proposal/oracle-inverse-proof.json').write_text(json.dumps(proof, indent=2, sort_keys=True) + '\n')
print(json.dumps({p: {k: v for k, v in r.items() if k != 'insertions_only'} for p, r in proof['profiles'].items()}, sort_keys=True))
