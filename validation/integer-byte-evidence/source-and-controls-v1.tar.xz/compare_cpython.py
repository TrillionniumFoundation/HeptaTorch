#!/usr/bin/env python3
"""Run the unmodified and observation-only integer oracles on the same pinned compiler."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'cpython-control-01'
COMPILER = Path('/workspace/scratch/d26699e25fea/toolchain/hia-native-compiler')
EXPECTED_COMPILER = '87c247e4d1c3c9a449d2947fd4227fdc186d519bffd203a04cafce7861a4ed54'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    OUT.mkdir(exist_ok=False)
    inputs = [p for directory in [ROOT / 'baseline', ROOT / 'proposal/files/tests']
              for p in sorted(directory.rglob('*')) if p.is_file()] + [COMPILER]
    before = {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in inputs}
    assert sha(COMPILER) == EXPECTED_COMPILER

    def run_profile(profile):
        records = []
        for variant, script in [('baseline', ROOT / 'baseline/tests' / (profile + '_oracle.py')),
                                ('observed', ROOT / 'proposal/files/tests' / (profile + '_oracle.py'))]:
            dest = OUT / (profile + '-' + variant)
            argv = [sys.executable, '-I', '-S', '-B', str(script), '--compiler', str(COMPILER),
                    '--source', str(ROOT / 'baseline/tools' / ('native-' + profile) / (profile + '_elementwise.hepta')),
                    '--reference', 'cpython', '--output', str(dest)]
            if profile == 'i8':
                argv += ['--repo', str(ROOT / 'baseline'), '--expected-elf-sha256',
                         'eba8c05bfe514c38ffa1a5e1ccbc9aacd513531f74becd18f4e3dca73db0a0b1']
            result = subprocess.run(argv, cwd=ROOT / 'baseline', capture_output=True, timeout=180)
            (OUT / (profile + '-' + variant + '.stdout')).write_bytes(result.stdout)
            (OUT / (profile + '-' + variant + '.stderr')).write_bytes(result.stderr)
            record = {'profile': profile, 'variant': variant, 'argv': argv, 'cwd': str(ROOT / 'baseline'),
                      'returncode': result.returncode, 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                      'stderr_sha256': hashlib.sha256(result.stderr).hexdigest(), 'report_exists': (dest / 'report.json').is_file()}
            (OUT / (profile + '-' + variant + '.command.json')).write_text(json.dumps(record, indent=2) + '\n')
            records.append(record)
        if any(r['returncode'] != 0 for r in records):
            return {'profile': profile, 'status': 'FAIL', 'commands': records}
        original_raw = (OUT / (profile + '-baseline/report.json')).read_bytes()
        observed_raw = (OUT / (profile + '-observed/report.json')).read_bytes()
        original = json.loads(original_raw); observed = json.loads(observed_raw)
        key = 'oracle_script_sha256' if profile == 'i64' else 'oracle_source_sha256'
        assert original[key] == sha(ROOT / 'baseline/tests' / (profile + '_oracle.py'))
        assert observed[key] == sha(ROOT / 'proposal/files/tests' / (profile + '_oracle.py'))
        original_without_identity = {k: v for k, v in original.items() if k != key}
        observed_without_identity = {k: v for k, v in observed.items() if k != key}
        same = original_without_identity == observed_without_identity
        assert original['status'] == observed['status'] == 'PASS'
        return {'profile': profile, 'status': 'PASS' if same else 'FAIL', 'commands': records,
                'original_report_sha256': hashlib.sha256(original_raw).hexdigest(),
                'observed_report_sha256': hashlib.sha256(observed_raw).hexdigest(),
                'only_expected_changed_report_field': key,
                'all_other_report_fields_including_every_row_exact': same,
                'cases': len(original['rows']), 'compared_values': original['compared_values']}

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(run_profile, ['i64', 'i8']))
    after = {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in inputs}
    assert after == before
    report = {'schema': 'heptatorch.integer-observation-neutrality.cpython.v1',
              'status': 'PASS' if all(x['status'] == 'PASS' for x in results) else 'FAIL',
              'inputs_before': before, 'inputs_after': after,
              'all_source_and_compiler_bytes_unchanged': True, 'profiles': results,
              'actual_Torch_executions': 0, 'actual_original_and_observed_CPython_oracles': 4}
    (OUT / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('inputs_before', 'inputs_after')}, sort_keys=True))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
