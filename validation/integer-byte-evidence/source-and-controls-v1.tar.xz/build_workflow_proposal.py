#!/usr/bin/env python3
"""Preserve the original workflows and add complete byte custody with archive modes."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
proof = {}
for profile in ('i64', 'i8'):
    original = (ROOT / 'baseline/.github/workflows' / ('native-' + profile + '.yml')).read_text()
    current = original
    changes = []

    def replace(before, after, label):
        global current
        assert current.count(before) == 1, (profile, label)
        current = current.replace(before, after)
        changes.append({'label': label, 'before': before, 'after': after})

    if profile == 'i64':
        before = '    paths: ["tools/native-i64/**", "tests/i64_oracle.py", ".github/workflows/native-i64.yml"]\n'
        after = '    paths: ["tools/native-i64/**", "tests/i64_oracle.py", ".github/workflows/native-i64.yml", "tests/integer_byte_evidence.py", "tests/check_integer_byte_evidence.py"]\n'
    else:
        before = '      - ".github/workflows/native-i8.yml"\n'
        after = before + '      - "tests/integer_byte_evidence.py"\n      - "tests/check_integer_byte_evidence.py"\n'
    replace(before, after, 'Observe shared helper/reader changes')
    prefix = 'i64' if profile == 'i64' else 'native-i8'
    upload_name = 'Upload original independent reports' if profile == 'i64' else 'Upload unmodified source-bound reports'
    marker = '      - name: ' + upload_name + '\n'
    step = '''      - name: Preserve and verify complete original integer byte evidence
        if: always()
        run: |
          tar -cJf build/PREFIX-original-byte-evidence.tar.xz -C build PREFIX-cpython PREFIX-pytorch
          python3 -I -S -B tests/check_integer_byte_evidence.py \
            --profile PROFILE --reference cpython --directory build/PREFIX-cpython \
            --output build/PREFIX-byte-review-cpython.json
          python3 -I -S -B tests/check_integer_byte_evidence.py \
            --profile PROFILE --reference pytorch --directory build/PREFIX-pytorch \
            --output build/PREFIX-byte-review-pytorch.json
'''.replace('PROFILE', profile).replace('PREFIX', prefix)
    replace(marker, step + marker, 'Preserve modes and check complete original bytes before upload')
    provenance = 'provenance-report.json' if profile == 'i64' else 'provenance.json'
    before = '            build/' + prefix + '-pytorch/' + provenance + '\n'
    after = before + ('            build/PREFIX-original-byte-evidence.tar.xz\n'
                      '            build/PREFIX-byte-review-cpython.json\n'
                      '            build/PREFIX-byte-review-pytorch.json\n').replace('PREFIX', prefix)
    replace(before, after, 'Keep every old upload and add original byte archive and offline reviews')
    inverse = current
    for change in reversed(changes):
        assert inverse.count(change['after']) == 1
        inverse = inverse.replace(change['after'], change['before'], 1)
    assert inverse == original
    target = ROOT / 'proposal/files/.github/workflows' / ('native-' + profile + '.yml')
    target.write_text(current)
    proof[profile] = {
        'old_sha256': hashlib.sha256(original.encode()).hexdigest(),
        'new_sha256': hashlib.sha256(current.encode()).hexdigest(),
        'byte_exact_inverse': True, 'all_original_steps_and_their_order_recovered': True,
        'old_report_upload_paths_unchanged': True, 'changes': changes,
        'new_success_archive_preserves_original_file_modes': True,
        'no_new_hosted_execution_claimed': True,
    }
(ROOT / 'proposal/workflow-inverse-proof.json').write_text(json.dumps(proof, indent=2, sort_keys=True) + '\n')
print(json.dumps({p: {k: v for k, v in r.items() if k != 'changes'} for p, r in proof.items()}, sort_keys=True))
