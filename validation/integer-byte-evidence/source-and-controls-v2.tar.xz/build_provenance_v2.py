#!/usr/bin/env python3
"""Add independently recomputed provenance to the frozen v1 byte reader only."""
from pathlib import Path
import ast
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent
OLD = ROOT / 'proposal'
NEW = ROOT / 'proposal-v2'
READER = 'tests/check_integer_byte_evidence.py'
OLD_PIN = '04a392cbcb3cd07e5242ce1d0d7d83db60d515ceaba6e262165104c433f112c9'
LEGACY = Path('/dev/shm/heptatorch-d26699e25fea/integer-pr-hosted-review/review_integer_artifacts.py')
LEGACY_PIN = '0adc6f30ab5fe8bc980d527519d93e814e8537bbfe6c4fe01a36634183af5a6f'
sha = lambda b: hashlib.sha256(b).hexdigest()

ADDITION = '''def verify_provenance_fields(provenance, lock, c):
    """Check real recorded metadata, independently of the eleven boolean flags.

    The lock's complete wheel URL and both archive hash representations are
    required. Original CI paths remain observations; they are never rewritten
    to this offline reader's local extraction paths.
    """
    c.equal('provenance-fields/top-level-keys', set(provenance),
            {'status', 'lock_path', 'lock_sha256', 'expected', 'observed',
             'checks', 'metadata_error', 'release_source_equivalence'})
    c.equal('provenance-fields/status', provenance['status'], 'PASS')
    c.equal('provenance-fields/lock-sha', provenance['lock_sha256'], LOCK)
    c.equal('provenance-fields/lock-basename', Path(provenance['lock_path']).name,
            'pytorch-oracle-lock.json')
    c.equal('provenance-fields/expected-entire-object', provenance['expected'], lock['oracle'])
    c.equal('provenance-fields/source-equivalence-entire-object',
            provenance['release_source_equivalence'], lock['release_source_equivalence'])
    c.equal('provenance-fields/eleven-check-names', set(provenance['checks']), PROVENANCE_NAMES)
    for name, value in provenance['checks'].items():
        c.check('provenance-fields/executed-check/' + name, value is True)
    c.equal('provenance-fields/metadata-error', provenance['metadata_error'], None)
    observed = provenance['observed']
    expected = lock['oracle']
    c.equal('provenance-fields/observed-keys', set(observed),
            {'python', 'platform', 'version', 'git_commit', 'backend_versions',
             'distribution_version', 'direct_url', 'install_report'})
    for name in ('version', 'git_commit', 'backend_versions', 'platform'):
        c.equal('provenance-fields/actual-' + name, observed[name], expected[name])
    c.equal('provenance-fields/python-keys', set(observed['python']),
            {'implementation', 'version', 'full_version'})
    for name in ('implementation', 'version'):
        c.equal('provenance-fields/python-' + name, observed['python'][name], expected['python'][name])
    c.check('provenance-fields/python-full-version-observed',
            type(observed['python']['full_version']) is str and bool(observed['python']['full_version']))
    c.equal('provenance-fields/distribution-version', observed['distribution_version'], expected['version'])
    wheel = expected['wheel']
    expected_archive = {'hash': 'sha256=' + wheel['sha256'], 'hashes': {'sha256': wheel['sha256']}}
    expected_download = {'url': wheel['url'], 'archive_info': expected_archive}
    c.equal('provenance-fields/direct-url-entire-object', observed['direct_url'], expected_download)
    recorded = observed['install_report']
    c.equal('provenance-fields/install-report-keys', set(recorded),
            {'path', 'pip_version', 'download_info', 'metadata_name', 'metadata_version', 'requested'})
    c.equal('provenance-fields/install-report-path', recorded['path'], expected['install_report'])
    c.equal('provenance-fields/install-download-entire-object', recorded['download_info'], expected_download)
    c.equal('provenance-fields/install-metadata-name', recorded['metadata_name'], expected['distribution'])
    c.equal('provenance-fields/install-metadata-version', recorded['metadata_version'], expected['version'])
    c.check('provenance-fields/install-requested', recorded['requested'] is True)
    c.check('provenance-fields/pip-version-observed',
            type(recorded['pip_version']) is str and bool(recorded['pip_version']))


'''
CALL = '        verify_provenance_fields(provenance, lock, c)\n'


def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'mode': path.stat().st_mode & 0o777,
            'sha256': sha(data),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def main():
    assert not NEW.exists()
    old = (OLD / 'files' / READER).read_bytes()
    assert sha(old) == OLD_PIN and sha(LEGACY.read_bytes()) == LEGACY_PIN
    shutil.copytree(OLD / 'files', NEW / 'files', copy_function=shutil.copy2)
    code = old.decode()
    anchor = 'def verify(directory, profile, reference, c):\n'
    assert code.count(anchor) == 1
    code = code.replace(anchor, ADDITION + anchor, 1)
    location = "        c.equal('no-provenance-metadata-error', provenance['metadata_error'], None)\n"
    assert code.count(location) == 1
    code = code.replace(location, location + CALL, 1)
    ast.parse(code)
    path = NEW / 'files' / READER
    path.write_text(code)
    inverse = code.replace(ADDITION, '', 1).replace(CALL, '', 1).encode()
    assert inverse == old
    assert ast.dump(ast.parse(inverse), include_attributes=True) == ast.dump(ast.parse(old), include_attributes=True)
    changed = []
    files = {}
    for p in sorted((NEW / 'files').rglob('*')):
        if p.is_file():
            name = p.relative_to(NEW / 'files').as_posix()
            files[name] = identity(p)
            if p.read_bytes() != (OLD / 'files' / name).read_bytes(): changed.append(name)
    assert changed == [READER]
    legacy_ast = ast.parse(LEGACY.read_bytes())
    function = next(x for x in legacy_ast.body if isinstance(x, ast.FunctionDef) and x.name == 'provenance')
    segment = ast.get_source_segment(LEGACY.read_text(), function)
    proof = {'schema': 'heptatorch.integer-byte-provenance-v2-inverse.v1', 'status': 'PASS',
             'baseline_reader_sha256': OLD_PIN, 'new_reader_sha256': files[READER]['sha256'],
             'changed_repository_paths': changed,
             'unchanged_repository_paths': sorted(set(files) - set(changed)),
             'insertions_only': {'helper': ADDITION, 'call': CALL},
             'entire_v1_reader_exact_inverse': True, 'entire_v1_ast_with_positions_exact_inverse': True,
             'legacy_2044_reader_sha256': LEGACY_PIN, 'legacy_provenance_function_sha256': sha(segment.encode()),
             'legacy_provenance_function': segment,
             'scope': 'Provenance-only strengthening; no numeric corpus, oracle, observer, kernel, workflow or old check changed.',
             'new_Torch_execution_claimed': False}
    (NEW / 'reader-provenance-inverse-proof.json').write_text(json.dumps(proof, indent=2, sort_keys=True) + '\n')
    manifest = {'schema': 'heptatorch.integer-byte-proposal.v2', 'files': files,
                'previous_proposal_manifest_sha256': sha((OLD / 'manifest.json').read_bytes()),
                'new_Torch_status': 'NOT_RUN_REQUIRES_NEW_HOSTED_CI'}
    (NEW / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': 'PASS', 'files': files, 'inverse_sha256': sha((NEW / 'reader-provenance-inverse-proof.json').read_bytes())}))


if __name__ == '__main__':
    main()
