#!/usr/bin/env python3
"""Freeze separate v2 proof and raw archives without rewriting v1 evidence."""
from pathlib import Path
import hashlib
import json
import lzma
import stat
import tarfile

ROOT = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()


def file_pin(path):
    assert path.is_file() and not path.is_symlink()
    return {'bytes': path.stat().st_size, 'mode': stat.S_IMODE(path.stat().st_mode),
            'sha256': sha(path.read_bytes())}


def freeze(path, paths):
    assert not path.exists()
    records = {p.relative_to(ROOT).as_posix(): file_pin(p) for p in sorted(paths)}
    assert records
    with lzma.open(path, 'wb', preset=6) as output, tarfile.open(fileobj=output, mode='w|', format=tarfile.PAX_FORMAT) as tar:
        for name, pin in records.items():
            p = ROOT / name
            info = tarfile.TarInfo(name); info.size = pin['bytes']; info.mode = pin['mode']; info.mtime = 0
            with p.open('rb') as stream: tar.addfile(info, stream)
    with tarfile.open(path, 'r:xz') as tar:
        members = tar.getmembers()
        assert len(members) == len(records) and {m.name for m in members} == set(records)
        for member in members:
            assert member.isfile() and member.mode & 0o777 == records[member.name]['mode']
            raw = tar.extractfile(member).read()
            assert len(raw) == records[member.name]['bytes'] and sha(raw) == records[member.name]['sha256']
    with lzma.open(path, 'rb') as stream:
        while stream.read(1024 * 1024): pass
    assert all(file_pin(ROOT / name) == pin for name, pin in records.items())
    return {'archive': str(path), **file_pin(path), 'member_count': len(records),
            'expanded_bytes': sum(p['bytes'] for p in records.values()),
            'all_members_sha_bytes_mode_verified': True, 'exact_membership_verified': True,
            'full_xz_trailer_read': True, 'inputs_unchanged_after': True, 'files': records}


def main():
    handoff = ROOT / 'handoff-v2'; handoff.mkdir(exist_ok=False)
    for report in ['cpython-control-v2/report.json', 'provenance-controls-v2/report.json']:
        assert json.loads((ROOT / report).read_bytes())['status'] == 'PASS'
    raw_paths = [p for name in ['i64-observed', 'i8-observed']
                 for p in (ROOT / 'cpython-control-v2' / name).rglob('*') if p.is_file()]
    raw = freeze(ROOT / 'cpython-original-bytes-v2.tar.xz', raw_paths)
    (handoff / 'raw-archive-manifest.json').write_text(json.dumps(raw, indent=2, sort_keys=True) + '\n')
    paths = []
    for name in ['proposal-v2', 'provenance-controls-v2']:
        paths.extend(p for p in (ROOT / name).rglob('*') if p.is_file())
    paths.extend(p for p in (ROOT / 'cpython-control-v2').rglob('*')
                 if p.is_file() and 'evidence' not in p.relative_to(ROOT / 'cpython-control-v2').parts)
    paths.extend(ROOT / name for name in ['HANDOFF-v2.md', 'build_provenance_v2.py',
                  'compare_cpython_v2.py', 'test_provenance_v2.py', 'freeze_handoff_v2.py'])
    paths.append(handoff / 'raw-archive-manifest.json')
    manifest = {'schema': 'heptatorch.integer-byte-evidence-handoff.v2', 'status': 'PASS_LOCAL_CPYTHON_AND_PURE_METADATA',
                'new_Torch_status': 'NOT_RUN_REQUIRES_NEW_HOSTED_CI',
                'files': {p.relative_to(ROOT).as_posix(): file_pin(p) for p in sorted(paths)},
                'complete_new_raw_archive': {k:v for k,v in raw.items() if k != 'files'},
                'preserved_v1': {name: file_pin(ROOT / name) for name in [
                    'handoff-01.tar.xz', 'handoff-01/manifest.json', 'cpython-original-bytes-01.tar.xz',
                    'proposal/manifest.json', 'proposal/files/tests/check_integer_byte_evidence.py']}}
    manifest_path = handoff / 'manifest.json'
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    paths.append(manifest_path)
    small = freeze(ROOT / 'handoff-v2.tar.xz', paths)
    receipt = {k:v for k,v in small.items() if k != 'files'}
    receipt.update(status='PASS', manifest=file_pin(manifest_path),
                   raw_complete_original_bytes_archive={k:v for k,v in raw.items() if k != 'files'})
    (handoff / 'archive-verification.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps(receipt, sort_keys=True))


if __name__ == '__main__': main()
