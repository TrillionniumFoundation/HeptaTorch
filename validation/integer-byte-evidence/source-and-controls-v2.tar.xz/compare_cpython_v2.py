#!/usr/bin/env python3
"""Run only the two new observations; retain original/v1 results untouched."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'cpython-control-v2'
COMPILER = Path('/workspace/scratch/d26699e25fea/toolchain/hia-native-compiler')
EXPECTED_COMPILER = '87c247e4d1c3c9a449d2947fd4227fdc186d519bffd203a04cafce7861a4ed54'
READER = ROOT / 'proposal-v2/files/tests/check_integer_byte_evidence.py'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    OUT.mkdir(exist_ok=False)
    inputs = [p for directory in [ROOT / 'baseline', ROOT / 'proposal/files', ROOT / 'proposal-v2/files']
              for p in sorted(directory.rglob('*')) if p.is_file()] + [COMPILER, Path(__file__)]
    before = {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in inputs}
    assert sha(COMPILER) == EXPECTED_COMPILER
    def run_profile(profile):
        dest = OUT / (profile + '-observed')
        script = ROOT / 'proposal-v2/files/tests' / (profile + '_oracle.py')
        argv = [sys.executable, '-I', '-S', '-B', str(script), '--compiler', str(COMPILER),
                '--source', str(ROOT / 'baseline/tools' / ('native-' + profile) / (profile + '_elementwise.hepta')),
                '--reference', 'cpython', '--output', str(dest)]
        if profile == 'i8':
            argv += ['--repo', str(ROOT / 'baseline'), '--expected-elf-sha256',
                     'eba8c05bfe514c38ffa1a5e1ccbc9aacd513531f74becd18f4e3dca73db0a0b1']
        result = subprocess.run(argv, cwd=ROOT / 'baseline', capture_output=True, timeout=180)
        (OUT / (profile + '.stdout')).write_bytes(result.stdout)
        (OUT / (profile + '.stderr')).write_bytes(result.stderr)
        command = {'argv': argv, 'cwd': str(ROOT / 'baseline'), 'returncode': result.returncode,
                   'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                   'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
        (OUT / (profile + '.command.json')).write_text(json.dumps(command, indent=2) + '\n')
        assert result.returncode == 0, (profile, result.returncode)
        original_path = ROOT / 'cpython-control-01' / (profile + '-baseline/report.json')
        v1_path = ROOT / 'cpython-control-01' / (profile + '-observed/report.json')
        original_raw = original_path.read_bytes(); v1_raw = v1_path.read_bytes()
        actual_raw = (dest / 'report.json').read_bytes()
        original = json.loads(original_raw); actual = json.loads(actual_raw)
        key = 'oracle_script_sha256' if profile == 'i64' else 'oracle_source_sha256'
        assert original['status'] == actual['status'] == 'PASS'
        assert actual[key] == sha(script)
        assert actual_raw == v1_raw
        assert {k:v for k,v in original.items() if k != key} == {k:v for k,v in actual.items() if k != key}
        previous = ROOT / 'cpython-control-01' / (profile + '-observed')
        oldfiles = {p.relative_to(previous).as_posix(): p for p in previous.rglob('*') if p.is_file()}
        newfiles = {p.relative_to(dest).as_posix(): p for p in dest.rglob('*') if p.is_file()}
        assert set(oldfiles) == set(newfiles)
        differences = sorted(name for name in oldfiles if oldfiles[name].read_bytes() != newfiles[name].read_bytes())
        assert differences == ['byte-evidence.json', 'evidence/sources/reader.py'], differences
        assert (dest / 'evidence/sources/reader.py').read_bytes() == READER.read_bytes()
        review_path = OUT / (profile + '-byte-review.json')
        review_argv = [sys.executable, '-I', '-S', '-B', str(READER), '--directory', str(dest),
                       '--profile', profile, '--reference', 'cpython', '--output', str(review_path)]
        review = subprocess.run(review_argv, capture_output=True, timeout=120)
        (OUT / (profile + '-reader.stdout')).write_bytes(review.stdout)
        (OUT / (profile + '-reader.stderr')).write_bytes(review.stderr)
        assert review.returncode == 0, (profile, review.stderr.decode())
        reader_report = json.loads(review_path.read_bytes())
        assert reader_report['status'] == 'PASS'
        return {'profile': profile, 'status': 'PASS', 'actual_observed_command': command,
                'baseline_report_reused_not_reexecuted': str(original_path), 'baseline_report_sha256': sha(original_path),
                'v1_observed_report_preserved': str(v1_path), 'v1_report_sha256': sha(v1_path),
                'v2_report_sha256': sha(dest / 'report.json'), 'entire_v1_observed_report_byte_identical': True,
                'entire_original_report_equal_except_oracle_self_sha': key,
                'only_new_raw_file_differences': differences, 'all_other_raw_files_byte_identical': True,
                'complete_relative_file_count': len(newfiles), 'cases': len(actual['rows']),
                'compared_values': actual['compared_values'], 'offline_reader_argv': review_argv,
                'offline_reader_report_sha256': sha(review_path)}
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(run_profile, ['i64','i8']))
    after = {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in inputs}
    assert after == before
    report = {'schema': 'heptatorch.integer-provenance-v2-cpython-neutrality.v1', 'status': 'PASS',
              'actual_Torch_executions': 0, 'actual_v2_CPython_oracles': 2,
              'original_and_v1_CPython_not_reexecuted': True, 'all_source_and_compiler_bytes_unchanged': True,
              'inputs_before': before, 'inputs_after': after, 'profiles': results}
    (OUT / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('inputs_before','inputs_after')},sort_keys=True))


if __name__ == '__main__':
    main()
