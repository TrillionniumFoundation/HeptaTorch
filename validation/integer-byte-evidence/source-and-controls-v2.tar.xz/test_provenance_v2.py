#!/usr/bin/env python3
"""Three copied-JSON attacks against each original, real hosted provenance.

This invokes only the reader's pure metadata checker. It does not import Torch,
start a native process, create a simulated numerical result, or alter a frozen
artifact. The positive metadata came from the separately admitted original CI.
"""
from pathlib import Path
import hashlib
import json
import runpy
import traceback

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'provenance-controls-v2'
READER = ROOT / 'proposal-v2/files/tests/check_integer_byte_evidence.py'
READER_PIN = '83b79fb7fd9f7b3fec442f45f448ab9648aea72c56e690c0c0a0cf4bd8bb3750'
ORIGINAL = Path('/dev/shm/heptatorch-d26699e25fea/integer-pr-hosted-review/admission-01/artifacts')
sha = lambda b: hashlib.sha256(b).hexdigest()


def main():
    OUT.mkdir(exist_ok=False)
    inputs = {str(READER): READER.read_bytes(),
              str(ROOT / 'baseline/compatibility/pytorch-oracle-lock.json'):
              (ROOT / 'baseline/compatibility/pytorch-oracle-lock.json').read_bytes()}
    report = {'schema': 'heptatorch.integer-byte-provenance-copied-controls.v1',
              'status': 'RUNNING', 'positive_original_hosted_metadata': [], 'negative_controls': [],
              'actual_native_executions': 0, 'actual_Torch_executions': 0,
              'scope': 'Pure copied provenance JSON; not the new full byte-evidence Torch pipeline.'}
    def save():
        (OUT / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    try:
        assert sha(inputs[str(READER)]) == READER_PIN
        namespace = runpy.run_path(str(READER), run_name='copied_integer_provenance_controls')
        assert READER.read_bytes() == inputs[str(READER)]
        lock = json.loads(inputs[str(ROOT / 'baseline/compatibility/pytorch-oracle-lock.json')])
        for profile, relative, key in (
                ('i64', 'i64/i64-pytorch/report.json', 'oracle_provenance'),
                ('i8', 'i8/native-i8-pytorch/report.json', 'provenance')):
            path = ORIGINAL / relative
            original_raw = path.read_bytes(); inputs[str(path)] = original_raw
            original_report = json.loads(original_raw)
            assert original_report['status'] == 'PASS' and original_report['reference'] == 'pytorch'
            original = original_report[key]
            (OUT / (profile + '-original-hosted-report.json')).write_bytes(original_raw)
            check = namespace['Checks']()
            namespace['verify_provenance_fields'](original, lock, check)
            report['positive_original_hosted_metadata'].append({
                'profile': profile, 'status': 'PASS', 'original_report_sha256': sha(original_raw),
                'checks': check.rows, 'original_actual_CI_not_reexecuted': True})
            for name, mutate, expected_rule in (
                ('all-flags-true-but-direct-url-hash-wrong',
                 lambda p: p['observed']['direct_url']['archive_info'].__setitem__('hash', 'sha256=' + '0' * 64),
                 'provenance-fields/direct-url-entire-object'),
                ('all-flags-true-but-installed-distribution-wrong',
                 lambda p: p['observed'].__setitem__('distribution_version', '0.0.0+wrong'),
                 'provenance-fields/distribution-version'),
                ('all-flags-true-but-install-report-path-wrong',
                 lambda p: p['observed']['install_report'].__setitem__('path', 'build/another-install.json'),
                 'provenance-fields/install-report-path')):
                changed = json.loads(json.dumps(original))
                mutate(changed)
                assert len(changed['checks']) == 11 and all(v is True for v in changed['checks'].values())
                raw = (json.dumps(changed, indent=2, sort_keys=True) + '\n').encode()
                target = OUT / (profile + '-' + name + '.json'); target.write_bytes(raw)
                negative = namespace['Checks']()
                try:
                    namespace['verify_provenance_fields'](changed, lock, negative)
                except AssertionError as error:
                    assert error.args == (expected_rule,), (name, error.args, expected_rule)
                    report['negative_controls'].append({'profile': profile, 'name': name,
                        'status': 'EXPECTED_REFUSAL', 'expected_rule': expected_rule,
                        'observed_rule': error.args[0], 'all_eleven_flags_remain_true': True,
                        'copied_input': target.name, 'copied_sha256': sha(raw), 'checks': negative.rows})
                else:
                    raise AssertionError(('unexpected accepted mutation', profile, name))
                assert original == json.loads(original_raw)[key]
                save()
        assert len(report['positive_original_hosted_metadata']) == 2 and len(report['negative_controls']) == 6
        assert all(Path(name).read_bytes() == raw for name, raw in inputs.items())
        report.update(status='PASS', rules=3, profiles=2, positive_count=2, negative_count=6,
                      all_original_inputs_unchanged=True,
                      inputs={name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in inputs.items()})
        save()
        print(json.dumps({k:v for k,v in report.items() if k not in ('inputs','positive_original_hosted_metadata','negative_controls')}))
        return 0
    except BaseException as error:
        report.update(status='FAIL', error=repr(error), traceback=traceback.format_exc())
        save(); raise


if __name__ == '__main__':
    raise SystemExit(main())
