#!/usr/bin/env python3
"""Read-only source/custody admission of the28 proposed integration files."""
import argparse
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import traceback

PREVIOUS = '0fd81b279c97dd969071c9efc51c8202fc16e45b'
MAIN = 'e0ea769c979236b0542af4b258890726cd01a99a'
sha = lambda b: hashlib.sha256(b).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('files', 'git-dir', 'evidence', 'historical', 'output'):
        p.add_argument('--' + name, required=True, type=Path)
    a = p.parse_args(); out = a.output.resolve(); out.mkdir(exist_ok=False, parents=True)
    records, checks = {}, []
    report = {'schema': 'heptatorch.integer-main-proposal-source-review.v1',
              'status': 'RUNNING', 'native_executed': False, 'Torch_executed': False,
              'hosted_admission': False, 'official_source_head': None, 'checks': checks}
    def save(): (out / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    def need(label, condition):
        checks.append({'name': label, 'passed': condition is True})
        if condition is not True: raise AssertionError(label)
    def read(path):
        path = path.resolve(); raw = path.read_bytes()
        now = {'sha256': sha(raw), 'bytes': len(raw), 'mode': stat.S_IMODE(path.stat().st_mode)}
        need('regular input ' + str(path), path.is_file() and not path.is_symlink())
        if str(path) in records: need('unchanged read ' + str(path), records[str(path)] == now)
        records[str(path)] = now
        return raw
    def git(spec):
        proc = subprocess.run(['git', '--git-dir', str(a.git_dir), 'cat-file', 'blob', spec], capture_output=True)
        need('read immutable Git blob ' + spec, proc.returncode == 0)
        return proc.stdout
    try:
        paths = {q.relative_to(a.files).as_posix(): q for q in a.files.rglob('*') if q.is_file()}
        need('exactly28regular integration files', len(paths) == 28)
        need('total proposed file bytes', sum(q.stat().st_size for q in paths.values()) == 20712167)
        mapped = {}
        for name in ['.github/workflows/native-i64.yml', 'tests/check_integer_byte_evidence.py',
                     'tests/i64_oracle.py', 'tests/integer_byte_evidence.py']:
            mapped[name] = a.evidence / 'proposal-v2/files' / name
        for target, original in {
            'HANDOFF-v1.md':'HANDOFF.md', 'HANDOFF-v2.md':'HANDOFF-v2.md',
            'cpython-control-v2.json':'cpython-control-v2/report.json',
            'proposal-v2.json':'proposal-v2/manifest.json',
            'provenance-controls-v2.json':'provenance-controls-v2/report.json',
            'source-and-controls-v1-manifest.json':'handoff-01/manifest.json',
            'source-and-controls-v1.tar.xz':'handoff-01.tar.xz',
            'source-and-controls-v2-manifest.json':'handoff-v2/manifest.json',
            'source-and-controls-v2.tar.xz':'handoff-v2.tar.xz',
        }.items(): mapped['validation/integer-byte-evidence/' + target] = a.evidence / original
        for target, original in {'README.md':'README.md', 'handoff-01.tar.xz':'handoff-01.tar.xz',
                                 'manifest.json':'handoff-01/manifest.json'}.items():
            mapped['validation/integer-original-hosted-admission/' + target] = a.historical / original
        mapped['validation/native-i64-cpython.json'] = a.evidence / 'cpython-control-01/i64-baseline/report.json'
        admitted = set()
        for name, original in mapped.items():
            need('installed original byte identity ' + name, read(paths[name]) == read(original))
            need('installed mode identity ' + name, records[str(paths[name].resolve())]['mode'] == records[str(original.resolve())]['mode'])
            admitted.add(name)
        for name in ['tools/native-i64/README.md', 'tools/native-i64/i64_elementwise.hepta']:
            need('unchanged original PR29 source ' + name, read(paths[name]) == git(PREVIOUS + ':' + name))
            admitted.add(name)
        for generation, original, expected_sha in [
            ('v1', 'cpython-original-bytes-01.tar.xz', '1c0ed412e93464c4c02c4a09016a6e9770505c21295049895179ab5915de7906'),
            ('v2', 'cpython-original-bytes-v2.tar.xz', '68c910ac7cb8530bdff0daa76252a1bd7f96aaa898f2e6a7f1efe969b06e802b')]:
            prefix = 'validation/integer-byte-evidence/cpython-' + generation
            name = prefix + '/archive-parts.json'
            spec = json.loads(read(paths[name])); admitted.add(name)
            need(generation + ' part-manifest exact schema', set(spec) == {'schema','target','bytes','sha256','mode','parts'}
                 and spec['schema'] == 'heptatorch.frozen-archive-parts.v1')
            need(generation + ' three ordered parts', [x['path'] for x in spec['parts']] == [prefix + '/parts/part-' + str(i).zfill(3) + '.bin' for i in range(3)])
            chunks = []
            for i, row in enumerate(spec['parts']):
                raw = read(paths[row['path']]); admitted.add(row['path'])
                need(generation + ' exact part fields', set(row) == {'path','bytes','sha256'})
                need(generation + ' exact part bytes ' + str(i), len(raw) == row['bytes'] and sha(raw) == row['sha256'])
                need(generation + ' transfer bound ' + str(i), 0 < len(raw) <= 4 << 20)
                chunks.append(raw)
            combined = b''.join(chunks)
            need(generation + ' exact original complete archive', combined == read(a.evidence / original))
            need(generation + ' declared complete archive identity', sha(combined) == spec['sha256'] == expected_sha
                 and len(combined) == spec['bytes'] and spec['mode'] == 0o644
                 and spec['target'] == prefix + '/' + original)
        name='validation/integer-original-hosted-admission/root-reproduction.json'
        receipt=json.loads(read(paths[name]));admitted.add(name)
        original=read(a.historical / 'review-01/report.json')
        need('root2044 receipt exact scope', receipt == {
            'schema':'heptatorch.integer-independent-root-reproduction.v1',
            'status':'PASS_SCOPED_ORIGINAL_HOSTED_EVIDENCE','checks':2044,'failed':0,
            'root_and_peer_full_report_bytes_equal':True,'report_sha256':sha(original),'report_bytes':len(original),
            'native_executed':False,'Torch_executed':False,'new_main_tree_qualified':False,
            'new_byte_observer_Torch_execution_not_claimed':True})
        need('complete28file role attribution', admitted == set(paths))
        need('kernel fixed2517', sha(read(paths['tools/native-i64/i64_elementwise.hepta'])) == '251705542f4e117e3c9cdaec36cead8ab38252b24ebfef1104d765c546fd0716')
        for name, expected in [('tests/pytorch_oracle.py','ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'),
                               ('compatibility/pytorch-oracle-lock.json','ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944')]:
            need('newmain fixed provenance source ' + name, sha(git(MAIN + ':' + name)) == expected)
            need('oldPR29 same provenance source ' + name, git(PREVIOUS + ':' + name) == git(MAIN + ':' + name))
        report['prepared_paths']={name:{**records[str(path.resolve())],
            'git_blob':hashlib.sha1(b'blob '+str(path.stat().st_size).encode()+b'\0'+read(path)).hexdigest()} for name,path in sorted(paths.items())}
        for name, pin in list(records.items()):
            raw=Path(name).read_bytes();need('final input unchanged ' + name, sha(raw)==pin['sha256'] and len(raw)==pin['bytes'] and stat.S_IMODE(Path(name).stat().st_mode)==pin['mode'])
        report.update(status='PASS_SOURCE_ONLY_PREPARED_NOT_RUN', checks_passed=len(checks), checks_failed=0,
                      files=28, total_bytes=20712167, inputs=records,
                      expected_source_parent_order=[PREVIOUS,MAIN],
                      original_hia_expected_and_eleven_provenance_sources_unchanged=True)
        save();print(json.dumps({k:report[k] for k in ['status','files','total_bytes','checks_passed','hosted_admission']}))
    except BaseException as error:
        report.update(status='FAIL',error=repr(error),traceback=traceback.format_exc(),inputs=records)
        save();raise


if __name__=='__main__':main()
