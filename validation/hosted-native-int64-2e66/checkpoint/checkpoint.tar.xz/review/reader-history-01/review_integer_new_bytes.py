#!/usr/bin/env python3
"""Admit newly executed integer CI using original bytes and frozen pure readers.

No native application, compiler or Torch is invoked. The only child command is
Git's read-only object lookup. All hosted inputs must name a new exact source
commit, its expected parent list, the official run/job/attempt and original ZIP.
"""
import argparse
import hashlib
import json
import lzma
from pathlib import Path, PurePosixPath
import re
import runpy
import stat
import subprocess
import tarfile
import traceback
import zipfile

REPO = 'TrillionniumFoundation/HeptaTorch'
READER_SHA = '83b79fb7fd9f7b3fec442f45f448ab9648aea72c56e690c0c0a0cf4bd8bb3750'
HISTORICAL_SHA = '0adc6f30ab5fe8bc980d527519d93e814e8537bbfe6c4fe01a36634183af5a6f'
COMPILER = '87c247e4d1c3c9a449d2947fd4227fdc186d519bffd203a04cafce7861a4ed54'
OBSERVER = '6a5ff8a8a6f920f8734f9c5a26533ba26d71965d8de4fbbf1e7f7aa1c631f453'
SUPPORT = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
TOOLCHAIN = 'f33d8da316de8fdf27b504371f1a5310997ff548'
PROFILES = {
    'i64': {'workflow': '5663c7ff358305623d9ac657170afb923e108d26e08320e93d489bd25acf20fc',
            'oracle': '1896142e1c25abe9478e84ffc7ffe735fd82ef3ba129504bd40e6dbdcc777f74',
            'kernel': '251705542f4e117e3c9cdaec36cead8ab38252b24ebfef1104d765c546fd0716',
            'image': 'fbb6cf1648385be200c94fc14ed73d1539cba3b0239aeea4f7866058c8395ebc',
            'folder': 'i64', 'rows': 33, 'values': 351174,
            'files': {'cpython': 207, 'pytorch': 226}},
    'i8': {'workflow': 'c8c0987f9b6412717c92abdd52d072cfbc1e99b4466313633f47c540ae2b0c79',
           'oracle': '3eb05c82a7951be3bb2b21349f8af903bd0f92f3bb00243f39c25be250f7fac9',
           'kernel': '7ca1765e2cede95ec19b64742f69816581733619b5b1b844f57aa72b743ed8d3',
           'image': 'eba8c05bfe514c38ffa1a5e1ccbc9aacd513531f74becd18f4e3dca73db0a0b1',
           'folder': 'native-i8', 'rows': 28, 'values': 1093216,
           'files': {'cpython': 177, 'pytorch': 191}},
}


def sha(raw): return hashlib.sha256(raw).hexdigest()
def gitsha(kind, raw): return hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result: raise AssertionError(('duplicate JSON key', key))
        result[key] = value
    return result


def decode(raw): return json.loads(raw, object_pairs_hook=unique)


class Audit:
    def __init__(self): self.checks, self.inputs = [], {}
    def check(self, name, condition):
        self.checks.append({'name': name, 'passed': condition is True})
        if condition is not True: raise AssertionError(name)
    def equal(self, name, actual, expected):
        self.check(name, type(actual) is type(expected) and actual == expected)
    def read(self, path):
        path = Path(path).resolve(); raw = path.read_bytes()
        pin = {'bytes': len(raw), 'sha256': sha(raw), 'mode': stat.S_IMODE(path.stat().st_mode)}
        if str(path) in self.inputs: self.equal('unchanged input ' + str(path), pin, self.inputs[str(path)])
        else: self.inputs[str(path)] = pin
        return raw
    def doc(self, path): return decode(self.read(path))
    def finish(self):
        for path in list(self.inputs): self.read(path)


def safe_name(name):
    path = PurePosixPath(name)
    assert name and not path.is_absolute() and '..' not in path.parts and '\\' not in name
    assert str(path) == name
    return path


def source(a, spec, out):
    profile = spec['profile']; pins = PROFILES[profile]
    commit = a.doc(spec['source_commit']); payload = commit.get('commit', commit)
    a.equal('official exact source head', commit['sha'], spec['source_head'])
    a.equal('official exact source tree', payload['tree']['sha'], spec['source_tree'])
    a.equal('official source parent order', [x['sha'] for x in commit['parents']], spec['source_parents'])
    gitdir = Path(spec['source_git_dir']).resolve()
    def obj(kind, name):
        result = subprocess.run(['git','--git-dir',str(gitdir),'cat-file',kind,name],capture_output=True)
        a.equal('read-only Git object exit ' + name, result.returncode, 0)
        return result.stdout
    raw_commit = obj('commit', spec['source_head'])
    a.equal('local immutable commit hash', gitsha('commit', raw_commit), spec['source_head'])
    header = raw_commit.split(b'\n\n',1)[0].splitlines()
    a.equal('commit object tree agrees with official', next(x[5:].decode() for x in header if x.startswith(b'tree ')), spec['source_tree'])
    a.equal('commit object parents agree with official', [x[7:].decode() for x in header if x.startswith(b'parent ')], spec['source_parents'])
    sources = {}
    required = {'.github/workflows/native-' + profile + '.yml':pins['workflow'],
                'tools/native-' + profile + '/' + profile + '_elementwise.hepta':pins['kernel'],
                'tests/' + profile + '_oracle.py':pins['oracle'],
                'tests/integer_byte_evidence.py':OBSERVER,
                'tests/check_integer_byte_evidence.py':READER_SHA,
                'tests/pytorch_oracle.py':SUPPORT,
                'compatibility/pytorch-oracle-lock.json':LOCK}
    for name, expected in required.items():
        raw = obj('blob', spec['source_head'] + ':' + name)
        a.equal('exact source pin ' + name, sha(raw), expected)
        entry = subprocess.check_output(['git','--git-dir',str(gitdir),'ls-tree','-z',spec['source_head'],'--',name])
        metadata, path = entry[:-1].split(b'\t',1)
        mode, kind, oid = metadata.split()
        a.equal('source tree entry path ' + name, path.decode(), name)
        a.equal('source tree entry kind ' + name, kind, b'blob')
        a.check('source tree entry mode ' + name, mode in (b'100644', b'100755'))
        a.equal('source Git blob byte identity ' + name, gitsha('blob',raw), oid.decode())
        target = out / 'source' / name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(raw)
        target.chmod(int(mode,8) & 0o777)
        sources[name] = raw
    return sources


def official_run(a, spec, workflow):
    run = a.doc(spec['run']); jobs = a.doc(spec['jobs']); checkout = a.doc(spec['checkout_commit'])
    a.equal('official repository', run['repository']['full_name'], REPO)
    for key, expected in [('id',spec['run_id']),('head_sha',spec['source_head']),
                          ('event',spec['event']),('status','completed'),('conclusion','success'),
                          ('run_attempt',spec['run_attempt']),('path','.github/workflows/native-' + spec['profile'] + '.yml')]:
        a.equal('official run ' + key, run[key], expected)
    a.equal('official run source tree', run['head_commit']['tree_id'], spec['source_tree'])
    a.equal('dedicated workflow has one job', jobs['total_count'], 1)
    a.equal('one complete job object', len(jobs['jobs']), 1)
    job = jobs['jobs'][0]
    for key, expected in [('id',spec['job_id']),('run_id',spec['run_id']),('head_sha',spec['source_head']),
                          ('run_attempt',spec['run_attempt']),('status','completed'),('conclusion','success')]:
        a.equal('official job ' + key, job[key], expected)
    names = re.findall(r'^      - name: (.+)$', workflow.decode(), re.M)
    a.equal('seven exact named steps in frozen dedicated source', len(names), 7)
    checkout_name = 'Run actions/checkout@d23441a48e516b6c34aea4fa41551a30e30af803'
    expected = ['Set up job',checkout_name,checkout_name,*names,'Post '+checkout_name,'Post '+checkout_name,'Complete job']
    a.equal('all13 actual steps exact order', [x['name'] for x in job['steps']], expected)
    a.equal('unique ordered job step numbers', [x['number'] for x in job['steps']], sorted({x['number'] for x in job['steps']}))
    for step in job['steps']:
        a.equal('step actual terminal success ' + step['name'], [step['status'],step['conclusion']], ['completed','success'])
    a.equal('exact checkout tree', checkout.get('commit',checkout)['tree']['sha'], spec['source_tree'])
    if spec['event'] == 'pull_request':
        a.equal('merge parents exact current base and source', [x['sha'] for x in checkout['parents']], [spec['base'],spec['source_head']])
    else:
        a.check('supported direct run event', spec['event'] in ('push','workflow_dispatch'))
        a.equal('direct checkout exact source', checkout['sha'], spec['source_head'])
    return run, job, checkout


def artifact(a, spec, run):
    listing = a.doc(spec['artifact']['metadata'])
    a.equal('one dedicated artifact count', listing['total_count'], 1)
    a.equal('one complete artifact entry', len(listing['artifacts']), 1)
    metadata = listing['artifacts'][0]; pin=spec['artifact']
    for key, value in [('id',pin['id']),('name','native-'+spec['profile']+'-evidence'),
                       ('size_in_bytes',pin['bytes']),('digest','sha256:'+pin['sha256']),('expired',False)]:
        a.equal('official artifact ' + key, metadata[key], value)
    a.equal('artifact official workflow run', metadata['workflow_run']['id'], run['id'])
    a.equal('artifact official source head', metadata['workflow_run']['head_sha'], spec['source_head'])
    a.check('artifact created in this exact attempt', run['run_started_at'] <= metadata['created_at'] <= run['updated_at'])
    raw = a.read(pin['zip']); a.equal('originalZIP bytes',len(raw),pin['bytes']);a.equal('originalZIP SHA',sha(raw),pin['sha256'])
    members={}
    with zipfile.ZipFile(pin['zip']) as archive:
        a.equal('original ZIP CRC integrity',archive.testzip(),None)
        for member in archive.infolist():
            if member.is_dir(): continue
            safe_name(member.filename)
            a.check('ordinary unique ZIP member '+member.filename,member.filename not in members and not stat.S_ISLNK(member.external_attr >> 16))
            members[member.filename]=archive.read(member)
            a.equal('ZIP original member length '+member.filename,len(members[member.filename]),member.file_size)
    folder=PROFILES[spec['profile']]['folder']
    wanted={folder+'-custody.json',folder+'-original-byte-evidence.tar.xz'}
    wanted.update(folder+'-'+r+'/report.json' for r in ('cpython','pytorch'))
    wanted.update(folder+'-byte-review-'+r+'.json' for r in ('cpython','pytorch'))
    a.equal('six exact root evidence members',set(members),wanted)
    return members,metadata


def unpack_original(a, archive_path, destination, profile):
    folder=PROFILES[profile]['folder']; roots={folder+'-'+r for r in ('cpython','pytorch')}
    destination.mkdir(exist_ok=False)
    inventory={}; directories=set(); total=0
    with tarfile.open(archive_path,'r:xz') as tar:
        members=tar.getmembers()
        a.check('bounded complete tar members',0<len(members)<2048)
        for member in members:
            name=member.name.rstrip('/') if member.isdir() else member.name
            path=safe_name(name)
            a.check('tar stays within the two reference roots '+name,path.parts[0] in roots)
            a.check('unique original tar path '+name,name not in inventory and name not in directories)
            a.check('ordinary file or directory only '+name,member.isfile() or member.isdir())
            if member.isdir(): directories.add(name);continue
            total+=member.size
            a.check('bounded original file bytes '+name,member.size>=0 and total<=128<<20)
            raw=tar.extractfile(member).read()
            a.equal('complete original tar member length '+name,len(raw),member.size)
            a.check('no special mode bits '+name,member.mode & ~0o777 == 0)
            target=destination/path;target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(raw);target.chmod(member.mode)
            inventory[name]={'bytes':len(raw),'sha256':sha(raw),'mode':member.mode}
        a.equal('fixed complete reference file total',len(inventory),sum(PROFILES[profile]['files'].values()))
    with lzma.open(archive_path,'rb') as stream:
        while stream.read(1024*1024):pass
    expected_directories={str(parent) for name in inventory for parent in PurePosixPath(name).parents if str(parent)!='.'}
    a.equal('all and only actual parent directory entries',directories,expected_directories)
    for name,pin in inventory.items():
        target=destination/name
        a.equal('restored tar mode '+name,stat.S_IMODE(target.stat().st_mode),pin['mode'])
        a.equal('restored tar SHA '+name,sha(target.read_bytes()),pin['sha256'])
    return inventory


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--inputs',type=Path,required=True)
    p.add_argument('--historical-reader',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    a=Audit();report={'schema':'heptatorch.integer-new-byte-hosted-admission.v1','status':'FAIL',
        'admission_allowed':False,'native_executed_by_reader':False,'Torch_executed_by_reader':False,
        'whole_pytorch_rewrite_complete':False,'full_schema_parity':0,'pytorch_api_denominator':2590,'whole_project_decision':'HOLD'}
    try:
        spec=a.doc(args.inputs);profile=spec['profile'];pins=PROFILES[profile]
        a.equal('explicit new-hosted input schema',spec['schema'],'heptatorch.integer-new-byte-hosted-inputs.v1')
        a.check('input forbids inherited result admission',spec['reuse_old_hosted_result'] is False)
        sources=source(a,spec,out)
        workflow=sources['.github/workflows/native-'+profile+'.yml']
        run,job,checkout=official_run(a,spec,workflow)
        members,metadata=artifact(a,spec,run)
        folder=pins['folder'];custody=decode(members[folder+'-custody.json'])
        a.equal('original custody checkout',custody['head' if profile=='i64' else 'checkout_sha'],checkout['sha'])
        a.equal('original custody exact tree',custody['tree' if profile=='i64' else 'checkout_tree'],spec['source_tree'])
        if profile=='i8':a.equal('original GitHub checkout',custody['github_sha'],checkout['sha'])
        fields={'source_sha256':pins['kernel'],'reference_sha256':pins['oracle'],'torch_lock_sha256':LOCK,'compiler_sha256':COMPILER} if profile=='i64' else {
            'source_sha':pins['kernel'],'oracle_sha':pins['oracle'],'lock_sha':LOCK,'compiler_sha':COMPILER}
        for key,value in fields.items():a.equal('actual custody '+key,custody[key],value)
        a.equal('no separate failed provenance receipt on success',custody['provenance_report_sha256' if profile=='i64' else 'torch_provenance_sha'],None)
        if profile=='i8':a.check('no whole rewrite claim',custody['whole_rewrite_complete'] is False)
        archive_path=out/(folder+'-original-byte-evidence.tar.xz');archive_path.write_bytes(members[archive_path.name])
        inventory=unpack_original(a,archive_path,out/'extracted',profile)
        reader_path=out/'source/tests/check_integer_byte_evidence.py'
        a.equal('frozen v2 byte reader',sha(reader_path.read_bytes()),READER_SHA)
        reader=runpy.run_path(str(reader_path),run_name='unchanged_integer_byte_reader')
        historical_raw=a.read(args.historical_reader);a.equal('immutable original2044 reader',sha(historical_raw),HISTORICAL_SHA)
        historical=runpy.run_path(str(args.historical_reader),run_name='unchanged_historical_integer_reader')
        historical['PROFILES'][profile]['oracle']=pins['oracle']
        old_review=historical['Review'](out)
        log=a.read(spec['job_log']).decode();log=re.sub(r'\x1b\[[0-9;]*m','',log)
        a.check('actual job log exact checkout',checkout['sha'] in log)
        a.check('actual pinned compiler bootstrap log',TOOLCHAIN in log and ('PASS native HIA compiler reproduction' if profile=='i64' else 'Pinned native compiler reproduced') in log)
        a.check('no optimized assertions disabled', 'PYTHONOPTIMIZE' not in log and 'python3 -O' not in log)
        printed=[]
        for line in log.splitlines():
            line=re.sub(r'^\d{4}-\d{2}-\d{2}T[^ ]+ ','',line)
            if line.startswith('{'):
                try:printed.append(decode(line))
                except json.JSONDecodeError:pass
        a.check('actual printed custody exact original object',custody in printed)
        references={}
        lock=decode(sources['compatibility/pytorch-oracle-lock.json'])
        for reference in ('cpython','pytorch'):
            directory=out/'extracted'/(folder+'-'+reference)
            raw=members[folder+'-'+reference+'/report.json']
            a.equal('ZIP report equals tar raw '+reference,raw,(directory/'report.json').read_bytes())
            report_sha=custody['reports'][reference] if profile=='i64' else custody['cpython_report_sha' if reference=='cpython' else 'torch_report_sha']
            a.equal('actual report custody '+reference,sha(raw),report_sha)
            original=historical['check_report'](old_review,'new actual '+profile,profile,reference,raw,historical['expected'](profile),lock)
            c=reader['Checks']();summary=reader['verify'](directory,profile,reference,c)
            recreated={'schema':'heptatorch.integer-byte-evidence-offline-review.v1','status':'PASS',
                'native_or_Torch_executions_by_reader':0,'full_rewrite_complete':False,**summary,
                'checks':c.rows,'checks_passed':sum(x['passed'] for x in c.rows),
                'checks_failed':sum(not x['passed'] for x in c.rows),'reader_sha256':READER_SHA}
            ci_raw=members[folder+'-byte-review-'+reference+'.json']
            a.equal('entire executed CI byte-reader report exact offline reconstruction '+reference,decode(ci_raw),recreated)
            a.equal('original CI reader canonical bytes '+reference,ci_raw,(json.dumps(recreated,indent=2,sort_keys=True)+'\n').encode())
            (out/('offline-'+reference+'-reader.json')).write_bytes(ci_raw)
            a.equal('full raw file count '+reference,summary['complete_files'],pins['files'][reference])
            a.check('actual oracle summary printed '+reference,{k:v for k,v in original.items() if k not in ('rows','oracle_provenance','provenance')} in printed)
            a.check('actual CI reader summary printed '+reference,{k:v for k,v in recreated.items() if k not in ('checks','traceback')} in printed)
            references[reference]={'cases':pins['rows'],'values':pins['values'],'original_report_sha256':sha(raw),
                'full_byte_reader_report_sha256':sha(ci_raw),'file_count':summary['complete_files'],
                'check_count':recreated['checks_passed'],'all_numeric_and_provenance_checks_retained':True}
        a.equal('historical original rules all true',all(x['passed'] is True for x in old_review.checks),True)
        a.finish()
        report.update(status='PASS_NEW_ACTUAL_HOSTED_BYTE_EVIDENCE',admission_allowed=True,
            source_head=spec['source_head'],source_tree=spec['source_tree'],source_parents=spec['source_parents'],
            checkout=checkout['sha'],run_id=run['id'],job_id=job['id'],run_attempt=run['run_attempt'],
            actual_step_count=len(job['steps']),root_artifact_members=6,original_tar_file_count=len(inventory),
            artifact_id=metadata['id'],profile=profile,references=references,
            frozen_reader_sha256=READER_SHA,legacy_reader_sha256=HISTORICAL_SHA,
            legacy_only_profile_oracle_pin_updated=True,legacy_checks=old_review.checks,
            native_or_Torch_reexecuted=False,all_original_inputs_unchanged=True)
    except BaseException as error:
        report.update(error=repr(error),traceback=traceback.format_exc())
    report.update(checks=a.checks,checks_passed=sum(x['passed'] for x in a.checks),
                  checks_failed=sum(not x['passed'] for x in a.checks),inputs=a.inputs,
                  reviewer_sha256=sha(Path(__file__).read_bytes()))
    (out/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('checks','legacy_checks','inputs','traceback')},sort_keys=True))
    return 0 if report['admission_allowed'] else 1


if __name__=='__main__':raise SystemExit(main())
