#!/usr/bin/env python3
"""Offline new integer-combined-tree source/hosted-byte admission; no native or Torch execution.

The af33 reader is a pinned, unchanged dependency. Its old numerical, EOF,
Version, provenance, history and private-snapshot rules are reused directly.
Only the exact third profile and report-mirror cardinality are added to its
quick-artifact routines. The new retained evidence reader validates the actual
CI archive, not a local reuse receipt or a fixed historical member count.
"""
import argparse
import ast
import base64
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import traceback
import types

TREE='51b2bf3b1d15e8662253668c0f6ee458885dd3de'
BASE='e0ea769c979236b0542af4b258890726cd01a99a'
HEAD='2e66ad094ca62d059a1a7ca5642a8ce27c40a949'
SOURCE_PARENTS=['0fd81b279c97dd969071c9efc51c8202fc16e45b', 'e0ea769c979236b0542af4b258890726cd01a99a']
PULL_REQUEST=29
BASE_READER='123aa0b96823a5f78d14a1998ab5cb992ac7172b65304b11905bc0d457967f59'
SOURCE_MANIFEST='dea1c3f5fdb68e8d5dc94f70d9168e71cabf4c258039dcceb26b98e1ed19ddb6'
EVIDENCE_READER_SHA='6c9685bf7f8c4433ea0391890839efd95343e2b248a9890bda9a5ebf29e7c06e'
OBSERVER='281f1ea437046a9cd884de2c8da34f38649a3b6482ade23123ac4aa992faed64'
PEER='00bcb0dc32e9a6a7424dc5fa1d407106f39703e8e77dbc8410458773683b5ce0'
VALIDATOR='984b9b4c83849aaabddffb8e2ef2bd6c6d90193c3ce7700aa8c56eb8110069ea'
QUALIFIER='c71d40ea111b9c80e9d0987f7cd42729cc3f47ecf5a86b7e5d4ecf0659ec0ee2'
OLD_OBSERVER='e900466bff13bcaa5cd89a814dc411b4fc33320d84855ca6bd085179cd599c6a'
OLD_PEER='c4873900abd44f2c74c2632d662d932ee0912501b7a127771c2bfecccc0f2db6'
RETAINED={'name':'retained-gradients-446',
          'source':'666230f05cc6942470006d1f184135321d8cbc26a6c6ba0bf7e3cf9857fe515b',
          'image':'7568c0a4ec40d82d3a0b46d1e8a27499dd96e8fe3fd15433523131a196da89b5'}

def sha(raw): return hashlib.sha256(raw).hexdigest()
def gitsha(kind,raw): return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()

def ast_value(source,name):
    return next(ast.literal_eval(n.value) for n in ast.parse(source).body
                if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))

def replace_exact(raw,changes):
    result=raw
    for old,new in changes:
        assert result.count(old)==1,('unique adaptation',old)
        result=result.replace(old,new,1)
    inverse=result
    for old,new in reversed(changes):
        assert inverse.count(new)==1,('unique inverse',new)
        inverse=inverse.replace(new,old,1)
    assert inverse==raw,'base reader adaptation must be exactly reversible'
    return result

def load_reader(bundle):
    raw=(bundle/'review_hosted_af33.py').read_bytes()
    assert sha(raw)==BASE_READER
    base=types.ModuleType('immutable_af33_hosted_reader')
    base.__file__=str(bundle/'review_hosted_af33.py')
    exec(compile(raw,base.__file__,'exec'),base.__dict__)
    tree=ast.parse(raw)
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Audit')
    custody=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='custody')
    custody_source=ast.get_source_segment(raw.decode(),custody)
    custody_changes=[
        ('exactly five requested report mirrors','exact requested report mirrors'),
        ('len(mirrors)==m["requested_report_count"]==5 and set(mirrors)==set(expected_reports)',
         'len(mirrors)==m["requested_report_count"]==len(expected_reports) and set(mirrors)==set(expected_reports)'),
    ]
    adapted_custody=replace_exact(custody_source,custody_changes)
    exec(compile(adapted_custody,'<exact-third-profile-custody>','exec'),base.__dict__)
    base.Audit.custody=base.custody
    quick=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='review_quick')
    quick_source=ast.get_source_segment(raw.decode(),quick)
    quick_changes=[
        ('"exactly two independent quick profiles",{x["profile"] for x in entries}=={"355","428"} and len(entries)==2',
         '"exactly three independent quick profiles",{x["profile"] for x in entries}=={"355","428","446"} and len(entries)==3'),
        ("'428':'458fab50d7eb4c9685fd400053dd6746225ccae348e75c758d1e0cbd6d8fb6fe'}",
         "'428':'458fab50d7eb4c9685fd400053dd6746225ccae348e75c758d1e0cbd6d8fb6fe',\n                     '446':'0cc512e60904cf32812efdb1aba166f01ff190cea6966a75a1c50e888325aec5'}"),
        ("{'355':30,'428':33}[profile]","{'355':30,'428':33,'446':33}[profile]"),
    ]
    adapted_quick=replace_exact(quick_source,quick_changes)
    exec(compile(adapted_quick,'<exact-third-profile-quick>','exec'),base.__dict__)
    base.PROFILES['446']=dict(RETAINED)
    base.OBSERVER=OBSERVER;base.PEER=PEER;base.TREE=TREE;base.BASE=BASE
    evidence={
        'base_reader_sha256':sha(raw),
        'base_reader_file_unchanged':True,
        'custody':{'original_source_sha256':sha(custody_source.encode()),
                   'adapted_source_sha256':sha(adapted_custody.encode()),'changes':custody_changes,'exact_inverse':True},
        'quick':{'original_source_sha256':sha(quick_source.encode()),
                 'adapted_source_sha256':sha(adapted_quick.encode()),'changes':quick_changes,'exact_inverse':True},
        'unchanged_definitions':{},
    }
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name not in ('main','review_quick','Audit'):
            evidence['unchanged_definitions'][node.name]=sha(ast.get_source_segment(raw.decode(),node).encode())
    for node in cls.body:
        if isinstance(node,ast.FunctionDef) and node.name!='custody':
            evidence['unchanged_definitions']['Audit.'+node.name]=sha(ast.get_source_segment(raw.decode(),node).encode())
    return base,evidence

@contextmanager
def historical_constants(base):
    current=base.OBSERVER,base.PEER
    base.OBSERVER,base.PEER=OLD_OBSERVER,OLD_PEER
    try: yield
    finally: base.OBSERVER,base.PEER=current

def tree_entries(raw):
    entries={};pos=0
    while pos<len(raw):
        end=raw.index(b'\0',pos)
        mode,name=raw[pos:end].split(b' ',1)
        oid=raw[end+1:end+21]
        assert len(oid)==20 and name not in entries
        entries[name.decode()]=(mode.decode(),oid.hex())
        pos=end+21
    assert pos==len(raw)
    return entries

def source_tree(audit,bundle):
    manifest_raw=audit.read(bundle/'source-manifest.json')
    audit.check('prepared source manifest exact independent pin',SOURCE_MANIFEST is not None and sha(manifest_raw)==SOURCE_MANIFEST)
    m=json.loads(manifest_raw)
    audit.check('prepared source identity is not a hosted result',m['status']=='PREPARED_NOT_RUN'
                and m['official_source_head'] is None and m['expected_tree']==TREE and m['expected_parent']==BASE
                and m['native_executed'] is m['Torch_executed'] is False)
    witness={}
    for oid,encoded in m['git_tree_witnesses'].items():
        raw=base64.b64decode(encoded,validate=True)
        audit.check('Git tree object identity '+oid,gitsha('tree',raw)==oid)
        witness[oid]=tree_entries(raw)
    tracked=m['all_tracked_file_digests']
    audit.check('complete predeclared source tree digest table',len(tracked)==m['full_git_tree_blob_count']==3861)
    for name,row in tracked.items():
        audit.check('source digest entry '+name,row['mode'] in ('100644','100755') and audit_module.plain_sha(row['sha256'])
                    and isinstance(row['bytes'],int) and row['bytes']>=0)
        parts=PurePosixPath(audit_module.member_name(name)).parts;oid=TREE
        for part in parts[:-1]:
            mode,oid=witness[oid][part]
            assert mode=='40000'
        mode,blob=witness[oid][parts[-1]]
        audit.check('source blob belongs to exact target tree '+name,mode==row['mode'] and blob==row['git_blob'])
    sources={}
    for row in m['files']:
        raw=audit.read(bundle/'source'/row['path'])
        audit.check('source snapshot exact bytes and Git blob '+row['path'],row==dict(path=row['path'],**tracked[row['path']])
                    and sha(raw)==row['sha256'] and len(raw)==row['bytes'] and gitsha('blob',raw)==row['git_blob'])
        sources[row['path']]=raw
    audit.check('all selected source files present',len(sources)==m['selected_file_count']==98)
    return sources,tracked

def inverse_observer(audit,sources):
    proof=json.loads(sources['validation/retained-observer-profile/inverse-proof.json'])
    audit.check('observer profile extension declares unchanged rules',proof['all_18_negative_mutations_and_assertions_unchanged'] is True
                and proof['T_record_flags_remain_exact_zero'] is True)
    changed=set()
    for name,row in proof['files'].items():
        raw=sources['tests/private_node_accounting/'+name]
        audit.check('current observer package source '+name,sha(raw)==row['after_sha256'] and len(raw)==row['after_bytes'])
        restored=raw.decode()
        for x in reversed(row['replacements']):
            audit.check('unique observer inverse '+name,restored.count(x['after'])==1)
            restored=restored.replace(x['after'],x['before'],1)
        audit.check('observer inverse exact old pin '+name,sha(restored.encode())==row['before_sha256'] and len(restored.encode())==row['before_bytes'])
        if row['changed']:
            changed.add(name)
            audit.check('observer inverse exact original file '+name,
                        restored.encode()==sources['validation/retained-observer-profile/baseline-af33/'+name])
    audit.check('exactly four profile-only file changes',changed=={'owner_accounting.py','check_owner_snapshots.py','check_frozen35_accounted.py','restore_native_inputs.py'})
    audit.check('fixed current source pins',sha(sources['tests/private_node_accounting/owner_accounting.py'])==OBSERVER
                and sha(sources['tests/private_node_accounting/check_owner_snapshots.py'])==PEER
                and sha(sources['tests/private_node_accounting/check_frozen35_accounted.py'])==VALIDATOR
                and sha(sources['tests/qualify_retained_gradients.py'])==QUALIFIER)

def original_boundaries(audit,sources):
    acceptance=json.loads(sources['compatibility/full-acceptance.json'])
    capabilities=json.loads(sources['compatibility/capabilities.json'])
    audit.check('all17 whole-project gates remain unresolved',acceptance['status']=='HOLD'
                and len(acceptance['gates'])==17
                and all(g['status'] in ('OPEN','IN_PROGRESS') for g in acceptance['gates'])
                and acceptance['native_schema_count']==2590 and acceptance['whole_pytorch_rewrite_complete'] is False)
    audit.check('zero fully equivalent upstream schemas',capabilities['full_upstream_schema_parity_count']==0
                and capabilities['native_schema_inventory_count']==2590 and capabilities['whole_pytorch_rewrite_complete'] is False)

def official_target(audit,spec):
    head=spec['source_head']
    audit.check('official new integer-combined source head supplied before admission',head==HEAD and spec['pull_request']==PULL_REQUEST)
    commit=audit.json(spec['source_commit'])
    payload=commit.get('commit',commit)
    audit.check('published source commit has exact prepared tree and base',commit['sha']==head
                and payload['tree']['sha']==TREE and [p['sha'] for p in commit['parents']]==SOURCE_PARENTS)
    return head

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bundle',type=Path,required=True)
    p.add_argument('--inputs',type=Path)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--prepare-only',action='store_true')
    p.add_argument('--quick-only',action='store_true')
    args=p.parse_args()
    bundle=args.bundle.resolve();out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=False)
    raw=Path(__file__).read_bytes();(out/'executed-reviewer.py').write_bytes(raw)
    global audit_module
    base,reuse=load_reader(bundle);audit_module=base
    root=args.inputs.resolve().parent if args.inputs else bundle
    audit=base.Audit(root,out)
    result={'schema':'heptatorch.integer-combined-tree.independent-hosted-admission.v1','status':'NOT_RUN','admission_allowed':False,
            'pull_request':PULL_REQUEST,'declared_source_head':HEAD,
            'expected_tree':TREE,'expected_base':BASE,'source_head':None,'reviewer_sha256':sha(raw),
            'native_executed_by_reviewer':False,'Torch_executed_by_reviewer':False,
            'original_report_bytes_rewritten':False,'whole_project_decision':'HOLD',
            'full_schema_parity':0,'pytorch_api_denominator':2590,'whole_pytorch_rewrite_complete':False,
            'af33_logic_reuse':reuse}
    code=1
    try:
        evidence_path=Path(__file__).with_name('retained_evidence.py')
        evidence_raw=audit.read(evidence_path)
        audit.check('exact independent retained evidence reader',sha(evidence_raw)==EVIDENCE_READER_SHA)
        evidence=types.ModuleType('source_bound_retained_evidence_reader')
        evidence.__file__=str(evidence_path)
        exec(compile(evidence_raw,evidence.__file__,'exec'),evidence.__dict__)
        sources,tracked=source_tree(audit,bundle)
        inverse_observer(audit,sources)
        original_boundaries(audit,sources)
        audit.original_pins=ast_value(sources['tests/private_node_accounting/owner_accounting.py'],'SOURCE_PINS')
        old_raw=audit.read(bundle/'old50-obligations.json')
        audit.check('old50 immutable obligations',sha(old_raw)==base.OLD50_SHA)
        old=base.decode(old_raw)['reports']
        plan32=old['pytorch-adam-distributions-backward.json']['case_plan']
        plan35=old['pytorch-adam-distributions-frozen35.json']['case_plan']
        workflow=sources['.github/workflows/native.yml'];quick=sources['.github/workflows/observer-accounting.yml']
        required=sorted({n.decode() for n in re.findall(rb'tools/emit_ci_report\.py build/([A-Za-z0-9_.-]+\.json)',workflow)})
        named=re.findall(rb'^      - name: (.+)$',workflow,re.M)
        qnamed=re.findall(rb'^      - name: (.+)$',quick,re.M)
        audit.check('prepared exact workflow obligations',len(named)==75 and len(qnamed)==10 and len(required)==33)
        if args.prepare_only:
            audit.check('prepare does not admit an official run',args.inputs is None and not args.quick_only)
            audit.finish()
            result.update(status='PREPARED_NOT_RUN',declared_native_steps=len(named),declared_quick_steps=len(qnamed),
                          declared_envelope_reports=required,official_source_head_bound=False,
                          expected_main_root_reports=63,expected_quick_profiles=['355','428','446'],
                          expected_actual_counts_are_unexecuted=True)
            return base.save_result(audit,result,0)
        audit.check('actual input specification required',args.inputs is not None)
        spec=audit.json(args.inputs.resolve())
        audit.check('integer-combined input schema',spec['schema']=='heptatorch.integer-combined-tree.hosted-admission-inputs.v1')
        base.HEAD=official_target(audit,spec);result['source_head']=base.HEAD
        if args.quick_only:
            summary=base.review_quick(audit,spec['quick'],quick,plan32,plan35,sources)
            audit.finish()
            result.update(status='PASS_QUICK_COMPONENTS_MAIN_PENDING',quick_profiles=summary,main_native_reviewed=False)
            return base.save_result(audit,result,0)
        ctx=base.Audit.job(audit,spec['native'],workflow)
        members,metadata=audit.archive(spec['native']['reports'])
        manifest=base.decode(members['ci-report-manifest.json'])
        audit.check('main original export complete',manifest['status']=='COMPLETE'
                    and manifest['job_status_before_export']=='success' and manifest['original_report_bytes_reserialized'] is False)
        audit.identity(manifest,ctx)
        audit.check('official main artifact belongs to this run',metadata['workflow_run']['id']==ctx['run']['id'])
        audit.check('source workflow and collector actually bound',manifest['workflow_sha256']==sha(workflow)
                    and manifest['collector_sha256']==sha(sources['tools/collect_ci_reports.py']))
        audit.check('all33 source-declared envelope obligations',manifest['required_envelope_reports']==required
                    and not manifest['missing_envelope_reports'])
        listed={r['path']:r for r in manifest['reports']}
        names=set(old)
        for prefix in ('gradient-objects','gradient-adam-distributions'):
            names.add('hosted-'+prefix+'-native.json')
            names.update('pytorch-'+prefix+x for x in ('-backward.json','-frozen35.json','-frozen35-original.json'))
        audit.check('old58 obligation set cardinality',len(names)==58)
        names.update({'hosted-retained-gradients-native.json','retained-gradients-ci-raw-manifest.json',
                      'pytorch-retained-gradients-backward.json','pytorch-retained-gradients-frozen35.json',
                      'pytorch-retained-gradients-frozen35-original.json'})
        audit.check('63 exact original root reports; no missing or extra JSON',len(listed)==len(manifest['reports'])==63
                    and set(listed)==names and set(members)==names|{'ci-report-manifest.json'})
        reports={}
        for name,row in listed.items():
            original=members[name]
            audit.check('original report byte custody '+name,len(original)==row['bytes'] and sha(original)==row['sha256'])
            reports[name]=base.decode(original)
        for name,expected in old.items():
            d=reports[name]
            audit.check('old50 schema and status '+name,d.get('schema')==expected['schema'] and d.get('status')==expected['status'])
            for field,value in expected['fields'].items(): audit.check('old50 preserved field '+name+'/'+field,d[field]==value)
            if 'case_plan' in expected: audit.check('old50 original plan '+name,d['case_plan']==expected['case_plan'])
            if 'row_count' in expected:
                audit.check('old50 complete row status ledger '+name,len(d['rows'])==expected['row_count']
                            and [r.get('status') if isinstance(r,dict) else None for r in d['rows']]==expected['row_statuses'])
            if 'oracle_provenance' in d: audit.provenance(d['oracle_provenance'],name)
        current_rows={}
        prefixes={'355':'pytorch-gradient-objects','428':'pytorch-gradient-adam-distributions','446':'pytorch-retained-gradients'}
        for profile,prefix in prefixes.items():
            model=base.PROFILES[profile]
            live=audit.live32(members[prefix+'-backward.json'],model,'main '+profile+' live32',plan32)
            inner=prefix+'-frozen35-original.json'
            d,w=audit.frozen35(members[prefix+'-frozen35.json'],members[inner],model,inner,'main '+profile+' frozen35',plan35)
            audit.pip_binding(members['pytorch-install.json'],[live['oracle_provenance'],d['oracle_provenance']],'main '+profile)
            current_rows[profile]=d['rows']
        base.native_components(audit,reports,sources)
        retained=evidence.review_retained_evidence(audit,base,spec['native']['retained_evidence'],ctx,members,reports,sources,tracked)
        journals,jmetadata=audit.archive(spec['native']['journals'])
        mirrored={'pytorch-install.json':members['pytorch-install.json']}
        for prefix in prefixes.values():
            for suffix in ('-frozen35.json','-frozen35-original.json'):
                name=prefix+suffix;mirrored[name]=members[name]
        audit.custody(journals,jmetadata,ctx,mirrored,'main journals')
        for profile,rows in current_rows.items(): audit.journals(journals,rows,'main '+profile)
        quick_summary=base.review_quick(audit,spec['quick'],quick,plan32,plan35,sources)
        for unit in reports['hosted-gradient-objects-native.json']['build']['units']:
            for suffix,kind in (('.hepta','source'),('.o','object')):
                restored=audit.restored_members['355'][unit['name']+suffix]
                audit.check('355 cold/restored exact extra byte field '+unit['name']+suffix,
                            unit[kind+'_bytes']==restored['bytes'] and unit[kind+'_sha256']==restored['sha256'])
        for unit in json.loads(sources['tools/retained_gradients/profile.json'])['units']:
            for suffix,kind in (('.hepta','source'),('.o','object')):
                restored=audit.restored_members['446'][unit['name']+suffix]
                audit.check('446 quick restoration matches fresh CI unit '+unit['name']+suffix,
                            restored['sha256']==unit[kind+'_sha256']==retained['unit_members'][unit['name']+suffix]['sha256'])
        with historical_constants(base): base.history_review(audit,spec['history'])
        audit.finish()
        result.update(status='PASS_SCOPED_HOSTED_ADMISSION',admission_allowed=True,
                      native_run=ctx['run']['id'],native_attempt=ctx['run']['run_attempt'],native_job=ctx['job']['id'],
                      old_reports_preserved=58,main_original_reports=len(listed),required_envelopes=len(required),
                      main_profiles={k:{'live32':32,'frozen35':35} for k in prefixes},quick_profiles=quick_summary,
                      retained_evidence=retained,all_original_files_unchanged=True)
        code=0
    except Exception as error:
        result.update(status='FAIL_ADMISSION_REVIEW',error=repr(error),traceback=traceback.format_exc())
    return base.save_result(audit,result,code)

if __name__=='__main__': raise SystemExit(main())
