# Independent admission of the new int64 combined tree

The exact source is `2e66ad094ca62d059a1a7ca5642a8ce27c40a949`, tree `51b2bf3b1d15e8662253668c0f6ee458885dd3de`. Its parents, in order, are the original int64 branch `0fd81b279c97dd969071c9efc51c8202fc16e45b` and admitted main `e0ea769c979236b0542af4b258890726cd01a99a`. The PR checkout is `1a28a87524e7dd6ffe94ab0ba032d42c4cfb2031`, with exact parents main then the new head and the same tree.

## Actually completed

The 28 prepared files passed 233 independent source and original-byte checks. The complete old tree has 3,833 unchanged file blob identities and modes; the new tree adds exactly 28 files. All 98 selected Native/quick source files are unchanged.

The new dedicated PR run `43886148312`, job `133364701595`, and push run `43886136338`, job `133364660907`, each completed their 13 actual steps. Each original six-member artifact includes a mode-preserving tar with 507 members, including exactly 433 ordinary files: 207 CPython and 226 PyTorch. Both references completed the original 33 cases and 351,174 exact values. Original compiler and two ELF generations, every request and actual response, framework expected bytes, source snapshots and full wheel provenance were independently checked. Empty cases explicitly do not claim a framework arithmetic call.

The final local wrapper passed 3,846 checks for PR and 3,847 for push, in addition to 638 original historical source/numeric/provenance assertions per run and the frozen byte reader's 2,057 CPython and 2,262 PyTorch checks. These are nested evidence counts, not additional API cases. The reviewer executed no compiler, native runtime or Torch.

The new quick run `43886148242` completed three independent 355/428/446 jobs with 13 steps each. The source-bound reader passed 52,151 checks of their original reports, 32/35 results, EOF, Version, all 11 provenance checks, three native controls, four positive and 18 exact negative copied-snapshot controls, and complete journal custody. Its status is explicitly `PASS_QUICK_COMPONENTS_MAIN_PENDING`.

The main Native run remains pending in this checkpoint. Historical PR31 results are not reused as observations for the new tree. Final merge admission requires a separate read of this run's original Native reports, journals and fresh retained-gradient evidence.

## Preserved reader correction

`int64-pr-byte-admission-01/report.json` preserves the first local reviewer refusal. It incorrectly required the entire frozen reader's check list to have identical array order on both machines. The frozen reader iterates a set of source roles and `Path.rglob`, whose order can differ. No value, source hash or assertion result differed.

The separate `review_integer_new_bytes_v2.py` requires exact complete noncheck fields, exact check count, every row's schema and True result, the complete check multiset including multiplicities, and unchanged order for all deterministic checks. It also verifies original CI JSON bytes without rewriting their row order. `reader-history-01/source-correction.json` contains an exact source inverse; the frozen byte reader, numerical corpus, expected values, assertions and source provenance rules are unchanged. The first refusal is not relabelled as PASS.

## Replay entry points

Use `review_integer_new_bytes_v2.py --inputs int64-pr-inputs-01.json --historical-reader <frozen review_integer_artifacts.py> --output <new-directory>` and the corresponding push inputs. Input paths are explicit and may be relocated by editing a new input manifest; original reports are never rewritten.

For quick and final Native admission, use `native-reader-2e66/review_integer_tree_native.py --bundle native-source-2e66 --inputs <new exact input manifest> --output <new-directory>`, adding `--quick-only` only for the quick component. `native-reader-inverse-2e66.json` proves exact inverse to the original PR31 reader; only source/head/tree/parent/inventory and descriptive schema bindings differ. The retained evidence reader and all numerical, provenance, EOF, Version, native construction and scope rules remain identical.

All original ZIPs and raw official metadata remain in `official-2e66/` and `quick-2e66/`. Duplicate expanded integer files were reclaimed only after complete tar member byte and mode comparison plus full XZ EOF verification. Each output retains its original tar and a complete `duplicate-expansion-reclaim.json`; original reports and first-failure bytes are unchanged.

Full PyTorch equivalence remains HOLD: zero complete schemas out of the 2,590 inventory and all 17 project gates retain their original state. These packed integer kernels remain distinct from a general Tensor dtype integration.
