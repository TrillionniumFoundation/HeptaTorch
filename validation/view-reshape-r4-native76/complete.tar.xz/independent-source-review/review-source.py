#!/usr/bin/env python3
"""Pure source custody/review; never imports an emitter or runs native/Torch."""
import ast, hashlib, json, re, stat, traceback
from pathlib import Path
R=Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
OUT=R/'hia-wrapped-scalar07b-source-review-01'
PINS={
 'parent_runtime':(R/'differentiable-view-r4-scalar06-native-build-01/candidate-r4-scalar06/runtime.hepta','743c6de8c4f2e9ea6dbb880aca5a27c719c2b14ce05e7262020ece63b1ccd148'),
 'prepared_runtime':(R/'differentiable-view-r4-scalar-prepare-07b/runtime.hepta','c436e21c45355891f8423f174a47e7c40fc8e1d6aef9a112043fac8787255d7a'),
 'prepared_build':(R/'differentiable-view-r4-scalar-prepare-07b/build.json','da92a5e395e212829da5263425b762e6d5872934b27570f31162a5f455222a46'),
 'author_runtime':(R/'differentiable-view-r4-scalar-source-07b/scalar_runtime.py','0b9d5e40bdf79d103b4fb4adbb7aa21de63e52c15fc4aff9e3b97bb9a54a44cc'),
 'author_overlay':(R/'differentiable-view-r4-scalar-source-07b/scalar_overlay.py','58afd420dae7b389bcb9b8238b683d5d9a9ea9fa1a8d044a13f1da8c5d77ebe4'),
 'author_math':(R/'differentiable-view-r4-scalar-source-07b/scalar_math.py','b410bef7152009f98d58559598e223dfe0d0f84cbd0fc91a66e9f5a0354707f0'),
 'producer_diff':(R/'differentiable-view-r4-scalar-source-07b/prepared-source-diff.json','d4124bb1233ffe92866861bf18fbcc84fcc50146641b662aab1b984854897d02'),
 'producer_manifest':(R/'differentiable-view-r4-scalar-source-handoff-07b/source-manifest.json','0ea8b5d66f99ec5290163c2534f94a08f2a58c2421bff425bcf612b952120fd2'),
 'compile_intent':(R/'differentiable-view-r4-scalar-source-handoff-07b/compile-intent.json','7a55e0267d93a1262fe297f1731f13ab91861db0dc97d8db75436eae570d6560'),
 'TensorIterator_cpp':(R/'r4-scalar07-TensorIterator-a71a7e.cpp','a71a7ec9ba0532bf1380aa8ebc92975e4acb31414cd4b8eeeba650afe9e4490c'),
}
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(p):
 b=p.read_bytes()
 return {'path':str(p),'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(p.stat().st_mode)}
def dump(p,x):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(x,f,indent=2,ensure_ascii=True);f.write('\n')
 p.chmod(0o600)
def copy_bytes(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
 p.chmod(0o600)
def functions(data):
 out={}
 for m in re.finditer(rb'(?ms)^fn ([A-Za-z0-9_]+)\(.*?^end\n',data):
  n=m.group(1).decode();assert n not in out,n;out[n]=m.group(0)
 assert len(out)==len(re.findall(rb'(?m)^fn ',data))
 return out
OUT.mkdir(exist_ok=False)
report={'schema':'heptatorch.wrapped-scalar07b.independent-source-review.v1',
 'status':'RUNNING','native_executed':False,'Torch_executed':False,'compiler_executed':False,
 'emitter_executed':False,'reference_admission_executed':False,
 'scope':'Independent source read plus pure byte/AST/body custody, not runtime qualification',
 'full_pytorch_status':'HOLD','qualified_pytorch_api_count':0}
try:
 before={};data={}
 for n,(p,h) in PINS.items():
  before[n]=meta(p);assert before[n]['sha256']==h,(n,before[n]);data[n]=p.read_bytes()
 for n in ('author_runtime','author_overlay','author_math'):ast.parse(data[n],filename=str(PINS[n][0]))
 a,b=functions(data['parent_runtime']),functions(data['prepared_runtime'])
 assert len(a)==656 and len(b)==658
 changed=sorted(n for n in a if a[n]!=b[n])
 added=sorted(set(b)-set(a))
 assert changed==['incoming_describe','incoming_mark_preserve_targets','retained_apply'],changed
 assert added==['scalar_previous_incoming_describe','scalar_previous_incoming_mark_preserve_targets'],added
 assert len([n for n in a if a[n]==b[n]])==653
 aliases=[]
 for old in ('incoming_describe','incoming_mark_preserve_targets'):
  new='scalar_previous_'+old
  oldhead=('fn '+old+'(').encode();newhead=('fn '+new+'(').encode()
  assert a[old].count(oldhead)==1 and b[new].count(newhead)==1
  assert b[new].replace(newhead,oldhead,1)==a[old],new
  aliases.append({'original':old,'alias':new,'before_sha256':sha(a[old]),'after_sha256':sha(b[new]),'whole_byte_inverse':True})
 oldcall=b'  v220:u64 = call(v219,v209) {"function":"addf"}\n'
 newcall=b'  v220:u64 = call(v219,v209) {"function":"scalar_add_preserving_bits"}\n'
 assert a['retained_apply'].count(oldcall)==1 and b['retained_apply'].count(newcall)==1
 assert b['retained_apply'].replace(newcall,oldcall,1)==a['retained_apply']
 assert sha(b['scalar_add_preserving_bits'])=='b9d272f526920879e66970641f60cfcc0fc1d71aaf3c285e2781a5a909c6a436'
 expected={
 'incoming_describe':'511d5ce76be9a318f2eceffb40a34b6ed3d8ea37ea52793b8fbe3e51ffedb585',
 'incoming_mark_preserve_targets':'8c4c0237279b24a1ce676535fe8f81884b7951d15dc1df7760731f904ae55fa7',
 'retained_apply':'460d1f302956925333993c60c2a118f9c1071e827fdec6c3f4205c24ee111c13'}
 for n,h in expected.items():assert sha(b[n])==h,n
 helper_names=['scalar_add_preserving_bits','retained_axis_order','retained_compare_axes','incoming_drop_cache',
 'incoming_reserve_preserve_storage','dview_preserve_capacity','dview_trim_preserve','incoming_adopt_gradient',
 'retained_reserve_one','retained_release_one','ensure_backward_work','scalar_peek_resolved','scalar_peek_public',
 'typed_command','to_command','transpose','binary_saved_bind','binary_saved_release','binary_saved_get',
 'gradient_accumulate','history_retained_target','history_retained_enabled','wrapped_scalar_mul','back_binary',
 'wrapped_scalar_back_binary','dtype_width','dtype_audit','so_audit_records']
 for n in helper_names:assert n in a and a[n]==b[n],n
 raw=data['author_runtime'].decode()
 assert 'if getw(w,p+8)==0:\n        return 1' not in raw[raw.index('def incoming_describe('):raw.index('def incoming_mark_preserve_targets(')]
 assert 'if inverted!=0:\n        return 1' in raw
 assert 'stride=stride*getw(w,p+96+8*axis)' in raw
 ti=data['TensorIterator_cpp'].decode()
 for needle in ('if (has_scalars && has_tensors)', 'if (is_reduction_ || !all_ops_same_shape_)',
  'next_stride *= shape_[dim];','if (perm_[j] != ndim() - j - 1)',
  'if (stride0 == 0 || stride1 == 0)'):
  assert needle in ti,needle
 details=[]
 for n in sorted(set(changed+added+helper_names)):
  copy_bytes(OUT/'source-functions'/(n+'.hepta'),b[n])
  if n in changed:copy_bytes(OUT/'parent-functions'/(n+'.hepta'),a[n])
  details.append({'name':n,'bytes':len(b[n]),'sha256':sha(b[n]),'parent_sha256':sha(a[n]) if n in a else None,
   'unchanged':n in a and a[n]==b[n]})
 for n in ('author_runtime','author_overlay','author_math','producer_diff','producer_manifest','compile_intent','prepared_build','TensorIterator_cpp'):
  copy_bytes(OUT/'inputs'/(n+PINS[n][0].suffix),data[n])
 dump(OUT/'whole-body-comparison.json',{'source06':before['parent_runtime'],'prepared07b':before['prepared_runtime'],
  'unchanged':653,'changed':changed,'added':added,'all_functions':[
  {'name':n,'sha256':sha(b[n]),'before_sha256':sha(a[n]) if n in a else None} for n in sorted(b)],'aliases':aliases,
  'retained_apply_single_call_inverse':{'old':oldcall.decode(),'new':newcall.decode(),'whole_byte_inverse':True}})
 report.update({
  'status':'PASS_SOURCE_REVIEW_ONLY','confirmed_source_blockers':[],
  'input_count':len(before),'source06_functions':656,'source07b_functions':658,'unchanged_functions':653,
  'changed_functions':changed,'added_aliases':aliases,'retained_apply_single_call_inverse':True,
  'source_sha256':before['prepared_runtime']['sha256'],'prepared_only_no_image_claim':True,
  'findings':[
   {'topic':'CPU TensorIterator layout','finding':'Tensor scalar plus non-scalar defeats same-shape fast setup. Rank-zero scalar strides broadcast to zero; the existing stable axis comparator is reused. Only an inverted axis permutation returns the previously written contiguous layout. Otherwise compatible strides multiply actual dimensions including zero, matching the fixed TensorIterator source branches. This is a source correspondence, not a new numerical test.'},
   {'topic':'Incoming describe scope','finding':'The original incoming description runs first. New layout applies only to side zero of op3 with an actual right dtype3 node and an exact same-shape parent; mismatched shape returns error9. No conversion, generic binary, or original other-side path is changed.'},
   {'topic':'Preserve marker','finding':'Original marking runs first. Additional marking is limited to live, current-epoch, nonempty op3 nodes with right dtype3, and the real enabled parent returned by gradient_parent_at. Parent live/epoch is checked before writing544=1.'},
   {'topic':'Actual cache ownership','finding':'The unchanged reserve allocates real private Hold-backed Storage and private Version;552/560/568 track them. The unchanged trim/adopt/cleanup chain is reused. incoming_drop_cache releases552 Hold and568 Version and clears544/552/560/568; no committed-state scratch exemption is added.'},
   {'topic':'Retained accumulation','finding':'Only the existing scalar_add_preserving_bits helper call replaces one addf call. The helper preserves and quiets right NaN before left NaN, returns negative canonical NaN for opposite infinities, otherwise calls unchanged addf. Retained reservation, replacement Tensor/Storage assignment, Version and release operations are byte-identical.'},
   {'topic':'06 guard fix preservation','finding':'Full-body equality preserves typed/to public-token peeks, transpose node handling, command guards and all original dtype3 Saved/public observation contracts. Original05/06 runtime failures are not reclassified.'},
  ],
  'qualification_limits':[
   'No native, compiler, emitter, Torch, reference admission, or copied-state test was executed by this review.',
   'Source06 resource3 PASS remains bound to source743c/imagef050. It is not transferred to source07b.',
   'The previous forward114 allocation OOM case does not cover the newly reachable backward preserve-cache allocation. Any such OOM claim requires separate source-bounded prerequisites and execution.',
   'Full26/32 and finite resource results on a compiled07b image remain separate actual obligations.',
   'No general float64 Tensor arithmetic or full PyTorch compatibility claim.'],
  'function_evidence':details,
 })
 after={n:meta(p) for n,(p,h) in PINS.items()}
 assert before==after,'review inputs changed'
 report['inputs_before']=before;report['inputs_after']=after;report['all_inputs_unchanged']=True
 copy_bytes(OUT/'review-source.py',Path(__file__).read_bytes())
 dump(OUT/'report.json',report)
 entries={}
 for p in sorted(OUT.rglob('*')):
  if p.is_file():entries[p.relative_to(OUT).as_posix()]={k:v for k,v in meta(p).items() if k!='path'}
 dump(OUT/'manifest.json',{'schema':'heptatorch.source-review.manifest.v1','files':entries,
  'self_exclusion':'manifest.json','native_executed':False,'Torch_executed':False})
 print(json.dumps({'status':report['status'],'report':meta(OUT/'report.json'),'manifest':meta(OUT/'manifest.json'),'payload_count':len(entries)}))
except Exception as exc:
 report.update(status='FAIL_SOURCE_REVIEW',error=repr(exc),traceback=traceback.format_exc())
 dump(OUT/'failure.json',report)
 raise
