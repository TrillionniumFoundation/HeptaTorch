"""Create four exact native execution intents; does not start a native process."""
import argparse, ast, hashlib, json
from pathlib import Path

R = Path("/home/qian-qi/heptatorch-continuation-20261116")
N = R / "runs/differentiable-view-r4-scalar07b-native-build-01/candidate-r4-scalar07b"
B = R / "runs/to-view-recovery-integration-01/repo/tests/differentiable_view_native_review"
I = R / "runs/to-view-recovery-integration-01/repo/tests/differentiable_view_input4_review"
E = R / "runs/root-r4-identity-epoch-source-01"
SOURCE = "c436e21c45355891f8423f174a47e7c40fc8e1d6aef9a112043fac8787255d7a"
OBS = "59019b5c4aeae0d7e04b362354bd9ca55917d2196791d3d18c4908a05fdbba8b"
sha = lambda b: hashlib.sha256(b).hexdigest()

def check(path, pin):
    raw = path.read_bytes()
    assert sha(raw) == pin, (str(path), sha(raw), pin)
    if path.suffix == ".py":
        ast.parse(raw)
    return raw

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--expected-native-sha256", required=True)
    ap.add_argument("--expected-build-sha256", required=True)
    a = ap.parse_args()
    common = {
        N / "runtime.hepta": SOURCE,
        N / "tensor-shape-scalar-session": a.expected_native_sha256,
        N / "build.json": a.expected_build_sha256,
        B / "replay_direct_view14.py": "52c3b3242a73fb412102c83c5ba47cf8d95a4eb3c01e56f41bfe593066506d05",
        B / "protocol.py": "7a30d7bca140e3a4cc9d63a3e6930b92d2ffd60ad4503895419d8a63e67c8bd9",
        B / "owner_client.py": "dee3e4cb25ee1e5e06513e2f33478fbe274d9510ce2aaab9525815c72312946b",
        R / "runs/native_observer_shape02.py": OBS,
        R / "runs/r4-native-replay-custody-runner-01.py": "0293f647b3d960db0c5ded6f5bd2472122fbcb35d4df088ff0dca46ce0a1281e",
    }
    for p, pin in common.items():
        check(p, pin)
    build = json.loads((N / "build.json").read_bytes())
    assert build["status"] == "PASS"
    assert build["functions"] == 658 and build["blocks"] == 8661 and build["instructions"] == 30980
    assert len(build["units"]) == 13 and build["descriptor_bytes"] == 672
    assert build["source_sha256"] == SOURCE and build["native_sha256"] == a.expected_native_sha256
    assert len({u["name"] for u in build["units"]}) == 13
    for u in build["units"]:
        for suffix, key in ((".hepta", "source_sha256"), (".o", "object_sha256")):
            p = N / (u["name"] + suffix)
            common[p] = u[key]
            check(p, u[key])
    common[Path(__file__).resolve()] = sha(Path(__file__).read_bytes())
    artifact14 = R / "runs/pr35-hosted-artifacts-01/native-artifact-extraction-01/14289318347/differentiable-view-native14/inputs"
    artifact4 = R / "runs/pr35-hosted-artifacts-01/native-artifact-extraction-01/14290366118/differentiable-view-native-input4/inputs"
    suites = [
        dict(label="26-first", count=26,
             reader=E / "replay_shape26_epoch_r1.py",
             reader_pin="b37c58e597e3c180736133ee4ac7826b76dd9b0ac41d7b902b3057eabc7297a6",
             reference=R / "runs/differentiable-view-r4-shape-reference26-01/actual.json",
             reference_pin="fecf1956790f78a9b1238f535c1c7cce9f1237b211c389ac0736d88687bbb9c9",
             probe=R / "runs/differentiable-view-r4-shape-reference26-01/pytorch_view_reshape_probe.py",
             probe_pin="4dd374419e4b21a9c814c855d846481730a12ea57a30dcf229a6b962f07021c5",
             support=True, refarg=True, epoch=True),
        dict(label="32-first", count=32,
             reader=R / "runs/replay_wrapped_scalar32_r1.py",
             reader_pin="7386703b3deb01d6ab809447a1e6ae83d3c87ab1b4264d9e54641dbf99b93ad0",
             reference=R / "runs/wrapped-f64-reference32-01/actual.json",
             reference_pin="f3ecc9dd7db2ce8fbd0e424557ad5b95ac2e899a1c09cf38dad47e4fecc2b0c6",
             probe=R / "runs/wrapped-f64-reference32-01/pytorch_wrapped_f64_probe.py",
             probe_pin="c0ddafbae6ea81bd98f6066bc867f71e0b6e8d4f73e6c5d7f15f7fe3d29569a3",
             support=True, refarg=False, epoch=False),
        dict(label="14-regression", count=14,
             reader=I / "replay_direct_view14_profile.py",
             reader_pin="deb9f6fafc3f91b2749bdfac030e19cb0ccdb832fa238af91ed9feb396e62eb8",
             reference=artifact14 / "007-actual.json",
             reference_pin="2270d5ba925bcf91c56db94fac663695e69079c74edbf80aff8fa086e7c81665",
             probe=artifact14 / "008-differentiable-view14-probe-1ca74384.py",
             probe_pin="1ca74384675f4f5bbe1b477be827e1d405bf3ca04bc3eeaa22e4628dfe0cc1ac",
             support=False, refarg=False, epoch=False),
        dict(label="input4-regression", count=4,
             reader=I / "replay_input_boundaries4.py",
             reader_pin="5b8809eb9e405bf89a3586741d64210483fe3fbc5bc323e2cc16cb712ce4de66",
             reference=artifact4 / "007-actual.json",
             reference_pin="f4abe6a750ecc791b3a7bc7aa507b4c77eb0a2fcccf45b0c6a828db0e01490d3",
             probe=artifact4 / "008-pytorch_differentiable_view_input_boundaries_probe.py",
             probe_pin="cf569335f48624c1edf2f97a649200f2e792ebcef5b6f1df6bac73293ce02efc",
             support=True, refarg=True, epoch=False),
    ]
    ready = []
    for s in suites:
        inputs = dict(common)
        for name in ("reader", "reference", "probe"):
            inputs[s[name]] = s[name + "_pin"]
        if s["epoch"]:
            inputs[E / "identity_epochs.py"] = "225472f6c7b00e8a7feefa876b025548d55aeca8a4ec5ffbf909a3e5d4d6d20b"
            inputs[R / "runs/replay_shape26_r3.py"] = "af290dad8ed2c815a1fe17c98296a39a451ba2de7673c16b97608ad16fc645a2"
        rows = []
        for p, pin in inputs.items():
            raw = check(p, pin)
            rows.append(dict(path=str(p), bytes=len(raw), sha256=pin))
        output = R / ("runs/r4-scalar07b-native" + s["label"] + "-01")
        intent_path = R / ("runs/r4-scalar07b-native" + s["label"] + "-intent.json")
        assert not output.exists() and not intent_path.exists(), (output, intent_path)
        argv = ["/usr/bin/python3", "-B", str(s["reader"]),
                "--binary", str(N / "tensor-shape-scalar-session"),
                "--source", str(N / "runtime.hepta"), "--build-report", str(N / "build.json"),
                "--protocol", str(B / "protocol.py"), "--observer", str(R / "runs/native_observer_shape02.py"),
                "--reference", str(s["reference"]), "--probe", str(s["probe"]),
                "--expected-source-sha256", SOURCE, "--expected-native-sha256", a.expected_native_sha256,
                "--expected-observer-sha256", OBS, "--expected-functions", "658",
                "--expected-native-units", "13", "--output", str(output / "observed")]
        if s["support"]:
            argv += ["--support-reader", str(B / "replay_direct_view14.py")]
        if s["refarg"]:
            argv += ["--expected-reference-sha256", s["reference_pin"]]
        if s["epoch"]:
            argv += ["--identity-adapter", str(E / "identity_epochs.py"),
                     "--parent-reader", str(R / "runs/replay_shape26_r3.py")]
        intent = dict(schema="heptatorch.r4-native-replay-intent.v1", argv=argv, cwd=str(R),
                      execution_owner="/root/pytorch_scope", native_requested=True, torch_requested=False,
                      custody_directory=str(output), timeout_seconds=2400, expected_cases=s["count"],
                      allowed_success_statuses=["PASS"], inputs=rows,
                      stable_key="heptatorch-r4-scalar07b-native" + s["label"] + "-20261117-v1",
                      native_started_at_intent_creation=False,
                      previous_scalar06_whole_scope="FAIL; original full26 24PASS/2FAIL and full32 PASS remain separate immutable results",
                      old_source_qualification_transferred=False,
                      invocation_scope="New complete fixed-reference replay; no case selection or reference/numerical-comparator edit")
        if s["epoch"]:
            intent["identity_scope"] = "Root's exact source-proven lifetime-epoch labels only; original reference and all inherited comparison methods remain immutable."
        if s["count"] in (14, 4):
            intent["inherited_regression_scope"] = "Original fixed reference and exact old reader, new final image; local custody argv uses -B, not a claim that the historical GitHub request is reused."
        raw = (json.dumps(intent, indent=2) + "\n").encode()
        ready.append((intent_path, raw, intent))
    for p, raw, intent in ready:
        with p.open("xb") as f:
            f.write(raw)
        print(json.dumps(dict(intent=str(p), sha256=sha(raw), bytes=len(raw), inputs=len(intent["inputs"]),
                              expected_cases=intent["expected_cases"], stable_key=intent["stable_key"],
                              native_started=False)), flush=True)

if __name__ == "__main__":
    main()
