"""Seal completed scalar07b native evidence; no native, Torch, or compiler execution."""
from pathlib import Path
import hashlib, json, lzma, os, stat, tarfile
R=Path("/home/qian-qi/heptatorch-continuation-20261116")
O=R/"runs/r4-scalar07b-native-four-suite-handoff-01"
O.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
SOURCE="c436e21c45355891f8423f174a47e7c40fc8e1d6aef9a112043fac8787255d7a"
NATIVE="0799496559ffdfb051e34bc7a543db238b81d09c970a5cb4a8235151e0335b74"
BUILD="b31a45a850f06196432b2786ad0a39b56088ccf6c7b100d0da3517a44de5ba48"
OBS="59019b5c4aeae0d7e04b362354bd9ca55917d2196791d3d18c4908a05fdbba8b"
SPECS=[
("native26","26-first",26,"1a1e770c538-392-3d81","0efe36bf9d976db0e0b7e9c8aabfb6891d866a6d2ab5c3955bf05d2b433a3e78"),
("native32","32-first",32,"1a1e771d1ac-392-3d83","375c2f22852f02c30ac9635fb6e2f0b44a1b69263b3870d913c21b3cb527aa56"),
("native14","14-regression",14,"1a1e7729f94-392-3d88","b60d5ea75d5b5d51a6135c4f673e0083225cadb3b1ea588c23ee1de079c810b8"),
("native-input4","input4-regression",4,"1a1e7734794-392-3d8b","e1ceb22facd06cfd65eca73eb76bb155a51cfabaf682e1bb2dc9c62251695de3"),
]
N=R/"runs/differentiable-view-r4-scalar07b-native-build-01/candidate-r4-scalar07b"
assert sha((N/"runtime.hepta").read_bytes())==SOURCE
assert sha((N/"tensor-shape-scalar-session").read_bytes())==NATIVE
assert sha((N/"build.json").read_bytes())==BUILD
build=json.loads((N/"build.json").read_bytes())
assert (build["status"],build["functions"],build["blocks"],build["instructions"],len(build["units"]),build["descriptor_bytes"])==("PASS",658,8661,30980,13,672)
for u in build["units"]:
 for suffix,key in ((".hepta","source_sha256"),(".o","object_sha256")):
  assert sha((N/(u["name"]+suffix)).read_bytes())==u[key]
def emit(name,data):
 p=O/name
 raw=data if isinstance(data,bytes) else (json.dumps(data,indent=2,allow_nan=False)+"\n").encode()
 with p.open("xb") as f:f.write(raw)
 p.chmod(0o644)
 return p
roots=[];results=[];counts={k:0 for k in ("cases","frames","assertions","exact_words","full_rng_bytes","rollback_bytes")}
copy_modes=[]
for name,label,count,job,pin in SPECS:
 root=R/("runs/r4-scalar07b-native"+label+"-01")
 raw=(root/"observed/report.json").read_bytes();assert sha(raw)==pin
 d=json.loads(raw)
 assert d["status"]=="PASS" and d["cases"]==d["passed_cases"]==count and d["failed_cases"]==0
 assert d["native_executed"] is True and d["torch_executed_here"] is False and d["all_inputs_unchanged"] is True
 assert (d["source_sha256"],d["native_sha256"],d["observer_sha256"],d["functions"],d["native_units"])==(SOURCE,NATIVE,OBS,658,13)
 assert d.get("all_sessions_eof_exit_zero",d.get("all_executed_sessions_eof_exit_zero")) is True
 assert len(d["rows"])==count and all(x["status"]=="PASS" and x["exit_code"]==0 and not x["mismatches"] and x["error"] is None for x in d["rows"])
 execution=json.loads((root/"execution.json").read_bytes())
 assert execution["status"]=="PASS" and execution["returncode"]==0
 assert execution["child_started"] and execution["child_completed"] and execution["all_inputs_unchanged"] and execution["request_file_unchanged"]
 assert execution["error"] is None and execution["child_report_sha256"]==pin
 assert (root/"stderr.bin").read_bytes()==b""
 intent_path=R/("runs/r4-scalar07b-native"+label+"-intent.json")
 intent=json.loads(intent_path.read_bytes())
 assert sha(intent_path.read_bytes())==execution["intent_sha256"] and execution["argv"]==intent["argv"]
 assert intent["expected_cases"]==count and intent["execution_owner"]=="/root/pytorch_scope"
 for row in intent["inputs"]:
  p=Path(row["path"])
  assert p.stat().st_size==row["bytes"] and sha(p.read_bytes())==row["sha256"],str(p)
 if count==26:
  assert d["blocked_cases"]==0 and d["all_reference_cases_executed"]
  e=d["identity_epoch_admission"]
  assert e["retirements"]==2 and e["unaffected_rows"]==24 and e["identity_annotations"]==208
  assert e["all_nonidentity_fields_unchanged"] and e["whole_inverse_equal"]
  assert sha((root/"observed/identity-epoch-plan.json").read_bytes())==e["proof_sha256"]=="d60cbd621e927434994b869edf93115eec7b1a3ec6b685041a90b14c9958becb"
  plan=json.loads((root/"observed/identity-epoch-plan.json").read_bytes())
  assert len(plan["copied_negative_controls"])==6
 out=emit(name+"-report.json",raw)
 copy_modes.append({"original":str(root/"observed/report.json"),"original_mode":stat.S_IMODE((root/"observed/report.json").stat().st_mode),"copy":out.name,"copy_mode":0o644,"sha256":pin,"bytes_identical":True})
 roots.append((name,root))
 results.append({"name":name,"status":"PASS","cases":count,"report_sha256":pin,"job":job,"stable_key":intent["stable_key"],"intent_sha256":execution["intent_sha256"],"execution_sha256":sha((root/"execution.json").read_bytes()),"inputs_bound":len(intent["inputs"]),"all_original_inputs_unchanged":True,"all_sessions_eof_exit_zero":True,"expected_scope":d["comparison_scope"]})
 for k in counts:counts[k]+=d[k]
assert counts=={"cases":76,"frames":82503,"assertions":481580,"exact_words":66165,"full_rng_bytes":11295104,"rollback_bytes":2143906608}
roots += [("native-build",N),("author-source07b",R/"runs/differentiable-view-r4-scalar-source-07b"),("independent-source-review",R/"runs/hia-wrapped-scalar07b-source-review-01")]
items=[]
for prefix,root in roots:
 for p in sorted(root.rglob("*")):
  assert not p.is_symlink(),str(p)
  if p.is_file():items.append((prefix+"/"+p.relative_to(root).as_posix(),p))
for name,label,_,_,_ in SPECS:
 for suffix in ("-intent.json",".request.json"):
  path=R/("runs/r4-scalar07b-native"+label+suffix)
  items.append(("orchestration/"+path.name,path))
for name in ("r4-native-replay-custody-runner-01.py","r4-scalar07b-create-four-intents-01.py","r4-scalar07b-create-four-intents-01.request.json","r4-scalar07b-runtime-tool-custody.json"):
 items.append(("orchestration/"+name,R/"runs"/name))
items += [("orchestration/seal.py",Path(__file__).resolve()),("orchestration/seal.request.json",R/"runs/r4-scalar07b-four-suite-seal-01.request.json")]
packet=R/"runs/differentiable-view-r4-scalar-source-handoff-07b"
for name in ("complete.tar.xz","source-manifest.json","compile-intent.json","prepare-review.json","custody.json"):
 items.append(("source-packet/"+name,packet/name))
rows=[]
for arc,p in items:
 st=p.stat();raw=p.read_bytes()
 rows.append({"path":arc,"source_path":str(p),"bytes":len(raw),"sha256":sha(raw),"mode":stat.S_IMODE(st.st_mode)})
assert len({x["path"] for x in rows})==len(rows)
manifest={"schema":"heptatorch.scalar07b.native-four-suite-members.v1","members":rows,"member_count":len(rows),"payload_bytes":sum(x["bytes"] for x in rows),"manifest_itself_is_additional_archive_member":True}
emit("file-manifest.json",manifest)
summary={"schema":"heptatorch.scalar07b.native-four-suite-qualification.v1","status":"PASS_FIXED_FOUR_SUITES_ONLY",
 "source_sha256":SOURCE,"native_sha256":NATIVE,"build_sha256":BUILD,"observer_sha256":OBS,
 "functions":658,"blocks":8661,"instructions":30980,"native_units":13,"descriptor_bytes":672,
 "suites":results,"totals":counts,"all_sessions_eof_exit_zero":True,"all_inputs_unchanged":True,
 "configuration":{"cpu_capability":"AVX512","threads":1,"deterministic_algorithms":True,"deterministic_fill":True},
 "identity_scope":"Original reference26 byte stream remains unchanged. The exact root adapter assigns epochs only after two source-proven Saved Scalar64 retirements; 208 identity labels change, 24 rows remain identical, all numerical and other fields have an exact inverse. Original immutable comparator methods are unchanged.",
 "source_delta_from06":{"unchanged_functions":653,"changed":["incoming_describe","incoming_mark_preserve_targets","retained_apply"],"exact_parent_body_aliases":["scalar_previous_incoming_describe","scalar_previous_incoming_mark_preserve_targets"],"global_arithmetic_Storage_Version_allocator_bodies_changed":False},
 "preserved_predecessors":{"scalar05":{"overall_status":"FAIL","native26":"0/26 FAIL","native32":"32/32 PASS","history_archive_sha256":"195eb47a586d9c19867d7c68bb93280fa35ac8cf1d4f50c3b3d2f494f0fdf026"},"scalar06":{"overall_status":"FAIL","native26":"24 PASS / 2 FAIL","native32":"32/32 PASS","history_archive_sha256":"6b81bf436bcc68b457d67f58982b66faa29932fc91ff47c35f061c1f3a1b5c66"},"source07":"PREPARED_NOT_COMPILED; original author/prepared evidence remains in source packet"},
 "resource_status":"Separate independent final-image resources are not claimed by this native-reference package. The forward114 OOM control is not a backward-preserve-cache OOM proof.",
 "raw_recalculation_status":"Full byte custody is verified here. Independent replay of every exported observation and owner invariant is a separate read-only admission task, not inferred from aggregate PASS.",
 "full_pytorch_status":"HOLD","closed_schema_count":0,"pytorch_api_denominator":2590,"derivative_inventory":688,"system_acceptance_gates":17,
 "this_seal_started_native":False,"this_seal_started_compiler":False,"this_seal_started_Torch":False,
 "original_files_modified_or_removed":False,"outer_report_installation_mode_mapping":copy_modes}
emit("summary.json",summary)
archive=O/"complete.tar.xz"
with tarfile.open(archive,"w:xz",preset=6) as t:
 for arc,p in items:t.add(p,arcname=arc,recursive=False)
 t.add(O/"file-manifest.json",arcname="file-manifest.json",recursive=False)
archive.chmod(0o644)
expected={x["path"]:x for x in rows}
with tarfile.open(archive,"r:xz") as t:
 members=t.getmembers()
 assert len(members)==len(rows)+1 and len({m.name for m in members})==len(members)
 for m in members:
  assert m.isfile() and not m.name.startswith("/") and ".." not in Path(m.name).parts,m.name
  raw=t.extractfile(m).read()
  if m.name=="file-manifest.json":
   assert raw==(O/m.name).read_bytes() and m.mode==0o644
  else:
   d=expected[m.name]
   assert len(raw)==d["bytes"] and sha(raw)==d["sha256"] and m.mode==d["mode"],m.name
decoder=lzma.LZMADecompressor()
with archive.open("rb") as f:
 while not decoder.eof:
  chunk=f.read(65536) if decoder.needs_input else b""
  assert chunk or not decoder.needs_input,"truncated XZ"
  decoder.decompress(chunk,max_length=1048576)
 assert not decoder.unused_data and f.read(1)==b"","multiple XZ streams or trailing bytes"
for row,(_,p) in zip(rows,items):
 assert p.stat().st_size==row["bytes"] and stat.S_IMODE(p.stat().st_mode)==row["mode"] and sha(p.read_bytes())==row["sha256"],str(p)
receipt={"schema":"heptatorch.scalar07b.native-four-suite-byte-custody.v1","archive_sha256":sha(archive.read_bytes()),"archive_bytes":archive.stat().st_size,"archive_members":len(rows)+1,"manifest_sha256":sha((O/"file-manifest.json").read_bytes()),"payload_bytes":manifest["payload_bytes"],"all_members_bytes_modes_verified":True,"single_xz_stream_complete_eof":True,"all_original_files_unchanged":True,"no_native_Torch_or_compiler_executed":True}
emit("custody.json",receipt)
emit("README.md",b"""# Scalar07b complete native reference evidence

All four suites executed on source c436e21c / ELF 07994965: view/reshape26,
wrapped-float64-scalar32, original direct-view14, and original input-boundaries4.
There are 76 complete PASS sessions with EOF exit0. The original references and
comparison methods remain intact. Reference26 alone uses the frozen,
source-proven lifetime-epoch identity labels; its two retired Saved Scalar64
addresses are not emulated by production allocation behavior.

The four *-report.json files are exact original bytes. Only their new outer
copies have Git-compatible0644 mode; the original0600 modes remain inside
complete.tar.xz and are listed in summary.json. The archive includes full raw
requests/responses, owner snapshots, transport/EOF records, every child input,
all13 compiled source/object units and ELF/build, source07b authoring, its frozen
source packet, independent source review, exact requests, and durable tool
responses. A read-only SSH read failure was retried without a new native job.

file-manifest.json maps every archive-relative path to original absolute path,
full SHA256, size, and numeric POSIX mode. It is one additional archive member.
custody.json records every member verification, one complete XZ stream and
original-input recheck. No files were removed. Original05/06 failure archives
remain separately frozen and are referenced in summary.json; they are never
reclassified. Prepared07 was never compiled.

This is a bounded four-suite native qualification, not full PyTorch acceptance.
The full gate remains HOLD,0/2590 schemas,688 derivative inventory and17 gates.
Independent resources and read-only recomputation of exported raw observations
are separate gates. No new Torch operation, compiler or native process is run
by the sealing script.
""")
outer=[]
for p in sorted(O.iterdir()):
 if p.is_file():
  assert stat.S_IMODE(p.stat().st_mode)==0o644
  outer.append({"path":p.name,"bytes":p.stat().st_size,"sha256":sha(p.read_bytes()),"mode":0o644})
package={"schema":"heptatorch.scalar07b.native-four-suite-handoff.v1","payload":outer,"payload_count":len(outer),"payload_bytes":sum(r["bytes"] for r in outer),"status":"PASS_FIXED_FOUR_SUITES_ONLY","native_source_sha256":SOURCE,"native_image_sha256":NATIVE,"archive_member_manifest":"file-manifest.json","original_outer_copy_modes_explicit":True}
emit("package-manifest.json",package)
print(json.dumps({**receipt,"package_manifest_sha256":sha((O/"package-manifest.json").read_bytes()),"summary_sha256":sha((O/"summary.json").read_bytes()),"outer_payload_count":len(outer),"output":str(O)},indent=2))
