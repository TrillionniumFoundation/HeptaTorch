# Mixed F32 / I64 autograd, revision 09

This producer extends immutable I64 revision 07 with genuine mixed add, sub,
mul and true-division differentiation and original Saved Tensor access.
Production arithmetic, conversion, Tensor/Storage/Version ownership, graph
execution and allocation run in HIA. Python authors, builds and observes it.

The locked source is `d26e33363e1d1e43ba03b0289551b75826f348739e32e77b5e285df578088068`;
the ELF is `a1479a8773eb52937748bd90a1c4a79cc8d38c628be687152b9a8a97b721fb8c`.
There are 555 core functions, 7,407 blocks, 26,858 instructions, 11 actual native
modules, 640-byte descriptors and new `HTMXAD01` / `HTOMXD01` owner formats.
The original protocol document was written for revision 08 and is preserved
byte-for-byte. Revision 09 changes only `gradient_detach_inplace`: after its
existing admission guard, it releases the real private Saved Tensor roots
before releasing graph edges and Saved data. All other 554 bodies match 08.

## Reproduce

With a real I64 07 parent build and the repository's pinned authoring/toolchain
inputs, run the following from a normal checkout. All paths are explicit; no
workspace-specific override or existing mixed executable is used.

```sh
python -B tools/mixed_integer_autograd/qualify.py \
  --parent build/integer-tensors/native \
  --repository . \
  --upstream build/hia-toolchain-cold \
  --compiler build/stack-canonical/native/stack-module-compiler \
  --linker build/stack-canonical/native/stack-linker-session \
  --flat-compiler build/compiler-expansion/compiler-1 \
  --output build/mixed-integer-autograd
```

The caller may supply the actual pinned compiler directories used by its build.
The parent is verified as source `adf6cae6…` / ELF `b7324639…`. `rebuild.py`
executes the author and every native compiler/linker invocation anew, requires
all 11 unit sources and objects plus the full source/ELF to match the locked
profile, and records process-start/completion separately from test outcomes.

The four producer gates are:

1. New cold native construction, all 11 exact modules.
2. All 36 immutable real-Torch mixed-autograd observations, exact values,
   layouts, identities, Versions, None state, Saved behavior and partial errors.
3. The eight existing I64 gates: original 54 split into storage/arithmetic/
   dropout, alias8, integer-to-F32 RNE1237, promotion20, true-view lifetime6 and
   the independent inplace40 reader.
4. The twelve legacy 523 gates, including its sixteen inherited suites.

The gates overlap. Their counts are not summed into unique upstream APIs.
Existing partial classifications and explicit state lifecycle differences in
old reports remain unchanged. Native execution of original-Torch observations
is not a new local execution of Torch.

## Ownership and errors

Command 103's differentiable F32/I64 paths save the actual original arguments,
not temporary promoted F32 copies. A private 32-byte Storage and Hold keep the
two `(node, incarnation)` references; repeated slots retain/release separately.
The existing actual Saved S/V/offset/counter still determines mutation errors.
Command 107 publishes the true saved input when present; absent, spent and
version-mismatched results retain their distinct contracts. Getter observation
can create a public token and must release it if only primitive metadata is held.
Command 58 keeps its established partial-commit semantics. Command 104 continues
to reject a requires-grad input; integer Tensor creation cannot require grad.

The frozen 36-case reader is copied without any numerical or identity changes.
The inherited readers only change necessary private tag/stride/source bindings;
exact inverse receipts accompany them. The ordinary zero-grad cleanup failure
of revision 08 is kept separately from its successful 36 numerical observations.
The fix does not relax audit53 or the original gradient detach guard.

## Remaining integration evidence

The standalone producer result does not replace the independent general-I64
owner checker, mixed Saved-root extension, resources and OOM controls, output
capacity checks, previous-profile typed handoff, new public Saved lifetime
reference, live32, or a correctly extended accounted35 observer. The previous
07 F32-only fixed35 checker assumed the descriptor's new role tail was zero;
that condition cannot be reused for new real Saved Tensor roots.

No higher-order gradients, Python exception-message frontend, arbitrary Python
wrapper reference counting, full 2,590-schema rewrite, or all-system-gates closure
is claimed. These remain separately bounded by the project's global ledger.
