from pathlib import Path
import hashlib,json,lzma,stat,tarfile
base=Path('/dev/shm/heptatorch-d26699e25fea/mixed-integer-autograd-extension')
out=Path('/workspace/scratch/d26699e25fea/mixed-integer-autograd-checkpoints/candidate10-portable-cold');out.mkdir(exist_ok=False)
sha=lambda r:hashlib.sha256(r).hexdigest();cold=base/'portable-cold10-01'
report_raw=(cold/'report.json').read_bytes();report=json.loads(report_raw)
assert report['status']=='PASS' and report['step_count']==5
assert report['native_cold_rebuild_executed'] is True
assert report['all_package_members_unchanged'] and report['all_external_package_members_unchanged']
inv=json.loads((base/'portable-cold10-invocation-01/invocation.json').read_bytes());assert inv['exit_code']==0 and inv['process_completed'] is True
assert sha((cold/'native/runtime.hepta').read_bytes())==report['source_sha256']
assert sha((cold/'native/tensor-mixed-autograd-session').read_bytes())==report['native_sha256']
files=[]
for name in ['portable-cold10-01','portable-cold10-invocation-01','peer-source-review10']:
 files.extend(p for p in (base/name).rglob('*') if p.is_file())
files.append(base/'checkpoint_cold10.py');assert len(files)==len(set(files))
members={};archive=out/'checkpoint.tar.xz'
with lzma.open(archive,'wb',preset=3) as xz:
 with tarfile.open(fileobj=xz,mode='w|') as tar:
  for p in sorted(files):
   assert not p.is_symlink();name=p.relative_to(base).as_posix();raw=p.read_bytes()
   members[name]={'bytes':len(raw),'sha256':sha(raw),'mode':stat.S_IMODE(p.stat().st_mode)}
   info=tar.gettarinfo(str(p),arcname=name);assert info.isfile()
   with p.open('rb') as r:tar.addfile(info,r)
seen=set()
with tarfile.open(archive,'r:xz') as tar:
 for info in tar:
  assert info.isfile() and info.name not in seen
  raw=tar.extractfile(info).read();pin=members[info.name]
  assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'] and info.mode==pin['mode'];seen.add(info.name)
assert seen==set(members)
d=lzma.LZMADecompressor()
with archive.open('rb') as r:
 while compressed:=r.read(65536):
  assert not d.eof;d.decompress(compressed);assert not d.unused_data
assert d.eof
receipt={'schema':'heptatorch.mixed10-portable-cold-complete-evidence.v1','status':'VERIFIED','source_sha256':report['source_sha256'],'native_sha256':report['native_sha256'],'source_package_manifest_sha256':report['package_manifest_sha256'],'cold_report_sha256':sha(report_raw),'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'member_count':len(members),'original_bytes':sum(x['bytes'] for x in members.values()),'members':members,'all_member_bytes_sizes_modes_verified':True,'single_xz_stream_EOF_verified':True,'new_native_units':11,'cold_gates':5,'expanded_inputs_or_outputs_deleted':False,'restoration_base':str(base)}
(out/'manifest.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='members'}))
