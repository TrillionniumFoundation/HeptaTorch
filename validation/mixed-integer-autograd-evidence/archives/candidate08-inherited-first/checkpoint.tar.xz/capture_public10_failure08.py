"""Reproduce the exact archived case07 packets and preserve the rejected audit owner."""
from pathlib import Path
import hashlib
import json
import lzma
import struct
from native_observer import Memory, wire
HERE=Path(__file__).resolve().parent
REPO=Path('/dev/shm/heptatorch-d26699e25fea/HeptaTorch-integer-tensors-integration-07')
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
def frames(raw):
    at=0; result=[]
    while at<len(raw):
        magic,n=struct.unpack_from('<8sQ',raw,at)
        result.append(raw[at+16:at+16+n]);at+=16+n
    assert at==len(raw)
    return result
native=HERE/'candidate-08/tensor-mixed-autograd-session'
source=HERE/'candidate-08/runtime.hepta'
assert SHA(native.read_bytes())=='fa604952990aabc12d09683dcb59c9dc8b2485ef35e8bb535c917804960f8be0'
assert SHA(source.read_bytes())=='c88498ab4674cd6857dad2b6ef752612b500bd4fa5df56dbf99dece0d96e3013'
old=HERE/'legacy523-first-08/inherited16/original-public-ten/case-07'
requests=frames((old/'requests.frames.bin').read_bytes());responses=frames((old/'responses.frames.bin').read_bytes())
assert len(requests)==len(responses)==129
out=HERE/'public10-case07-diagnostic-08';out.mkdir(exist_ok=False)
w=wire(REPO/'tests/retained_nonleaf_review/protocol.py');s=w.Session(native,directory=out/'raw')
try:
    for i,(request,expected) in enumerate(zip(requests,responses)):
        if i==128:before=s.owner()
        actual=s.exchange(request)
        assert actual==expected,('original-packet-replay',i,SHA(actual),SHA(expected))
    after=s.owner();assert before==after
    assert w.parse(actual)==(9,[])
    raw=before['bytes'];(out/'owner-before-audit.bin.xz').write_bytes(lzma.compress(raw,preset=6))
    m=Memory(raw);rows=[]
    for node in range(1,m.q(8)):
        d=m.node(node)
        if d[38] and (d[73] or d[75]):
            rows.append({'node':node,'incarnation':d[40],'AD_opcode':d[5],'metadata_refs':d[26],
                'optimizer_refs':d[39],'gradient_refs':d[50],'Saved_root_refs':d[75],
                'role_handle_or_node':d[73],'role_address_or_incarnation':d[74],
                'Saved_ids':list(d[35:38]),'descriptor_words':list(d)})
    assert any(x['AD_opcode']==0 and x['role_handle_or_node']>65535 and x['Saved_ids']==[0,0,0] for x in rows)
    summary={'status':'DIAGNOSED_NATIVE_FAILURE','original_frames_reproduced':129,'original_responses_all_byte_identical':True,
       'audit_status':9,'whole_owner_rollback':True,'owner_bytes':len(raw),'owner_sha256':SHA(raw),'pointer_before':before['pointer'],
       'pointer_after':after['pointer'],'source_sha256':SHA(source.read_bytes()),'native_sha256':SHA(native.read_bytes()),
       'role_nodes':rows,'original_request_sha256':SHA((old/'requests.frames.bin').read_bytes()),
       'original_response_sha256':SHA((old/'responses.frames.bin').read_bytes())}
finally:
    summary['transport']=s.finish()
(out/'report.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='role_nodes'}))
