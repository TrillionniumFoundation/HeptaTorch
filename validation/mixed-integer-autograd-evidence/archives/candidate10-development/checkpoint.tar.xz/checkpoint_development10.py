import hashlib,json,lzma,os,stat,tarfile
from pathlib import Path
base=Path('/dev/shm/heptatorch-d26699e25fea/mixed-integer-autograd-extension')
out=Path('/workspace/scratch/d26699e25fea/mixed-integer-autograd-checkpoints/candidate10-development')
out.mkdir(parents=True,exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
roots=['candidate-10','actual36-first-10','inherited07-first-10','legacy523-first-10','inherited-tests10','legacy-adapters10']
singles=['run_inherited10.py','run_legacy523_10.py','replay_actual36.py','native_observer10.py','candidate10-rebind.json','observer10-inverse.json','checkpoint_development10.py']
files=[]
for rel in roots:
 files.extend(p for p in (base/rel).rglob('*') if p.is_file())
files.extend(base/r for r in singles)
assert len(files)==len(set(files))
for rel in roots[1:4]:
 d=json.loads((base/rel/'report.json').read_bytes());assert d['status']=='PASS'
assert sha((base/'candidate-10/runtime.hepta').read_bytes())=='5f8ab1f7ca1593dc21b8b6a3537e210cfbc42b37ddefcb322239c5a316d88c49'
assert sha((base/'candidate-10/tensor-mixed-autograd-session').read_bytes())=='69045063c00395d07fc6c0101ed1b8aba18376cb1daea54e0a01c2c5caeb49b6'
members={};archive=out/'checkpoint.tar.xz'
with lzma.open(archive,'wb',preset=3) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|') as tar:
  for p in sorted(files):
   assert not p.is_symlink(),str(p)
   data=p.read_bytes();name=p.relative_to(base).as_posix()
   members[name]={'bytes':len(data),'sha256':sha(data),'mode':stat.S_IMODE(p.stat().st_mode)}
   info=tar.gettarinfo(str(p),arcname=name);assert info.isfile()
   with p.open('rb') as r:tar.addfile(info,r)
seen=set()
with tarfile.open(archive,'r:xz') as tar:
 for info in tar:
  assert info.isfile() and info.name not in seen
  raw=tar.extractfile(info).read();pin=members[info.name]
  assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'] and info.mode==pin['mode']
  seen.add(info.name)
assert seen==set(members)
d=lzma.LZMADecompressor()
with archive.open('rb') as r:
 while c:=r.read(65536):
  assert not d.eof;d.decompress(c);assert not d.unused_data
assert d.eof
receipt={'schema':'heptatorch.mixed-autograd-development10-checkpoint.v1','status':'VERIFIED','source_sha256':'5f8ab1f7ca1593dc21b8b6a3537e210cfbc42b37ddefcb322239c5a316d88c49','native_sha256':'69045063c00395d07fc6c0101ed1b8aba18376cb1daea54e0a01c2c5caeb49b6','archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'member_count':len(members),'original_bytes':sum(x['bytes'] for x in members.values()),'members':members,'all_member_bytes_sizes_modes_verified':True,'single_xz_stream_EOF_verified':True,'restoration_base':str(base),'executed_suites':roots[1:4]}
manifest=out/'manifest.json';manifest.write_text(json.dumps(receipt,indent=2)+'\n')
remove=[]
for name,pin in members.items():
 p=base/name
 if name.split('/')[0] not in roots[1:4]:continue
 if p.suffix in ('.json','.py','.md','.txt','.stdout','.stderr'):continue
 remove.append(p)
remove_abs={str(p) for p in remove};active=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdecimal():continue
 try:
  for fd in (proc/'fd').iterdir():
   try:
    target=os.readlink(fd)
    if target in remove_abs:active.append({'pid':proc.name,'fd':fd.name,'target':target})
   except OSError:pass
 except OSError:pass
assert not active,active
removed=[]
for p in remove:
 name=p.relative_to(base).as_posix();pin=members[name]
 assert sha(p.read_bytes())==pin['sha256'] and stat.S_IMODE(p.stat().st_mode)==pin['mode']
 p.unlink();removed.append(name)
compaction={'status':'COMPLETED','no_active_fds_verified':True,'archive_sha256':receipt['archive_sha256'],'manifest_sha256':sha(manifest.read_bytes()),'removed_files':removed,'removed_bytes':sum(members[x]['bytes'] for x in removed),'kept_candidate_source_and_all11units':True,'kept_reports_and_sources':True}
(out/'compaction.json').write_text(json.dumps(compaction,indent=2)+'\n')
for rel in roots[1:4]:
 (base/rel/'RESTORE-DEVELOPMENT10.json').write_text(json.dumps({'archive':str(archive),'manifest':str(manifest),'archive_member_prefix':rel},indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='members'}))
print(json.dumps({k:v for k,v in compaction.items() if k!='removed_files'}))
