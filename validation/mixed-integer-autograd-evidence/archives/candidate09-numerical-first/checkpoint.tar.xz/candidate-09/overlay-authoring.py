def entry(s: readbuf, o: mutbuf, w: mutbuf, scratch: mutbuf) -> u32:
    if length(o) < 32:
        return 0
    reply_error(o, 0)
    error = frame_valid(s)
    if error != 0:
        reply_error(o, error)
        return 32
    putw(w, 0, 0)
    putw(w, 48, 0)
    putw(w, 56, 0)
    count = getr(s, 8)
    if count != 0:
        putw(w, 96, 8192)
    end = 32 + count * 64
    i = 0
    at = 32
    halted = 0
    while i < count and halted == 0:
        if at > length(o) - 32:
            putw(o, 24, 3)
            return at
        putw(w, 104, i)
        code = getr(s, 32 + i * 64)
        if code == 107:
            next = binary_saved_command(s,o,w,32+i*64,at)
        elif code == 106:
            next = integer_scalar_command(s, o, w, 32 + i * 64, at)
        elif code == 105:
            next = integer_dropout_command(s, o, w, scratch, 32 + i * 64, at)
        elif code == 103 or code == 104:
            next = integer_command(s, o, w, 32 + i * 64, at)
        elif code >= 96 and code <= 102:
            next = typed_command(s, o, w, scratch, 32 + i * 64, at, end)
        elif code >= 91 and code <= 94:
            next = gradient_object_command(s, o, w, 32 + i * 64, at)
        elif code >= 71 and code <= 79 or code == 90 or code == 95:
            next = owned_optimizer_command(s, o, w, 32 + i * 64, at, end)
        elif code >= 80 and code <= 89:
            if code == 86 or code == 87:
                next = dist_partial_command(s, o, w, scratch, 32 + i * 64, at)
            else:
                next = dist_command(s, o, w, scratch, 32 + i * 64, at)
        elif code >= 60 and code <= 69:
            next = rng_command(s, o, w, scratch, 32 + i * 64, at, end)
        else:
            next = command(s, o, w, 32 + i * 64, at, end)
        if getw(w, 0) == 0 and getw(w, 3968) != 0:
            graph_collect_since(w, getw(w, 8))
        error = getw(w, 0)
        if error != 0:
            putw(o, 24, error)
            return next
        putw(w, getw(w, 96) + i * 8, getw(o, at + 16))
        if (code == 58 or code == 86 or code == 87) and getw(o, at + 16) != 0:
            halted = 1
        if code == 105 and getw(o, at + 32) != 0:
            halted = 1
        at = next
        i = i + 1
        putw(o, 16, i)
    if count != 0:
        fill_range(w, 8192, count * 8, 0)
        putw(w, 96, 0)
        putw(w, 104, 0)
    putw(w, 80, 0)
    if getw(w, 0) != 0:
        reply_error(o, getw(w, 0))
        return 32
    return at

def integer_result_dtype(w: mutbuf, op: u64, a: u64, b: u64) -> u64:
    ca = tensor_dtype(w, a)
    cb = tensor_dtype(w, b)
    if ca > 2 or cb > 2 or (ca != 2 and cb != 2):
        return terror(w, 7)
    if op < 1 or op > 7:
        return terror(w, 7)
    if op == 2 and (ca == 1 or cb == 1):
        return terror(w, 7)
    if ca == 0 or cb == 0 or op == 7:
        return 0
    return 2

def integer_binary(w: mutbuf, op: u64, a: u64, b: u64, inplace: u64) -> u64:
    if valid(w, a) == 0 or valid(w, b) == 0:
        return 0
    requires = getw(w,dptr(w,a)+32) | getw(w,dptr(w,b)+32)
    if inplace != 0 and requires != 0:
        return terror(w,5)
    dtype = integer_result_dtype(w, op, a, b)
    if getw(w, 0) != 0:
        return 0
    if inplace != 0:
        if integer_inplace_overlap(w, a, b) == 0:
            return 0
    rank = bshape(w, a, b)
    if getw(w, 0) != 0:
        return 0
    target = a
    if inplace != 0:
        if integer_target_shape(w, a, rank) == 0:
            return 0
        if tensor_dtype(w, a) != 2 or dtype != 2:
            return terror(w, 7)
        if version_can_bump(w, a, 1) == 0:
            return 0
    if op >= 4 and op <= 6 and (dtype == 0):
        return terror(w, 7)
    left = integer_promote_operand(w, a, dtype)
    if left == 0:
        return 0
    right = integer_promote_operand(w, b, dtype)
    if right == 0:
        return 0
    if inplace == 0:
        rank = bshape(w, left, right)
        if getw(w, 0) != 0:
            return 0
        target = typed_descriptor(w, rank, 128, requires, 1, dtype)
        if target == 0:
            return 0
        if integer_pointwise_layout(w, target, left, right) == 0:
            return 0
    n = getw(w, dptr(w, target) + 8)
    i = 0
    while i < n:
        integer_binary_element(w, op, target, left, right, i)
        i = i + 1
    if inplace != 0:
        if bump_version(w, target) == 0:
            return 0
    if inplace == 0 and requires != 0:
        return record(w,target,choose(op == 7,4,op),a,b)
    return target

def dtype_audit(w: mutbuf) -> u64:
    status = 0
    i = 1
    while i < getw(w, 8):
        p = dptr(w, i)
        if getw(w, p + 616) != 0:
            status = 9
        i = i + 1
    if status == 0:
        status = history_audit(w)
    i = 1
    while i < getw(w, 8) and status == 0:
        p = dptr(w, i)
        if getw(w, p + 304) != 0:
            code = getw(w, p + 576)
            if code > 2:
                status = 9
            if code != 0 and (getw(w, p + 32) != 0 or getw(w, p + 384) != 0):
                status = 9
            mask = getw(w, p + 584)
            if mask > 65535:
                status = binary_saved_audit(w,p)
            elif mask != 0:
                q = private_tensor(w, mask, getw(w, p + 592))
                if code == 2 and getw(w, p + 408) != 0:
                    if integer_view_root_valid(w, p, q) == 0:
                        status = 9
                    else:
                        putw(w, q + 616, getw(w, q + 616) + 1)
                elif q == 0 or getw(w, p + 40) != 42 or getw(w, p + 288) == 0:
                    status = 9
                else:
                    saved = so_saved_live(w, getw(w, p + 288))
                    if saved == 0:
                        status = 9
                    elif so_uget(w, saved + 16) != getw(w, q + 216) or so_uget(w, saved + 24) != getw(w, q + 224):
                        status = 9
                    putw(w, q + 616, getw(w, q + 616) + 1)
            elif getw(w, p + 592) != 0 or (code == 2 and getw(w, p + 408) != 0):
                status = 9
        elif getw(w, p + 584) != 0 or getw(w, p + 592) != 0 or getw(w, p + 600) != 0:
            status = 9
        i = i + 1
    i = 1
    while i < getw(w, 8):
        p = dptr(w, i)
        if getw(w, p + 600) != getw(w, p + 616):
            status = 9
        putw(w, p + 616, 0)
        i = i + 1
    return status

def gradient_detach_inplace(w: mutbuf, g: u64) -> u64:
    p = dptr(w, g)
    if getw(w, p + 40) != 0:
        if getw(w, p + 408) != 0 or getw(w, p + 208) != getw(w, p + 312) + getw(w, p + 400):
            return terror(w, 5)
        if dtype_mask_release(w, g) == 0:
            return 0
        j = 0
        while j < gradient_parent_count(w, g):
            if graph_release_edge(w, graph_parent_at(w, g, j), graph_edge_enabled(w, g, j)) == 0:
                return 0
            j = j + 1
        saved_release(w, getw(w, p + 280))
        saved_release(w, getw(w, p + 288))
        saved_release(w, getw(w, p + 296))
        hold_release(w, getw(w, p + 256))
        hold_release(w, getw(w, p + 264))
        hold_release(w, getw(w, p + 272))
        putw(w, p + 40, 0)
        putw(w, p + 48, 0)
        putw(w, p + 56, 0)
        putw(w, p + 72, 0)
        putw(w, p + 80, 0)
        putw(w, p + 160, 0)
        putw(w, p + 184, 0)
        putw(w, p + 256, 0)
        putw(w, p + 264, 0)
        putw(w, p + 272, 0)
        putw(w, p + 280, 0)
        putw(w, p + 288, 0)
        putw(w, p + 296, 0)
        putw(w, p + 328, 0)
        putw(w, p + 344, 0)
        putw(w, p + 352, 0)
    putw(w, p + 32, 0)
    return choose(getw(w, 0) == 0, 1, 0)

def binary_saved_base(w:mutbuf, p:u64) -> u64:
    id = getw(w,p+584)
    if id <= 65535:
        return 0
    hp = so_slot_lookup(w,6,id)
    if hp == 0 or so_uget(w,hp+24) != 1:
        return terror(w,9)
    sp = so_storage_live(w,so_uget(w,hp+16))
    if sp == 0 or so_uget(w,sp+24) != 32:
        return terror(w,9)
    address = 9223372036854775808+so_uget(w,sp+16)
    if address != getw(w,p+592):
        return terror(w,9)
    return address

def binary_saved_retain_one(w:mutbuf, address:u64, slot:u64, t:u64, saved:u64) -> u64:
    if saved == 0:
        return 1
    p = dptr(w,t)
    s = so_saved_live(w,saved)
    if s == 0 or getw(w,p+240) != 1 or getw(w,p+320) == 0:
        return terror(w,9)
    if so_uget(w,s+16) != getw(w,p+216) or so_uget(w,s+24) != getw(w,p+224):
        return terror(w,9)
    if getw(w,p+600) >= 4294967295:
        return terror(w,8)
    if node_retain(w,t) == 0:
        return 0
    putw(w,p+600,getw(w,p+600)+1)
    putw(w,address+slot*16,t)
    putw(w,address+slot*16+8,getw(w,p+320))
    return 1

def binary_saved_bind(w:mutbuf, t:u64, a:u64, b:u64) -> u64:
    p = dptr(w,t)
    sa = getw(w,p+280)
    sb = getw(w,p+288)
    if sa == 0 and sb == 0:
        return 1
    if getw(w,p+584) != 0 or getw(w,p+592) != 0:
        return terror(w,9)
    address = alloc(w,32)
    if getw(w,0) != 0:
        return 0
    putw(w,p+584,getw(w,80))
    putw(w,p+592,address)
    if binary_saved_retain_one(w,address,0,a,sa) == 0:
        return 0
    return binary_saved_retain_one(w,address,1,b,sb)

def record(w:mutbuf, t:u64, op:u64, a:u64, b:u64) -> u64:
    result = mixed_original_record(w,t,op,a,b)
    if result == 0:
        return 0
    if op == 3 or op == 4:
        if binary_saved_bind(w,t,a,b) == 0:
            return 0
    return result

def binary_saved_release(w:mutbuf, t:u64) -> u64:
    p = dptr(w,t)
    address = binary_saved_base(w,p)
    if address == 0:
        return terror(w,9)
    hold = getw(w,p+584)
    putw(w,p+584,0)
    putw(w,p+592,0)
    slot = 0
    while slot < 2:
        target = getw(w,address+slot*16)
        inc = getw(w,address+slot*16+8)
        if target != 0:
            q = private_tensor(w,target,inc)
            if q == 0 or getw(w,q+600) == 0:
                return terror(w,9)
            putw(w,address+slot*16,0)
            putw(w,address+slot*16+8,0)
            putw(w,q+600,getw(w,q+600)-1)
            if node_release(w,target) == 0:
                return 0
        elif inc != 0:
            return terror(w,9)
        slot = slot+1
    return hold_release(w,hold)

def dtype_mask_release(w:mutbuf, t:u64) -> u64:
    if getw(w,dptr(w,t)+584) > 65535:
        return binary_saved_release(w,t)
    return mixed_original_mask_release(w,t)

def binary_saved_audit(w:mutbuf, p:u64) -> u64:
    address = binary_saved_base(w,p)
    if address == 0 or getw(w,p+576) != 0 or getw(w,p+32) == 0:
        return 9
    op = getw(w,p+40)
    if (op != 3 and op != 4) or getw(w,p+328) != 0:
        return 9
    count = 0
    slot = 0
    while slot < 2:
        target = getw(w,address+slot*16)
        inc = getw(w,address+slot*16+8)
        saved = getw(w,p+280+slot*8)
        if target == 0:
            if saved != 0 or inc != 0:
                return 9
        else:
            q = private_tensor(w,target,inc)
            s = so_saved_live(w,saved)
            if q == 0 or s == 0 or inc >= getw(w,p+320):
                return 9
            if so_uget(w,s+16) != getw(w,q+216) or so_uget(w,s+24) != getw(w,q+224):
                return 9
            if so_uget(w,s+40) != getw(w,q+232) or so_uget(w,s+56) != 0:
                return 9
            putw(w,q+616,getw(w,q+616)+1)
            count = count+1
        slot = slot+1
    if count == 0:
        return 9
    return 0

def binary_saved_needed(w:mutbuf, p:u64, slot:u64) -> u64:
    op = getw(w,p+40)
    if op == 1 or op == 2:
        return 0
    if op != 3 and op != 4:
        return terror(w,7)
    if slot == 0:
        return getw(w,p+80)
    if op == 4:
        return getw(w,p+72) | getw(w,p+80)
    return getw(w,p+72)

def binary_saved_get(w:mutbuf, t:u64, slot:u64) -> u64:
    p = dptr(w,t)
    if slot > 1:
        return terror(w,7)
    needed = binary_saved_needed(w,p,slot)
    if getw(w,0) != 0 or needed == 0:
        return 0
    if getw(w,p+328) != 0:
        return terror(w,10)
    saved = getw(w,p+280+slot*8)
    if saved == 0:
        return terror(w,9)
    if graph_saved_check(w,saved) == 0:
        return 0
    address = binary_saved_base(w,p)
    if address == 0:
        return terror(w,9)
    target = getw(w,address+slot*16)
    if private_tensor(w,target,getw(w,address+slot*16+8)) == 0:
        return terror(w,9)
    return publish_tensor(w,target)

def binary_saved_command(s:readbuf, o:mutbuf, w:mutbuf, cp:u64, at:u64) -> u64:
    result = 0
    if getr(s,cp+24) != 0 or getr(s,cp+32) != 0 or getr(s,cp+40) != 0 or getr(s,cp+48) != 0 or getr(s,cp+56) != 0:
        terror(w,7)
    if getw(w,0) == 0:
        t = public_node(w,resolve_handle(w,getr(s,cp+8)))
        if t != 0:
            result = binary_saved_get(w,t,getr(s,cp+16))
    status = getw(w,0)
    if status != 0:
        result = 0
    putw(o,at,107)
    putw(o,at+8,status)
    putw(o,at+16,result)
    putw(o,at+24,0)
    return at+32

def binary_backward_read(w:mutbuf, t:u64, index:u64) -> u64:
    value = tget(w,t,index)
    return integer_as_f32(value,tensor_dtype(w,t))
