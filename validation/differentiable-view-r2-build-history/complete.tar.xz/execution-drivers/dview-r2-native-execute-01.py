#!/usr/bin/env python3
"""One R2 child native compilation using the already verified cold parent and tools."""
from pathlib import Path
import datetime,hashlib,json,os,re,stat,subprocess,sys,traceback
BASE=Path('/home/qian-qi/heptatorch-continuation-20261116')
RUNS=BASE/'runs'
REPO=RUNS/'to-view-recovery-integration-01/repo'
SRC=RUNS/'differentiable-view-recovered-source-02'
PRIOR=RUNS/'differentiable-view-r1-native-build-01'
PARENT=PRIOR/'parent09b'
R1=PRIOR/'candidate-r1'
TOOLRUN=RUNS/'dview-r1-fixed-toolchain-cold-02'
TOOLS=TOOLRUN/'hepta-stack-budget/native'
OUT=RUNS/'differentiable-view-r2-native-build-01'
CHILD=OUT/'candidate-r2'
os.umask(0o077);OUT.mkdir(mode=0o700,exist_ok=False)
LOG=OUT/'execution';LOG.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n')
def info(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink(),str(p)
 b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(s.st_mode)}
before={}
def pin(p,digest):
 r=info(p);assert r['sha256']==digest,(str(p),r,digest);before[str(p)]=r;return r
report={'schema':'heptatorch.differentiable-view-r2-native-invocation.v1','status':'RUNNING',
 'started_at':utc(),'commands':[],'torch_executions':0,'target_runtime_business_executions':0,
 'runtime_qualified':False,'whole_project_status':'HOLD','closed_api_schemas':0,
 'pytorch_api_denominator':2590,'full_pytorch_rewrite_complete':False,
 'parent_native_rebuilt_this_invocation':False,'parent_reused_from_actual_cold_job':'1a1e661f2ad-392-3af9',
 'toolchain_rebuilt_this_invocation':False,'toolchain_reused_from_actual_cold_job':'1a1e65f617b-392-3af4'}
def run(label,argv):
 r={'label':label,'argv':[str(x) for x in argv],'cwd':str(REPO),
 'started':False,'completed':False,'started_at':utc(),'timeout_seconds':1800}
 report['commands'].append(r);save(LOG/(label+'.argv.json'),r)
 with (LOG/(label+'.stdout')).open('xb') as so,(LOG/(label+'.stderr')).open('xb') as se:
  p=subprocess.Popen(r['argv'],cwd=REPO,stdout=so,stderr=se)
  r['started']=True;r['pid']=p.pid;save(LOG/(label+'.started.json'),r)
  try:r['returncode']=p.wait(timeout=1800);r['timed_out']=False
  except subprocess.TimeoutExpired:p.kill();r['returncode']=p.wait();r['timed_out']=True
  r['completed']=True;r['completed_at']=utc()
 r['stdout']=info(LOG/(label+'.stdout'));r['stderr']=info(LOG/(label+'.stderr'))
 save(LOG/(label+'.completed.json'),r)
 print(json.dumps({'label':label,'returncode':r['returncode'],'stderr_bytes':r['stderr']['bytes']}),flush=True)
 assert r['returncode']==0 and not r['timed_out'] and r['stderr']['bytes']==0,r
try:
 compiler=TOOLS/'stack-module-compiler';linker=TOOLS/'stack-linker-session'
 pin(compiler,'b1c851a0896fa6071f800e1146c3c27d0c6cf85059e9a6281b46d42908a3f59f')
 pin(linker,'aae650e8822ef0b1e74d15108ad1d0f17ec791205ed5a158ec60b709f48f0e16')
 pin(TOOLRUN/'report.json','444c47e36a0c44f21a03bacefd4e2021d913fcb5815ecf6458c009790f8f7a4c')
 pin(PRIOR/'report.json','d69ce52b9e90faa77002a2f2be742bb9921c0d78ba0d1a2027d9f4ce0291354b')
 pin(PARENT/'build.json','bbd8678cb4434183003b4702ccb89fe83b6f899e4e1f0764bdce83391f80815d')
 pin(R1/'build.json','c42bc1b1ad5b7919a59907f20a6d514ef2ef1938fd6f10ec1bb1461b9b9e9339')
 pin(R1/'runtime.hepta','644c1e3e7828c60b1335794469a7ab38f73cb73b9f364d1b7ec9b83fdf7bf3c5')
 pin(SRC/'source-manifest.json','cfb6053ca9c8c85bccadc3d947ea431bf581a5f71dc254cfaeb6283581b50e9e')
 manifest=json.loads((SRC/'source-manifest.json').read_bytes())
 assert manifest['revision']=='R2' and len(manifest['files'])==15
 assert len({r['path'] for r in manifest['files']})==15
 for row in manifest['files']:
  p=SRC/row['path'];assert p.parent==SRC
  got=info(p);assert got=={k:row[k] for k in ('bytes','sha256','mode')},row
  before[str(p)]=got
 r1=json.loads((R1/'build.json').read_bytes())
 for name,digest in r1['inputs_sha256'].items():pin(Path(name),digest)
 pb=json.loads((PARENT/'build.json').read_bytes())
 assert pb['status']=='PASS' and pb['native_built_this_invocation'] is True
 assert pb['native_tool_processes_started']==pb['native_tool_processes_completed']==13
 assert len(pb['units'])==12 and all(x['started'] and x['completed'] and x['returncode']==0 and x['matches_original'] for x in pb['units'])
 assert all(pb[k] is True for k in ['all_unit_source_hashes_match_original','all_unit_object_hashes_match_original','linked_image_hash_matches_original','all_package_inputs_unchanged','all_native_tools_unchanged'])
 pin(PARENT/'runtime.hepta','4f8f73f463f681b5eb29423d71a35a0b42d807fd92bf976bbf76c1970fbcee33')
 pin(PARENT/'tensor-to-copy-session','53fb43b869858f020c0b936a65f00f3b14b97d9e37038a74c357e1da471fe083')
 pin(PARENT/'reference-original-build.json','9913ccb35c690f1a8795479ddd468531a966df71c375fcb91ed22d9f3c887557')
 for u in pb['units']:
  pin(PARENT/(u['name']+'.hepta'),u['source_sha256'])
  pin(PARENT/(u['name']+'.o'),u['object_sha256'])
 before[str(Path(__file__))]=info(Path(__file__))
 save(OUT/'inputs-before.json',before)
 review={'schema':'heptatorch.direct-view-r2-independent-source-review.v1','status':'SOURCE_ONLY_NO_BLOCKER_IDENTIFIED',
  'source_manifest_sha256':'cfb6053ca9c8c85bccadc3d947ea431bf581a5f71dc254cfaeb6283581b50e9e',
  'patch_sha256':'a11723de0cb3ed33d24b8650972301f7f482c1a9e17a46a98bd86ae6a67ba2e6',
  'upstream_variable_cpp_sha256':'ca2f1e573307069dee2fdff70ba81f161f48817cd278ad5464b9809cf23ab2c6',
  'read_source_spans':{'upstream-variable.cpp':[[177,207],[737,758]]},
  'read_complete_sources':['build.py','differentiable_view_overlay.py','view_refresh_retained_patch.py','SOURCE_REVIEW.md'],
  'findings':['Only the capture-success branch changes; eight appended blocks validate and move the retained weak hook.',
   'Old op0 captured accumulator bypasses this move. Weak pair requires exact old mode1/source index/incarnation.',
   'Current608 requires low16bits plus disable bit; only its disable bit is removed. Current624 is preserved.',
   'No600/208 strong ref change, no global history_capture change, no numerical kernel or reference change.',
   'Upstream lazy ViewInfo refresh calls update_tensor_hooks_on_new_gradfn, which moves retains_grad from old Node to new Node.'],
  'native_or_Torch_execution_by_source_review':False,
  'runtime_assertions_unchanged_by_this_wrapper':True}
 save(OUT/'independent-source-review.json',review)
 run('01-child-r2-native',[sys.executable,'-B',SRC/'build.py','--previous',PARENT,
  '--repository',REPO,'--upstream',BASE/'toolchain','--compactor',REPO/'tools/owned_optimizers/compact_functions.py',
  '--compiler',compiler,'--linker',linker,'--output',CHILD])
 child=json.loads((CHILD/'build.json').read_bytes())
 assert child['status']=='PASS' and child['orchestration_revision']=='RECOVERED_SOURCE_R2'
 assert (child['functions'],child['blocks'],child['instructions'],child['descriptor_bytes'])==(614,8090,29094,672)
 assert len(child['units'])==12 and child['state_format']=='HTVAD002' and child['backing_format']=='HTOVAD02'
 assert child['runtime_qualified'] is False and child['torch_executed'] is False
 assert child['link_exit']==0 and child['added_functions']==[]
 assert set(child['changed_parent_functions'])=={'to_strided_view','to_view_refresh','init_state','state_header','so_state_init','so_state_header'}
 assert child['source_sha256']=='197bd52db4815f575ea3e9055d3f5556900314bd2f4fbb262e80cea76ea16ef2'
 for u in child['units']:
  assert u['compiler_exit']==0
  assert info(CHILD/(u['name']+'.hepta'))['sha256']==u['source_sha256']
  assert info(CHILD/(u['name']+'.o'))['sha256']==u['object_sha256']
  assert (CHILD/(u['name']+'.stderr')).read_bytes()==b''
 assert (CHILD/'link.stderr').read_bytes()==b''
 assert info(CHILD/'runtime.hepta')['sha256']==child['source_sha256']
 assert info(CHILD/'tensor-differentiable-view-session')['sha256']==child['native_sha256']
 F=re.compile(rb'^(fn ([A-Za-z_][A-Za-z_0-9]*)\([^\n]*\n.*?^end\n)',re.M|re.S)
 old={n.decode():b for b,n in F.findall((R1/'runtime.hepta').read_bytes())}
 new={n.decode():b for b,n in F.findall((CHILD/'runtime.hepta').read_bytes())}
 assert set(old)==set(new) and len(new)==614
 changes=[n for n in old if old[n]!=new[n]]
 assert set(changes)=={'to_view_refresh','init_state','state_header','so_state_init','so_state_header'}
 assert sha(new['to_view_refresh'])=='08bf8d7fd28c4492e52dbaf1699a62457520201b4a73bbef90b5985a94a9c7a5'
 for n in changes:
  if n=='to_view_refresh':continue
  outer=n in ('init_state','state_header')
  a=b'HTVAD001' if outer else b'HTOVAD01';b=b'HTVAD002' if outer else b'HTOVAD02'
  a=('{"value":'+str(int.from_bytes(a,'little'))+'}').encode()
  b=('{"value":'+str(int.from_bytes(b,'little'))+'}').encode()
  assert new[n].count(b)==1 and old[n].count(a)==1 and new[n].replace(b,a)==old[n]
 for p,row in before.items():assert info(Path(p))==row,p
 report.update(status='BUILT_NOT_RUNTIME_QUALIFIED',completed_at=utc(),all_inputs_unchanged=True,
  child={'path':str(CHILD),'build_report':info(CHILD/'build.json'),'source_sha256':child['source_sha256'],
   'native_sha256':child['native_sha256'],'native_bytes':child['native_bytes'],
   'functions':614,'blocks':8090,'instructions':29094,'units':child['units'],
   'changed_parent_functions':child['changed_parent_functions'],'changed_r1_functions':changes,
   'unchanged_complete_r1_bodies':609},
  parent={'path':str(PARENT),'source_sha256':pb['source_sha256'],'native_sha256':pb['native_sha256'],
   'build_report':info(PARENT/'build.json'),'reused_from_cold_job':True})
 report['output_inventory']={str(p.relative_to(OUT)):info(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='report.json'}
 save(OUT/'report.json',report)
 print(json.dumps({'status':report['status'],'report':str(OUT/'report.json'),'report_sha256':sha((OUT/'report.json').read_bytes()),
  'source_sha256':child['source_sha256'],'native_sha256':child['native_sha256'],
  'build_sha256':info(CHILD/'build.json')['sha256'],'functions':614,'blocks':8090,'instructions':29094,'units':12}),flush=True)
except BaseException as error:
 report.update(status='FAIL',completed_at=utc(),error=repr(error),traceback=traceback.format_exc())
 try:report['input_recheck']={p:info(Path(p))==r for p,r in before.items()}
 except BaseException as secondary:report['input_recheck_error']=repr(secondary)
 try:report['partial_files']={str(p.relative_to(OUT)):info(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='report.json'}
 except BaseException as secondary:report['partial_inventory_error']=repr(secondary)
 if not (OUT/'report.json').exists():save(OUT/'report.json',report)
 print(json.dumps({'status':'FAIL','report':str(OUT/'report.json'),'error':repr(error)}),flush=True)
 raise
