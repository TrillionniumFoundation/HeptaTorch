#!/usr/bin/env python3
"""Seal the R2 compilation delta, with exact references to unchanged R1 evidence."""
from pathlib import Path,PurePosixPath
import hashlib,io,json,lzma,os,stat,tarfile,tempfile
BASE=Path('/home/qian-qi/heptatorch-continuation-20261116')
RUNS=BASE/'runs'
OUT=RUNS/'differentiable-view-r2-build-handoff-01'
BUILD=RUNS/'differentiable-view-r2-native-build-01'
SRC=RUNS/'differentiable-view-recovered-source-02'
R1=RUNS/'differentiable-view-r1-build-handoff-01'
sha=lambda b:hashlib.sha256(b).hexdigest()
os.umask(0o077);OUT.mkdir(mode=0o700,exist_ok=False)
def info(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink(),str(p)
 return {'bytes':s.st_size,'sha256':sha(p.read_bytes()),'mode':stat.S_IMODE(s.st_mode)}
def pin(p,d):
 r=info(p);assert r['sha256']==d,(str(p),r,d);return r
def verify_archive(a,m):
 ar=info(a);assert ar=={k:m['archive'][k] for k in ('bytes','sha256','mode')}
 de=lzma.LZMADecompressor(format=lzma.FORMAT_XZ);dh=hashlib.sha256();dn=0
 with tempfile.TemporaryFile(dir=OUT) as tmp,a.open('rb') as fi:
  while True:
   compressed=fi.read(65536)
   if not compressed:break
   assert not de.eof
   block=de.decompress(compressed,max_length=1048576)
   while True:
    dh.update(block);dn+=len(block);tmp.write(block)
    if de.eof:
     assert not de.unused_data and not fi.read(1);break
    if de.needs_input:break
    block=de.decompress(b'',max_length=1048576)
   if de.eof:break
  assert de.eof and dn==m['archive']['tar_bytes'] and dh.hexdigest()==m['archive']['tar_sha256']
  tmp.seek(0);seen=set();total=0
  with tarfile.open(fileobj=tmp,mode='r:') as tar:
   for member in tar:
    n=member.name;p=PurePosixPath(n)
    assert member.isfile() and not p.is_absolute() and '..' not in p.parts and str(p)==n and n not in seen and n in m['files']
    f=tar.extractfile(member);h=hashlib.sha256();length=0
    while True:
     b=f.read(65536)
     if not b:break
     h.update(b);length+=len(b)
    got={'bytes':length,'sha256':h.hexdigest(),'mode':member.mode}
    assert got==m['files'][n],(n,got,m['files'][n])
    total+=length;seen.add(n)
 assert seen==set(m['files']) and len(seen)==m['file_count'] and total==m['expanded_bytes']
 return {'file_count':len(seen),'expanded_bytes':total,'single_xz_eof':True,'all_member_bytes_sizes_modes_exact':True,
         'decompressed_tar_bytes':dn,'decompressed_tar_sha256':dh.hexdigest()}
pin(R1/'manifest.json','091db48eb6792b7f6def09c8080e067e22b32dc56243747b37a578669923d42c')
pin(R1/'complete.tar.xz','73d92a8e15b3f5fae7a6e5149227ca05e42d0d19c57c2e61b41a360d2f9c42ed')
r1=json.loads((R1/'manifest.json').read_bytes())
r1verify=verify_archive(R1/'complete.tar.xz',r1)
pin(BUILD/'report.json','20c6d8a6fa1dc4e63c97a6ecddc6a76fe494ae3b0fe12c07d5757a7a1ff15422')
pin(BUILD/'candidate-r2/build.json','e97c4c2c65e0a0f17880f0d41a73281daf0b8badfb39865e3efbe310ccf2972e')
pin(SRC/'source-manifest.json','cfb6053ca9c8c85bccadc3d947ea431bf581a5f71dc254cfaeb6283581b50e9e')
paths={};payload={};origins={};source_map={}
def add_path(name,p):
 assert name not in paths and name not in payload
 q=PurePosixPath(name);assert not q.is_absolute() and '..' not in q.parts
 info(p);paths[name]=p;origins[name]=str(p);source_map[str(p)]=name
def add_tree(prefix,path):
 for p in sorted(path.rglob('*')):
  assert not p.is_symlink(),str(p)
  if p.is_file():add_path(prefix+'/'+p.relative_to(path).as_posix(),p)
  else:assert p.is_dir()
def add_json(name,obj):
 payload[name]=((json.dumps(obj,indent=2,sort_keys=True)+'\n').encode(),0o600)
add_tree('executed/r2-native-build',BUILD)
add_tree('producer-r2',SRC)
for n in ['dview-r2-native-execute-01.py','dview-r2-execution-custody-original.json']:
 add_path('execution-drivers/'+n,RUNS/n)
add_path('parent-r1-packet/manifest.json',R1/'manifest.json')
add_path('parent-r1-packet/verification.json',R1/'verification.json')
add_path('parent-r1-packet/outer-custody.json',R1/'outer-custody.json')
add_path('seal_delta.py',Path(__file__))
old_origin={p:n for n,p in r1['origins'].items()}
inputs=json.loads((BUILD/'inputs-before.json').read_bytes())
child=json.loads((BUILD/'candidate-r2/build.json').read_bytes())
for p,digest in child['inputs_sha256'].items():
 got=info(Path(p));assert got['sha256']==digest
 if p in inputs:assert inputs[p]==got
 inputs[p]=got
bindings={}
for index,(p,expected) in enumerate(sorted(inputs.items())):
 got=info(Path(p));assert got==expected,(p,got,expected)
 if p in source_map:
  bindings[p]={'scope':'THIS_DELTA','member':source_map[p],**got}
 elif p in old_origin:
  name=old_origin[p];assert r1['files'][name]==got,(p,name)
  bindings[p]={'scope':'EXACT_R1_PACKET','manifest_sha256':'091db48eb6792b7f6def09c8080e067e22b32dc56243747b37a578669923d42c','member':name,**got}
 else:
  name='extra-inputs/%04d-'%index+Path(p).name;add_path(name,Path(p))
  bindings[p]={'scope':'THIS_DELTA','member':name,**got}
add_json('input-bindings.json',bindings)
add_json('parent-r1-packet/full-reverification.json',r1verify)
payload['README.md']=(b'''# Direct differentiable view R2 compilation delta

This is a new actual child build; all twelve units and the final ELF were compiled and linked by the unchanged exact b1c/aae tools.
The exact parent09b and the tools are reused from the prior real cold jobs. They were not rebuilt in this invocation.
The original R1 1468-member packet is an explicit immutable prerequisite, not silently copied or relabeled.
input-bindings.json assigns every original absolute input to this delta or the exact R1 manifest member, with bytes, mode and SHA.
Both archive streams were verified through their single XZ EOF and every regular member was compared by size/mode/full SHA.

R2 runtime source197bd52db4815f575ea3e9055d3f5556900314bd2f4fbb262e80cea76ea16ef2
R2 ELF13cee2163e8f62081db35e831885714789ac5117fb80c030a1ccaf7194e0821c
R2 actual build reporte97c4c2c65e0a0f17880f0d41a73281daf0b8badfb39865e3efbe310ccf2972e
Actual job1a1e671a388-392-3b3d exited0, all logs complete;614functions/8090blocks/29094instructions/12units/672bytes.
Independent body comparison retains609 whole R1 bodies exactly. Only four format tags and to_view_refresh changed.
The constructor934c, all general history_capture and arithmetic bodies, original reference14 and R3 comparator remain outside this production patch.

Original R1 runtime failure is preserved separately by the sole native replay owner. This packet preserves compile evidence only.
The compiler build reports retain runtime_qualified=false; native14 evidence is a different executed artifact.
No native target operation or Torch execution is performed by this sealer. No previous failure is reclassified.
''',0o600)
before={n:info(p) for n,p in paths.items()}
files={**before,**{n:{'bytes':len(b),'sha256':sha(b),'mode':mode} for n,(b,mode) in payload.items()}}
archive=OUT/'complete.tar.xz';th=hashlib.sha256();tn=0
class HW:
 def __init__(self,f):self.f=f
 def write(self,b):
  global tn
  th.update(b);tn+=len(b);return self.f.write(b)
 def flush(self):return self.f.flush()
with lzma.open(archive,'wb',preset=3) as xz:
 with tarfile.open(fileobj=HW(xz),mode='w|',format=tarfile.PAX_FORMAT) as tar:
  for n,row in sorted(files.items()):
   ti=tarfile.TarInfo(n);ti.size=row['bytes'];ti.mode=row['mode'];ti.uid=ti.gid=0;ti.mtime=0
   if n in paths:
    with paths[n].open('rb') as f:tar.addfile(ti,f)
   else:tar.addfile(ti,io.BytesIO(payload[n][0]))
manifest={'schema':'heptatorch.direct-view-r2-complete-build-delta.v1','file_count':len(files),
 'expanded_bytes':sum(r['bytes'] for r in files.values()),'files':files,'origins':origins,
 'archive':{'path':'complete.tar.xz',**info(archive),'tar_bytes':tn,'tar_sha256':th.hexdigest()},
 'required_parent_packet':{'manifest_sha256':'091db48eb6792b7f6def09c8080e067e22b32dc56243747b37a578669923d42c',
 'archive_sha256':'73d92a8e15b3f5fae7a6e5149227ca05e42d0d19c57c2e61b41a360d2f9c42ed',
 'repo_path':'validation/differentiable-view-r1-build-history'},
 'all_input_bindings_complete':True,'native_target_executions_by_sealer':0,'Torch_executions_by_sealer':0,
 'self_exclusions':['complete.tar.xz','manifest.json','verification.json']}
verified=verify_archive(archive,manifest)
for n,p in paths.items():assert info(p)==before[n],n
for p,row in inputs.items():assert info(Path(p))==row,p
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
verification={'schema':'heptatorch.direct-view-r2-build-delta-verification.v1','status':'PASS',
 **verified,'archive':manifest['archive'],'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),
 'required_parent_archive_fully_reverified':True,'all_inputs_unchanged':True,
 'native_target_executions':0,'Torch_executions':0}
(OUT/'verification.json').write_text(json.dumps(verification,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':'PASS','directory':str(OUT),'file_count':len(files),'expanded_bytes':manifest['expanded_bytes'],
 'archive':info(archive),'manifest':info(OUT/'manifest.json'),'verification':info(OUT/'verification.json')}),flush=True)
