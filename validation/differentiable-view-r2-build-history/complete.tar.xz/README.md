# Direct differentiable view R2 compilation delta

This is a new actual child build; all twelve units and the final ELF were compiled and linked by the unchanged exact b1c/aae tools.
The exact parent09b and the tools are reused from the prior real cold jobs. They were not rebuilt in this invocation.
The original R1 1468-member packet is an explicit immutable prerequisite, not silently copied or relabeled.
input-bindings.json assigns every original absolute input to this delta or the exact R1 manifest member, with bytes, mode and SHA.
Both archive streams were verified through their single XZ EOF and every regular member was compared by size/mode/full SHA.

R2 runtime source197bd52db4815f575ea3e9055d3f5556900314bd2f4fbb262e80cea76ea16ef2
R2 ELF13cee2163e8f62081db35e831885714789ac5117fb80c030a1ccaf7194e0821c
R2 actual build reporte97c4c2c65e0a0f17880f0d41a73281daf0b8badfb39865e3efbe310ccf2972e
Actual job1a1e671a388-392-3b3d exited0, all logs complete;614functions/8090blocks/29094instructions/12units/672bytes.
Independent body comparison retains609 whole R1 bodies exactly. Only four format tags and to_view_refresh changed.
The constructor934c, all general history_capture and arithmetic bodies, original reference14 and R3 comparator remain outside this production patch.

Original R1 runtime failure is preserved separately by the sole native replay owner. This packet preserves compile evidence only.
The compiler build reports retain runtime_qualified=false; native14 evidence is a different executed artifact.
No native target operation or Torch execution is performed by this sealer. No previous failure is reclassified.
