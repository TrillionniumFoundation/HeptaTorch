#!/usr/bin/python3
"""One explicit R3 qualification execution; source expectations stay frozen."""
import argparse,hashlib,json,subprocess,sys,time
from pathlib import Path
B=Path('/home/qian-qi/heptatorch-continuation-20261116')
RUN=B/'runs'
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
def write(p,value):
    p.write_text(json.dumps(value,indent=2)+'\n')
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--suite',choices=('input4','original14'),required=True)
    ap.add_argument('--build',type=Path,required=True)
    ap.add_argument('--expected-native-sha256',required=True)
    ap.add_argument('--expected-build-sha256',required=True)
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args()
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
    author=RUN/'differentiable-view-recovered-source-03'
    source=a.build/'runtime.hepta'
    binary=a.build/'tensor-differentiable-view-session'
    buildpath=a.build/'build.json'
    observer=author/'native_observer_direct03.py'
    protocol=RUN/'to09b-full35-614-01/execution/fixtures/protocol.py'
    if a.suite=='input4':
        directory=RUN/'differentiable-view-input-boundaries-reader-02'
        reader=directory/'replay_input_boundaries4.py'
        readerpin='5b8809eb9e405bf89a3586741d64210483fe3fbc5bc323e2cc16cb712ce4de66'
        reference=RUN/'differentiable-view-input-boundaries-04-20261116/actual.json'
        probe=reference.with_name('pytorch_differentiable_view_input_boundaries_probe.py')
        extra=['--support-reader',str(directory/'actual14_reader_support.py'),
               '--expected-reference-sha256','f4abe6a750ecc791b3a7bc7aa507b4c77eb0a2fcccf45b0c6a828db0e01490d3']
    else:
        reader=RUN/'to-view-recovery-integration-01/repo/tests/differentiable_view_input4_review/replay_direct_view14_profile.py'
        readerpin='deb9f6fafc3f91b2749bdfac030e19cb0ccdb832fa238af91ed9feb396e62eb8'
        reference=RUN/'differentiable-view14-packet-02/payload/original/actual.json'
        probe=reference.parent/'inputs/differentiable-view14-probe-1ca74384.py'
        extra=[]
    pins={
      reader:readerpin,
      source:'3c2c0a125bcac6d47075bf58fc3f78c0e7b9a0b1370757981b99dcd3793b21c6',
      binary:a.expected_native_sha256,buildpath:a.expected_build_sha256,
      observer:'68d0f4657c6cc7062d98cbf033565b16c7b51f3381c6490247e42512c5baf4a2',
      protocol:'7a30d7bca140e3a4cc9d63a3e6930b92d2ffd60ad4503895419d8a63e67c8bd9',
      protocol.with_name('owner_client.py'):'dee3e4cb25ee1e5e06513e2f33478fbe274d9510ce2aaab9525815c72312946b',
      author/'source-manifest.json':'048bdfbda2bd71486faaa98a89b70d5f41dfa48e8fd8ae2ad7a344420dded77b',
    }
    for p,pin in list(pins.items()):assert SHA(p.read_bytes())==pin,(p,SHA(p.read_bytes()),pin)
    build=json.loads(buildpath.read_bytes())
    assert build['status']=='PASS' and build['functions']==627 and len(build['units'])==13
    assert build['source_sha256']==pins[source] and build['native_sha256']==pins[binary]
    for unit in build['units']:
        assert unit['compiler_exit']==0
        pins[a.build/(unit['name']+'.hepta')]=unit['source_sha256']
        pins[a.build/(unit['name']+'.o')]=unit['object_sha256']
    manifest=json.loads((author/'source-manifest.json').read_bytes())
    for row in manifest['files']:pins[author/row['path']]=row['sha256']
    pins[reference]=SHA(reference.read_bytes())
    pins[probe]=SHA(probe.read_bytes())
    pins[Path(__file__).resolve()]=SHA(Path(__file__).read_bytes())
    if a.suite=='input4':
        pins[directory/'actual14_reader_support.py']='52c3b3242a73fb412102c83c5ba47cf8d95a4eb3c01e56f41bfe593066506d05'
    for p,pin in pins.items():assert SHA(p.read_bytes())==pin,(p,SHA(p.read_bytes()),pin)
    cmd=[sys.executable,'-B',str(reader),'--binary',str(binary),'--source',str(source),
         '--build-report',str(buildpath),'--protocol',str(protocol),'--observer',str(observer),
         '--reference',str(reference),'--probe',str(probe),'--output',str(out/'observed'),
         '--expected-source-sha256',pins[source],'--expected-native-sha256',pins[binary],
         '--expected-observer-sha256',pins[observer],'--expected-functions','627',
         '--expected-native-units','13']+extra
    execution={'schema':'heptatorch.direct-view-r3-execution.v1','suite':a.suite,'argv':cmd,
      'inputs_sha256':{str(p):pin for p,pin in pins.items()},
      'inputs_modes':{str(p):p.stat().st_mode&0o777 for p in pins},
      'native_child_started':False,'native_child_completed':False}
    write(out/'execution.json',execution)
    write(out/'command.json',cmd)
    start=time.time()
    with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
        execution['native_child_started']=True
        write(out/'execution.json',execution)
        try:
            child=subprocess.run(cmd,cwd=str(B),stdout=stdout,stderr=stderr,timeout=1200)
            execution.update(native_child_completed=True,exit_code=child.returncode)
        except BaseException as error:
            execution.update(host_error=repr(error))
            raise
        finally:
            execution['wall_seconds']=time.time()-start
            execution['all_inputs_unchanged']=all(SHA(p.read_bytes())==pin for p,pin in pins.items())
            write(out/'execution.json',execution)
    for name in ('stdout.log','stderr.log'):
        execution[name+'_sha256']=SHA((out/name).read_bytes())
    reportpath=out/'observed/report.json'
    if reportpath.is_file():
        report=json.loads(reportpath.read_bytes())
        execution['report_sha256']=SHA(reportpath.read_bytes())
        execution['report_status']=report['status']
        execution['summary']={k:report[k] for k in ('status','cases','passed_cases','failed_cases','frames','assertions','exact_words','full_rng_bytes','rollback_bytes','all_sessions_eof_exit_zero') if k in report}
    write(out/'execution.json',execution)
    print(json.dumps({k:v for k,v in execution.items() if k not in ('argv','inputs_sha256','inputs_modes')},indent=2))
    raise SystemExit(execution['exit_code'] if execution['all_inputs_unchanged'] else 97)
if __name__=='__main__':
    main()
