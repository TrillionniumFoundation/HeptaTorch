#!/usr/bin/env python3
"""Read original integer CI artifacts. Never launch HIA, a compiler, or PyTorch."""
import argparse
import ast
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import random
import re
import stat
import struct
import traceback
import zipfile

REPOSITORY = 'TrillionniumFoundation/HeptaTorch'
COMPILER = '87c247e4d1c3c9a449d2947fd4227fdc186d519bffd203a04cafce7861a4ed54'
TOOLCHAIN = 'f33d8da316de8fdf27b504371f1a5310997ff548'
COMPILER_SOURCE = '388b182e42675f11435867dd99520e9452a4ff48e23c0766a3952b662acc7627'
SUPPORT = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
INVENTORY = '31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457'
HEAD64 = '0fd81b279c97dd969071c9efc51c8202fc16e45b'
HEAD8 = '214f6c232ae8b471ac9537bac2aa21fa0df3be1b'
OLD8 = 'c812c1c888d05f7710da58a28d6ee47558669cc4'
BASE_OLD = 'dcb903ccbb679497f4c7fa3c413dc0f6d19340ef'
BASE_28 = '7e7e37be38457d88f214d45f261924983dc96b56'
PROFILES = {
    'i64': {
        'head': HEAD64, 'tree': '57b754d41960e16f483046bab36f694a8c0491d9',
        'kernel': '251705542f4e117e3c9cdaec36cead8ab38252b24ebfef1104d765c546fd0716',
        'oracle': 'ed7ad57e5cf8c95198661a9aabcbf848b644dd7a63c14d0bf627bfc70bdd7761',
        'workflow': 'f74b7e3ac880c18246c517f0ea8bc21edf88c8613b95996a0415c17b96da5c61',
        'elf': 'fbb6cf1648385be200c94fc14ed73d1539cba3b0239aeea4f7866058c8395ebc',
        'run': 43851296835, 'job': 133244226312, 'artifact': 14218775358,
        'zip_sha': 'c7683a60421afc40a4df4d97a80fc1935d96b2676f2fa564e0504648d9f2e0ae',
        'zip_bytes': 10383, 'checkout': 'd993a99ee5cc83e8f186b96958b9df165f838296',
        'base': BASE_OLD, 'rows': 33, 'values': 351174,
    },
    'i8': {
        'head': HEAD8, 'tree': '7aa4475461787e00d382e5d0c179c1eb964a18eb',
        'kernel': '7ca1765e2cede95ec19b64742f69816581733619b5b1b844f57aa72b743ed8d3',
        'oracle': '0a75c065d9b520c4d3a3949dec09650e972725af09295176101562af92b8c6ec',
        'workflow': 'fe76343d9a04fa595be2d20a88e87d8ecd7f880def89cc1afbf05cd8619e1f28',
        'elf': 'eba8c05bfe514c38ffa1a5e1ccbc9aacd513531f74becd18f4e3dca73db0a0b1',
        'run': 43878602383, 'job': 133338132847, 'artifact': 14230882971,
        'zip_sha': 'c61ca3acecf56ab00b23cbc5b32ab27e4974f4ccf59c846036d5d13dc891a15e',
        'zip_bytes': 9257, 'checkout': '07c3071d21108f659874c9dd2debe4e0a1038e83',
        'checkout_tree': '1c7cb0087ea020b609bdc22c67b29938b11304c7',
        'base': BASE_28, 'rows': 28, 'values': 1093216,
    },
}
PUSH8 = {'run': 43878592238, 'job': 133338098716, 'artifact': 14231167849,
         'zip_sha': '55e30b07e3e5e536b1f90cc35ef97e9927f7bf7ee63e61a562aa9f9fba43f39b',
         'zip_bytes': 9255, 'checkout': HEAD8,
         'checkout_tree': '7aa4475461787e00d382e5d0c179c1eb964a18eb'}
PROVENANCE_NAMES = {
    'python_matches', 'platform_matches', 'version_backend_matches',
    'git_matches_oracle_build_pin', 'distribution_version_matches',
    'direct_url_matches', 'direct_url_archive_sha256_matches',
    'pip_report_url_matches', 'pip_report_archive_sha256_matches',
    'pip_report_version_matches', 'pip_report_requested',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


class Review:
    def __init__(self, root):
        self.root = root
        self.checks = []
        self.loaded = {}

    def check(self, name, condition, observed=None):
        good = condition is True
        self.checks.append({'name': name, 'passed': good, 'observed': observed})
        if not good:
            raise AssertionError(name + ': ' + repr(observed))

    def eq(self, name, actual, expected):
        def shown(value):
            if isinstance(value, bytes):
                return {'bytes': len(value), 'sha256': sha(value)}
            return value
        self.check(name, type(actual) is type(expected) and actual == expected,
                   {'actual': shown(actual), 'expected': shown(expected)})

    def read(self, relative):
        path = self.root / relative
        data = path.read_bytes()
        now = {'bytes': len(data), 'sha256': sha(data)}
        if str(relative) in self.loaded:
            self.eq('repeated-input-unchanged/' + str(relative), now, self.loaded[str(relative)])
        else:
            self.loaded[str(relative)] = now
        return data

    def doc(self, relative):
        return json.loads(self.read(relative))

    def source(self, profile, kind):
        return self.read('official/' + profile + '-' + kind + '-contents.source')


def original_zip(review, name, spec):
    raw = review.read(name + '.zip')
    review.eq(name + '/zip-bytes', len(raw), spec['zip_bytes'])
    review.eq(name + '/zip-sha', sha(raw), spec['zip_sha'])
    found = {}
    with zipfile.ZipFile(review.root / (name + '.zip')) as z:
        review.eq(name + '/zip-crc', z.testzip(), None)
        for member in z.infolist():
            p = PurePosixPath(member.filename)
            review.check(name + '/safe-member/' + member.filename,
                         not p.is_absolute() and '..' not in p.parts and '\\' not in member.filename
                         and not member.is_dir() and not stat.S_ISLNK(member.external_attr >> 16)
                         and member.filename not in found)
            data = z.read(member)
            review.eq(name + '/member-size/' + member.filename, len(data), member.file_size)
            review.eq(name + '/expanded-copy/' + member.filename,
                      review.read('artifacts/' + name + '/' + member.filename), data)
            found[member.filename] = data
    return found


def corpus64():
    mask = (1 << 64) - 1
    values = [0, 1, 2, 3, 7, 255, 256, 1024, (1 << 16) - 1, 1 << 16,
              (1 << 31) - 1, 1 << 31, (1 << 32) - 1, 1 << 32,
              (1 << 53) - 1, 1 << 53, (1 << 63) - 1, 1 << 63, mask, mask - 1, mask - 2,
              0x5555555555555555, 0xaaaaaaaaaaaaaaaa]
    edges = [(a, b) for a in values for b in values]
    for mode in range(6):
        yield 'empty-mode-' + str(mode), mode, []
        yield 'edge-product-mode-' + str(mode), mode, edges
        rng = random.Random(192830 + mode * 19)
        yield '10k-random-mode-' + str(mode), mode, [(rng.getrandbits(64), rng.getrandbits(64)) for _ in range(10000)]
        yield '48k-boundary-mode-' + str(mode), mode, [
            (rng.getrandbits(64), rng.getrandbits(64)) if i % 13 else edges[i % len(edges)] for i in range(48000)]


def corpus8():
    exhaustive = [(a, b) for a in range(256) for b in range(256)]
    for mode in range(6):
        yield 'empty-' + str(mode), mode, []
        yield 'exhaustive-' + str(mode), mode, exhaustive
        rng = random.Random(20261116 + mode * 1009)
        yield '100k-random-' + str(mode), mode, [(rng.randrange(256), rng.randrange(256)) for _ in range(100000)]
    rng = random.Random(836485)
    yield '100k-admission-boundary', 2, [(rng.randrange(256), rng.randrange(256)) for _ in range(100000)]


def packet(profile, mode, pairs):
    payload = b''.join(struct.pack('<QQ', a, b) for a, b in pairs) if profile == 'i64' else bytes(v for pair in pairs for v in pair)
    return struct.pack('<II', mode, len(pairs)) + payload


def expected(profile):
    mask = (1 << (64 if profile == 'i64' else 8)) - 1
    output = []
    for name, mode, pairs in (corpus64() if profile == 'i64' else corpus8()):
        values = [((a + b, a - b, a * b, a & b, a | b, a ^ b)[mode] & mask) for a, b in pairs]
        payload = b''.join(struct.pack('<Q', value) for value in values) if profile == 'i64' else bytes(values)
        output.append({'case': name, 'mode': mode, 'count': len(pairs), 'compared_values': len(pairs),
                       'input_sha256': sha(packet(profile, mode, pairs)),
                       'response_sha256': sha(bytes(4) + payload), 'reference_sha256': sha(payload)})
    if profile == 'i64':
        refused = [('short-header', bytes(7)), ('unknown-mode', struct.pack('<II', 6, 0)),
                   ('u32-mode', struct.pack('<II', 0xffffffff, 0)),
                   ('truncated-pair', struct.pack('<II', 0, 1) + bytes(15)),
                   ('count-too-large', struct.pack('<II', 1, 48001)),
                   ('count-max', struct.pack('<II', 0, 0xffffffff)),
                   ('payload-after-empty', struct.pack('<II', 2, 0) + b'X'),
                   ('payload-after-pair', packet(profile, 3, [(1, 2)]) + b'X'),
                   ('wrong-count', struct.pack('<II', 4, 2) + struct.pack('<QQ', 3, 4))]
    else:
        refused = [('short-header', bytes(7)), ('unknown-mode', struct.pack('<II', 6, 0)),
                   ('mode-fmax', struct.pack('<II', 0xffffffff, 0)),
                   ('count-over', struct.pack('<II', 0, 100001)), ('count-u32max', struct.pack('<II', 0, 0xffffffff)),
                   ('truncated-pair', struct.pack('<II', 0, 1) + bytes(1)),
                   ('trailing-empty', struct.pack('<II', 1, 0) + b'x'),
                   ('trailing-pair', packet(profile, 2, [(0, 255)]) + b'x'),
                   ('count-mismatch', struct.pack('<II', 0, 2) + bytes(2))]
    for name, raw in refused:
        output.append({'case': 'refuse-' + name, 'input_sha256': sha(raw), 'response_sha256': sha(b'\x01\0\0\0')})
    return output


def provenance(review, label, actual, lock):
    prefix = label + '/provenance/'
    review.eq(prefix + 'keys', sorted(actual), sorted(['status', 'lock_path', 'lock_sha256', 'expected', 'observed', 'checks', 'metadata_error', 'release_source_equivalence']))
    review.eq(prefix + 'status', actual['status'], 'PASS')
    review.eq(prefix + 'lock-sha', actual['lock_sha256'], LOCK)
    review.eq(prefix + 'lock-basename', Path(actual['lock_path']).name, 'pytorch-oracle-lock.json')
    review.eq(prefix + 'expected-entire-object', actual['expected'], lock['oracle'])
    review.eq(prefix + 'source-equivalence-entire-object', actual['release_source_equivalence'], lock['release_source_equivalence'])
    review.eq(prefix + 'check-names', sorted(actual['checks']), sorted(PROVENANCE_NAMES))
    for key, value in actual['checks'].items():
        review.check(prefix + key, value is True)
    review.eq(prefix + 'metadata-error', actual['metadata_error'], None)
    observed = actual['observed']; expected_oracle = lock['oracle']
    review.eq(prefix + 'observed-keys', sorted(observed), sorted(['python', 'platform', 'version', 'git_commit', 'backend_versions', 'distribution_version', 'direct_url', 'install_report']))
    for key in ('version', 'git_commit', 'backend_versions', 'platform'):
        review.eq(prefix + 'actual-' + key, observed[key], expected_oracle[key])
    review.eq(prefix + 'actual-python-implementation', observed['python']['implementation'], expected_oracle['python']['implementation'])
    review.eq(prefix + 'actual-python-version', observed['python']['version'], expected_oracle['python']['version'])
    review.eq(prefix + 'actual-distribution-version', observed['distribution_version'], expected_oracle['version'])
    wheel = expected_oracle['wheel']
    expected_archive = {'hash': 'sha256=' + wheel['sha256'], 'hashes': {'sha256': wheel['sha256']}}
    review.eq(prefix + 'actual-direct-url', observed['direct_url'], {'url': wheel['url'], 'archive_info': expected_archive})
    pip = observed['install_report']
    review.eq(prefix + 'pip-path', pip['path'], expected_oracle['install_report'])
    review.eq(prefix + 'pip-download-info', pip['download_info'], {'url': wheel['url'], 'archive_info': expected_archive})
    review.eq(prefix + 'pip-name', pip['metadata_name'], 'torch')
    review.eq(prefix + 'pip-version', pip['metadata_version'], expected_oracle['version'])
    review.check(prefix + 'pip-requested', pip['requested'] is True)


def inspect_source(review, profile):
    spec = PROFILES[profile]
    for kind, pin in [('kernel', spec['kernel']), ('oracle', spec['oracle']), ('workflow', spec['workflow']), ('support', SUPPORT), ('lock', LOCK)]:
        data = review.source(profile, kind)
        review.eq(profile + '/source/' + kind, sha(data), pin)
        if kind == 'oracle':
            ast.parse(data)
    workflow = review.source(profile, 'workflow').decode()
    oracle = review.source(profile, 'oracle').decode()
    for text in (TOOLCHAIN, COMPILER, COMPILER_SOURCE, "for label in ('B1','B2','B3')", "image_format='seed-shared' if label=='B1' else 'flat-x86-64'"):
        review.check(profile + '/compiler-workflow/' + text, text in workflow)
    for text in ("env={'PATH':''}", 'capture_output=True', 'runpy.run_path', "torch.set_num_threads(1)", "raise SystemExit(main())", 'traceback.format_exc'):
        review.check(profile + '/oracle-required-source/' + text, text in oracle)
    if profile == 'i64':
        for text in ('assert binary[0]==binary[1] and SHA(binary[0])==IMAGE_SHA', "assert run.returncode==0 and not run.stderr", 'raw_actual!=raw_expected', "len(rows)==33", "len(set(r['case'] for r in rows))==33", 'and unchanged'):
            review.check(profile + '/strict-source/' + text, text in oracle)
        review.check(profile + '/compiler-self-reproduction-2', "for i in range(2):" in workflow and 'p.stdout==compiler.read_bytes()' in workflow)
    else:
        for text in ('assert images[0]==images[1]', 'assert not a.expected_elf_sha256 or SHA(images[0])==a.expected_elf_sha256', 'assert actual==bytes(4)+expected', 'len(rows)==28', 'and exe.read_bytes()==images[0]', 'SHA(compiler.read_bytes())==COMPILER_SHA'):
            review.check(profile + '/strict-source/' + text, text in oracle)
        review.eq(profile + '/two-explicit-image-pins', workflow.count('--expected-elf-sha256 ' + spec['elf']), 2)
        old = review.read('legacy-source/30/.github/workflows/native-i8.yml')
        marker = b'      - name: Execute real PyTorch byte exact differential and 11 provenance checks\n        run: |\n          python3 -I -S -B tests/i8_oracle.py'
        review.eq(profile + '/old-torch-command-unique', old.count(marker), 1)
        new = marker.replace(b'python3 -I -S -B', b'python3 -B')
        review.eq(profile + '/workflow-exact-one-command-inverse', review.source(profile, 'workflow').replace(new, marker, 1), old)
        for kind, filename in [('oracle', 'tests/i8_oracle.py'), ('kernel', 'tools/native-i8/i8_elementwise.hepta')]:
            review.eq(profile + '/unchanged-old-' + kind, review.source(profile, kind), review.read('legacy-source/30/' + filename))
    return json.loads(review.source(profile, 'lock'))


def check_report(review, label, profile, reference, raw, want_rows, lock):
    r = json.loads(raw); spec = PROFILES[profile]
    prefix = label + '/' + reference + '/'
    review.eq(prefix + 'status', r['status'], 'PASS')
    review.eq(prefix + 'reference', r['reference'], reference)
    review.eq(prefix + 'source-pin', r['source_sha256'], spec['kernel'])
    review.eq(prefix + 'compiler-pin', r['compiler_sha256'], COMPILER)
    review.eq(prefix + 'inventory-pin', r['upstream_commit'], INVENTORY)
    review.eq(prefix + 'oracle-pin', r['oracle_script_sha256' if profile == 'i64' else 'oracle_source_sha256'], spec['oracle'])
    review.eq(prefix + 'native-image-pin', r['native_elf_sha256' if profile == 'i64' else 'executable_sha256'], spec['elf'])
    review.eq(prefix + 'reported-count', r['tests' if profile == 'i64' else 'cases'], spec['rows'])
    review.eq(prefix + 'zero-failures', r['failed_tests' if profile == 'i64' else 'failed_cases'], 0)
    review.eq(prefix + 'total-compared', r['compared_values'], spec['values'])
    identical = r['native_compilations_byte_identical' if profile == 'i64' else 'two_independent_compiler_invocations_identical']
    review.check(prefix + 'two-actual-compilations-identical', identical is True)
    if profile == 'i64':
        review.check(prefix + 'source-compiler-image-unchanged', r['producer_and_elf_unchanged'] is True)
    else:
        review.check(prefix + 'not-full-rewrite', r['full_rewrite_complete'] is False)
        review.eq(prefix + 'schema-denominator', r['pytorch_schema_denominator'], 2590)
        review.eq(prefix + 'gates-closed', r['full_system_gates_closed'], 0)
    rows = r['rows']
    review.eq(prefix + 'actual-row-count', len(rows), len(want_rows))
    review.eq(prefix + 'exact-ordered-case-plan', [x['case'] for x in rows], [x['case'] for x in want_rows])
    review.eq(prefix + 'distinct-names', len({x['case'] for x in rows}), spec['rows'])
    for row, expected_row in zip(rows, want_rows):
        tag = prefix + row['case'] + '/'
        review.eq(tag + 'status', row['status'], 'PASS')
        review.check(tag + 'no-error-fields', not ({'error', 'traceback', 'reference_crosscheck_errors', 'reference_disagreements'} & set(row)))
        for key, value in expected_row.items():
            actual_key = {'response_sha256': 'output_sha256', 'reference_sha256': 'expected_sha256'}.get(key, key) if profile == 'i8' else key
            review.eq(tag + actual_key, row[actual_key], value)
        if 'mismatches' in row:
            review.eq(tag + 'no-mismatches', row['mismatches'], [])
    review.eq(prefix + 'sum-all-counts', sum(x.get('count', 0) for x in rows), spec['values'])
    review.eq(prefix + 'sum-all-compared', sum(x.get('compared_values', 0) for x in rows), spec['values'])
    observed = r['oracle_provenance' if profile == 'i64' else 'provenance']
    if reference == 'pytorch':
        provenance(review, prefix.rstrip('/'), observed, lock)
    else:
        review.eq(prefix + 'no-Torch-used-as-CPython', observed, None)
    return r


def audit_run(review, label, profile, spec, lock, wanted):
    run = review.doc('official/' + label + '-run.json')
    jobs = review.doc('official/' + label + '-jobs.json')
    artifacts = review.doc('official/' + label + '-artifacts.json')
    review.eq(label + '/run-id', run['id'], spec['run'])
    review.eq(label + '/run-head', run['head_sha'], spec['head'])
    review.eq(label + '/source-head-tree', run['head_commit']['tree_id'], spec['tree'])
    review.eq(label + '/run-status', (run['status'], run['conclusion']), ('completed', 'success'))
    review.eq(label + '/repository', run['repository']['full_name'], REPOSITORY)
    review.eq(label + '/event', run['event'], 'push' if label.endswith('-push') else 'pull_request')
    review.eq(label + '/attempt', run['run_attempt'], 1)
    review.eq(label + '/workflow-path', run['path'], '.github/workflows/native-' + profile + '.yml')
    review.eq(label + '/one-job-total', jobs['total_count'], 1)
    review.eq(label + '/one-job-present', len(jobs['jobs']), 1)
    job = jobs['jobs'][0]
    for key, value in [('id', spec['job']), ('run_id', spec['run']), ('head_sha', spec['head']), ('run_attempt', 1), ('status', 'completed'), ('conclusion', 'success')]:
        review.eq(label + '/job-' + key, job[key], value)
    steps = job['steps']
    review.eq(label + '/12-actual-steps', len(steps), 12)
    review.eq(label + '/step-number-order', [x['number'] for x in steps], sorted({x['number'] for x in steps}))
    for s in steps:
        review.eq(label + '/step/' + s['name'], (s['status'], s['conclusion']), ('completed', 'success'))
    workflow = review.source(profile, 'workflow').decode()
    names = re.findall(r'^      - name: (.*)$', workflow, re.M)
    review.eq(label + '/all-declared-named-steps-in-order', [s['name'] for s in steps if s['name'] in names], names)
    review.eq(label + '/one-original-artifact-total', artifacts['total_count'], 1)
    review.eq(label + '/one-original-artifact-present', len(artifacts['artifacts']), 1)
    artifact = artifacts['artifacts'][0]
    for key, value in [('id', spec['artifact']), ('size_in_bytes', spec['zip_bytes']), ('digest', 'sha256:' + spec['zip_sha']), ('expired', False)]:
        review.eq(label + '/artifact-' + key, artifact[key], value)
    review.eq(label + '/artifact-name', artifact['name'], 'native-' + profile + '-evidence')
    review.eq(label + '/artifact-run', artifact['workflow_run']['id'], spec['run'])
    review.eq(label + '/artifact-head', artifact['workflow_run']['head_sha'], spec['head'])
    review.check(label + '/artifact-created-in-this-attempt', run['run_started_at'] <= artifact['created_at'] <= run['updated_at'])
    files = original_zip(review, label, spec)
    folder = 'i64' if profile == 'i64' else 'native-i8'
    expected_members = sorted([folder + '-custody.json'] + [folder + '-' + r + '/report.json' for r in ('cpython', 'pytorch')])
    review.eq(label + '/exact-3-member-set', sorted(files), expected_members)
    custody = json.loads(files[folder + '-custody.json'])
    review.eq(label + '/actual-checkout', custody['head' if profile == 'i64' else 'checkout_sha'], spec['checkout'])
    review.eq(label + '/actual-checkout-tree', custody['tree' if profile == 'i64' else 'checkout_tree'], spec.get('checkout_tree', spec['tree']))
    for field, value in ({'source_sha256': spec['kernel'], 'reference_sha256': spec['oracle'], 'torch_lock_sha256': LOCK, 'compiler_sha256': COMPILER}
                         if profile == 'i64' else {'source_sha': spec['kernel'], 'oracle_sha': spec['oracle'], 'lock_sha': LOCK, 'compiler_sha': COMPILER}).items():
        review.eq(label + '/custody-' + field, custody[field], value)
    log = review.read('official/' + label + '-job.log').decode()
    log = re.sub(r'\x1b\[[0-9;]*m', '', log)
    review.check(label + '/log-checkout', spec['checkout'] in log)
    review.check(label + '/log-toolchain-checkout', TOOLCHAIN in log)
    review.check(label + '/log-no-python-optimized-mode', 'PYTHONOPTIMIZE' not in log and 'python3 -O' not in log)
    review.check(label + '/compiler-success-output', ('PASS native HIA compiler reproduction' if profile == 'i64' else 'Pinned native compiler reproduced') in log)
    actual_json_output = []
    for line in log.splitlines():
        line = re.sub(r'^\d{4}-\d{2}-\d{2}T[^ ]+ ', '', line)
        if line.startswith('{'):
            try:
                actual_json_output.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    review.check(label + '/printed-custody-exact', custody in actual_json_output)
    reports = {}
    for reference in ('cpython', 'pytorch'):
        raw = files[folder + '-' + reference + '/report.json']
        reported_sha = custody['reports'][reference] if profile == 'i64' else custody['cpython_report_sha' if reference == 'cpython' else 'torch_report_sha']
        review.eq(label + '/' + reference + '/original-report-sha', sha(raw), reported_sha)
        report = check_report(review, label, profile, reference, raw, wanted, lock)
        summary = {k: v for k, v in report.items() if k not in ('rows', 'oracle_provenance', 'provenance')}
        review.check(label + '/' + reference + '/original-log-summary-exact', summary in actual_json_output)
        reports[reference] = report
    review.eq(label + '/both-reference-identical-per-case-outcomes', reports['cpython']['rows'], reports['pytorch']['rows'])
    review.eq(label + '/separate-provenance-file-not-required-on-success', custody['provenance_report_sha256' if profile == 'i64' else 'torch_provenance_sha'], None)
    return {'profile': profile, 'run_id': spec['run'], 'job_id': spec['job'], 'attempt': 1,
            'source_head': spec['head'], 'checkout': spec['checkout'], 'checkout_tree': spec.get('checkout_tree', spec['tree']),
            'actual_steps': 12, 'cases_per_reference': spec['rows'], 'values_per_reference': spec['values'],
            'references': ['independent CPython', 'locked real PyTorch'], 'provenance_checks': 11,
            'image_sha256': spec['elf'], 'artifact_sha256': spec['zip_sha']}


def history(review):
    repair = review.doc('official/i8-repair-commit.json')
    review.eq('repair/head', repair['sha'], HEAD8)
    review.eq('repair/parent', [x['sha'] for x in repair['parents']], [OLD8])
    changed = repair['files']
    review.eq('repair/exact-change-count', len(changed), 10)
    review.eq('repair/only-one-existing-file-modified', [x['filename'] for x in changed if x['status'] != 'added'], ['.github/workflows/native-i8.yml'])
    for row in changed:
        if row['status'] == 'added':
            review.check('repair/all-additions-are-original-failure-custody/' + row['filename'], row['filename'].startswith('validation/native-i8-first-hosted-failure/c812/'))
            raw = review.read('i8-original-failure.zip') if row['filename'].endswith('original-artifact.zip') else review.read('source-repair/' + row['filename'])
            review.eq('repair/committed-original-git-blob/' + row['filename'], blob(raw), row['sha'])
    old_spec = {'zip_bytes': 4645, 'zip_sha': 'd56a7c9610ef929a2fe1f674208786c8d1050ba117e925ccdf3574a8d0ffef80'}
    files = original_zip(review, 'i8-original-failure', old_spec)
    review.eq('old-failure/exact-set', sorted(files), sorted(['native-i8-custody.json', 'native-i8-cpython/report.json', 'native-i8-pytorch/provenance.json']))
    run = review.doc('official/i8-original-run.json')
    jobs = review.doc('official/i8-original-jobs.json')
    review.eq('old-failure/run', run['id'], 43865611996)
    review.eq('old-failure/head', run['head_sha'], OLD8)
    review.eq('old-failure/conclusion', run['conclusion'], 'failure')
    review.eq('old-failure/job', jobs['jobs'][0]['id'], 133293258942)
    review.eq('old-failure/exact-failed-step', [s['name'] for s in jobs['jobs'][0]['steps'] if s['conclusion'] == 'failure'], ['Execute real PyTorch byte exact differential and 11 provenance checks'])
    prov = json.loads(files['native-i8-pytorch/provenance.json'])
    review.eq('old-failure/not-run-retained', prov['status'], 'NOT_RUN')
    review.eq('old-failure/import-reason', prov['reason'], "No module named 'torch'")
    old_custody = json.loads(files['native-i8-custody.json'])
    review.eq('old-failure/no-Torch-report', old_custody['torch_report_sha'], None)
    review.eq('old-failure/provenance-original-sha', old_custody['torch_provenance_sha'], sha(files['native-i8-pytorch/provenance.json']))
    review.eq('old-failure/CPython-still-original', files['native-i8-cpython/report.json'], review.read('artifacts/i8/native-i8-cpython/report.json'))
    old_commit = review.doc('official/i8-original-checkout.json')
    review.eq('old-failure/checkout', old_commit['sha'], old_custody['checkout_sha'])
    review.eq('old-failure/tree', old_commit['tree']['sha'], old_custody['checkout_tree'])
    review.eq('old-failure/parents', [x['sha'] for x in old_commit['parents']], [BASE_OLD, OLD8])
    original_log = review.read('source-repair/validation/native-i8-first-hosted-failure/c812/original-job.log').decode()
    review.check('old-failure/user-site-install-actually-recorded', 'Defaulting to user installation because normal site-packages is not writeable' in original_log)
    review.check('old-failure/import-failure-actually-recorded', "No module named 'torch'" in original_log)
    review.check('old-failure/isolated-Torch-launch-recorded', 'python3 -I -S -B tests/i8_oracle.py' in original_log)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bundle', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    review = Review(args.bundle.resolve())
    result = {'schema': 'heptatorch.integer-original-hosted-review.v1', 'status': 'FAIL',
              'scoped_original_evidence_admitted': False, 'merged_current_main_validated': False,
              'native_or_torch_executions_by_reviewer': 0, 'full_rewrite_complete': False,
              'full_schema_parity': {'qualified': 0, 'total': 2590}, 'whole_program_decision': 'HOLD'}
    try:
        scopes = []
        for profile in ('i64', 'i8'):
            spec = PROFILES[profile]
            source = review.doc('official/' + profile + '-source.json')
            checkout = review.doc('official/' + profile + '-checkout.json')
            review.eq(profile + '/source-head', source['sha'], spec['head'])
            review.eq(profile + '/source-tree', source['tree']['sha'], spec['tree'])
            review.eq(profile + '/source-parent', [x['sha'] for x in source['parents']], [BASE_OLD if profile == 'i64' else OLD8])
            review.eq(profile + '/merge-checkout-sha', checkout['sha'], spec['checkout'])
            review.eq(profile + '/merge-tree', checkout['tree']['sha'], spec.get('checkout_tree', spec['tree']))
            review.eq(profile + '/merge-parents', [x['sha'] for x in checkout['parents']], [spec['base'], spec['head']])
            lock = inspect_source(review, profile)
            wanted = expected(profile)
            scopes.append(audit_run(review, profile, profile, spec, lock, wanted))
            if profile == 'i8':
                scopes.append(audit_run(review, 'i8-push', profile, {**spec, **PUSH8}, lock, wanted))
        history(review)
        for filename, record in review.loaded.items():
            raw = (review.root / filename).read_bytes()
            review.check('final-input-unchanged/' + filename, len(raw) == record['bytes'] and sha(raw) == record['sha256'])
        result.update(status='PASS_SCOPED_ORIGINAL_HOSTED_EVIDENCE', scoped_original_evidence_admitted=True,
                      scopes=scopes,
                      original_failure={'status': 'NOT_RUN_IMPORT_FAILURE_PRESERVED', 'run_id': 43865611996, 'head': OLD8},
                      boundaries=[
                          'Original ZIPs contain reports and custody records, not ELF/compiler files or raw per-case streams. Exact execution identities are bound by unchanged pinned source, executed workflow assertions, successful official jobs/logs and original report hashes. No fresh byte verification of unavailable binaries is claimed.',
                          'All reported request/expected-response hashes were independently reconstructed from fixed exact integer corpora offline; this is not a new native or PyTorch execution.',
                          'The complete original pip-install file is not an artifact member. Embedded original provenance and its eleven executed gates are checked against the exact lock; no locally downloaded wheel identity is claimed.',
                          'PR29 ran against dcb903 and PR30 against the recorded 7e7e37 merge checkout. Neither is qualification of the newer retained446 main tree or a combined int64/int8 tree.',
                          'These are bounded contiguous standalone integer packet operations. General Tensor dtype dispatch, shapes, broadcasting, storage, autograd and full PyTorch API parity remain outside this evidence.',
                      ])
    except Exception as exc:
        result['error'] = repr(exc)
        result['traceback'] = traceback.format_exc()
    result['checks'] = review.checks
    result['checks_passed'] = sum(x['passed'] for x in review.checks)
    result['checks_failed'] = sum(not x['passed'] for x in review.checks)
    result['inputs'] = review.loaded
    script = Path(__file__).read_bytes()
    result['reader_sha256'] = sha(script)
    (args.output / 'executed-reader.py').write_bytes(script)
    (args.output / 'report.json').write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('checks', 'inputs', 'traceback', 'boundaries')}, sort_keys=True))
    return 0 if result['scoped_original_evidence_admitted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
