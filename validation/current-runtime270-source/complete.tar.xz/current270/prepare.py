#!/usr/bin/env python3
"""Pure source admission and reversible transport overlays for original270.

This module never imports Torch, starts a subprocess, or evaluates a case.
"""
import argparse
import ast
import hashlib
import json
import re
import types
from pathlib import Path
from generator_admission import derive as derive_generator_admission

HERE = Path(__file__).resolve().parent
FROZEN = HERE / 'frozen'
ORACLE = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
OWNER = 'c39600e7c37dea390f88cf9e74d86dfa924301456e0f32e127d82c98ad6778b0'
ADMISSION = '5b7b9a538877c06bce9daff0631657ae3b9ce79bcd7336d42839a01ef9cbcfde'
LOCK = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
INVENTORY = 'd204c5a8268a0d0f0a1dd162b5e0ab184beee83310bcad643b084deb691f3f49'
GROUPS = [('operators', 51), ('spatial_modules', 16), ('optimizers', 8),
          ('training', 1), ('extensions', 77), ('training_sessions', 6),
          ('concatenation', 27), ('concatenation_layouts', 8),
          ('scatter_index_extensions', 74), ('combined_indexed_training', 2)]
COMPARATORS = ('compare', 'compare_join_metadata', '_indexed_reject', 'compare_join_layout')


def require(test, message):
    if not test:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, expected):
    raw = Path(path).read_bytes()
    require(sha(raw) == expected, 'source SHA mismatch: ' + str(path))
    return raw


def edits(raw, changes):
    """Apply exact whole-file text edits and prove complete inverse equality."""
    result = raw.decode()
    for before, after, count in changes:
        require(result.count(before) == count, 'edit occurrence: ' + before[:80])
        result = result.replace(before, after)
    reverse = result
    for before, after, count in reversed(changes):
        require(reverse.count(after) == count, 'inverse occurrence: ' + after[:80])
        reverse = reverse.replace(after, before)
    require(reverse.encode() == raw, 'entire source inverse differs')
    ast.parse(result)
    return result.encode(), {'original_sha256': sha(raw), 'derived_sha256': sha(result.encode()),
        'whole_inverse_exact': True,
        'edits': [{'before': a, 'after': b, 'count': c} for a, b, c in changes]}


def comparator_overlay(raw):
    require(sha(raw) == ORACLE, 'only the exact original270 oracle is accepted')
    tree = ast.parse(raw)
    selected = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)
                and n.name in COMPARATORS}
    require(set(selected) == set(COMPARATORS), 'complete four-comparator coverage')
    derived = []
    proofs = {}
    for name in COMPARATORS:
        node = selected[name]
        original = ast.get_source_segment(raw.decode(), node).encode()
        calls = [n for n in ast.walk(node) if isinstance(n, ast.Call)
                 and ast.unparse(n.func) == 'subprocess.run']
        require(len(calls) == 1, 'one original native invocation per comparator')
        old_call = ast.get_source_segment(raw.decode(), calls[0])
        variable = 'p' if name == '_indexed_reject' else 'program'
        new_call = '_current270_run(row["case"], ' + variable
        if name == '_indexed_reject':
            new_call += ', expected_status=status'
        new_call += ')'
        changes = [(old_call, new_call, 1)]
        if name == '_indexed_reject':
            changes += [
                ("(b'HTORSP01', 1, len(p.commands), status)",
                 "(b'HTORSP03', 3, len(p.commands) - 1, 0)", 1),
                ('        offset = 32\n',
                 '        assert len(result.current_failure) == 32\n'
                 "        assert struct.unpack('<8sQQQ', result.current_failure) == (b'HTORSP03', 3, 0, status)\n"
                 '        assert result.terminal_command == p.commands[-1][0] and result.terminal_command in (29, 36, 37)\n'
                 '        offset = 32\n', 1),
                ('assert error == (status if i == count - 1 else 0)',
                 'assert error == 0', 1),
            ]
        elif name == 'compare':
            changes.append(("(b'HTORSP01', 1, len(program.commands), 0)",
                            "(b'HTORSP03', 3, len(program.commands), 0)", 1))
        else:
            changes += [("(b'HTORSP01',1,len(program.commands),0)",
                         "(b'HTORSP03',3,len(program.commands),0)", 1),
                        ("struct.unpack('<13Q',payload)", "struct.unpack('<16Q',payload)", 1)]
        changed, proof = edits(original, changes)
        rewritten, = ast.parse(changed).body
        # The inverse includes the entire numeric and metadata comparison body.
        proof.update(original_ast_sha256=sha(ast.dump(node, include_attributes=False).encode()),
                     derived_ast_sha256=sha(ast.dump(rewritten, include_attributes=False).encode()),
                     numeric_expectations_or_tolerances_changed=False)
        proofs[name] = proof
        derived.append(rewritten)
    return ast.fix_missing_locations(ast.Module(body=derived, type_ignores=[])), proofs


def owner_module(source_sha256, native_sha256):
    for value in (source_sha256, native_sha256):
        require(re.fullmatch('[0-9a-f]{64}', value), 'complete explicit target SHA required')
    raw = read(FROZEN / 'owner_integral.py', OWNER)
    changes = [('HTSINT01', 'HTSINT02', 2), ('HTOSIN01', 'HTOSIN02', 2),
               ('functions == 699', 'functions == 712', 1),
               ('sum-integral-source01-UNBOUND-699', 'original270-current712-UNBOUND', 1),
               ('sum-integral-source01-%d-preserved47-48', 'original270-current%d-full-owner', 1),
               ('heptatorch.sum-integral-owner-source01.v1', 'heptatorch.original270-current712-owner.v1', 1)]
    derived, proof = edits(raw, changes)
    module = types.ModuleType('current270_complete_owner')
    module.__file__ = str(FROZEN / 'owner_integral.py') + '#current712-profile'
    exec(compile(derived, module.__file__, 'exec'), module.__dict__)
    module.bind_profile(source_sha256, native_sha256, 712)
    return module, proof, derived


def admission_module(source_sha256, native_sha256):
    """Admit the exact actually cold-built712 generation through a complete source inverse."""
    raw = read(FROZEN / 'admission701.py', ADMISSION)
    derived, inverse = derive_generator_admission(raw, source_sha256, native_sha256)
    module = types.ModuleType('current270_cold_admission')
    module.__file__ = str(FROZEN / 'admission701.py') + '#generator712-contract'
    exec(compile(derived, module.__file__, 'exec'), module.__dict__)
    module._executed_source = derived
    proof = {'source_sha256': sha(raw), 'executed_source_sha256': sha(derived),
             'all_admission_function_bodies_unchanged': False,
             'explicit_module_bindings_before': {
                 'SOURCE': inverse['edits'][0][0], 'IMAGE': inverse['edits'][1][0]},
             'explicit_module_bindings_after': {'SOURCE': source_sha256, 'IMAGE': native_sha256},
             'functions': 712, 'units': 15,
             'builder_toolchain_and_stack_checks_unchanged': False,
             'original_check_shape_preserved': True,
             'generator_generation_inverse': inverse}
    return module, proof


def source_admission(repository):
    repo = Path(repository).resolve(strict=True)
    oracle = read(FROZEN / 'pytorch_oracle.py', ORACLE)
    require(read(repo / 'tests/pytorch_oracle.py', ORACLE) == oracle, 'repository oracle differs')
    read(repo / 'compatibility/pytorch-oracle-lock.json', LOCK)
    read(repo / 'compatibility/upstream-lock.json', INVENTORY)
    read(FROZEN / 'owner_integral.py', OWNER)
    read(FROZEN / 'admission701.py', ADMISSION)
    overlay, proof = comparator_overlay(oracle)
    tree = ast.parse(oracle)
    functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    require(sum(n for _, n in GROUPS) == 270, 'complete original270 group census')
    require(len([n for n in ast.walk(tree) if isinstance(n, ast.Call)
                 and ast.unparse(n.func) == 'subprocess.run']) == 4,
            'unreviewed additional subprocess invocation')
    require(b'torch.manual_seed(1729)' in oracle and b'manual_seed(1847)' in oracle,
            'original independent seeds')
    main = functions['main']
    calls = []
    for n in ast.walk(main):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in dict(GROUPS):
            calls.append((n.lineno, n.func.id))
    require([n for _, n in sorted(calls)] == [n for n, _ in GROUPS], 'original group order changed')
    report = {'schema': 'heptatorch.current270.source-admission.v1', 'status': 'PREPARED_NOT_RUN',
              'oracle_sha256': ORACLE, 'lock_sha256': LOCK, 'inventory_sha256': INVENTORY,
              'groups': [{'function': n, 'cases': c} for n, c in GROUPS], 'expected_cases': 270,
              'expected_success_cases': 256, 'expected_refusal_cases': 14,
              'expected_native_processes': 270, 'expected_frames': 284,
              'comparator_overlay': proof, 'original_case_functions_modified': False,
              'original_Torch_provenance_setup_modified': False,
              'native_executed': False, 'Torch_executed': False,
              'reference_values_generated': False, 'full_pytorch_rewrite_complete': False}
    return oracle, overlay, report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repository', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    require(__debug__, 'assertions must be enabled')
    _, overlay, report = source_admission(a.repository)
    a.output.mkdir(parents=True, exist_ok=False)
    (a.output / 'comparators.py').write_text(ast.unparse(overlay) + '\n')
    (a.output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('status', 'expected_cases', 'expected_frames',
                                           'native_executed', 'Torch_executed')}))


if __name__ == '__main__':
    main()
