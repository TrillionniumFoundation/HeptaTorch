"""Read-only admission of the exact complete current701 cold build."""
from pathlib import Path
import hashlib
import json
import re
import stat
import struct

SOURCE = 'de4fdf964a74be11acfeddcf5fe16656c6cfa671fc7917585a72364918387a92'
IMAGE = '75e29e13c0a7f14395fd21acb82686279dc962615ae6bcde3176b72083cac971'
COMPILER = 'b1c851a0896fa6071f800e1146c3c27d0c6cf85059e9a6281b46d42908a3f59f'
LINKER = 'aae650e8822ef0b1e74d15108ad1d0f17ec791205ed5a158ec60b709f48f0e16'
INSPECTOR = '71b72260014417db72ffcebd80c86543e257c80d76cdd6c878b41feaa117cf92'
BUILDER = 'b9d039c365a8a3988e3add120e8cffa46a4e1297878f4cced30103953b030bfb'
EMPTY = hashlib.sha256(b'').hexdigest()
SUPPORT = {'rng03': 'a3fa507339b40435285dc1fa65e3cd519b6a0921a4c93bccf6ea834bb24763a3',
           'owners': '9c02b75c44eee8459c476049f4d9ebe10935d9d9ed8b27f5842c699f8e6a0884'}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def admit_build(directory, expected_report_sha256, binary, source):
    """Validate existing bytes/receipts only. Starts no subprocess."""
    need(isinstance(expected_report_sha256, str)
         and re.fullmatch('[0-9a-f]{64}', expected_report_sha256), 'exact build report SHA required')
    directory = Path(directory).resolve(strict=True)
    files = {}

    def read(path, expected=None, size=None):
        path = Path(path).resolve(strict=True)
        st = path.stat()
        need(stat.S_ISREG(st.st_mode), 'not a regular build input: ' + str(path))
        raw = path.read_bytes()
        after = path.stat()
        need((st.st_size, st.st_mtime_ns, st.st_ino) ==
             (after.st_size, after.st_mtime_ns, after.st_ino), 'build input changed during read')
        digest = sha(raw)
        need(expected is None or digest == expected, 'build input SHA mismatch: ' + str(path))
        need(size is None or len(raw) == size, 'build input length mismatch: ' + str(path))
        record = {'bytes': len(raw), 'sha256': digest, 'mode': stat.S_IMODE(after.st_mode)}
        need(str(path) not in files or files[str(path)] == record, 'inconsistent build binding')
        files[str(path)] = record
        return raw

    def parse(raw):
        return json.loads(raw, object_pairs_hook=unique_object)

    raw = read(directory / 'build.json', expected_report_sha256)
    built = parse(raw)
    need(built['schema'] == 'heptatorch.complete-runtime-build.v1'
         and built['status'] == 'PASS_NATIVE_BUILD_ONLY', 'a complete real cold build is required')
    need(built['source_sha256'] == SOURCE and built['native_sha256'] == IMAGE
         and built['functions'] == built['complete_core_bodies_matched'] == 701
         and built['units_planned'] == 14, 'not the exact complete current701 build')
    need(built['all_inputs_unchanged'] is True, 'cold inputs were not all rechecked')
    for key in ('objects_reused', 'historical_runtime_executed', 'result_executable_executed',
                'torch_executed', 'runtime_qualified', 'full_pytorch_rewrite_complete'):
        need(built[key] is False, 'unexpected cold-build claim: ' + key)
    need(built['compiler_sha256'] == COMPILER and built['linker_sha256'] == LINKER
         and built['stack_inspector_sha256'] == INSPECTOR, 'toolchain identity changed')
    need(built['link_exit'] == 0 and built['native_basename'] == 'heptatorch', 'link did not finish')
    need(built['stack']['maximum_path_bytes'] <= 8 * 1024 * 1024 - 4096,
         'native stack path exceeds fixed reserve budget')
    need(any(v['sha256'] == BUILDER for v in built['inputs'].values())
         and any(v['sha256'] == INSPECTOR for v in built['inputs'].values()),
         'cold build omitted the fixed builder or inspector input')
    source_raw = read(source, SOURCE)
    need(read(directory / 'runtime.hepta', SOURCE) == source_raw, 'different complete runtime copies')
    manifest = parse(read(directory / 'manifest.json', built['manifest_sha256']))
    need(manifest['schema'] == 'heptatorch.complete-runtime-source.v1'
         and manifest['runtime']['sha256'] == SOURCE, 'manifest is not current701')
    units, processes = built['units'], built['processes']
    need(len(units) == len(manifest['units']) == 14 and len(processes) == 15,
         'incomplete native unit/compiler/linker coverage')
    need([u['name'] for u in units] == [u['name'] for u in manifest['units']]
         and len({u['name'] for u in units}) == 14, 'unit identities/order differ')
    need(units[0]['name'] == 'rng03' and units[-1]['name'] == 'owners', 'support unit order differs')
    need([p['name'] for p in processes] == [u['name'] for u in units] + ['link'],
         'native process sequence differs')
    for process in processes:
        need(process['started'] is True and process['exit_code'] == 0
             and process['stdout_EOF'] is True and process['stderr_EOF'] is True
             and process['stderr_bytes'] == 0 and process['stderr_sha256'] == EMPTY
             and not process.get('timed_out'), 'native tool did not finish cleanly')
        read(directory / (process['name'] + '.stderr'), EMPTY, 0)
    functions = re.findall(rb'^(fn ([A-Za-z_][A-Za-z_0-9]*)\([^\n]* entry\([A-Za-z_][A-Za-z_0-9]*\)\n.*?^end\n)',
                           source_raw, re.M | re.S)
    bodies = {name: body for body, name in functions}
    need(len(functions) == len(bodies) == 701, 'complete source function census differs')
    matched = {}
    objects = []
    for unit, entry, process in zip(units, manifest['units'], processes):
        name = unit['name']
        need(re.fullmatch('[A-Za-z_][A-Za-z_0-9]*', name), 'unsafe unit name')
        unit_raw = read(directory / (name + '.hepta'), unit['source_sha256'])
        need(entry['sha256'] == unit['source_sha256'] == process['input_sha256']
             and process['input_bytes'] == len(unit_raw), 'compiler source binding differs')
        need(unit['compiler_exit'] == 0 and unit['compiler_stderr_bytes'] == 0,
             'unit compiler failed')
        obj = read(directory / (name + '.o'), unit['object_sha256'], unit['object_bytes'])
        need(obj[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<H', obj, 16)[0] == 1
             and struct.unpack_from('<H', obj, 18)[0] == 62, 'wrong relocatable object')
        need(process['stdout_sha256'] == sha(obj) and process['stdout_bytes'] == len(obj),
             'compiler output differs from actual object')
        if name in SUPPORT:
            # Fixed support modules have private local helpers whose names can
            # match core names. They are not alternative core definitions.
            need(sha(unit_raw) == SUPPORT[name], 'fixed support source changed')
        else:
            for body, fn in re.findall(rb'^(fn ([A-Za-z_][A-Za-z_0-9]*)\([^\n]* entry\([A-Za-z_][A-Za-z_0-9]*\)\n.*?^end\n)',
                                       unit_raw, re.M | re.S):
                need(fn in bodies and fn not in matched and body == bodies[fn],
                     'partition changed a complete-runtime body')
                matched[fn] = name
        objects.append(obj)
    need(set(matched) == set(bodies), 'partition omits complete-runtime bodies')
    link_request = b'HIASTKS1' + struct.pack('<3Q', 14, 4, 0) + b'step'
    link_request += b''.join(struct.pack('<Q', len(obj)) + obj for obj in objects)
    need(read(directory / 'link.request.bin') == link_request, 'link did not bind these actual objects')
    link = processes[-1]
    need(link['input_sha256'] == sha(link_request) and link['input_bytes'] == len(link_request),
         'linker request receipt differs')
    native = read(binary, IMAGE, built['native_bytes'])
    need(read(directory / 'heptatorch', IMAGE) == native and native[:6] == b'\x7fELF\x02\x01'
         and struct.unpack_from('<H', native, 16)[0] == 2
         and struct.unpack_from('<H', native, 18)[0] == 62, 'wrong complete native executable')
    need(link['stdout_sha256'] == IMAGE and link['stdout_bytes'] == len(native), 'link output receipt differs')
    read(directory / 'toolchain/stack-module-compiler', COMPILER)
    read(directory / 'toolchain/stack-linker-session', LINKER)
    return {'schema': 'heptatorch.current701-original35.cold-build-admission.v1',
            'status': 'ADMITTED_CURRENT701_COLD_BUILD', 'build_sha256': expected_report_sha256,
            'source_sha256': SOURCE, 'native_sha256': IMAGE, 'functions': 701,
            'units': 14, 'compiler_processes': 14, 'linker_processes': 1,
            'native_executed_by_admission': False, 'Torch_executed_by_admission': False,
            'files': files, 'runtime_qualification_inferred': False}


def recheck_build(admission):
    results = {}
    for name, expected in admission['files'].items():
        try:
            path = Path(name)
            raw = path.read_bytes()
            results[name] = (len(raw) == expected['bytes'] and sha(raw) == expected['sha256']
                             and stat.S_IMODE(path.stat().st_mode) == expected['mode'])
        except OSError:
            results[name] = False
    return results
