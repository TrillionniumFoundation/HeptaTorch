"""Numeric-free transport encoding for the frozen original270 Program.

Original command order, scalar bit patterns, Tensor blobs and index bytes are
retained. Only framing, payload offsets and genuine Tensor identities change.
"""
import hashlib
import struct

MIB = 1 << 20
RESULT_REF = 0xfe000000
TENSOR_FIELDS = {
    2: (2, 3), 3: (2,), 4: (2,), 5: (1, 2), 6: (1,), 7: (1,), 8: (1,),
    9: (1,), 10: (1,), 11: (1,), 12: (1,), 13: (1,), 15: (1, 2, 3),
    16: (1, 2), 17: (1,), 18: (1,), 19: (1,), 20: (2,), 21: (2,),
    22: (1, 2), 23: (2,), 24: (1, 2, 3), 25: (1, 2), 26: (1, 2, 3),
    27: (1, 2), 28: (1, 2, 3, 4, 5), 29: (1, 2), 30: (1,), 31: (1,),
    32: (1, 2), 36: (1, 2), 37: (1, 2),
}
TENSOR_RESULTS = {1, 2, 3, 4, 5, 6, 15, 16, 17, 18, 19, 20, 21, 22, 23,
                  26, 27, 28, 30, 31, 32, 34, 35, 36, 37}
COMMANDS = set(range(1, 38))


def require(test, message):
    if not test:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def typed(value, kind):
    require(type(value) is int and 0 < value < 1 << 64, 'invalid typed native identity')
    generation, observed, slot = value >> 32, (value >> 24) & 255, value & 0xffffff
    require(generation > 0 and observed == kind and 1 <= slot <= 65536,
            'native identity kind, generation or slot differs')
    return generation, slot


def tracking_program(original):
    """Keep all original Program methods; add construction-result bookkeeping."""
    class CurrentProgram(original):
        def __init__(self):
            super().__init__()
            self.current270_produced = {}

        def handle(self, slot):
            logical = super().handle(slot)
            ordinal = len(self.commands) - 1
            require(ordinal >= 0 and self.commands[ordinal][0] in TENSOR_RESULTS,
                    'logical Tensor handle without a constructor command')
            require(logical not in self.current270_produced, 'logical Tensor identity reused')
            self.current270_produced[logical] = ordinal
            return logical

    return CurrentProgram


def encode_frame(program, start, stop, bindings):
    """Encode one contiguous range; returns actual bytes and reversible proof."""
    total = len(program.commands)
    require(0 <= start < stop <= total, 'invalid contiguous command range')
    require(all(len(c) == 8 and c[0] in COMMANDS for c in program.commands),
            'unreviewed original270 opcode')
    produced = program.current270_produced

    def resolve(logical, ordinal):
        if logical == 0:
            return 0
        require(logical in produced, 'unobserved logical Tensor input')
        origin = produced[logical]
        require(origin < ordinal, 'forward or self result reference')
        if origin >= start:
            return RESULT_REF | (origin - start + 1)
        require(logical in bindings, 'missing actual earlier-frame Tensor result')
        typed(bindings[logical], 1)
        return bindings[logical]

    # Repack only the selected original records and their original payloads.
    # Pointer relocation follows the frozen serializer, with no numerical work.
    commands = [list(c) for c in program.commands[start:stop]]
    payload = bytearray()
    offset = 32 + 64 * len(commands)
    join_regions = []
    payload_roles = set()
    for at, data in program.blobs.items():
        if start <= at < stop:
            require(isinstance(data, bytes), 'Tensor blob must be exact frozen bytes')
            commands[at - start][7] = offset + len(payload)
            payload.extend(data)
            payload_roles.add((at, 7))
    for at, field, data in program.extra:
        if start <= at < stop:
            require((at, field) not in payload_roles, 'duplicate payload pointer')
            while (offset + len(payload)) % 8:
                payload.append(0)
            commands[at - start][field] = offset + len(payload)
            if program.commands[at][0] in (34, 35):
                require(field == 2 and len(data) >= 8, 'join list field')
                count, = struct.unpack_from('<Q', data)
                require(len(data) == 8 + count * 8, 'join list exact shape')
                join_regions.append((at, offset + len(payload), count))
            payload.extend(data)
            payload_roles.add((at, field))
    for at, data in program.configs.items():
        if start <= at < stop:
            require((at, 5) not in payload_roles, 'duplicate optimizer payload')
            while (offset + len(payload)) % 8:
                payload.append(0)
            commands[at - start][5] = offset + len(payload)
            payload.extend(data)
            payload_roles.add((at, 5))
    legacy = struct.pack('<8sQQQ', b'HTORCH01', len(commands), offset + len(payload), 0)
    legacy += b''.join(struct.pack('<8Q', *c) for c in commands) + payload
    if start == 0 and stop == total:
        require(legacy == program.encode(), 'whole request differs from original serializer')
    actual = bytearray(legacy)
    actual[:8] = b'HTORCH03'
    changes = []
    for local, command in enumerate(commands):
        ordinal = start + local
        for field in TENSOR_FIELDS.get(command[0], ()):
            address = 32 + 64 * local + 8 * field
            old, = struct.unpack_from('<Q', actual, address)
            new = resolve(old, ordinal)
            struct.pack_into('<Q', actual, address, new)
            changes.append((address, old, new))
    for ordinal, region, count in join_regions:
        for i in range(count):
            address = region + 8 * (i + 1)
            old, = struct.unpack_from('<Q', actual, address)
            new = resolve(old, ordinal)
            struct.pack_into('<Q', actual, address, new)
            changes.append((address, old, new))
    inverse = bytearray(actual)
    inverse[:8] = b'HTORCH01'
    for address, old, new in reversed(changes):
        require(struct.unpack_from('<Q', inverse, address)[0] == new, 'identity patch overlap')
        struct.pack_into('<Q', inverse, address, old)
    require(bytes(inverse) == legacy, 'transport changed a non-identity or non-framing byte')
    require(len(actual) <= MIB, 'current frame exceeds original one-MiB ceiling')
    return bytes(actual), {'start': start, 'stop': stop, 'command_count': stop - start,
        'legacy_range_sha256': sha(legacy), 'native_frame_sha256': sha(actual),
        'bytes': len(actual), 'identity_patches': [list(c) for c in changes],
        'complete_inverse_to_legacy_range': True,
        'whole_original_request': start == 0 and stop == total,
        'numeric_or_index_payload_bytes_changed': False}


def parse_response(raw, commands, expected_status):
    require(32 <= len(raw) <= MIB, 'native response length')
    magic, version, count, status = struct.unpack_from('<8sQQQ', raw)
    require((magic, version, status) == (b'HTORSP03', 3, expected_status),
            'actual current response profile or status differs')
    if expected_status:
        require(count == 0 and len(raw) == 32, 'current atomic refusal must contain no records')
        return []
    require(count == len(commands), 'native successful record count differs')
    records = []
    offset = 32
    for command in commands:
        require(offset + 32 <= len(raw), 'truncated actual native record')
        code, error, value, size = struct.unpack_from('<4Q', raw, offset)
        offset += 32
        require(code == command[0] and error == 0 and offset + size <= len(raw),
                'native record opcode, error or exact payload bounds')
        payload = raw[offset:offset + size]
        offset += size
        if code in TENSOR_RESULTS:
            typed(value, 1)
            require(size == 0, 'constructor returned an unexpected payload')
        if code == 13:
            typed(value, 1)
            require(size == 128, 'full current metadata width')
            metadata = struct.unpack('<16Q', payload)
            typed(metadata[11], 2)
            typed(metadata[12], 3)
        records.append((code, value, payload))
    require(offset == len(raw), 'unexpected trailing native response bytes')
    return records


def accept_bindings(program, start, stop, records, bindings):
    require(len(records) == stop - start, 'binding range must be completely successful')
    updated = dict(bindings)
    seen = set(bindings.values())
    generations = {}
    for native in bindings.values():
        generation, slot = typed(native, 1)
        generations[slot] = max(generation, generations.get(slot, 0))
    for logical, ordinal in program.current270_produced.items():
        if start <= ordinal < stop:
            code, native, payload = records[ordinal - start]
            require(code == program.commands[ordinal][0] and code in TENSOR_RESULTS and not payload,
                    'binding is not an actual constructor result')
            generation, slot = typed(native, 1)
            require(native not in seen and logical not in updated, 'native Tensor identity reused')
            require(generation > generations.get(slot, 0), 'native slot generation did not advance')
            updated[logical] = native
            seen.add(native)
            generations[slot] = generation
    for local, command in enumerate(program.commands[start:stop]):
        if command[0] == 13:
            require(command[1] in updated and records[local][1] == updated[command[1]],
                    'metadata response identifies a different Tensor')
    return updated
