#!/usr/bin/env python3
"""Run the complete original270 numeric suite on one selected cold 712 image.

The selected source/image/build SHA256 values are mandatory. No build, history
image, old numeric report, or frozen expected Tensor is invoked by this entry.
"""
from pathlib import Path
import argparse
import ast
import contextlib
import json
import os
import stat
import sys
import time
import traceback

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from prepare import (GROUPS, LOCK, admission_module, owner_module,
                     require, sha, source_admission)
from transport import NativeTransport
from wire import tracking_program

CHECKS = {'python_matches', 'platform_matches', 'version_backend_matches',
          'git_matches_oracle_build_pin', 'distribution_version_matches',
          'direct_url_matches', 'direct_url_archive_sha256_matches',
          'pip_report_url_matches', 'pip_report_archive_sha256_matches',
          'pip_report_version_matches', 'pip_report_requested'}


def file_record(path):
    raw = path.read_bytes()
    return {'sha256': sha(raw), 'bytes': len(raw), 'mode': stat.S_IMODE(path.stat().st_mode)}


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('repository', 'binary', 'source', 'build-directory', 'output'):
        parser.add_argument('--' + name, required=True, type=Path)
    for name in ('source', 'native', 'build'):
        parser.add_argument('--expected-' + name + '-sha256', required=True)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    require(not sys.flags.optimize, 'all original assertions must remain enabled')
    for name in ('repository', 'binary', 'source', 'build_directory'):
        setattr(args, name, getattr(args, name).resolve(strict=True))
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=False)
    report = {'schema': 'heptatorch.current712-original270.v1', 'status': 'PREPARED_NOT_RUN',
              'source_sha256': args.expected_source_sha256,
              'native_sha256': args.expected_native_sha256,
              'build_sha256': args.expected_build_sha256,
              'expected_cases': 270, 'expected_frames': 284,
              'native_executed': False, 'Torch_executed': False,
              'historical_runtime_executed': False,
              'synthetic_reference_values': False,
              'synthetic_native_response_records': False,
              'full_private_allocation_transition_ledger_claimed': False,
              'full_pytorch_rewrite_complete': False, 'groups': [], 'error': None}
    transport = None
    custody = {}
    cold = admission = None
    started = time.monotonic()
    exit_code = 1
    previous_argv, previous_directory = sys.argv, Path.cwd()
    try:
        raw, overlay, source_proof = source_admission(args.repository)
        admission, admission_binding = admission_module(args.expected_source_sha256,
                                                        args.expected_native_sha256)
        executed_admission = args.output / 'executed-admission.py'
        executed_admission.write_bytes(admission._executed_source)
        cold = admission.admit_build(args.build_directory, args.expected_build_sha256,
                                     args.binary, args.source)
        owner, owner_proof, owner_source = owner_module(args.expected_source_sha256,
                                                       args.expected_native_sha256)
        profile = owner.pin_profile(args.binary, args.source)
        save(args.output / 'source-admission.json', source_proof)
        save(args.output / 'cold-build-admission.json', cold)
        save(args.output / 'admission-binding.json', admission_binding)
        save(args.output / 'owner-profile-adaptation.json', owner_proof)
        (args.output / 'executed-owner.py').write_bytes(owner_source)
        (args.output / 'executed-comparators.py').write_text(ast.unparse(overlay) + '\n')
        paths = {str(p.resolve()): p.resolve() for p in HERE.rglob('*')
                 if p.is_file() and '__pycache__' not in p.parts}
        paths[str(executed_admission)] = executed_admission
        for relative in ('tests/pytorch_oracle.py', 'compatibility/pytorch-oracle-lock.json',
                         'compatibility/upstream-lock.json'):
            path = args.repository / relative
            paths[str(path)] = path
        for name in cold['files']:
            paths[name] = Path(name)
        if not args.prepare_only:
            install = args.repository / 'build/pytorch-install.json'
            require(install.is_file(), 'original fixed Torch installation report is required')
            paths[str(install)] = install
        custody = {name: file_record(path) for name, path in paths.items()}
        report.update(source_admission=source_proof, cold_build_admission=cold,
                      cold_admission_identity_binding=admission_binding,
                      owner_profile=profile, owner_adaptation=owner_proof)
        if args.prepare_only:
            exit_code = 0
        else:
            original_report = args.output / 'original-report.json'
            scope = {'__name__': 'current270_original_definitions',
                     '__file__': str(args.repository / 'tests/pytorch_oracle.py')}
            sys.argv = [scope['__file__'], str(args.binary), str(original_report),
                        str(args.repository / 'compatibility/pytorch-oracle-lock.json')]
            os.chdir(args.repository)
            with (args.output / 'original-entry.stdout').open('x') as stdout, \
                    (args.output / 'original-entry.stderr').open('x') as stderr:
                with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                    # Original top-level provenance, CPU controls, and seed run once.
                    report['Torch_executed'] = True
                    exec(compile(raw, scope['__file__'], 'exec'), scope)
                    require(scope['PROVENANCE']['status'] == 'PASS'
                            and set(scope['PROVENANCE']['checks']) == CHECKS
                            and all(v is True for v in scope['PROVENANCE']['checks'].values()),
                            'all eleven original Torch provenance checks are mandatory')
                    transport = NativeTransport(args.binary, args.output / 'native', owner,
                                                args.expected_native_sha256)
                    scope['Program'] = tracking_program(scope['Program'])
                    scope['_current270_run'] = transport.execute
                    exec(compile(overlay, '<inverse-proved-current270-transport>', 'exec'), scope)

                    def guarded_group(name, expected, function):
                        def call():
                            before = len(scope['ROWS'])
                            value = function()
                            rows = scope['ROWS'][before:]
                            item = {'function': name, 'expected_cases': expected,
                                    'cases': len(rows), 'case_names': [r['case'] for r in rows]}
                            report['groups'].append(item)
                            require(len(rows) == expected, 'original group census differs: ' + name)
                            return value
                        return call

                    for name, expected in GROUPS:
                        scope[name] = guarded_group(name, expected, scope[name])
                    try:
                        scope['main']()
                    except SystemExit as error:
                        if error.code not in (0, None):
                            raise
            original = json.loads(original_report.read_bytes())
            require(original['status'] == 'PASS' and original['setup_error'] is None
                    and original['failed_cases'] == 0 and original['expected_cases'] ==
                    original['cases'] == len(original['rows']) == 270, 'all original270 rows must pass')
            require(original['native_executable_sha256'] == args.expected_native_sha256
                    and original['native_unchanged_during_run'] is True, 'original report image binding')
            require(original['seed'] == 1729 and original['oracle_provenance']['lock_sha256'] == LOCK,
                    'original seed and oracle lock binding')
            require(len(transport.cases) == 270 and
                    [r['case'] for r in original['rows']] == [r['case'] for r in transport.cases],
                    'each original numeric case requires its own new actual native execution')
            require(all(row['status'] == 'PASS' for row in original['rows']), 'original numerical failure')
            for row in transport.cases:
                require(row['status'] == 'PASS_ACTUAL_TRANSPORT' and row['native_started'] is True
                        and row['executed_image_sha256'] == args.expected_native_sha256
                        and row['native_exit'] == 0 and row['stdout_EOF'] is True
                        and row['stderr_EOF'] is True and row['stderr_bytes'] == 0
                        and row['unexpected_stdout_bytes'] == 0, 'native EOF, exit or transport failure')
            require(sum(bool(c['expected_status']) for c in transport.cases) == 14
                    and sum(len(c['requests']) for c in transport.cases) == 284,
                    'complete 256 ordinary cases plus 14 actual prefix/refusal pairs')
            require([(r['function'], r['cases']) for r in report['groups']] == GROUPS,
                    'complete original group order and cases')
            report.update(status='PASS_CURRENT712_ORIGINAL270', cases=270, frames=284,
                          compared_values=original['compared_values'],
                          original_report={'path': str(original_report), **file_record(original_report)},
                          oracle_provenance=original['oracle_provenance'])
            exit_code = 0
    except BaseException as error:
        report.update(status='FAIL', error={'type': type(error).__name__, 'message': str(error),
                                           'traceback': traceback.format_exc()})
        exit_code = 1
    finally:
        sys.argv = previous_argv
        os.chdir(previous_directory)
        report['native_executed'] = transport is not None and any(c['native_started'] for c in transport.cases)
        report['Torch_executed'] = not args.prepare_only and 'torch' in sys.modules
        if transport is not None:
            report['native_cases'] = transport.cases
        unchanged = {}
        for name, expected in custody.items():
            try:
                unchanged[name] = file_record(Path(name)) == expected
            except OSError:
                unchanged[name] = False
        if admission is not None and cold is not None:
            unchanged.update({'cold:' + name: passed for name, passed in admission.recheck_build(cold).items()})
        report['source_custody'] = custody
        report['inputs_unchanged'] = unchanged
        report['all_inputs_unchanged'] = bool(unchanged) and all(v is True for v in unchanged.values())
        if not report['all_inputs_unchanged']:
            report['status'] = 'FAIL'
            report['custody_failure'] = True
            exit_code = 1
        report['wall_seconds'] = time.monotonic() - started
        save(args.output / 'report.json', report)
    print(json.dumps({k: report.get(k) for k in ('status', 'cases', 'frames', 'compared_values',
                                               'native_executed', 'Torch_executed', 'error')}))
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
