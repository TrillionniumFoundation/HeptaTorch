# Original270 on a complete current 701 HIA image

This package adapts the complete, fixed `tests/pytorch_oracle.py` to the current
owned Tensor protocol. Its present qualification is **PREPARED_NOT_RUN**. Pure
source and packet checks have run; this package has not imported Torch or
started an HIA process during authoring. Its actual `run.py` entry is provided
for a separately scheduled complete execution.

The original oracle is 61,783 bytes, SHA256
`ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae`.
All case functions, input generation, expected Torch computations, training
steps, tolerances, and the eleven provenance checks remain unchanged. The
entire four comparison functions are restored by the recorded reverse
transformation. Their changes are restricted to actual current transport,
metadata width, and the explicit transaction-refusal mapping below.

| Derived comparison function | Exact edits and their purpose | Unchanged assertions |
| --- | --- | --- |
| `compare` | Replace its one `subprocess.run` expression with the real current transport; response magic/version1→3 | Every expected tensor, shape check, F32 `isclose`, tolerance, NaN rule, error metric, mismatch count and complete response-length assertion |
| `compare_join_metadata` | Same transport/profile replacement; unpack the actual metadata as16 words instead of13 | Exact original first11 geometry/stride/requires fields, zero-length reads and full parsing |
| `compare_join_layout` | Same transport/profile replacement; actual16-word metadata | Original `torch.testing.assert_close(rtol=0, atol=0)`, original geometry checks and full parsing |
| `_indexed_reject` | Replace its one launch with the two actual frames; prefix must now be success/count`n-1`; require the separately observed32-byte/count0 refusal with the exact old status and exact terminal opcode; all prefix record errors remain zero | Full original Torch exception phase observation, original input construction and bounds, every prefix `torch.equal`, shapes, value counts and complete prefix parsing |

`prepare.py` records every before/after string and occurrence count, then
reverses the entire derived function to its exact frozen source. The ten group
functions and other numeric/input helpers remain original. The rejection
helper contains both input/reference code and transport; only its listed
transport assertions are adapted. The original Torch top-level initialization
and original `main` are executed unchanged.

## Scope: 270 is a separate gate

| Original group | Cases | Material coverage |
| --- | ---: | --- |
| `operators` | 51 | Broadcasting binary ops, transposed/empty mm, seven activations, sum/mean axes, softmax/log-softmax; forward and real autograd |
| `spatial_modules` | 16 | Grouped/dilated Conv2d, max/average pooling, LayerNorm, eval BatchNorm, probability-target cross entropy, view/clone |
| `optimizers` | 8 | Adam/AdamW weight decay, SGD momentum/dampening/Nesterov, large-gradient Adam state |
| `training` | 1 | Original random-initialized tanh MLP and real SGD for 18 steps |
| `extensions` | 77 | Rank/empty/strided matmul, biased/unbiased linear, index-select, gather, repeated seeded VJP, composed attention |
| `training_sessions` | 6 | 1,024-step SGD; 512-step Adam and AdamW; three accumulated-gradient/reset/empty cases |
| `concatenation` | 27 | Cat/stack ranks, shared parents, empty-axis special cases, exact shape/stride metadata, 12 resets, 256 repeated parents |
| `concatenation_layouts` | 8 | Exact values and gradients for dense/channels-last, mixed and singleton layouts |
| `scatter_index_extensions` | 74 | Rank/axis, repeated/strided/shared indexing, empty and nonfinite cases, overflow/alpha, reset composition; 14 original refusal cases |
| `combined_indexed_training` | 2 | Cat/stack + duplicate index-add + real gradients + SGD/AdamW in the same request, 12 resets |
| **Total** | **270** | **256 successful numerical cases and 14 phase/status refusal cases** |

The 35-case suite executes 21 cross-frame cases, seven capacity/owned Tensor
extensions and seven lifetime cases. Its 24-step MLP, 64/128-step optimizer
sequences, seeds, framing and lifetime assertions differ from this oracle.
Neither case count is a substitute for the other.

The current159 gate runs view/reshape26, wrapped scalar32, direct view14,
input-boundary4, F32 Sum32, Integral24 and Bool27. It does not call this oracle's
`main`. Its dedicated sum operation uses command115; original270 reduces with
commands4/20 (`reduce` / `reduce_axis`). The 159 gate therefore cannot supply
this numeric/NN/optimizer gate even when some operation families overlap.

The historical CI runs this oracle against `build/heptatorch` and
`build/heptatorch-monolithic`, both from `src/heptatorch.hepta`. That old source
has 143 functions and SHA256
`264e9c5c4e8ea1834724cc0d8d859952016daffe4af330a8daa7745e7a5e5233`.
In the first 701 source every old function name exists, but only 64 complete
bodies are identical and 79 changed. Name coverage is not current-image
qualification. `audit.json` records this source-level comparison.

## Current transport

The original oracle builds no executable and starts no historical path on its
own: it runs the executable supplied as its first argument. The four original
launch sites each use a 120-second complete-process limit and require exit0,
empty stderr and complete parsing of stdout.

The old transport is one raw `HTORCH01` request and an `HTORSP01` response per
case. Current HIA consumes `HTOWNR01` envelopes around `HTORCH03`, returns
`HTOWNS01` / `HTORSP03`, and uses actual typed Tensor identities. Merely changing
the magic bytes would send incorrect logical IDs.

`wire.py` retains the original eight-bit logical client ledger, including its
reset behavior. It records the original command that produced each logical
result. A same-frame operand uses a checked earlier-record reference; an
earlier-frame operand uses a typed identity read from the real prior response.
All scalar bits, Tensor data, optimizer configuration and numeric index bytes
remain original. Cat/stack Tensor-ID payloads receive only identity relocation.
Each generated frame has an explicit inverse proof. The whole successful
request must reproduce the original serializer exactly before relocation.

The original constructor `count` only advances that frozen client ledger. It
never predicts a native descriptor or public slot: a composite operation's
result token comes from its actual response record, regardless of how many
private objects the kernel allocates. Reset command33 and its original prefix
count remain unchanged. Same-request references still point to their actual
earlier result records across resets; a live prefix therefore retains its real
token. Reused native slots must have strictly advancing generations and no
complete typed identity may repeat. The adapter never substitutes a newly
allocated object for a stale handle. A changed native reset contract fails the
original request instead of being repaired by guessed slot arithmetic.

All 256 ordinary cases keep their complete original command sequence in one
frame and one fresh native process. Full 16-word metadata is read; the original
first-eleven-word geometry/gradient/layout comparisons stay exact. Actual
Tensor, Storage and Version identities are additionally checked for their
proper kinds. No metadata field is fabricated or truncated.

### The 14 refusals

The old one-shot interface includes successful records before its last failing
command. Current `owners.step_impl` drops the trial owner on failure and emits
only a 32-byte response with count0 and the real status. That is an actual
contract difference, not a format literal that can be relabeled.

For each of the original 14 cases this adapter sends the unchanged successful
prefix first, then sends exactly its one final failing command to the same
process using the genuine returned identities. The prefix response remains
actual native bytes and is passed through the complete original prefix numeric
comparison. The second actual response must be exactly `HTORSP03`, version3,
count0, the original expected status2/5/7, and 32 bytes. Its request opcode must
be the original final command29/36/37. The complete owner pointer, length, SHA
and semantic snapshot must be unchanged by that refusal.

There are nine forward and five backward rejection cases. Their actual Torch
exception phase checks are unchanged. No failure record is synthesized and no
successful prefix observation is omitted. The additional wrapper report names
the framing change; the original one-shot atomicity is not claimed.

Successful complete qualification requires **270 new native processes and
284 actual frames**. Every process is checked through `/proc/PID/exe` against
the selected ELF SHA, reaches both actual stream EOFs, exits0 and emits no
unexpected output. Raw sent/received bytes, frame files, full owner snapshots,
partial failure streams and per-case transport reports are retained.

## Owner and cold-build admission

The complete 71,640-byte frozen `owner_integral.py`, SHA256
`c39600e7c37dea390f88cf9e74d86dfa924301456e0f32e127d82c98ad6778b0`, is retained.
Only tags, schema/profile identities and count699→701 change, with a whole-file
inverse. Its structural predicates are unchanged, and every before/after
snapshot contains all 84 words of every descriptor.

The original35 transition ledger is intentionally not applied to 270: it
admits at most one reset per frame and forbids backward together with reset,
whereas this suite includes complete long training programs with many resets.
The new gate checks the complete existing general structural owner and exact
refusal rollback. It does **not** claim an independent complete private
allocation transition ledger for each operation inside a large successful
frame. The original270 numerical oracle never made that stronger claim.

The exact source, executable and build-report SHA values are mandatory CLI
arguments. The frozen full cold-build admission functions remain unchanged;
their two explicit identity bindings select this particular 701 build. All
14 source/object units, complete701 bodies, 15 real compiler/linker receipts,
fixed compiler/linker/builder/inspector hashes, stack budget and final file
SHA/length/mode checks remain mandatory. No build or old image runs here.

## Fixed Torch environment and numeric comparisons

The unchanged lock requires Linux x86-64, CPython3.12, official CPU
PyTorch2.15.0+cpu, build commit
`d0f2af8b66b20da4baa50644c0cd3f887a2eae2e`, and wheel SHA256
`0955c7e3446326293f48af18fad67872fa31dee5a36a87690eb9e5be8b465be3`.
`build/pytorch-install.json` must be the actual fixed pip installation receipt.
The eleven checks cover Python, platform, version/backend, Git build pin,
installed distribution, PEP610 URL/hash and pip report URL/hash/version/request.
The inventory commit is a separate release-source identity; the original lock
records their exact source equivalence rather than pretending the commits match.

Original setup uses one thread, seed1729, disabled MKLDNN and deterministic
algorithms. The scatter/index extension owns a separate generator seeded1847.
Setup runs once, in the original order. The adapter performs no Torch operation
while constructing or observing transport.

Default comparison is F32 `torch.isclose(rtol=4e-5, atol=5e-6, equal_nan=True)`.
Declared per-family tolerances are preserved: unary8e-5; softmax/pool1e-4;
Conv2d/BatchNorm2e-4 with2e-5 absolute; LayerNorm5e-4 with5e-5 absolute;
MLP6e-4 with4e-5 absolute; seeded extensions8e-5 with8e-6 absolute.
Optimizer and composed training calls keep their own exact original values.
Metadata and the layout suite use exact comparisons. Refusal-prefix values use
the original `torch.equal`. Finite error metrics use float64 differences, while
acceptance remains the original F32 comparisons.

The old reports contain aggregate comparisons and examples, not all Torch
expected tensors. Old native wire replies cannot replace these expected values.
This entry therefore runs the original fixed Torch code; it does not invent a
frozen reference or replay an old PASS.

## Commands

Pure source admission and packet tests, with no Torch import or native launch:

```sh
python3 -I -S -B prepare.py --repository "$REPO" --output "$NEW_SOURCE_REVIEW"
python3 -I -S -B static_check.py --repository "$REPO" --output "$NEW_WIRE_REVIEW_JSON"
```

For the separately selected AVX2-corrected 701 candidate, use its already
verified complete cold build and a new output directory. `BUILD_SHA` is the
actual SHA of that particular cold build's original `build.json`:

```sh
"$PINNED_TORCH_PYTHON" -B run.py \
  --repository "$REPO" \
  --binary "$COLD_BUILD/heptatorch" \
  --source "$COLD_BUILD/runtime.hepta" \
  --build-directory "$COLD_BUILD" \
  --expected-source-sha256 706673d47858a47fafeefe9f40aed6c52e5181caa4183ec12f72151385ca84e3 \
  --expected-native-sha256 589367e5db70847c727e8d1005680dc5e8f73d536d887c9bb2c30c41db4ae9c4 \
  --expected-build-sha256 "$BUILD_SHA" \
  --output "$NEW_ACTUAL_OUTPUT"
```

Adding `--prepare-only` performs all source/profile/cold-build admission and
returns `PREPARED_NOT_RUN` without importing Torch or starting native. Use a
different output directory for actual execution. The actual success status is
`PASS_CURRENT701_ORIGINAL270`, with original270 all PASS, all ten group counts,
270 real process identities, 284 frames, all actual exits/EOFs and unchanged
inputs. Any failed numeric row, missing run, protocol mismatch or changed input
produces FAIL. It cannot count toward whole-project closure before a real run.
