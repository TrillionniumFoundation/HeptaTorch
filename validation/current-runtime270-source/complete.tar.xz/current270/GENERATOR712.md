# Current Tensor and Generator 712 source adaptation

This package has not executed a native or Torch test. It retains every original
source file, the original numerical loops and comparisons, all owner predicates,
all refusal/partial-prefix checks and both EOF requirements. `parent701` holds
the exact old versions of the few changed wrapper files and their manifest.
The original README and review records remain historical source witnesses.

`source-transition712.json` records complete reversible wrapper changes. The
new cold admission changes only fixed identities and generation contract
literals: 712 functions, 15 actual objects, 16 actual tool processes, the
four-argument entropy linker and its exact source/support bindings. The new
`cg_model` remains part of complete core-body matching. No old PASS transfers.
