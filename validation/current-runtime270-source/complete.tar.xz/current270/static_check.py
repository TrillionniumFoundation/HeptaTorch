#!/usr/bin/env python3
"""Pure source/wire checks. Synthetic packets here are not runtime evidence."""
from pathlib import Path
import argparse
import ast
import json
import struct
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from prepare import source_admission, owner_module, admission_module, require
from wire import tracking_program, encode_frame, parse_response, accept_bindings


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    require(not sys.flags.optimize, 'assertions must remain enabled')
    raw, overlay, proof = source_admission(args.repository)
    node = next(n for n in ast.parse(raw).body if isinstance(n, ast.ClassDef) and n.name == 'Program')
    scope = {'struct': struct}
    exec(compile(ast.Module(body=[node], type_ignores=[]), '<frozen-Program-wire-only>', 'exec'), scope)
    Program = tracking_program(scope['Program'])

    def scalar_bytes(program, bits):
        at = len(program.commands)
        result = program.make(1, 0, 1, 0, 0, 0, 0, 0)
        program.blobs[at] = struct.pack('<I', bits)
        return result

    p = Program()
    a, b = scalar_bytes(p, 0x3f800000), scalar_bytes(p, 0x40000000)
    c = p.binary(3, a, b)
    d = p.join([a, c, a], 0)
    p.read(d)
    frame, inverse = encode_frame(p, 0, len(p.commands), {})
    assert frame[:8] == b'HTORCH03' and inverse['complete_inverse_to_legacy_range']
    assert len(inverse['identity_patches']) == 6
    q = Program()
    x = scalar_bytes(q, 0x3f800000)
    q.reset_graph(1)
    y = q.clone(x)
    q.read(y)
    encode_frame(q, 0, len(q.commands), {})
    assert x == 1 and y == 258  # Original eight-bit logical ledger is unchanged.

    r = Program()
    x, y = scalar_bytes(r, 0x3f800000), scalar_bytes(r, 0x40000000)
    at = r.command(37, x, y, 0, 0, 0x3f800000)
    r.extra.append((at, 4, struct.pack('<2Qq', 1, 1, 0)))
    r.next_id += 1
    r.handle(r.next_id - 1)
    encode_frame(r, 0, 2, {})
    tokens = [(1 << 32) | (1 << 24) | slot for slot in (7, 11)]
    synthetic = struct.pack('<8sQQQ', b'HTORSP03', 3, 2, 0)
    synthetic += b''.join(struct.pack('<4Q', 1, 0, token, 0) for token in tokens)
    records = parse_response(synthetic, r.commands[:2], 0)
    known = accept_bindings(r, 0, 2, records, {})
    terminal, _ = encode_frame(r, 2, 3, known)
    assert struct.unpack_from('<2Q', terminal, 40) == tuple(tokens)
    assert parse_response(struct.pack('<8sQQQ', b'HTORSP03', 3, 0, 7), r.commands[2:], 7) == []
    rejected = 0
    for bad in (struct.pack('<8sQQQ', b'HTORSP01', 1, 0, 7),
                struct.pack('<8sQQQ', b'HTORSP03', 3, 1, 7),
                struct.pack('<8sQQQ', b'HTORSP03', 3, 0, 7) + b'x'):
        try:
            parse_response(bad, r.commands[2:], 7)
        except ValueError:
            rejected += 1
        else:
            raise AssertionError('malformed refusal accepted')
    missing = {}
    try:
        encode_frame(r, 2, 3, missing)
    except ValueError:
        rejected += 1
    else:
        raise AssertionError('missing earlier-frame native identity accepted')
    source = '706673d47858a47fafeefe9f40aed6c52e5181caa4183ec12f72151385ca84e3'
    image = '589367e5db70847c727e8d1005680dc5e8f73d536d887c9bb2c30c41db4ae9c4'
    owner, owner_proof, _ = owner_module(source, image)
    admission, _ = admission_module(source, image)
    assert owner.SOURCE == admission.SOURCE == source and owner.IMAGE == admission.IMAGE == image
    for path in HERE.rglob('*.py'):
        ast.parse(path.read_bytes())
    assert 'torch' not in sys.modules
    result = {'schema': 'heptatorch.current270.pure-source-wire-check.v1',
              'status': 'PASS_PURE_SOURCE_AND_WIRE_ONLY',
              'original_comparator_whole_inverses': len(proof['comparator_overlay']),
              'owner_inverse': owner_proof['whole_inverse_exact'],
              'protocol_rejection_controls': rejected,
              'actual_native_responses_used': False,
              'native_executed': False, 'Torch_imported': False,
              'expected_tensor_values_computed': False,
              'runtime_qualification': 'NOT_RUN'}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
