"""Run the selected current HIA ELF; preserve every actual frame separately."""
import gzip
import json
import os
import select
import struct
import subprocess
import time
import traceback
from pathlib import Path

from wire import MIB, accept_bindings, encode_frame, parse_response, require, sha


class NativeTransport:
    def __init__(self, executable, directory, owner, expected_image_sha256):
        self.executable = Path(executable).resolve(strict=True)
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=False)
        self.owner = owner
        self.expected_image_sha256 = expected_image_sha256
        self.cases = []

    def execute(self, name, program, expected_status=0):
        require(type(expected_status) is int and expected_status in (0, 2, 5, 7),
                'unreviewed original270 refusal status')
        count = len(program.commands)
        require(count > 0, 'empty original case')
        if expected_status:
            require(count >= 3 and program.commands[-1][0] in (29, 36, 37),
                    'only the original single terminal indexed rejection is adapted')
        require(name not in {c['case'] for c in self.cases}, 'duplicate original270 case')
        directory = self.directory / (str(len(self.cases)).zfill(3) + '-' + sha(name.encode())[:16])
        directory.mkdir(exist_ok=False)
        record = {'case': name, 'status': 'FAIL', 'native_started': False,
                  'whole_original_request_sha256': sha(program.encode()),
                  'original_commands': count, 'expected_status': expected_status,
                  'requests': [], 'native_exit': None, 'stdout_EOF': False,
                  'stderr_EOF': False, 'unexpected_stdout_bytes': None,
                  'stderr_bytes': None, 'owner_snapshots': [], 'error': None,
                  'same_process_success_prefix_and_refusal': bool(expected_status),
                  'synthetic_native_response_records': False,
                  'full_private_allocation_transition_ledger_claimed': False}
        process = None
        deadline = time.monotonic() + 120.0  # Same complete-case limit as the original subprocess.run.
        started = time.monotonic()
        primary, terminal = None, None
        bindings = {}
        sent_stream = (directory / 'actual.stdin').open('xb')
        received_stream = (directory / 'actual.stdout').open('xb')

        def remaining():
            value = deadline - time.monotonic()
            require(value > 0, 'native complete-case 120-second deadline')
            return value

        def write_all(raw):
            view = memoryview(raw)
            while view:
                require(select.select([], [process.stdin], [], remaining())[1], 'native write timeout')
                try:
                    wrote = os.write(process.stdin.fileno(), view)
                except BlockingIOError:
                    continue
                require(wrote > 0, 'native closed request pipe')
                sent_stream.write(view[:wrote])
                sent_stream.flush()
                view = view[wrote:]

        def read_exact(length):
            pieces = bytearray()
            while len(pieces) < length:
                require(select.select([process.stdout], [], [], remaining())[0], 'native response timeout')
                try:
                    part = os.read(process.stdout.fileno(), length - len(pieces))
                except BlockingIOError:
                    continue
                require(part, 'premature native stdout EOF')
                received_stream.write(part)
                received_stream.flush()
                pieces.extend(part)
            return bytes(pieces)

        def snapshot(label, reader):
            remaining()
            value = reader.snapshot()
            verified = self.owner.verify_snapshot(value)
            raw = json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
            path = directory / (label + '.json.gz')
            with gzip.open(path, 'xb', compresslevel=1) as stream:
                stream.write(raw)
            record['owner_snapshots'].append({'label': label, 'file': path.name,
                'snapshot_sha256': sha(raw), 'full_owner_sha256': value['full_sha256'],
                'owner_bytes': value['length'], 'verification': verified})
            remaining()
            return value

        try:
            process = subprocess.Popen([str(self.executable)], stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0, env={'PATH': ''})
            record['native_started'] = True
            record['executed_image_sha256'] = sha(Path('/proc/%d/exe' % process.pid).read_bytes())
            require(record['executed_image_sha256'] == self.expected_image_sha256,
                    'actual child executable differs from the selected cold image')
            for stream in (process.stdin, process.stdout):
                os.set_blocking(stream.fileno(), False)
            reader = self.owner.OwnerReader(process)
            ranges = [(0, count, 0)] if not expected_status else [(0, count - 1, 0), (count - 1, count, expected_status)]
            for number, (start, stop, status) in enumerate(ranges):
                before = snapshot('%02d-before' % number, reader)
                body, proof = encode_frame(program, start, stop, bindings)
                framed = b'HTOWNR01' + struct.pack('<Q', len(body)) + body
                (directory / ('%02d-request.bin' % number)).write_bytes(framed)
                write_all(framed)
                header = read_exact(16)
                magic, size = struct.unpack('<8sQ', header)
                require(magic == b'HTOWNS01' and 32 <= size <= MIB, 'current native outer frame')
                response = read_exact(size)
                (directory / ('%02d-response.bin' % number)).write_bytes(header + response)
                require(process.poll() is None and not process.stdin.closed,
                        'native response must precede stdin EOF')
                rows = parse_response(response, program.commands[start:stop], status)
                after = snapshot('%02d-after' % number, reader)
                if status:
                    require(before['pointer'] == after['pointer']
                            and before['length'] == after['length']
                            and before['full_sha256'] == after['full_sha256']
                            and self.owner.semantic(before) == self.owner.semantic(after),
                            'current atomic terminal refusal changed the complete owner')
                    terminal = response
                else:
                    bindings = accept_bindings(program, start, stop, rows, bindings)
                    primary = response
                record['requests'].append({'frame': number, **proof,
                    'request_sha256': sha(framed), 'response_sha256': sha(header + response),
                    'response_body_bytes': len(response), 'actual_status': status,
                    'actual_records': len(rows), 'response_before_stdin_EOF': True,
                    'complete_owner_rollback': True if status else None})
            process.stdin.close()
            record['native_exit'] = process.wait(timeout=min(20.0, remaining()))
            # The process has exited; blocking reads now reach actual EOF.
            os.set_blocking(process.stdout.fileno(), True)
            tail, stderr = process.stdout.read(), process.stderr.read()
            received_stream.write(tail)
            received_stream.flush()
            (directory / 'unexpected.stdout').write_bytes(tail)
            (directory / 'native.stderr').write_bytes(stderr)
            record.update(stdout_EOF=True, stderr_EOF=True,
                          unexpected_stdout_bytes=len(tail), stderr_bytes=len(stderr))
            require(record['native_exit'] == 0 and not tail and not stderr,
                    'native final exit or complete EOF assertion failed')
            require(primary is not None and len(record['requests']) == len(ranges),
                    'incomplete actual case transport')
            if expected_status:
                require(terminal is not None, 'missing actual terminal refusal')
            result = subprocess.CompletedProcess([str(self.executable)], 0, primary, b'')
            result.current_failure = terminal
            result.terminal_command = program.commands[-1][0] if expected_status else None
            record['status'] = 'PASS_ACTUAL_TRANSPORT'
            return result
        except BaseException as error:
            record['error'] = {'type': type(error).__name__, 'message': str(error),
                               'traceback': traceback.format_exc()}
            raise
        finally:
            if process is not None and process.poll() is None:
                process.kill()
                record['native_exit'] = process.wait(timeout=10)
            if process is not None:
                if not record['stdout_EOF']:
                    os.set_blocking(process.stdout.fileno(), True)
                    remaining_stdout = process.stdout.read()
                    received_stream.write(remaining_stdout)
                    received_stream.flush()
                    record['stdout_EOF'] = True
                    (directory / 'failure-tail.stdout').write_bytes(remaining_stdout)
                if not record['stderr_EOF']:
                    stderr = process.stderr.read()
                    (directory / 'native.stderr').write_bytes(stderr)
                    record.update(stderr_EOF=True, stderr_bytes=len(stderr))
                for stream in (process.stdin, process.stdout, process.stderr):
                    if stream is not None and not stream.closed:
                        stream.close()
            sent_stream.close()
            received_stream.close()
            record['wall_seconds'] = time.monotonic() - started
            (directory / 'transport.json').write_text(json.dumps(record, indent=2) + '\n')
            self.cases.append(record)
