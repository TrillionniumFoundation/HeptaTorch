"""Execute the frozen Scalar07b compiler intent once; no Torch or business replay."""
import hashlib
import json
import os
import re
from pathlib import Path
import stat
import subprocess
import time
import traceback

RUNS = Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
HANDOFF = RUNS / 'differentiable-view-r4-scalar-source-handoff-07b'
OUTPUT = RUNS / 'differentiable-view-r4-scalar07b-native-build-01'
MANIFEST = '0ea8b5d66f99ec5290163c2534f94a08f2a58c2421bff425bcf612b952120fd2'
INTENT = '7a55e0267d93a1262fe297f1731f13ab91861db0dc97d8db75436eae570d6560'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def info(path):
    p = Path(path)
    s = p.stat()
    assert stat.S_ISREG(s.st_mode) and not p.is_symlink(), str(p)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b),
            'mode': stat.S_IMODE(s.st_mode)}


def write(name, value):
    p = OUTPUT / name
    p.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    p.chmod(0o600)


def main():
    OUTPUT.mkdir(exist_ok=False)
    report = {'schema': 'heptatorch.r4-scalar07b-independent-compile-execution.v1',
              'status': 'PREPARING', 'compiler_driver_started': False,
              'compiler_driver_completed': False, 'Torch_executed': False,
              'native_business_executed': False,
              'started_at_unix_ns': time.time_ns()}
    rc = 1
    before = {}
    try:
        mr = (HANDOFF / 'source-manifest.json').read_bytes()
        ir = (HANDOFF / 'compile-intent.json').read_bytes()
        assert sha(mr) == MANIFEST and sha(ir) == INTENT
        manifest, intent = json.loads(mr), json.loads(ir)
        assert manifest['schema'] == 'heptatorch.scalar64.source-packet.v1'
        assert manifest['member_count'] == len(manifest['members']) == 106
        assert intent['not_started'] is True and intent['runtime_qualified'] is False
        assert intent['execution_owner'] == '/root/autograd_extension'
        assert intent['stable_key'] == 'heptatorch-dview-r4-scalar07b-child13-native-build-20261117-v1'
        prepared_path = RUNS / 'differentiable-view-r4-scalar-prepare-07b/build.json'
        assert info(prepared_path)['sha256'] == 'da92a5e395e212829da5263425b762e6d5872934b27570f31162a5f455222a46'
        prepared = json.loads(prepared_path.read_bytes())
        assert prepared['status'] == 'PREPARED_NOT_COMPILED' and prepared['units_planned'] == 13
        assert all(x['native_compile_started'] is False for x in prepared['units'])
        assert info(HANDOFF / 'complete.tar.xz')['sha256'] == 'cafe0c20a3d639ee23040b04547f390e4e6a07b8c7d8a00149b010b135f5d6ab'
        assert intent['argv'][-2] == '--output'
        candidate = Path(intent['argv'][-1])
        assert candidate == OUTPUT / 'candidate-r4-scalar07b' and not candidate.exists()
        for row in manifest['members']:
            obs = info(row['source_path'])
            assert all(obs[k] == row[k] for k in ('bytes', 'sha256', 'mode')), row
            before[obs['path']] = obs
        for p in (HANDOFF / 'source-manifest.json', HANDOFF / 'complete.tar.xz',
                  Path(__file__).resolve(), RUNS / 'differentiable-view-r4-scalar07b-compile-request-01.json'):
            before[str(p)] = info(p)
        before[str(HANDOFF / 'compile-intent.json')] = info(HANDOFF / 'compile-intent.json')
        source_review_path = RUNS / 'scalar07b-autograd-selected-source-review.json'
        source_review = info(source_review_path)
        assert source_review['sha256'] == '1aa565081dc178999887bbc903e4c8cdbc8ab078cfb866cbd9d2a1f99480f671'
        before[str(source_review_path)] = source_review
        source_review_data = json.loads(source_review_path.read_bytes())
        assert source_review_data['status'] == 'PASS_SELECTED_SOURCE_REVIEW_ONLY'
        assert source_review_data['prepared_source_sha256'] == intent['expected_source_sha256']
        assert all(source_review_data[k] is False for k in
                   ('native_executed', 'Torch_executed', 'compiler_executed', 'emitter_executed'))
        for path, binding in source_review_data['inputs'].items():
            item = info(path)
            assert all(item[k] == binding[k] for k in ('bytes', 'sha256')), path
            before[path] = item
        report['independent_source_review'] = source_review
        def function_bodies(raw):
            matches = list(re.finditer(rb'(?ms)^fn ([A-Za-z0-9_]+)\\(.*?^end\\n', raw))
            result = {m.group(1).decode(): m.group(0) for m in matches}
            assert len(result) == len(matches)
            return result
        previous06 = RUNS / 'differentiable-view-r4-scalar06-native-build-01/candidate-r4-scalar06/runtime.hepta'
        before[str(previous06)] = info(previous06)
        assert before[str(previous06)]['sha256'] == '743c6de8c4f2e9ea6dbb880aca5a27c719c2b14ce05e7262020ece63b1ccd148'
        original_bodies = function_bodies(previous06.read_bytes())
        prepared_raw = (prepared_path.parent / 'runtime.hepta').read_bytes()
        assert sha(prepared_raw) == intent['expected_source_sha256']
        next_bodies = function_bodies(prepared_raw)
        changed = sorted(n for n in original_bodies if original_bodies[n] != next_bodies[n])
        added = sorted(set(next_bodies) - set(original_bodies))
        assert len(original_bodies) == 656 and len(next_bodies) == 658
        assert changed == ['incoming_describe', 'incoming_mark_preserve_targets', 'retained_apply']
        assert added == ['scalar_previous_incoming_describe', 'scalar_previous_incoming_mark_preserve_targets']
        assert sum(original_bodies[n] == next_bodies[n] for n in original_bodies) == 653
        for original_name in ('incoming_describe', 'incoming_mark_preserve_targets'):
            alias = 'scalar_previous_' + original_name
            assert next_bodies[alias].replace(('fn '+alias+'(').encode(), ('fn '+original_name+'(').encode(), 1) == original_bodies[original_name]
        old_call = b'  v220:u64 = call(v219,v209) {"function":"addf"}\\n'
        new_call = b'  v220:u64 = call(v219,v209) {"function":"scalar_add_preserving_bits"}\\n'
        assert original_bodies['retained_apply'].count(old_call) == 1
        assert original_bodies['retained_apply'].replace(old_call, new_call) == next_bodies['retained_apply']
        descriptor_path = RUNS / 'hia-r4-wrapped-scalar-source-review-02/typed_descriptor.hepta'
        assert sha(descriptor_path.read_bytes()) == 'eed87bc2f1ff9db405584a249d0548a47703d73a8df4df3f0a6c3cb386925ff2'
        assert next_bodies['scalar_previous_typed_descriptor'].replace(b'fn scalar_previous_typed_descriptor(', b'fn typed_descriptor(', 1) == descriptor_path.read_bytes()
        report['whole_prepared_body_inverse'] = {'source06_sha256': before[str(previous06)]['sha256'],
            'source07b_sha256': intent['expected_source_sha256'], 'unchanged': 653,
            'changed': changed, 'added': added, 'aliases_exact': True,
            'retained_single_call_inverse': True, 'rank0_descriptor_alias_exact': True}
        args = intent['argv']
        for flag in ('--compiler', '--linker', '--compactor'):
            p = Path(args[args.index(flag) + 1])
            before[str(p)] = info(p)
        for flag,key in (('--compiler','compiler_sha256'),('--linker','linker_sha256')):
            assert info(args[args.index(flag)+1])['sha256'] == prepared[key]
        for path,pin in prepared['inputs_sha256'].items():
            item = info(path)
            assert item['sha256'] == pin, path
            before[path] = item
        parent = Path(args[args.index('--previous') + 1])
        parent_report = json.loads((parent / 'build.json').read_bytes())
        for p in parent.iterdir():
            if p.is_file() and (p.suffix in ('.hepta', '.o', '.py', '.json') or
                               p.name.startswith('tensor-')):
                before[str(p)] = info(p)
        assert parent_report['source_sha256'] == '67307c29c29d3f35c288f1775d883b179a6d1ab6497ac8da004b3a713b20db21'
        assert parent_report['native_sha256'] == 'ef877aa61320746f71956fd34b4d18d5cf4e164e5a0274e3c98301d4fd288ba1'
        write('inputs-before.json', before)
        write('actual-command.json', {'argv': args, 'cwd': intent['cwd'], 'original_intent': intent})
        report.update(source_manifest_sha256=MANIFEST, intent_sha256=INTENT,
                      input_file_count=len(before), idempotency_key=intent['stable_key'])
        write('execution.json', report)
        with (OUTPUT / 'compile.stdout').open('wb') as stdout, (OUTPUT / 'compile.stderr').open('wb') as stderr:
            process = subprocess.Popen(args, cwd=intent['cwd'], stdin=subprocess.DEVNULL,
                                       stdout=stdout, stderr=stderr)
            report.update(compiler_driver_started=True, pid=process.pid,
                          driver_started_at_unix_ns=time.time_ns())
            write('execution.json', report)
            rc = process.wait()
            report.update(compiler_driver_completed=True, driver_returncode=rc,
                          driver_finished_at_unix_ns=time.time_ns())
        report.update(stdout_closed=True, stderr_closed=True,
                      stdout=info(OUTPUT / 'compile.stdout'), stderr=info(OUTPUT / 'compile.stderr'))
        assert rc == 0, rc
        build = json.loads((candidate / 'build.json').read_bytes())
        assert build['status'] == 'PASS'
        assert build['source_sha256'] == intent['expected_source_sha256']
        assert info(candidate / 'runtime.hepta')['sha256'] == intent['expected_source_sha256']
        for k in ('functions', 'blocks', 'instructions'):
            assert build[k] == intent['expected_' + k], k
        assert build['descriptor_bytes'] == 672
        assert build['state_format'] == 'HTVSHP02' and build['backing_format'] == 'HTOVSHP2'
        assert build['runtime_qualified'] is False and build['torch_executed'] is False
        assert build['link_exit'] == 0
        assert len(build['units']) == intent['expected_units'] == 13
        products = {}
        for got, expected in zip(build['units'], prepared['units'], strict=True):
            assert got['name'] == expected['name'] and got['source_sha256'] == expected['source_sha256']
            assert got['compiler_exit'] == 0
            for suffix, field in (('.hepta', 'source_sha256'), ('.o', 'object_sha256')):
                p = candidate / (got['name'] + suffix)
                item = info(p)
                assert item['sha256'] == got[field]
                if suffix == '.o':
                    assert p.read_bytes().startswith(b'\x7fELF')
                products[str(p)] = item
            assert not (candidate / (got['name'] + '.stderr')).read_bytes()
        image = candidate / intent['new_native_basename']
        assert info(image)['sha256'] == build['native_sha256']
        assert image.read_bytes().startswith(b'\x7fELF') and not (candidate / 'link.stderr').read_bytes()
        products[str(image)] = info(image)
        products[str(candidate / 'build.json')] = info(candidate / 'build.json')
        for name,pin in build['inputs_sha256'].items():
            assert name in before and before[name]['sha256'] == pin, name
        for name,pin in build['authoring_inputs_sha256'].items():
            assert info(Path(args[2]).parent/name)['sha256'] == pin
        assert build['compiler_sha256'] == prepared['compiler_sha256']
        assert build['linker_sha256'] == prepared['linker_sha256']
        report.update(status='PASS', source_sha256=build['source_sha256'],
                      native_sha256=build['native_sha256'], build_report=info(candidate / 'build.json'),
                      units=13, functions=build['functions'], blocks=build['blocks'],
                      instructions=build['instructions'], products=products,
                      all_13_units_fresh_compiler_outputs_verified=True,
                      all_prepared_unit_source_pins_matched=True)
    except BaseException as error:
        report.update(status='FAIL', error=repr(error), traceback=traceback.format_exc())
        rc = 1
    finally:
        if before:
            after = {p: info(p) for p in before}
            write('inputs-after.json', after)
            report['all_bound_inputs_unchanged'] = before == after
            if before != after:
                report['status'] = 'FAIL'
                rc = 1
        report['finished_at_unix_ns'] = time.time_ns()
        write('execution.json', report)
        print(json.dumps({k: report.get(k) for k in ('status', 'source_sha256', 'native_sha256',
                         'units', 'functions', 'blocks', 'instructions', 'error')}))
    raise SystemExit(rc)


if __name__ == '__main__':
    main()
