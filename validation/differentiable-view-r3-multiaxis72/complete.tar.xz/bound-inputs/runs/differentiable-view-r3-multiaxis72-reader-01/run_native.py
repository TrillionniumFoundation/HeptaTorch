#!/usr/bin/python3
"""Frozen R3 multiaxis72 replay and custody; no Torch import or numerical model."""
import argparse,hashlib,json,os,signal,struct,subprocess,sys,time,traceback
from pathlib import Path
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')
def check_inputs(pins):
    changed=[]
    for path,expected in pins.items():
        p=Path(path)
        if not p.is_file() or SHA(p.read_bytes())!=expected:
            changed.append(path)
    return changed
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--contract',type=Path,required=True)
    ap.add_argument('--expected-contract-sha256',required=True)
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args()
    raw=a.contract.read_bytes()
    assert SHA(raw)==a.expected_contract_sha256
    c=json.loads(raw)
    pins=c['inputs_sha256']
    assert not check_inputs(pins)
    assert str(Path(__file__).resolve()) in pins
    source=Path(c['source']);binary=Path(c['binary'])
    build=json.loads(Path(c['build_report']).read_bytes())
    assert (build['status'],build['functions'],build['blocks'],build['instructions'],len(build['units']))==('PASS',627,8245,29636,13)
    assert (build['descriptor_bytes'],build['state_format'],build['backing_format'])==(672,'HTVAD003','HTOVAD03')
    assert build['source_sha256']==pins[str(source)] and build['native_sha256']==pins[str(binary)]
    assert len({u['name'] for u in build['units']})==13
    for u in build['units']:
        assert u['compiler_exit']==0
        assert pins[str(source.parent/(u['name']+'.hepta'))]==u['source_sha256']
        assert pins[str(source.parent/(u['name']+'.o'))]==u['object_sha256']
    assert source.read_bytes().count(b'\nfn ')+(source.read_bytes().startswith(b'fn '))==627
    reference=json.loads(Path(c['reference']).read_bytes())
    assert (reference['cases'],reference['observed'],reference['errors'],len(reference['rows']))==(72,72,0,72)
    assert reference['raw_gradient_words']==21312
    provenance=reference['oracle_provenance']
    expected_checks={'python_matches','platform_matches','version_backend_matches',
      'git_matches_oracle_build_pin','distribution_version_matches','direct_url_matches',
      'direct_url_archive_sha256_matches','pip_report_url_matches',
      'pip_report_archive_sha256_matches','pip_report_version_matches','pip_report_requested'}
    assert provenance['status']=='PASS' and set(provenance['checks'])==expected_checks
    assert all(value is True for value in provenance['checks'].values())
    settings=reference['execution_settings']
    assert settings=={'num_threads':1,'deterministic_algorithms':True,'fill_uninitialized_memory':True,'mkldnn':False}
    assert len({r['case'] for r in reference['rows']})==72
    for r in reference['rows']:
        assert r['status']=='OBSERVED' and len(r['base_grad_bits'])==256
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
    cmd=[sys.executable,'-B',c['reader'],'--count','72','--output',str(out/'observed')]
    execution={'schema':'heptatorch.multiaxis72.r3-execution.v1','status':'STARTING',
      'contract_sha256':a.expected_contract_sha256,'argv':cmd,
      'inputs_sha256':pins,'inputs_modes':{p:Path(p).stat().st_mode&0o777 for p in pins},
      'native_executed':False,'torch_executed':False,
      'reader_process_started':False,'reader_process_completed':False,
      'scope':c['scope'],'input_mapping':c['input_mapping'],
      'source_sha256':pins[str(source)],'native_sha256':pins[str(binary)],
      'build_report_sha256':pins[c['build_report']],'functions':627,'native_units':13}
    write(out/'command.json',cmd);write(out/'execution.json',execution)
    child=None;started=time.time()
    try:
        with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
            child=subprocess.Popen(cmd,cwd=c['cwd'],stdout=stdout,stderr=stderr,start_new_session=True)
            execution.update(reader_process_started=True,reader_pid=child.pid)
            write(out/'execution.json',execution)
            try:
                code=child.wait(timeout=600)
            except subprocess.TimeoutExpired:
                execution['reader_timed_out']=True
                os.killpg(child.pid,signal.SIGKILL);code=child.wait()
            execution.update(reader_process_completed=True,exit_code=code)
        report_path=out/'observed/report.json'
        assert report_path.is_file()
        report=json.loads(report_path.read_bytes())
        execution['inner_report_sha256']=SHA(report_path.read_bytes())
        execution['inner_counts']={k:report[k] for k in ('cases_requested','passed','failed','errors')}
        transport=[];input_witnesses=[]
        original_base=struct.pack('<256f',*range(256))
        expected_create=(b'HTORCH03'+struct.pack('<3Q',1,1184,0)+
          struct.pack('<8Q',97,0,96,0,0,0,0,0)+
          struct.pack('<8Q',1,0,256,0,0,0,160,1024)+original_base)
        assert len(expected_create)==1184
        for index,row in enumerate(report['rows']):
            rawdir=out/'observed'/('case-%02d'%index)/'raw'
            p=rawdir/'transport.json'
            t=json.loads(p.read_bytes());transport.append(t)
            execution['native_executed'] |= t.get('frames',0)>0
            with (rawdir/'requests.frames.bin').open('rb') as stream:
                header=stream.read(16)
                assert len(header)==16
                size=struct.unpack_from('<Q',header,8)[0]
                body=stream.read(size)
            same=body==expected_create
            input_witnesses.append({'case':row['case'],'exact_arange256_create_packet':same,
              'request_body_sha256':SHA(body),'expected_request_body_sha256':SHA(expected_create)})
        execution['input_witnesses']=input_witnesses
        execution['frames']=sum(t['frames'] for t in transport)
        execution['all_sessions_eof_exit_zero']=(len(transport)==72 and all(t.get('exit_code')==0 and t.get('responses_before_stdin_eof') is True and t.get('executable_sha256')==pins[str(binary)] for t in transport))
        execution['all_arange_inputs_exact']=(len(input_witnesses)==72 and all(x['exact_arange256_create_packet'] for x in input_witnesses))
        execution['exact_gradient_words']=sum(row.get(name+'_observed_words',0) for row in report['rows'] for name in ('base','view'))
        matches=(report['cases_requested']==72 and len(report['rows'])==72 and
          all(x['case']==y['case'] for x,y in zip(report['rows'],reference['rows'])) and
          report['passed']==72 and report['failed']==0 and report['errors']==0 and
          all(x['status']=='PASS' and x.get('base_mismatches')==0 and x.get('view_mismatches')==0 and x.get('finished_without_wire_error') is True for x in report['rows']))
        execution['all_original_gradient_comparisons_pass']=matches
        execution['status']='PASS' if (code==0 and matches and execution['all_sessions_eof_exit_zero'] and execution['all_arange_inputs_exact'] and execution['exact_gradient_words']==21312) else 'FAIL'
    except BaseException as error:
        execution.update(status='HOST_ERROR',host_error=repr(error),traceback=traceback.format_exc())
    finally:
        changed=check_inputs(pins)
        execution['inputs_changed']=changed
        execution['all_inputs_unchanged']=not changed
        if changed:execution['status']='INPUT_CUSTODY_FAIL'
        execution['wall_seconds']=time.time()-started
        for name in ('stdout.log','stderr.log'):
            p=out/name
            if p.is_file():
                execution[name+'_sha256']=SHA(p.read_bytes())
                execution[name+'_bytes']=p.stat().st_size
        write(out/'execution.json',execution)
    print(json.dumps({k:v for k,v in execution.items() if k not in ('inputs_sha256','inputs_modes','argv','input_witnesses')},indent=2))
    return 0 if execution['status']=='PASS' else 1
if __name__=='__main__':
    raise SystemExit(main())
