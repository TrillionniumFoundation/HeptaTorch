"""Independent pinned PyTorch 2.15.0 AsStrided multi-axis backward oracle.
No native implementation, no inferred expected values and no PyTorch use by production.
Each row contains actual float32 bit patterns, dtype, layout and version metadata.
"""
from pathlib import Path
import hashlib, json, os, sys, struct, tarfile, io, platform, traceback
ROOT = Path('/home/qian-qi/heptatorch-continuation-20261116')
REPO = ROOT / 'repo-pr28-repair'
OUT = ROOT / 'runs/independent-asstrided-multiaxis-20261116-v1'
assert OUT.is_dir()
os.chdir(REPO)
provenance_path = REPO / 'tests/pytorch_oracle.py'
raw_provenance = provenance_path.read_bytes()
assert b'\nclass Program:' in raw_provenance
old_argv = sys.argv
sys.argv = [str(provenance_path), '/dev/null', str(OUT/'provenance-failure.json'), str(REPO/'compatibility/pytorch-oracle-lock.json')]
scope = {'__name__':'pinned_heptatorch_provenance_provider', '__file__':str(provenance_path)}
try:
    exec(compile(raw_provenance.split(b'\nclass Program:')[0],str(provenance_path),'exec'),scope)
finally:
    sys.argv = old_argv
assert scope['PROVENANCE']['status'] == 'PASS'
assert len(scope['PROVENANCE']['checks']) == 11 and all(v is True for v in scope['PROVENANCE']['checks'].values())
torch=scope['torch']
torch.set_num_threads(1)
torch.use_deterministic_algorithms(True, warn_only=False)
torch.utils.deterministic.fill_uninitialized_memory=True
torch.backends.mkldnn.enabled=False
shape_specs=[
    ('dense3', (2,3,4),(12,4,1),7),
    ('parity_strided3',(2,3,4),(1,8,2),13),
    ('outer_zero3',(2,3,4),(0,8,2),13),
    ('middle_zero3',(2,3,4),(12,0,1),4),
    ('double_zero3',(2,3,4),(0,0,1),9),
    ('ends_zero3',(2,3,4),(0,1,0),9),
    ('inner_double_zero3',(2,3,4),(1,0,0),9),
    ('all_zero3',(3,2,4),(0,0,0),15),
    ('mixed_zero3',(2,3,4),(1,2,0),30),
    ('overlap_nonzero3',(2,3,4),(3,1,2),30),
    ('zero_and_overlap3',(2,3,4),(0,3,1),30),
    ('zero_repeat3',(2,3,4),(3,0,2),30),
    ('front_zero4',(1,4,3,2),(0,0,2,1),37),
    ('big_zero4',(2,3,4,5),(0,0,5,1),5),
    ('parity_zero4',(2,3,4,5),(1,0,10,2),10),
    ('triple_zero4',(2,3,4,5),(0,0,0,1),39),
    ('middle_zero4',(2,3,4,5),(20,0,5,1),0),
    ('outer_zero4',(2,3,4,5),(0,20,5,1),2),
    ('empty_outer3',(0,3,4),(12,4,1),0),
    ('empty_middle3',(2,0,4),(0,0,1),0),
    ('zero_row2',(3,4),(0,1),50),
    ('zero_col2',(3,4),(1,0),50),
    ('dense2',(3,4),(4,1),50),
    ('transpose2',(3,4),(1,3),50),
]
seed_modes=('negative_zero','mixed_qnan','finite_cancel')
def rawbits(t):
    v=t.detach().contiguous().view(torch.int32).reshape(-1).tolist()
    return [int(x)&0xffffffff for x in v]
def summarise(bits):
    return {'negative_zero':sum(x==0x80000000 for x in bits),
            'positive_zero':sum(x==0 for x in bits),
            'negative_qnan_payload':sum(x==0xffc01234 for x in bits),
            'positive_qnan_payload':sum(x==0x7fc34567 for x in bits),
            'nan_total':sum((x&0x7f800000)==0x7f800000 and (x&0x007fffff)!=0 for x in bits)}
def seeds(mode,n):
    if mode=='negative_zero': return [0x80000000]*n
    if mode=='mixed_qnan':
        pool=[0xffc01234,0x7fc34567,0x80000000,0x3f800000,0x00000000,0xbf800000]
    else:
        pool=[0x3f800000,0xbf800000,0x33800000,0xb3800000,0x80000000,0x00000000]
    return [pool[i%len(pool)] for i in range(n)]
rows=[]
for name, shape, stride, offset in shape_specs:
    n=1
    for v in shape:n*=v
    for mode in seed_modes:
        row={'case':name+'__'+mode,'shape':list(shape),'strides':list(stride),'storage_offset':offset,'seed_mode':mode,'status':'NOT_RUN'}
        try:
            base=torch.arange(256,dtype=torch.float32,device='cpu').requires_grad_(True)
            view=base.as_strided(shape,stride,offset)
            view.retain_grad()
            copy=view.to(dtype=torch.float32,copy=True)
            expected_seed_bits=seeds(mode,n)
            signed=[x if x<0x80000000 else x-0x100000000 for x in expected_seed_bits]
            seed=torch.tensor(signed,dtype=torch.int32).view(torch.float32).reshape(shape)
            assert rawbits(seed)==expected_seed_bits
            baseV0,viewV0,copyV0=int(base._version),int(view._version),int(copy._version)
            copy.backward(seed)
            assert base.grad is not None and view.grad is not None
            assert int(base.grad.numel())==256 and int(view.grad.numel())==n
            row.update(status='OBSERVED',numel=n,base_is_leaf=bool(base.is_leaf),
                view_base_is_base=(view._base is base),copy_is_distinct=(copy is not view),
                base_version=[baseV0,int(base._version)],view_version=[viewV0,int(view._version)],
                copy_version=[copyV0,int(copy._version)],copy_grad_fn=type(copy.grad_fn).__name__,
                view_grad_fn=type(view.grad_fn).__name__,
                seed_bits=expected_seed_bits,view_grad_bits=rawbits(view.grad),
                base_grad_bits=rawbits(base.grad),
                view_grad_stride=list(view.grad.stride()),
                base_grad_stride=list(base.grad.stride()),
                seed_summary=summarise(expected_seed_bits),
                view_grad_summary=summarise(rawbits(view.grad)),
                base_grad_summary=summarise(rawbits(base.grad)))
        except Exception as exc:
            row.update(status='ERROR',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc())
        rows.append(row)
report={
  'schema':'heptatorch.independent-pytorch-asstrided-multiaxis-bit-oracle.v1',
  'status':'OBSERVED' if all(r['status']=='OBSERVED' for r in rows) else 'PARTIAL',
  'scope':'Reference-only: pinned CPU PyTorch AsStridedBackward through actual Tensor.to(copy=True); never a HIA numerical pass',
  'reference_backend':'torch.as_strided plus Tensor.to(copy=True) plus autograd on real pinned CPU wheel',
  'cases':len(rows),'observed':sum(r['status']=='OBSERVED' for r in rows),
  'errors':sum(r['status']=='ERROR' for r in rows),
  'shape_families':len(shape_specs),'seed_modes':list(seed_modes),
  'raw_gradient_words':sum(len(r.get('base_grad_bits',[]))+len(r.get('view_grad_bits',[])) for r in rows),
  'provenance_source_sha256':hashlib.sha256(raw_provenance).hexdigest(),
  'repo_git_head':'30ea38d3572a18ede2dda80decc2fcb4a83feb84',
  'oracle_provenance':scope['PROVENANCE'],
  'execution_settings':{'num_threads':torch.get_num_threads(),'deterministic_algorithms':torch.are_deterministic_algorithms_enabled(),
                        'fill_uninitialized_memory':torch.utils.deterministic.fill_uninitialized_memory,
                        'mkldnn':torch.backends.mkldnn.enabled},
  'rows':rows
}
raw=json.dumps(report,indent=2,allow_nan=False).encode()+b'\n'
(OUT/'actual.json').write_bytes(raw)
assert report['cases']==24*3 and report['observed']==report['cases'] and report['errors']==0
manifest={'schema':'heptatorch.independent-asstrided-evidence-manifest.v1','status':'OBSERVED_REFERENCE_ONLY',
    'files':[]}
for name in ('probe.py','actual.json'):
    data=(OUT/name).read_bytes()
    manifest['files'].append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':'0644'})
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(OUT/'original-evidence.tar.xz','w:xz') as tar:
    for name in ('probe.py','actual.json','manifest.json'):
        data=(OUT/name).read_bytes()
        i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;i.uid=i.gid=0;i.mtime=0
        tar.addfile(i,io.BytesIO(data))
with tarfile.open(OUT/'original-evidence.tar.xz','r:xz') as tar:
    names=tar.getnames()
    assert names==['probe.py','actual.json','manifest.json']
    for name in names:assert tar.extractfile(name).read()==(OUT/name).read_bytes()
summary={'status':report['status'],'cases':len(rows),'errors':report['errors'],'source_sha256':hashlib.sha256((OUT/'probe.py').read_bytes()).hexdigest(),
 'report_sha256':hashlib.sha256(raw).hexdigest(),'report_bytes':len(raw),'archive_sha256':hashlib.sha256((OUT/'original-evidence.tar.xz').read_bytes()).hexdigest(),
 'archive_bytes':(OUT/'original-evidence.tar.xz').stat().st_size,'raw_gradient_words':report['raw_gradient_words'],
 'provenance_check_count':len(report['oracle_provenance']['checks']),'out':str(OUT)}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
