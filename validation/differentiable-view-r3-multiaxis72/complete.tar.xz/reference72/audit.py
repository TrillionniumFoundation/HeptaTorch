"""Read-only, no-Torch verifier for the independent multi-axis AsStrided oracle.
This qualifies an original PyTorch observation packet, NOT an HIA runtime.
"""
from pathlib import Path
import copy,hashlib,itertools,json,collections,struct,tarfile,io
ROOT=Path('/home/qian-qi/heptatorch-continuation-20261116')
OUT=ROOT/'runs/independent-asstrided-multiaxis-20261116-v1'
REPO=ROOT/'repo-pr28-repair'
SPECS=[
('dense3',(2,3,4),(12,4,1),7),('parity_strided3',(2,3,4),(1,8,2),13),
('outer_zero3',(2,3,4),(0,8,2),13),('middle_zero3',(2,3,4),(12,0,1),4),
('double_zero3',(2,3,4),(0,0,1),9),('ends_zero3',(2,3,4),(0,1,0),9),
('inner_double_zero3',(2,3,4),(1,0,0),9),('all_zero3',(3,2,4),(0,0,0),15),
('mixed_zero3',(2,3,4),(1,2,0),30),('overlap_nonzero3',(2,3,4),(3,1,2),30),
('zero_and_overlap3',(2,3,4),(0,3,1),30),('zero_repeat3',(2,3,4),(3,0,2),30),
('front_zero4',(1,4,3,2),(0,0,2,1),37),('big_zero4',(2,3,4,5),(0,0,5,1),5),
('parity_zero4',(2,3,4,5),(1,0,10,2),10),('triple_zero4',(2,3,4,5),(0,0,0,1),39),
('middle_zero4',(2,3,4,5),(20,0,5,1),0),('outer_zero4',(2,3,4,5),(0,20,5,1),2),
('empty_outer3',(0,3,4),(12,4,1),0),('empty_middle3',(2,0,4),(0,0,1),0),
('zero_row2',(3,4),(0,1),50),('zero_col2',(3,4),(1,0),50),
('dense2',(3,4),(4,1),50),('transpose2',(3,4),(1,3),50),
]
MODES=('negative_zero','mixed_qnan','finite_cancel')
def sha(b):return hashlib.sha256(b).hexdigest()
def bits(mode,n):
    if mode=='negative_zero':return [0x80000000]*n
    vals=([0xffc01234,0x7fc34567,0x80000000,0x3f800000,0,0xbf800000] if mode=='mixed_qnan'
          else [0x3f800000,0xbf800000,0x33800000,0xb3800000,0x80000000,0])
    return [vals[i%6] for i in range(n)]
def stat(bs):
    return {'negative_zero':sum(b==0x80000000 for b in bs),
            'positive_zero':sum(b==0 for b in bs),
            'negative_qnan_payload':sum(b==0xffc01234 for b in bs),
            'positive_qnan_payload':sum(b==0x7fc34567 for b in bs),
            'nan_total':sum((b&0x7f800000)==0x7f800000 and (b&0x007fffff)!=0 for b in bs)}
def check(r):
    assert r['schema']=='heptatorch.independent-pytorch-asstrided-multiaxis-bit-oracle.v1'
    assert r['status']=='OBSERVED' and r['cases']==72 and r['observed']==72 and r['errors']==0
    assert r['shape_families']==24 and r['seed_modes']==list(MODES)
    assert r['repo_git_head']=='30ea38d3572a18ede2dda80decc2fcb4a83feb84'
    src=(REPO/'tests/pytorch_oracle.py').read_bytes()
    assert sha(src)==r['provenance_source_sha256']
    lock=(REPO/'compatibility/pytorch-oracle-lock.json').read_bytes()
    p=r['oracle_provenance'];assert p['status']=='PASS' and p['lock_sha256']==sha(lock)
    assert len(p['checks'])==11 and all(v is True for v in p['checks'].values())
    assert p['expected']['version']=='2.15.0+cpu'
    assert p['expected']['git_commit']=='d0f2af8b66b20da4baa50644c0cd3f887a2eae2e'
    assert r['execution_settings']=={'num_threads':1,'deterministic_algorithms':True,
                                     'fill_uninitialized_memory':True,'mkldnn':False}
    assert len(r['rows'])==72
    expect=[f'{name}__{mode}' for name,shape,stride,offset in SPECS for mode in MODES]
    assert [x['case'] for x in r['rows']]==expect
    count=0;checks=0;unique_cases=0;overlap_cases=0;maxfan=0
    for (name,shape,stride,off),mode,x in zip((s for s in SPECS for mode in MODES),MODES*len(SPECS),r['rows']):
        # Match against immutable independent case plan, not the row's fields.
        assert x['status']=='OBSERVED' and x['shape']==list(shape) and x['strides']==list(stride)
        assert x['storage_offset']==off and x['seed_mode']==mode
        n=1
        for v in shape:n*=v
        assert x['numel']==n and len(x['seed_bits'])==len(x['view_grad_bits'])==n
        assert len(x['base_grad_bits'])==256 and len(x['base_grad_stride'])==1
        assert len(x['view_grad_stride'])==len(shape)
        assert x['seed_bits']==bits(mode,n) and x['view_grad_bits']==x['seed_bits']
        assert x['base_version']==[0,0] and x['view_version']==[0,0] and x['copy_version']==[0,0]
        assert x['copy_grad_fn']=='ToCopyBackward0'
        assert x['view_base_is_base'] and x['base_is_leaf'] and x['copy_is_distinct']
        for arr,field in [('seed_bits','seed_summary'),('view_grad_bits','view_grad_summary'),
                          ('base_grad_bits','base_grad_summary')]:
            assert all(type(v)==int and 0<=v<2**32 for v in x[arr])
            assert x[field]==stat(x[arr])
        offs=[off+sum(k*v for k,v in zip(coords,stride))
              for coords in itertools.product(*(range(y) for y in shape))]
        assert len(offs)==n and all(0<=o<256 for o in offs)
        freq=collections.Counter(offs)
        maxfan=max(maxfan,max(freq.values(),default=0))
        assert all(x['base_grad_bits'][i]==0 for i in range(256) if i not in freq)
        if n==len(freq):
            unique_cases+=1
            assert all(x['base_grad_bits'][o]==x['seed_bits'][i] for i,o in enumerate(offs))
        else:overlap_cases+=1
        checks+=30+n+len(freq)
        count+=len(x['view_grad_bits'])+len(x['base_grad_bits'])
    assert count==r['raw_gradient_words']
    return {'status':'PASS','rows':len(r['rows']),'semantic_checks_lower_bound':checks,
            'unique_or_empty_cases':unique_cases,'overlap_cases':overlap_cases,'max_storage_multiplicity':maxfan,
            'raw_gradient_words':count,'provenance_checks':11}
r=json.loads((OUT/'actual.json').read_bytes())
manifest=json.loads((OUT/'manifest.json').read_bytes())
assert [q['path'] for q in manifest['files']]==['probe.py','actual.json']
for row in manifest['files']:
    b=(OUT/row['path']).read_bytes()
    assert sha(b)==row['sha256'] and len(b)==row['bytes']
assert len((OUT/'actual.json').read_bytes())==425385
assert sha((OUT/'actual.json').read_bytes())=='2512acdfeaf98f0aa8d8f44ce37dec48b926244ae274066e6e5b86e919a806e9'
assert sha((OUT/'probe.py').read_bytes())=='6cbf7caa8e532dd030dd8da60fc9763755d4d153357d8c4ae963a02acf4fdc44'
positive=check(r)
negatives=[]
def neg(name,fn):
    q=copy.deepcopy(r)
    fn(q)
    try:check(q)
    except (AssertionError,KeyError,IndexError,ValueError,TypeError):
        negatives.append({'name':name,'status':'EXPECTED_REFUSAL'})
    else:
        raise AssertionError('Mutation unexpectedly accepted: '+name)
neg('drop_case',lambda q:q['rows'].pop())
neg('duplicate_case',lambda q:q['rows'].__setitem__(1,copy.deepcopy(q['rows'][0])))
neg('shape_mutation',lambda q:q['rows'][0]['shape'].__setitem__(0,3))
neg('stride_mutation',lambda q:q['rows'][0]['strides'].__setitem__(0,9))
neg('offset_mutation',lambda q:q['rows'][0].__setitem__('storage_offset',8))
neg('wrong_seed_bits',lambda q:q['rows'][0]['seed_bits'].__setitem__(0,0))
neg('wrong_view_gradient',lambda q:q['rows'][0]['view_grad_bits'].__setitem__(0,0))
neg('wrong_base_gradient',lambda q:q['rows'][0]['base_grad_bits'].__setitem__(7,0))
neg('wrong_base_version',lambda q:q['rows'][0]['base_version'].__setitem__(0,1))
neg('wrong_grad_fn',lambda q:q['rows'][0].__setitem__('copy_grad_fn','AccumulateGrad'))
neg('false_base_alias',lambda q:q['rows'][0].__setitem__('view_base_is_base',False))
neg('false_copy_identity',lambda q:q['rows'][0].__setitem__('copy_is_distinct',False))
neg('wrong_numel',lambda q:q['rows'][0].__setitem__('numel',777))
neg('wrong_source_pin',lambda q:q.__setitem__('provenance_source_sha256','0'*64))
neg('source_check_false',lambda q:q['oracle_provenance']['checks'].__setitem__('python_matches',False))
neg('wrong_threads',lambda q:q['execution_settings'].__setitem__('num_threads',2))
neg('fake_view_summary',lambda q:q['rows'][0]['view_grad_summary'].__setitem__('negative_zero',0))
neg('wrong_unique_base_bit',lambda q:q['rows'][-1]['base_grad_bits'].__setitem__(50,0))
assert len(negatives)==18
audit={'schema':'heptatorch.independent-asstrided-multiaxis-audit.v1',
    'scope':'Exact immutable PyTorch reference; no HIA comparison performed',
    'positive':positive,'negative_controls':negatives,'all_negative_refusals':True,
    'source_sha256':sha((OUT/'probe.py').read_bytes()),
    'original_json_sha256':sha((OUT/'actual.json').read_bytes()),
    'original_archive_sha256':sha((OUT/'original-evidence.tar.xz').read_bytes())}
(OUT/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
with tarfile.open(OUT/'verification-evidence.tar.xz','w:xz') as t:
    for name in ['probe.py','actual.json','manifest.json','original-evidence.tar.xz','audit.py','audit.json']:
        b=(OUT/name).read_bytes();i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;i.uid=i.gid=0;i.mtime=0
        t.addfile(i,io.BytesIO(b))
with tarfile.open(OUT/'verification-evidence.tar.xz','r:xz') as t:
    assert len(t.getmembers())==6
    for m in t:
        assert t.extractfile(m).read()==(OUT/m.name).read_bytes()
print(json.dumps({'positive':positive,'negative_refusals':len(negatives),
 'audit_sha256':sha((OUT/'audit.json').read_bytes()),
 'archive_sha256':sha((OUT/'verification-evidence.tar.xz').read_bytes()),
 'archive_bytes':(OUT/'verification-evidence.tar.xz').stat().st_size}))
