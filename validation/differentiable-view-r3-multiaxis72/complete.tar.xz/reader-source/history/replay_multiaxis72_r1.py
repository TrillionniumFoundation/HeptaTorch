#!/usr/bin/env python3
"""Exact original PyTorch 72-case AsStridedBackward bit replay against pinned native HIA 09b.
No Python numerical oracle: expected bits are immutable real PyTorch observations.
"""
import hashlib, importlib.util, json, struct, argparse, traceback
from pathlib import Path

BASE=Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
REFERENCE=BASE/'independent-asstrided-multiaxis-20261116-v1/actual.json'
BINARY=BASE/'differentiable-view-r1-native-build-01/candidate-r1/tensor-differentiable-view-session'
SOURCE=BASE/'differentiable-view-r1-native-build-01/candidate-r1/runtime.hepta'
PROTOCOL=BASE/'to09b-full35-614-01/execution/fixtures/protocol.py'
OBS=BASE/'differentiable-view-native-reader-r1/native_observer_direct01.py'
EXPECTED={'reference':'2512acdfeaf98f0aa8d8f44ce37dec48b926244ae274066e6e5b86e919a806e9',
 'source':'644c1e3e7828c60b1335794469a7ab38f73cb73b9f364d1b7ec9b83fdf7bf3c5',
 'binary':'526dde8b0e3d1b48511781e0b5d5c5082fd25127cef4df96edfbc41dc99c15ef'}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(path):
 spec=importlib.util.spec_from_file_location('frozen_native09b_observer',path)
 obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj)
 return obj
def words(t):
 raw=bytes.fromhex(t['logical_bytes_hex'])
 assert len(raw)%4==0
 return list(struct.unpack('<%dI'%(len(raw)//4),raw))
def run_case(observer,row,directory):
 directory.mkdir()
 n=observer.Native(BINARY,SOURCE,PROTOCOL,directory)
 res={'case':row['case'],'status':'NOT_RUN','stages':[],'differences':[]}
 try:
  total=len(row['base_grad_bits'])
  base=n.create(0,[total],struct.pack('<%dI'%total,*([0x3f800000]*total)))
  res['stages'].append('native_create_base')
  n.one(90,base,1);res['stages'].append('native_set_requires_grad')
  shape, strides=row['shape'],row['strides']
  cfg=struct.pack('<10Q',len(shape),*shape,*([0]*(4-len(shape))),*strides,
                  *([0]*(4-len(shape))),row['storage_offset'])
  view=n.one(111,base,n.w.Payload(cfg),80)['value'];res['stages'].append('native_as_strided')
  n.one(93,view);res['stages'].append('native_retain_grad')
  cp=n.one(109,view,0,0)['value'];res['stages'].append('native_to_copy')
  seed_bits=row['seed_bits']
  seed=n.create(0,shape,struct.pack('<%dI'%len(seed_bits),*seed_bits))
  res['stages'].append('native_seed_raw_bits')
  n.one(58,cp,seed,0);res['stages'].append('native_backward')
  for name,tok,wanted in [('base',base,row['base_grad_bits']),('view',view,row['view_grad_bits'])]:
   gt=n.one(91,tok)['value']
   if not gt:res['differences'].append({'field':name+'_gradient_absent'});continue
   observed=n.tensor(gt)
   got=words(observed)
   diff=[(i,wanted[i],got[i]) for i in range(min(len(wanted),len(got))) if wanted[i]!=got[i]]
   res[name+'_observed_words']=len(got);res[name+'_expected_words']=len(wanted)
   res[name+'_mismatches']=len(diff)+abs(len(got)-len(wanted))
   res['differences']+= [{'field':name+'.raw_bits','index':i,'expected':a,'actual':b} for i,a,b in diff[:12]]
   res[name+'_version']=observed['version']
   n.one(41,gt)
  res['stages'].append('native_gradient_read')
  res['status']='PASS' if not res['differences'] and all(res.get(n+'_mismatches',-1)==0 for n in ('base','view')) else 'FAIL'
 except BaseException as e:
  res['status']='ERROR';res['error']=repr(e);res['traceback']=traceback.format_exc()[-2500:]
 finally:
  try:
   out=n.finish()
   res['finished_without_wire_error']=True
  except BaseException as e:
   res['finished_without_wire_error']=False;res['finish_error']=repr(e)
 return res
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--count',type=int,default=2);ap.add_argument('--output',required=True)
 a=ap.parse_args();o=Path(a.output);o.mkdir(parents=True,exist_ok=False)
 for k,p in [('reference',REFERENCE),('source',SOURCE),('binary',BINARY)]:
  assert digest(p)==EXPECTED[k],(k,digest(p),EXPECTED[k])
 assert digest(PROTOCOL)=='7a30d7bca140e3a4cc9d63a3e6930b92d2ffd60ad4503895419d8a63e67c8bd9'
 data=json.loads(REFERENCE.read_text())
 assert data['cases']==72 and data['observed']==72 and data['errors']==0
 assert data['oracle_provenance']['status']=='PASS'
 obs=module(OBS)
 rows=[]
 for row in data['rows'][:a.count]:
  try:rows.append(run_case(obs,row,o/('case-%02d'%len(rows))))
  except BaseException as e:rows.append({'case':row['case'],'status':'HARNESS_ERROR','error':repr(e),'traceback':traceback.format_exc()[-2000:]})
 report={'schema':'heptatorch.multiaxis.actual-native09b-independent-replay.v1',
  'reference_sha256':digest(REFERENCE),'native_sha256':digest(BINARY),'source_sha256':digest(SOURCE),
  'observer_sha256':digest(OBS),'cases_requested':a.count,'rows':rows,
  'passed':sum(r['status']=='PASS' for r in rows),
  'failed':sum(r['status']=='FAIL' for r in rows),
  'errors':sum(r['status'] in ('ERROR','HARNESS_ERROR') for r in rows)}
 (o/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'report':str(o/'report.json'),'passed':report['passed'],
  'failed':report['failed'],'errors':report['errors'],'rows':[{'case':r['case'],'status':r['status'],'stages':r.get('stages',[]),'error':r.get('error'),'differences':r.get('differences',[])[:4]} for r in rows]},indent=2))
 return 0 if report['failed']==0 and report['errors']==0 else 2
if __name__=='__main__':raise SystemExit(main())
