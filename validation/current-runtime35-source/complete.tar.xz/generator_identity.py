"""Read-only whole-source/whole-reader inverse for the fixed Generator712 ABI.

This module never imports Torch, opens a native process, or runs a compiler.
Its PASS proves source identity and preservation, not execution qualification.
"""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import stat

HERE = Path(__file__).resolve().parent
PARENT_MANIFEST = '0241d2f320765f1ad53aa28721a4e30304aedc21d7cca8a44668ee5567510f57'
PARENT_SOURCE = '82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313'
SOURCE = 'fac3d413c6c0f6874d224cbea312108ee2c8baa027102d41890d85094a5faa38'
IMAGE = '5b7aac203d2c913d43781f0da45d40e9bac2037c2bc074ec30f8dd663710a805'
MANIFEST = '708e4b642f630604cedb1d2cf566fefcfb3d9afd74a835f5a265d7e51f1ff4e5'
PARITY_TRANSITION = '5b2661f5f21c8d3d3cae708eb4f4be6592010dcb89b1bdb07c325a1873454180'
OLD_HEADER = b'hia-asm.v1 hepta.hia.program.v8 sum_integral_f32_runtime\n'
NEW_HEADER = b'hia-asm.v1 hepta.hia.program.v8 tensor_generator_complete01\n'
CG = ('cg_state_valid', 'cg_stat', 'cg_find', 'cg_mutates', 'cg_payload',
      'cg_validate', 'cg_size', 'cg_reply', 'cg_read', 'cg_initialize', 'cg_apply')
DERIVED = {'admission.py': 'admission.py', 'run.py': 'run.py',
           'observer712.py': 'observer701.py',
           'owner712_structural.py': 'owner701_structural.py',
           'check_report.py': 'check_report.py', 'controls.py': 'controls.py'}
PINS = {
 'tensor701/manifest.json': '63db93823ff79b3f68d69a276ae2eebc7e7718618c188c387b758c5c3ed97a47',
 'tensor701/owners.hepta': '9c02b75c44eee8459c476049f4d9ebe10935d9d9ed8b27f5842c699f8e6a0884',
 'tensor701/rng03.hepta': 'a3fa507339b40435285dc1fa65e3cd519b6a0921a4c93bccf6ea834bb24763a3',
 'tensor701/build.py': 'b9d039c365a8a3988e3add120e8cffa46a4e1297878f4cced30103953b030bfb',
 'generator712/manifest.json': MANIFEST,
 'generator712/owners.hepta': '867a27b3a86634ea6a873909eb8bc16d5d8027c98c7cb9340376fba51312ec86',
 'generator712/rng03.hepta': '7c32981c916bc277e16221cce1c3dd2381ce0018642e21b20836d861cf585865',
 'generator712/cg_model.hepta': '4ca8c5a0ff81cd82cf2ae325085e1ae0450dc8d53b2da8668726cc002e28990f',
 'generator712/build.py': '9c93f8ff3fcfda8358e51a4c12efb3b0e0962abed9b5a750ca32d5a5568ac14d',
 'generator712/transition.json': PARITY_TRANSITION,
 'generator-original/owners.hepta': '09783363390a6bce3dd8e69d3650478e8b16f37348e81204d0dabf2f58e8b5d2',
 'generator-original/model.hepta': 'dbae4d899b8a962716b23119980fe5da22e1c269c4b3efc8fb162a9166eee3ec',
 'generator-original/rng.hepta': 'd0e6f2ff5da90e2f0891ddcd12fc4fff33594423d49538d79f08662ede017e7c',
}
FN = re.compile(rb'^(fn ([A-Za-z_][A-Za-z_0-9]*)\([^\n]* entry\([A-Za-z_][A-Za-z_0-9]*\)\n.*?^end\n)', re.M | re.S)
EXTERNAL = re.compile(rb'^fn [^\n]* external\(\)\n', re.M)


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique_object)


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def bodies(raw):
    matches = FN.findall(raw)
    value = {name.decode(): body for body, name in matches}
    need(len(value) == len(matches), 'duplicate HIA body')
    return value


def invert(raw, edits):
    text = raw.decode()
    for edit in reversed(edits):
        need(set(edit) == {'label', 'before', 'after', 'count'}, 'inverse edit fields')
        need(type(edit['count']) is int and edit['count'] > 0 and edit['after'], 'inverse edit shape')
        need(text.count(edit['after']) == edit['count'], 'inverse multiplicity: ' + edit['label'])
        text = text.replace(edit['after'], edit['before'])
    return text.encode()


def rename(raw, before, after):
    start, finish = b'fn ' + before.encode() + b'(', b'fn ' + after.encode() + b'('
    need(raw.count(start) == 1 and finish not in raw, 'function rename shape')
    return raw.replace(start, finish)


def verify_identity(source_raw):
    """Bind package and provenance bytes; recompute every inverse without execution."""
    files = {}

    def read(relative, expected=None):
        relative = PurePosixPath(relative)
        need(not relative.is_absolute() and '..' not in relative.parts, 'unsafe package path')
        path = HERE.joinpath(*relative.parts)
        need(not path.is_symlink(), 'symlink is not a frozen input')
        before = path.stat()
        need(stat.S_ISREG(before.st_mode), 'nonregular frozen input')
        raw = path.read_bytes()
        after = path.stat()
        need((before.st_size, before.st_ino, before.st_mtime_ns, before.st_mode) ==
             (after.st_size, after.st_ino, after.st_mtime_ns, after.st_mode), 'frozen input changed during read')
        record = {'bytes': len(raw), 'sha256': sha(raw), 'mode': stat.S_IMODE(after.st_mode)}
        if isinstance(expected, str):
            need(record['sha256'] == expected, 'source pin mismatch: ' + str(relative))
        elif expected is not None:
            need(record == expected, 'source bytes/mode mismatch: ' + str(relative))
        key = str(path.resolve())
        need(key not in files or files[key] == record, 'inconsistent source read')
        files[key] = record
        return raw

    parent_manifest = parse(read('parent701/package-manifest.json', PARENT_MANIFEST))
    need(len(parent_manifest['files']) == 26, 'parent package denominator')
    actual_parent_files = {str(p.relative_to(HERE / 'parent701'))
                           for p in (HERE / 'parent701').rglob('*') if p.is_file()}
    need(actual_parent_files == set(parent_manifest['files']) | {'package-manifest.json'},
         'parent package member set')
    parent = {name: read('parent701/' + name, entry)
              for name, entry in parent_manifest['files'].items()}
    frozen = {name for name in parent if name.startswith('frozen/')}
    need({str(p.relative_to(HERE)) for p in (HERE / 'frozen').rglob('*') if p.is_file()} == frozen,
         'original frozen member set')
    for name in sorted(frozen):
        need(read(name, parent_manifest['files'][name]) == parent[name], 'frozen original bytes changed')

    transition_raw = read('generator-identity-transition.json')
    transition = parse(transition_raw)
    need(transition['schema'] == 'heptatorch.current712-original35.identity-transition.v1'
         and transition['status'] == 'SOURCE_ONLY_NOT_EXECUTED', 'wrong identity transition')
    need(transition['parent_manifest_sha256'] == PARENT_MANIFEST
         and transition['parent_source_sha256'] == PARENT_SOURCE
         and transition['source_sha256'] == SOURCE and transition['native_sha256'] == IMAGE,
         'transition identity mismatch')
    need(transition['native_executed'] is False and transition['Torch_executed'] is False
         and transition['runtime_qualification_transferred'] is False, 'invalid source-only claim')
    need(set(transition['derived']) == set(DERIVED), 'derived file denominator')
    inverse_rows = {}
    for name, prior in DERIVED.items():
        record = transition['derived'][name]
        need(record['original'] == prior and record['original_sha256'] == sha(parent[prior]),
             'wrong parent inverse target')
        raw = read(name, record['record'])
        need(invert(raw, record['edits']) == parent[prior], 'whole file inverse failed: ' + name)
        inverse_rows[name] = {'original': prior, 'original_sha256': sha(parent[prior]),
                             'current_sha256': sha(raw), 'whole_file_inverse_exact': True,
                             'edits': len(record['edits'])}

    old_profile = parse(parent['profile701.json'])
    profile_raw = read('profile712.json', transition['profile']['record'])
    profile = parse(profile_raw)
    need(canonical(old_profile) == parent['profile701.json'] and canonical(profile) == profile_raw,
         'canonical profile bytes required')
    old_pins, pins = old_profile['function_pins'], profile['function_pins']
    need(len(old_pins) == 701 and len(pins) == 712
         and set(pins) - set(old_pins) == set(CG)
         and all(pins.get(name) == digest for name, digest in old_pins.items()), 'complete712 function pins')
    inverse_profile = dict(profile)
    inverse_profile['function_pins'] = old_pins
    allowed = {'functions', 'name', 'native_sha256', 'schema', 'source_sha256', 'structural_observer_sha256'}
    need(set(transition['profile']['fields']) == allowed, 'profile identity-only fields')
    for name, edit in transition['profile']['fields'].items():
        need(old_profile[name] == edit['before'] and profile[name] == edit['after'], 'profile inverse field')
        inverse_profile[name] = edit['before']
    need(canonical(inverse_profile) == parent['profile701.json'], 'whole profile inverse failed')
    need(profile['functions'] == 712 and profile['source_sha256'] == SOURCE
         and profile['native_sha256'] == IMAGE
         and profile['name'] == 'current712-generator-original35-F32-ViewInfo-Saved', 'wrong active profile')

    # Preserve and actually recompute the earlier complete-file inverses too.
    old_authoring = parse(parent['authoring.json'])
    parent_inverse = {}
    for name, record in old_authoring['derived'].items():
        original = parent['frozen/' + record['original']]
        need(sha(parent[name]) == record['sha256'] and sha(original) == record['original_sha256'],
             'parent proof source pins')
        need(invert(parent[name], record['edits']) == original, 'parent complete-file inverse failed')
        parent_inverse[name] = {'whole_file_inverse_exact': True, 'original_sha256': sha(original)}

    need(sha(source_raw) == SOURCE and source_raw.startswith(NEW_HEADER), 'wrong complete712 source')
    complete = bodies(source_raw)
    need(len(complete) == 712 and {k: sha(v) for k, v in complete.items()} == pins,
         'actual complete-source/profile binding')
    appended = b''.join(complete[name] for name in CG)
    need(source_raw.endswith(appended), 'eleven appended generator bodies/order')
    source_inverse = OLD_HEADER + source_raw[len(NEW_HEADER):-len(appended)]
    need(sha(source_inverse) == PARENT_SOURCE and {k: sha(v) for k, v in bodies(source_inverse).items()} == old_pins,
         'entire712 to701 source inverse')
    for target, expected in old_profile['capture_callers'].items():
        actual = sorted(name for name, body in complete.items()
                        if ('"function":"' + target + '"').encode() in body)
        need(actual == sorted(expected), 'unchanged capture caller set: ' + target)

    inputs = {name: read('provenance/' + name, digest) for name, digest in PINS.items()}
    old_manifest, manifest = map(parse, (inputs['tensor701/manifest.json'], inputs['generator712/manifest.json']))
    need([r['name'] for r in manifest['units']] ==
         ['rng03'] + ['cat_f32_%02d' % i for i in range(12)] + ['cg_model', 'owners'], 'exact15 units/order')
    need(manifest['runtime']['sha256'] == SOURCE and manifest['runtime']['functions'] == 712
         and old_manifest['runtime']['sha256'] == PARENT_SOURCE, 'source manifest identities')
    need(manifest['units'][1:13] == old_manifest['units'][1:13], 'all12 Tensor partition entries unchanged')
    candidate_transition = parse(inputs['generator712/transition.json'])
    need(candidate_transition['candidate_source_sha256'] == SOURCE
         and candidate_transition['original_source_sha256'] == PARENT_SOURCE
         and candidate_transition['whole701_source_inverse_exact'] is True, 'reviewed generator transition pin')

    old_rng, new_rng = inputs['tensor701/rng03.hepta'], inputs['generator712/rng03.hepta']
    rng_before, rng_after = bodies(old_rng), bodies(new_rng)
    need(len(rng_before) == 17 and set(rng_after) == set(rng_before) | {'cg_putw'}
         and all(rng_after[k] == v for k, v in rng_before.items()), 'all17 original RNG bodies')
    need(bodies(inputs['generator-original/rng.hepta']) == rng_before, 'original CG RNG bodies')
    old_exports, new_exports = old_rng.splitlines(keepends=True)[1], new_rng.splitlines(keepends=True)[1]
    need(new_rng.endswith(rng_after['cg_putw']), 'raw writer alias suffix')
    need(new_rng[:-len(rng_after['cg_putw'])].replace(new_exports, old_exports, 1) == old_rng,
         'whole RNG support inverse')
    need(sha(rng_after['cg_putw']) == '3763f0acdfefec6ce8216f8e24d766ff4b129bdf56c63e495dd447cae751f3fe',
         'raw writer alias binding')
    need(re.sub(rb'\bcg_putw\b', b'putw', inputs['generator712/cg_model.hepta']) ==
         inputs['generator-original/model.hepta'], 'whole11 CG model inverse')
    model = bodies(inputs['generator712/cg_model.hepta'])
    need(tuple(model) == CG and all(complete[n] == model[n] for n in CG), 'core cg_model bodies exact')

    old_owner, new_owner = inputs['tensor701/owners.hepta'], inputs['generator712/owners.hepta']
    tensor_owner, owner, cg_owner = bodies(old_owner), bodies(new_owner), bodies(inputs['generator-original/owners.hepta'])
    added = ('cg_error', 'generator_step', 'mux_request_kind', 'mux_refuse_generator', 'mux_refuse_tensor', 'step')
    need(set(owner) == {'make_trial', 'step_impl', 'close', 'tensor_step'} | set(added), 'exact10 owner bodies')
    need(rename(owner['tensor_step'], 'tensor_step', 'step') == tensor_owner['step'], 'original Tensor step inverse')
    need(rename(owner['generator_step'], 'generator_step', 'step') == cg_owner['step']
         and owner['cg_error'] == cg_owner['cg_error'], 'original Generator step/error unchanged')
    need(owner['close'] == tensor_owner['close'] == cg_owner['close'], 'one original close body')
    for name in ('make_trial', 'step_impl'):
        need(owner[name] == tensor_owner[name], 'original Tensor owner function changed')
    signature = owner['step'].splitlines()[0]
    need(signature == b'fn step(s0:readbuf,o0:mutbuf,st0:buffer,e0:readbuf) -> (buffer,u32) effects(alloc,read,write,trap) entry(b0)',
         'actual four-argument entropy ABI')
    inv_owner = new_owner
    for name in added:
        need(inv_owner.count(owner[name]) == 1, 'new owner function occurrence')
        inv_owner = inv_owner.replace(owner[name], b'')
    old_imports = set(EXTERNAL.findall(old_owner))
    for declaration in EXTERNAL.findall(new_owner):
        if declaration not in old_imports:
            need(inv_owner.count(declaration) == 1, 'added external declaration occurrence')
            inv_owner = inv_owner.replace(declaration, b'')
    inv_owner = inv_owner.replace(new_owner.splitlines(keepends=True)[0], old_owner.splitlines(keepends=True)[0], 1)
    need(rename(inv_owner, 'tensor_step', 'step') == old_owner, 'whole Tensor owner-unit inverse')

    old_builder, new_builder = inputs['tensor701/build.py'], inputs['generator712/build.py']
    builder_edits = (
        ('aae650e8822ef0b1e74d15108ad1d0f17ec791205ed5a158ec60b709f48f0e16',
         '761a941fd7a2d53eb9b45869fcfc20e970640e9dd11d60f7c61a89812b61d74e'),
        (PINS['tensor701/rng03.hepta'], PINS['generator712/rng03.hepta']),
        (PINS['tensor701/owners.hepta'], PINS['generator712/owners.hepta']),
        ('b"HIASTKS1"', 'b"HIACGS01"'))
    inv_builder = new_builder
    for before, after in reversed(builder_edits):
        need(inv_builder.count(after.encode()) == 1, 'builder literal multiplicity')
        inv_builder = inv_builder.replace(after.encode(), before.encode())
    need(inv_builder == old_builder, 'whole fixed builder inverse')
    for name, expected in transition['additions'].items():
        read(name, expected)
    need(set(transition['additions']) == {'generator_identity.py', 'author.py'}, 'new source module set')

    return {'schema': 'heptatorch.current712-original35.generator-identity-inverse.v1',
            'status': 'PASS_SOURCE_AND_ABI_IDENTITY_ONLY',
            'source_sha256': SOURCE, 'native_sha256': IMAGE,
            'parent_source_sha256': PARENT_SOURCE, 'parent_manifest_sha256': PARENT_MANIFEST,
            'transition_sha256': sha(transition_raw),
            'reader_inverses': inverse_rows, 'parent_reader_inverses': parent_inverse,
            'full_profile_inverse_exact': True, 'whole701_source_inverse_exact': True,
            'original701_function_bodies_byte_identical': True,
            'generator11_complete_body_pins_covered': True, 'original12_core_units_byte_identical': True,
            'whole_rng_support_inverse_exact': True, 'whole_generator_model_inverse_exact': True,
            'whole_tensor_owner_inverse_exact': True, 'generator_step_rename_only': True,
            'single_original_close_byte_identical': True, 'whole_builder_inverse_exact': True,
            'native_entry_argument_types': ['readbuf', 'mutbuf', 'buffer', 'readbuf'],
            'link_request_magic': 'HIACGS01', 'functions': 712, 'units': 15,
            'files': files, 'native_executed': False, 'Torch_executed': False,
            'runtime_qualification_transferred': False}
