"""Recheck this frozen source-only 35/Generator712 adapter without native execution."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import stat
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from generator_identity import verify_identity


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native-source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError('source verification output must be new')
    raw = args.native_source.read_bytes()
    proof = verify_identity(raw)
    syntax = {}
    for path in sorted(HERE.rglob('*.py')):
        tree = ast.parse(path.read_bytes(), filename=str(path))
        syntax[str(path.relative_to(HERE))] = len(tree.body)
    rechecked = {}
    for name, expected in proof['files'].items():
        path = Path(name)
        content = path.read_bytes()
        actual = {'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest(),
                  'mode': stat.S_IMODE(path.stat().st_mode)}
        rechecked[name] = actual == expected
    if not all(rechecked.values()) or args.native_source.read_bytes() != raw:
        raise ValueError('source inputs changed during verification')
    report = {'schema': 'heptatorch.current712-original35.source-check.v1',
              'status': 'PASS_SOURCE_ONLY_NOT_RUN', 'identity_inverse': proof,
              'all_inputs_unchanged': True, 'syntax': syntax,
              'compiler_executed': False, 'linker_executed': False,
              'native_executed': False, 'Torch_executed': False,
              'runtime_qualification_transferred': False}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'status': report['status'], 'files': len(proof['files']),
                      'functions': 712, 'native_executed': False, 'Torch_executed': False}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
