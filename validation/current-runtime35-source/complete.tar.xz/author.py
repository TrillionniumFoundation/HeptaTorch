#!/usr/bin/env python3
"""Author an explicit current701 adapter; never executes HIA or imports Torch."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
FROZEN = HERE / 'frozen'
SOURCE = '82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313'
IMAGE = '80445a8c433f20314d3bc7b00ebb68f6a70fa200ee2e6aba193cff21aabfbc17'
NAME = 'current701-cat-empty-original35-F32-ViewInfo-Saved'
PINS = {
    'owner_integral.py': 'c39600e7c37dea390f88cf9e74d86dfa924301456e0f32e127d82c98ad6778b0',
    'legacy_owner_rules.py': '281f1ea437046a9cd884de2c8da34f38649a3b6482ade23123ac4aa992faed64',
    'owner_accounting_to.py': 'a496aae3ca0b9f02b7f0e8c26c7177c3ce5b5a8c4198354c22059434b1491914',
    'launcher614.py': '45b635448e7c4d2db48cbc3a9b31e722eaf3ec93be7e252ef0c51c740d04d949',
    'report_checker614.py': 'a86cde9c035e622932560441ad4d496452bef6afd648c836f297240e0b0136bf',
    'check_owner_snapshots_672.py': 'b276b3239d254c52b7877919fe1401e95121014975fdce64f5adc40a264a523e',
    'entry.py': '149b41c455444edeb8d25d0ad98045e29683e780f37f7e210e7985242d359597',
    'bridge.py': 'c2888687f8876ad3505f0e13c9aecddc45695eff22bfdd9fa16d760f9aa3dac5',
    'lifecycle.py': '4a195d07772123342ac3a33aa878aab1663ce0d0d1dbd8ea5ddb110438fd278c',
    'owned_reference.py': 'ee3cf72154ac9dfa31055557b3facab8fdd3e14aad03ef6000ced55ccd75ed88',
    'session_reference.py': '35fa5fa3e1b740f901c11d46dca484079b77805004586c03ae42b35be2265577',
    'reference.py': 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    originals = {name: (FROZEN / name).read_bytes() for name in PINS}
    for name, raw in originals.items():
        assert sha(raw) == PINS[name], ('frozen source changed', name)
        ast.parse(raw)
    raw = args.source.read_bytes()
    assert sha(raw) == SOURCE
    bodies = {name.decode(): body for body, name in re.findall(
        rb'^(fn ([A-Za-z_][A-Za-z_0-9]*)\([^\n]* entry\([A-Za-z_][A-Za-z_0-9]*\)\n.*?^end\n)',
        raw, re.M | re.S)}
    assert len(bodies) == 701
    old_profile_raw = (FROZEN / 'profile614.json').read_bytes()
    assert sha(old_profile_raw) == '1e5e8db18a2e9a7bc4b98ac1063a427eb0e60613781962371dacafc76414529f'
    old_profile = json.loads(old_profile_raw)
    admission_raw = (HERE / 'admission.py').read_bytes()
    ast.parse(admission_raw)
    admission_sha = sha(admission_raw)
    for name, expected in old_profile['constructor_functions_exact_parent'].items():
        assert sha(bodies[name]) == expected, ('constructor body changed', name)

    proof = {'schema': 'heptatorch.current701-original35.authoring.v1',
             'status': 'PREPARED_NOT_RUN', 'source_sha256': SOURCE, 'native_sha256': IMAGE,
             'functions': 701, 'native_executed': False, 'Torch_executed': False,
             'originals': PINS, 'derived': {}, 'admission_sha256': admission_sha,
             'full_project_status': 'HOLD',
             'new_current35_native_qualification': False}

    def derive(original_name, destination, edits):
        original = originals[original_name].decode()
        changed = original
        rows = []
        for label, before, after, count in edits:
            assert changed.count(before) == count, (destination, label, changed.count(before), count)
            changed = changed.replace(before, after)
            rows.append({'label': label, 'before': before, 'after': after, 'count': count})
        inverse = changed
        for row in reversed(rows):
            assert inverse.count(row['after']) == row['count'], (destination, row['label'], 'inverse')
            inverse = inverse.replace(row['after'], row['before'])
        assert inverse == original
        ast.parse(changed)
        produced = changed.encode()
        (HERE / destination).write_bytes(produced)
        proof['derived'][destination] = {'original': original_name,
            'original_sha256': sha(originals[original_name]), 'sha256': sha(produced),
            'bytes': len(produced), 'edits': rows, 'whole_file_inverse_equals_original': True}
        return sha(produced)

    structural = derive('owner_integral.py', 'owner701_structural.py', [
        ('state-tag', 'HTSINT01', 'HTSINT02', 2),
        ('backing-tag', 'HTOSIN01', 'HTOSIN02', 2),
        ('exact-count', 'functions == 699', 'functions == 701', 1),
        ('schema-identity', 'heptatorch.sum-integral-owner-source01.v1', 'heptatorch.current701-full-owner.v1', 1),
        ('unbound-profile-identity', 'sum-integral-source01-UNBOUND-699', 'current701-original35-UNBOUND', 1),
        ('bound-profile-identity', '"sum-integral-source01-%d-preserved47-48" % functions', repr(NAME), 1),
    ])
    profile = {
        'schema': 'heptatorch.current701-original35.profile.v1', 'name': NAME,
        'source_sha256': SOURCE, 'native_sha256': IMAGE, 'functions': 701,
        'descriptor_bytes': 672, 'state': 'HTSINT02', 'backing': 'HTOSIN02',
        'legacy_owner_rules_sha256': PINS['legacy_owner_rules.py'],
        'structural_observer_sha256': structural,
        'function_pins': {name: sha(body) for name, body in bodies.items()},
        'capture_callers': {target: sorted(name for name, body in bodies.items()
            if ('"function":"' + target + '"').encode() in body)
            for target in old_profile['capture_callers']},
        'constructor_functions_exact_parent': old_profile['constructor_functions_exact_parent'],
        'private_Tensor_root_roles': ['ordinary-binary-Saved-Tensor', 'F32-ViewInfo-ultimate-base'],
        'fixed35_domain': 'All unchanged original35 commands 1..56 and F32. Exact binary Saved and ViewInfo base references, complete 84-word structural checking, original constructor and private-G incarnation equation. Fields 608/616/624/632 remain required zero: an actual new history allocation fails this profile and is never explained as a residual.',
        'original_614_functions_unchanged': sum(sha(bodies[n]) == h for n,h in old_profile['function_pins'].items()),
        'original_614_functions_changed': [n for n,h in old_profile['function_pins'].items() if sha(bodies[n]) != h],
        'authoring_only': True, 'new_native_execution_qualified': False,
    }
    profile_raw = encoded(profile)
    (HERE / 'profile701.json').write_bytes(profile_raw)
    dependencies_before = '''    return {"legacy_owner_rules": LEGACY, "structural_owner672": STRUCTURAL,
            "original_structural_owner672": ORIGINAL_STRUCTURAL,
            "storage_tombstone_correction": HERE / "storage-tombstone-correction.json",
            "accounting_profile": PROFILE_FILE,
            "structural_profile_adaptation": HERE / "structural-profile-adaptation.json"}'''
    dependencies_after = '''    return {"legacy_owner_rules": LEGACY, "structural_owner672": STRUCTURAL,
            "original_structural_owner672": ORIGINAL_STRUCTURAL,
            "storage_tombstone_correction": FROZEN / "storage-tombstone-correction.json",
            "accounting_profile": PROFILE_FILE,
            "structural_profile_adaptation": FROZEN / "structural-profile-adaptation.json",
            "current701_authoring": HERE / "authoring.json",
            "current701_build_admitter": HERE / "admission.py"}'''
    targets_before = '    return [values[slot] for slot in (0,2) if values[slot]]'
    targets_after = '''    targets = [values[slot] for slot in (0,2) if values[slot]]
    node = snapshot["nodes"][str(index)]
    need(len(node) == 84, "descriptor-width")
    marker = word(node, 664)
    need(marker in (0, 1, 3), "current35-ViewInfo-marker")
    if marker:
        # The complete structural checker separately validates the live base,
        # incarnation, shared Storage/Version, ordering and effective requires.
        # Add this actual strong reference to the exact 600/208 equations.
        need(word(node, 640) > 0, "current35-ViewInfo-base")
        targets.append(word(node, 640))
    return targets'''
    observer = derive('owner_accounting_to.py', 'observer701.py', [
        ('frozen-directory', 'HERE = Path(__file__).resolve().parent\n', 'HERE = Path(__file__).resolve().parent\nFROZEN = HERE / "frozen"\n', 1),
        ('legacy-file', 'LEGACY = HERE / "legacy_owner_rules.py"', 'LEGACY = FROZEN / "legacy_owner_rules.py"', 1),
        ('profile-file', 'PROFILE_FILE = HERE / "profile.json"', 'PROFILE_FILE = HERE / "profile701.json"', 1),
        ('full-structural-original', 'ORIGINAL_STRUCTURAL = HERE / "owner672_general.py"', 'ORIGINAL_STRUCTURAL = FROZEN / "owner_integral.py"', 1),
        ('full-structural-derived', 'STRUCTURAL = HERE / "owner672_fixed35.py"', 'STRUCTURAL = HERE / "owner701_structural.py"', 1),
        ('original-structural-pin', '6d230e2df25e04e32f76fb10fd0936ec9d220b60acda37c40b52a45633372312', PINS['owner_integral.py'], 1),
        ('derived-structural-pin', 'e58adb23bb65cdc81ec36e3e2fcbd178c0d5198f3b10c5d274afa94da7761a6f', structural, 1),
        ('explicit-actual-profile-bind', 'CONFIG = json.loads(PROFILE_FILE.read_bytes())\n', 'CONFIG = json.loads(PROFILE_FILE.read_bytes())\nstructural.bind_profile(CONFIG["source_sha256"], CONFIG["native_sha256"], CONFIG["functions"])\n', 1),
        ('source-function-count', 'len(bodies) == 614', 'len(bodies) == 701', 1),
        ('actual-view-base-strong-reference', targets_before, targets_after, 1),
        ('all-live-root-providers', '    for index in snapshot["binary_saved_roots"]:\n', '    for index, node in snapshot["nodes"].items():\n        if not word(node, 304):\n            continue\n', 1),
        ('explicit-view-role-in-fixed35', '(608,616,624,632,640,648,656,664)', '(608,616,624,632)', 1),
        ('exact-combined-root-rule-name', 'fixed35-original-Saved-T-reference-count', 'fixed35-original-Saved-T-and-ViewInfo-reference-count', 1),
        ('current-dependency-custody', dependencies_before, dependencies_after, 1),
        ('current-profile-root-role-record', '                   inverse_proof=inverse_proof(), source_constructor_costs=True)', '                   inverse_proof=inverse_proof(), source_constructor_costs=True,\n                   private_Tensor_root_roles=CONFIG["private_Tensor_root_roles"])', 1),
    ])
    launcher = derive('launcher614.py', 'run.py', [
        ('current-observer-import', 'import owner_accounting_to as observer', 'import observer701 as observer\nfrom admission import admit_build, recheck_build', 1),
        ('cold-build-arguments', '    args, original_args = parser.parse_known_args()\n', '    parser.add_argument("--build-directory", type=Path, required=True)\n    parser.add_argument("--expected-build-sha256", required=True)\n    args, original_args = parser.parse_known_args()\n', 1),
        ('cold-build-admission', '    profile = observer.pin_profile(binary, source)\n', '    profile = observer.pin_profile(binary, source)\n    build_admission = admit_build(args.build_directory, args.expected_build_sha256, binary, source)\n    (output / "build-admission.json").write_text(json.dumps(build_admission, indent=2) + "\\n")\n', 1),
        ('all-cold-build-files-in-custody', '    paths.update(observer.dependency_paths())\n', '    paths.update(observer.dependency_paths())\n    paths.update({"cold_build_" + str(i): Path(path) for i, path in enumerate(build_admission["files"])})\n', 1),
        ('build-binding-in-invocation', '                  "native_rebuilt": False, "native_frozen_bytes_reused": True}', '                  "native_rebuilt": False, "native_frozen_bytes_reused": True,\n                  "cold_build_admission": build_admission}', 1),
        ('build-binding-in-report', '            "observer_overlay": overlay, "profile": profile,', '            "observer_overlay": overlay, "profile": profile,\n            "cold_build_admission": build_admission,', 1),
        ('recheck-exact-build-modes-and-bytes', '        inner = json.loads(inner_report.read_text()) if inner_report.exists() else None\n', '        unchanged.update({"cold_build_mode_and_bytes:" + path: ok for path, ok in recheck_build(build_admission).items()})\n        inner = json.loads(inner_report.read_text()) if inner_report.exists() else None\n', 1),
        ('current-profile-scope', 'separately pinned614/672 owner', 'separately pinned701/672 owner with exact F32 ViewInfo base references', 1),
        ('root-equation-description', 'Ordinary F32mul/div Saved-original-T Hold/600/208 equations are explicit; 99/101 roles absent.', 'Ordinary F32mul/div Saved-original-T and F32 ViewInfo-base 600/208 equations are explicit; 99/101 and captured-history roles remain absent.', 1),
    ])
    derive('report_checker614.py', 'check_report.py', [
        ('native-image-pin', old_profile['native_sha256'], IMAGE, 1),
        ('source-pin', old_profile['source_sha256'], SOURCE, 1),
        ('profile-name', 'tensor-to-copy-614-fixed35-F32-Saved', NAME, 1),
        ('observer-pin', PINS['owner_accounting_to.py'], observer, 1),
        ('launcher-pin', PINS['launcher614.py'], launcher, 1),
        ('derived-full-owner-pin', 'e58adb23bb65cdc81ec36e3e2fcbd178c0d5198f3b10c5d274afa94da7761a6f', structural, 1),
        ('original-full-owner-pin', '6d230e2df25e04e32f76fb10fd0936ec9d220b60acda37c40b52a45633372312', PINS['owner_integral.py'], 1),
        ('current-profile-file-pin', '1e5e8db18a2e9a7bc4b98ac1063a427eb0e60613781962371dacafc76414529f', sha(profile_raw), 1),
        ('current-roots-and-build-required', ' assert wrapper["profile"]["descriptor_bytes"]==672\n', ' assert wrapper["profile"]["descriptor_bytes"]==672\n assert wrapper["profile"]["private_Tensor_root_roles"]==["ordinary-binary-Saved-Tensor","F32-ViewInfo-ultimate-base"]\n assert wrapper["cold_build_admission"]["status"]=="ADMITTED_CURRENT701_COLD_BUILD"\n assert wrapper["cold_build_admission"]["source_sha256"]==expected_source\n assert wrapper["cold_build_admission"]["native_sha256"]==inner["native_executable_sha256"]\n assert wrapper["source_custody"]["current701_build_admitter"]["sha256"]==' + repr(admission_sha) + '\n', 1),
    ])
    derive('check_owner_snapshots_672.py', 'controls.py', [
        ('current-observer-pin', PINS['owner_accounting_to.py'], observer, 1),
        ('current-profile-name', 'tensor-to-copy-614-fixed35-F32-Saved', NAME, 1),
    ])
    proof['profile_sha256'] = sha(profile_raw)
    proof['unchanged_original_case_sources'] = {n: PINS[n] for n in
        ('entry.py','bridge.py','lifecycle.py','owned_reference.py','session_reference.py','reference.py')}
    proof['private_ledger_policy'] = {
        'full84_structural_owner_predicates_preserved': True,
        'view_base_reference_added_to_600_208_and_reachable_reset_closure': True,
        'incarnation_equals_constructor_tickets_plus_new_private_gradients_unchanged': True,
        'node_high_water_and_original18_refusal_bodies_unchanged': True,
        'history_fields_608_616_624_632_still_required_zero': True,
        'unexpected_history_or_allocation_fails_instead_of_residual_explanation': True,
        'numeric_training_lifetime_EOF_Version_comparisons_changed': False,
    }
    (HERE / 'authoring.json').write_bytes(encoded(proof))
    print(json.dumps({'status': proof['status'], 'derived': {n:r['sha256'] for n,r in proof['derived'].items()},
                      'profile_sha256': proof['profile_sha256'], 'native_executed': False, 'Torch_executed': False}))


if __name__ == '__main__':
    main()
