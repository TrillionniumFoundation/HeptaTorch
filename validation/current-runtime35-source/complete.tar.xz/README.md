# Original 35 cases on the Generator712 image

This is a source-only identity bridge for the unchanged original 35-case Torch comparison and its exact private-node observer. Its status is `PREPARED_NOT_RUN`. No compiler, linker, HIA runtime, Torch reference, or application process is executed while constructing or checking this package. The original 35-case result on another image is not transferred.

## Fixed identities

| Input | SHA256 or contract |
|---|---|
| Complete source | `fac3d413c6c0f6874d224cbea312108ee2c8baa027102d41890d85094a5faa38` |
| Native executable | `5b7aac203d2c913d43781f0da45d40e9bac2037c2bc074ec30f8dd663710a805` |
| Source manifest | `708e4b642f630604cedb1d2cf566fefcfb3d9afd74a835f5a265d7e51f1ff4e5` |
| Compiler | `b1c851a0896fa6071f800e1146c3c27d0c6cf85059e9a6281b46d42908a3f59f` |
| Entropy-capable linker | `761a941fd7a2d53eb9b45869fcfc20e970640e9dd11d60f7c61a89812b61d74e` |
| Builder | `9c93f8ff3fcfda8358e51a4c12efb3b0e0962abed9b5a750ca32d5a5568ac14d` |
| Stack inspector | `71b72260014417db72ffcebd80c86543e257c80d76cdd6c878b41feaa117cf92` |
| Core function count | 712: all 701 original Tensor bodies and 11 appended Generator bodies |
| Unit order | `rng03`, `cat_f32_00` through `cat_f32_11`, `cg_model`, `owners` |
| Build subprocesses | 15 compilers and 1 linker, each actual exit 0 and complete stdout/stderr EOF |
| Link request | `HIACGS01`, 15 actual object payloads, entry `step` |
| Actual entry ABI | `step(readbuf, mutbuf, buffer, readbuf)`, returning `(buffer, u32)` |
| Tensor owner | `HTSINT02` / `HTOSIN02`, complete 672-byte descriptors (84 words) |

The caller supplies the exact SHA256 of its actual cold-build report. A new cold build with these same fixed identities is admitted; no old build-report bytes or timestamp are synthesized. The earlier root cold build has report SHA256 `37d6038d6315a2f83b3fb1582f94e9e1b63dfa45c7168896b8123946fbea0c52`, but this source package does not treat that build as a runtime qualification.

`cg_model` is a core unit, so all 11 of its actual bodies must match the complete source and the 712-entry profile. Only `rng03` and `owners` are support units. The support units have fixed complete-file pins; the old raw RNG writer is kept distinct from the tagged Tensor writer.

## What remains exact

`parent701/` preserves the entire old cat-fixed 35 package, including its manifest, all 26 payload files, modes, and existing derivation proofs. `frozen/` also preserves every original input at the original relative path. The parent manifest is `0241d2f320765f1ad53aa28721a4e30304aedc21d7cca8a44668ee5567510f57`.

The current bridge keeps the original 28 numeric cases and 7 lifetime cases, all exact bit/tolerance expressions, original Torch provenance, 6,344 frames, 2,590,274 compared values, 283 explicit-state absolute Version differences, zero direct parameter Version mismatches, original process EOF/exit checks, and all post-close Version gates. It retains all four positive and eighteen negative observer controls, their original mutation bodies and refusal expectations.

The full owner decoder and 84-word checks remain intact. Saved Tensor and ViewInfo base references still enter the exact 600/208 equations and reachable closure. Original constructor/private-gradient incarnation counts stay exact. Fields 608/616/624/632 must still be zero. No unexpected history or allocation is explained away. The Tensor-only fixed35 owner observer does not claim to qualify Generator owner semantics; Generator testing is a separate workload.

The only current reader edits are file/module names, identity pins, function/unit/process counts, profile/schema labels, and additive source/ABI inverse verification. `generator-identity-transition.json` records every exact literal edit and reconstructs each complete parent file. The profile inverse removes only the eleven new function pins and restores the six identity fields, recovering the entire original profile bytes. The earlier five complete reader inverses back to frozen sources are executed again by the verifier.

`generator_identity.py` additionally reconstructs the complete 701 source by removing the eleven fixed appended bodies and restoring the module header. It verifies the complete original Tensor owner unit, original Generator step/error/close, full RNG support unit, complete Generator model, and the fixed builder through exact inverses. The original twelve core partition entries remain unchanged. `provenance/` contains these frozen source inputs, never an application ELF.

## Source-only check

Run in an isolated new output location:

```sh
python -I -S -B author.py \
  --native-source /absolute/path/to/complete712/runtime.hepta \
  --output /absolute/new/path/source-check.json
```

Expected status is `PASS_SOURCE_ONLY_NOT_RUN`. This command only reads source/JSON files and parses Python syntax; it never runs the native image or imports Torch.

## Actual execution interface

The original CLI stays intact. Use the fixed Torch interpreter, the original legacy directory, original references and locks, and a new output directory:

```sh
TORCH_PYTHON run.py \
  --legacy-directory ORIGINAL35_SOURCE_DIRECTORY \
  --native-source COMPLETE712_SOURCE \
  --observer-output NEW_OBSERVER_DIRECTORY \
  --observer-report NEW_OBSERVER_REPORT_JSON \
  --build-directory ACTUAL_COLD_BUILD_DIRECTORY \
  --expected-build-sha256 ACTUAL_BUILD_REPORT_SHA256 \
  -- COMPLETE712_BINARY NEW_ORIGINAL_REPORT_JSON \
  --owned-reference ORIGINAL_OWNED_REFERENCE \
  --session-reference ORIGINAL_SESSION_REFERENCE \
  --reference ORIGINAL_REFERENCE \
  ORIGINAL_UNCHANGED_ENTRY_OPTIONS
```

Appending the original entry's `--prepare-only` option must yield `PREPARED_NOT_RUN`, with no qualification credit. Actual execution requires the original entry report to be `PASS`, all 35 observer rows to be `PASS`, complete original EOF/Version gates, and every source/build input unchanged. Any original failure, timeout, exception, wrong image, missing raw result, incomplete EOF or custody mismatch remains a failure.

Then run the unchanged CLI of the strict checker and observer controls:

```sh
python -I -S -B check_report.py --observer-report OBSERVER_REPORT --original-report ORIGINAL_REPORT
python -I -S -B controls.py --help
```

The controls accept `--expected-profile current712-generator-original35-F32-ViewInfo-Saved` and the original journal/report arguments; their command-line and mutation logic are otherwise unchanged.

## Report interface changes

| Report | Schema / status |
|---|---|
| Main wrapper | `heptatorch.current712-original35-private-node-accounted-run.v1`; `PREPARED_NOT_RUN`, `PASS`, or `FAIL` |
| Cold admission | `heptatorch.current712-original35.cold-build-admission.v1`; `ADMITTED_CURRENT712_COLD_BUILD` |
| Source/ABI inverse | `heptatorch.current712-original35.generator-identity-inverse.v1`; `PASS_SOURCE_AND_ABI_IDENTITY_ONLY` |
| Observer controls | `heptatorch.current712-private-node-observer-independent-negative-controls.v1`; `PASS_OBSERVER_CONTROLS_ONLY` or `FAIL_OBSERVER_CONTROLS` |
| Strict checker | Original output status `PASS_EXACT_ORIGINAL_AND_ADDITIVE_REPORT_BINDING` |

All existing report fields retain their meaning. Cold admission adds `generator_identity_inverse`. The source custody keys `current701_authoring` and `current701_build_admitter` become `current712_authoring` and `current712_build_admitter`, with new `generator_identity` and `generator_identity_transition` entries. Every file read by the inverse verifier is also included in cold admission's before/after bytes/mode custody. No `PREPARED_NOT_RUN`, source-only PASS, old-image PASS, or build-only PASS counts as a current35 native PASS.
