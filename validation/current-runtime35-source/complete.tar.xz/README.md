# Current701 original35 adapter

This isolated package prepares the complete original35 PyTorch comparison for
the exact current701 HIA source and executable. It has not executed a native
case or imported Torch during authoring. `authoring.json` deliberately reports
`PREPARED_NOT_RUN`; that receipt is not runtime qualification.

The pinned source is
`82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313`.
The pinned executable is
`80445a8c433f20314d3bc7b00ebb68f6a70fa200ee2e6aba193cff21aabfbc17`.
The source contains 701 core functions and uses the complete 672-byte
descriptor and `HTSINT02` / `HTOSIN02` owner tags. `admission.py` checks the
existing complete cold-build report, every actual source/object unit, all
compiler/linker exits and EOFs, fixed compiler/linker bytes, the exact link
request, and the complete source/image. It does not execute a build or image.

## Preserved comparison scope

The six unchanged case/reference files remain byte-pinned: the original entry,
bridge, lifecycle cases, owned Tensor oracle, session oracle, and reference
support. All 35 cases, their input generation, tolerances, training steps,
actual Torch expectations, lifetime checks, original EOF/exit assertions, and
post-close parameter Version assertions remain unchanged. The expected full
workload remains 6,344 frames and 2,590,274 compared values, with the original
283 explicit state-Version differences and zero parameter-Version mismatches.

This entry generates its references with the original pinned CPU PyTorch
environment. It does not accept an old native wire trace as a replacement
numeric reference. The reference lock and all eleven provenance checks remain
mandatory. The full separate 270-case base/NN oracle is not invoked by this
35-case entry.

## Exact owner adaptation

`owner701_structural.py` is derived from the complete frozen `owner_integral.py`
in `root-sum-integral-native24-reviewed-intent-v2.json`. Its complete structural
predicate bodies are unchanged; only tags, profile identities, and the exact
source function count are adapted with a whole-file inverse proof.

The old fixed35 ledger now includes actual F32 ViewInfo ultimate-base references
in its exact descriptor fields 600 and 208 equations and in reachable/reset
root closure. The full structural checker independently verifies every live
base, incarnation, shared Storage/Version, attribute version, ordering and
effective requires-grad flag. Binary Saved Tensor roots remain fully checked.
Every snapshot still contains all 84 words; no field projection is used.

The original equation `incarnation delta = constructor tickets + new private G`
and the original high-water, reset, rollback, and public-prefix assertions
remain exact. Captured-history fields 608, 616, 624 and 632 are still required
zero in this fixed35 profile. If an actual current701 case exercises a new
history allocation, it fails explicitly; an unexplained allocation is never
accepted as a residual or an inequality. Such a failure requires an additional
source-derived exact rule and a separately preserved attempted run.

The complete original four copied positive controls and eighteen named
negative controls remain unchanged except for the exact observer SHA/profile
identity. Their input is the new current701 execution's own full journals.

## Commands for a separately authorized actual run

Use the same fixed Linux x86-64 / CPython 3.12 / PyTorch 2.15.0+cpu environment
recorded in `compatibility/pytorch-oracle-lock.json`. The example variables
below denote existing exact inputs. `RESULTS` must be a new directory.

```bash
python -I -S -B author.py --source "$SOURCE"

"$PINNED_TORCH_PYTHON" run.py \
  --legacy-directory "$REPO/tests/tensor_object_oracle" \
  --native-source "$SOURCE" \
  --build-directory "$COLD_BUILD" \
  --expected-build-sha256 "$BUILD_SHA256" \
  --observer-output "$RESULTS/observer" \
  --observer-report "$RESULTS/observer-report.json" \
  -- "$COLD_BUILD/heptatorch" "$RESULTS/original-report.json" \
  --owned-reference "$REPO/tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py" \
  --session-reference "$REPO/tests/pytorch_session_oracle.py" \
  --reference "$REPO/tests/pytorch_oracle.py" \
  --lock "$REPO/compatibility/pytorch-oracle-lock.json" --repo "$REPO" \
  --trace-directory "$RESULTS/wire" \
  --expected-native-sha256 80445a8c433f20314d3bc7b00ebb68f6a70fa200ee2e6aba193cff21aabfbc17

python -I -S -B check_report.py \
  --observer-report "$RESULTS/observer-report.json" \
  --original-report "$RESULTS/original-report.json"

python -I -S -B controls.py --observer ./observer701.py \
  --expected-profile current701-cat-empty-original35-F32-ViewInfo-Saved \
  --journals "$RESULTS/observer/owners" --output "$RESULTS/copied-controls"
```

Appending `--prepare-only` to the original-entry arguments checks the complete
frozen source and case plan without importing Torch or starting native cases.
The result stays `PREPARED_NOT_RUN`; the strict report checker rejects it.

Whole-project schema closure remains false. Neither preparing this adapter nor
passing its finite 35 cases establishes full PyTorch rewrite completion.

This independent source package binds the AVX2 reduction-order correction.
The original701 source and its successful original35 run remain preserved.
The two sd reduction bodies and the incoming_describe_cat empty-gradient
aggregation assignment differ from the first701 runtime. This source package
has not executed the selected cat-corrected image. The original six reference/case files
and all comparison, training, lifetime and observer predicates remain fixed.
