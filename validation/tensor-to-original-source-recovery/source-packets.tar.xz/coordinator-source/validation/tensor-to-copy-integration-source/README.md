# Source-frozen Tensor.to seven-gate integration coordinator

`tests/qualify_tensor_to_copy.py` performs a genuine fresh producer build in OUTPUT/producer/native, then executes independent source custody, four owner cases with17 copied refusals, six resource controls, five entry controls, the original six Saved107 entry controls using that same newly built entry probe, and two legitimate owned-profile handoff directions. No previous producer result can substitute for this invocation. The12 producer gates preserve the original54/view4/toggle4/copy4/reduction4/lanes2/branches6/mixed36/Saved14, integer8 and legacy12/inherited16 expectations including every originalOPEN/partial status. Numeric suites overlap and are not summed into a uniqueAPI count.

All exact source-package manifests, actual references and tools are captured before execution. The physical76-payload independent delivery is checked separately from its unchanged original71-payload logical manifest. Ordered opaque parts reconstruct the original29f0 archive in memory; the repository does not contain a fictitious originalwhole archive file. The original1405 members are fully reverified without reclassifying historical results. The same final09b six-gate actual reports supply only frozen case/source contracts; all seven current subprocesses must actually start and finish successfully.

All new output files and nested producer evidence archives are sealed byte-for-byte with mode/size/SHA/singleXZ EOF verification. The three root self-references(report.json/evidence-manifest.json/raw-evidence.tar.xz) are excluded explicitly. Failure retains the primary error and attempts to preserve partial raw evidence; an archive failure is recorded separately.

This source packet is **SOURCE_FROZEN_NOT_EXECUTED**. Its exact mainprefix through complete pre-execution custody was executed on862 actual inputs, stopping before producer start. The finalfile only changes the docstring relative to that exact preflight; complete remainingAST is identical. The first preflight used a nonexistentupstream path and was refused before any child; that originalFAIL is preserved. The earlier report-schema factory-name rejection and five draft01 execution-flag mismatches are preserved as source/integration preparation failures, not native failures.

Run from any directory:

```sh
python -S -B REPO/tests/qualify_tensor_to_copy.py \
  --repo REPO --parent-build MIXED10_NATIVE --upstream PINNED_HEPTA_SOURCE \
  --compiler CANONICAL_STACK/native/stack-module-compiler \
  --linker CANONICAL_STACK/native/stack-linker-session \
  --flat-compiler PINNED_FLAT_COMPILER --stack-build CANONICAL_STACK \
  --output NEW_OUTPUT
```

The current tested preparation uses `/workspace/scratch/dfc64d0acfc2/hia-toolchain-cold` as theupstream source, never an inferredunpopulatedHepta directory. Paths are parameters and everyrequiredfileSHA ischecked. Whole-project PyTorch remains HOLD/0/2590/full=false. Live32,full35 with18copied controls andStorage tombstones remain separate required actual gates.
