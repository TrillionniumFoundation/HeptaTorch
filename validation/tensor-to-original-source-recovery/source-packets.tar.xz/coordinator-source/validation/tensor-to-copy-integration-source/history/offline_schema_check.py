#!/usr/bin/env python3
"""Check coordinator access paths against original reports; no native/Torch run."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import lzma
import tarfile
import traceback

HERE=Path(__file__).resolve().parent
BASE=Path('/dev/shm/heptatorch-d26699e25fea')
EXT=BASE/'tensor-to-copy-extension'
REPO=BASE/'HeptaTorch-tensor-to-integration'
PACKAGE=EXT/'package-09b'


def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


def main():
    out=HERE/'schema-review-02';out.mkdir(exist_ok=False)
    current=module(HERE/'tests/qualify_tensor_to_copy.py','to_coordinator_schema_current')
    old=module(HERE.parent/'tests/qualify_tensor_to_copy.py','to_coordinator_schema_parent')
    inputs={};checks=[];findings=[]
    def read(p):
        p=p.resolve();raw=p.read_bytes();inputs[str(p)]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':p.stat().st_mode&511};return json.loads(raw)
    samples={
      'to54':EXT/'actual54-first-05/report.json',
      'view4':BASE/'to-view-dropout-reference4-01/native-first-05/report.json',
      'toggle4':BASE/'to-view-base-toggle-reference4-01/native-first-05/report.json',
      'copy-bits4':EXT/'as-strided-copy-bits-review/native-first-09b/report.json',
      'reduction-bits4':EXT/'as-strided-reduction-bits-review/native-first-09b/report.json',
      'sum-lanes2':EXT/'as-strided-sum-lanes-review/native-first-09b/report.json',
      'sum-branches6':EXT/'as-strided-sum-branches-review/native-first-09b/report.json',
      'mixed36':EXT/'mixed36-first-05/report.json',
      'Saved14':EXT/'saved14-first-05/report.json'}
    for role,path in samples.items():
        child=read(path)
        candidates=[Path(p) for p,pin in child['inputs_sha256'].items() if pin==child['reference_sha256']]
        assert len(candidates)==1
        reference=read(candidates[0]);ref={'sha256':child['reference_sha256'],'probe_sha256':child['probe_sha256']}
        current.actual_reference_fields(reference,role,ref['probe_sha256'])
        current.SOURCE=child['source_sha256'];current.IMAGE=child['native_sha256']
        spec={'report_schema':child['schema'],'reader_sha256':child.get('reader_sha256'),
              'observer_sha256':child.get('observer_sha256')}
        current.native_reference_fields(child,role,reference,ref,spec)
        flag_shape={k:k in child for k in ('native_executed','Torch_executed_here')}
        try:old.fields(child,{'native_executed':True,'Torch_executed_here':False},role)
        except AssertionError as e:findings.append({'role':role,'original_report_sha256':sha(path),'draft01_refusal':repr(e),'classification':'SOURCE_SCHEMA_MISMATCH_NO_NEW_NATIVE_FAILURE'})
        checks.append({'role':role,'reference_path':str(candidates[0]),'reference_sha256':ref['sha256'],
            'native_sample_path':str(path),'native_sample_sha256':sha(path),'source_sha256':child['source_sha256'],
            'native_sha256':child['native_sha256'],'sample_status':child['status'],'native_schema':child['schema'],
            'execution_flag_presence':flag_shape,'shape_validation':'PASS',
            'historical_source_identity_not_rebound':True})
        # Raw journal verification is tested on the four new exact byte sets.
        # This is an offline repack of existing bytes, not a new native result.
        if role not in ('copy-bits4','reduction-bits4','sum-lanes2','sum-branches6'):continue
        originals={}
        for row in child['rows']:
            for suffix in ('transport.json','requests.frames.bin','responses.frames.bin'):
                rel=f"case-{row['index']:02d}/raw/{suffix}";p=path.parent/rel
                originals[rel]={'path':p,'bytes':p.stat().st_size,'sha256':sha(p),'mode':p.stat().st_mode&511}
        archive=out/(role+'-original-journals-only.tar.xz')
        with lzma.open(archive,'wb',preset=1) as stream,tarfile.open(fileobj=stream,mode='w|') as tar:
            for rel,row in sorted(originals.items()):
                info=tar.gettarinfo(str(row['path']),arcname=rel)
                with row['path'].open('rb') as f:tar.addfile(info,f)
        receipt={'members':{rel:{k:v for k,v in row.items() if k!='path'} for rel,row in originals.items()}}
        checked=current.verify_archive(archive,receipt['members'],recurse=False)
        journals=current.reference_native_journals(child,role,archive,receipt)
        checks[-1]['original_journals_offline_recheck']={**journals,'archive_sha256':sha(archive),'members':checked['members']}
        for row in originals.values():assert sha(row['path'])==row['sha256']
    factory=read(BASE/'to-view-factory-version-review-01/remote/actual.json')
    current.actual_reference_fields(factory,'factory4',factory['probe_sha256'])
    checks.append({'role':'factory4','status':'REFERENCE_SHAPE_PASS_DIAGNOSTIC_ONLY','native_execution_claimed':False})
    support=REPO/'tests/pytorch_oracle.py'
    assert sha(support)==current.REFERENCE_SUPPORT
    tree=ast.parse(support.read_text())
    assert sum(isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.dump(n.value,include_attributes=False)==ast.dump(ast.parse('torch.set_num_threads(1)').body[0].value,include_attributes=False) for n in tree.body)==1
    checks.append({'role':'dispatch-configuration','support_sha256':sha(support),'module_scope_set_num_threads_1':True,
                   'actual_branch_AVX512_required_separately':True,'separate_get_num_threads_observation_claimed':False})
    native_source=read(BASE/'to-view-owner-review-09b/source-final/observed/report.json')
    current.SOURCE=native_source['source_sha256'];current.IMAGE=native_source['native_sha256']
    current.FINAL['functions']=614;current.FINAL['units']=12
    profile=read(PACKAGE/'tools/tensor_to_copy/profile.json')
    current.source_audit_complete(native_source,native_source,profile)
    checks.append({'role':'source-audit','status':'CURRENT_REPORT_SHAPE_PASS','source_sha256':native_source['source_sha256'],
                   'current_functions':native_source['core_function_count'],'previous_source_sha256':native_source['previous_source_sha256'],
                   'previous_functions':native_source['previous_functions'],'current_units':len(native_source['units']),
                   'parent_units':len(native_source['parent_units'])})
    # The frozen archive helpers are exercised against actual parent archives,
    # including all twelve nested legacy archives and their original manifests.
    original=BASE/'mixed10-root-cold-integration-01/producer5/evidence'
    for name in ('fixed-mixed-actual36','fixed-saved-public14','inherited-I64-eight','legacy523-twelve'):
        receipt=read(original/(name+'.manifest.json'));archive=original/(name+'.tar.xz')
        assert receipt['archive']==archive.name and sha(archive)==receipt['archive_sha256'] and archive.stat().st_size==receipt['archive_bytes']
        assert receipt['member_count']==len(receipt['members']) and receipt['original_bytes']==sum(p['bytes'] for p in receipt['members'].values())
        verified=current.verify_archive(archive,receipt['members'])
        checks.append({'role':'original-archive-shape','name':name,'archive_sha256':sha(archive),**verified})
    for p,pin in inputs.items():
        q=Path(p);assert sha(q)==pin['sha256'] and q.stat().st_size==pin['bytes'] and q.stat().st_mode&511==pin['mode']
    report={'schema':'heptatorch.to-coordinator-offline-schema-review.v1','status':'PASS_OFFLINE_SCHEMA_ONLY',
        'native_executions':0,'Torch_executions':0,'compiler_executions':0,
        'current_coordinator_sha256':sha(HERE/'tests/qualify_tensor_to_copy.py'),
        'draft01_sha256':sha(HERE.parent/'tests/qualify_tensor_to_copy.py'),
        'draft01_source_findings':findings,'checks':checks,'original_report_inputs':inputs,
        'all_original_inputs_unchanged':True,'no_historical_numeric_result_rebound':True,
        'final_full_cold_oracle_qualification_claimed':False}
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'report':str(out/'report.json'),'sha256':sha(out/'report.json'),
                      'schema_checks':len(checks),'draft01_findings':len(findings)}))


if __name__=='__main__':main()
