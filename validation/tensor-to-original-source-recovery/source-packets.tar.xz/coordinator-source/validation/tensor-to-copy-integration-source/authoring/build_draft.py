#!/usr/bin/env python3
"""Emit the reviewable coordinator without executing its native commands."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PARENT = Path('/dev/shm/heptatorch-d26699e25fea/HeptaTorch-tensor-to-integration/tests/qualify_mixed_integer_autograd.py')
EXPECTED = '78978f2665e68c78a66d5e21d0c359a7bfdb426199902dff2be5a720f858f905'
FUNCTIONS = ('require', 'digest', 'unique', 'loads', 'decode', 'dump', 'relative', 'fields',
             'Custody', 'manifest', 'open_raw', 'archive_members', 'verify_archive',
             'bind_report_inputs', 'child_report', 'complete_cases', 'archive_evidence')
CONSTANTS = ('CHECKS', 'INTEGER_GATES', 'LEGACY_GATES', 'INHERITED_NAMES', 'INHERITED_EXPECTED')
SHA = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    raw = PARENT.read_bytes()
    assert SHA(raw) == EXPECTED
    original = raw.decode()
    nodes = ast.parse(original).body
    defs = {node.name: node for node in nodes if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    constants = {node.targets[0].id: node for node in nodes
                 if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)}
    imports = [ast.get_source_segment(original, n) for n in nodes if isinstance(n, (ast.Import, ast.ImportFrom))]
    helper = []
    for name in FUNCTIONS:
        text = ast.get_source_segment(original, defs[name])
        if name == 'archive_evidence':
            assert text.count('heptatorch.mixed-integer-autograd-fresh-raw-evidence.v1') == 1
            text = text.replace('heptatorch.mixed-integer-autograd-fresh-raw-evidence.v1',
                                'heptatorch.tensor-to-copy-fresh-raw-evidence.v1')
        helper.append(text)
    inherited = [ast.get_source_segment(original, constants[name]) for name in CONSTANTS]
    parent_manifests = ast.get_source_segment(original, constants['MANIFESTS']).replace('MANIFESTS =', 'PARENT_MANIFESTS =', 1)
    own = (ROOT / 'current.py.in').read_text()
    own_tree = ast.parse(own)
    doc = own_tree.body[0]
    assert isinstance(doc, ast.Expr) and isinstance(doc.value, ast.Constant)
    own = '\n'.join(own.splitlines()[doc.end_lineno:]).lstrip('\n')
    split = own.index('def contract_ready():')
    generated = '#!/usr/bin/env python3\n' + '"""Fresh native Tensor.to/_to_copy qualification with seven explicit outer gates.\n\n'
    generated += 'This review draft refuses execution until every final source/package/step pin is frozen.\n'
    generated += 'Live32 and full35 remain separate required gates. No old result is rebound to a new image.\n"""\n'
    generated += '\n'.join(imports) + '\nimport importlib.util\nimport zlib\nimport ast\nimport re\n\n'
    generated += '\n\n'.join(inherited + [parent_manifests]) + '\n\n'
    generated += own[:split] + '\n\n' + '\n\n'.join(helper) + '\n\n' + own[split:]
    parsed = ast.parse(generated)
    current = {n.name: n for n in parsed.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    assert len(current) == len([n for n in parsed.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))])
    receipts = {}
    for name in FUNCTIONS:
        before = ast.get_source_segment(original, defs[name])
        after = ast.get_source_segment(generated, current[name])
        restored = after.replace('heptatorch.tensor-to-copy-fresh-raw-evidence.v1',
                                 'heptatorch.mixed-integer-autograd-fresh-raw-evidence.v1') if name == 'archive_evidence' else after
        assert restored == before
        receipts[name] = {'parent_source_sha256': SHA(before.encode()), 'current_source_sha256': SHA(after.encode()),
                          'whole_body_byte_equal_after_schema_literal_inverse': True,
                          'schema_literal_only_changed': name == 'archive_evidence'}
    target = ROOT / 'tests/qualify_tensor_to_copy.py'
    target.write_text(generated)
    target.chmod(0o644)
    (ROOT / 'parent-qualifier.py').write_bytes(raw)
    receipt = {'status': 'DRAFT_PREPARED_NOT_RUN', 'native_executions': 0, 'Torch_executions': 0,
               'parent_path': str(PARENT), 'parent_sha256': EXPECTED, 'script_path': str(target),
               'script_sha256': SHA(target.read_bytes()), 'script_bytes': target.stat().st_size,
               'inherited_constants': list(CONSTANTS), 'reused_helpers': receipts,
               'draft_blocks_all_native_commands_until_final_contract': True,
               'producer_output': 'OUTPUT/producer/native', 'outer_commands': 7}
    out = ROOT / 'draft-source-receipt.json'
    out.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'status': receipt['status'], 'script': str(target),
                      'sha256': receipt['script_sha256'], 'bytes': receipt['script_bytes'],
                      'receipt_sha256': SHA(out.read_bytes())}))


if __name__ == '__main__':
    main()
