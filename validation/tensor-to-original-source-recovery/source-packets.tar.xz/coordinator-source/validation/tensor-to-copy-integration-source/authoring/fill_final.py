from pathlib import Path
import ast,hashlib,json,pprint,subprocess,sys
HERE=Path(__file__).resolve().parent
BASE=Path('/dev/shm/heptatorch-d26699e25fea')
REPO=BASE/'HeptaTorch-tensor-to-integration'
PACKAGE=BASE/'tensor-to-copy-extension/package-09b'
INDEPENDENT=BASE/'to-view-owner-delivery-09b'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
profile=read(PACKAGE/'tools/tensor_to_copy/profile.json')
producer_manifest=read(PACKAGE/'tools/tensor_to_copy/package-manifest.json')
manifest_path='validation/to-view-owner-review/delivery-manifest.json'
delivery=read(INDEPENDENT/manifest_path)
final={'status':'FROZEN','source_sha256':profile['source_sha256'],'native_sha256':profile['native_sha256'],
 'profile_sha256':sha(PACKAGE/'tools/tensor_to_copy/profile.json'),
 'producer_manifest_sha256':sha(PACKAGE/'tools/tensor_to_copy/package-manifest.json'),
 'independent_manifest_path':manifest_path,'saved_entry_manifest_path':manifest_path,
 'functions':profile['functions'],'units':len(profile['units']),
 'state_format':profile['state_format'],'backing_format':profile['backing_format'],
 'manifests':[
 ['tools/tensor_to_copy/package-manifest.json',sha(PACKAGE/'tools/tensor_to_copy/package-manifest.json'),len(producer_manifest['files'])],
 ['validation/tensor-to-copy-reference/package-manifest.json','351209e5b68730161e7701fe6d1ca7042f73f4b3a8fe3c46447b06354c7559d7',41],
 [manifest_path,sha(INDEPENDENT/manifest_path),len(delivery['files'])]],
 'references':{},'producer_steps':[],'outer_expected':{},'outer_baselines':{},'scripts':{},
 'general_owner':'tests/to_view_owner_review/owner_view05.py',
 'general_owner_sha256':sha(INDEPENDENT/'tests/to_view_owner_review/owner_view05.py'),
 'extra_inputs':[],'historical_archives':[], 'external_manifest_pins':profile['external_manifests']}
assert final['functions']==614 and final['units']==12
final['references']['to54']=profile['fixed_reference']
for role,old in [('view4','view-dropout4'),('toggle4','base-toggle4'),('factory4','factory-version4'),('copy-bits4','as-strided-copy4'),('reduction-bits4','as-strided-reduction4'),('sum-lanes2','as-strided-lanes2'),('sum-branches6','as-strided-branches6')]:final['references'][role]=profile['additional_references'][old]
for role,path,probe in [('mixed36','validation/mixed-integer-autograd/reference/torch-mixed-integer-autograd.json','validation/mixed-integer-autograd/reference/pytorch_mixed_integer_autograd_probe.py'),('Saved14','validation/saved-public-lifetime/fixed-reference-original.json','tests/saved_public_lifetime_review/pytorch_saved_public_lifetime_probe.py')]:
 v=read(REPO/path);assert sha(REPO/probe)==v['probe_sha256']
 final['references'][role]={'path':path,'sha256':sha(REPO/path),'bytes':(REPO/path).stat().st_size,'probe_path':probe,'probe_sha256':v['probe_sha256']}
samples={
 'to54':BASE/'tensor-to-copy-extension/actual54-first-05/report.json',
 'view4':BASE/'to-view-dropout-reference4-01/native-first-05/report.json',
 'toggle4':BASE/'to-view-base-toggle-reference4-01/native-first-05/report.json',
 'copy-bits4':BASE/'tensor-to-copy-extension/as-strided-copy-bits-review/native-first-09b/report.json',
 'reduction-bits4':BASE/'tensor-to-copy-extension/as-strided-reduction-bits-review/native-first-09b/report.json',
 'sum-lanes2':BASE/'tensor-to-copy-extension/as-strided-sum-lanes-review/native-first-09b/report.json',
 'sum-branches6':BASE/'tensor-to-copy-extension/as-strided-sum-branches-review/native-first-09b/report.json',
 'mixed36':BASE/'tensor-to-copy-extension/mixed36-first-05/report.json',
 'Saved14':BASE/'tensor-to-copy-extension/saved14-first-05/report.json'}
# Schema names alone come from earlier unchanged-reader samples. Expected fields
# below are the final frozen producer contract, not old results repinned to09b.
items=[
 ('fixed-to-copy54','to54','replay_actual54.py',54,5588,38344,20118,20271696,2335872),
 ('fixed-view-dropout4','view4','replay_view_dropout4_v2.py',4,2061,11802,444,22368768,323584),
 ('fixed-base-toggle4','toggle4','replay_view_base_toggle4.py',4,5474,77288,4590,48931680,910080),
 ('fixed-as-strided-copy4','copy-bits4','replay_as_strided_copy4.py',4,480,2568,384,0,465152),
 ('fixed-as-strided-reduction4','reduction-bits4','replay_as_strided_reduction4.py',4,480,2568,384,0,465152),
 ('fixed-as-strided-lanes2','sum-lanes2','replay_as_strided_lanes2.py',2,240,1284,552,0,232576),
 ('fixed-as-strided-branches6','sum-branches6','replay_as_strided_branches6.py',6,720,3852,20572,0,697728),
 ('fixed-mixed36','mixed36','parent-regression09b/replay_actual36.py',36,4728,21477,4670,58018992,940416),
 ('fixed-saved14','Saved14','parent-regression09b/replay_saved_public14.py',14,2058,8842,2166,27261936,480320)]
final['producer_steps'].append({'name':'cold-native-build','kind':'cold','expected':{'units_reproduced_exactly':12}})
for name,role,reader,cases,frames,checks,words,rollback,rng in items:
 path='tests/tensor_to_copy_review/'+reader; sample=read(samples[role]); expect={'cases':cases,'passed':cases,'failed':0,'frames':frames,'checks':checks,'exact_words':words,'rollback_bytes':rollback,'rng_bytes':rng}
 if role=='to54':expect.update(conversion_calls=186,reference_indices=list(range(54)))
 if role=='toggle4':expect['snapshot_order_matches_reference']=True
 final['producer_steps'].append({'name':name,'kind':'reference','role':role,'expected':expect,
  'reader_path':path,'reader_sha256':sha(PACKAGE/path),'observer_path':'tests/tensor_to_copy_review/native_observer09.py',
  'observer_sha256':profile['observer_sha256'],'report_schema':sample['schema']})
final['producer_steps'].extend([
 {'name':'inherited-I64-eight','kind':'integer','expected':{}},
 {'name':'legacy523-twelve','kind':'legacy','expected':{'step_count':12,'existing_native_units_verified':12,'all_expected_statuses_and_counts_matched':True}}])
assert [r['name'] for r in final['producer_steps']]==profile['ordered_steps']
files={'source-custody':'audit_source09b.py','owner4-copied17':'test_view_roles.py','resources6':'test_resources.py','owned-entry5':'test_owned_entry_view05.py','Saved-entry6':'test_saved_entry_to.py','typed-handoff2':'test_typed_handoff_view05.py'}
for name,filename in files.items():
 rp='validation/to-view-owner-review/reports/'+name+'.json';row=read(INDEPENDENT/rp)
 assert row['source_sha256']==profile['source_sha256'] and row['native_sha256']==profile['native_sha256']
 final['outer_baselines'][name]={'path':rp,'sha256':sha(INDEPENDENT/rp)}
 script='tests/to_view_owner_review/'+filename
 final['scripts'][name]={'path':script,'sha256':sha(INDEPENDENT/script)}
 # Only stable semantic/count/configuration fields. ASLR-dependent owner hashes,
 # directory names and source-custody maps are verified from current raw data.
 keys={'source-custody':['status','schema','descriptor_bytes','descriptor_words','core_function_count','parent_functions','native_executed_here','Torch_executed_here','machine_code_certification','inputs_unchanged'],
 'owner4-copied17':['status','schema','case_count','passed','frames_before_EOF','checks','copied_negative_cases','full_owner_rollback_bytes','inputs_after_unchanged','native_executed','Torch_executed_here','observer_is_read_only','copied_controls_mutate_target'],
 'resources6':['status','schema','case_count','passed','frames_before_EOF','checks','copied_negative_cases','full_owner_rollback_bytes','inputs_after_unchanged','native_executed','Torch_executed_here','reference_sha256'],
 'owned-entry5':['status','schema','case_count','passed','native_probe_processes','interactive_frames','complete_owner_bytes_compared','linked_modules','native_probe_compiled_this_invocation','source_custody_after','Torch_executed_here','foreign_pointer_import','owner_descriptor_memcpy','compiler_sha256','runtime_linker_sha256','probe_source_sha256','probe_image_sha256'],
 'Saved-entry6':['status','case_count','passed','native_probe_processes','interactive_frames','complete_owner_bytes_compared','linked_modules','native_probe_recompiled_this_invocation','source_custody_after','Torch_executed_here','foreign_pointer_import','owner_descriptor_memcpy','EOF_exit_code','probe_source_sha256','probe_image_sha256'],
 'typed-handoff2':['status','schema','case_count','passed','frames_before_EOF','rollback_bytes','linked_modules','EOF_exit_code','source_custody_after','Torch_executed_here','raw_pointer_import','owner_descriptor_memcpy','controller_sha256','compiler_sha256','linker_sha256','previous_source_sha256','previous_native_sha256','qualification_image_sha256']}[name]
 final['outer_expected'][name]={k:row[k] for k in keys}
final['historical_archives']=[{'archive':'validation/to-view-owner-review/raw-evidence.tar.xz','archive_bytes':14813344,
 'archive_sha256':'29f0ac8b44d0f452030b4914eae1dac368592e9941e852ff06c36ae9882162a9',
 'manifest':'validation/to-view-owner-review/evidence-manifest.json','manifest_sha256':'c19ad4f8a76e4b897c35ed6fecc45f8238bc7e6a67b972fe1c0d3d2a414a4136','member_field':'members',
 'split_delivery':{'delivery_manifest_path':manifest_path,'delivery_manifest_sha256':sha(INDEPENDENT/manifest_path),
 'original_manifest_path':'validation/to-view-owner-review/package-manifest.json','original_manifest_sha256':'f17bdec965f6f706911b57525af88033e0b3bfccf1cd742b36f10780b3387da5',
 'verifier_path':'validation/to-view-owner-review/transport/verify_delivery.py','verifier_sha256':sha(INDEPENDENT/'validation/to-view-owner-review/transport/verify_delivery.py')}}]
# The six runners are the actual final09b executions. The unchanged original54
# manifest and full producer package bind all other reference/source bytes.
for rel in ['tests/pytorch_oracle.py','compatibility/pytorch-oracle-lock.json']:
 p=REPO/rel;final['extra_inputs'].append({'path':rel,'sha256':sha(p),'bytes':p.stat().st_size,'mode':p.stat().st_mode&511})
p=HERE/'current.py.in';text=p.read_text();tree=ast.parse(text);node=next(n for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='FINAL')
lines=text.splitlines(keepends=True);text=''.join(lines[:node.lineno-1])+'FINAL = '+pprint.pformat(final,sort_dicts=False,width=110)+'\n'+''.join(lines[node.end_lineno:]);ast.parse(text);p.write_text(text)
(HERE/'final-contract.json').write_text(json.dumps(final,indent=2)+'\n')
(HERE/'final-binding-source-custody.json').write_text(json.dumps({'status':'FROZEN_CONFIGURATION_NOT_NEW_NATIVE_EXECUTION','source_sha256':final['source_sha256'],'native_sha256':final['native_sha256'],'producer_package_manifest_sha256':final['producer_manifest_sha256'],'independent_physical_manifest_sha256':sha(INDEPENDENT/manifest_path),'original_logical_manifest_sha256':'f17bdec965f6f706911b57525af88033e0b3bfccf1cd742b36f10780b3387da5','reference_schema_samples_only':{role:{'path':str(q),'sha256':sha(q),'source_sha256':read(q)['source_sha256'],'native_sha256':read(q)['native_sha256'],'use':'original unchanged schema identity only; not a final native PASS'} for role,q in samples.items()},'outer_actual_baselines':final['outer_baselines'],'native_executed_by_this_binding':False,'Torch_executed':False},indent=2)+'\n')
print(json.dumps({'contract':str(HERE/'final-contract.json'),'sha256':sha(HERE/'final-contract.json'),'source':final['source_sha256'],'native':final['native_sha256'],'producer_steps':len(final['producer_steps']),'manifests':final['manifests']}))
