"""Execute the exact main prefix before the first native command; no fake child."""
from pathlib import Path
import ast,hashlib,importlib.util,json,sys,traceback
HERE=Path(__file__).resolve().parent
script=HERE/'tests/qualify_tensor_to_copy.py'
out=HERE/'preflight-01'
raw=script.read_bytes();tree=ast.parse(raw)
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
try_index=next(i for i,n in enumerate(main.body) if isinstance(n,ast.Try))
work=main.body[try_index]
cut=next(i for i,n in enumerate(work.body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='execute')
assert ast.literal_eval(work.body[cut].value.args[0])=='producer'
prefix=ast.Module(body=main.body[:try_index]+work.body[:cut],type_ignores=[])
# The execute closure is defined but cannot be reached: no call named execute
# exists anywhere in the selected executable statements outside that definition.
for n in prefix.body:
 if isinstance(n,(ast.FunctionDef,ast.ClassDef)):continue
 assert not any(isinstance(k,ast.Call) and isinstance(k.func,ast.Name) and k.func.id=='execute' for k in ast.walk(n))
spec=importlib.util.spec_from_file_location('final_to_coordinator',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
args=[str(script),'--repo','/dev/shm/heptatorch-d26699e25fea/HeptaTorch-tensor-to-integration','--parent-build','/dev/shm/heptatorch-d26699e25fea/mixed10-root-cold-integration-01/producer5/native','--upstream','/workspace/scratch/d26699e25fea/Hepta','--compiler','/workspace/scratch/d26699e25fea/stack-canonical-integration/native/stack-module-compiler','--linker','/workspace/scratch/d26699e25fea/stack-canonical-integration/native/stack-linker-session','--flat-compiler','/workspace/scratch/d26699e25fea/compiler-expansion/reproduce-build/compiler-1','--stack-build','/workspace/scratch/d26699e25fea/stack-canonical-integration','--output',str(out)]
sys.argv=args
g=m.__dict__
try:
 exec(compile(ast.fix_missing_locations(prefix),str(script)+'::<exact-pre-execution-prefix>','exec'),g)
 assert g['report']['commands']==[] and not g['report']['producer_executed_this_invocation']
 g['custody'].finish()
 result={'status':'PASS_EXACT_PREEXECUTION_ONLY','native_executions':0,'Torch_executions':0,'compiler_executions':0,'coordinator_sha256':hashlib.sha256(raw).hexdigest(),'same_source_main_prefix':True,'statements_before_try':try_index,'try_prefix_statements':cut,'first_unexecuted_command':'producer','inputs':len(g['custody'].files),'original_reports_and_refs_unchanged':True,'report':g['report']}
except BaseException as e:
 result={'status':'FAIL_EXACT_PREEXECUTION_ONLY','native_executions':0,'Torch_executions':0,'compiler_executions':0,'coordinator_sha256':hashlib.sha256(raw).hexdigest(),'error':repr(e),'traceback':traceback.format_exc(),'commands_started':g.get('report',{}).get('commands',[])}
 if out.exists():
  (out/'executed-coordinator.py').write_bytes(raw)
  (out/'executed-preflight.py').write_bytes(Path(__file__).read_bytes())
out.mkdir(parents=True,exist_ok=True)
p=out/'preflight-result.json';p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('report','traceback')}))
sys.exit(0 if result['status'].startswith('PASS') else 1)
