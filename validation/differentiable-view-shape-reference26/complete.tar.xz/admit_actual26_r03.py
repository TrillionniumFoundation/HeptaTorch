"""Pure admission of the one fixed R4 actual26 observation, never executes Torch/native."""
import argparse
import ast
import collections
import email
import hashlib
import io
import itertools
import json
import lzma
import math
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import traceback

PINS = {
    'original-packet/complete.tar.xz': 'e42fdfc7055566da52df3931038690044e51a8680a195911d87690ae23d931c4',
    'original-packet/manifest.json': '633c28707e559a601853677b195f1bd2c9bc589712f80673eb5b5e5e242da05e',
    'original-packet/verification.json': '6f96716085c5f85b8876e310ea127091e8af91a24619dd33f14c83f221a68021',
    'original-packet/payload/actual/actual.json': 'fecf1956790f78a9b1238f535c1c7cce9f1237b211c389ac0736d88687bbb9c9',
    'original-packet/payload/execution/execution.json': 'ba971fbf6762db9a40a662f8ec83b3b756cd92ef54de18c29532f356d6344113',
    'original-packet/payload/source/source-manifest.json': 'c9b98b083b78335f12eb697c066d55cd1d5c2db5a86296f874f17afc0ee0d08f',
    'original-packet/payload/source/pytorch_view_reshape_probe.py': '4dd374419e4b21a9c814c855d846481730a12ea57a30dcf229a6b962f07021c5',
    'original-packet/payload/source/actual-execution-intent.json': 'dab765cb2a2ade66114fab3546abe4643723945c863b011d1266e62fb35c2a93',
    'original-packet/payload/source/execute_actual_once.py': 'df3e97c87bef4d5208e068c098267dc99bdbbb687c185bfbae8451bbd4a6563f',
    'original-packet/payload/source/actual-request.json': 'a6069c1fe83ae502de553aeaa2065509a0e98a0a9522ecfd07e72e9e3edeae0a',
    'original-packet/payload/source/inputs/pytorch_oracle.py': 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae',
    'original-packet/payload/source/inputs/pytorch-oracle-lock.json': 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944',
    'original-packet/payload/source/inputs/pytorch-install.json': '35ad4841c2f2f94be7ded7f1bcc97f9592f806658ff660bfac5bdc3b0cf986ef',
}
SOURCE_ROOT = '/home/qian-qi/heptatorch-continuation-20261116/runs/differentiable-view-r4-shape-reference26-01'
JOB = '1a1e6e2725d-392-3c75'
KEY = 'heptatorch-d266-r4-view-reshape26-actual-20261117-v1'
PROVENANCE_CHECKS = {'python_matches', 'platform_matches', 'version_backend_matches',
    'git_matches_oracle_build_pin', 'distribution_version_matches', 'direct_url_matches',
    'direct_url_archive_sha256_matches', 'pip_report_url_matches', 'pip_report_archive_sha256_matches',
    'pip_report_version_matches', 'pip_report_requested'}
RAW_KEYS = {'tensor_identity','storage_identity','dtype','element_size','shape','strides','numel',
    'storage_bytes','storage_offset_elements','storage_offset_bytes','storage_raw_hex',
    'logical_bytes_hex','binary_words','version','requires_grad','is_view','base_tensor_identity'}
CAPTURE_KEYS = {'accepted','outcome','error','warnings'}
SNAPSHOT_KEYS = {'tensor_getter_order','tensors','relations','saved_getters_after_tensor_getters',
    'edge_getters','edges_after_all_tensor_getters','expired','state'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def jread(p):
    def unique(pairs):
        out = {}
        for k,v in pairs:
            if k in out:
                raise ValueError('duplicate JSON key: '+k)
            out[k] = v
        return out
    return json.loads(Path(p).read_bytes(), object_pairs_hook=unique,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))


class Audit:
    def __init__(self, root):
        self.root = root
        self.p = root/'original-packet/payload'
        self.count = 0
        self.categories = collections.Counter()
        self.raw_count = self.logical_bytes = self.storage_bytes = self.snapshot_count = 0
        self.states_referenced = collections.Counter()
        self.rows = []
        self.inputs = {}
        self.failure = None

    def ck(self, good, label):
        self.count += 1
        self.categories[label.split(':')[0]] += 1
        if not good:
            self.failure = label
            raise AssertionError(label)

    def keys(self, value, keys, label):
        self.ck(type(value) is dict and set(value) == set(keys), label)

    def integer(self, x, label, lower=0):
        self.ck(type(x) is int and x >= lower, label)

    def boolean(self, x, label):
        self.ck(type(x) is bool, label)

    def file(self, path, expected=None):
        p = Path(path)
        s = p.lstat()
        self.ck(stat.S_ISREG(s.st_mode), 'custody:regular:'+str(p))
        b = p.read_bytes()
        d = {'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(s.st_mode)}
        if expected:
            for k in ('bytes','sha256','mode'):
                if k in expected:
                    self.ck(d[k] == expected[k], 'custody:'+k+':'+str(p))
        self.inputs[str(p.relative_to(self.root))] = d
        return b

    def custody(self):
        for name,pin in PINS.items():
            self.file(self.root/name, {'sha256':pin})
        manifest = jread(self.root/'original-packet/manifest.json')
        raw = self.file(self.root/'original-packet/complete.tar.xz')
        self.ck(len(raw)==manifest['archive_bytes'] and sha(raw)==manifest['archive_sha256'], 'custody:archive-full')
        decoder = lzma.LZMADecompressor(format=lzma.FORMAT_XZ)
        tar = decoder.decompress(raw)
        self.ck(decoder.eof and not decoder.unused_data, 'custody:single-XZ-EOF')
        self.ck(len(tar)==manifest['tar_bytes'] and sha(tar)==manifest['tar_sha256'], 'custody:complete-tar')
        found = set()
        with tarfile.open(fileobj=io.BytesIO(tar),mode='r:') as tf:
            for member in tf:
                name = member.name
                self.ck(member.isfile() and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts,
                        'custody:safe-member:'+name)
                self.ck(name not in found and name in manifest['files'], 'custody:unique-member:'+name)
                found.add(name)
                b = tf.extractfile(member).read()
                expected = manifest['files'][name]
                self.ck(len(b)==expected['bytes']==member.size and sha(b)==expected['sha256'] and member.mode==expected['mode'],
                        'custody:archive-member:'+name)
                self.ck(self.file(self.p/name,expected)==b, 'custody:extracted-original:'+name)
        self.ck(found==set(manifest['files']) and len(found)==manifest['file_count']==40, 'custody:exact-40-members')
        self.ck(sum(v['bytes'] for v in manifest['files'].values())==manifest['expanded_bytes']==29086614,'custody:expanded-total')
        self.ck(manifest['new_Torch_executions']==manifest['new_native_executions']==0,'custody:copy-only')
        verification = jread(self.root/'original-packet/verification.json')
        self.ck(verification['single_XZ_EOF'] is True and verification['all_bytes_modes_verified'] is True,'custody:remote-byte-verification')
        self.ck(verification['archive_sha256']==manifest['archive_sha256'] and verification['manifest_sha256']==sha((self.root/'original-packet/manifest.json').read_bytes()),'custody:remote-verification-pins')
        self.manifest = manifest
        self.mapping = manifest['input_path_mapping']
        self.e = e = jread(self.p/'execution/execution.json')
        before = jread(self.p/'execution/inputs-before.json')
        after = jread(self.p/'execution/inputs-after.json')
        self.ck(before==after==e['inputs_before']==e['inputs_after'],'custody:all-inputs-before-after')
        self.ck(len(before)==len(self.mapping)==e['input_file_count']==33 and set(before)==set(self.mapping),'custody:33-complete-bound-paths')
        for original,entry in before.items():
            self.ck(entry['path']==original and Path(entry['resolved']).is_absolute(),'custody:original-path:'+original)
            name = self.mapping[original]
            self.ck(manifest['files'][name]['original_path']==original,'custody:archive-input-map:'+original)
            self.file(self.p/name, entry)
        sm = jread(self.p/'source/source-manifest.json')
        self.ck(len(sm['files'])==e['declared_inputs_count']==18,'custody:declared18')
        for entry in sm['files']:
            original = SOURCE_ROOT+'/'+entry['path']
            self.ck(original in before,'custody:declared-input-present:'+original)
            self.ck(all(before[original][k]==entry[k] for k in ('bytes','sha256','mode')),'custody:declared-input-exact:'+original)
        primary = [x for x in sm['files'] if x['path'].startswith('upstream/')]
        self.ck(len(primary)==e['primary_source_count']==5,'custody:five-complete-primary-files')
        self.ck(e['status']=='PASS_ACTUAL_EXECUTED_AND_INPUTS_BOUND' and e['all_bound_inputs_unchanged'] is True,'execution:wrapper-success')
        self.ck(e['Torch_probe_started'] is True and e['Torch_probe_completed'] is True and e['probe_returncode']==0,'execution:one-child-terminal0')
        self.ck(e['native_executed'] is False and e['wrapper_imports_Torch'] is False,'execution:no-native-or-wrapper-Torch')
        self.ck(e['stdout_closed'] is True and e['stderr_closed'] is True,'execution:child-EOF')
        for key,name in (('stdout','probe.stdout'),('stderr','probe.stderr'),('original_actual','../actual/actual.json')):
            self.file(self.p/'execution'/name,e[key])
        self.intent = intent = jread(self.p/'source/actual-execution-intent.json')
        self.ck(e['original_intent']==intent and e['idempotency_key']==intent['idempotency_key']==KEY,'execution:exact-original-intent')
        command = jread(self.p/'execution/actual-command.json')
        self.ck(command=={'executable':intent['executable'],'argv':[intent['executable']]+intent['args'],
                         'cwd':intent['cwd'],'environment_inherited':True},'execution:exact-actual-command')
        request = jread(self.root/'actual-request.json')
        self.ck(request==jread(self.p/'source/actual-request.json'),'execution:request-persisted-before-start')
        self.ck(request['idempotency_key']==KEY and request['executable']==intent['executable'] and request['host']=='rog','execution:outer-request-identity')
        launch = jread(self.root/'actual-start-response.json')
        job = launch['job']
        self.ck(job['id']==JOB and job['idempotency_key']==KEY and launch['reused'] is False,'execution:unique-durable-job')
        for key in ('args','cwd','executable','host','idempotency_key'):
            self.ck(job[key]==request[key],'execution:request-job:'+key)
        terminal = jread(self.root/'actual-terminal-status.json')
        self.ck(terminal['job_id']==JOB and terminal['state']=='succeeded' and terminal['exit_code']==0,'execution:durable-terminal')
        for key in ('output_complete','output_durable','terminal_publication_confirmed'):
            self.ck(terminal[key] is True,'execution:'+key)
        for key in ('automatic_retry','cancelled','timed_out'):
            self.ck(terminal[key] is False,'execution:'+key)
        logs = jread(self.root/'actual-terminal-log-read.json')
        self.ck(logs['job_id']==JOB,'execution:log-job')
        for stream in ('stdout','stderr'):
            d=logs[stream]; b=bytes.fromhex(d['bytes_hex'])
            self.ck(d['offset']==0 and d['eof'] is True and d['size']==d['next_offset']==len(b),'execution:durable-EOF:'+stream)
            self.ck(terminal['log_synced'][stream] is True and terminal['log_truncated'][stream] is False and
                    terminal['log_errors'][stream] is None and terminal['log_bytes'][stream]=={'seen':len(b),'stored':len(b)},'execution:durable-untruncated:'+stream)
        for name in ('actual-request.json','actual-start-response.json','actual-terminal-status.json','actual-terminal-log-read.json'):
            self.file(self.root/name)

    def provenance(self):
        a=self.actual
        lock=jread(self.p/'source/inputs/pytorch-oracle-lock.json'); expected=lock['oracle']
        v=a['oracle_provenance']; o=v['observed']; e=self.e['environment_before']
        self.ck(v['status']=='PASS' and v['metadata_error'] is None,'provenance:status')
        self.ck(v['expected']==expected and v['release_source_equivalence']==lock['release_source_equivalence'],'provenance:complete-lock-equality')
        self.ck(v['lock_sha256']==sha((self.p/'source/inputs/pytorch-oracle-lock.json').read_bytes()) and v['lock_path']==SOURCE_ROOT+'/inputs/pytorch-oracle-lock.json','provenance:lock-path-and-bytes')
        self.ck(set(v['checks'])==PROVENANCE_CHECKS and len(v['checks'])==11,'provenance:exact-11-flags')
        for k in PROVENANCE_CHECKS:self.ck(v['checks'][k] is True,'provenance:flag:'+k)
        self.ck(o['python']['implementation']==expected['python']['implementation'] and o['python']['version']==expected['python']['version'],'provenance:python')
        self.ck(o['python']['full_version']==e['python'] and o['platform']==expected['platform'] and
                e['platform']==o['platform']['sys_platform'] and e['machine']==o['platform']['machine'],'provenance:platform-full-record')
        self.ck(o['version']==o['distribution_version']==e['torch_distribution_version']==expected['version'],'provenance:installed-versions')
        self.ck(o['git_commit']==expected['git_commit'] and o['backend_versions']==expected['backend_versions'],'provenance:build-and-backends')
        paths=[k for k in self.mapping if k.endswith('.dist-info/direct_url.json')]
        self.ck(len(paths)==1,'provenance:single-installed-direct-url')
        direct=jread(self.p/self.mapping[paths[0]])
        wheel=expected['wheel']; canonical={'archive_info':{'hash':'sha256='+wheel['sha256'],'hashes':{'sha256':wheel['sha256']}},'url':wheel['url']}
        self.ck(o['direct_url']==e['direct_url']==direct==canonical,'provenance:complete-direct-url')
        pip=jread(self.p/self.mapping[self.e['actual_pip_report']['path']])
        records=[x for x in pip['install'] if x['metadata']['name']=='torch']
        self.ck(len(records)==1,'provenance:single-Torch-install-record')
        installed=records[0]
        self.ck(installed==e['installed_torch_record'] and installed['requested'] is True and installed['is_direct'] is True and installed['is_yanked'] is False,'provenance:complete-pip-Torch-record')
        self.ck(installed['download_info']==canonical and installed['metadata']['version']==expected['version'],'provenance:locked-pip-archive')
        want={'path':expected['install_report'],'pip_version':pip['pip_version'],
              'download_info':installed['download_info'],'metadata_name':installed['metadata']['name'],
              'metadata_version':installed['metadata']['version'],'requested':installed['requested']}
        self.ck(o['install_report']==want,'provenance:all-observed-pip-fields')
        metadata_paths=[p for p in self.mapping if p.endswith('.dist-info/METADATA')]
        self.ck(len(metadata_paths)==1,'provenance:single-installed-metadata')
        metadata=(self.p/self.mapping[metadata_paths[0]]).read_bytes()
        parsed=email.message_from_bytes(metadata)
        self.ck(parsed['Name']==expected['distribution'] and parsed['Version']==expected['version'],'provenance:installed-metadata-name-version')
        self.ck(sha(metadata)==wheel['metadata_sha256'],'provenance:installed-metadata-full-sha')
        self.ck(self.e['full_observed_provenance_matches_prebound_files'] is True and self.e['all_11_provenance_true'] is True,'provenance:outer-source-bound-checks')
        env={'deterministic_algorithms':True,'deterministic_fill':True,'grad_enabled':True,'num_threads':1,'cpu_capability':'AVX512'}
        self.ck(a['environment_before']==a['environment_after']==env,'environment:exact-before-after')
        self.ck(a['cpu_capability']=='AVX512' and a['num_threads']==1,'environment:observed-vector-profile')
        self.ck('CPU capability usage: AVX512' in a['build_configuration'] and 'COMMIT_SHA='+expected['git_commit'] in a['build_configuration'],'environment:full-build-configuration')
        for k in ('environment_restored','original_outer_rng_restored','source_files_unchanged'):
            self.ck(a[k] is True,'environment:'+k)

    def capture(self,x,label,extra=()):
        self.keys(x,CAPTURE_KEYS|set(extra),label+':keys')
        self.boolean(x['accepted'],label+':accepted')
        self.ck(x['outcome']==('SUCCEEDED' if x['accepted'] else 'RAISED'),label+':outcome')
        if x['accepted']:self.ck(x['error'] is None,label+':no-error')
        else:
            self.keys(x['error'],('type','message'),label+':error-keys')
            self.ck(all(type(x['error'][k]) is str and x['error'][k] for k in ('type','message')),label+':original-error')
        self.ck(type(x['warnings']) is list,label+':warnings')
        for warning in x['warnings']:
            self.keys(warning,('type','message'),label+':warning-keys')
            self.ck(all(type(warning[k]) is str for k in warning),label+':warning-text')

    def raw_tensor(self,x,label):
        if x is None:return
        self.raw_count+=1
        self.keys(x,RAW_KEYS,label+':raw-keys')
        for k in ('tensor_identity','storage_identity'):
            self.ck(type(x[k]) is str and re.fullmatch('[1-9][0-9]*',x[k]) is not None,label+':'+k)
        widths={'torch.float32':4,'torch.bool':1,'torch.int64':8,'torch.float64':8}
        self.ck(x['dtype'] in widths and x['element_size']==widths[x['dtype']],label+':dtype-width')
        width=x['element_size'];shape=x['shape'];strides=x['strides']
        if x['dtype']=='torch.float64':
            self.ck(':Saved-_saved_other:tensor' in label and shape==[] and strides==[] and
                    x['requires_grad'] is False and x['is_view'] is False and x['base_tensor_identity'] is None,
                    label+':internal-wrapped-scalar-only-no-public-F64-claim')
        self.ck(type(shape) is list and type(strides) is list and len(shape)==len(strides)<=4,label+':rank')
        self.ck(all(type(v)is int and v>=0 for v in shape+strides),label+':concrete-geometry')
        for k in ('numel','storage_bytes','storage_offset_elements','storage_offset_bytes','version'):
            self.integer(x[k],label+':'+k)
        self.ck(x['numel']==math.prod(shape),label+':numel')
        self.ck(x['storage_offset_bytes']==width*x['storage_offset_elements'],label+':offset-units')
        for k in ('requires_grad','is_view'):self.boolean(x[k],label+':'+k)
        self.ck(x['base_tensor_identity'] is None or (type(x['base_tensor_identity']) is str and re.fullmatch('[1-9][0-9]*',x['base_tensor_identity']) is not None),label+':base-identity')
        self.ck(x['is_view']==(x['base_tensor_identity'] is not None),label+':base-presence')
        for k in ('storage_raw_hex','logical_bytes_hex'):
            self.ck(type(x[k]) is str and re.fullmatch('(?:[0-9a-f]{2})*',x[k]) is not None,label+':'+k)
        storage=bytes.fromhex(x['storage_raw_hex']);logical=bytes.fromhex(x['logical_bytes_hex'])
        self.ck(len(storage)==x['storage_bytes'] and len(storage)%width==0 and len(logical)==x['numel']*width,label+':full-byte-extents')
        recomputed=bytearray()
        for coordinates in itertools.product(*(range(n) for n in shape)):
            at=x['storage_offset_elements']+sum(i*s for i,s in zip(coordinates,strides))
            self.ck(0<=at*width and (at+1)*width<=len(storage),label+':physical-element-bounds')
            recomputed.extend(storage[at*width:(at+1)*width])
        self.ck(bytes(recomputed)==logical,label+':logical-bytes-from-entire-Storage')
        words=x['binary_words']
        self.ck(type(words)is list and len(words)==x['numel'] and all(type(w)is int and 0<=w<1<<(8*width) for w in words),label+':raw-integer-words')
        self.ck(b''.join(w.to_bytes(width,'little') for w in words)==logical,label+':exact-word-bytes')
        self.logical_bytes+=len(logical);self.storage_bytes+=len(storage)

    def primitive(self,x,label):
        if x is None or type(x) in (bool,int,str):return
        if type(x)is list:
            for i,v in enumerate(x):self.primitive(v,label+'/'+str(i))
        elif type(x)is dict and set(x)=={'tensor'}:self.raw_tensor(x['tensor'],label+':tensor')
        elif type(x)is dict and set(x)=={'double_bits'}:
            self.ck(type(x['double_bits'])is int and 0<=x['double_bits']<1<<64,label+':f64-raw')
        else:
            self.keys(x,('type','diagnostic_repr'),label+':diagnostic-keys')
            self.ck(all(type(v)is str for v in x.values()),label+':diagnostic-strings')

    def node(self,x,label,depth=4):
        if x is None:return
        keys={'kind'}|({'variable'} if x.get('kind')=='AccumulateGrad' else set())|({'next_edges'} if depth else set())
        self.keys(x,keys,label+':node-keys')
        self.ck(type(x['kind'])is str and bool(x['kind']),label+':node-kind')
        if 'variable'in x:self.raw_tensor(x['variable'],label+':accumulator-real-variable')
        if depth:
            self.ck(type(x['next_edges'])is list,label+':next-edges')
            for i,edge in enumerate(x['next_edges']):
                self.keys(edge,('output_nr','node'),label+':edge-keys')
                self.integer(edge['output_nr'],label+':output-nr')
                self.node(edge['node'],label+'/'+str(i),depth-1)

    def snapshot(self,x,label):
        self.snapshot_count+=1
        self.keys(x,SNAPSHOT_KEYS,label+':snapshot-keys')
        names=x['tensor_getter_order']
        self.ck(type(names)is list and len(set(names))==len(names) and all(type(n)is str for n in names),label+':getter-order')
        self.ck(list(x['tensors'])==names and list(x['edge_getters'])==names,label+':all-named-getters')
        for name in names:
            t=x['tensors'][name];p=label+'/'+name
            self.keys(t,('before_grad_fn_getter','grad_fn_getter','requires_grad_after_grad_fn_getter','is_leaf_after_grad_fn_getter','retains_grad','gradient'),p+':tensor-observation-keys')
            self.raw_tensor(t['before_grad_fn_getter'],p+':before-getters')
            self.boolean(t['requires_grad_after_grad_fn_getter'],p+':requires-after')
            for key,valuekey in (('grad_fn_getter','node'),('is_leaf_after_grad_fn_getter','value'),('retains_grad','value'),('gradient','tensor')):
                g=t[key];self.capture(g,p+':'+key, (valuekey,) if g['accepted'] else ())
                if g['accepted']:
                    if valuekey=='node':self.node(g['node'],p+':grad-fn')
                    elif valuekey=='tensor':self.raw_tensor(g['tensor'],p+':gradient')
                    else:self.boolean(g['value'],p+':'+key+'-value')
            self.capture(x['edge_getters'][name],p+':second-grad-fn-getter')
        successful=[n for n in names if x['edge_getters'][n]['accepted']]
        self.ck(list(x['saved_getters_after_tensor_getters'])==successful and list(x['edges_after_all_tensor_getters'])==successful,label+':complete-second-getter-results')
        for name,attributes in x['saved_getters_after_tensor_getters'].items():
            self.ck(type(attributes)is dict and list(attributes)==sorted(attributes),label+':sorted-Saved-attributes')
            for key,g in attributes.items():
                self.ck(key.startswith('_saved_'),label+':Saved-key')
                self.capture(g,label+':Saved-'+key,('value',) if g['accepted'] else ())
                if g['accepted']:self.primitive(g['value'],label+':Saved-'+key)
        for name,edges in x['edges_after_all_tensor_getters'].items():
            self.ck(type(edges)is list,label+':actual-current-edges')
            for edge in edges:
                self.keys(edge,('output_nr','node','matches_live_current_grad_fn'),label+':current-edge-keys')
                self.integer(edge['output_nr'],label+':current-output-nr')
                self.node(edge['node'],label+':actual-current-node')
                match=edge['matches_live_current_grad_fn']
                self.ck(type(match)is list and len(match)==len(set(match)) and all(n in successful for n in match),label+':actual-edge-identity-match-names')
                if edge['node']is None:self.ck(match==[],label+':None-edge-no-fabricated-match')
        combos=list(itertools.combinations(names,2))
        self.ck(list(x['relations'])==[l+'|'+r for l,r in combos],label+':all-pairwise-relations')
        for left,right in combos:
            d=x['relations'][left+'|'+right]
            self.keys(d,('same_Python_object','same_Tensor','same_Storage','same_current_Version_value'),label+':relation-keys')
            for v in d.values():self.boolean(v,label+':relation-bool')
            l=x['tensors'][left]['before_grad_fn_getter'];r=x['tensors'][right]['before_grad_fn_getter']
            for key,field in (('same_Tensor','tensor_identity'),('same_Storage','storage_identity'),('same_current_Version_value','version')):
                self.ck(d[key]==(l[field]==r[field]),label+':relation-'+key)
            self.ck(not d['same_Python_object'] or d['same_Tensor'],label+':Python-identity-implies-real-T')
        self.ck(type(x['expired'])is dict and all(type(v)is bool for v in x['expired'].values()),label+':actual-weak-observations')
        self.ck(x['state'] in self.states,label+':full-MT-reference')
        self.states_referenced[x['state']]+=1

    def event(self,x,label):
        extra={'label','before','after'}
        if x['accepted']:extra.add('returned')
        if 'returned_is_existing'in x:extra.add('returned_is_existing')
        self.capture(x,label,extra)
        self.ck(type(x['label'])is str and bool(x['label']),label+':label')
        self.snapshot(x['before'],label+':before');self.snapshot(x['after'],label+':after')
        if x['accepted']:self.primitive(x['returned'],label+':returned')
        if 'returned_is_existing'in x:
            d=x['returned_is_existing']
            self.ck(list(d)==x['before']['tensor_getter_order'] and all(type(v)is bool for v in d.values()),label+':return-identity-completeness')
            self.ck(type(x['returned'])is dict and set(x['returned'])=={'tensor'},label+':Tensor-return')
            t=x['returned']['tensor']
            for n,value in d.items():
                self.ck(not value or t['tensor_identity']==x['before']['tensors'][n]['before_grad_fn_getter']['tensor_identity'],label+':return-identical-T')

    def observed_trace(self,row,spec):
        """Derive attempted operation order from fixed probe control flow and observed states."""
        events=row['events'];cursor=0
        def take(label):
            nonlocal cursor
            self.ck(cursor<len(events) and events[cursor]['label']==label,'trace:declared-next-event:'+str(row['index'])+':'+label)
            result=events[cursor];cursor+=1;return result
        self.ck(take('construct_backing')['accepted'] is True,'trace:actual-backing-created')
        family=spec['family']
        if family in ('nonleaf_mul','nonleaf_mul_transpose'):
            self.ck(take('backing_requires_grad_true')['accepted'] is True,'trace:actual-input-requires')
            if family=='nonleaf_mul':self.ck(take('construct_mul_input')['accepted'] is True,'trace:actual-mul-created')
            else:
                self.ck(take('construct_mul_middle')['accepted'] is True,'trace:actual-middle-created')
                self.ck(take('construct_transpose_input')['accepted'] is True,'trace:actual-transpose-created')
        else:
            self.ck(take('construct_'+family)['accepted'] is True,'trace:actual-input-geometry-created')
            if family=='derived_requires_view':self.ck(take('backing_requires_grad_true')['accepted'] is True,'trace:actual-derived-requires')
            elif spec['requires_grad']:self.ck(take('input_requires_grad_true')['accepted'] is True,'trace:actual-own-requires')
        target=take('target_'+spec['operation'])
        result_meta=None
        if not target['accepted']:
            self.ck(row.get('remaining_not_attempted')=='target view/reshape raised; no result Tensor exists','trace:original-target-exception-scope')
        else:
            result_meta=target['returned']['tensor']
            grad_names=[n for n in ('backing','middle','input','result') if n in target['after']['tensors'] and target['after']['tensors'][n]['requires_grad_after_grad_fn_getter']]
            for name in grad_names:
                if not target['after']['tensors'][name]['is_leaf_after_grad_fn_getter']['value']:
                    take('retain_grad_'+name)
            if target['after']['tensors']['result']['requires_grad_after_grad_fn_getter']:
                for phase,seedplan in enumerate(spec['seed_phases']):
                    if phase:
                        for name in grad_names:take('clear_before_phase_'+str(phase)+'_'+name)
                        take('drop_seed_before_phase_'+str(phase))
                    seed=take('construct_seed_phase_'+str(phase))
                    self.ck(seed['accepted'] is True,'trace:actual-seed-created')
                    rawseed=seed['returned']['tensor'];pattern=seedplan['repeating_input_words']
                    self.ck(rawseed['shape']==result_meta['shape'] and rawseed['dtype']=='torch.float32' and
                            rawseed['binary_words']==[pattern[i%len(pattern)] for i in range(result_meta['numel'])], 'trace:exact-declared-seed-bits')
                    self.ck(rawseed['is_view'] is False and rawseed['base_tensor_identity'] is None,'trace:seed-published-nonview')
                    backward=take('backward_phase_'+str(phase)+'_'+seedplan['name'])
                    for name in grad_names:
                        if backward['after']['tensors'][name]['gradient'].get('tensor') is not None:
                            take('hold_phase_'+str(phase)+'_'+name+'_gradient')
                if family in ('nonleaf_mul','nonleaf_mul_transpose'):take('backward_retry_after_default')
            else:self.ck(row.get('backward_not_attempted')=='actual result.requires_grad is false','trace:actual-no-gradient-scope')
            take('mutate_result_fill_nograd')
        self.ck(row['before_final_drops']['tensor_getter_order']==events[cursor-1]['after']['tensor_getter_order'],'trace:final-live-order')
        for name in row['before_final_drops']['tensor_getter_order']:take('final_drop_'+name)
        self.ck(cursor==len(events),'trace:all-events-consumed')
        self.ck(events[-1]['after']['tensor_getter_order']==[],'trace:all-public-roots-dropped')
        self.ck(row['final_expired']==events[-1]['after']['expired'],'trace:final-weak-observations-preserved')
        return target,result_meta

    def data(self):
        a=self.actual=jread(self.p/'actual/actual.json')
        self.provenance()
        self.ck(a['schema']=='heptatorch.concrete-view-reshape-reference26.v1' and a['status']=='OBSERVED','actual:schema-status')
        self.ck(a['torch_executed'] is True and a['native_executed'] is False and a['native_qualified'] is False,'actual:observation-only')
        self.ck(a['full_pytorch_rewrite_complete'] is False and a['closed_schema_count']==0 and a['pytorch_api_denominator']==2590,'actual:unchanged-scope-boundary')
        self.ck(a['probe_errors']==[] and a['probe_error_count']==0 and a['cases']==len(a['rows'])==26,'actual:complete-26')
        probe=(self.p/'source/pytorch_view_reshape_probe.py').read_text();tree=ast.parse(probe)
        assignments={n.targets[0].id:n.value for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
        call=assignments['CASE_PLAN'];self.ck(isinstance(call,ast.Call) and isinstance(call.func,ast.Attribute) and call.func.attr=='loads','actual:fixed-case-plan-literal')
        baseplan=json.loads(ast.literal_eval(call.args[0]));phases=ast.literal_eval(assignments['SEED_PHASES'])
        plan=[{**x,'seed_phases':[{'name':n,'repeating_input_words':list(w)} for n,w in phases]} for x in baseplan]
        self.ck(a['case_plan']==plan,'actual:every-plan-field-from-frozen-probe')
        self.ck(baseplan==jread(self.p/'source/case-plan.json'),'actual:complete-base-plan-file')
        self.ck(a['probe_sha256']==sha(probe.encode()),'actual:executed-probe-sha')
        self.ck(a['primary_source_ref']==ast.literal_eval(assignments['SOURCE_REF']) and a['primary_source_pins']==ast.literal_eval(assignments['SOURCE_PINS']),'actual:primary-source-declarations')
        for upstream,pin in a['primary_source_pins'].items():
            self.ck(sha((self.p/'source/upstream'/Path(upstream).name).read_bytes())==pin,'actual:full-primary-file:'+upstream)
        source_paths={SOURCE_ROOT+'/pytorch_view_reshape_probe.py':a['probe_sha256'],SOURCE_ROOT+'/inputs/pytorch_oracle.py':ast.literal_eval(assignments['SUPPORT_SHA']),SOURCE_ROOT+'/inputs/pytorch-oracle-lock.json':ast.literal_eval(assignments['LOCK_SHA'])}
        self.ck(a['inputs_sha256']==source_paths,'actual:probe-own-three-inputs')
        self.states=a['states']
        self.ck(type(self.states)is dict and len(self.states)==a['unique_complete_states']>0,'rng:complete-state-inventory')
        for key,d in self.states.items():
            self.keys(d,('bytes','hex'),'rng:state-keys')
            b=bytes.fromhex(d['hex']);self.ck(len(b)==d['bytes']==5056 and sha(b)==key,'rng:full-5056-byte-hash')
        totals=collections.Counter(attempted=0,succeeded=0,raised=0)
        for index,(row,spec) in enumerate(zip(a['rows'],plan,strict=True)):
            extras={'state_before_setup','events','before_final_drops','status','final_expired','state_after'}
            for key in ('remaining_not_attempted','backward_not_attempted'):
                if key in row:extras.add(key)
            self.keys(row,set(spec)|extras,'row:complete-keys:'+str(index))
            self.ck({k:row[k] for k in spec}==spec and row['index']==index and row['status']=='OBSERVED','row:complete-declared-spec:'+str(index))
            self.ck(type(row['events'])is list and bool(row['events']),'row:events-present:'+str(index))
            for k in ('state_before_setup','state_after'):
                self.ck(row[k]in self.states,'rng:row-state:'+str(index)+':'+k);self.states_referenced[row[k]]+=1
            before_count=self.count
            for n,event in enumerate(row['events']):
                self.event(event,'observation:case'+str(index)+'/event'+str(n))
                totals['attempted']+=1;totals['succeeded' if event['accepted'] else 'raised']+=1
            self.snapshot(row['before_final_drops'],'observation:case'+str(index)+'/before-final-drops')
            self.ck(type(row['final_expired'])is dict and all(type(v)is bool for v in row['final_expired'].values()),'row:final-weak-values')
            target,meta=self.observed_trace(row,spec)
            self.rows.append({'index':index,'name':row['name'],'original_status':row['status'],
                'event_count':len(row['events']),'checks':self.count-before_count,
                'target_accepted_observed':target['accepted'],'target_error_observed':target['error'],
                'initial_result_metadata_observed':None if meta is None else {k:v for k,v in meta.items() if k not in ('storage_raw_hex','logical_bytes_hex','binary_words')},
                'initial_result_grad_fn_observed':None if meta is None else target['after']['tensors']['result']['grad_fn_getter'],
                'all_operation_errors_observed':[{'label':x['label'],'error':x['error']} for x in row['events'] if not x['accepted']],
                'final_expired_observed':row['final_expired'],
                'row_canonical_structure_sha256':sha(json.dumps(row,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode())})
        self.ck(dict(totals)==a['operation_totals']==self.e['operation_totals']=={'attempted':483,'succeeded':475,'raised':8},'actual:all-operation-totals-recomputed')
        self.ck(set(self.states_referenced)==set(self.states),'rng:all-records-referenced-no-extra')
        self.totals=dict(totals)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();root=args.root.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    audit=Audit(root)
    result={'schema':'heptatorch.independent-view-reshape26-admission.v1','status':'FAIL','admission':False,
        'native_executed':False,'Torch_executed_here':False,'original_actual_executions':1,
        'original_job':JOB,'original_key':KEY,'original_actual_sha256':PINS['original-packet/payload/actual/actual.json'],
        'reader_sha256':sha(Path(__file__).read_bytes()),'closed_schema_count':0,'full_pytorch_rewrite_complete':False,
        'scope':'Original byte custody, fixed provenance, exhaustive recorded field/geometry/identity consistency and source-declared event coverage. No predicted numerical oracle or native parity is claimed. Version value equality is not Version-counter identity; hidden Clone/UnsafeView counter separation is source-only evidence.'}
    rc=1
    try:
        audit.custody();audit.data()
        result.update(status='PASS_REFERENCE_ADMITTED',admission=True,operation_totals=audit.totals,
            original_case_count=26,original_probe_errors=0,raw_tensor_observations_checked=audit.raw_count,
            snapshot_observations_checked=audit.snapshot_count,logical_bytes_checked=audit.logical_bytes,
            full_Storage_bytes_checked=audit.storage_bytes,complete_MT_state_references=dict(audit.states_referenced),rows=audit.rows)
        rc=0
    except BaseException as e:
        result.update(error=repr(e),failed_check=audit.failure,traceback=traceback.format_exc())
    result.update(checks_passed=audit.count-(1 if audit.failure else 0),checks_failed=int(bool(audit.failure)),
                  check_categories=dict(sorted(audit.categories.items())),bound_inputs=audit.inputs)
    p=out/'report.json';p.write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n');p.chmod(0o600)
    print(json.dumps({'status':result['status'],'admission':result['admission'],'checks_passed':result['checks_passed'],
                      'checks_failed':result['checks_failed'],'failed_check':audit.failure,'report_sha256':sha(p.read_bytes())}))
    raise SystemExit(rc)


if __name__=='__main__':main()
