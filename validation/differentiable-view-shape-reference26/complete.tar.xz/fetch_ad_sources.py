#!/usr/bin/env python3
"""Fetch exact official source bytes and verify Git blob identity; source only."""
from pathlib import Path
import base64
import hashlib
import json
import traceback
import urllib.parse
import urllib.request

REF = '31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457'
OUT = Path('/home/qian-qi/heptatorch-continuation-20261116/runs/r4-view-reshape-ad-official-source-review-01')
FILES = [
    'tools/autograd/derivatives.yaml',
    'tools/autograd/gen_inplace_or_view_type.py',
    'tools/autograd/gen_variable_type.py',
    'c10/core/TensorImpl.h',
    'c10/core/TensorImpl.cpp',
    'torch/csrc/autograd/VariableTypeUtils.h',
    'aten/src/ATen/native/native_functions.yaml',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    OUT.mkdir(exist_ok=False)
    report = {'schema': 'heptatorch.r4-official-ad-source-custody.v1',
              'status': 'RUNNING', 'commit': REF, 'files': [],
              'native_executions': 0, 'Torch_executions': 0, 'compiler_executions': 0}
    code = 0
    try:
        for rel in FILES:
            url = 'https://api.github.com/repos/pytorch/pytorch/contents/' + rel + '?ref=' + REF
            request = urllib.request.Request(url, headers={
                'User-Agent': 'HeptaTorch-fixed-source-review',
                'Accept': 'application/vnd.github+json'})
            with urllib.request.urlopen(request, timeout=60) as response:
                status = response.status
                raw = response.read()
            json_path = OUT / 'github' / (rel.replace('/', '__') + '.json')
            json_path.parent.mkdir(exist_ok=True)
            json_path.write_bytes(raw)
            json_path.chmod(0o600)
            rec = json.loads(raw)
            assert status == 200 and rec['type'] == 'file' and rec['path'] == rel
            assert rec['encoding'] == 'base64'
            content = base64.b64decode(rec['content'])
            assert len(content) == rec['size']
            blob = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
            assert blob == rec['sha']
            path = OUT / 'upstream' / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
            path.chmod(0o600)
            report['files'].append({'path': rel, 'bytes': len(content), 'sha256': sha(content),
                                    'mode': 0o600, 'git_blob': blob, 'url': url,
                                    'github_response': str(json_path.relative_to(OUT)),
                                    'github_response_bytes': len(raw),
                                    'github_response_sha256': sha(raw)})
            (OUT / 'custody.json').write_text(json.dumps(report, indent=2) + '\n')
        report['status'] = 'PASS_OFFICIAL_SOURCE_BYTES_AND_GIT_BLOBS'
    except BaseException as exc:
        report.update(status='FAIL', error=repr(exc), traceback=traceback.format_exc())
        code = 1
    (OUT / 'custody.json').write_text(json.dumps(report, indent=2) + '\n')
    (OUT / 'custody.json').chmod(0o600)
    print(json.dumps(report))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
