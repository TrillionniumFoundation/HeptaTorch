"""Seal exact originals and independent actual26 admission; byte-only operation."""
import argparse
import hashlib
import io
import json
import lzma
from pathlib import Path
import stat
import tarfile


def sha(b):return hashlib.sha256(b).hexdigest()


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args();r=a.root.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
    chosen={p for p in r.iterdir() if p.is_file() and (p.suffix in ('.json','.py','.diff','.md'))}
    for prefix in ('inputs','transport','source-ad-review','admission-first-01','admission-r02-first','admission-r03-first'):
        chosen.update(p for p in (r/prefix).rglob('*') if p.is_file())
    for prefix in ('original-packet','ad-source-packet'):
        chosen.update(p for p in (r/prefix).iterdir() if p.is_file())
        chosen.update((r/prefix/'chunks').glob('*.response.json'))
    for name in ('constructors.py','overlay.py','geometry.py'):
        chosen.add(r/'r4-compile-source'/name)
    files={};stream=io.BytesIO()
    with tarfile.open(fileobj=stream,mode='w',format=tarfile.USTAR_FORMAT) as tf:
        for p in sorted(chosen):
            name=str(p.relative_to(r));b=p.read_bytes();s=p.lstat();assert stat.S_ISREG(s.st_mode)
            mode=stat.S_IMODE(s.st_mode)
            files[name]={'bytes':len(b),'mode':mode,'sha256':sha(b),'original_cloud_path':str(p)}
            item=tarfile.TarInfo(name);item.size=len(b);item.mode=mode;item.mtime=0;item.uid=item.gid=0
            tf.addfile(item,io.BytesIO(b))
    tar=stream.getvalue();raw=lzma.compress(tar,format=lzma.FORMAT_XZ,preset=6)
    archive=out/'complete.tar.xz';archive.write_bytes(raw);archive.chmod(0o600)
    manifest={'schema':'heptatorch.r4-view-reshape26-independent-final-packet.v1','status':'ORIGINAL_REFERENCE_AND_PURE_ADMISSION',
        'files':files,'file_count':len(files),'expanded_bytes':sum(x['bytes'] for x in files.values()),
        'archive_bytes':len(raw),'archive_sha256':sha(raw),'tar_bytes':len(tar),'tar_sha256':sha(tar),
        'original_actual_sha256':'fecf1956790f78a9b1238f535c1c7cce9f1237b211c389ac0736d88687bbb9c9',
        'independent_admission_sha256':'deb686ea4af865bbf03b3978cfbf6154f0780488d3e460555f6fba97484eb014',
        'original_reader_failures_preserved':2,'new_Torch_executions':0,'new_native_executions':0}
    mp=out/'manifest.json';mp.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n');mp.chmod(0o600)
    dec=lzma.LZMADecompressor(format=lzma.FORMAT_XZ);decoded=dec.decompress(archive.read_bytes());assert dec.eof and not dec.unused_data and decoded==tar
    found=set()
    with tarfile.open(fileobj=io.BytesIO(decoded),mode='r:') as tf:
        for m in tf:
            assert m.isfile() and m.name not in found;found.add(m.name);b=tf.extractfile(m).read();e=files[m.name]
            assert len(b)==m.size==e['bytes'] and m.mode==e['mode'] and sha(b)==e['sha256']
    assert found==set(files)
    v={'status':'PASS_ALL_ORIGINAL_BYTES_MODES_SINGLE_XZ','file_count':len(files),'expanded_bytes':manifest['expanded_bytes'],
        'archive_sha256':sha(raw),'manifest_sha256':sha(mp.read_bytes()),'tar_sha256':sha(tar),
        'single_XZ_EOF':True,'all_bytes_modes_verified':True,'new_Torch_executions':0,'new_native_executions':0}
    vp=out/'verification.json';vp.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n');vp.chmod(0o600)
    outer={'schema':'heptatorch.r4-reference26-delivery.v1','files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'mode':stat.S_IMODE(p.stat().st_mode)} for p in (archive,mp,vp)},
           'original_outer_mode':0o600,'git_install_mode_may_be_mapped_explicitly_to':0o644,'original_archive_member_modes_unchanged':True}
    op=out/'outer.json';op.write_text(json.dumps(outer,indent=2,sort_keys=True)+'\n');op.chmod(0o600)
    print(json.dumps({'status':v['status'],'files':len(files),'expanded_bytes':manifest['expanded_bytes'],'archive_bytes':len(raw),
                      'archive_sha256':sha(raw),'manifest_sha256':sha(mp.read_bytes()),'verification_sha256':sha(vp.read_bytes()),'outer_sha256':sha(op.read_bytes())}))


if __name__=='__main__':main()
