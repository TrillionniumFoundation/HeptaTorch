# Fixed R4 view / reshape actual26 reference

This package preserves one actual Torch execution, its complete original bytes, and an independent pure admission. It does not qualify a native implementation.

## Recorded execution

The sole actual job is `1a1e6e2725d-392-3c75`, original idempotency key `heptatorch-d266-r4-view-reshape26-actual-20261117-v1`. It completed with exit 0 and complete durable stdout/stderr. The original report is 18,335,446 bytes, SHA256 `fecf1956790f78a9b1238f535c1c7cce9f1237b211c389ac0736d88687bbb9c9`. Its status remains OBSERVED: 26 cases, zero probe errors, 483 attempted operations, 475 successes, and eight actual exceptions. All errors, warnings, weak lifetimes, raw Tensor/Storage bytes, gradient versions and metadata remain in that original file.

The wrapper binds all 18 frozen source-package files, five complete pinned upstream source files, the original interpreter and installed wheel metadata, and the actual pip report. All 33 bound files match before and after. All 11 provenance checks are independently compared against complete fixed wheel/version/direct_url/install metadata, including the recorded lint-only release/build source equivalence. CPU AVX512, single-thread execution, deterministic algorithms and deterministic fill are explicitly recorded. The wrapper performs no Torch import; it invokes the original frozen probe once.

## Independent admission and honest history

The final pure reader is `admit_actual26_r03.py`, SHA256 `be8c14f2161dbae865a2e8fc0d79c5747a3065538f746ba850a1091d4d0429c3`. It actually completed 448,108 checks with zero failures. The complete admission report is `admission-r03-first/report.json`, SHA256 `deb686ea4af865bbf03b3978cfbf6154f0780488d3e460555f6fba97484eb014`.

It checks all 6,612 raw Tensor observations, 992 snapshots, exact physical-Storage-to-logical element mapping, 64-bit integer words without float conversion, Version value/identity relationships as actually exposed, all 483 declared operation events, complete Saved getter records and actual errors, and 1,044 references to the complete 5,056-byte MT state. It does not compute replacement gradient expectations or infer a native pass from the actual report.

Two original reader failures are retained. The first confused the base case-plan file with the runtime plan that adds the frozen seed phases; r02 separately checks both complete structures. The second rejected the internal float64 scalar Tensor saved by the two `input * 2.0` nonleaf recipes. R03 admits only this nonrequiring, nonview, scalar `_saved_other` field and retains all exact eight-byte checks. Public input/output cases remain F32, bool and int64. The original reader sources, failed reports and whole-file inverse proofs are included. There was no additional Torch execution.

## AD source conclusion

`source-ad-review/report.json` binds seven complete official GitHub source responses plus the five already frozen primary files at commit `31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457`. It records exact source ranges and full file/blob hashes. Normal `view` and `_reshape_alias` establish ViewInfo and share the base Version counter. `_unsafe_view` shares Storage with the temporary contiguous clone but receives a fresh Version counter initially zero, and is excluded from the autograd view wrapper. Its backward edge points to the immediate clone, whose edge points to the original input. The final `_unsafe_view` has no `_base`.

The counter-separation conclusion is source-derived: these actual26 recipes expose the final output V0, not the hidden temporary clone's counter. No observation of equal counter values is described as proof of shared counter identity. View, ReshapeAlias and UnsafeView backward use reshape-to-self-size, not general AsStrided normalization. Symbolic shapes, other backends, inference tensors, higher-order AD and complete schema qualification are outside this reference.

## Packet layout and reproducibility

`original-packet/complete.tar.xz` contains all 40 original reference/input/execution members, with exact modes. `ad-source-packet/complete.tar.xz` contains 20 complete official-source/custody members. The outer packet adds the independent reader/history, source review, durable tool responses and transfer chunks. Original binaries and JSON files are never reserialized or path-rewritten.

Run `python -I -S -B verify_packet.py --packet PACKET_DIR` for complete outer and nested archive verification. To restore all exact original modes and run the pure admission, use `python -I -S -B verify_packet.py --packet PACKET_DIR --restore NEW_ROOT --admission-output NEW_REPORT_DIR`. The entire resulting admission report must be byte-identical to the preserved final report. Neither command invokes Torch or native executables.

Original outer files are mode 0600. A later Git installation may use mode 0644 with an explicit delivery map; archive member modes remain unchanged and are restored exactly. Remote job and source filenames remain historical evidence rather than local path expectations.
