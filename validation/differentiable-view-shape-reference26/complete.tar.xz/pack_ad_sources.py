from pathlib import Path
import hashlib,json,lzma,tarfile,io,stat
B=Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
root=B/'r4-view-reshape-ad-official-source-review-01';out=B/'r4-view-reshape-ad-source-packet-01';out.mkdir(exist_ok=False)
c=json.loads((root/'custody.json').read_bytes());assert c['status']=='PASS_OFFICIAL_SOURCE_BYTES_AND_GIT_BLOBS' and len(c['files'])==7
paths={'custody.json':root/'custody.json'}
for rec in c['files']:
 p=root/'upstream'/rec['path'];b=p.read_bytes();assert len(b)==rec['bytes'] and hashlib.sha256(b).hexdigest()==rec['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==rec['git_blob']
 paths['upstream/'+rec['path']]=p
 p=root/rec['github_response'];b=p.read_bytes();assert len(b)==rec['github_response_bytes'] and hashlib.sha256(b).hexdigest()==rec['github_response_sha256'];paths[rec['github_response']]=p
source=B/'differentiable-view-r4-shape-reference26-01';m=json.loads((source/'source-manifest.json').read_bytes())
for rec in m['files']:
 if rec['path'].startswith('upstream/'):
  p=source/rec['path'];b=p.read_bytes();assert len(b)==rec['bytes'] and hashlib.sha256(b).hexdigest()==rec['sha256'];paths['previous-fixed/'+rec['path']]=p
buf=io.BytesIO();files={}
with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as t:
 for rel,p in sorted(paths.items()):
  b=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode);i=tarfile.TarInfo(rel);i.size=len(b);i.mode=mode;i.mtime=0;t.addfile(i,io.BytesIO(b));files[rel]={'bytes':len(b),'mode':mode,'sha256':hashlib.sha256(b).hexdigest(),'original_path':str(p)}
tar=buf.getvalue();raw=lzma.compress(tar);(out/'complete.tar.xz').write_bytes(raw)
d=lzma.LZMADecompressor();u=d.decompress(raw);assert d.eof and not d.unused_data and u==tar
mf={'schema':'heptatorch.r4-ad-source-original-packet.v1','files':files,'file_count':len(files),'expanded_bytes':sum(x['bytes'] for x in files.values()),'archive_bytes':len(raw),'archive_sha256':hashlib.sha256(raw).hexdigest(),'tar_bytes':len(tar),'tar_sha256':hashlib.sha256(tar).hexdigest(),'single_XZ_EOF':True,'native_executions':0,'Torch_executions':0}
(out/'manifest.json').write_text(json.dumps(mf,indent=2)+'\n')
for p in out.iterdir():p.chmod(0o600)
print(json.dumps({'path':str(out),'file_count':len(files),'files':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in out.iterdir()}}))
