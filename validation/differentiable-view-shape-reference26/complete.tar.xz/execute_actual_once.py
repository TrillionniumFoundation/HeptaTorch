#!/usr/bin/env python3
"""Custody wrapper for exactly the frozen actual26 intent. Does not import Torch."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import stat
import subprocess
import sys
import time
import traceback

BASE = Path('/home/qian-qi/heptatorch-continuation-20261116/runs/differentiable-view-r4-shape-reference26-01')
OUT = BASE.parent / 'r4-view-reshape26-actual-custody-01'
MANIFEST_SHA = 'c9b98b083b78335f12eb697c066d55cd1d5c2db5a86296f874f17afc0ee0d08f'
INTENT_SHA = 'dab765cb2a2ade66114fab3546abe4643723945c863b011d1266e62fb35c2a93'
PROBE_SHA = '4dd374419e4b21a9c814c855d846481730a12ea57a30dcf229a6b962f07021c5'
PIP_SHA = '35ad4841c2f2f94be7ded7f1bcc97f9592f806658ff660bfac5bdc3b0cf986ef'
KEY = 'heptatorch-d266-r4-view-reshape26-actual-20261117-v1'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_record(path):
    path = Path(path)
    resolved = path.resolve(strict=True)
    st = resolved.stat()
    assert stat.S_ISREG(st.st_mode), str(path)
    h = hashlib.sha256()
    with resolved.open('rb') as f:
        while True:
            b = f.read(1024 * 1024)
            if not b:
                break
            h.update(b)
    return {'path': str(path), 'resolved': str(resolved), 'bytes': st.st_size,
            'mode': stat.S_IMODE(st.st_mode), 'sha256': h.hexdigest()}


def dump(name, obj):
    path = OUT / name
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')
    path.chmod(0o600)


def main():
    OUT.mkdir(exist_ok=False)
    report = {'schema': 'heptatorch.view-reshape26-actual-custody.v1',
              'status': 'PREPARING', 'idempotency_key': KEY,
              'native_executed': False, 'Torch_probe_started': False,
              'Torch_probe_completed': False, 'wrapper_imports_Torch': False,
              'started_at_unix_ns': time.time_ns()}
    inputs = {}
    code = 1
    try:
        manifest_path = BASE / 'source-manifest.json'
        intent_path = BASE / 'actual-execution-intent.json'
        assert sha(manifest_path.read_bytes()) == MANIFEST_SHA
        assert sha(intent_path.read_bytes()) == INTENT_SHA
        manifest = json.loads(manifest_path.read_bytes())
        intent = json.loads(intent_path.read_bytes())
        assert manifest['status'] == 'PREPARED_NOT_RUN'
        assert isinstance(manifest['files'], list) and len(manifest['files']) == 18
        assert len({r['path'] for r in manifest['files']}) == 18
        primary = [r for r in manifest['files'] if r['path'].startswith('upstream/')]
        assert len(primary) == 5
        assert intent['idempotency_key'] == KEY
        assert intent['source_sha256'] == PROBE_SHA
        assert intent['unique_executor'] == '/root/autograd_extension'
        assert intent['native_executed'] is False and intent['torch_executed'] is False
        assert intent['actual_started_here'] is False
        assert intent['host'] == 'rog'
        assert Path.cwd().resolve() == Path(intent['cwd']).resolve()
        assert Path(sys.executable).resolve() == Path(intent['executable']).resolve()
        assert list(sys.version_info[:2]) == [3, 12]
        assert sys.implementation.name == 'cpython' and sys.platform == 'linux'
        assert platform.machine() == 'x86_64'
        assert intent['args'][0] == '-B'
        assert Path(intent['args'][1]) == BASE / 'pytorch_view_reshape_probe.py'
        assert '--prepare-only' not in intent['args']
        assert len(intent['args']) == 10
        named = dict(zip(intent['args'][2::2], intent['args'][3::2]))
        assert set(named) == {'--reference', '--lock', '--repo', '--output'}
        assert Path(named['--reference']) == BASE / 'inputs/pytorch_oracle.py'
        assert Path(named['--lock']) == BASE / 'inputs/pytorch-oracle-lock.json'
        assert named['--repo'] == intent['cwd']
        actual = Path(named['--output'])
        assert actual == BASE / 'actual.json' and not actual.exists()
        for expected in manifest['files']:
            rel = Path(expected['path'])
            assert not rel.is_absolute() and '..' not in rel.parts
            record = file_record(BASE / rel)
            assert (record['bytes'], record['mode'], record['sha256']) == (
                expected['bytes'], expected['mode'], expected['sha256'])
            inputs[record['path']] = record
        for path in (manifest_path, Path(__file__),
                     BASE / 'actual-request.json', Path(intent['executable']),
                     Path(intent['executable']).parent.parent / 'pyvenv.cfg',
                     Path(intent['cwd']) / 'compatibility/upstream-lock.json'):
            record = file_record(path)
            inputs[record['path']] = record
        lock = json.loads((BASE / 'inputs/pytorch-oracle-lock.json').read_bytes())
        expected = lock['oracle']
        actual_pip = Path(intent['cwd']) / expected['install_report']
        record = file_record(actual_pip)
        assert record['sha256'] == PIP_SHA
        inputs[record['path']] = record
        distribution = importlib.metadata.distribution('torch')
        assert distribution.version == expected['version']
        direct = json.loads(distribution.read_text('direct_url.json'))
        assert direct['url'] == expected['wheel']['url']
        assert direct['archive_info']['hashes']['sha256'] == expected['wheel']['sha256']
        pip = json.loads(actual_pip.read_bytes())
        torch_records = [r for r in pip['install'] if r.get('metadata', {}).get('name', '').lower() == 'torch']
        assert len(torch_records) == 1
        installed = torch_records[0]
        assert installed['requested'] is True
        assert installed['metadata']['version'] == expected['version']
        assert installed['download_info']['url'] == expected['wheel']['url']
        assert installed['download_info']['archive_info']['hashes']['sha256'] == expected['wheel']['sha256']
        required_metadata = {'METADATA', 'WHEEL', 'RECORD', 'INSTALLER', 'direct_url.json'}
        found_metadata = set()
        for entry in distribution.files:
            rel = str(entry)
            if rel.endswith('.dist-info/' + entry.name) and entry.name in required_metadata:
                found_metadata.add(entry.name)
                record = file_record(distribution.locate_file(entry))
                inputs[record['path']] = record
        assert found_metadata == required_metadata
        for rel in ('torch/__init__.py', 'torch/version.py', 'torch/_C.cpython-312-x86_64-linux-gnu.so'):
            record = file_record(distribution.locate_file(rel))
            inputs[record['path']] = record
        report.update(status='RUNNING', source_manifest_sha256=MANIFEST_SHA,
                      intent_sha256=INTENT_SHA, probe_sha256=PROBE_SHA,
                      original_intent=intent, declared_inputs_count=18,
                      primary_source_count=5, inputs_before=inputs,
                      input_file_count=len(inputs),
                      actual_pip_report=inputs[str(actual_pip)],
                      environment_before={'python': sys.version, 'executable': sys.executable,
                                          'platform': sys.platform, 'machine': platform.machine(),
                                          'torch_distribution_version': distribution.version,
                                          'direct_url': direct, 'installed_torch_record': installed})
        dump('inputs-before.json', inputs)
        dump('execution.json', report)
        argv = [intent['executable'], *intent['args']]
        dump('actual-command.json', {'executable': intent['executable'], 'argv': argv,
                                     'cwd': intent['cwd'], 'environment_inherited': True})
        with (OUT / 'probe.stdout').open('xb') as stdout, (OUT / 'probe.stderr').open('xb') as stderr:
            stdout_path, stderr_path = Path(stdout.name), Path(stderr.name)
            stdout_path.chmod(0o600)
            stderr_path.chmod(0o600)
            report['Torch_probe_started'] = True
            report['probe_started_at_unix_ns'] = time.time_ns()
            dump('execution.json', report)
            process = subprocess.Popen(argv, cwd=intent['cwd'], stdout=stdout, stderr=stderr)
            report['probe_pid'] = process.pid
            dump('execution.json', report)
            returncode = process.wait()
        report.update(Torch_probe_completed=True, probe_returncode=returncode,
                      probe_finished_at_unix_ns=time.time_ns(), stdout_closed=True, stderr_closed=True,
                      stdout=file_record(stdout_path), stderr=file_record(stderr_path))
        if actual.exists():
            report['original_actual'] = file_record(actual)
            observed = json.loads(actual.read_bytes())
            report['observation_status'] = observed['status']
            report['observed_cases'] = observed.get('cases')
            report['operation_totals'] = observed.get('operation_totals')
            report['probe_errors'] = observed.get('probe_errors')
            provenance = observed['oracle_provenance']
            assert provenance['status'] == 'PASS' and len(provenance['checks']) == 11
            assert all(v is True for v in provenance['checks'].values())
            assert provenance['expected'] == expected
            assert provenance['observed']['direct_url'] == direct
            assert provenance['observed']['distribution_version'] == distribution.version
            assert provenance['observed']['install_report']['path'] == expected['install_report']
            assert provenance['observed']['install_report']['download_info'] == installed['download_info']
            assert provenance['observed']['install_report']['requested'] is True
            assert observed['probe_sha256'] == PROBE_SHA
            assert observed['source_files_unchanged'] is True
            assert observed['native_executed'] is False and observed['native_qualified'] is False
            assert observed['closed_schema_count'] == 0 and observed['full_pytorch_rewrite_complete'] is False
            assert observed['environment_restored'] is True and observed['original_outer_rng_restored'] is True
            assert observed['cpu_capability'] == 'AVX512' and observed['num_threads'] == 1
            assert observed['cases'] == len(observed['rows']) == 26
            report['all_11_provenance_true'] = True
            report['full_observed_provenance_matches_prebound_files'] = True
            report['actual_semantics_not_reclassified'] = True
        assert returncode == 0, returncode
        assert actual.exists()
        assert observed['status'] == 'OBSERVED' and observed['probe_error_count'] == 0
        report['status'] = 'PASS_ACTUAL_EXECUTED_AND_INPUTS_BOUND'
        code = 0
    except BaseException as exc:
        report.update(status='FAIL', primary_error=repr(exc), primary_traceback=traceback.format_exc())
    finally:
        try:
            after = {p: file_record(p) for p in inputs}
            report['inputs_after'] = after
            report['all_bound_inputs_unchanged'] = after == inputs
            dump('inputs-after.json', after)
            assert after == inputs
        except BaseException as exc:
            report.update(status='FAIL', custody_error=repr(exc), custody_traceback=traceback.format_exc())
            code = 1
        report['finished_at_unix_ns'] = time.time_ns()
        dump('execution.json', report)
    print(json.dumps({k: report.get(k) for k in (
        'status', 'Torch_probe_started', 'Torch_probe_completed', 'probe_returncode',
        'observed_cases', 'operation_totals', 'all_bound_inputs_unchanged',
        'input_file_count', 'primary_error')}))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
