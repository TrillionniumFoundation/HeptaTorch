#!/usr/bin/env python3
"""Create a lossless original reference packet; no Torch/native execution."""
from pathlib import Path
import hashlib
import io
import json
import lzma
import os
import stat
import tarfile

B = Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
SOURCE = B / 'differentiable-view-r4-shape-reference26-01'
EXECUTION = B / 'r4-view-reshape26-actual-custody-01'
OUT = B / 'r4-view-reshape26-original-custody-packet-01'


def digest(b):
    return hashlib.sha256(b).hexdigest()


def main():
    OUT.mkdir(exist_ok=False)
    report_data = (EXECUTION / 'execution.json').read_bytes()
    assert digest(report_data) == 'ba971fbf6762db9a40a662f8ec83b3b756cd92ef54de18c29532f356d6344113'
    report = json.loads(report_data)
    assert report['status'] == 'PASS_ACTUAL_EXECUTED_AND_INPUTS_BOUND'
    assert report['all_bound_inputs_unchanged'] is True
    assert report['inputs_before'] == report['inputs_after']
    assert report['input_file_count'] == len(report['inputs_before']) == 33
    mappings = {}
    originals = {}
    for index, (key, rec) in enumerate(sorted(report['inputs_before'].items())):
        path = Path(key)
        if path.is_relative_to(SOURCE):
            rel = 'source/' + str(path.relative_to(SOURCE))
        else:
            rel = 'environment/%02d-%s' % (index, path.name)
        assert rel not in originals
        originals[rel] = (path, rec)
        mappings[key] = rel
    actual = SOURCE / 'actual.json'
    originals['actual/actual.json'] = (actual, {
        'bytes': 18335446, 'mode': 0o600,
        'sha256': 'fecf1956790f78a9b1238f535c1c7cce9f1237b211c389ac0736d88687bbb9c9'})
    for p in sorted(EXECUTION.iterdir()):
        assert p.is_file() and not p.is_symlink()
        b = p.read_bytes()
        originals['execution/' + p.name] = (p, {
            'bytes': len(b), 'mode': stat.S_IMODE(p.stat().st_mode), 'sha256': digest(b)})
    assert len(originals) == 40
    files = {}
    tarbuf = io.BytesIO()
    with tarfile.open(fileobj=tarbuf, mode='w', format=tarfile.USTAR_FORMAT) as tf:
        for rel, (p, expected) in sorted(originals.items()):
            b = p.read_bytes()
            mode = stat.S_IMODE(p.resolve().stat().st_mode)
            assert (len(b), mode, digest(b)) == (expected['bytes'], expected['mode'], expected['sha256']), str(p)
            ti = tarfile.TarInfo(rel)
            ti.mode, ti.size, ti.mtime = mode, len(b), 0
            tf.addfile(ti, io.BytesIO(b))
            files[rel] = {'original_path': str(p), 'bytes': len(b), 'mode': mode, 'sha256': digest(b)}
    raw_tar = tarbuf.getvalue()
    compressed = lzma.compress(raw_tar, format=lzma.FORMAT_XZ, preset=6)
    (OUT / 'complete.tar.xz').write_bytes(compressed)
    manifest = {'schema': 'heptatorch.view-reshape26-original-reference-packet.v1',
                'status': 'ORIGINAL_BYTES_ONLY', 'files': files,
                'input_path_mapping': mappings, 'file_count': len(files),
                'expanded_bytes': sum(r['bytes'] for r in files.values()),
                'archive_bytes': len(compressed), 'archive_sha256': digest(compressed),
                'tar_bytes': len(raw_tar), 'tar_sha256': digest(raw_tar),
                'new_Torch_executions': 0, 'new_native_executions': 0}
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    decoder = lzma.LZMADecompressor()
    decompressed = decoder.decompress((OUT / 'complete.tar.xz').read_bytes())
    assert decoder.eof and not decoder.unused_data and decompressed == raw_tar
    seen = set()
    with tarfile.open(fileobj=io.BytesIO(decompressed), mode='r:') as tf:
        for member in tf.getmembers():
            assert member.isfile() and member.name not in seen
            assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            seen.add(member.name)
            b = tf.extractfile(member).read()
            expected = files[member.name]
            assert (len(b), member.mode, digest(b)) == (expected['bytes'], expected['mode'], expected['sha256'])
    assert seen == set(files)
    verification = {'status': 'PASS_ORIGINAL_PACKET_BYTES', 'file_count': len(files),
                    'expanded_bytes': manifest['expanded_bytes'], 'single_XZ_EOF': True,
                    'all_bytes_modes_verified': True, 'archive_sha256': digest(compressed),
                    'manifest_sha256': digest((OUT / 'manifest.json').read_bytes()),
                    'tar_sha256': digest(raw_tar), 'new_Torch_executions': 0, 'new_native_executions': 0}
    (OUT / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n')
    for p in OUT.iterdir():
        p.chmod(0o600)
    print(json.dumps({'status': verification['status'], 'output': str(OUT),
                      'file_count': len(files), 'expanded_bytes': manifest['expanded_bytes'],
                      'files': {p.name: {'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes()),
                                         'mode': stat.S_IMODE(p.stat().st_mode)} for p in OUT.iterdir()}}))


if __name__ == '__main__':
    main()
