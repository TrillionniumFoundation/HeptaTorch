# PR25 original artifact review

PASS. Read-only review of run **43833157423**, source head `abc2046cd4285ac9573895d8de8e3b846c64dde8`. These Adam results were executed in PR25; they are not relabeled as a PR24 run.

| Component | Native reports | Actual-reference scope | Live 32 cases | Frozen 35 cases |
| --- | ---: | --- | --- | --- |
| Adam | 19 checked; 8 native units reproduced | 22 qualified within exposed scope, 1 partial, 1 open of original24 | PASS; 2,132 frames; 17,455 exact words | PASS; 6,344 frames; 2,590,274 values |
| CPU distributions | 11 checked; each 7-unit profile reproduced | Explicit165 +18open; atomic161 +4 transaction differences +18open of original183 | PASS; 2,132 frames; 17,455 exact words | PASS; 6,344 frames; 2,590,274 values |

All four live reports retain 11 successful provenance checks. Both 32-case rows equal the inherited nullable and SGD profile rows byte-for-field, including request/response/reference digests. Compared with the older common05 profile, four partial-backward response digests already differ; the exact differences are preserved in this receipt, while all request, reference and metric fields are unchanged. Both 35-case plans, inverse-AST receipts, and frozen source hashes match the original ABI3 oracle. Each retains 0 direct parameter Version mismatches and 283 legacy explicit-state Version observations.

The ZIP has48 unique members: the manifest and47 original reports. Every extracted report was compared byte for byte with its ZIP member and checked against the manifest length/SHA256. All21 required envelope names match the committed workflow. Inputs were rehashed after review and are unchanged.

The manifest records a successful job; this review did not fetch the separate GitHub step listing and therefore does not independently assert the parent-reported65/65 step count. No tests were rerun and no original JSON was rewritten.

The original270,21,28,35,32 and477 regression counts remain separate. Repeated profiles and controls do not increase the2,590-schema denominator. Full PyTorch compatibility remains open.
