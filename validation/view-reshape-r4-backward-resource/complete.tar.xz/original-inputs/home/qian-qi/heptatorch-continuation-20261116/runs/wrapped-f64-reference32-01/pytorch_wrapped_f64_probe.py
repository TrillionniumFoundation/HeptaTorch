#!/usr/bin/env python3
"""Observe Python binary64 scalar multiplication of F32 Tensors on fixed CPU Torch.

Thirty-two literal binary64 inputs exercise rounding boundaries without an
expected numeric table. The actual Python float roundtrip, Saved.other bytes,
F32 result, explicit-seed backward, Versions and errors are observations only.
"""
import argparse
import gc
import hashlib
import json
from pathlib import Path
import runpy
import struct
import sys
import traceback
import warnings

SUPPORT_SHA = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK_SHA = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
SOURCE_REF = '31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457'
ORIGIN_PROBE_SHA = '4dd374419e4b21a9c814c855d846481730a12ea57a30dcf229a6b962f07021c5'
CHECKS = {
    'python_matches', 'platform_matches', 'version_backend_matches',
    'git_matches_oracle_build_pin', 'distribution_version_matches',
    'direct_url_matches', 'direct_url_archive_sha256_matches',
    'pip_report_url_matches', 'pip_report_archive_sha256_matches',
    'pip_report_version_matches', 'pip_report_requested',
}

# These are only input bit patterns. No F32 output or gradient expectations are
# computed here, by the software conversion helper, or by a native executable.
SCALARS = (
    ('positive_zero', '0000000000000000'),
    ('negative_zero', '8000000000000000'),
    ('positive_one', '3ff0000000000000'),
    ('negative_one', 'bff0000000000000'),
    ('even_midpoint_predecessor', '3ff000000fffffff'),
    ('even_midpoint', '3ff0000010000000'),
    ('even_midpoint_successor', '3ff0000010000001'),
    ('odd_midpoint_predecessor', '3ff000002fffffff'),
    ('odd_midpoint', '3ff0000030000000'),
    ('odd_midpoint_successor', '3ff0000030000001'),
    ('negative_even_midpoint', 'bff0000010000000'),
    ('negative_odd_midpoint', 'bff0000030000000'),
    ('positive_f32_min_subnormal', '36a0000000000000'),
    ('negative_f32_min_subnormal', 'b6a0000000000000'),
    ('half_min_subnormal_predecessor', '368fffffffffffff'),
    ('half_min_subnormal', '3690000000000000'),
    ('half_min_subnormal_successor', '3690000000000001'),
    ('negative_half_min_subnormal', 'b690000000000000'),
    ('f32_max_subnormal', '380fffffc0000000'),
    ('subnormal_normal_midpoint', '380fffffe0000000'),
    ('f32_min_normal', '3810000000000000'),
    ('f32_max_finite', '47efffffe0000000'),
    ('overflow_midpoint_predecessor', '47efffffefffffff'),
    ('overflow_midpoint', '47effffff0000000'),
    ('overflow_midpoint_successor', '47effffff0000001'),
    ('negative_overflow_midpoint', 'c7effffff0000000'),
    ('positive_infinity', '7ff0000000000000'),
    ('negative_infinity', 'fff0000000000000'),
    ('positive_quiet_nan_payload', '7ff8123456789abc'),
    ('negative_quiet_nan_payload', 'fff8abcdef012345'),
    ('positive_signaling_nan_payload', '7ff0123456789abc'),
    ('negative_signaling_nan_payload', 'fff023456789abcd'),
)
INPUT_WORDS = (0x3f800000, 0xbf800000, 0x00000000, 0x80000000)
SEED_WORDS = (0x3f800000, 0xc0000000, 0x3f000000, 0x80000000)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def plan():
    assert len(SCALARS) == 32 and len({x[0] for x in SCALARS}) == 32
    result = []
    for index, (name, word) in enumerate(SCALARS):
        assert len(word) == 16 and f'{int(word, 16):016x}' == word
        result.append({'index': index, 'name': name, 'scalar_binary64_hex': word,
                       'scalar_little_endian_hex': int(word, 16).to_bytes(8, 'little').hex(),
                       'operation': 'F32_tensor_times_Python_float', 'shape': [4],
                       'input_binary32_hex': [f'{x:08x}' for x in INPUT_WORDS],
                       'seed_binary32_hex': [f'{x:08x}' for x in SEED_WORDS],
                       'requires_grad': True, 'retain_output_gradient': True,
                       'retain_graph': False})
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ('reference', 'lock', 'repo', 'output'):
        ap.add_argument('--' + name, type=Path, required=True)
    ap.add_argument('--prepare-only', action='store_true')
    args = ap.parse_args()
    assert Path.cwd().resolve() == args.repo.resolve()
    assert not args.output.exists()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    inputs = {p.resolve(): p.read_bytes() for p in (Path(__file__), args.reference, args.lock)}
    assert sha(inputs[args.reference.resolve()]) == SUPPORT_SHA
    assert sha(inputs[args.lock.resolve()]) == LOCK_SHA
    common = {
        'schema': 'heptatorch.wrapped-f64-multiply-reference32.v1',
        'probe_sha256': sha(inputs[Path(__file__).resolve()]),
        'primary_source_ref': SOURCE_REF, 'case_plan': plan(),
        'observer_origin_probe_sha256': ORIGIN_PROBE_SHA,
        'native_executed': False, 'native_qualified': False,
        'full_pytorch_rewrite_complete': False, 'pytorch_api_denominator': 2590,
        'closed_schema_count': 0,
        'policy': 'OBSERVATION ONLY. No expected numeric results are computed. No native executable or conversion helper is loaded.',
        'scope': 'CPU F32 Tensor times a Python float built from a literal binary64 word. Exact Saved.other storage is observed, without claiming general public F64 Tensor API support.',
        'scalar_policy': 'struct.unpack constructs the Python float once; struct.pack records its actual word before and after multiplication/backward. No float32 scalar substitute is created.',
        'getter_order': 'For live names in insertion order: raw Tensor/Storage/layout/Version, grad_fn and its Saved attributes, is_leaf, retains_grad, grad. All returned snapshots are primitives and copied bytes.',
        'ownership_scope': 'live holds explicit named Tensor roots. Local Function/Tensor wrappers are released before each snapshot returns. No weak-expiration or arbitrary Python refcount claim is made.',
        'saved_release_scope': 'Saved attribute getters are observed again after default backward; their actual errors are recorded separately from operation errors.',
        'inputs_sha256': {str(p): sha(b) for p, b in inputs.items()},
    }
    if args.prepare_only:
        report = {**common, 'status': 'PREPARED_NOT_RUN', 'torch_executed': False,
                  'cases': 0, 'rows': [], 'source_files_unchanged': all(p.read_bytes() == b for p, b in inputs.items())}
        args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
        print(json.dumps({'status': report['status'], 'planned_cases': len(plan()), 'probe_sha256': common['probe_sha256']}))
        return 0

    old_argv = sys.argv
    try:
        sys.argv = [str(args.reference), str(args.repo / 'reference-only-no-native-execution'),
                    str(args.output.with_suffix('.provenance.json')), str(args.lock)]
        context = runpy.run_path(str(args.reference), run_name='wrapped_f64_provenance_only')
    finally:
        sys.argv = old_argv
    torch, provenance = context['torch'], context['PROVENANCE']
    assert provenance['status'] == 'PASS' and set(provenance['checks']) == CHECKS
    assert all(value is True for value in provenance['checks'].values())
    assert torch.are_deterministic_algorithms_enabled()
    assert torch.utils.deterministic.fill_uninitialized_memory is True
    assert torch.get_num_threads() == 1
    assert torch.backends.cpu.get_cpu_capability() == 'AVX512'
    states, rows, errors = {}, [], []

    def environment():
        return {'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
                'deterministic_fill': torch.utils.deterministic.fill_uninitialized_memory,
                'grad_enabled': torch.is_grad_enabled(), 'num_threads': torch.get_num_threads(),
                'cpu_capability': torch.backends.cpu.get_cpu_capability(),
                'default_dtype': str(torch.get_default_dtype())}

    environment_before = environment()
    outer_rng = bytes(torch.get_rng_state().tolist())

    def rng():
        raw = bytes(torch.get_rng_state().tolist())
        assert len(raw) == 5056
        key = sha(raw)
        states.setdefault(key, {'bytes': len(raw), 'hex': raw.hex()})
        return key

    def capture(operation):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            try:
                value = operation()
                event = {'accepted': True, 'outcome': 'SUCCEEDED', 'error': None}
            except Exception as error:
                value = None
                event = {'accepted': False, 'outcome': 'RAISED',
                         'error': {'type': type(error).__name__, 'message': str(error)}}
        event['warnings'] = [{'type': type(w.message).__name__, 'message': str(w.message)} for w in caught]
        return value, event

    def raw_tensor(x):
        if x is None:
            return None
        storage = x.untyped_storage()
        raw = bytes(storage)
        width = x.element_size()
        shape, strides, offset = list(x.shape), list(x.stride()), x.storage_offset()
        logical = bytearray()
        for linear in range(x.numel()):
            quotient, at = linear, offset
            for size, stride in zip(reversed(shape), reversed(strides)):
                at += (quotient % size) * stride
                quotient //= size
            word = raw[at * width:at * width + width]
            assert len(word) == width
            logical.extend(word)
        base = x._base
        result = {'tensor_identity': str(x._cdata), 'storage_identity': str(storage._cdata),
                  'dtype': str(x.dtype), 'element_size': width, 'shape': shape, 'strides': strides,
                  'numel': x.numel(), 'storage_bytes': len(raw),
                  'storage_offset_elements': offset, 'storage_offset_bytes': offset * width,
                  'storage_raw_hex': raw.hex(), 'logical_bytes_hex': bytes(logical).hex(),
                  'binary_words': [int.from_bytes(logical[i:i + width], 'little') for i in range(0, len(logical), width)],
                  'version': x._version, 'requires_grad': x.requires_grad, 'is_view': x._is_view(),
                  'base_tensor_identity': None if base is None else str(base._cdata)}
        del base, storage
        return result

    def primitive(value):
        if isinstance(value, torch.Tensor):
            return {'tensor': raw_tensor(value)}
        if value is None or isinstance(value, (bool, int, str)):
            return value
        if isinstance(value, float):
            return {'double_bits': struct.unpack('<Q', struct.pack('<d', value))[0]}
        if isinstance(value, (tuple, list)):
            return [primitive(item) for item in value]
        return {'type': type(value).__name__, 'diagnostic_repr': repr(value)}

    def node_info(fn, depth=4):
        if fn is None:
            return None
        result = {'kind': type(fn).__name__}
        if type(fn).__name__ == 'AccumulateGrad':
            variable = fn.variable
            result['variable'] = raw_tensor(variable)
            del variable
        if depth:
            result['next_edges'] = [{'output_nr': int(nr), 'node': node_info(child, depth - 1)}
                                    for child, nr in fn.next_functions]
        return result

    def saved_attributes(fn):
        if fn is None:
            return {}
        attributes = {}
        for name in sorted(n for n in dir(fn) if n.startswith('_saved_')):
            value, event = capture(lambda name=name: getattr(fn, name))
            if event['accepted']:
                event['value'] = primitive(value)
            del value
            attributes[name] = event
        return attributes

    def tensor_state(x):
        result = {'raw': raw_tensor(x)}
        fn, event = capture(lambda: x.grad_fn)
        if event['accepted']:
            event['node'] = node_info(fn)
            event['saved'] = saved_attributes(fn)
        result['grad_fn'] = event
        del fn
        leaf, event = capture(lambda: x.is_leaf)
        if event['accepted']:
            event['value'] = bool(leaf)
        result['is_leaf'] = event
        del leaf
        retained, event = capture(lambda: x.retains_grad)
        if event['accepted']:
            event['value'] = bool(retained)
        result['retains_grad'] = event
        del retained
        gradient, event = capture(lambda: x.grad)
        if event['accepted']:
            event['tensor'] = raw_tensor(gradient)
        result['gradient'] = event
        del gradient
        return result

    def snapshot(live):
        return {'tensor_getter_order': list(live),
                'tensors': {name: tensor_state(value) for name, value in live.items()},
                'state': rng()}

    def make_f32(words):
        source = bytearray(b''.join(int(word).to_bytes(4, 'little') for word in words))
        result = torch.frombuffer(source, dtype=torch.float32).clone()
        assert raw_tensor(result)['binary_words'] == list(words)
        assert not result._is_view() and result._base is None
        return result

    def scalar_word(value):
        data = struct.pack('<d', value)
        return {'little_endian_hex': data.hex(),
                'binary64_hex': f'{int.from_bytes(data, "little"):016x}',
                'python_type': type(value).__name__}

    def observe(spec):
        torch.manual_seed(1729)
        source_bytes = bytes.fromhex(spec['scalar_little_endian_hex'])
        scalar = struct.unpack('<d', source_bytes)[0]
        live, events = {}, []
        row = {**spec, 'state_before_setup': rng(), 'events': events,
               'python_scalar_after_unpack': scalar_word(scalar)}

        def event(label, operation, publish=None):
            before = snapshot(live)
            value, result = capture(operation)
            result.update(label=label, before=before,
                          python_scalar=scalar_word(scalar))
            if result['accepted']:
                result['returned'] = primitive(value)
                if publish is not None:
                    assert isinstance(value, torch.Tensor), (label, type(value).__name__)
                    live[publish] = value
            del value
            result['after'] = snapshot(live)
            events.append(result)
            return result['accepted']

        def finish():
            row.update(status='OBSERVED', final=snapshot(live),
                       python_scalar_after_operations=scalar_word(scalar), state_after=rng())
            live.clear()
            gc.collect()
            row['state_after_explicit_roots_cleared'] = rng()
            return row

        if not event('construct_input', lambda: make_f32(INPUT_WORDS), publish='input'):
            row['remaining_not_attempted'] = 'input constructor raised'
            return finish()
        if not event('input_requires_grad', lambda: live['input'].requires_grad_(True)):
            row['remaining_not_attempted'] = 'requires request raised'
            return finish()
        if not event('multiply_python_float', lambda: live['input'] * scalar, publish='output'):
            row['remaining_not_attempted'] = 'Python scalar multiplication raised'
            return finish()
        row['python_scalar_after_multiply'] = scalar_word(scalar)
        if not event('retain_output_gradient', lambda: live['output'].retain_grad()):
            row['remaining_not_attempted'] = 'retain_grad request raised'
            return finish()
        if not event('construct_seed', lambda: make_f32(SEED_WORDS), publish='seed'):
            row['remaining_not_attempted'] = 'seed constructor raised'
            return finish()
        event('backward_default_release', lambda: live['output'].backward(live['seed']))
        return finish()

    try:
        for spec in plan():
            try:
                rows.append(observe(spec))
            except Exception as error:
                errors.append({'index': spec['index'], 'name': spec['name'],
                               'type': type(error).__name__, 'message': str(error),
                               'traceback': traceback.format_exc()})
                rows.append({**spec, 'status': 'PROBE_ERROR', 'error': errors[-1]})
    finally:
        torch.set_rng_state(torch.tensor(list(outer_rng), dtype=torch.uint8))
    environment_after = environment()
    source_unchanged = all(p.read_bytes() == b for p, b in inputs.items())
    totals = {'attempted': 0, 'succeeded': 0, 'raised': 0}
    for row in rows:
        for event in row.get('events', []):
            totals['attempted'] += 1
            totals['succeeded' if event['accepted'] else 'raised'] += 1
    report = {**common, 'status': 'OBSERVED' if not errors else 'PROBE_ERROR',
              'torch_executed': True, 'cases': len(rows), 'rows': rows,
              'probe_errors': errors, 'operation_totals': totals,
              'oracle_provenance': provenance,
              'environment_before': environment_before, 'environment_after': environment_after,
              'environment_unchanged': environment_before == environment_after,
              'outer_rng_restored': bytes(torch.get_rng_state().tolist()) == outer_rng,
              'full_rng_states': states, 'source_files_unchanged': source_unchanged,
              'inputs_after_sha256': {str(p): sha(p.read_bytes()) for p in inputs}}
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'status': report['status'], 'cases': len(rows), 'probe_errors': len(errors),
                      'operation_totals': totals, 'source_files_unchanged': source_unchanged}))
    return 0 if not errors and source_unchanged and report['environment_unchanged'] and report['outer_rng_restored'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
