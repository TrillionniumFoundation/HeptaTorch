#!/usr/bin/env python3
"""Pure recorded-byte admission and complete preservation of one native resource control."""
import argparse, datetime, gzip, hashlib, importlib.util, io, json, lzma, os, stat, struct, sys, tarfile, traceback
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
ACTUAL=R/'root-backward-private-cache-actual02-first-01'
PREPARE=R/'root-backward-private-cache-prepare-01'
PARENT=R/'hia-wrapped-scalar-resource-source-07b'
REPORT='f3e69cfd730d7431e4b010b2e5a814fd77444992d5a2a3f0b4c6646aa0c6223c'
IMAGE='0799496559ffdfb051e34bc7a543db238b81d09c970a5cb4a8235151e0335b74'
SOURCE='c436e21c45355891f8423f174a47e7c40fc8e1d6aef9a112043fac8787255d7a'
PEER='30296b98346704540a9175ef8f1547c0807af7b95a2444c16ba7f6f5c40d2e49'
ATTEMPTS=[]; BOUND={}; CHECKS=0
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.posix_spawn','os.posix_spawnp','os.exec','os.fork','os.forkpty','socket.connect','ctypes.dlopen'):
        ATTEMPTS.append(event);raise RuntimeError('Pure admission cannot start processes/network: '+event)
    if event=='open' and args and isinstance(args[0],(str,bytes,os.PathLike)) and os.fsdecode(args[0]).startswith('/proc/'):
        ATTEMPTS.append('open:/proc');raise RuntimeError('Pure admission cannot inspect a live process')
sys.addaudithook(audit)
def need(ok,label):
    global CHECKS
    CHECKS+=1
    if not ok:raise AssertionError(label)
def encode(obj):
    return (json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
def write(path,raw,mode=0o600):
    fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,mode)
    try:
        os.fchmod(fd,mode)
        with os.fdopen(fd,'wb',closefd=False) as f:f.write(raw);f.flush();os.fsync(f.fileno())
    finally:os.close(fd)
def bind(path,pin=None):
    path=Path(path);st=path.lstat()
    need(path.is_absolute() and stat.S_ISREG(st.st_mode) and not path.is_symlink(),'regular input '+str(path))
    raw=path.read_bytes();end=path.stat()
    need((st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns,st.st_mode)==
         (end.st_dev,end.st_ino,end.st_size,end.st_mtime_ns,end.st_ctime_ns,end.st_mode),'stable input '+str(path))
    meta={'bytes':len(raw),'sha256':sha(raw),'mode':stat.S_IMODE(st.st_mode)}
    need(pin is None or meta['sha256']==pin,'input pin '+str(path))
    if str(path) in BOUND:need(BOUND[str(path)]==meta,'unchanged repeated input '+str(path))
    BOUND[str(path)]=meta
    return raw
def single_xz(raw):
    d=lzma.LZMADecompressor();plain=d.decompress(raw)
    need(d.eof and not d.unused_data,'complete single XZ stream')
    return plain
def frames(raw,magic):
    result=[];at=0
    while at<len(raw):
        need(at+16<=len(raw),'frame header')
        tag,size=struct.unpack_from('<8sQ',raw,at);at+=16
        need(tag==magic and 32<=size<=1<<20 and at+size<=len(raw),'bounded frame body')
        result.append(raw[at:at+size]);at+=size
    need(at==len(raw),'full frame EOF')
    return result
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def mcp(result):
    if 'value' in result:
        need(result['status']=='fulfilled','fulfilled original tool call');result=result['value']
    need(result.get('isError') is not True,'successful original tool receipt')
    return json.loads(result['content'][0]['text'])
def admit(tool_custody):
    native_raw=bind(ACTUAL/'report.json',REPORT);report=json.loads(native_raw)
    need(report['status']=='PASS' and report['case_count']==report['passed']==1,'actual one case PASS')
    need(report['native_executed'] is True and report['Torch_executed'] is False and report['compiler_executed'] is False,'actual execution scope')
    need(report['source_sha256']==SOURCE and report['native_sha256']==IMAGE and report['closed_schema_count']==0 and report['whole_pytorch_gate']=='HOLD','actual scope pins')
    need(report['all_inputs_unchanged'] is True and len(report['inputs'])==93,'complete original input denominator')
    for path,meta in report['inputs'].items():
        bind(Path(path),meta['sha256']);need(BOUND[path]==meta,'exact original input size and mode')
    manifest=json.loads(bind(PARENT/'source-manifest.json','fefb9247a2c01ad14c5b8a5016b3a9c6e3063ecc496637052e48665d9d851bd2'))
    need({p.relative_to(PARENT).as_posix() for p in PARENT.rglob('*') if p.is_file()}==
         set(manifest['files'])|{'source-manifest.json'},'complete frozen parent source tree')
    for name,meta in manifest['files'].items():
        p=PARENT/name;bind(p,meta['sha256']);need(BOUND[str(p)]==meta,'original parent source metadata')
    sys.path.insert(0,str(PARENT))
    observer=load('pure_backward_resource_observer',PARENT/'owner_view05.py')
    State=load('pure_backward_resource_state',PARENT/'owner_state.py').State
    wire=load('pure_backward_resource_wire',PARENT/'protocol.py')
    c=report['cases'][0];directory=ACTUAL/c['name']
    need(c['status']=='PASS' and c['EOF_exit_code']==0 and c['target_allocation_qualified'] is True and c['original_limit_restored'] is True,'actual control qualification')
    need(c['checks']==report['checks']==46 and c['frames_before_EOF']==report['frames_before_EOF']==22,'original test counters')
    need(c['committed_84Q_snapshots']==report['committed_84Q_snapshots']==len(c['snapshots'])==23,'all snapshots denominator')
    need(json.loads(bind(directory/'report.json'))==c,'original child report exact')
    transport=json.loads(bind(directory/'transport/transport.json'))
    requests=frames(bind(directory/'transport/requests.frames.bin'),b'HTOWNR01')
    responses=frames(bind(directory/'transport/responses.frames.bin'),b'HTOWNS01')
    need(len(requests)==len(responses)==transport['frames']==22,'all actual frames')
    need(transport['executable_sha256']==IMAGE and transport['exit_code']==0 and transport['responses_before_stdin_eof'] is True,'transport binding and EOF')
    need(len(transport['rows'])==22,'transport complete rows')
    expected_ops=[60,38,114,38,111,97,58,13,13,13,98,38,38,94,58,53,58,13,98,33,66,53]
    commands=[];decoded=[]
    for i,(request,response) in enumerate(zip(requests,responses)):
        magic,count,size,reserved=struct.unpack_from('<8s3Q',request)
        need(magic==b'HTORCH03' and count==1 and size==len(request) and reserved==0,'original one-command frame')
        command=struct.unpack_from('<8Q',request,32);commands.append(command)
        need(command[0]==expected_ops[i],'exact ordered recipe opcode')
        status,records=wire.parse(response);decoded.append((status,records))
        need(transport['rows'][i]=={'frame':i+1,'pid':transport['pid'],'response_bytes':len(response),'stdin_open':True},'complete exact transport row')
        if i==14:need(status==3 and records==[],'only native expected allocation refusal')
        else:need(status==0 and len(records)==1 and records[0]['opcode']==expected_ops[i],'exact successful response')
    need(requests[6]==requests[14]==requests[16],'byte-identical warmup refusal and retry request')
    command=c['exact_backward_command']
    need(commands[6]==tuple(command)+tuple([0]*(8-len(command))),'exact report backward request')
    need(command[0]==58 and command[3]==1,'actual retained backward recipe')
    for i in (6,16):
        rec=decoded[i][1][0]
        need(rec['value']==0 and len(rec['payload'])==32 and struct.unpack('<4Q',rec['payload'])[0]==0,'actual successful warmup/recovery diagnostics')
    need(list(struct.unpack('<4Q',decoded[16][1][0]['payload']))==c['recovery_diagnostics'],'recovery full diagnostics')
    need(decoded[13][1][0]['value']==0 and decoded[15][1][0]['value']==1 and decoded[21][1][0]['value']==1,'same-capacity and native audits')
    need(decoded[10][1][0]['payload']==decoded[18][1][0]['payload'],'actual canary read bytes unchanged')
    state_rows=[];snap_rows=[];owner_blobs={};rng0=None;rng_compared=0;partitions=0
    for i,row in enumerate(c['snapshots']):
        compressed=bind(directory/row['snapshot_file'])
        plain=gzip.decompress(compressed)
        need(sha(plain)==row['snapshot_sha256'],'canonical snapshot SHA')
        snapshot=json.loads(plain)
        need(observer.canonical(snapshot)==plain,'exact canonical snapshot bytes')
        meta=row['owner'];archive=bind(directory/meta['path'],meta['archive_sha256'])
        raw=single_xz(archive)
        need(len(raw)==meta['bytes'] and sha(raw)==meta['sha256'],'complete original owner bytes')
        owner_blobs[meta['sha256']]=len(raw)
        rebuilt=observer.decode_owner(raw,snapshot['pointer'])
        need(rebuilt==snapshot,'full physical owner reconstructs complete snapshot')
        need(observer.verify_snapshot(rebuilt)==row['result'],'original complete84Q invariants')
        state=State(raw);partitions+=state.partition();state_rows.append(state);snap_rows.append(snapshot)
        gen=decoded[0][1][0]['value']
        if gen in state.table(7):
            rng=state.rng(gen)
            if rng0 is None:rng0=rng
            else:need(rng==rng0,'full5056 recorded RNG unchanged');rng_compared+=len(rng)
    need(rng_compared==c['full_rng_bytes']==report['full_rng_bytes']==96064,'all recorded RNG comparisons')
    need(state_rows[-1].final_pages_only()==c['final_pages_only'],'final roots dropped; only actual descriptor pages')
    need(snap_rows[-1]==snap_rows[-2],'final extra snapshot matches last audited owner')
    need(len(c['events'])==1 and c['events'][0]['expected']==c['events'][0]['status']==3,'single original resource refusal')
    event=c['events'][0]
    need(event['before']==event['after']==c['snapshots'][13]['owner']==c['snapshots'][14]['owner'],'exact rollback recorded owner binding')
    need(snap_rows[13]==snap_rows[14] and state_rows[13].raw==state_rows[14].raw,'owner pointer length full bytes unchanged')
    need(len(state_rows[13].raw)==c['rollback_bytes']==report['full_owner_rollback_bytes']==4369040,'rollback byte denominator')
    prefix=event['name']
    need(bind(directory/(prefix+'.maps-before'))==bind(directory/(prefix+'.maps-after')),'complete captured process mappings unchanged')
    proof=c['allocation_setup'];state=state_rows[13]
    need(json.loads(bind(directory/'allocation-setup.json'))==proof,'actual allocation proof original bytes')
    need(proof['native_pid']==transport['pid'],'same actual native child')
    for field,node in (('raw_leaf_words',proof['leaf_node']),('raw_output_words',proof['output_node']),('raw_seed_words',proof['seed_node']),('raw_saved_scalar_words',proof['scalar_node'])):
        need(list(state.node(node))==proof[field],'actual physical geometry '+field)
    need(proof['highest_descriptor']==state.next-1 and proof['pool']==state.pool,'actual setup size')
    N=65536;workspace=24+24*state.next+72+5*N
    align=lambda n:(n+15)&~15
    need(proof['workspace_requested']==workspace and proof['workspace_rounded']==align(workspace) and proof['normal_buffer_rounded']==proof['preserve_target_rounded']==4*N,'exact source-bound extent sizes')
    need([list(x) for x in state.free()]==proof['original_free_extents'],'actual ordered extent source')
    budget=[list(x) for x in state.free()]
    for amount,record in zip((align(workspace),4*N),proof['pre_target_extent_allocations']):
        matches=[i for i,(off,size) in enumerate(budget) if size>=amount];need(bool(matches),'pre-target extent must fit')
        index=matches[0];offset,size=budget[index]
        need(record['requested_rounded_bytes']==amount and record['offset']==offset,'source-bound first-fit allocation')
        if size==amount:budget.pop(index)
        else:budget[index]=[offset+amount,size-amount]
    need(budget==proof['remaining_extents_before_target'] and sum(size for off,size in budget)<4*N,'private-preserve extent must request growth')
    need(proof['total_free_bytes']==sum(size for off,size in state.free()),'total actual free extent budget')
    available={}
    for kind in range(1,9):
        rows=[struct.unpack_from('<8Q',state.raw,139264+128+((kind-1)*state.slots+i)*64) for i in range(state.slots)]
        available[str(kind)]=sum(r[1]==0 and r[0]<4294967295 for r in rows)
    need(available==proof['table_reusable_slots'] and min(available[str(k)] for k in (1,2,3,6))>=8,'actual source-bound reusable table slots')
    status=bind(directory/'before-limit.status').decode()
    vm=int(next(x.split()[1] for x in status.splitlines() if x.startswith('VmSize:')))*1024
    page=lambda n:(n+4095)&~4095
    headroom=page(len(state.raw)+16)+page(5056+16)+65536
    growth=len(state.raw)+state.pool
    need(vm==proof['current_vm'] and headroom==proof['permitted_transaction_headroom'] and vm+headroom==proof['temporary_soft_limit'],'captured VmSize and transaction budget')
    need(growth==proof['first_growth_owner_bytes'] and headroom<page(growth+16),'larger-owner capacity refused by actual limit')
    limits=bind(directory/'limited.limits').decode()
    limitrow=next(x.split() for x in limits.splitlines() if x.startswith('Max address space'))
    need(int(limitrow[3])==proof['temporary_soft_limit'] and int(limitrow[4])==proof['original_limit'][1],'captured actual constrained child soft/hard limits')
    need(state_rows[16].pool==2*state.pool and len(state_rows[16].raw)==growth,'identical retry grew actual owner pool')
    x=commands[1];y=commands[2];seed=commands[4]
    need(x[:4]==(38,1,1,N) and x[7]==0x3f800000 and y[0]==114 and y[2]==0x3ff0000000000000,'exact original public F32/Scalar64 construction')
    need(seed[0]==111 and commands[6][2]==decoded[4][1][0]['value'],'actual noncontiguous seed used')
    source_tid=decoded[1][1][0]['value'];seed_tid=decoded[4][1][0]['value']
    _,leaf_before=state.tensor_node(source_tid);_,leaf_after=state_rows[16].tensor_node(source_tid)
    need(leaf_before[48:50]==leaf_after[48:50]==(proof['gradient_node'],proof['gradient_incarnation']),'same existing gradient root incarnation')
    for tid in (source_tid,seed_tid):
        baseline=None
        for st in state_rows[6:19]:
            node,words=st.tensor_node(tid);storage=st.row(words[27],2)
            raw=st.storage_bytes(words[27])
            if baseline is None:baseline=raw
            else:need(raw==baseline,'full recorded source or seed physical Storage unchanged')
    need(c['negative_controls']==[],'no claimed copied controls')
    tools=json.loads(bind(tool_custody))
    status_receipt=mcp(tools['actual_status_original_MCP']);stream_receipt=mcp(tools['actual_streams_original_MCP'])
    need(status_receipt['job_id']=='1a1e7b48d55-392-3e63' and status_receipt['exit_code']==0 and status_receipt['state']=='succeeded' and status_receipt['output_complete'] is True,'actual durable job terminal')
    for name,size in (('stdout',103),('stderr',0)):
        stream=stream_receipt[name]
        need(stream['offset']==0 and stream['next_offset']==stream['size']==size and stream['eof'] is True,'complete original tool stream')
        need(bytes.fromhex(stream['bytes_hex'])==stream['text'].encode(),'original stream text matches bytes')
    printed=json.loads(stream_receipt['stdout']['text'])
    need(printed=={'status':'PASS','case_count':1,'passed':1,'checks':46,'frames_before_EOF':22,'error':None},'actual full printed status')
    return report,native_raw,{
        'status':'PASS_PURE_RECORDED_RESOURCE_EVIDENCE','frames':22,'committed_84Q_snapshots':23,
        'unique_owner_blobs':len(owner_blobs),'unique_owner_bytes':sum(owner_blobs.values()),
        'partition_spans_checked':partitions,'full_rng_bytes':rng_compared,
        'complete_adjacent_rollback_pairs':1,'full_owner_rollback_bytes':4369040,
        'actual_resource_checks_retained':46,'source_and_seed_storage_reads':26,
        'target_attribution':'Fixed HIA allocation order plus actual captured geometry and OS limit; not an instruction trace.',
        'native_executions_here':0,'Torch_executions_here':0,'compiler_executions_here':0,
        'numeric_oracles_computed_here':0,'general_transition_checker_invoked':False,
        'whole_pytorch_gate':'HOLD','closed_schema_count':0}
def archive_verify(path,members):
    raw=path.read_bytes();plain=single_xz(raw)
    with tarfile.open(fileobj=io.BytesIO(plain),mode='r:') as tf:
        actual=tf.getmembers();need(len(actual)==len(members) and len({m.name for m in actual})==len(actual),'exact archive denominator')
        need({m.name for m in actual}==set(members),'exact archive members')
        for m in actual:
            need(m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts,'regular safe archive path')
            body=tf.extractfile(m).read();meta=members[m.name]
            need(len(body)==m.size==meta['bytes'] and sha(body)==meta['sha256'] and m.mode==meta['mode'],'exact archived original byte/mode')
        end=max(m.offset_data+((m.size+511)//512)*512 for m in actual)
        need(len(plain)-end>=1024 and not any(plain[end:]),'TAR complete zero end padding')
    return {'archive_sha256':sha(raw),'archive_bytes':len(raw),'archive_members':len(members),
            'payload_bytes':sum(m['bytes'] for m in members.values()),'all_original_modes_preserved':True,
            'single_XZ_EOF':True,'TAR_end_padding_zero':True}
def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--tool-custody',type=Path,required=True);p.add_argument('--expected-source-sha256',required=True)
    a=p.parse_args();out=a.output;out.mkdir(parents=True,exist_ok=False)
    result={'schema':'heptatorch.root.backward-private-cache-pure-admission-and-seal.v1','status':'RUNNING',
            'native_executions_here':0,'Torch_executions_here':0,'compiler_executions_here':0}
    code=1
    try:
        bind(Path(__file__).resolve(),a.expected_source_sha256)
        report,native_raw,admission=admit(a.tool_custody)
        sources={}
        def add(label,path):
            need(label not in sources,'unique preserved member');sources[label]=Path(path)
        for label,directory in (('original-actual',ACTUAL),('original-source01-prepare',PREPARE)):
            for path in sorted(directory.rglob('*')):
                need(not path.is_symlink(),'no original symlink')
                if path.is_file():add(label+'/'+path.relative_to(directory).as_posix(),path)
        for path in report['inputs']:add('original-inputs/'+str(Path(path)).lstrip('/'),path)
        extras={
            'source01.py':R/'root-backward-private-cache-source-01/driver.py',
            'source02.py':R/'root-backward-private-cache-source-02/driver.py',
            'source-review-original.json':R/'scope-backward-private-cache-source-review-01.json',
            'exact-intent-original.json':R/'to-view-recovery-integration-01/publication-preflight-01/root-backward-private-cache-source02-and-exact-intent-v1.json',
            'tool-custody-original.json':a.tool_custody,
            'seal-source.py':Path(__file__).resolve()}
        for name,path in extras.items():add('provenance/'+name,path)
        bind(extras['source-review-original.json'],PEER)
        old=bind(extras['source01.py'],'54f1eb3b9ba7a4ee3f317c068e3c0ccb97b12e33515d018c28d52a1acde8cb5b')
        new=bind(extras['source02.py'],'5183c0d6cd0274d29e4fd9e5c7dac1e89d79e8bf35ff0bec6fdcdb1432ee498c')
        intent=json.loads(bind(extras['exact-intent-original.json'],'fed33952cdf11f87dfa5b130eb6898b9518ed96474f3da716c9ef2ed00cf4838'))
        before,after=intent['edit']['before'].encode(),intent['edit']['after'].encode()
        need(old.count(before)==new.count(after)==1 and old.replace(before,after)==new and new.replace(after,before)==old,'original source finalization correction exact inverse')
        members={}
        archive=out/'complete.tar.xz'
        with tarfile.open(archive,'x:xz',format=tarfile.USTAR_FORMAT,preset=1) as tf:
            for name,path in sorted(sources.items()):
                raw=bind(path);meta=BOUND[str(path)]
                info=tarfile.TarInfo(name);info.size=len(raw);info.mode=meta['mode'];info.mtime=0
                tf.addfile(info,io.BytesIO(raw));members[name]={**meta,'source_path':str(path)}
        os.chmod(archive,0o600)
        verification=archive_verify(archive,members)
        need(not ATTEMPTS,'no forbidden side effects')
        before_inputs=dict(BOUND)
        for path,meta in before_inputs.items():bind(Path(path),meta['sha256']);need(BOUND[path]==meta,'all original inputs unchanged after full admission/archive')
        admission['checks']=CHECKS
        write(out/'native-report-original.json',native_raw)
        write(out/'admission-report.json',encode(admission))
        write(out/'file-manifest.json',encode({'schema':'heptatorch.backward-private-cache.complete-evidence.v1','members':members,
              'member_count':len(members),'member_bytes':sum(x['bytes'] for x in members.values()),'archive':verification}))
        write(out/'verification.json',encode(verification))
        write(out/'inputs-custody.json',encode(before_inputs))
        write(out/'README.md',b'# Backward private preserve resource evidence\n\nOne actual native resource control passed; all original source, input, request, response, owner, RNG, maps, limit and EOF evidence is preserved here. Original source01 preparation was PREPARED_NOT_RUN. Source02 only makes final EOF failures persist before reporting. No native, Torch or compiler process runs during this pure admission. Internal target attribution uses fixed HIA source order plus actual owner geometry, not an instruction trace. No complete PyTorch schema is closed.\n\ncomplete.tar.xz preserves original member modes. Repository copies of outer files use 0644; original outer files are 0600. file-manifest.json binds all original member bytes and modes. native-report-original.json is copied without JSON reserialization. General transition checking and new numeric parity are outside this resource control; the separate original76 qualification remains authoritative.\n')
        result.update(status='PASS_PURE_RECORDED_EVIDENCE_AND_FULL_SEAL',admission=admission,verification=verification,
                      all_inputs_unchanged=True,input_count=len(before_inputs),forbidden_attempts=ATTEMPTS)
        code=0
    except BaseException as error:
        result.update(status='FAIL',error=repr(error),traceback=traceback.format_exc(),forbidden_attempts=ATTEMPTS)
    result['completed_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['checks']=CHECKS;write(out/'report.json',encode(result))
    print(json.dumps({'status':result['status'],'checks':CHECKS,'error':result.get('error'),'report':str(out/'report.json')}))
    return code
if __name__=='__main__':raise SystemExit(main())
