status=0
make test-differentiable-view-preserve-resources \
  HEPTA_SOURCE_ROOT="$GITHUB_WORKSPACE/.toolchain/hepta" \
  HEPTA_STACK_BUILD="$RUNNER_TEMP/hepta-stack-budget" \
  > build/differentiable-view-preserve-resources.make.stdout \
  2> build/differentiable-view-preserve-resources.make.stderr || status=$?
cat build/differentiable-view-preserve-resources.make.stdout
cat build/differentiable-view-preserve-resources.make.stderr >&2
if [ -f build/differentiable-view-preserve-resources/report.json ]; then
  cp build/differentiable-view-preserve-resources/report.json build/differentiable-view-preserve-resources.json
  python3 -I -S -B tools/emit_ci_report.py build/differentiable-view-preserve-resources.json
fi
exit "$status"
