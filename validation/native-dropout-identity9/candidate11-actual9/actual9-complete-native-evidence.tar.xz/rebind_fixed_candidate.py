#!/usr/bin/env python3
"""Create a distinct replay file with only an exact new native build identity."""
import argparse
import hashlib
import json
from pathlib import Path

def sha(value):
    return hashlib.sha256(value).hexdigest()

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--original',type=Path,required=True)
p.add_argument('--build-report',type=Path,required=True)
p.add_argument('--binary',type=Path,required=True)
p.add_argument('--source',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
original=a.original.read_bytes()
assert sha(original)=='d119db9e9e190af5beb838f55e9208b2c58fef10c624f63e90cc9058459f3d6c'
build=json.loads(a.build_report.read_bytes())
assert build['source_sha256']==sha(a.source.read_bytes())
assert build['native_sha256']==sha(a.binary.read_bytes())
assert build['status']=='PASS' and build['link_exit']==0
assert build['descriptor_bytes']==640 and build['state_format']=='HTDTYP03' and build['backing_format']=='HTODTY03'
assert len(build['units'])==11 and all(u['compiler_exit']==0 for u in build['units'])
changes=[
    (b"SOURCE = '7b8f597f6734722e38679163e2aea1058ae0d04c46c876bd682a19a319f76f26'",
     ("SOURCE = '"+build['source_sha256']+"'").encode()),
    (b"IMAGE = '165fe622d9ead60c9f94a01f7c5d09784cc096cb96c12dd008ce148e643ef96d'",
     ("IMAGE = '"+build['native_sha256']+"'").encode()),
    (b'==(519,6827,24958,640)',
     ('==('+','.join(str(build[k]) for k in ('functions','blocks','instructions','descriptor_bytes'))+')').encode()),
]
updated=original
for old,new in changes:
    assert updated.count(old)==1
    updated=updated.replace(old,new)
inverse=updated
for old,new in reversed(changes):
    assert inverse.count(new)==1
    inverse=inverse.replace(new,old)
assert inverse==original
a.output.mkdir(parents=True,exist_ok=False)
target=a.output/'replay_actual_identity9.py'
target.write_bytes(updated)
report={'schema':'heptatorch.identity9-candidate-pin-only-rebind.v1',
        'original_runner_sha256':sha(original),'new_runner_sha256':sha(updated),
        'original_reference_sha256':'de7db2f985873be797bd7e167fb374f82b5690021e0a0541d2fb4f7a36b7ad83',
        'source_sha256':build['source_sha256'],'native_sha256':build['native_sha256'],
        'build_report_sha256':sha(a.build_report.read_bytes()),
        'changes':[{'old':old.decode(),'new':new.decode()}for old,new in changes],
        'inverse_exact':True,'numeric_expected_changes':0,'assertion_rule_changes':0,
        'recipe_changes':0,'reference_changes':0,'native_executed':False,'status':'PREPARED_NOT_RUN'}
(a.output/'pin-rebind.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'new_runner_sha256':report['new_runner_sha256'],
                  'inverse_exact':True,'source_sha256':build['source_sha256'],'native_sha256':build['native_sha256']}))
