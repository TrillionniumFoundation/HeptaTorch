#!/usr/bin/env python3
"""Preserve the failing native audit and inspect the two original lifetime stages."""
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import traceback

ROOT=Path('/dev/shm/heptatorch-d26699e25fea')
FROZEN=ROOT/'identity-native-review/candidate07-actual9-01/inputs'
OUT=ROOT/'identity-native-review/candidate07-optimizer-audit-diagnostic-02'
OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('original_identity9',FROZEN/'replay_actual_identity9.py')
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
spec=importlib.util.spec_from_file_location('original_identity9_protocol',FROZEN/'protocol.py')
w=importlib.util.module_from_spec(spec)
spec.loader.exec_module(w)
reference=json.loads((FROZEN/'torch-empty-dropout-identity.json').read_bytes())
assert m.sha((FROZEN/'torch-empty-dropout-identity.json').read_bytes())==m.REFERENCE
native=ROOT/'native-dropout-dtype-extension/candidate-07/tensor-dtype-dropout-session'
assert m.sha(native.read_bytes())==m.IMAGE
r=m.Replay(w,SimpleNamespace(binary=native),OUT/'native',reference,reference['rows'][7],4)
observations=[]

def diagnostic_weak(handles,expected,label):
    r.phase=label
    for name,handle in handles.items():
        assert expected['Storage_expired'][name] is False
        hold=r.make(43,handle)
        r.eq(hold!=0,True,label+' Storage remains actually lockable '+name)
        r.one(45,hold)
    before=r.save_owner(label+'-before-audit')
    status,records=w.parse(r.session.exchange(w.packet([(53,)])))
    after=r.save_owner(label+'-after-audit')
    observations.append({'stage':label,'audit_frame_status':status,
                         'audit_records':[{'opcode':v['opcode'],'value':v['value'],'payload_hex':v['payload'].hex()} for v in records],
                         'before_sha256':m.sha(before['bytes']),'after_sha256':m.sha(after['bytes']),
                         'owner_pointer_unchanged':before['pointer']==after['pointer'],
                         'owner_bytes_unchanged':before['bytes']==after['bytes']})
    # Record the actual failure. This diagnostic does not relabel it as PASS;
    # continue only to the original recipe's next optimizer-drop observation.

r.weak_snapshot=diagnostic_weak
report={'schema':'heptatorch.optimizer-history-audit-diagnostic.v1','status':'RUNNING',
        'original_failure_preserved':True,'full_qualification':False,
        'native_sha256':m.IMAGE,'source_sha256':m.SOURCE,'reference_sha256':m.REFERENCE,
        'runner_sha256':m.sha((FROZEN/'replay_actual_identity9.py').read_bytes()),
        'diagnostic_sha256':m.sha(Path(__file__).read_bytes())}
try:
    r.run_lifetime(reference['rows'][7]['observation']['variants'][4])
    report['status']='DIAGNOSED_FAILURE'
except BaseException as e:
    report.update(status='DIAGNOSTIC_ERROR',error=repr(e),traceback=traceback.format_exc())
finally:
    r.save_owner('final-diagnostic')
    r.session.finish()
    report.update(observations=observations,owners=r.owners,frames=r.session.frames,
                  assertions=r.assertions,native_exit_code=r.session.exit_code,trace=r.trace)
    m.write_json(OUT/'report.json',report)
    print(json.dumps({k:report[k] for k in ('status','observations','frames','assertions','native_exit_code')}))
