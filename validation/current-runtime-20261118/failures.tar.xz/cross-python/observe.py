from pathlib import Path
import sys,json
repo=Path('/home/qian-qi/heptatorch-current-49c929e8308c/final-660-snapshot-01/repo')
sys.path.insert(0,str(repo/'tests/current_runtime_original35'))
from binding import Inputs,bind_build
import observer
inputs=Inputs()
build,bodies=bind_build(repo/'build/current-runtime','aae73ebfbc0d04401a02467f896b48e4cf886ca47f27835f25f24512a2ba57d9',inputs)
owner,adaptation=observer.configure(build,bodies,repo/'build/current-runtime',inputs)
print(json.dumps({'python':sys.version,'executable':sys.executable,'adaptation':adaptation,'changed_inputs':inputs.recheck()},sort_keys=True))
