#!/usr/bin/env python3
"""Run only the three affected regressions through the frozen official coordinator.

This external orchestration file does not modify the repository's GROUPS,
readers, comparison predicates, fixtures, or qualification functions.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
import time
import traceback

sys.dont_write_bytecode = True
SELECTED = ("original76", "sum32", "live32")
CASES = {"original76": 76, "sum32": 32, "live32": 32}
OFFICIAL = ("bool27", "original76", "integral24", "sum_f32_17", "current35",
            "base270", "sum32", "live32", "logical147", "resource7")
SOURCE = "0c1c0dd3acf0285a887a2766c1308dfd992acf3fe51849dcd98749bb64a00f3b"
IMAGE = "6ff13ccab1b30db389307900958937496905e0ed842893081d878788aa7c754c"
BUILD = "aae73ebfbc0d04401a02467f896b48e4cf886ca47f27835f25f24512a2ba57d9"
PRIOR = "aa168047fc9a0392707f3c1c08b8ab4cb88c2bc16e1732c4c37c2a3994cc14c0"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--build-directory", type=Path, required=True)
    parser.add_argument("--expected-build-sha256", required=True)
    parser.add_argument("--expected-coordinator-sha256", required=True)
    parser.add_argument("--snapshot-manifest", type=Path, required=True)
    parser.add_argument("--expected-snapshot-manifest-sha256", required=True)
    parser.add_argument("--torch-python", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not sys.flags.optimize and sys.version_info[:2] == (3, 12)
    repository = args.repository.resolve()
    build = args.build_directory.resolve()
    output = args.output.resolve()
    torch_python = args.torch_python.absolute()
    assert args.expected_build_sha256 == BUILD
    assert build == repository / "build/current-runtime"
    assert not output.is_relative_to(repository)
    output.mkdir(parents=True, exist_ok=False)

    source_path = repository / "tests/qualify_current_runtime.py"
    spec = importlib.util.spec_from_file_location("frozen_official_coordinator", source_path)
    official = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(official)
    require = official.require
    require(tuple(official.GROUPS) == OFFICIAL, "official ten-group contract must be unchanged")
    require(official.SOURCE == SOURCE and official.IMAGE == IMAGE
            and official.FUNCTIONS == 700 and official.UNITS == 14,
            "same canonical current source/image required")
    inputs, suites, failures = official.Inputs(), [], []
    started = time.monotonic()
    report = dict(
        schema="heptatorch.partial-post-667-regression.v1",
        scope="PARTIAL_POST_667_REGRESSION", status="RUNNING",
        source_sha256=SOURCE, native_sha256=IMAGE, actual_build_sha256=BUILD,
        functions=700, units=14,
        required_suites=list(SELECTED), selected_suites=list(SELECTED),
        required_cases=CASES, required_cases_total=140,
        official_required_suites=list(OFFICIAL), official_required_cases_total=667,
        official_GROUPS_modified=False, full_667_executed=False,
        prior_667_qualification_sha256=PRIOR, prior_667_PASS_transferred=False,
        old_PASS_transferred=False, original_assertions_modified=False,
        full_pytorch_rewrite_complete=False, schema_closure=False,
        full_project_status="HOLD", compiler_executed=False,
        Torch_executed=False, native_executed=False,
        coordinator_source_sha256=args.expected_coordinator_sha256,
        snapshot_manifest_sha256=args.expected_snapshot_manifest_sha256,
        interpreter_version=sys.version,
        suites=suites, failures=failures,
    )

    def save():
        official.dump(output / "qualification.json", report)

    try:
        inputs.bind(Path(__file__).resolve())
        inputs.bind(source_path, args.expected_coordinator_sha256)
        inputs.bind(args.snapshot_manifest.resolve(), args.expected_snapshot_manifest_sha256)
        require(Path(sys.executable).resolve() == torch_python.resolve(),
                "coordinator and actual Torch must use the same pinned interpreter")
        python_raw = inputs.bind(torch_python.resolve(),
            "e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f")
        report["interpreter_binary_sha256"] = official.sha(python_raw)
        for name in ("current_runtime_fixtures.py", "current_runtime_process.py",
                     "current_runtime_admission.py", "current_runtime_torch.py",
                     "current_runtime_live32.py", "current_runtime_live32_readback.py"):
            inputs.bind(repository / "tests" / name)
        build_sha = official.build_binding(build, inputs)
        require(build_sha == BUILD, "same complete admitted actual cold build")
        fixtures = official.Fixtures(output, inputs)
        for name in SELECTED:
            execution = output / (name + "-execution")
            execution.mkdir()
            directory = output / name
            row = dict(name=name, status="PREPARING", qualified=False)
            suites.append(row)
            save()
            print(json.dumps(dict(suite=name, status=row["status"], scope=report["scope"])), flush=True)
            try:
                command = official.runner_command(name, build, build_sha, directory,
                                                  fixtures, inputs, torch_python)
                row["actual_command"] = command
                receipt = official.execute(command, execution, official.SUITE_TIMEOUT_SECONDS[name])
                row["runner"] = receipt
                observed = None
                if (directory / "report.json").is_file():
                    raw = inputs.bind(directory / "report.json")
                    observed = json.loads(raw)
                    row["original_report"] = dict(path=str((directory / "report.json").relative_to(output)),
                                                  bytes=len(raw), sha256=official.sha(raw))
                    row["original_report_status"] = observed.get("status")
                    row["native_executed"] = observed.get("native_executed")
                    row["Torch_executed"] = observed.get("Torch_executed")
                    if observed.get("native_executed") is True:
                        report["native_executed"] = True
                    if observed.get("Torch_executed") is True:
                        report["Torch_executed"] = True
                require(receipt["started"] is True and receipt["exit_code"] == 0
                        and receipt["stdout_EOF"] is True and receipt["stderr_EOF"] is True
                        and receipt["stderr_bytes"] == 0 and not receipt.get("timed_out")
                        and not receipt.get("forced_cleanup") and not receipt.get("cleanup_errors")
                        and not receipt.get("running_descendants_after_cleanup"),
                        "native suite runner failed or did not finish; report=" + str(row.get("original_report_status")))
                require(observed is not None, "native suite produced no original report")
                require(observed["source_sha256"] == SOURCE and observed["native_sha256"] == IMAGE,
                        "suite source or native image identity changed")
                if name == "original76":
                    counts = official.qualify_legacy(observed, build_sha)
                elif name == "sum32":
                    counts = official.qualify_sum32(observed, build_sha)
                else:
                    counts = official.qualify_live32(observed, build_sha, directory, inputs)
                row.update(status="PASS", qualified=True, **counts)
            except Exception as error:
                if "runner" not in row and (execution / "runner.json").is_file():
                    row["runner"] = json.loads(inputs.bind(execution / "runner.json"))
                row.update(status="FAIL", error=dict(type=type(error).__name__, message=str(error),
                                                     traceback=traceback.format_exc()))
                failures.append(name + ": " + str(error))
            save()
            print(json.dumps(dict(suite=name, status=row["status"], qualified=row["qualified"],
                                  scope=report["scope"])), flush=True)
    except Exception as error:
        failures.append("build/source admission: " + repr(error))
        report["admission_error"] = traceback.format_exc()
    finally:
        errors = inputs.recheck()
        if errors:
            failures.append("bound inputs changed during partial regression")
        complete = len(suites) == len(SELECTED) and [row["name"] for row in suites] == list(SELECTED)
        passed = complete and all(row["qualified"] is True and row["status"] == "PASS" for row in suites) and not failures
        require(tuple(official.GROUPS) == OFFICIAL, "official GROUPS changed during execution")
        report.update(status="PASS_PARTIAL_POST_667_REGRESSION" if passed else "FAIL_PARTIAL_POST_667_REGRESSION",
            all_suites_executed=complete and all(row.get("runner", {}).get("started") is True for row in suites),
            all_selected_suites_executed=complete and all(row.get("runner", {}).get("started") is True for row in suites),
            all_inputs_unchanged=not errors, input_recheck_errors=errors,
            checked_inputs=inputs.records, elapsed_seconds=time.monotonic() - started)
        save()
    print(json.dumps(dict(status=report["status"], scope=report["scope"],
        suites={row["name"]: row["status"] for row in suites}, failures=failures,
        selected_cases_total=140, full_667_executed=False,
        qualification=str(output / "qualification.json"))), flush=True)
    return 0 if report["status"] == "PASS_PARTIAL_POST_667_REGRESSION" else 1


if __name__ == "__main__":
    raise SystemExit(main())
