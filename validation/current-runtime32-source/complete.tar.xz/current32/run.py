#!/usr/bin/env python3
"""Preserve the complete original live32 oracle; add cold-build and raw custody.

No request, response, Tensor id, reference value, comparison, or original source
is rewritten. The two transport taps only observe bytes that the original
Native implementation actually writes/reads. Prepare starts no native or Torch.
"""
from pathlib import Path
from generator_admission import derive as derive_generator_admission
import argparse
import contextlib
import gzip
import hashlib
import json
import os
import re
import stat
import struct
import sys
import time
import traceback
import types

HERE = Path(__file__).resolve().parent
SOURCE = 'fac3d413c6c0f6874d224cbea312108ee2c8baa027102d41890d85094a5faa38'
IMAGE = '5b7aac203d2c913d43781f0da45d40e9bac2037c2bc074ec30f8dd663710a805'
ORACLE = '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160'
ADMISSION = '5b7b9a538877c06bce9daff0631657ae3b9ce79bcd7336d42839a01ef9cbcfde'
OWNER = 'c39600e7c37dea390f88cf9e74d86dfa924301456e0f32e127d82c98ad6778b0'
SUPPORT = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
UPSTREAM = 'd204c5a8268a0d0f0a1dd162b5e0ab184beee83310bcad643b084deb691f3f49'
CHECKS = {'python_matches', 'platform_matches', 'version_backend_matches',
          'git_matches_oracle_build_pin', 'distribution_version_matches',
          'direct_url_matches', 'direct_url_archive_sha256_matches',
          'pip_report_url_matches', 'pip_report_archive_sha256_matches',
          'pip_report_version_matches', 'pip_report_requested'}
SEEDS = [0, 1, 17, 5489, (1 << 31)-1, (1 << 32)-1, 1 << 32,
         (1 << 32)+17, (1 << 63)-1, 1 << 63, (1 << 64)-2, (1 << 64)-1]
PLAN = ([f'train-{seed}' for seed in SEEDS] +
        ['transpose', 'interleaved', 'overlap-nonzero-strides', 'channels-last',
         'empty-contiguous', 'empty-offset-999', 'empty-zero-strides',
         'clone-across-twist', 'state-restore-with-live-tensors', 'import-normal-cache-state',
         'version-error-prefix', 'spent-saved-prefix', 'ready-leaf-before-error',
         'two-generators-prefix', 'equal-interval', 'rounded-upper-clamp',
         'subnormal-interval', 'signed-zero-interval', 'binary64-maximum-admission',
         'invalid-ordered-interval'])


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def record(path):
    path = Path(path)
    before = path.stat()
    need(stat.S_ISREG(before.st_mode), 'input is not a regular file: ' + str(path))
    raw = path.read_bytes()
    after = path.stat()
    need((before.st_size, before.st_mtime_ns, before.st_ino) ==
         (after.st_size, after.st_mtime_ns, after.st_ino), 'input changed during read')
    return {'sha256': sha(raw), 'bytes': len(raw), 'mode': stat.S_IMODE(after.st_mode)}


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def bind(path, digest):
    raw = Path(path).read_bytes()
    need(sha(raw) == digest, 'SHA mismatch: ' + str(path))
    return raw


def package_inputs():
    manifest = json.loads((HERE / 'package-manifest.json').read_bytes())
    need(manifest['schema'] == 'heptatorch.current712-live32-source.v1', 'package schema')
    entries = list(HERE.rglob('*'))
    need(all(not p.is_symlink() and (p.is_file() or p.is_dir()) for p in entries),
         'source package links or special files are forbidden')
    actual = {str(p.relative_to(HERE)): record(p) for p in entries
              if p.is_file() and p != HERE / 'package-manifest.json'}
    need(actual == manifest['files'], 'exact complete package bytes/modes required')
    return {str((HERE / name).resolve()): row for name, row in actual.items()} | {
        str(HERE / 'package-manifest.json'): record(HERE / 'package-manifest.json')}


def admission_module(output):
    frozen = bind(HERE / 'frozen/admission701.py', ADMISSION)
    raw, proof = derive_generator_admission(frozen, SOURCE, IMAGE)
    path = output / 'executed-admission.py'
    path.write_bytes(raw)
    module = types.ModuleType('current32_actual_cold_admission')
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module, proof


def owner_module(output):
    frozen = bind(HERE / 'frozen/owner_integral.py', OWNER)
    changes = [('HTSINT01', 'HTSINT02', 2), ('HTOSIN01', 'HTOSIN02', 2),
               ('functions == 699', 'functions == 712', 1),
               ('sum-integral-source01-UNBOUND-699', 'live32-current712-UNBOUND', 1),
               ('sum-integral-source01-%d-preserved47-48', 'live32-current%d-full-owner', 1),
               ('heptatorch.sum-integral-owner-source01.v1', 'heptatorch.live32-current712-owner.v1', 1)]
    raw = frozen
    for before, after, count in changes:
        need(raw.count(before.encode()) == count and after.encode() not in raw,
             'owner profile edit count differs')
        raw = raw.replace(before.encode(), after.encode())
    restored = raw
    for before, after, count in reversed(changes):
        need(restored.count(after.encode()) == count, 'owner inverse edit count differs')
        restored = restored.replace(after.encode(), before.encode())
    need(restored == frozen, 'complete original full-owner source inverse failed')
    path = output / 'executed-owner.py'
    path.write_bytes(raw)
    module = types.ModuleType('current32_complete_owner')
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    module.bind_profile(SOURCE, IMAGE, 712)
    return module, {'frozen_sha256': OWNER, 'executed_sha256': sha(raw),
                    'whole_file_inverse_exact': True, 'edits': changes,
                    'all_original_84Q_predicates_retained': True,
                    'full_private_allocation_transition_ledger_claimed': False}


class StdinTap:
    def __init__(self, real, child):
        self.real, self.child = real, child

    def write(self, raw):
        frame = self.child['active_frame']
        need(frame is not None, 'write outside an original frame')
        written = self.real.write(raw)
        need(type(written) is int and 0 <= written <= len(raw), 'unverifiable native write')
        frame['request'].extend(raw[:written])
        return written

    def __getattr__(self, name):
        return getattr(self.real, name)


class ProcessTap:
    def __init__(self, real, child):
        self.real, self.child = real, child
        self.input_tap = StdinTap(real.stdin, child)

    @property
    def stdin(self):
        return None if self.real.stdin is None else self.input_tap

    @stdin.setter
    def stdin(self, value):
        need(value is None, 'original close only clears stdin')
        self.real.stdin = None

    def communicate(self, *args, **kwargs):
        item = {'stdout_EOF': False, 'stderr_EOF': False, 'exit_code': None,
                'error': None}
        ordinal = len(self.child['communications'])
        self.child['communications'].append(item)
        try:
            out, err = self.real.communicate(*args, **kwargs)
            prefix = self.child['directory'] / f'close-{ordinal:02d}'
            prefix.with_suffix('.stdout').write_bytes(out)
            prefix.with_suffix('.stderr').write_bytes(err)
            item.update(stdout_EOF=True, stderr_EOF=True, exit_code=self.real.returncode,
                        stdout_bytes=len(out), stderr_bytes=len(err),
                        stdout_sha256=sha(out), stderr_sha256=sha(err))
            return out, err
        except BaseException:
            item['error'] = traceback.format_exc()
            raise

    def __getattr__(self, name):
        return getattr(self.real, name)


class OSTap:
    def __init__(self, original, audit):
        self.original, self.audit = original, audit

    def read(self, fd, count):
        child = self.audit.by_fd.get(fd)
        need(child is not None and child['active_frame'] is not None,
             'read outside the actual original native frame')
        raw = self.original.read(fd, count)
        child['active_frame']['response'].extend(raw)
        if not raw:
            child['active_frame']['early_stdout_EOF'] = True
        return raw

    def __getattr__(self, name):
        return getattr(self.original, name)


class Audit:
    def __init__(self, output, binary, original, owner):
        self.output, self.binary, self.original, self.owner = output, binary, original, owner
        self.children, self.by_fd, self.instances = [], {}, []
        self.owner_capture = None
        (output / 'native').mkdir()
        original_decode, original_verify = owner.decode_owner, owner.verify_snapshot

        def captured_decode(raw, pointer):
            capture = self.owner_capture
            need(capture is not None, 'full owner decode outside an actual observation')
            path = capture['directory'] / (capture['label'] + '.owner.bin.gz')
            with gzip.open(path, 'xb', compresslevel=1) as stream:
                stream.write(raw)
            capture['raw'] = {'path': str(path.relative_to(output)), 'bytes': len(raw),
                              'sha256': sha(raw), 'pointer': pointer}
            # All bytes come from the unchanged OwnerReader's actual /proc read.
            value = original_decode(raw, pointer)
            encoded = json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
            path = capture['directory'] / (capture['label'] + '.owner.json.gz')
            with gzip.open(path, 'xb', compresslevel=1) as stream:
                stream.write(encoded)
            capture['decoded'] = {'path': str(path.relative_to(output)),
                                  'bytes': len(encoded), 'sha256': sha(encoded)}
            return value

        def captured_verify(value):
            verified = original_verify(value)
            need(self.owner_capture is not None, 'owner verification outside an observation')
            self.owner_capture['verification'] = verified
            return verified

        # Observational wrappers delegate to the complete unchanged checker.
        # Failed decoding/checking still retains the raw bytes read before it.
        owner.decode_owner, owner.verify_snapshot = captured_decode, captured_verify

    def snapshot(self, instance, directory, label):
        need(self.owner_capture is None, 'nested full-owner capture')
        capture = {'directory': directory, 'label': label, 'error': None}
        self.owner_capture = capture
        try:
            value = instance.owner_reader.snapshot()
            need(capture['raw']['bytes'] == value['length']
                 and capture['raw']['sha256'] == value['full_sha256'],
                 'full owner observation differs from actual captured memory')
            need(capture['verification']['all_original_84Q_predicates_retained'] is True,
                 'full original structural owner predicates did not run')
            capture['passed'] = True
        except BaseException:
            capture.update(passed=False, error=traceback.format_exc())
            raise
        finally:
            self.owner_capture = None
            capture.pop('directory')
            save(directory / (label + '.owner-observation.json'), capture)
        return capture

    def native_class(self):
        audit, base = self, self.original['Native']

        class CapturedNative(base):
            def __init__(self, executable):
                need(Path(executable).resolve() == audit.binary, 'wrong original native executable')
                need(record(executable)['sha256'] == IMAGE, 'native changed before Popen')
                ordinal = len(audit.children)
                need(ordinal < len(PLAN), 'unexpected extra native child')
                directory = audit.output / 'native' / f'{ordinal:02d}-{PLAN[ordinal]}'
                directory.mkdir()
                self.audit_child = {'case': PLAN[ordinal], 'directory': directory,
                    'started': False, 'frames': [], 'communications': [], 'active_frame': None,
                    'close_calls': [], 'request_hash': hashlib.sha256(),
                    'response_hash': hashlib.sha256(), 'initialization_error': None}
                audit.children.append(self.audit_child)
                audit.instances.append(self)
                try:
                    # The complete original constructor performs the only Popen.
                    base.__init__(self, executable)
                    child = self.audit_child
                    child.update(started=True, pid=self.process.pid)
                    self.process = ProcessTap(self.process, child)
                    proc_exe = Path('/proc') / str(self.process.pid) / 'exe'
                    proc_raw = proc_exe.read_bytes()
                    need(sha(proc_raw) == IMAGE, 'actual /proc child ELF differs')
                    child['proc_exe_sha256'] = sha(proc_raw)
                    child['proc_exe_bytes'] = len(proc_raw)
                    audit.by_fd[self.process.stdout.fileno()] = child
                    self.owner_reader = audit.owner.OwnerReader(self.process)
                except BaseException:
                    self.audit_child['initialization_error'] = traceback.format_exc()
                    raise

            def run(self, commands, status=0, returned=None):
                child = self.audit_child
                need(child['active_frame'] is None, 'nested original frame')
                body = audit.original['packet'](commands)
                attempted = b'HTOWNR01' + struct.pack('<Q', len(body)) + body
                frame = {'request': bytearray(), 'response': bytearray(),
                         'expected_transport_status': status, 'returned_records_override': returned,
                         'command_count': len(commands), 'early_stdout_EOF': False,
                         'original_assertions_passed': False, 'owner_before': None,
                         'owner_after': None, 'error': None}
                child['active_frame'] = frame
                ordinal = len(child['frames'])
                directory = child['directory'] / f'frame-{ordinal:05d}'
                directory.mkdir()
                (directory / 'attempted-request.bin').write_bytes(attempted)
                try:
                    frame['owner_before'] = audit.snapshot(self, directory, 'before')
                    result = base.run(self, commands, status=status, returned=returned)
                    frame['owner_after'] = audit.snapshot(self, directory, 'after')
                    need(bytes(frame['request']) == attempted, 'actual write differs from original packet')
                    response = bytes(frame['response'])
                    need(len(response) >= 48 and response[:8] == b'HTOWNS01'
                         and struct.unpack_from('<Q', response, 8)[0] == len(response)-16,
                         'observed complete original response framing differs')
                    need(not frame['early_stdout_EOF'], 'frame completed after premature EOF')
                    frame['original_assertions_passed'] = True
                    return result
                except BaseException:
                    frame['error'] = traceback.format_exc()
                    if frame['owner_before'] is not None and frame['owner_after'] is None \
                            and not (directory / 'after.owner-observation.json').exists():
                        try:
                            frame['owner_after'] = audit.snapshot(self, directory, 'after-failure')
                        except BaseException:
                            frame['failure_owner_observation_error'] = traceback.format_exc()
                    raise
                finally:
                    child['active_frame'] = None
                    request, response = bytes(frame.pop('request')), bytes(frame.pop('response'))
                    (directory / 'request.bin').write_bytes(request)
                    (directory / 'response.bin').write_bytes(response)
                    child['request_hash'].update(request)
                    child['response_hash'].update(response)
                    frame.update(index=ordinal, directory=str(directory.relative_to(audit.output)),
                                 request_bytes=len(request), response_bytes=len(response),
                                 request_sha256=sha(request), response_sha256=sha(response))
                    child['frames'].append(frame)
                    save(directory / 'transport.json', frame)

            def close(self, failed=False):
                call = {'failed_argument': failed, 'returned': False, 'error': None}
                self.audit_child['close_calls'].append(call)
                try:
                    base.close(self, failed)
                    call['returned'] = True
                except BaseException:
                    call['error'] = traceback.format_exc()
                    raise

        return CapturedNative

    def cleanup(self):
        for instance in self.instances:
            process = getattr(instance, 'process', None)
            child = instance.audit_child
            complete = bool(child['communications']) and all(
                child['communications'][-1][key] is True for key in ('stdout_EOF', 'stderr_EOF'))
            if process is not None and not complete:
                instance.audit_child['outer_cleanup_required'] = True
                try:
                    if process.poll() is None:
                        process.kill()
                    process.communicate(timeout=30)
                except BaseException:
                    instance.audit_child['outer_cleanup_error'] = traceback.format_exc()

    def reports(self):
        rows = []
        for child in self.children:
            row = {k: v for k, v in child.items()
                   if k not in {'directory', 'active_frame', 'request_hash', 'response_hash'}}
            row['directory'] = str(child['directory'].relative_to(self.output))
            row['request_stream_sha256'] = child['request_hash'].hexdigest()
            row['response_stream_sha256'] = child['response_hash'].hexdigest()
            row['frames_completed'] = sum(f['original_assertions_passed'] for f in child['frames'])
            save(child['directory'] / 'transport.json', row)
            rows.append(row)
        return rows


def check_actual(original, children):
    need(original['schema'] == 'heptatorch.live-pytorch-tensor-rng-backward.v1'
         and original['status'] == 'PASS' and original['cases'] == original['expected_cases'] == 32
         and original['failed_cases'] == 0 and original['pytorch_executed'] is True
         and original['one_native_process_per_trajectory'] is True, 'original32 did not pass completely')
    need(original['native_source_sha256'] == SOURCE and original['native_executable_sha256'] == IMAGE,
         'original report did not use selected source/image')
    provenance = original['oracle_provenance']
    need(provenance['status'] == 'PASS' and set(provenance['checks']) == CHECKS
         and all(v is True for v in provenance['checks'].values()), 'all eleven actual provenance checks required')
    need(set(original['source_files_unchanged_during_run']) ==
         {'native', 'source', 'oracle', 'reference_support', 'lock'}
         and all(v is True for v in original['source_files_unchanged_during_run'].values()),
         'original source custody failed')
    rows = original['rows']
    need([r['case'] for r in rows] == [c['case'] for c in children] == PLAN,
         'complete original32 ordered trajectory coverage required')
    for row, child in zip(rows, children):
        need(row['status'] == 'PASS' and child['started'] is True
             and child['proc_exe_sha256'] == IMAGE and child['initialization_error'] is None,
             'actual native child failed')
        need(len(child['frames']) == child['frames_completed'] == row['frames'] > 0
             and all(f['error'] is None for f in child['frames']), 'raw frame/original report census differs')
        need(all(f[key] is not None and f[key]['passed'] is True
                 and f[key]['verification']['all_original_84Q_predicates_retained'] is True
                 for f in child['frames'] for key in ('owner_before', 'owner_after')),
             'full actual owner verification is required before and after every original frame')
        need(row['request_stream_sha256'] == child['request_stream_sha256']
             and row['response_stream_sha256'] == child['response_stream_sha256'],
             'actual byte streams differ from original oracle digests')
        need(child['close_calls'] == [{'failed_argument': False, 'returned': True, 'error': None}]
             and len(child['communications']) == 1 and not child.get('outer_cleanup_required'),
             'original normal close required without cleanup or retry')
        close = child['communications'][0]
        need(close['exit_code'] == 0 and close['stdout_EOF'] is True and close['stderr_EOF'] is True
             and close['stdout_bytes'] == close['stderr_bytes'] == 0 and close['error'] is None,
             'actual child exit/EOF/trailing output failed')
    for field in ('frames', 'exact_binary32_words', 'serialized_state_bytes',
                  'absolute_version_comparisons', 'gradient_presence_comparisons'):
        need(original[field] == sum(row[field] for row in rows) > 0, 'original aggregate mismatch: ' + field)
    refusals = [(c['case'], f) for c in children for f in c['frames'] if f['expected_transport_status']]
    partials = [(c['case'], f) for c in children for f in c['frames'] if f['returned_records_override'] is not None]
    need(len(refusals) == 1 and refusals[0][0] == 'invalid-ordered-interval'
         and refusals[0][1]['expected_transport_status'] == 7, 'original single uniform refusal missing')
    need([name for name, frame in partials] == PLAN[22:26]
         and all(frame['returned_records_override'] == 2 for name, frame in partials),
         'four original partial-backward prefixes missing')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ('repository', 'binary', 'source', 'build-directory', 'output'):
        ap.add_argument('--' + name, required=True, type=Path)
    for name in ('source', 'native', 'build'):
        ap.add_argument('--expected-' + name + '-sha256', required=True)
    ap.add_argument('--prepare-only', action='store_true')
    args = ap.parse_args()
    need(not sys.flags.optimize, 'all original assertions must remain enabled')
    need(args.expected_source_sha256 == SOURCE and args.expected_native_sha256 == IMAGE,
         'this source-only adapter is reviewed for the exact native Tensor/Generator712 profile')
    for name in ('repository', 'binary', 'source', 'build_directory'):
        setattr(args, name, getattr(args, name).resolve(strict=True))
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    report = {'schema': 'heptatorch.current712-original-live32.v1', 'status': 'PREPARED_NOT_RUN',
              'source_sha256': SOURCE, 'native_sha256': IMAGE, 'build_sha256': args.expected_build_sha256,
              'expected_cases': 32, 'original_oracle_sha256': ORACLE, 'case_plan': PLAN,
              'native_executed': False, 'Torch_executed': False, 'Torch_execution_attempted': False,
              'historical_runtime_executed': False, 'request_or_response_translation': False,
              'original_comparisons_changed': False, 'full_private_allocation_ledger_claimed': False,
              'full_pytorch_rewrite_complete': False, 'error': None}
    custody, audit, original = {}, None, None
    exit_code = 1
    old_argv, old_cwd = sys.argv, Path.cwd()
    try:
        custody.update(package_inputs())
        original_raw = bind(HERE / 'frozen/oracle32.py', ORACLE)
        source_paths = {'tests/pytorch_tensor_rng_backward_oracle.py': ORACLE,
                        'tests/pytorch_oracle.py': SUPPORT,
                        'compatibility/pytorch-oracle-lock.json': LOCK,
                        'compatibility/upstream-lock.json': UPSTREAM}
        for relative, digest in source_paths.items():
            path = args.repository / relative
            bind(path, digest)
            custody[str(path)] = record(path)
        admission, proof = admission_module(args.output)
        owner, owner_proof = owner_module(args.output)
        owner_profile = owner.pin_profile(args.binary, args.source)
        cold = admission.admit_build(args.build_directory, args.expected_build_sha256,
                                     args.binary, args.source)
        custody.update(cold['files'])
        for name in ('executed-admission.py', 'executed-owner.py'):
            custody[str(args.output / name)] = record(args.output / name)
        save(args.output / 'cold-build-admission.json', cold)
        report.update(cold_build_admission=cold, admission_source_inverse=proof,
                      owner_source_inverse=owner_proof, owner_profile=owner_profile,
                      full_owner_structural_checks_required=True,
                      owner_raw_memory_captured_before_decode=True)
        if args.prepare_only:
            exit_code = 0
        else:
            install = args.repository / 'build/pytorch-install.json'
            custody[str(install)] = record(install)
            scope = {'__name__': 'current32_original_definitions',
                     '__file__': str(args.repository / 'tests/pytorch_tensor_rng_backward_oracle.py')}
            # This exact original source defines the original main and all comparisons.
            # Its top level contains only standard-library imports and the original plan.
            exec(compile(original_raw, scope['__file__'], 'exec'), scope)
            need(scope['PLAN'] == PLAN, 'the complete original32 plan changed')
            audit = Audit(args.output, args.binary, scope, owner)
            scope['Native'] = audit.native_class()
            scope['os'] = OSTap(scope['os'], audit)
            sys.argv = [scope['__file__'], '--native', str(args.binary), '--source', str(args.source),
                        '--expected-native-sha256', IMAGE, '--expected-source-sha256', SOURCE,
                        '--repo', str(args.repository), '--output', str(args.output / 'original-report.json')]
            report['Torch_execution_attempted'] = True
            with (args.output / 'original-entry.stdout').open('x') as stdout, \
                    (args.output / 'original-entry.stderr').open('x') as stderr:
                with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                    original_exit = scope['main']()
            report['original_entry_exit'] = original_exit
            original = json.loads((args.output / 'original-report.json').read_bytes())
            report['Torch_executed'] = original.get('pytorch_executed', False)
            children = audit.reports()
            need(original_exit == 0, 'complete original32 entry returned failure')
            check_actual(original, children)
            report.update(status='PASS_CURRENT712_ORIGINAL_LIVE32', cases=32,
                          native_children=32, frames=original['frames'],
                          exact_binary32_words=original['exact_binary32_words'],
                          serialized_state_bytes=original['serialized_state_bytes'],
                          absolute_version_comparisons=original['absolute_version_comparisons'],
                          gradient_presence_comparisons=original['gradient_presence_comparisons'],
                          original_report=record(args.output / 'original-report.json'),
                          oracle_provenance=original['oracle_provenance'])
            exit_code = 0
    except BaseException:
        report.update(status='FAIL', error=traceback.format_exc())
        exit_code = 1
    finally:
        sys.argv = old_argv
        os.chdir(old_cwd)
        if audit is not None:
            audit.cleanup()
            children = audit.reports()
            report['native_children_actual'] = children
            report['native_executed'] = any(c['started'] for c in children)
            if report['Torch_execution_attempted'] and original is None:
                report['Torch_executed'] = None
        unchanged = {}
        for path, expected in custody.items():
            try:
                unchanged[path] = record(path) == expected
            except BaseException:
                unchanged[path] = False
        report['inputs'] = custody
        report['input_checks_after_execution'] = unchanged
        report['all_inputs_unchanged'] = bool(custody) and all(unchanged.values())
        if not report['all_inputs_unchanged']:
            report['status'] = 'FAIL'
            exit_code = 1
        report['elapsed_seconds'] = time.monotonic() - started
        save(args.output / 'report.json', report)
        print(json.dumps({k: report[k] for k in ('status', 'expected_cases', 'native_executed',
                                                'Torch_executed', 'all_inputs_unchanged')}))
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
