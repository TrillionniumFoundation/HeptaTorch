# Original live Tensor/RNG/backward32 on the current cat-fixed701

This package is **SOURCE_ONLY / NOT_EXECUTED**. It has not started HIA, Torch,
the compiler, or a remote process. Preparation must say `PREPARED_NOT_RUN` and
cannot confer runtime qualification. Historical35/211/270/481 results do not
qualify these32 trajectories.

## Exact inputs

- Original oracle: `frozen/oracle32.py`, 22,577 bytes,
  `554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160`.
  It is byte-identical to the repository's
  `tests/pytorch_tensor_rng_backward_oracle.py`. Its complete main, case plan,
  `Comparison`, `train`, `layout`, `generator_case`, `partial`, `range_case`,
  packet serializer, original transport assertions, and close assertions run.
- Complete source:
  `82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313`.
- Actual native ELF:
  `80445a8c433f20314d3bc7b00ebb68f6a70fa200ee2e6aba193cff21aabfbc17`.
- Root's current cold build report:
  `ff065dcd35698ffbf4b456fed0740049cbd5804fec324c4a305b6ee81810c0d8`.
- Frozen full cold-build admission:
  `frozen/admission701.py`, SHA
  `5b7b9a538877c06bce9daff0631657ae3b9ce79bcd7336d42839a01ef9cbcfde`.
  Only the two source/image identities are replaced; reversing them restores
  the entire original file. All original14 units/15 processes, objects,
  physical output bytes, link request, two tool binaries, and stack predicates
  must pass. The actual report SHA is a mandatory explicit argument, so a new
  independent CI cold build can be bound without pretending its receipt is
  the original remote receipt.
- Frozen complete structural owner:
  `frozen/owner_integral.py`, 71,640 bytes,
  `c39600e7c37dea390f88cf9e74d86dfa924301456e0f32e127d82c98ad6778b0`.
  Only HTSINT01→HTSINT02, HTOSIN01→HTOSIN02,699→701 count and explicit profile
  names change; complete-file inverse is mandatory. All84-word structural
  predicates remain active. This is not a claim that the original35 private
  allocation transition ledger covers all32 RNG trajectories.
- Repository support, unchanged:
  `tests/pytorch_oracle.py` SHA
  `ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae`,
  `compatibility/pytorch-oracle-lock.json` SHA
  `ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944`,
  `compatibility/upstream-lock.json` SHA
  `d204c5a8268a0d0f0a1dd162b5e0ab184beee83310bcad643b084deb691f3f49`.
- Actual execution also requires the original installation report
  `REPO/build/pytorch-install.json` and the same locked CPython3.12/Linux x86_64
  CPU Torch2.15.0 environment used by the live35/270 gates. All11 original
  provenance checks must actually pass. An old reference report is not an
  input that can substitute for live Torch here.

## Interface and preservation boundary

The original protocol is already HTOWNR01/HTORCH03→HTOWNS01/HTORSP03. Public
metadata is128 bytes/16Q. Actual Tensor and Generator return handles are kept
throughout each trajectory; intra-frame references retain the original
`0xfe000000 | ordinal` encoding. No reset, private constructor, or slot number
is predicted by the wrapper.

The wrapper executes the complete original source definitions and calls the
original `main`. An observational subclass invokes each original Native
constructor/run/close body. `StdinTap.write` calls the actual original pipe
write and records exactly the returned written bytes. `OSTap.read` calls the
actual original `os.read` and returns its bytes unchanged. Captured request
and response streams must equal the digests reported by the original oracle.
The original64-byte command serializer and every response assertion remain
in charge; no error record or response is synthesized.

The complete original OwnerReader reads `/proc/PID/syscall` and `/proc/PID/mem`
at the wrapper's next16-byte stdin read. It sends no additional request and
does not mutate HIA memory. Before and after every original frame, the owner
must settle and all structural predicates must pass. Observational wrappers
around the unchanged decoder and verifier save actual full owner bytes before
decoding and the exact decoded JSON before validation. Thus a real structural
failure retains its raw memory and decoded state when decoding succeeds.

The original comparisons remain stronger than a floating tolerance: all
binary32 tensor and gradient bytes must match exactly, and each serialized CPU
Generator state must equal all5056 original Torch bytes. Absolute Version,
storage byte offset/extent, gradient presence and shape/stride remain exact.

The32 trajectory plan is12 seed training sequences,4 layouts,3 empty layouts,
3 Generator-state trajectories,4 partial-backward trajectories and6 uniform
range trajectories. The32-case report must retain the original ordered names.
Each of12 training sequences performs12 SGD updates. A real invalid interval
must produce the original count0/status7 refusal. The four partial-backward
requests must preserve the actual two-record prefix with original error6/10
and leave their original suffix unexecuted. Neither case class is converted
into a synthetic old-protocol error response.

Compatibility still requires a new actual run: empty offset999, overlapping
uniform fill, Generator cached normal state, partial-backward owner validity,
absolute Version and all exact binary32 training results may expose real
implementation differences. This package changes no expectation to hide them.

## Exact invocation

Set `PY` to the locked interpreter, `PKG` to this package, `REPO` to the exact
reviewed repository and `COLD` to the actual current cat cold-build directory
whose build.json SHA is ff065dcd…. The outputs must be separate fresh paths.

```sh
"$PY" -B "$PKG/run.py" \
  --repository "$REPO" --binary "$COLD/heptatorch" \
  --source "$COLD/runtime.hepta" --build-directory "$COLD" \
  --expected-source-sha256 82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313 \
  --expected-native-sha256 80445a8c433f20314d3bc7b00ebb68f6a70fa200ee2e6aba193cff21aabfbc17 \
  --expected-build-sha256 ff065dcd35698ffbf4b456fed0740049cbd5804fec324c4a305b6ee81810c0d8 \
  --output "$PREPARE_OUTPUT" --prepare-only

"$PY" -B "$PKG/run.py" \
  --repository "$REPO" --binary "$COLD/heptatorch" \
  --source "$COLD/runtime.hepta" --build-directory "$COLD" \
  --expected-source-sha256 82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313 \
  --expected-native-sha256 80445a8c433f20314d3bc7b00ebb68f6a70fa200ee2e6aba193cff21aabfbc17 \
  --expected-build-sha256 ff065dcd35698ffbf4b456fed0740049cbd5804fec324c4a305b6ee81810c0d8 \
  --output "$ACTUAL_OUTPUT"
```

Do not use `-S` for the actual invocation: it must import the installed fixed
Torch. Do not use `-O`; the wrapper rejects optimization and the original
assertions must execute. No legacy ELF is invoked or rebuilt.

## Mandatory actual result

The outer exit must be0 and `report.json.status` must be
`PASS_CURRENT701_ORIGINAL_LIVE32`. The original report must independently say
PASS with32 ordered cases, zero failed cases, live Torch and all11 provenance
checks. All32 actual children must bind `/proc/PID/exe` to80445a8c…, execute
every original frame, and close normally with exit0, both EOF and empty extra
stdout/stderr. Every frame needs successful full owner before/after snapshots.
Original stream digests and all original counter sums must match the captured
data. Every original/package/cold-build/derived-reader input must remain
unchanged in SHA, bytes and mode. No skip, missing input, cleanup kill, old PASS,
or preparation result is admitted as actual PASS.

Outputs include the untouched `original-report.json`, original stdout/stderr,
complete build admission and source inverses, per-child process/close receipts,
per-frame actual requests/responses, full owner memory/decoded snapshots and
all-input rechecks. The full private allocation transition ledger and whole
PyTorch rewrite claims remain false even if this bounded32 group passes.
