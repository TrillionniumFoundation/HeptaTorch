import pathlib,json,hashlib,ast
R=pathlib.Path("/home/qian-qi/heptatorch-continuation-20261116")
N=R/"runs/differentiable-view-r4-scalar06-native-build-01/candidate-r4-scalar06"
sha=lambda b:hashlib.sha256(b).hexdigest()
BASE=R/"runs/to-view-recovery-integration-01/repo/tests/differentiable_view_native_review"
expected={
 N/"runtime.hepta":"743c6de8c4f2e9ea6dbb880aca5a27c719c2b14ce05e7262020ece63b1ccd148",
 N/"tensor-shape-scalar-session":"f05020afd1f6d80551713a031e1976137d8e3ea25e9501f44f1449dde85a44ea",
 N/"build.json":"29b9d7246859ae79c228090b6f8b14fdf92a95a49816e9d74ddc95eae8564c2b",
 BASE/"replay_direct_view14.py":"52c3b3242a73fb412102c83c5ba47cf8d95a4eb3c01e56f41bfe593066506d05",
 BASE/"protocol.py":"7a30d7bca140e3a4cc9d63a3e6930b92d2ffd60ad4503895419d8a63e67c8bd9",
 BASE/"owner_client.py":"dee3e4cb25ee1e5e06513e2f33478fbe274d9510ce2aaab9525815c72312946b",
 R/"runs/native_observer_shape02.py":"59019b5c4aeae0d7e04b362354bd9ca55917d2196791d3d18c4908a05fdbba8b",
 R/"runs/r4-native-replay-custody-runner-01.py":"0293f647b3d960db0c5ded6f5bd2472122fbcb35d4df088ff0dca46ce0a1281e",
}
for p,h in expected.items():
 raw=p.read_bytes();assert sha(raw)==h,(str(p),sha(raw),h)
 if p.suffix==".py":ast.parse(raw)
build=json.loads((N/"build.json").read_bytes())
assert build["status"]=="PASS" and build["functions"]==656 and len(build["units"])==13
assert build["source_sha256"]==expected[N/"runtime.hepta"] and build["native_sha256"]==expected[N/"tensor-shape-scalar-session"]
for u in build["units"]:
 for suffix,key in ((".hepta","source_sha256"),(".o","object_sha256")):
  p=N/(u["name"]+suffix);expected[p]=u[key];assert sha(p.read_bytes())==u[key]
suites=[
 (26,"replay_shape26_r3.py","af290dad8ed2c815a1fe17c98296a39a451ba2de7673c16b97608ad16fc645a2",
   "differentiable-view-r4-shape-reference26-01","pytorch_view_reshape_probe.py",
   "4dd374419e4b21a9c814c855d846481730a12ea57a30dcf229a6b962f07021c5",
   "fecf1956790f78a9b1238f535c1c7cce9f1237b211c389ac0736d88687bbb9c9"),
 (32,"replay_wrapped_scalar32_r1.py","7386703b3deb01d6ab809447a1e6ae83d3c87ab1b4264d9e54641dbf99b93ad0",
   "wrapped-f64-reference32-01","pytorch_wrapped_f64_probe.py",
   "c0ddafbae6ea81bd98f6066bc867f71e0b6e8d4f73e6c5d7f15f7fe3d29569a3",
   "f3ecc9dd7db2ce8fbd0e424557ad5b95ac2e899a1c09cf38dad47e4fecc2b0c6"),
]
for count,readername,readerpin,refdir,probename,probepin,refpin in suites:
 own=dict(expected)
 reader=R/"runs"/readername;probe=R/"runs"/refdir/probename;ref=R/"runs"/refdir/"actual.json"
 own.update({reader:readerpin,probe:probepin,ref:refpin})
 for p,h in own.items():assert sha(p.read_bytes())==h,(str(p),sha(p.read_bytes()),h)
 output=R/("runs/r4-scalar06-native%d-first-01"%count)
 assert not output.exists()
 argv=["/usr/bin/python3","-B",str(reader),
  "--binary",str(N/"tensor-shape-scalar-session"),"--source",str(N/"runtime.hepta"),
  "--build-report",str(N/"build.json"),"--protocol",str(BASE/"protocol.py"),
  "--observer",str(R/"runs/native_observer_shape02.py"),"--reference",str(ref),
  "--probe",str(probe),"--support-reader",str(BASE/"replay_direct_view14.py"),
  "--expected-source-sha256",expected[N/"runtime.hepta"],
  "--expected-native-sha256",expected[N/"tensor-shape-scalar-session"],
  "--expected-observer-sha256",expected[R/"runs/native_observer_shape02.py"],
  "--expected-functions","656","--expected-native-units","13","--output",str(output/"observed")]
 if count==26:argv+=["--expected-reference-sha256",refpin]
 rows=[{"path":str(p),"bytes":p.stat().st_size,"sha256":h} for p,h in own.items()]
 intent={"schema":"heptatorch.r4-native-replay-intent.v1","argv":argv,"cwd":str(R),
  "execution_owner":"/root/pytorch_scope","native_requested":True,"torch_requested":False,
  "custody_directory":str(output),"timeout_seconds":2400,"expected_cases":count,
  "allowed_success_statuses":["PASS"],"inputs":rows,
  "stable_key":"heptatorch-r4-scalar06-native%d-first-20261117-v1"%count,
  "initial_native638_history":"24 PASS / 2 NOT_RUN, whole26 FAIL; not transferred to this source"}
 p=R/("runs/r4-scalar06-native%d-first-intent.json"%count)
 with p.open("x") as f:f.write(json.dumps(intent,indent=2)+"\n")
 print(json.dumps({"suite":count,"intent":str(p),"sha256":sha(p.read_bytes()),"bytes":p.stat().st_size,"inputs":len(rows),"not_started":True}))
