"""One-shot, exact-intent native replay custody. No Tensor evaluator."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import traceback

sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--intent', type=Path, required=True)
    ap.add_argument('--expected-intent-sha256', required=True)
    args = ap.parse_args()
    intent_raw = args.intent.read_bytes()
    assert sha(intent_raw) == args.expected_intent_sha256
    intent = json.loads(intent_raw)
    assert intent['execution_owner'] == '/root/pytorch_scope'
    assert intent['native_requested'] is True and intent['torch_requested'] is False
    argv = intent['argv']
    assert argv[0] == '/usr/bin/python3' and argv[1] == '-B'
    assert argv.count('--output') == 1
    out = Path(intent['custody_directory'])
    out.mkdir(parents=True, exist_ok=False)
    child_output = Path(argv[argv.index('--output') + 1])
    assert child_output == out / 'observed' and not child_output.exists()
    before = {Path(row['path']): Path(row['path']).read_bytes() for row in intent['inputs']}
    for row in intent['inputs']:
        assert len(before[Path(row['path'])]) == row['bytes']
        assert sha(before[Path(row['path'])]) == row['sha256']
    assert Path(argv[2]) in before
    report = {'schema': 'heptatorch.r4-native-replay-custody.v1',
              'status': 'STARTING', 'intent_sha256': sha(intent_raw),
              'argv': argv, 'cwd': intent['cwd'],
              'child_started': False, 'child_completed': False,
              'native_requested': True, 'torch_executed_here': False,
              'all_inputs_unchanged': None}
    def save():
        (out / 'execution.json').write_text(json.dumps(report, indent=2) + '\n')
    save()
    code, stdout, stderr, error = None, b'', b'', None
    try:
        process = subprocess.Popen(argv, cwd=intent['cwd'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        report['child_started'] = True
        report['pid'] = process.pid
        save()
        try:
            stdout, stderr = process.communicate(timeout=intent['timeout_seconds'])
        except subprocess.TimeoutExpired:
            process.kill()
            stdout, stderr = process.communicate()
            raise
        code = process.returncode
        report['child_completed'] = True
    except BaseException as failure:
        error = {'type': type(failure).__name__, 'message': str(failure),
                 'traceback': traceback.format_exc()}
    (out / 'stdout.bin').write_bytes(stdout)
    (out / 'stderr.bin').write_bytes(stderr)
    after = {str(path): {'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size}
             for path in before}
    unchanged = all(path.read_bytes() == raw for path, raw in before.items())
    child = child_output / 'report.json'
    summary = json.loads(child.read_bytes()) if child.is_file() else None
    allowed = intent['allowed_success_statuses']
    succeeded = (error is None and code == 0 and unchanged and summary is not None
                 and summary['status'] in allowed)
    report.update(status=summary['status'] if succeeded else 'FAIL', returncode=code,
                  stdout_sha256=sha(stdout), stdout_bytes=len(stdout),
                  stderr_sha256=sha(stderr), stderr_bytes=len(stderr),
                  all_inputs_unchanged=unchanged, inputs_after=after,
                  child_report_path=str(child), child_report_sha256=sha(child.read_bytes()) if child.is_file() else None,
                  child_status=summary['status'] if summary else None, error=error)
    report['request_file_unchanged'] = args.intent.read_bytes() == intent_raw
    if not report['request_file_unchanged']:
        report['status'] = 'FAIL'
        succeeded = False
    save()
    print(json.dumps({key: report[key] for key in ('status', 'returncode', 'child_started',
        'child_completed', 'all_inputs_unchanged', 'child_report_path', 'child_report_sha256',
        'stderr_bytes', 'error')}), flush=True)
    return 0 if succeeded else 1


if __name__ == '__main__':
    raise SystemExit(main())
