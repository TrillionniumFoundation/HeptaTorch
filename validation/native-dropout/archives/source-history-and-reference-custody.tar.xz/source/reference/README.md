# Actual native_dropout reference observations

This directory preserves one actual run of the pinned Linux CPU PyTorch wheel.
It contains 28 observations, not a HIA compatibility result. The source probe is
unchanged from its reviewed 17,914-byte draft (SHA256
751ec38a24c9856a6a02c7f9494ad468c1f265965c36337e94cc3fb74a6e566d).
No HIA executable ran during these observations.

## Provenance and custody

The ROG task 1a1e431d3fd-392-367b exited 0 under the existing CPython 3.12.3 Torch
environment. All eleven checks in the original pinned provenance helper passed.
Source, helper, lock, complete pip installation report and the native path used
only as a provenance argument were unchanged before and after execution.
The native argument was the frozen 428-function image, SHA256
6773485896d961b6c2e62784ebb66320290df47128bd1331aecc0c8b7f6611fe; it was not executed.

The complete pretty JSON is 492,271 bytes, SHA256
bc5a490f1623a4078050829798f502b0be934722f371adbcbb5612aaeb1a563c.
The complete stdout, stderr, launch inputs, execution receipt and original pip
report are retained. The original report and stdout were copied as bytes rather
than parsed and reserialized. This preserves exact 64-bit integers and the
2^61 size-one stride.

A separate Mac standard-library check parsed both representations using exact
Python integers, checked all 28 case-plan identities, all eleven provenance
checks and all three complete 5,056-byte Generator states. This check executed
neither Torch nor a Linux native image. Its receipt is reference-review.json.

The earlier ROG preparation job 1a1e40d76b6-392-35de remains UNKNOWN after its
transport failure. It was not resubmitted under another preparation key and
was not relabeled as successful. The new actual task was explicitly authorized
after the successful independent Mac AST/prepare stage.

## Observations within the recorded sequence

- Nonempty training=None and training=True at p=0.5 had identical forward
  values and masks, but their observed reverse scales were 1 and 2 respectively.
- Nonempty training=False accepted p=0.5, NaN, -0.25 and 1.25. It consumed no
  RNG state, returned fresh output storage and a true bool mask. Its mask used
  one byte per element, was nondifferentiable and started at Version 0.
- The six nonempty invalid-probability cases with training=None or True raised
  without changing the complete Generator state.
- All twelve empty cases returned the original Tensor and Storage, preserved
  the nonstandard strides, returned a float32 empty mask and consumed no RNG.
  For the requires-grad leaf inputs used here, forward changed the same input
  into a NativeDropoutBackward0 nonleaf. The first output backward in the
  recorded sequence raised "leaf variable has been moved into the graph
  interior". This is an actual boundary, not completed empty autograd support.
- The public mask and the Saved mask were the same Tensor and Storage. Direct
  mask.backward was rejected in every successful-forward case. Public
  mask.zero_ advanced its Version and later output backward reported a Saved
  version error. Input mutation alone did not cause that error in the
  nonempty transpose cases.
- The overlap, expanded, channels-last and extreme size-one layouts all
  accepted forward and first default backward. Their next backward reported
  released Saved data while the public mask remained readable.
- The six-element training cases matched twelve float32 raw32 controls; the
  twelve-element channels-last case matched twenty-four. All three distinct
  complete states preserved both prepopulated normal caches.

These statements describe this explicit operation order. They do not claim
higher-order differentiation, other dtypes, all seeds or all layouts. The
frozen 183-case probe and its original results were not changed.

The 371-byte stderr is retained verbatim. It is the pinned Torch import warning
that NumPy is not installed; this probe does not use NumPy, and all provenance
checks and the complete 28-row observation ran successfully.

## Fixed primary sources

The probe records source hashes and URLs for PyTorch commit
31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457, including:

- aten/src/ATen/native/Dropout.cpp: the empty, optional-training and mask paths.
- tools/autograd/derivatives.yaml: native_dropout reverse semantics.
- aten/src/ATen/native/TensorFactories.cpp and aten/src/ATen/ExpandUtils.cpp:
  Preserve-format allocation and inferred dense strides.
- torchgen/api/autograd.py: output differentiation handling.

The observed wheel identity and the pinned release-source relationship remain
in the original provenance object; source inspection does not substitute for
the actual wheel observations.

## Reproduction

Run the probe from the pinned repository root, where the original
build/pytorch-install.json is available. Use the pinned Linux Python and pass
the unchanged helper and lock through --support and --lock. The required
--executable argument is supplied to the provenance helper only. Select a new
--output path; preserve the first result and all errors.

verify_reference_snapshot.py checks this specific preserved observation. Run it
with --directory pointing to a fresh copy of the raw inputs that does not yet
contain reference-review.json. It deliberately uses exclusive output creation.

All native/full-RNG/full-PyTorch completion flags remain false. The project
denominator remains 2590, and these reference rows do not add completed APIs.
