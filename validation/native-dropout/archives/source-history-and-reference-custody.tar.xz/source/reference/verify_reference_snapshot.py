#!/usr/bin/env python3
"""Verify the exact preserved reference observation, without executing Torch."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

PINS = {
    "pytorch_native_dropout_contract_probe.py": "751ec38a24c9856a6a02c7f9494ad468c1f265965c36337e94cc3fb74a6e566d",
    "pytorch_oracle.py": "ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae",
    "pytorch-oracle-lock.json": "ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944",
    "pytorch-install.json": "35ad4841c2f2f94be7ded7f1bcc97f9592f806658ff660bfac5bdc3b0cf986ef",
    "torch-native-dropout.json": "bc5a490f1623a4078050829798f502b0be934722f371adbcbb5612aaeb1a563c",
    "actual.stdout.txt": "3e446949770af7ac2cc1944c1a580ba4cabcd5669aed08fd83910202d2a12801",
    "actual.stderr.txt": "d1e8fb8d8622d9a8d3a6a3a9ace42ef4c9c59e9e0fa8a18cbe4e34263b729382",
    "execution.json": "4588b9e6e99c30c7cd11e745f88b2d23982b040187b303943de6cd3a4a199648",
    "launch-inputs.json": "18eff6d200f0b32a5e68d219592774d6dc9d7b7bf540b95fbdb8939a660d3f34",
}
CHECKS = ("python_matches", "platform_matches", "version_backend_matches",
          "git_matches_oracle_build_pin", "distribution_version_matches",
          "direct_url_matches", "direct_url_archive_sha256_matches",
          "pip_report_url_matches", "pip_report_archive_sha256_matches",
          "pip_report_version_matches", "pip_report_requested")
SHA = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--directory", type=Path, required=True)
    a = p.parse_args()
    d = a.directory.resolve()
    original = {name: (d / name).read_bytes() for name in PINS}
    for name, pin in PINS.items():
        assert SHA(original[name]) == pin, name
    report = json.loads(original["torch-native-dropout.json"])
    assert json.loads(original["actual.stdout.txt"]) == report
    assert report["status"] == "OBSERVED"
    assert report["cases"] == report["expected_cases"] == len(report["rows"]) == len(report["case_plan"]) == 28
    assert report["probe_errors"] == [] and report["probe_error_count"] == 0
    assert report["probe_sha256"] == PINS["pytorch_native_dropout_contract_probe.py"]
    assert report["source_files_unchanged"] is True
    assert report["native_executed"] is False and report["native_qualified"] is False
    assert report["pytorch_api_denominator"] == 2590 and report["full_pytorch_rewrite_complete"] is False
    assert report["oracle_provenance"]["status"] == "PASS"
    checks = report["oracle_provenance"]["checks"]
    assert set(checks) == set(CHECKS) and all(checks[k] is True for k in CHECKS)
    assert len({r["name"] for r in report["rows"]}) == 28
    for index, (row, plan) in enumerate(zip(report["rows"], report["case_plan"])):
        assert row["index"] == index and row["status"] == "OBSERVED"
        assert all(row[k] == value for k, value in plan.items())
    states = report["states"]
    assert len(states) == report["unique_complete_states"]
    state_rows = []
    for digest, item in sorted(states.items()):
        raw = bytes.fromhex(item["hex"])
        assert len(raw) == item["bytes"] == 5056 and SHA(raw) == digest
        assert struct.unpack_from("<i", raw, 8)[0] == item["left"]
        assert struct.unpack_from("<Q", raw, 16)[0] == item["next"]
        assert raw[5016:].hex() == item["normal_cache_bytes"]
        state_rows.append({"sha256": digest, "bytes": len(raw), "left": item["left"],
                           "next": item["next"], "normal_cache_bytes": item["normal_cache_bytes"]})
    referenced = set()
    def walk(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if key in ("state_before", "state_after", "state_after_forward", "state_after_all"):
                    assert isinstance(item, str) and item in states
                    referenced.add(item)
                else:
                    walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)
    walk(report["rows"])
    assert referenced == set(states)
    execution = json.loads(original["execution.json"])
    assert execution["status"] == "COMPLETED" and execution["probe_exit_code"] == 0
    assert execution["inputs_unchanged"] is True and execution["native_executed"] is False
    assert execution["report"]["sha256"] == PINS["torch-native-dropout.json"]
    assert execution["stdout"]["sha256"] == PINS["actual.stdout.txt"]
    assert execution["stderr"]["sha256"] == PINS["actual.stderr.txt"]
    inputs = json.loads(original["launch-inputs.json"])
    for row in inputs["files"]:
        name = Path(row["path"]).name
        if name == "tensor-gradient-adam-distributions-session":
            assert row["sha256"] == "6773485896d961b6c2e62784ebb66320290df47128bd1331aecc0c8b7f6611fe"
            continue
        assert name in original and row["bytes"] == len(original[name])
        assert row["sha256"] == PINS[name]
    rows = []
    for item in report["rows"]:
        row = {"index": item["index"], "name": item["name"], "forward_accepted": item["forward"]["accepted"],
               "forward_error": item["forward"]["error"], "raw32_state_matches": item["matching_raw32_uniform_counts"],
               "normal_caches_unchanged": item["normal_caches_unchanged"]}
        if "mask" in item:
            row.update(mask={k: item["mask"][k] for k in ("dtype", "element_size", "storage_bytes", "strides", "version", "requires_grad")},
                       output={k: item["output"][k] for k in ("shape", "strides", "storage_offset_elements", "grad_fn")},
                       output_same_Tensor=item["output_is_input_Tensor"],
                       output_same_Storage=item["output_aliases_input_Storage"],
                       input_is_leaf_after_forward=item["input_after_forward"]["is_leaf"],
                       mask_backward_accepted=item["mask_as_output_backward"]["accepted"],
                       first_backward_accepted=item["first_backward"]["accepted"],
                       first_backward_error=item["first_backward"]["error"],
                       first_gradient=item["first_backward"]["input_gradient"]["tensor"])
            for key in ("backward_after_input_mutation", "backward_after_mask_mutation", "retry_after_default_release"):
                if key in item:
                    row[key] = {k: item[key][k] for k in ("accepted", "error")}
        rows.append(row)
    result = {"schema": "heptatorch.native-dropout-reference-custody-review.v1",
              "status": "REFERENCE_BYTES_AND_STRUCTURE_VERIFIED",
              "reference_origin": "Actual pinned Linux Torch on ROG, job 1a1e431d3fd-392-367b",
              "review_execution_scope": "JSON, exact bytes and complete state hashes only; no new Torch or native execution",
              "cases_observed": 28, "probe_errors": 0, "provenance_checks_true": 11,
              "unique_complete_states": len(states), "state_checks": state_rows,
              "raw_report_sha256": PINS["torch-native-dropout.json"],
              "raw_stdout_semantically_equals_report_with_exact_Python_integers": True,
              "all_input_custody_checks_passed": True, "rows": rows,
              "warning": original["actual.stderr.txt"].decode("utf-8"),
              "interpretation_limit": "Observations describe the recorded operation order. The empty requires-grad alias case is an observed backward error, not completed empty autograd support.",
              "native_executed_by_review": False, "torch_executed_by_review": False,
              "native_qualified": False, "all_rng_complete": False,
              "full_pytorch_rewrite_complete": False, "pytorch_api_denominator": 2590}
    output = d / "reference-review.json"
    with output.open("x") as f:
        f.write(json.dumps(result, indent=2, allow_nan=False) + "\n")
    assert all((d / name).read_bytes() == raw for name, raw in original.items())
    print(json.dumps({"status": result["status"], "cases": 28, "checks": 11, "states": len(states),
                      "report": str(output), "bytes": output.stat().st_size, "sha256": SHA(output.read_bytes())}))


if __name__ == "__main__":
    main()
