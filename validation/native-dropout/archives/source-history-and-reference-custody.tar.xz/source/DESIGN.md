# Native dtype and native_dropout successor

Status: implementation in progress; no successor binary has been qualified.

## Immutable parent and reference

The parent is the recovered, byte-verified 446-function retained-gradient runtime,
source `666230f05cc6942470006d1f184135321d8cbc26a6c6ba0bf7e3cf9857fe515b`,
ELF `7568c0a4ec40d82d3a0b46d1e8a27499dd96e8fe3fd15433523131a196da89b5`.
Its 79-member handoff manifest is `ebb1bef63aee4f715dcf45399f454b8a82c94097f2d7147d05de281fcdf6540f`.
Recovery is not a new build or transfer of test results to another source.

The additional real Torch observation is `reference/torch-native-dropout.json`,
492,271 bytes, SHA256 `bc5a490f1623a4078050829798f502b0be934722f371adbcbb5612aaeb1a563c`.
It contains 28 observations, zero probe errors and all 11 pinned provenance
checks. The probe, observations and original 183-case reference remain immutable.

The implementation follows PyTorch source commit
`31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457`:

- [Dropout.cpp](https://github.com/pytorch/pytorch/blob/31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457/aten/src/ATen/native/Dropout.cpp)
  defines the early empty return, optional training branch, bool mask,
  sequential multiplication and clone branch.
- [derivatives.yaml](https://github.com/pytorch/pytorch/blob/31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457/tools/autograd/derivatives.yaml)
  saves the returned mask and specifies different backward scale for absent
  training and true training.
- [TensorFactories.cpp](https://github.com/pytorch/pytorch/blob/31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457/aten/src/ATen/native/TensorFactories.cpp)
  and [ExpandUtils.cpp](https://github.com/pytorch/pytorch/blob/31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457/aten/src/ATen/ExpandUtils.cpp)
  specify Preserve allocation and dense-stride inference. This is distinct
  from TensorIterator's signed byte-stride ordering.

## Actual contract to implement

| Input / training | Forward | Mask | Random state | Backward |
|---|---|---|---|---|
| Nonempty F32, None | Same sampled values as true training | True one-byte bool, fresh T/S/V0 | Two MT32 words per element in the observed CPU kernel | Scale 1 |
| Nonempty F32, true | Multiply input by mask, then double-derived scale | True one-byte bool, Preserve layout, V0 | Includes draws at p=0 and p=1 in the original 183 observations | Scale 0 at p=1, otherwise 1/(1-p) |
| Nonempty F32, false | Fresh Preserve clone, including NaN/out-of-range p | One-byte bool ones, V0 | Unchanged | Scale 1 |
| Empty F32, requires false | Same input Tensor and Storage | Fresh empty F32 with Preserve strides, offset 0 | Unchanged | No differentiable target |
| Empty F32, requires true | Actual Torch returns the same Tensor, changes its autograd identity | Fresh empty F32 | Unchanged | Actual first backward raises leaf-interior error; after mask mutation Saved version error takes precedence |

Every returned mask in the new reference is non-differentiable. The Saved mask
is the same Tensor and Storage as the public mask; mutating that mask changes
its actual shared Version and invalidates backward. Input mutation does not
invalidate the mask-only derivative. Default backward releases Saved state;
the still-public mask remains readable.

The empty differentiable case needs a real separation of Tensor identity and
AccumulateGrad node identity. It must not be implemented by a self-edge, a fake
successful empty gradient, or a counter-only adjustment. Until that transition
is represented, it remains an explicitly reported admission/semantic gap.

## Native layout

The successor has a new internal state tag and 640-byte descriptor. Existing
offsets 0 through 575 retain their meanings, including retained-gradient flags
in the Tensor table, captured AccumulateGrad references at 88, optimizer roots
at 312, Tensor incarnation at 320, gradient binding and incoming caches.

| Descriptor offset | Role |
|---:|---|
| 576 | dtype code: 0 = binary32, 1 = bool |
| 584 | NativeDropout's saved mask node, or zero |
| 592 | Saved mask Tensor incarnation, or zero |
| 600 | Number of native Saved Tensor strong roots targeting this node |
| 608 | Reserved for a separately specified identity transition; zero initially |
| 616 | Audit-only expected Saved Tensor root count; zero at commit |
| 624, 632 | Reserved, zero |

Element width is derived from dtype, not independently mutable metadata.
Descriptor pages are `256 * 640` bytes. The old gradient audit's `[448,576)`
temporary-field check remains exactly that range: its 576 constant is not a
descriptor size. Storage extents and offsets continue to be byte quantities.

The initial supported storage dtypes are F32 and bool. Width-based checked
allocation, access, views and serialization are designed to admit later F64
and I64 implementations without another fake float representation. Reserving
that design does not implement their arithmetic or autograd.

## Ownership and safety

The single HIA owner remains linear, with offset-based extents, slot/generation
tables and native allocation/migration. No raw capability is copied into a
byte table. A Saved mask retains both the existing Saved S/V record and a real
Tensor root. The latter increments node metadata references and offset 600;
it is counted independently of optimizer roots and gradient roots. Release
clears the referring node's fields before decrementing references and draining
GC. This preserves public-mask-drop/unpack identity and permits final release.

All old numeric paths remain binary32 and receive explicit dtype admission.
They must reject bool before reading a four-byte value. In particular this
includes scalar add, RNG fill, distribution targets/probabilities, optimizer
parameter/state construction, all ordinary numerical kernels, backward seeds
and public gradient assignment. Generic clone, detach, views and public Saved
pack/unpack preserve dtype and true element width. A bool requires-grad request
is rejected with whole-owner and RNG rollback. Gradient compatibility compares
dtype as well as shape; manual bool gradient arithmetic is not silently enabled.

Public Saved layout remains a 128-byte private Storage; its previously zero
offset 16 stores dtype. The legacy F32 Saved range reader rejects bool; a
typed Saved can be unpacked and read through the new typed byte reader.

## Acceptance gates

1. Raw bool storage is exactly one byte per element; values, byte extent,
   offset, noncontiguous strides, clone/detach/views and Saved round trip.
2. Every old numeric admission class rejects bool, including empty bool,
   without altering owner, Generator, Version or published handles.
3. Real bool mask generation matches immutable full 5056-byte Generator
   reference states, output/mask values and exact metadata.
4. Public mask and Saved access share actual Tensor incarnation, Storage and
   Version. Drop, unpack, mutation, retain/default release and weak expiry are
   checked independently of numerical equality.
5. Same-owner alias and optimizer/retained-gradient regressions remain intact.
6. Ordinary errors and output-capacity/OOM errors roll back the complete owner;
   command 58 still commits only the explicitly documented partial execution.
7. Old/new owned profiles reject each other's nonempty state, retain the
   original owner on rejection, and close the actual mapping correctly.

No gate is marked passed here. The full PyTorch rewrite remains incomplete;
the coverage denominator stays 2590.
