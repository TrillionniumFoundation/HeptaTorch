# Proposed typed Tensor protocol increment

Status: implementation contract, not a qualification result. Commands 1–95,
including 93/94 retained-gradient behavior, keep their existing contracts on
F32. The internal format changes to `HTDTYP02` / `HTODTY02`; the outer owned
framing and `HTORCH03` / `HTORSP03` wire headers remain unchanged.

Each command remains eight little-endian u64 words. All unspecified words are
zero and nonzero reserved words are rejected with status 7. Dtype codes are
0=F32 (4 bytes) and 1=bool (1 byte); other codes are rejected with status 7.

| Code | Words after opcode | Successful record |
|---:|---|---|
| 96 | Tensor, query | query 0: value=dtype, payload four u64 `(dtype, element_bytes, Tensor_incarnation, is_leaf)`; query 1: Saved NativeDropout mask's public Tensor token, no payload |
| 97 | dtype, config_offset | New real Tensor token; no payload |
| 98 | Tensor, first_element, element_count | value=element_count; payload exact logical-order element bytes, with no conversion or padding |
| 99 | input Tensor, Generator, p_binary64_bits, training | value=output Tensor token; payload one u64 mask Tensor token |
| 100 | Tensor, scalar_raw_bits, no_grad | value=1, no payload; fill logical elements and bump the actual Version exactly once, including empty tensors |

For 96, query 0 exposes actual Tensor incarnation separately from the revocable
public token. Query 1 checks the real Saved version before publishing the
retained mask Tensor. Republishing after a public drop changes the public
token, while preserving Tensor incarnation and Storage/Version identity. It
does not create a clone or synthetic mask.

For 97, config is aligned to eight bytes, begins after the command table and
contains eight u64 words: `(rank, requires_grad, d0, d1, d2, d3, data_offset,
data_bytes)`. Unused shape words are zero. Data starts after the command table,
is within the frame, and has exactly `numel * element_bytes` bytes. F32 uses
raw little-endian IEEE words; bool bytes must be exactly 0 or 1. Bool with
requires_grad=1 is rejected with status 5. Dimension, element-count, owner
capacity and handle limits retain the parent's explicit bounded contract.

For 98, range errors are status 2 and insufficient response capacity is status
3. F32 bytes are the same words exposed by the older F32 reader. Bool is not
serialized as a float or widened fake tensor.

For 99, training is 0=false, 1=true, 2=None. The explicit Generator selects the
same CPU state transition observed for Torch's default CPU generator; this
does not claim a Python-compatible default-generator API. NativeDropout
produces two actual Tensor objects. A request-local result reference denotes
only the first output; the mask token is returned in the response and can be
used in a subsequent frame. Probability validation occurs only in the
applicable nonempty training branch. Unsupported dtype and the not-yet-
implemented empty differentiable identity transition are explicit failures,
not successful substitutes.

For 100, F32 scalar bits must fit u32 and bool scalar must be 0 or 1. no_grad
is 0 or 1; differentiable tensors require explicit no_grad=1. This initial
operation does not create an autograd fill node. It operates on each logical
index, including overlapping views, and performs one shared Version update.

Existing F32 numerical APIs reject bool before four-byte access. Generic
metadata, ownership, clone/detach/view, weak references, Saved pack/unpack and
typed reads preserve bool dtype. Existing low-level public mutation command
12 uses the tensor's actual element width and raw dtype bits. The legacy
F32-only range readers remain F32-only; their old payload schema is unchanged.

Weak records carry the source Tensor dtype at +24. Public Hold records carry that dtype at +32, independently of the existing private-Hold flag at +24. The legacy F32 Hold reader rejects bool, including empty reads; locking and releasing a bool Storage remain valid lifetime operations. Private raw-byte Holds retain type word zero.
