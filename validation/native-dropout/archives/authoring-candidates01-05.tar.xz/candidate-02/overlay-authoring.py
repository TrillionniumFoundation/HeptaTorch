def typed_descriptor(w: mutbuf, rank: u64, shape: u64, requires: u64, own: u64, dtype: u64) -> u64:
    if getw(w, 0) != 0:
        return 0
    width = dtype_width(dtype)
    if width == 0:
        return terror(w, 7)
    if dtype == 1 and requires == 1:
        return terror(w, 5)
    if rank > 4 or requires > 1:
        return terror(w, 2)
    location = object_address(w, shape)
    if location > length(w) or 32 > length(w) - location:
        return terror(w, 2)
    slot = getw(w, 8)
    if slot >= 65536:
        return terror(w, 3)
    if getw(w, 120) == 18446744073709551615:
        return terror(w, 8)
    n = 1
    axis = 0
    while axis < rank:
        d = getw(w, shape + axis * 8)
        if d > 262144:
            return terror(w, 3)
        if d == 0:
            n = 0
        axis = axis + 1
    if n != 0:
        axis = 0
        while axis < rank:
            n = n * getw(w, shape + axis * 8)
            if n > 16777216:
                return terror(w, 3)
            axis = axis + 1
    if descriptor_page(w, slot) == 0:
        return 0
    if storage_capacity(w, 1, 0) == 0:
        return 0
    if own != 0 and storage_capacity(w, 3, 0) == 0:
        return 0
    p = dptr(w, slot)
    memory_fill(w, p, 640, 0)
    putw(w, p, rank)
    putw(w, p + 576, dtype)
    putw(w, p + 8, n)
    putw(w, p + 32, requires)
    putw(w, p + 64, choose(own != 0, slot, 0))
    putw(w, p + 200, 2)
    putw(w, p + 304, 1)
    putw(w, 120, getw(w, 120) + 1)
    putw(w, p + 320, getw(w, 120))
    axis = rank
    stride = 1
    while axis > 0:
        axis = axis - 1
        d = getw(w, shape + axis * 8)
        putw(w, p + 96 + axis * 8, d)
        putw(w, p + 128 + axis * 8, stride)
        if d != 0:
            stride = stride * d
    tid = so_slot_new(w, 1)
    tp = so_slot_lookup(w, 1, tid)
    putw(w, p + 192, tid)
    putw(w, p + 240, 1)
    so_uput(w, tp + 48, slot)
    if own != 0:
        data = alloc(w, n * width)
        if getw(w, 0) != 0:
            return 0
        hid = getw(w, 80)
        hp = so_slot_lookup(w, 6, hid)
        sid = so_uget(w, hp + 16)
        vid = so_slot_new(w, 3)
        vp = so_slot_lookup(w, 3, vid)
        so_uput(w, vp + 24, 1)
        so_uput(w, tp + 16, sid)
        so_uput(w, tp + 24, vid)
        so_uput(w, tp + 40, n * width)
        putw(w, p + 16, data)
        putw(w, p + 216, sid)
        putw(w, p + 224, vid)
        so_slot_drop(w, 6, hid)
    if requires != 0:
        work = alloc(w, n * 4)
        if getw(w, 0) != 0:
            return 0
        putw(w, p + 160, work)
        putw(w, p + 256, getw(w, 80))
    putw(w, 8, slot + 1)
    return slot

def bind_alias(w: mutbuf, t: u64, source: u64) -> u64:
    p = dptr(w, t)
    q = dptr(w, source)
    putw(w, p + 576, getw(w, q + 576))
    sid = getw(w, q + 216)
    vid = getw(w, q + 224)
    if so_storage_retain(w, sid) != 0 or so_version_retain(w, vid) != 0:
        return terror(w, 9)
    tp = so_slot_lookup(w, 1, getw(w, p + 192))
    so_uput(w, tp + 16, sid)
    so_uput(w, tp + 24, vid)
    so_uput(w, tp + 32, getw(w, q + 232))
    sp = so_storage_live(w, sid)
    remaining = 0
    if getw(w, q + 232) <= so_uget(w, sp + 24):
        remaining = so_uget(w, sp + 24) - getw(w, q + 232)
    so_uput(w, tp + 40, remaining)
    putw(w, p + 216, sid)
    putw(w, p + 224, vid)
    putw(w, p + 232, getw(w, q + 232))
    return 1

def save_public(w: mutbuf, t: u64) -> u64:
    p = dptr(w, t)
    layout = alloc(w, 128)
    if layout == 0:
        return 0
    hid = getw(w, 80)
    putw(w, layout, getw(w, p))
    putw(w, layout + 8, getw(w, p + 8))
    putw(w, layout + 16, getw(w, p + 576))
    j = 0
    while j < 4:
        putw(w, layout + 32 + j * 8, getw(w, p + 96 + j * 8))
        putw(w, layout + 64 + j * 8, getw(w, p + 128 + j * 8))
        j = j + 1
    return saved_create(w, t, hid)

def unpack_saved(w: mutbuf, id: u64) -> u64:
    p = public_saved(w, id)
    if p == 0:
        return 0
    if graph_saved_check(w, id) == 0:
        return 0
    layout = private_hold(w, so_uget(w, p + 56), 128)
    t = typed_descriptor(w, getw(w, layout), layout + 32, 0, 0, getw(w, layout + 16))
    if t == 0:
        return 0
    tp = dptr(w, t)
    sid = so_uget(w, p + 16)
    vid = so_uget(w, p + 24)
    if so_storage_retain(w, sid) != 0 or so_version_retain(w, vid) != 0:
        return terror(w, 9)
    record = so_slot_lookup(w, 1, getw(w, tp + 192))
    so_uput(w, record + 16, sid)
    so_uput(w, record + 24, vid)
    so_uput(w, record + 32, so_uget(w, p + 40))
    so_uput(w, record + 40, so_uget(w, p + 48))
    putw(w, tp + 216, sid)
    putw(w, tp + 224, vid)
    putw(w, tp + 232, so_uget(w, p + 40))
    sp = so_storage_live(w, sid)
    putw(w, tp + 16, 9223372036854775808 + so_uget(w, sp + 16) + so_uget(w, p + 40))
    j = 0
    while j < getw(w, layout):
        putw(w, tp + 128 + j * 8, getw(w, layout + 64 + j * 8))
        j = j + 1
    return t

def rng_strided_view(s: readbuf, w: mutbuf, id: u64, config: u64, end: u64) -> u64:
    t = public_node(w, id)
    if t == 0:
        return 0
    if config < end or config > length(s) or 80 > length(s) - config or (config & 7 != 0):
        return terror(w, 100)
    rank = getr(s, config)
    offset = getr(s, config + 72)
    if rank > 4:
        return terror(w, 2)
    p = dptr(w, t)
    sp = so_storage_live(w, getw(w, p + 216))
    if sp == 0:
        return terror(w, 1)
    width = dtype_width(getw(w, p + 576))
    size = so_uget(w, sp + 24) // width
    if offset > 1073741824 // width:
        return terror(w, 3)
    n = 1
    i = 0
    while i < 4:
        dim = getr(s, config + 8 + i * 8)
        stride = getr(s, config + 40 + i * 8)
        if i >= rank:
            if dim != 0 or stride != 0:
                return terror(w, 2)
        else:
            if dim > 262144 or stride >= 9223372036854775808:
                return terror(w, 3)
            if dim == 0:
                n = 0
        putw(w, 2048 + i * 8, dim)
        i = i + 1
    if n != 0:
        if offset > size:
            return terror(w, 2)
        extent = 1
        i = 0
        while i < rank:
            dim = getr(s, config + 8 + i * 8)
            stride = getr(s, config + 40 + i * 8)
            if n > 16777216 // dim:
                return terror(w, 3)
            n = n * dim
            if extent > size - offset:
                return terror(w, 2)
            if stride != 0:
                if dim - 1 > (size - offset - extent) // stride:
                    return terror(w, 2)
                extent = extent + (dim - 1) * stride
            i = i + 1
        if extent > size - offset:
            return terror(w, 2)
    result = descriptor(w, rank, 2048, 0, 0)
    if result == 0:
        return 0
    q = dptr(w, result)
    if bind_alias(w, result, t) == 0:
        return 0
    putw(w, q + 16, 9223372036854775808 + so_uget(w, sp + 16) + offset * width)
    putw(w, q + 64, getw(w, p + 64))
    putw(w, q + 232, offset * width)
    tp = so_slot_lookup(w, 1, getw(w, q + 192))
    so_uput(w, tp + 32, offset * width)
    remaining = 0
    if offset <= size:
        remaining = (size - offset) * width
    so_uput(w, tp + 40, remaining)
    i = 0
    while i < rank:
        putw(w, q + 128 + i * 8, getr(s, config + 40 + i * 8))
        i = i + 1
    return result

def gradient_shape_matches(w: mutbuf, t: u64, g: u64) -> u64:
    p = dptr(w, t)
    q = dptr(w, g)
    if getw(w, p + 576) != getw(w, q + 576):
        return 0
    rank = getw(w, p)
    if getw(w, q) != rank:
        return 0
    j = 0
    while j < rank:
        if getw(w, p + 96 + j * 8) != getw(w, q + 96 + j * 8):
            return 0
        j = j + 1
    return 1

def gradient_assign(w: mutbuf, t: u64, g: u64) -> u64:
    if valid(w, t) == 0:
        return 0
    p = dptr(w, t)
    if g == 0:
        return gradient_unbind(w, t)
    if valid(w, g) == 0:
        return 0
    if t == g or gradient_shape_matches(w, t, g) == 0:
        return terror(w, 2)
    if tensor_dtype(w, t) != 0:
        return terror(w, 5)
    if gradient_binding(w, t) == g:
        return 1
    if gradient_cycle_check(w, t, g) == 0:
        return 0
    incarnation = getw(w, dptr(w, g) + 320)
    if gradient_reference_retain(w, g, incarnation) == 0:
        return 0
    if gradient_unbind(w, t) == 0:
        return 0
    putw(w, p + 384, g)
    putw(w, p + 392, incarnation)
    putw(w, p + 360, 1)
    return 1

def entry(s: readbuf, o: mutbuf, w: mutbuf, scratch: mutbuf) -> u32:
    if length(o) < 32:
        return 0
    reply_error(o, 0)
    error = frame_valid(s)
    if error != 0:
        reply_error(o, error)
        return 32
    putw(w, 0, 0)
    putw(w, 48, 0)
    putw(w, 56, 0)
    count = getr(s, 8)
    if count != 0:
        putw(w, 96, 8192)
    end = 32 + count * 64
    i = 0
    at = 32
    halted = 0
    while i < count and halted == 0:
        if at > length(o) - 32:
            putw(o, 24, 3)
            return at
        putw(w, 104, i)
        code = getr(s, 32 + i * 64)
        if code >= 96 and code <= 100:
            next = typed_command(s, o, w, scratch, 32 + i * 64, at, end)
        elif code >= 91 and code <= 94:
            next = gradient_object_command(s, o, w, 32 + i * 64, at)
        elif code >= 71 and code <= 79 or code == 90 or code == 95:
            next = owned_optimizer_command(s, o, w, 32 + i * 64, at, end)
        elif code >= 80 and code <= 89:
            if code == 86 or code == 87:
                next = dist_partial_command(s, o, w, scratch, 32 + i * 64, at)
            else:
                next = dist_command(s, o, w, scratch, 32 + i * 64, at)
        elif code >= 60 and code <= 69:
            next = rng_command(s, o, w, scratch, 32 + i * 64, at, end)
        else:
            next = command(s, o, w, 32 + i * 64, at, end)
        if getw(w, 0) == 0 and getw(w, 3968) != 0:
            graph_collect_since(w, getw(w, 8))
        error = getw(w, 0)
        if error != 0:
            putw(o, 24, error)
            return next
        putw(w, getw(w, 96) + i * 8, getw(o, at + 16))
        if (code == 58 or code == 86 or code == 87) and getw(o, at + 16) != 0:
            halted = 1
        at = next
        i = i + 1
        putw(o, 16, i)
    if count != 0:
        fill_range(w, 8192, count * 8, 0)
        putw(w, 96, 0)
        putw(w, 104, 0)
    putw(w, 80, 0)
    if getw(w, 0) != 0:
        reply_error(o, getw(w, 0))
        return 32
    return at

def incoming_describe(w: mutbuf, t: u64, parent: u64, edge: u64) -> u64:
    memory_fill(w, 3808, 88, 0)
    p = dptr(w, t)
    op = getw(w, p + 40)
    putw(w, 3840, parent)
    putw(w, 3848, 2)
    incoming_contiguous_layout(w, parent, 3856)
    if op == 1 or (op == 2 and edge == 0) or op == 17 or ((op == 39 or op == 40) and edge == 0):
        if incoming_same_shape(w, t, parent) != 0:
            return incoming_describe_alias(w, t, getw(w, p + 472), getw(w, p + 488))
        return 1
    if op == 10:
        if incoming_describe_alias(w, t, 2, parent) == 0:
            return 0
        a = getw(w, p + 176)
        b = getw(w, p + 184)
        putw(w, 3856 + a * 8, getw(w, p + 496 + b * 8))
        putw(w, 3856 + b * 8, getw(w, p + 496 + a * 8))
        return 1
    if op == 16:
        if incoming_describe_alias(w, t, 2, parent) == 0:
            return 0
        if incoming_reshape_layout(w, t, parent, 3856) != 0:
            return 1
        putw(w, 3808, 0)
        putw(w, 3816, 0)
        putw(w, 3824, 0)
        putw(w, 3832, 0)
        return incoming_contiguous_layout(w, parent, 3856)
    if op == 7:
        if incoming_describe_alias(w, t, 2, parent) == 0:
            return 0
        j = 0
        while j < getw(w, dptr(w, parent)):
            putw(w, 3856 + j * 8, 0)
            j = j + 1
        return 1
    if op == 37 or op == 38:
        return incoming_describe_cat(w, t, parent, edge)
    if op == 42:
        return native_dropout_grad_layout(w, t, 3856)
    if op == 41:
        return incoming_zero_layout(w, t, 3856)
    if op == 26 or op == 27:
        putw(w, 3888, 1)
        return 1
    if op == 2 or op == 3 or op == 4 or (op == 5) or (op == 6) or (op >= 11 and op <= 15) or (op == 20) or (op == 21) or (op == 22) or (op == 25) or (op == 39) or (op == 40):
        return 1
    putw(w, 3848, 1)
    return 1

def incoming_mark_preserve_targets(w: mutbuf, limit: u64, epoch: u64) -> u64:
    i = 1
    while i <= limit:
        p = dptr(w, i)
        if getw(w, p + 304) != 0 and getw(w, p + 168) == epoch:
            if getw(w, p + 544) != 0 or getw(w, p + 552) != 0 or getw(w, p + 560) != 0 or (getw(w, p + 568) != 0):
                return terror(w, 9)
        i = i + 1
    i = 1
    while i <= limit:
        p = dptr(w, i)
        if getw(w, p + 304) != 0 and getw(w, p + 168) == epoch and (getw(w, p + 40) == 41 or getw(w, p + 40) == 42):
            parent = gradient_parent_at(w, i, 0)
            if parent != 0:
                q = dptr(w, parent)
                if getw(w, q + 304) == 0 or getw(w, q + 168) != epoch:
                    return terror(w, 9)
                putw(w, q + 544, 1)
        i = i + 1
    return 1

def graph_audit(w: mutbuf) -> u64:
    status = 0
    budget = 0
    i = 1
    while i < getw(w, 8) and status == 0:
        p = dptr(w, i)
        if getw(w, p + 304) != 0:
            count = gradient_parent_count(w, i)
            if count > 16777216 - budget:
                status = 3
            else:
                budget = budget + count
                j = 0
                while j < count and status == 0:
                    parent = graph_parent_at(w, i, j)
                    flag = graph_edge_enabled(w, i, j)
                    if flag > 1 or parent >= i:
                        status = 9
                    elif parent != 0:
                        q = dptr(w, parent)
                        if getw(w, q + 304) == 0:
                            status = 9
                        else:
                            putw(w, q + 376, getw(w, q + 376) + 1)
                            if flag != 0 and getw(w, q + 40) == 0:
                                putw(w, q + 368, getw(w, q + 368) + 1)
                    elif flag != 0:
                        status = 9
                    j = j + 1
        i = i + 1
    i = 1
    while i < getw(w, 8):
        p = dptr(w, i)
        if status == 0 and getw(w, p + 304) != 0:
            if getw(w, p + 88) != getw(w, p + 368) or getw(w, p + 208) != getw(w, p + 376) + getw(w, p + 312) + getw(w, p + 400) + getw(w, p + 600):
                status = 9
        putw(w, p + 368, 0)
        putw(w, p + 376, 0)
        i = i + 1
    return status

def tensor_dtype(w:mutbuf, t:u64) -> u64:
    return getw(w,dptr(w,t)+576)

def dtype_width(code:u64) -> u64:
    if code == 0:
        return 4
    if code == 1:
        return 1
    return 0

def valid_f32(w:mutbuf, t:u64) -> u64:
    if valid(w,t) == 0:
        return 0
    if tensor_dtype(w,t) != 0:
        return terror(w,7)
    return 1

def public_f32(w:mutbuf, id:u64) -> u64:
    t = public_node(w,id)
    if t == 0:
        return 0
    if tensor_dtype(w,t) != 0:
        return terror(w,7)
    return t

def typed_load(w:mutbuf, address:u64, width:u64) -> u64:
    address = object_address(w,address)
    value = 0
    i = 0
    while i < width:
        value = value | (byte(w,address+i) << (i*8))
        i = i+1
    return value

def typed_store(w:mutbuf, address:u64, width:u64, value:u64) -> u64:
    address = object_address(w,address)
    i = 0
    while i < width:
        store(w,address+i,value >> (i*8))
        i = i+1
    return 1

def taddr(w:mutbuf, t:u64, index:u64) -> u64:
    p = dptr(w,t)
    axis = getw(w,p)
    offset = 0
    while axis > 0:
        axis = axis-1
        dim = getw(w,p+96+axis*8)
        coordinate = index % dim
        index = index // dim
        offset = offset+coordinate*getw(w,p+128+axis*8)
    return getw(w,p+16)+offset*dtype_width(getw(w,p+576))

def tget(w:mutbuf, t:u64, index:u64) -> u64:
    if valid(w,t) == 0:
        return 0
    p = dptr(w,t)
    if index >= getw(w,p+8):
        return terror(w,7)
    sp = so_storage_live(w,getw(w,p+216))
    if sp == 0:
        return terror(w,1)
    width = dtype_width(getw(w,p+576))
    if width == 0:
        return terror(w,9)
    address = taddr(w,t,index)
    origin = 9223372036854775808+so_uget(w,sp+16)
    offset = address-origin
    if offset > so_uget(w,sp+24) or width > so_uget(w,sp+24)-offset:
        return terror(w,2)
    return typed_load(w,address,width)

def tset(w:mutbuf, t:u64, index:u64, bits:u64) -> u64:
    if valid(w,t) == 0:
        return 0
    p = dptr(w,t)
    code = getw(w,p+576)
    width = dtype_width(code)
    if width == 0:
        return terror(w,9)
    if index >= getw(w,p+8) or bits > 4294967295:
        return terror(w,7)
    if code == 1 and bits > 1:
        return terror(w,7)
    if version_can_bump(w,t,1) == 0:
        return 0
    typed_store(w,taddr(w,t,index),width,bits)
    return bump_version(w,t)

def descriptor(w:mutbuf, rank:u64, shape:u64, requires:u64, own:u64) -> u64:
    return typed_descriptor(w,rank,shape,requires,own,0)

def typed_clone(w:mutbuf, a:u64) -> u64:
    if valid(w,a) == 0:
        return 0
    p = dptr(w,a)
    code = getw(w,p+576)
    t = typed_descriptor(w,getw(w,p),p+96,0,1,code)
    if t == 0:
        return 0
    if dist_dense_layout(w,t,a,1) == 0:
        return 0
    width = dtype_width(code)
    i = 0
    while i < getw(w,p+8):
        typed_store(w,taddr(w,t,i),width,tget(w,a,i))
        i = i+1
    return t

def clone(w:mutbuf, a:u64) -> u64:
    if valid(w,a) == 0:
        return 0
    if tensor_dtype(w,a) == 0:
        return dtype_original_clone(w,a)
    return typed_clone(w,a)

def inspect_command(s:readbuf, o:mutbuf, w:mutbuf, cp:u64, at:u64) -> u64:
    if getr(s,cp) != 13:
        t = public_node(w,getr(s,cp+8))
        if t != 0 and tensor_dtype(w,t) != 0:
            terror(w,7)
    return dtype_original_inspect_command(s,o,w,cp,at)

def saved_logical(w:mutbuf, id:u64, index:u64) -> u64:
    p = public_saved(w,id)
    if p == 0:
        return 0
    layout = private_hold(w,so_uget(w,p+56),128)
    if getw(w,layout+16) != 0:
        return terror(w,7)
    return dtype_original_saved_logical(w,id,index)

def leaf_requires_grad(w:mutbuf, id:u64, requires:u64) -> u64:
    t = public_node(w,id)
    if t == 0:
        return 0
    if requires == 1 and tensor_dtype(w,t) != 0:
        return terror(w,5)
    return dtype_original_leaf_requires_grad(w,id,requires)

def dtype_mask_retain(w:mutbuf, t:u64, mask:u64) -> u64:
    p = dptr(w,t)
    q = dptr(w,mask)
    if getw(w,p+584) != 0 or getw(w,p+592) != 0:
        return terror(w,9)
    if getw(w,q+600) >= 4294967295:
        return terror(w,8)
    if node_retain(w,mask) == 0:
        return 0
    putw(w,q+600,getw(w,q+600)+1)
    putw(w,p+584,mask)
    putw(w,p+592,getw(w,q+320))
    return 1

def dtype_mask_node(w:mutbuf, t:u64) -> u64:
    p = dptr(w,t)
    mask = getw(w,p+584)
    q = private_tensor(w,mask,getw(w,p+592))
    if q == 0 or getw(w,q+600) == 0:
        return terror(w,9)
    return mask

def dtype_mask_release(w:mutbuf, t:u64) -> u64:
    p = dptr(w,t)
    mask = getw(w,p+584)
    if mask == 0:
        if getw(w,p+592) != 0:
            return terror(w,9)
        return 1
    q = private_tensor(w,mask,getw(w,p+592))
    if q == 0 or getw(w,q+600) == 0:
        return terror(w,9)
    putw(w,p+584,0)
    putw(w,p+592,0)
    putw(w,q+600,getw(w,q+600)-1)
    return node_release(w,mask)

def gradient_gc_enqueue(w:mutbuf, t:u64) -> u64:
    if t != 0 and getw(w,dptr(w,t)+600) != 0:
        return 1
    return dtype_original_gradient_gc_enqueue(w,t)

def tensor_row_release(w:mutbuf, t:u64) -> u64:
    if getw(w,dptr(w,t)+600) != 0:
        return 1
    return dtype_original_tensor_row_release(w,t)

def graph_node_release(w:mutbuf, t:u64) -> u64:
    if getw(w,dptr(w,t)+600) != 0:
        return terror(w,9)
    if dtype_mask_release(w,t) == 0:
        return 0
    return dtype_original_graph_node_release(w,t)

def release_backward_saved(w:mutbuf, t:u64) -> u64:
    if dtype_original_release_backward_saved(w,t) == 0:
        return 0
    return dtype_mask_release(w,t)

def dtype_audit(w:mutbuf) -> u64:
    status = 0
    i = 1
    while i < getw(w,8):
        p = dptr(w,i)
        if getw(w,p+616) != 0 or getw(w,p+624) != 0 or getw(w,p+632) != 0:
            status = 9
        i = i+1
    i = 1
    while i < getw(w,8) and status == 0:
        p = dptr(w,i)
        if getw(w,p+304) != 0:
            code = getw(w,p+576)
            if code > 1 or getw(w,p+608) != 0:
                status = 9
            if code == 1 and (getw(w,p+32) != 0 or getw(w,p+384) != 0):
                status = 9
            mask = getw(w,p+584)
            if mask != 0:
                q = private_tensor(w,mask,getw(w,p+592))
                if q == 0 or getw(w,p+40) != 42 or getw(w,p+288) == 0:
                    status = 9
                else:
                    saved = so_saved_live(w,getw(w,p+288))
                    if saved == 0:
                        status = 9
                    else:
                        if so_uget(w,saved+16) != getw(w,q+216) or so_uget(w,saved+24) != getw(w,q+224):
                            status = 9
                    putw(w,q+616,getw(w,q+616)+1)
            elif getw(w,p+592) != 0:
                status = 9
        elif getw(w,p+584) != 0 or getw(w,p+592) != 0 or getw(w,p+600) != 0:
            status = 9
        i = i+1
    i = 1
    while i < getw(w,8):
        p = dptr(w,i)
        if getw(w,p+600) != getw(w,p+616):
            status = 9
        putw(w,p+616,0)
        i = i+1
    return status

def gradient_audit(w:mutbuf) -> u64:
    if dtype_audit(w) != 0:
        return 9
    return dtype_original_gradient_audit(w)

def typed_fill(w:mutbuf, t:u64, bits:u64, no_grad:u64) -> u64:
    if valid(w,t) == 0:
        return 0
    p = dptr(w,t)
    code = getw(w,p+576)
    width = dtype_width(code)
    if width == 0 or no_grad > 1 or bits > 4294967295:
        return terror(w,7)
    if code == 1 and bits > 1:
        return terror(w,7)
    if no_grad == 0 and getw(w,p+32) != 0:
        return terror(w,5)
    if version_can_bump(w,t,1) == 0:
        return 0
    i = 0
    while i < getw(w,p+8):
        typed_store(w,taddr(w,t,i),width,bits)
        i = i+1
    return bump_version(w,t)

def typed_from_wire(s:readbuf, w:mutbuf, dtype:u64, config:u64, end:u64) -> u64:
    width = dtype_width(dtype)
    if width == 0:
        return terror(w,7)
    if config < end or config > length(s) or 64 > length(s)-config or (config & 7) != 0:
        return terror(w,100)
    rank = getr(s,config)
    requires = getr(s,config+8)
    if rank > 4 or requires > 1:
        return terror(w,2)
    if dtype == 1 and requires != 0:
        return terror(w,5)
    axis = 0
    n = 1
    while axis < 4:
        dim = getr(s,config+16+axis*8)
        if axis >= rank:
            if dim != 0:
                return terror(w,2)
        else:
            if dim > 262144:
                return terror(w,3)
            if dim == 0:
                n = 0
        putw(w,2048+axis*8,dim)
        axis = axis+1
    if n != 0:
        axis = 0
        while axis < rank:
            n = n*getw(w,2048+axis*8)
            if n > 16777216:
                return terror(w,3)
            axis = axis+1
    data = getr(s,config+48)
    size = getr(s,config+56)
    if size != n*width or data < end or data > length(s) or size > length(s)-data:
        return terror(w,100)
    if dtype == 1:
        i = 0
        while i < size:
            if byte(s,data+i) > 1:
                return terror(w,7)
            i = i+1
    t = typed_descriptor(w,rank,2048,requires,1,dtype)
    if t == 0:
        return 0
    address = object_address(w,getw(w,dptr(w,t)+16))
    copy_range(w,s,address,data,size)
    return t

def typed_command(s:readbuf, o:mutbuf, w:mutbuf, scratch:mutbuf, cp:u64, at:u64, end:u64) -> u64:
    code = getr(s,cp)
    a = getr(s,cp+8)
    b = getr(s,cp+16)
    c = getr(s,cp+24)
    d = getr(s,cp+32)
    result = 0
    payload = 0
    first = getw(w,8)
    if code < 96 or code > 100:
        terror(w,4)
    if getr(s,cp+40) != 0 or getr(s,cp+48) != 0 or getr(s,cp+56) != 0:
        terror(w,7)
    if code != 99 and d != 0:
        terror(w,7)
    if (code == 96 or code == 97) and c != 0:
        terror(w,7)
    if getw(w,0) == 0:
        if code == 97:
            result = typed_from_wire(s,w,a,b,end)
            if getw(w,0) == 0:
                result = publish_tensor(w,result)
        else:
            t = public_node(w,a)
            if t != 0:
                if code == 96:
                    if b == 0:
                        if at+32 > length(o) or 32 > length(o)-at-32:
                            terror(w,3)
                        else:
                            p = dptr(w,t)
                            result = getw(w,p+576)
                            putw(o,at+32,result)
                            putw(o,at+40,dtype_width(result))
                            putw(o,at+48,getw(w,p+320))
                            putw(o,at+56,choose(getw(w,p+40) == 0,1,0))
                            payload = 32
                    elif b == 1:
                        result = native_dropout_saved_mask(w,t)
                        if getw(w,0) == 0:
                            result = publish_tensor(w,result)
                    else:
                        terror(w,7)
                if code == 98:
                    p = dptr(w,t)
                    n = getw(w,p+8)
                    width = dtype_width(getw(w,p+576))
                    if b > n or c > n-b:
                        terror(w,2)
                    elif c > (length(o)-at-32)//width:
                        terror(w,3)
                    else:
                        j = 0
                        while j < c:
                            typed_store(o,at+32+j*width,width,tget(w,t,b+j))
                            j = j+1
                        result = c
                        payload = c*width
                if code == 99:
                    if length(o)-at-32 < 8:
                        terror(w,3)
                    else:
                        result = native_dropout(w,scratch,t,b,c,d,at+32,o)
                        if getw(w,0) == 0:
                            result = publish_tensor(w,result)
                            payload = 8
                if code == 100:
                    result = typed_fill(w,t,b,c)
    if getw(w,0) == 0:
        finish_command(w,first)
    status = getw(w,0)
    if status != 0:
        result = 0
        payload = 0
    putw(o,at,code)
    putw(o,at+8,status)
    putw(o,at+16,result)
    putw(o,at+24,payload)
    return at+32+payload


def native_dropout_scale(complement:u64) -> u64:
    if complement == 0:
        return 0
    significand = (complement & 4503599627370495) | 4503599627370496
    exponent = complement >> 52
    remainder = 0
    quotient = 0
    bit_index = 106
    while bit_index > 0:
        bit_index = bit_index-1
        remainder = remainder << 1
        if bit_index == 105:
            remainder = remainder | 1
        quotient = quotient << 1
        if remainder >= significand:
            remainder = remainder-significand
            quotient = quotient | 1
    doubled = remainder << 1
    if doubled > significand or (doubled == significand and (quotient & 1) != 0):
        quotient = quotient+1
    result_exponent = 2045-exponent
    if quotient == 9007199254740992:
        quotient = quotient >> 1
        result_exponent = result_exponent+1
    reciprocal = (result_exponent << 52) | (quotient & 4503599627370495)
    return dist_probability_to32(reciprocal)

def typed_iteration_address(w:mutbuf, p:u64, order:u64, index:u64) -> u64:
    offset = 0
    i = 0
    while i < getw(w,p):
        axis = (order >> (i*8)) & 255
        size = getw(w,p+96+axis*8)
        coordinate = index % size
        index = index // size
        offset = offset+coordinate*getw(w,p+128+axis*8)
        i = i+1
    return getw(w,p+16)+offset*dtype_width(getw(w,p+576))

def native_dropout_fill_mask(w:mutbuf, scratch:mutbuf, mask:u64, data:u64, probability:u64, training:u64) -> u64:
    p = dptr(w,mask)
    if training == 0:
        memory_fill(w,getw(w,p+16),getw(w,p+8),1)
        return 1
    if rng_load_scratch(w,scratch,data) == 0:
        return 0
    order = rng_axis_order(w,p)
    i = 0
    while i < getw(w,p+8):
        unit = rng_unit64(rng_next64(scratch))
        value = choose(unit < probability,1,0)
        typed_store(w,typed_iteration_address(w,p,order,i),1,value)
        i = i+1
    return rng_save_scratch(w,scratch,data)

def native_dropout_write(w:mutbuf, output:u64, input:u64, mask:u64, scale:u64, training:u64) -> u64:
    p = dptr(w,output)
    i = 0
    while i < getw(w,p+8):
        value = tget(w,input,i)
        if training != 0:
            coefficient = choose(tget(w,mask,i) != 0,1065353216,0)
            value = mulf(mulf(value,coefficient),scale)
        put4(w,taddr(w,output,i),value)
        i = i+1
    return 1

def native_dropout_record(w:mutbuf, output:u64, input:u64, mask:u64, scale:u64) -> u64:
    if record(w,output,42,input,0) == 0:
        return 0
    p = dptr(w,output)
    if getw(w,p+32) != 0:
        saved = saved_create(w,mask,0)
        if saved == 0:
            return 0
        putw(w,p+288,saved)
        putw(w,p+176,scale)
        if dtype_mask_retain(w,output,mask) == 0:
            return 0
    return output

def native_dropout(w:mutbuf, scratch:mutbuf, input:u64, generator:u64, probability:u64, training:u64, mask_out:u64, o:mutbuf) -> u64:
    if valid_f32(w,input) == 0:
        return 0
    data = rng_object(w,generator)
    if data == 0:
        return 0
    if training > 2:
        return terror(w,7)
    p = dptr(w,input)
    n = getw(w,p+8)
    if n == 0:
        if getw(w,p+32) != 0:
            return terror(w,5)
        mask = typed_descriptor(w,getw(w,p),p+96,0,1,0)
        if mask == 0:
            return 0
        dist_dense_layout(w,mask,input,1)
        putw(o,mask_out,publish_tensor(w,mask))
        return input
    if n > 1000000:
        return terror(w,3)
    complement = 0
    scale = 1065353216
    if training != 0:
        if dist_prob64_valid(probability) == 0:
            return terror(w,7)
        complement = dist_complement64(probability)
        scale = native_dropout_scale(complement)
    mask = typed_descriptor(w,getw(w,p),p+96,0,1,1)
    if mask == 0:
        return 0
    if dist_dense_layout(w,mask,input,1) == 0:
        return 0
    output = descriptor(w,getw(w,p),p+96,getw(w,p+32),1)
    if output == 0:
        return 0
    if dist_dense_layout(w,output,input,1) == 0:
        return 0
    if native_dropout_fill_mask(w,scratch,mask,data,complement,training) == 0:
        return 0
    native_dropout_write(w,output,input,mask,scale,training)
    backward_scale = scale
    if training != 1:
        backward_scale = 1065353216
    if native_dropout_record(w,output,input,mask,backward_scale) == 0:
        return 0
    putw(o,mask_out,publish_tensor(w,mask))
    return output

def native_dropout_saved_mask(w:mutbuf, t:u64) -> u64:
    p = dptr(w,t)
    if getw(w,p+40) != 42:
        return terror(w,5)
    if getw(w,p+328) != 0:
        return terror(w,10)
    if graph_saved_check(w,getw(w,p+288)) == 0:
        return 0
    return dtype_mask_node(w,t)

def native_dropout_backward(w:mutbuf, t:u64) -> u64:
    p = dptr(w,t)
    parent = gradient_parent_at(w,t,0)
    if parent == 0:
        return 1
    mask = dtype_mask_node(w,t)
    if mask == 0:
        return 0
    scale = getw(w,p+176)
    i = 0
    while i < getw(w,p+8):
        grad = get4(w,getw(w,p+160)+i*4)
        coefficient = choose(tget(w,mask,i) != 0,1065353216,0)
        value = mulf(mulf(grad,coefficient),scale)
        gadd(w,parent,i,value)
        i = i+1
    return 1

def partial_apply_node(w:mutbuf, t:u64) -> u64:
    if getw(w,dptr(w,t)+40) == 42:
        return native_dropout_backward(w,t)
    return dtype_original_partial_apply_node(w,t)

def native_dropout_compare_axes(w:mutbuf, p:u64, q:u64, left:u64, right:u64) -> u64:
    operand = 0
    while operand < 2:
        layout = p+496
        if operand == 1:
            layout = q+128
        ls = getw(w,layout+left*8) << 2
        rs = getw(w,layout+right*8) << 2
        if ls != 0 and rs != 0:
            ordered_left = ls ^ 9223372036854775808
            ordered_right = rs ^ 9223372036854775808
            if ordered_left < ordered_right:
                return 1
            if ordered_left > ordered_right:
                return 2
            if getw(w,p+96+left*8) > getw(w,p+96+right*8):
                return 2
        operand = operand+1
    return 0

def native_dropout_axis_order(w:mutbuf, p:u64, q:u64) -> u64:
    rank = getw(w,p)
    perm = 0
    i = 0
    while i < rank:
        perm = perm | ((rank-i-1) << (i*8))
        i = i+1
    i = 1
    while i < rank:
        anchor = i
        j = i
        done = 0
        while j > 0 and done == 0:
            j = j-1
            left = (perm >> (j*8)) & 255
            right = (perm >> (anchor*8)) & 255
            comparison = native_dropout_compare_axes(w,p,q,left,right)
            if comparison == 2:
                difference = left ^ right
                perm = perm ^ (difference << (j*8)) ^ (difference << (anchor*8))
                anchor = j
            if comparison == 1:
                done = 1
        i = i+1
    return perm

def native_dropout_grad_layout(w:mutbuf, t:u64, dest:u64) -> u64:
    p = dptr(w,t)
    mask = dtype_mask_node(w,t)
    if mask == 0:
        return 0
    q = dptr(w,mask)
    if incoming_dense(w,t,p+496) != 0 and is_dense(w,mask) != 0:
        same = 1
        j = 0
        while j < getw(w,p):
            if getw(w,p+496+j*8) != getw(w,q+128+j*8):
                same = 0
            j = j+1
        if same != 0:
            j = 0
            while j < 4:
                putw(w,dest+j*8,getw(w,p+496+j*8))
                j = j+1
            return 1
    if incoming_contiguous(w,t,p+496) != 0 and is_contiguous(w,mask) != 0:
        return incoming_contiguous_layout(w,t,dest)
    order = native_dropout_axis_order(w,p,q)
    stride = 1
    j = 0
    while j < getw(w,p):
        axis = (order >> (j*8)) & 255
        putw(w,dest+axis*8,stride)
        stride = stride*getw(w,p+96+axis*8)
        j = j+1
    return 1

def dtype_backward_admit(w:mutbuf, t:u64, seed:u64) -> u64:
    if valid(w,t) == 0:
        return 0
    if tensor_dtype(w,t) != 0:
        return terror(w,5)
    if seed != 0:
        if valid(w,seed) == 0:
            return 0
        if tensor_dtype(w,seed) != tensor_dtype(w,t):
            return terror(w,2)
    return 1

def backward_execute(w:mutbuf, t:u64, seed:u64, retain:u64) -> u64:
    if dtype_backward_admit(w,t,seed) == 0:
        return 0
    return dtype_original_backward_execute(w,t,seed,retain)

def partial_admit(w:mutbuf, t:u64, seed:u64) -> u64:
    if dtype_backward_admit(w,t,seed) == 0:
        return 0
    return dtype_original_partial_admit(w,t,seed)
