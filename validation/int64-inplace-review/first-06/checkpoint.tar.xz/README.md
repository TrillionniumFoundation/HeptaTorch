# Int64 inplace40: actual reference and preserved candidate06 failures

The pinned real PyTorch process observed 40 operations: 20 accepted, 20 raised, zero probe errors, and all eleven provenance checks passed. The immutable report SHA-256 is `107188393d611c7b53df948c9404a4aca6550f9dc94b91499cdc5fff559c5475`.

The independent native replay executed candidate06 and passed 37 of 40 cases. Cases 14 and 15 rejected accepted interleaved/strided shared-Storage writes. Case 36 reported a cast status before the actual internal-overlap status. All original failures, raw sessions, before/after owned byte archives, compiler-produced image/source inputs, stdout/stderr, requests and complete source/reference identities are preserved. No expected value is produced by a Python Tensor evaluator.

Native exception status categories are qualified here; the Python exception text/class frontend is not implemented or claimed. The original reference contains every actual message. Strong observer roots remain alive in this reference; it makes no weak-lifetime claim. Subsequent candidates must execute this unchanged reader against the fixed reference and their own explicit source/image SHA-256 pins.

## Restore and replay

Extract the checkpoint into a new directory after checking its complete manifest, all member sizes/SHA-256/modes and single XZ EOF. Inside that directory use:

```sh
python3 -B replay_inplace40.py --binary fixed-native-inputs/tensor-integer-session --source fixed-native-inputs/runtime.hepta --protocol fixed-native-inputs/protocol.py --observer fixed-native-inputs/native_observer.py --reference remote/torch-int64-inplace-reference.json --output NEW_OUTPUT --expected-source-sha256 46cba6e9951de45374f4ba0a7567811cd9e03a16db0e5b9e67ba7512559b9bb3 --expected-native-sha256 b701b4c0b6f82f928150a9ed33f8805d0783fc652ca3d9f1c3d5f9ad19478bdd
```

This reproduces the preserved candidate06 result, including its three failures. The whole 2590-schema PyTorch rewrite remains HOLD.
