#!/usr/bin/env python3
"""Emit a source-only combined native Tensor/Generator runtime candidate.

This program never invokes a compiler, linker, runtime, Torch or remote job.
It preserves all701 current core bodies and12 original core units, adds the
original11 Generator HIA model bodies with one reversible raw-writer binding,
and delegates from a new four-argument native owner entry to both original
owners. Actual compilation and qualification remain separately required.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import stat
import types

HERE = Path(__file__).resolve().parent
SOURCE = '82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313'
MANIFEST = '63db93823ff79b3f68d69a276ae2eebc7e7718618c188c387b758c5c3ed97a47'
BUILDER = 'b9d039c365a8a3988e3add120e8cffa46a4e1297878f4cced30103953b030bfb'
INSPECTOR = '71b72260014417db72ffcebd80c86543e257c80d76cdd6c878b41feaa117cf92'
RNG = 'a3fa507339b40435285dc1fa65e3cd519b6a0921a4c93bccf6ea834bb24763a3'
OWNERS = '9c02b75c44eee8459c476049f4d9ebe10935d9d9ed8b27f5842c699f8e6a0884'
CG_MODEL = 'dbae4d899b8a962716b23119980fe5da22e1c269c4b3efc8fb162a9166eee3ec'
CG_OWNERS = '09783363390a6bce3dd8e69d3650478e8b16f37348e81204d0dabf2f58e8b5d2'
CG_RNG = 'd0e6f2ff5da90e2f0891ddcd12fc4fff33594423d49538d79f08662ede017e7c'
TENSOR_LINKER = 'aae650e8822ef0b1e74d15108ad1d0f17ec791205ed5a158ec60b709f48f0e16'
ENTROPY_LINKER = '761a941fd7a2d53eb9b45869fcfc20e970640e9dd11d60f7c61a89812b61d74e'
RAW_WRITER_ALIAS = b'''fn cg_putw(raw0:mutbuf,at0:u64,value0:u64) -> (u64) effects(read,write,trap) entry(b0)
block b0(raw0:mutbuf,at0:u64,value0:u64)
  result0:u64 = call(raw0,at0,value0) {"function":"putw"}
  ret(result0)
end
'''


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def rename_function(raw, old, new):
    before, after = ('fn '+old+'(').encode(), ('fn '+new+'(').encode()
    need(raw.count(before) == 1 and after not in raw, 'function rename count')
    changed = raw.replace(before, after)
    need(changed.replace(after, before) == raw, 'function rename inverse')
    return changed


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repository', type=Path, required=True)
    ap.add_argument('--baseline-source-root', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    repo, baseline, out = args.repository.resolve(strict=True), args.baseline_source_root.resolve(strict=True), args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    inputs = {}

    def bind(path, expected=None):
        path = Path(path).resolve(strict=True)
        raw = path.read_bytes()
        need(expected is None or sha(raw) == expected, 'input SHA: '+str(path))
        row = {'bytes': len(raw), 'sha256': sha(raw), 'mode': stat.S_IMODE(path.stat().st_mode)}
        need(str(path) not in inputs or inputs[str(path)] == row, 'input changed: '+str(path))
        inputs[str(path)] = row
        return raw

    def write(relative, raw):
        path = out / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        return path

    bind(Path(__file__))
    template = bind(HERE / 'dispatch.hepta.in')
    old_builder = bind(repo / 'tools/current_runtime/build.py', BUILDER)
    builder = types.ModuleType('frozen_current_builder_source_only')
    builder.__file__ = str(repo / 'tools/current_runtime/build.py')
    exec(compile(old_builder, builder.__file__, 'exec'), builder.__dict__)
    old_manifest_raw = bind(baseline / 'manifest.json', MANIFEST)
    old_manifest = json.loads(old_manifest_raw, object_pairs_hook=builder.unique_object)
    original, original_units, original_summary = builder.check_sources(old_manifest, baseline, bind)
    need(sha(original) == SOURCE and original_summary['functions'] == 701
         and len(original_units) == 14, 'exact original cat-fixed701 source/partition required')
    original_core = builder.parse_source(original)
    originals = {entry['name']: (entry, raw, parsed) for entry, raw, parsed in original_units}
    old_rng, old_owners = originals['rng03'][1], originals['owners'][1]
    need(sha(old_rng) == RNG and sha(old_owners) == OWNERS, 'exact current support units required')

    cg_model = bind(repo / 'tools/cpu_generators/sources/model.hepta', CG_MODEL)
    cg_owners = bind(repo / 'tools/cpu_generators/sources/owners.hepta', CG_OWNERS)
    cg_rng = bind(repo / 'tools/cpu_generators/sources/rng.hepta', CG_RNG)
    generator_model = builder.parse_source(cg_model, unit=True)
    generator_owners = builder.parse_source(cg_owners, unit=True)
    generator_rng = builder.parse_source(cg_rng, unit=True)
    current_rng = originals['rng03'][2]
    need(generator_rng['definitions'] == current_rng['definitions']
         and len(current_rng['definitions']) == 17, 'all17 RNG bodies must be exact')
    need(original_core['definitions']['getr'] == current_rng['definitions']['getr'],
         'model raw read helper must remain exact')
    need(original_core['definitions']['putw'] != current_rng['definitions']['putw'],
         'explicit raw write alias must not be dropped through a current tagged helper')
    need(len(generator_model['definitions']) == 11
         and not (generator_model['definitions'].keys() & original_core['definitions'].keys()),
         'eleven separate cg_* model functions required')

    # Keep every old RNG body; export the two original rounding helpers and one
    # new alias that calls this unit's private original raw writer.
    old_export = old_rng.splitlines(keepends=True)[1]
    rng_export = b'exports(' + ','.join(current_rng['exports'] + ['round_f16', 'round_bf16', 'cg_putw']).encode() + b')\n'
    need(old_rng.count(old_export) == 1, 'one original RNG export header')
    new_rng = old_rng.replace(old_export, rng_export) + RAW_WRITER_ALIAS
    need(new_rng.removesuffix(RAW_WRITER_ALIAS).replace(rng_export, old_export) == old_rng,
         'entire RNG support-unit inverse')

    # Only change the raw writer's binding, not arithmetic, bounds, state bytes
    # or owner/error algorithms. A tagged Tensor address helper is not reused.
    writer_occurrences = len(re.findall(rb'\bputw\b', cg_model))
    need(writer_occurrences > 1 and b'cg_putw' not in cg_model, 'original model raw-writer sites')
    new_cg_model = re.sub(rb'\bputw\b', b'cg_putw', cg_model)
    need(re.sub(rb'\bcg_putw\b', b'putw', new_cg_model) == cg_model,
         'complete original Generator model inverse')
    new_model = builder.parse_source(new_cg_model, unit=True)
    new_core_header = b'hia-asm.v1 hepta.hia.program.v8 tensor_generator_complete01\n'
    old_core_header, core_tail = original.split(b'\n', 1)
    appended = b''.join(new_model['definitions'].values())
    runtime = new_core_header + core_tail + appended
    need(old_core_header+b'\n'+runtime[len(new_core_header):].removesuffix(appended) == original,
         'entire original701 source inverse')
    parsed_runtime = builder.parse_source(runtime)
    need(len(parsed_runtime['definitions']) == 712
         and all(parsed_runtime['definitions'][name] == body
                 for name, body in original_core['definitions'].items()),
         'all701 original core function bodies must stay byte-identical')

    dispatch = template
    for key, value in [('CG_STATE_MAGIC', b'HTCGST01'), ('TENSOR_STATE_MAGIC', b'HTSINT02'),
                       ('TENSOR_BACKING_MAGIC', b'HTOSIN02'), ('CG_REQUEST_MAGIC', b'HTCGEN01')]:
        need(dispatch.count(key.encode()) == 1, 'dispatch placeholder count: '+key)
        dispatch = dispatch.replace(key.encode(), str(int.from_bytes(value, 'little')).encode())
    old_owner_parsed = originals['owners'][2]
    need(old_owner_parsed['definitions']['close'] == generator_owners['definitions']['close'],
         'the single original close implementation must be byte-identical')
    renamed_tensor = rename_function(old_owners, 'step', 'tensor_step')
    cg_error = generator_owners['definitions']['cg_error']
    cg_step = rename_function(generator_owners['definitions']['step'], 'step', 'generator_step')
    # Preserve all original Tensor external declarations/order; add the exact
    # original Generator externals and the proven raw getr declaration.
    existing_imports = set(old_owner_parsed['imports'])
    additional = []
    for match in builder.HEADER.finditer(cg_owners):
        name = match[1].decode()
        if match[5] == b'external()' and name not in existing_imports:
            additional.append(match[0]); existing_imports.add(name)
    getr = next(m[0] for m in builder.HEADER.finditer(cg_model)
                if m[1] == b'getr' and m[5] == b'external()')
    need('getr' not in existing_imports, 'dispatch getr was not expected in old Tensor owner')
    additional.append(getr)
    extra_imports = b''.join(additional)
    owner_header, owner_exports, owner_tail = renamed_tensor.split(b'\n', 2)
    new_owner_header = b'hia-asm.v1 hepta.hia.program.v8 tensor_generator_owners01'
    new_owners = new_owner_header+b'\n'+owner_exports+b'\n'+extra_imports+owner_tail+cg_error+cg_step+dispatch
    suffix = cg_error+cg_step+dispatch
    owner_inverse = new_owners.removesuffix(suffix).replace(extra_imports, b'', 1)
    owner_inverse = owner_inverse.replace(new_owner_header, owner_header, 1)
    owner_inverse = rename_function(owner_inverse, 'tensor_step', 'step')
    need(owner_inverse == old_owners, 'entire original Tensor owner source inverse')
    new_owner_parsed = builder.parse_source(new_owners, unit=True)
    need(len(new_owner_parsed['definitions']) == 10, 'expected ten owner functions')
    need(new_owner_parsed['signatures']['step'][0] == (b'readbuf', b'mutbuf', b'buffer', b'readbuf')
         and new_owner_parsed['signatures']['close'] == old_owner_parsed['signatures']['close'],
         'real four-argument trusted-entropy ABI and original close are required')
    need(rename_function(new_owner_parsed['definitions']['generator_step'], 'generator_step', 'step')
         == generator_owners['definitions']['step'], 'entire original Generator step inverse')

    manifest = {'schema': old_manifest['schema'], 'name': 'tensor-generator-native01',
                'runtime': {'path': 'runtime.hepta', 'sha256': sha(runtime),
                            **{key: parsed_runtime[key] for key in ('functions', 'blocks', 'instructions')}},
                'units': []}
    write('source/runtime.hepta', runtime)
    unchanged_units = []
    for entry, raw, parsed in original_units[:-1]:
        if entry['name'] == 'rng03': raw = new_rng
        else: unchanged_units.append({'name': entry['name'], 'sha256': sha(raw)})
        name = entry['name']; path = 'units/'+name+'.hepta'
        write('source/'+path, raw)
        manifest['units'].append({'name': name, 'path': path, 'sha256': sha(raw)})
    for name, raw in [('cg_model', new_cg_model), ('owners', new_owners)]:
        path = 'units/'+name+'.hepta'; write('source/'+path, raw)
        manifest['units'].append({'name': name, 'path': path, 'sha256': sha(raw)})
    need(len(manifest['units']) == 15 and len(unchanged_units) == 12, 'new model has one separate unit')
    save(out/'source/manifest.json', manifest)

    builder_edits = [(TENSOR_LINKER.encode(), ENTROPY_LINKER.encode()),
                     (RNG.encode(), sha(new_rng).encode()), (OWNERS.encode(), sha(new_owners).encode()),
                     (b'b"HIASTKS1"', b'b"HIACGS01"')]
    new_builder = old_builder
    for before, after in builder_edits:
        need(new_builder.count(before) == 1 and after not in new_builder, 'builder identity edit count')
        new_builder = new_builder.replace(before, after)
    builder_inverse = new_builder
    for before, after in reversed(builder_edits):
        need(builder_inverse.count(after) == 1, 'builder inverse count')
        builder_inverse = builder_inverse.replace(after, before)
    need(builder_inverse == old_builder, 'whole builder inverse; no predicate weakened')
    builder_path = write('tools/current_runtime/build.py', new_builder)
    write('tools/stack_budget/inspect_stack.py', bind(repo/'tools/stack_budget/inspect_stack.py', INSPECTOR))
    write('authoring/emit.py', Path(__file__).read_bytes())
    write('authoring/dispatch.hepta.in', template)
    candidate_builder = types.ModuleType('generator_native_candidate_source_only_builder')
    candidate_builder.__file__ = str(builder_path)
    exec(compile(new_builder, str(builder_path), 'exec'), candidate_builder.__dict__)
    check_exit = candidate_builder.main(['--manifest', str(out/'source/manifest.json'),
                                        '--source-root', str(out/'source'), '--check-only',
                                        '--output', str(out/'source-check')])
    need(check_exit == 0, 'pure complete-source/unit/import check failed')
    checked = json.loads((out/'source-check/build.json').read_bytes())
    need(not checked['processes'] and not checked['result_executable_executed']
         and not checked['torch_executed'], 'source authoring must not execute any native tool')
    after = {}
    for name, expected in inputs.items():
        p = Path(name); raw = p.read_bytes()
        after[name] = {'bytes': len(raw), 'sha256': sha(raw), 'mode': stat.S_IMODE(p.stat().st_mode)} == expected
    need(all(after.values()), 'source input changed during emission')
    transition = {'schema': 'heptatorch.tensor-generator-native.source-transition.v1',
        'status': 'SOURCE_ONLY_NOT_COMPILED_NOT_EXECUTED', 'compiler_executed': False,
        'linker_executed': False, 'native_executed': False, 'Torch_executed': False,
        'original_source_sha256': SOURCE, 'candidate_source_sha256': sha(runtime),
        'original_core_functions': 701, 'candidate_core_functions': 712,
        'all701_original_complete_bodies_byte_identical': True,
        'whole701_source_inverse_exact': True, 'units': 15, 'old_core_units_byte_identical': unchanged_units,
        'generator_model': {'original_sha256': CG_MODEL, 'candidate_sha256': sha(new_cg_model),
            'functions': list(new_model['definitions']), 'whole_file_inverse_exact': True,
            'only_changes': 'raw helper identifier putw -> cg_putw',
            'raw_helper_identifier_occurrences': writer_occurrences,
            'expectations_or_numeric_algorithms_changed': False},
        'rng': {'original_sha256': RNG, 'candidate_sha256': sha(new_rng),
            'all17_original_bodies_byte_identical': True, 'whole_file_inverse_exact': True,
            'added_function': 'cg_putw', 'added_exports': ['round_f16','round_bf16','cg_putw'],
            'raw_writer_alias_sha256': sha(RAW_WRITER_ALIAS)},
        'owners': {'original_tensor_sha256': OWNERS, 'original_generator_sha256': CG_OWNERS,
            'candidate_sha256': sha(new_owners), 'whole_original_tensor_inverse_exact': True,
            'original_tensor_step_rename_only': True, 'original_generator_step_rename_only': True,
            'original_generator_error_unchanged': True, 'single_original_close_byte_identical': True,
            'new_dispatch_sha256': sha(dispatch), 'functions': list(new_owner_parsed['definitions']),
            'allocation_or_rollback_logic_changed': False,
            'mode_selection': 'Empty owner may start either native protocol. Recognized nonempty CG state at0 or Tensor state64/backing139264 selects its original validator regardless of request. Nonempty short/unknown state always takes explicit refusal-only functions; request chooses error formatting and validation priority, never an application step. No state is replaced by the dispatcher.'},
        'builder': {'original_sha256': BUILDER, 'candidate_sha256': sha(new_builder),
            'whole_file_inverse_exact': True, 'only_changes': ['linker SHA','rng support SHA','owner support SHA','HIACGS01 link request'],
            'entropy_linker_sha256': ENTROPY_LINKER, 'compiler_sha256': candidate_builder.COMPILER,
            'limits_unchanged': candidate_builder.LIMITS == builder.LIMITS},
        'source_check_report_sha256': sha((out/'source-check/build.json').read_bytes()),
        'inputs': inputs, 'all_inputs_unchanged': True, 'input_checks_after': after,
        'original513_runtime_pass_transferred': False, 'generator24_pass_transferred': False,
        'generator11_and59_pass_transferred': False, 'full_pytorch_rewrite_complete': False}
    save(out/'transition.json', transition)
    print(json.dumps({k: transition[k] for k in ('status','candidate_source_sha256','candidate_core_functions','units','all_inputs_unchanged')}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
