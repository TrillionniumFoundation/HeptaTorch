# Tensor and Generator native source candidate

This is a source candidate, not a runtime qualification. Pure source validation
completed with 712 core functions and 15 units. No HIA compiler, linker, native
application, Torch, remote process or Git write was invoked by its author.

The baseline is the cat-fixed 701-function source
`82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313`.
The candidate complete source is
`fac3d413c6c0f6874d224cbea312108ee2c8baa027102d41890d85094a5faa38`.
`transition.json` records the complete byte inverses and all physical input
identities. No baseline PASS is transferred to this new source, support units,
four-argument entry, startup or future executable.

## Exact implementation boundary

All 701 original core function bodies and all 12 original core partition files
are unchanged. Eleven original `cg_*` functions are added in their own unit.
Their only change is the raw writer name `putw` to `cg_putw`, checked with a
whole-file inverse to the original Generator model. The new `cg_putw` is a thin
alias inside the shared RNG unit, calling that unit's original private raw
writer. This binding matters: the current Tensor core's `putw` performs tagged
address translation and is not byte-identical to the original raw RNG writer.
The raw `getr` bodies are identical. No arithmetic, random-state transition,
range, numerical expectation, epoch, handle or compact owner equation is
implemented in Python.

All 17 original RNG bodies remain byte-identical. The additional exports are
the original `round_f16`, original `round_bf16`, and the new `cg_putw` alias.
The original Tensor `step` is renamed to `tensor_step`; the original Generator
`step` is renamed to `generator_step`. The original Generator `cg_error` is
unchanged. Both originals had a byte-identical `close(buffer)` implementation;
there is one copy and one startup-owned state slot.

The new four-argument `step(readbuf, mutbuf, buffer, readbuf)` selects the owner
family. Its only additional helpers are `mux_request_kind`,
`mux_refuse_generator` and `mux_refuse_tensor`. These new dispatch/refusal
functions contain no allocation, owner drop, application commit or state write.
Every borrowed state view ends before its owned buffer is transferred onward.

## State and request dispatch matrix

The table describes the new source contract, not results of executed tests.
The request discriminator checks at least eight bytes before reading magic.
All state reads are independently length-guarded.

| Existing state | Request / output | Actual selected HIA path | Result and ownership contract |
|---|---|---|---|
| Empty owner, length 0 | Request begins `HTCGEN01` | Original `generator_step` | Original Generator envelope validation, allocation and compact-state transaction; invalid requests follow its original errors. |
| Empty owner, length 0 | Any other request, including a short request | Original `tensor_step` | Original Tensor validation and allocation behavior. Unknown requests use the Tensor response family. |
| Nonempty, length at least 8, raw offset 0 is `HTCGST01` | Any request | Original `generator_step` regardless of request | A Tensor request cannot switch or replace the existing CG owner. Original CG validator refuses the wrong protocol with its original status; malformed recognized CG owners are also validated there. |
| Nonempty, length at least 139272, raw offset 64 is `HTSINT02` and raw offset 139264 is `HTOSIN02` | Any request | Original `tensor_step` regardless of request | A Generator request cannot switch or replace the existing Tensor owner. The original Tensor validator checks the complete actual state and request. The two magic words are dispatch hints, not a substitute for that validator. |
| Nonempty length 1–7 | Request begins `HTCGEN01` | `mux_refuse_generator` only | The original readonly `cg_validate` and original `cg_error` preserve its validation priority and real state fields. A valid stats request returns original status 10. No application step, allocation or commit is reachable. |
| Nonempty with unknown magic, short Tensor state, or one mismatching Tensor magic | Request begins `HTCGEN01` | `mux_refuse_generator` only | Same refusal-only behavior. If validation unexpectedly reports success, force invalid-owner status 10; never enter `generator_step` from this branch. |
| Nonempty short or unknown state | Other request | `mux_refuse_tensor` only | `frame_valid` keeps actual request-validation errors; if the frame is valid, `reply_error` reports invalid-owner status 7. The exact original owned buffer is returned. |
| CG family or CG refusal-only path | Output capacity below 64 | Original or refusal-only short-output branch | Return the same owned buffer and length 0; write no output. |
| Tensor family or Tensor refusal-only path | Output capacity below 32 | Original or refusal-only short-output branch | Return the same owned buffer and length 0; write no output. |

The invalid-owner branches use the request only to select error formatting and
validation priority. They cannot select application execution. The Tensor
refusal-only helper deliberately does not allocate the old Tensor scratch
buffer: the ordering of errors for an **unknown nonempty Tensor owner under
simultaneous allocation failure** is a new explicit boundary, not a claim of
identical old scratch-allocation priority. Recognized current Tensor owners
still enter the original, unchanged Tensor step.

## Original Generator refusal and rollback checks

The original 59-entry qualifier's short-input cases use a recognized valid CG
pool, so their status 1 still comes from the unchanged original step. Its
short-internal-owner cases use a valid CG stats request, so the original
`cg_validate` returns status 10 through the refusal-only helper. Its malformed
header cases either retain CG magic and reach the original step, or alter
magic and reach the refusal-only validator; both retain the original error and
the complete original owner. These statements describe reachable source paths;
the 59 actual cases must still run against the new image.

Recognized CG mutations keep the original order: validation; trial allocation;
5056-byte scratch allocation; `cg_apply`; scratch drop; commit or abort. Failed
allocation and failed apply discard only the new temporary owners. Commit
drops the old state exactly once and returns the real new compact owner.
Generator state has actual length `64 + 5088 * live_count`; epoch and last
handle are read from and updated in native state, not generated by a wrapper.

## Genuine entropy and new ABI

The candidate builder requires the original fixed entropy linker
`761a941fd7a2d53eb9b45869fcfc20e970640e9dd11d60f7c61a89812b61d74e`
and sends `HIACGS01`. The module compiler remains
`b1c851a0896fa6071f800e1146c3c27d0c6cf85059e9a6281b46d42908a3f59f`.
Only four literal identities change in the original current builder: linker,
RNG support, owner support, and request magic. Its complete inverse is checked;
source limits, complete unit/import checks, actual cold compilation, object
inspection, stack-budget calculation and native linking remain in force.

The native startup supplies the fourth read-only argument from a private
8-byte area populated by Linux `getrandom(318)`. Only complete requests of at
least 64 bytes with `HTCGEN01` and operation 3 request entropy. It retries EINTR
and partial reads, supplies length 0 on failure, and clears the private length
and bytes before and after each frame. Frames cannot supply the entropy
pointer or data. An invalid handle or wrong existing owner may still cause an
OS entropy read **before** application validation; the required atomicity is
unchanged application owner/RNG state, not absence of an OS entropy read.

The fixed startup preserves its 8 MiB usable stack and two 4096-byte guards.
The original 8384512-byte maximum call path and 4096-byte reserve remain checked.
The result area and startup stack controls are unchanged. The old three-argument
linker must still reject this entry, and the entropy linker must reject the
old three-argument entry or a writable/owned/wrong entropy argument.

## Required next execution

Root exclusively builds and executes. First build only the entropy **tool**
with the accompanying `tool-bootstrap/build_tool.py`; its original source
prefix ends before old RNG/model/owner/application authoring. Then cold-build:

```sh
python3 -S -B "$CANDIDATE/tools/current_runtime/build.py" \
  --manifest "$CANDIDATE/source/manifest.json" \
  --source-root "$CANDIDATE/source" \
  --compiler "$STACK/native/stack-module-compiler" \
  --linker "$TOOL_BUILD/generator-session-linker" \
  --output "$FRESH_COMBINED_BUILD"
```

The expected outcome at this step is only `PASS_NATIVE_BUILD_ONLY`. The new
ELF SHA must come from this actual build; no predicted or historical image is
substituted. All original 513 same-image cases must run again against the new
source/ELF/startup, with explicit identity/source inverse adapters. Generator
24, native-resource 11 and ABI-entry 59 are additional mandatory groups; the
original expected values, exact bit comparisons, state bytes and failures stay
unchanged. Extra mixed-protocol and malformed-state dispatcher cases are also
needed, including state retention and capacity boundaries from the table.

The original Generator 11 gate requires 1715 frames, 121611 exact output
values, 471 state checks and 72 whole-pool failure rollbacks. Resource ceilings,
seccomp getrandom failure, unmap/recovery, handle/epoch exhaustion and entry
signature refusals remain real native tests. A pass of the 24 numerical oracle
alone cannot retire those gates or establish full PyTorch compatibility.
