"""Authoring-only exact original Emitter policy; runtime never imports this module."""

class _Emitter:
    def __init__(self, document, allowed_exports, block_order=None, foreign_buffer_exports=(), machine_plan=None):
        from .hia_machine_plan import code_options
        self.document, self.allowed_exports = document, allowed_exports
        self.c, self.symbols, self.exports, self.frames = Code(**code_options(machine_plan)), [], [], []
        self.machine_plan = machine_plan
        self.function_alignment = 1 if machine_plan is None else machine_plan.get("function_alignment", 1)
        self.indices = {fn["name"]: i for i, fn in enumerate(document["functions"])}
        self.serial = 0
        self.block_order = block_order or {}
        self.foreign_buffer_exports = dict(foreign_buffer_exports)

    def ordered_blocks(self, fn):
        """Realize the caller's checked layout; never choose a profitable order."""
        order = self.block_order.get(fn["name"])
        if order is None:
            return fn["blocks"]
        blocks = {block["id"]: block for block in fn["blocks"]}
        return [blocks[name] for name in order]

    def label(self, suffix):
        self.serial += 1
        return suffix + "_" + str(self.serial)

    def function_symbol(self, name):
        return "__hia_native_fn_" + str(self.indices[name])

    def wrapper(self, fn):
        name = fn["name"]
        if name in self.foreign_buffer_exports:
            from .hia_native_byte_abi import emit_wrapper
            emit_wrapper(self, fn, self.foreign_buffer_exports[name])
            return
        if (name not in self.allowed_exports
                or any(p["type"] not in set(WIDTHS) | {"bool"} for p in fn["params"])
                or len(fn["returns"]) > 1
                or any(t not in set(WIDTHS) | {"bool", "unit"} for t in fn["returns"])):
            return
        if name in IMPORTS or name in _LOADER_HOOKS or name.startswith("__hia_"):
            _reject("export conflicts with the closed runtime or loader ABI", "E_HIA_PROGRAM_ABI")
        count = len(fn["params"])
        frame = ((count + 1) * 8 + 15) & -16
        if frame > MAX_FRAME_BYTES:
            _reject("entry wrapper exceeds the stack budget", "E_HIA_PROGRAM_LIMIT")
        c = self.c
        begin = len(c.data)
        _prologue(c, frame)
        input_slot, result_slot = -frame, -8
        # rax is the only scratch until every incoming argument is saved.
        for i, param in enumerate(fn["params"]):
            if i < len(_ARG_REGS):
                c.mov_rr("rax", _ARG_REGS[i])
            else:
                c.load("rax", "rbp", 16 + 8 * (i - len(_ARG_REGS)))
            _normalize(c, "rax", param["type"])
            c.store("rbp", input_slot + i * 8, "rax")
        c.lea("rdi", "rbp", input_slot); c.lea("rsi", "rbp", result_slot)
        c.call(self.function_symbol(name))
        if fn["returns"] and fn["returns"] != ["unit"]:
            c.load("rax", "rbp", result_slot)
            _normalize(c, "rax", fn["returns"][0])
        c.leave(); c.ret()
        self.symbols.append({"name": name, "offset": begin, "size": len(c.data) - begin, "global": True})
        self.exports.append(name)

    def render(self):
        # Future Core additions require an explicit lowering review. A growing
        # verifier registry cannot silently widen this backend through prefixes.
        if self.document["schema"] not in CORE_SCHEMAS:
            _reject("Core schema lacks a reviewed direct lowering", "E_HIA_PROGRAM_PROFILE")
        for fn in self.document["functions"]:
            types = [p["type"] for p in fn["params"]] + fn["returns"]
            for block in fn["blocks"]:
                types.extend(p["type"] for p in block["params"])
                if block["term"]["op"] not in {"ret", "jump", "branch", "trap"}:
                    _reject("terminator lacks a reviewed direct lowering", "E_HIA_PROGRAM_PROFILE")
                for instruction in block["ops"]:
                    if instruction["op"] not in SUPPORTED_OPCODES:
                        _reject("opcode lacks a reviewed direct lowering", "E_HIA_PROGRAM_PROFILE")
                    types.extend(p["type"] for p in instruction["out"])
            if any(typ not in _TYPES for typ in types):
                _reject("type lacks a reviewed direct lowering", "E_HIA_PROGRAM_PROFILE")
        functions = self.document["functions"]
        if self.machine_plan is not None and "function_order" in self.machine_plan:
            by_name = {fn["name"]: fn for fn in functions}
            functions = [by_name[name] for name in self.machine_plan["function_order"]]
        for fn in functions:
            self.c.align(self.function_alignment)
            _Function(self, fn, self.indices[fn["name"]]).render()
        for fn in functions:
            self.c.align(self.function_alignment)
            self.wrapper(fn)
        missing = set(self.document.get("exports", [])) - set(self.exports)
        if missing:
            _reject("explicit exports have signatures outside the native C ABI: " + ", ".join(sorted(missing)), "E_HIA_PROGRAM_ABI")
        if not 1 <= len(self.exports) <= 128:
            _reject("native profile requires between 1 and 128 admitted entrypoints")
        if len(self.c.data) > MAX_TEXT_BYTES:
            _reject("direct code exceeds the text budget", "E_HIA_PROGRAM_LIMIT")
        text, relocations = self.c.finalize()
        obj = write_elf_object(text, self.symbols, relocations,
                               text_alignment=max(16, self.function_alignment))
        return text, obj
