# Direct differentiable view R1 build evidence

This packet preserves the actual fixed-tool bootstrap, one exact frozen09b parent rebuild and one recovered-R1 child build.
It does not claim a new Torch reference execution, semantic replay or full API closure.

## Actual terminal results

- Fixed-toolchain cold02: job1a1e65f617b-392-3af4, ten original stages passed, exact b1c compiler / aae session linker / 0c51 runtime linker.
- Parent plus child: job1a1e661f2ad-392-3af9, exit0; parent12 real object compiles and final native link reproduce the original09b hashes.
- Child source644c1e3e7828c60b1335794469a7ab38f73cb73b9f364d1b7ec9b83fdf7bf3c5; ELF526dde8b0e3d1b48511781e0b5d5c5082fd25127cef4df96edfbc41dc99c15ef.
- Child614 functions /8082 blocks /29053 instructions /12 actual units /672-byte descriptor.
- Parent generated build.json bbd8678 is new; original9913 remains reference-original-build.json. It is never renamed as the new execution report.

## Preserved failures and preparation

The first bootstrap3ae9 failed before new compiler generation because the original non-cone sparse source layout omitted true f33 pyproject.toml. The pinned resolver selected installed-package resources. The original missing-file traceback and complete inputs remain unchanged.
An isolated local clone then failed because a promisor repository upload-pack could not fetch an unrelated object; its raw command/error remains.
The minimal layout repair restored the exact426-byte f33 Git blob ca913dcef0c60ef1b3d27447e25f732e4dcd517f, not a synthetic sentinel. Existing32 authoring files and tracked state remained unchanged.
Wrapper02 was prepared but never executed. Wrapper03 adds only the new output path and exact pyproject input custody. All original compiler predicates and expected hashes remain.

## Custody and scope

The original14 reference is a separate immutable packet: manifest4542524a91d21f897fbb53b80b15f1f7f36c740a94b80d2b148729f76c8520c3, archive55c9718395e6007de32a43e93c60e90500ec1c2aea9b7e93dd831b25cefac345, actual2270d5ba925bcf91c56db94fac663695e69079c74edbf80aff8fa086e7c81665.
The business replayer is executed separately by its unique owner. Build receipts retain runtime_qualified=false.
The source-only audit independently checks every614 complete parent/child body and all four tag inverses. The exact HIA constructor diff is retained.
captured-input-map.json maps original absolute paths to stored immutable bytes. Original reports and raw tool-response strings are not rewritten.
To verify storage, compare every tar member with manifest.json, reject links/extra members, and require the single XZ stream and decompressed tar size/SHA. No native or Torch execution is required.
