"""Reconstruct the complete original Half737 source from current736 bytes.

The inverse documents source changes; it does not claim runtime equivalence.
"""
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
SOURCE = '51820849f7becec549be15babace00f00687601ae7f53bcee0e636ca02f721f9'
ORIGINAL = 'b2430af6ab7070efda67a1f7e9e2a8a83e273d57e44728b5492f0ee9d03e8fc3'
DELTA = '3882ff7628f9555bcbb630be5e5a62ad705712113d2e175ae2c0aa0d9bbc1f02'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def functions(raw, count):
    matches = list(re.finditer(rb'^fn ([A-Za-z_][A-Za-z0-9_]*)\(.*?^end\n', raw, re.M | re.S))
    result = {m[1].decode(): m[0] for m in matches}
    header = raw.split(b'\n', 1)[0] + b'\n'
    require(len(result) == len(matches) == count, 'exact complete function count')
    require(header + b''.join(result.values()) == raw, 'complete function and header extent')
    return header, result


def body(row, name, prefix=''):
    raw = row[prefix + 'body'].encode()
    require(raw.startswith(('fn ' + name + '(').encode()) and raw.endswith(b'end\n')
            and len(raw) == row[prefix + 'bytes'] and sha(raw) == row[prefix + 'sha256'],
            'complete pinned function: ' + name)
    return raw


def restore_source(source, bind):
    bind(Path(__file__).resolve())
    require(sha(source) == SOURCE, 'exact current736 source')
    delta = json.loads(bind(HERE / 'source-transition.json', DELTA))
    require(delta['schema'] == 'heptatorch.current736-to-original-half737.source-delta.v1'
            and delta['current']['sha256'] == SOURCE and delta['original']['sha256'] == ORIGINAL,
            'exact source identities')
    header, current = functions(source, 736)
    require(header.decode() == delta['current']['header']
            and len(source) == delta['current']['bytes']
            and list(current) == delta['current']['order'], 'entire current source extent')
    changed, added, removed, unchanged = (delta[k] for k in ('changed', 'added', 'removed', 'unchanged'))
    old_order = delta['original']['order']
    require(len(old_order) == len(set(old_order)) == 737
            and len(changed) == 9 and len(added) == 6 and len(removed) == 7 and len(unchanged) == 721
            and set(changed) | set(removed) | set(unchanged) == set(old_order)
            and set(changed) | set(added) | set(unchanged) == set(current)
            and not (set(changed) & set(unchanged))
            and not (set(removed) & set(current)) and not (set(added) & set(old_order)),
            'exact721 unchanged,9 changed,7 removed,6 added partition')
    old = {}
    for name, row in unchanged.items():
        require(len(current[name]) == row['bytes'] and sha(current[name]) == row['sha256'],
                'unchanged complete body: ' + name)
        old[name] = current[name]
    for name, row in changed.items():
        before, after = body(row, name, 'before_'), body(row, name, 'after_')
        require(current[name] == after and before != after, 'changed current body: ' + name)
        old[name] = before
    for name, row in removed.items():
        old[name] = body(row, name)
    for name, row in added.items():
        require(current[name] == body(row, name), 'added complete body: ' + name)
    restored = delta['original']['header'].encode() + b''.join(old[n] for n in old_order)
    old_header, original = functions(restored, 737)
    require(sha(restored) == ORIGINAL and len(restored) == delta['original']['bytes'],
            'all original737 source bytes restored')
    forward = header + b''.join(body(changed[n], n, 'after_') if n in changed else
                               body(added[n], n) if n in added else original[n]
                               for n in delta['current']['order'])
    require(forward == source, 'entire current736 forward round trip')
    callers = {n: sorted(k for k, v in original.items()
                         if ('"function":"' + n + '"').encode() in v) for n in removed}
    require(callers == delta['removed_original_callers'] and all(not x for x in callers.values()),
            'removed original declarations have no call sites')
    half = delta['original_half_changed_or_added']
    require(len(half) == 21 and set(half) & set(changed) == {'to_command'},
            'only the public dispatcher differs among the21 original Half bodies')
    for name, row in half.items():
        require(sha(original[name]) == row['original_sha256']
                and sha(current[name]) == row['current_sha256']
                and row['entire_body_unchanged'] is (original[name] == current[name]),
                'explicit original Half body relation: ' + name)
    return restored, dict(
        schema='heptatorch.current736-to-original-half737.source-inverse.v1',
        source_sha256=SOURCE, original_source_sha256=ORIGINAL,
        source_functions=736, original_functions=737, delta_sha256=DELTA,
        whole_source_inverse_exact=True, whole_source_round_trip_exact=True,
        unchanged_complete_functions=721, changed_functions=list(changed),
        removed_functions=list(removed), added_functions=list(added),
        removed_original_callers=callers, original_half_bodies=half,
        original_header_restored=old_header.decode(), runtime_equivalence_proved=False,
        historical_runtime_PASS_transferred=False, cases_or_expected_values_changed=False,
        native_executed=False, Torch_executed=False, compiler_executed=False)
