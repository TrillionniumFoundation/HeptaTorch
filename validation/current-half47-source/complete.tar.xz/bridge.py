"""Bind original Half47 cases to current736 without changing their predicates."""
import ast
import contextlib
import hashlib
import json
from pathlib import Path
import re
import stat
import sys
import types

HERE = Path(__file__).resolve().parent
FROZEN = HERE / 'frozen737'
PRODUCER_CANDIDATE = HERE / 'frozen-candidate737'
SOURCE = '51820849f7becec549be15babace00f00687601ae7f53bcee0e636ca02f721f9'
IMAGE = 'aa3cc8f0c8738a9505d31c9e8ba5a523b7e08b591b61fc7bfb8592295491618b'
REFERENCE = 'ae6079c8f0960db53d26e056cc67fbe0a8eee7de04aa0644f4475afc368a75fe'
PRODUCER_MANIFEST = 'a767ddfa1982e71daa35f476dcd40d2f3c624c79eb9dd768bc49138c4fb65b34'
PRODUCER_SOURCE = 'b2430af6ab7070efda67a1f7e9e2a8a83e273d57e44728b5492f0ee9d03e8fc3'
COMMON = '25dc615d52402737603864dec69d9d49728e2061a17621db7afff0801dad60de'
ORIGINAL_RUN = '2671a9ab7937d692e4c675a660b209e4c26e8fd97a45cf452e6088b0c2266154'
PARTITION = '28865982694c45b8b022ad9ee63255e31b6001f2b0004652e099d2de39ae5885'
QUALIFICATION = '9a45cee45a289dae0a35b0a256f66f6a1ea2d3c8becd30bb2174da1ffb51e9bb'
BUILDER = '9c93f8ff3fcfda8358e51a4c12efb3b0e0962abed9b5a750ca32d5a5568ac14d'
IDENTITY_AUTHOR = '1818aa41ce6b813014d4cf904e80a19103ffc6cb087e68ec803061531947ccf2'
IDENTITY_PROOF = '04272990d2ff459134dfa685f5180eb8c1e0c69f9d8ffaafa544cc5d25c87e6d'
SOURCE_HELPER = 'e4cc64c0e7e449d4e418655aa3d43d5334d330642c2410d7904f0b7449fc84fa'
OWNER = '998b16ee4db0d65230007bf21e375f6b336d1f93c5fb07480c19f0107f0d01ee'
DERIVED_RUN = '05dcfc306a0ffbde1685c7a8343c30b21201a2d1cdaae8ed15a6631df784e149'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique(pairs):
    result = {}
    for name, value in pairs:
        require(name not in result, 'duplicate JSON key')
        result[name] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique)


def regular(path, expected):
    path = Path(path)
    require(not path.is_symlink(), 'regular physical source')
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    identity = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    require(stat.S_ISREG(after.st_mode) and identity(before) == identity(after)
            and sha(raw) == expected, 'unchanged exact physical source')
    return raw


def module(raw, name, path):
    result = types.ModuleType(name)
    result.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), result.__dict__)
    return result


def manifest(directory, filename, expected, inputs):
    directory = Path(directory).resolve(strict=True)
    raw = inputs.bind(directory / filename, expected)
    data = parse(raw)
    require(isinstance(data['files'], dict), 'source manifest member mapping')
    physical = set()
    for path in directory.rglob('*'):
        require(not path.is_symlink(), 'no symlinks in source package')
        if path.is_file():
            physical.add(path.relative_to(directory).as_posix())
    require(physical == set(data['files']) | {filename}, 'complete source-package physical census')
    for relative, row in data['files'].items():
        part = Path(relative)
        require(not part.is_absolute() and '..' not in part.parts and part.as_posix() == relative,
                'normalized package path')
        inputs.bind(directory / part, row['sha256'], row['bytes'], row['mode'])
    return sha(raw), data


@contextlib.contextmanager
def original_modules():
    names = ('common', 'cases', 'corpus', 'reference', 'native', 'controls')
    missing = object()
    previous = {n: sys.modules.get(n, missing) for n in names}
    old_path, old_bytecode = list(sys.path), sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        common = module(regular(FROZEN / 'common.py', COMMON), 'half_original737_common', FROZEN / 'common.py')
        sys.modules['common'] = common
        inputs = common.Inputs()
        manifest(FROZEN, 'source-manifest.json', PRODUCER_MANIFEST, inputs)
        require(common.HERE == FROZEN and common.SOURCE == PRODUCER_SOURCE, 'original737 producer namespace')
        originals = {'common': common}
        for name in names[1:]:
            path = FROZEN / (name + '.py')
            originals[name] = module(inputs.bind(path), 'half_original737_' + name, path)
            sys.modules[name] = originals[name]
        old_run = module(inputs.bind(FROZEN / 'run.py', ORIGINAL_RUN), 'half_original737_run', FROZEN / 'run.py')
        require(old_run.Reference.__init__.__globals__['SOURCE'] == PRODUCER_SOURCE,
                'unchanged original Reference source namespace')
        yield originals, old_run, inputs
        inputs.unchanged()
    finally:
        for name in names:
            if previous[name] is missing:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = previous[name]
        sys.path[:] = old_path
        sys.dont_write_bytecode = old_bytecode


class Adapter:
    def __init__(self, originals, old_run, startup_inputs):
        self.old, self.run, self.startup_inputs = originals, old_run, startup_inputs
        self.repository = self.profile = self.identity = None

    def bind_package(self, inputs):
        digest, _ = manifest(HERE, 'source-manifest.json', None, inputs)
        manifest(FROZEN, 'source-manifest.json', PRODUCER_MANIFEST, inputs)
        for path, row in self.startup_inputs.rows.items():
            inputs.bind(path, row['sha256'], row['bytes'], row['mode'])
        path = HERE / 'identity.py'
        author = module(inputs.bind(path, IDENTITY_AUTHOR), 'half736_identity_author', path)
        outputs, proof = author.derive(inputs.bind)
        for name, raw in outputs.items():
            require(inputs.bind(HERE / name) == raw, 'entire identity rederivation: ' + name)
        inputs.bind(HERE / 'identity-derivation.json', IDENTITY_PROOF)
        self.identity = proof
        return digest

    def candidate_admission(self, directory, inputs):
        repository = Path(directory).resolve(strict=True)
        manifest_raw = inputs.bind(repository / 'tools/current_runtime/source/manifest.json', PARTITION)
        planned = parse(manifest_raw)
        require(planned['runtime']['sha256'] == SOURCE and planned['runtime']['functions'] == 736
                and planned['expected_native_sha256'] == IMAGE and len(planned['units']) == 14,
                'exact source736 and14-unit image profile')
        source = inputs.bind(repository / 'tools/current_runtime/source/runtime.hepta', SOURCE)
        helper_path = HERE / 'source_transition.py'
        helper = module(inputs.bind(helper_path, SOURCE_HELPER), 'half736_complete_source_inverse', helper_path)
        restored, proof = helper.restore_source(source, inputs.bind)
        require(restored == inputs.bind(PRODUCER_CANDIDATE / 'candidate/runtime.hepta', PRODUCER_SOURCE),
                'all original737 source bytes restored')
        original = self.old['common'].candidate_admission(PRODUCER_CANDIDATE, inputs)
        path = repository / 'tools/current_runtime/qualification.py'
        profile = module(inputs.bind(path, QUALIFICATION), 'half736_current_strict_build_admission', path)
        require(profile.ROOT == repository and profile.PROFILE_BYTES == manifest_raw
                and profile.SOURCE == SOURCE and profile.IMAGE == IMAGE
                and profile.FUNCTIONS == 736 and profile.UNITS == 14,
                'same current source profile and unchanged shared build admission')
        inputs.bind(repository / 'tools/current_runtime/build.py', BUILDER)
        self.repository, self.profile = repository, profile
        return dict(schema='heptatorch.current736-half47.source-admission.v1',
            source_sha256=SOURCE, native_sha256=IMAGE, functions=736, units=14,
            complete736_to737_inverse=proof, original737_source_admission=original,
            original_reference_producer_source_sha256=PRODUCER_SOURCE,
            original_reference_producer_manifest_sha256=PRODUCER_MANIFEST,
            current_source_manifest_sha256=PARTITION, reader_identity_inverse=self.identity,
            original_numerical_and_boundary_predicates_changed=False,
            original239_refusal_expectations_changed=False,
            old12_standalone_refusals_transferred=False, prior_runtime_PASS_transferred=False,
            native_executed=False, Torch_executed=False)

    def cold_admission(self, directory, image_sha, report_sha, candidate, inputs):
        require(self.repository is not None and self.profile is not None
                and Path(candidate).resolve(strict=True) == self.repository,
                'admitted current source precedes cold admission')
        require(image_sha == IMAGE and re.fullmatch('[0-9a-f]{64}', report_sha) is not None,
                'current image and explicit actual receipt digest')
        directory = Path(directory).resolve(strict=True)
        physical = {}
        def bound(path, expected=None):
            raw = inputs.bind(path, expected)
            key = str(Path(path).resolve(strict=True))
            physical[key] = inputs.rows[key]
            return raw
        built = self.profile.admit_build(directory, bound, report_sha)
        require(len(physical) == 69 and built['functions'] == 736
                and len(built['units']) == 14 and len(built['processes']) == 15,
                'all69 physical inputs and14 fresh compilers plus1 linker')
        for path, row in built['inputs'].items():
            inputs.bind(path, row['sha256'], row['bytes'])
        return dict(schema='heptatorch.current736-half47.cold-admission.v1',
            status='PASS_BUILD_ADMISSION_ONLY', source_sha256=SOURCE, native_sha256=IMAGE,
            build_sha256=report_sha, functions=736, units=14, physical_inputs=69, files=physical,
            actual_original_build_inputs_rechecked=True, compiler_processes=14, linker_processes=1,
            shared_admission_sha256=QUALIFICATION, builder_sha256=BUILDER, manifest_sha256=PARTITION,
            original_shared_predicates_unchanged=True, link_request_magic='HIACGS01',
            historical_fixed_build_receipt_used=False, native_executed_by_admission=False,
            Torch_executed_by_admission=False, runtime_qualification_inferred=False)

    def groups(self, directory, inputs):
        require(Path(directory).resolve(strict=True) == self.repository, 'groups for admitted repository')
        return self.old['corpus'].groups(PRODUCER_CANDIDATE, inputs)

    def comparisons(self, directory, inputs):
        require(Path(directory).resolve(strict=True) == self.repository, 'comparison for admitted repository')
        return self.old['corpus'].comparison_functions(PRODUCER_CANDIDATE, inputs)

    def make_owner(self, candidate, image_sha, inputs):
        require(Path(candidate).resolve(strict=True) == self.repository and image_sha == IMAGE,
                'full owner for admitted current image')
        path = HERE / 'owner736.py'
        owner = module(inputs.bind(path, OWNER), 'current736_original_half_owner', path)
        owner.bind_profile(SOURCE, IMAGE, 736)
        return owner

    def current_main(self):
        raw = regular(HERE / 'derived737_run.py', DERIVED_RUN)
        main = next(n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name == 'main')
        namespace = dict(self.run.__dict__)
        namespace.update(HERE=HERE, SOURCE=SOURCE, IMAGE=IMAGE,
                         PRODUCER_SOURCE=PRODUCER_SOURCE, PRODUCER_MANIFEST=PRODUCER_MANIFEST,
                         bind_package=self.bind_package, candidate_admission=self.candidate_admission,
                         cold_admission=self.cold_admission, groups=self.groups,
                         comparison_functions=self.comparisons, make_owner=self.make_owner)
        exec(compile(ast.Module(body=[main], type_ignores=[]), 'current736-half47-main', 'exec'), namespace)
        require(namespace['Reference'] is self.run.Reference
                and namespace['Reference'].__init__.__globals__['SOURCE'] == PRODUCER_SOURCE
                and namespace['Driver'] is self.run.Driver and namespace['run_child'] is self.run.run_child,
                'only main has current identity; all original Reference and47 tasks remain unchanged')
        return namespace['main']


def main():
    import argparse
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--expected-reference-sha256', required=True)
    args, _ = parser.parse_known_args()
    require(args.expected_reference_sha256 == REFERENCE, 'exact original actual Torch reference report')
    with original_modules() as (originals, old_run, startup):
        return Adapter(originals, old_run, startup).current_main()()


if __name__ == '__main__':
    raise SystemExit(main())
