#!/usr/bin/env python3
"""Derive the explicit 2-byte owner observer; no runtime or /proc reads."""
from pathlib import Path
import argparse
import ast
import hashlib
import json

HERE = Path(__file__).resolve().parent
PARENT = '5700ca389d9b73ab6f37cf13c7a25ae241aac9d4612e4f33f5158379a0e6cd2b'
SOURCE = 'b2430af6ab7070efda67a1f7e9e2a8a83e273d57e44728b5492f0ee9d03e8fc3'

APPENDIX = '''

# BEGIN EXPLICIT PUBLIC HALF OBSERVATION; numerical references are external.
_half_original_verify_snapshot = verify_snapshot
_half_original_verify_frame_boundary = verify_frame_boundary
HALF_ZERO_FIELDS = (24,32,40,48,56,72,80,176,184,232,248,288,360,384,408,
                    584,592,600,608,616,624,632,640,648,656,664)
HALF_CAST_PAIRS = ((0,5),(5,0),(0,6),(6,0),(5,5),(6,6))


def half_role(snapshot, index):
    node = _live_node(snapshot,index,"half-live-node")
    need(w(node,576) in (5,6) and not any(w(node,f) for f in HALF_ZERO_FIELDS),
         "half-public-noAD-noSaved-noView-offset-zero",node=index)
    need(w(node,240)==1,"half-live-real-Tensor-row",node=index)
    storage = _live_row(snapshot,2,w(node,216),"half-real-Storage")
    version = _live_row(snapshot,3,w(node,224),"half-real-Version")
    need(storage[3]==2*w(node,8),"half-exact-two-byte-storage-extent",node=index)
    # Dense permutations are allowed. Dimensions of size1 do not constrain
    # addressing; empty tensors are checked by the complete original decoder.
    if w(node,8):
        product = 1
        axes = sorted((node[16+d],node[12+d]) for d in range(w(node,0)) if node[12+d]>1)
        for stride,size in axes:
            need(stride==product,"half-owned-dense-permutation-layout",node=index)
            product *= size
        need(product==w(node,8),"half-owned-dense-layout-numel",node=index)
    return {"node":index,"dtype":w(node,576),"width":2,"storage":w(node,216),
            "version":w(node,224),"actual_version_value":version[2],
            "storage_bytes":storage[3],"requires_grad":False,
            "autograd_operation":0,"ViewInfo_absent":True,"Saved_absent":True}


def verify_snapshot(snapshot):
    checked = _half_original_verify_snapshot(snapshot)
    actual = [half_role(snapshot,int(name)) for name,node in snapshot["nodes"].items()
              if w(node,304) and w(node,576) in (5,6)]
    return {**checked,"ordinary_half_nodes":actual,
            "all_original_84Q_fields_checked":True,
            "all_original_84Q_predicates_retained":False,
            "old_dtype_domains_and_private_scalar3_preserved":True,
            "prior_public4_structure_checks_preserved":True,
            "explicit_dtype_domain_extension":[4,5,6],
            "new_half_dtype_domain_extension":[5,6],
            "full_transition_recomputed":False}


def _half_fresh_result(before,after,result,sources):
    node = _live_node(after,result,"half-new-result")
    need(str(result) not in before["nodes"] or not w(before["nodes"][str(result)],304),
         "half-new-live-node")
    dtype = w(node,576)
    need(dtype in (0,5,6),"half-new-result-supported-dtype")
    width = 4 if dtype==0 else 2
    storage = _live_row(after,2,w(node,216),"half-new-Storage")
    version = _live_row(after,3,w(node,224),"half-new-Version")
    need(version[2]==0 and w(node,232)==0 and storage[3]==width*w(node,8),
         "half-result-fresh-zero-Version-and-complete-storage")
    for source in sources:
        old = before["nodes"][str(source)]
        need(result!=source and w(node,320)!=w(old,320)
             and w(node,216)!=w(old,216) and w(node,224)!=w(old,224),
             "half-result-distinct-T-S-V",source=source)


def half_command_metadata(before,after,command,record):
    op = command[0]
    need(record["opcode"]==op,"half-response-opcode")
    if op==97 and command[1] in (5,6):
        result = public_node(after,record["value"])
        role = half_role(after,result)
        need(role["dtype"]==command[1],"half-factory-request-dtype")
        _half_fresh_result(before,after,result,[])
        return {"operation":97,"role":role,"explicit_dtype5_or6":True}
    if op in (108,109):
        source = public_node(before,command[1]); old = before["nodes"][str(source)]
        source_dtype,target_dtype = w(old,576),command[2]
        if source_dtype not in (5,6) and target_dtype not in (5,6):
            return None
        need((source_dtype,target_dtype) in HALF_CAST_PAIRS and w(old,32)==0,
             "half-cast-exact-six-pairs-noAD")
        result = public_node(after,record["value"])
        node = _live_node(after,result,"half-cast-result")
        need(w(node,576)==target_dtype and not any(w(node,f) for f in HALF_ZERO_FIELDS),
             "half-cast-target-dtype-noAD-Saved-or-view")
        need(after["nodes"][str(source)]==old,"half-input-complete84words-unchanged")
        if target_dtype in (5,6):
            half_role(after,result)
        if result==source:
            need(op==108 and command[3]==0 and target_dtype==source_dtype,
                 "half-cast-alias-only-explicit-same-dtype-no-copy")
        else:
            _half_fresh_result(before,after,result,[source])
        return {"operation":op,"source_dtype":source_dtype,"result_dtype":target_dtype,
                "actual_same_Tensor":result==source,"input_all84words_unchanged":True,
                "numerical_conversion_reference_compared_here":False}
    return None


def verify_frame_boundary(before,after,commands,frame_status,records,body,*,
                          before_raw=None,after_raw=None):
    original = _half_original_verify_frame_boundary(before,after,commands,frame_status,records,body,
                 before_raw=before_raw,after_raw=after_raw)
    details = None
    if not frame_status and any(c[0] in (97,108,109) for c in commands):
        need(len(commands)==1,"half-new-operation-one-command-per-observation")
        details = half_command_metadata(before,after,commands[0],records[0])
    return {**original,"half_command_details":details,
            "numeric_expected_values_computed_here":False,"full_transition_recomputed":False}
# END EXPLICIT PUBLIC HALF OBSERVATION
'''


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def need(value, rule):
    if not value:
        raise AssertionError(rule)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    old = (HERE / 'frozen/owner730.py').read_bytes()
    need(sha(old) == PARENT, 'complete frozen public4 observer')
    need(sha((HERE / 'candidate/runtime.hepta').read_bytes()) == SOURCE, 'candidate source identity')
    replacements = [
        ('heptatorch.f64-generator730-owner.v1','heptatorch.half-generator737-owner.v1',1,'schema identity'),
        ('f64-generator730-UNBOUND-730','half-generator737-UNBOUND-737',1,'unbound profile identity'),
        ('functions == 730','functions == 737',2,'actual selected function count'),
        ('f64-generator730-%d-full-owner','half-generator737-%d-full-owner',1,'bound profile identity'),
        ('6c9fc24a2006163d98827f0c464162dc635ded7e4fc284cbad4b30a692022f04',SOURCE,1,'actual source identity'),
        ('(0, 1, 2, 3, 4)','(0, 1, 2, 3, 4, 5, 6)',3,'explicit Tensor/Weak/Hold dtype domains'),
        ('(4, 1, 8, 8, 8)[dtype]','(4, 1, 8, 8, 8, 2, 2)[dtype]',1,'actual byte-addressed storage widths'),
    ]
    text = old.decode()
    for before, after, count, label in replacements:
        need(text.count(before)==count and after not in text, 'unique owner edit: '+label)
        text = text.replace(before,after)
    prefix = text.encode()
    new = prefix + APPENDIX.encode()
    inverse = prefix.decode()
    for before, after, count, label in reversed(replacements):
        need(inverse.count(after)==count, 'unique inverse owner edit: '+label)
        inverse = inverse.replace(after,before)
    need(inverse.encode()==old, 'complete whole-owner inverse to5700')
    ast.parse(new)
    # Compare source spans, not version-specific ast.dump hashes.
    def bodies(raw):
        return {(n.name,n.lineno):ast.get_source_segment(raw.decode(),n)
                for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    a,b = bodies(old),bodies(prefix)
    need(a.keys()==b.keys(), 'original complete function/class inventory')
    changed = [name for (name,line),body in a.items() if b[(name,line)]!=body]
    need(changed==['_parent_verify_snapshot','bind_profile','bind_profile'],
         'only explicit domain and profile bodies changed')
    out = args.output.resolve();need(not out.exists(),'new owner output required');out.mkdir(parents=True)
    (out/'owner737.py').write_bytes(new)
    (out/'half-appendix.py.txt').write_bytes(APPENDIX.encode())
    proof = {'schema':'heptatorch.public-half737.owner-source-derivation.v1',
             'status':'SOURCE_ONLY_NOT_NATIVE_TESTED','parent_owner_sha256':PARENT,
             'source_sha256':SOURCE,'owner_sha256':sha(new),'owner_bytes':len(new),
             'prefix_sha256':sha(prefix),'appendix_sha256':sha(APPENDIX.encode()),
             'whole_inverse_exact':True,'inverse_edits':[
                 dict(before=before,after=after,count=count,purpose=label)
                 for before,after,count,label in replacements],
             'original_function_spans_preserved':len(a)-len(changed),
             'changed_original_function_spans':changed,
             'old_public4_numeric_or_owner_qualification_transferred':False,
             'original_all84_fields_still_checked':True,'original_dtype_domains_extended_explicitly':[5,6],
             'full_transition_recomputed':False,'native_executed':False,'Torch_executed':False,
             'compiler_executed':False,'actual_half_owner_observed':False}
    raw=(json.dumps(proof,indent=2,sort_keys=True)+'\n').encode();(out/'derivation.json').write_bytes(raw)
    need((HERE/'frozen/owner730.py').read_bytes()==old,'frozen parent unchanged')
    print(json.dumps({'status':proof['status'],'owner_sha256':sha(new),'owner_bytes':len(new),
                      'proof_sha256':sha(raw)}))


if __name__=='__main__':
    main()
