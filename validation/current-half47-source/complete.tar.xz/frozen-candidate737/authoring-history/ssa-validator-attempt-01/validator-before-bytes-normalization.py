#!/usr/bin/env python3
"""Pure partition and textual SSA checks; never invoke any HIA executable."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re

HERE = Path(__file__).resolve().parent
FROZEN = HERE / 'frozen'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pairs(text):
    if not text:
        return []
    rows = [tuple(item.split(':')) for item in text.split(',')]
    require(all(len(row) == 2 for row in rows), 'parameter syntax')
    return rows


def check_ssa(name, body, signatures):
    """Only validate names, local definition order, types and control edges.

    No HIA instruction is evaluated. The actual compiler remains mandatory.
    """
    lines = body.decode().splitlines()
    blocks = {}
    for line in lines:
        if line.startswith('block '):
            m = re.fullmatch(r'block (\w+)\(([^)]*)\)', line)
            require(m and m[1] not in blocks, name + ': unique block')
            blocks[m[1]] = pairs(m[2])
    global_names, local, terminated, count = set(), {}, True, 0

    def operand(value):
        require(value in local, name + ': undefined local SSA operand ' + value)
        return local[value]

    def edge(block, text):
        args = text.split(',') if text else []
        require(block in blocks and [operand(x) for x in args] == [t for _, t in blocks[block]],
                name + ': exact branch/jump parameter types ' + block)

    for line in lines[1:-1]:
        if line.startswith('block '):
            require(terminated, name + ': previous block has a terminator')
            m = re.fullmatch(r'block (\w+)\(([^)]*)\)', line)
            local = {}
            for variable, kind in blocks[m[1]]:
                require(variable not in global_names, name + ': unique block SSA name ' + variable)
                global_names.add(variable); local[variable] = kind
            terminated = False
            continue
        require(not terminated, name + ': no instruction after terminator')
        stripped = line.strip()
        if stripped.startswith('branch '):
            m = re.fullmatch(r'branch (v\d+) (\w+)\(([^)]*)\) (\w+)\(([^)]*)\)', stripped)
            require(m and operand(m[1]) == 'bool', name + ': branch bool')
            edge(m[2], m[3]); edge(m[4], m[5]); terminated = True
        elif stripped.startswith('jump '):
            m = re.fullmatch(r'jump (\w+)\(([^)]*)\)', stripped)
            require(m, name + ': jump syntax'); edge(m[1], m[2]); terminated = True
        elif stripped.startswith('ret('):
            m = re.fullmatch(r'ret\(([^)]*)\)', stripped)
            args = m[1].split(',') if m[1] else []
            require([operand(v) for v in args] == list(signatures[name][1]), name + ': result types')
            terminated = True
        else:
            m = re.fullmatch(r'(v\d+):(\w+) = ([\w.]+)\(([^)]*)\)(?: (\{.*\}))?', stripped)
            require(m, name + ': instruction syntax ' + stripped)
            variable, kind, op, text, attrs = m.groups()
            args = text.split(',') if text else []
            types = [operand(v) for v in args]
            attrs = json.loads(attrs) if attrs else {}
            require(variable not in global_names, name + ': unique instruction SSA name ' + variable)
            if op == 'call':
                callee = attrs['function']; require(callee in signatures, name + ': declared callee')
                expected = signatures[callee]
                require(types == list(expected[0]) and [kind] == list(expected[1]), name + ': call types ' + callee)
            elif op == 'const':
                require(not args and kind in ('u64', 'u32', 'usize') and type(attrs['value']) is int,
                        name + ': integer const')
            elif op.startswith('compare.'):
                require(len(types) == 2 and types[0] == types[1] and kind == 'bool', name + ': compare types')
            elif op.startswith('bool.'):
                require(types == ['bool', 'bool'] and kind == 'bool', name + ': bool types')
            elif op == 'select':
                require(len(types) == 3 and types[0] == 'bool' and types[1:] == [kind, kind], name + ': select types')
            elif op.startswith(('int.add.', 'int.sub.', 'int.mul.', 'int.div.', 'int.rem.', 'bit.')):
                require(types == [kind, kind] and kind in ('u64', 'u32', 'usize'), name + ': integer types')
            elif op.startswith(('int.shl.', 'int.shr.')):
                require(types == [kind, kind] and kind in ('u64', 'u32', 'usize'), name + ': shift types')
            elif op == 'int.cast':
                require(len(types) == 1, name + ': cast arity')
            elif op == 'buffer.len':
                require(len(types) == 1 and types[0] in ('mutbuf', 'readbuf') and kind == 'usize', name + ': len types')
            else:
                raise ValueError(name + ': unreviewed instruction kind ' + op)
            global_names.add(variable); local[variable] = kind; count += 1
    require(terminated, name + ': final terminator')
    return {'function': name, 'blocks': len(blocks), 'instructions': count, 'unique_ssa_names': len(global_names)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate', type=Path, default=HERE / 'candidate')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    author = load('_half_author_for_static_source_checks', HERE / 'emit_candidate.py')
    frozen = author.read_frozen()
    partition = load('_frozen_partition_source_only', FROZEN / 'partition.py')
    build = partition.build
    runtime = (args.candidate / 'runtime.hepta').read_bytes()
    transition = json.loads((args.candidate / 'transition.json').read_bytes())
    require(sha(runtime) == transition['source_sha256'], 'candidate source pin')
    core = build.parse_source(runtime)
    cg = build.parse_source(frozen['cg_model.hepta'], unit=True)
    tensor = runtime
    for name, body in cg['definitions'].items():
        require(core['definitions'][name] == body and tensor.count(body) == 1, 'unchanged CG core body ' + name)
        tensor = tensor.replace(body, b'', 1)
    tensor_core = build.parse_source(tensor)
    require(tensor_core['functions'] == 726, 'Tensor-only source has 719 + 7 functions')
    units = partition.partition(tensor, frozen['rng03.hepta'], frozen['owners.hepta'], 'public_half')
    require(units[-1][0] == 'owners', 'owner last')
    units.insert(len(units) - 1, ('cg_model', frozen['cg_model.hepta']))
    old_units = {row['name']: row for row in json.loads(frozen['parent730-manifest.json'])['units']}
    manifest = {'schema': 'heptatorch.complete-runtime-source.v1', 'name': 'current-generator-public-half-737',
                'runtime': {'path': 'runtime.hepta', 'sha256': sha(runtime),
                            **{k: core[k] for k in ('functions', 'blocks', 'instructions')}},
                'units': []}
    for name, raw in units:
        row = {'name': name, 'path': 'units/' + name + '.hepta', 'sha256': sha(raw)}
        if name in ('rng03', 'cg_model', 'owners'):
            require(row['sha256'] == old_units[name]['sha256'], 'unchanged support full source ' + name)
            row['expected_object_sha256'] = old_units[name]['expected_object_sha256']
        manifest['units'].append(row)
    out = args.output.resolve(); require(not out.exists(), 'new output required')
    (out / 'units').mkdir(parents=True)
    (out / 'runtime.hepta').write_bytes(runtime)
    for name, raw in units:
        (out / 'units' / (name + '.hepta')).write_bytes(raw)
    (out / 'manifest.json').write_bytes(build.json_bytes(manifest))
    _, _, summary = build.check_sources(manifest, out, build.read_file)
    signatures = dict(core['signatures'])
    signatures.update(build.parse_source(frozen['rng03.hepta'], unit=True)['signatures'])
    # Resolve shared signatures by equality. Raw RNG-only putw has exactly the
    # same type signature; source identity remains separately pinned above.
    for name, sig in core['signatures'].items():
        require(signatures[name] == sig, 'shared type signature: ' + name)
    reviewed = list(transition['changed']) + list(transition['added'])
    ssa = [check_ssa(name, core['definitions'][name], signatures) for name in reviewed]
    require(len(ssa) == 21, 'all fourteen changes and seven additions statically checked')
    report = {'schema': 'heptatorch.public-half-pure-partition.v1',
              'status': 'SOURCE_CHECKED_NOT_COMPILED_NOT_RUN', **summary,
              'manifest_sha256': sha((out / 'manifest.json').read_bytes()),
              'whole_source_inverse_to730': transition['full_source_inverse_to_730'],
              'unchanged_support_full_sources': ['rng03', 'cg_model', 'owners'],
              'support_object_pins_are_future_reproduction_requirements': True,
              'actual_objects_reused_or_read': False, 'ssa_static_checks': ssa,
              'native_executed': False, 'Torch_executed': False, 'compiler_executed': False,
              'native_semantics_or_qualification_claimed': False}
    (out / 'partition.json').write_bytes(build.json_bytes(report))
    require(author.read_frozen() == frozen, 'all frozen inputs unchanged')
    print(json.dumps({k: report[k] for k in ('status', 'source_sha256', 'functions', 'blocks',
                                             'instructions', 'units_planned', 'global_exports', 'manifest_sha256')}))


if __name__ == '__main__':
    main()
