#!/usr/bin/env python3
"""Emit a source-only public F64 Tensor candidate; never execute HIA or Torch.

This is a deliberately small assembly text author, not the HIA compiler.  All
original bodies and nine frozen numerical bodies are retained independently.
The original sqrt64 body is archived but is not admitted to the Tensor surface.
"""
from pathlib import Path
import hashlib
import json
import re
import stat

ROOT = Path('/workspace/scratch/fd98c6279214/HeptaTorch')
HERE = Path(__file__).resolve().parent
BASE = '82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313'
F64 = '44a6ff00413829d3cf8f7fbd91fb96a6baf090c3c754882d4361f49ed85a2e56'
FN = re.compile(rb'^fn (\w+)\([^\n]*\n.*?^end\n', re.M | re.S)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def once(raw, old, new):
    old = old.encode() if isinstance(old, str) else old
    new = new.encode() if isinstance(new, str) else new
    assert raw.count(old) == 1, (old, raw.count(old))
    return raw.replace(old, new, 1)


def definitions(raw):
    pairs = [(m[1].decode(), m[0]) for m in FN.finditer(raw)]
    result = dict(pairs)
    assert len(pairs) == len(result)
    return result


class Function:
    """Emit explicit SSA blocks; only constants and textual instructions."""
    def __init__(self, name, types):
        self.name, self.counter, self.blocks = name, 0, []
        self.entry = self.block(types)
        self.current = self.entry

    def variable(self, kind):
        value = (f'v{self.counter}', kind)
        self.counter += 1
        return value

    def block(self, types):
        result = {'name': f'b{len(self.blocks)}',
                  'params': [self.variable(t) for t in types], 'lines': []}
        self.blocks.append(result)
        return result

    def at(self, block):
        self.current = block
        return block['params']

    def op(self, kind, operation, args=(), attrs=None):
        value = self.variable(kind)
        tail = '' if attrs is None else ' ' + json.dumps(attrs, separators=(',', ':'))
        self.current['lines'].append(
            f'  {value[0]}:{kind} = {operation}({",".join(v[0] for v in args)}){tail}')
        return value

    def c(self, value):
        return self.op('u64', 'const', attrs={'value': value})

    def call(self, name, *args):
        return self.op('u64', 'call', args, {'function': name})

    def compare(self, mode, a, b):
        return self.op('bool', 'compare.' + mode, (a, b))

    def logic(self, mode, a, b):
        return self.op('bool', 'bool.' + mode, (a, b))

    def offset(self, base, amount):
        return self.op('u64', 'int.add.wrap', (base, self.c(amount)))

    def get(self, w, p, offset=0):
        return self.call('getw', w, self.offset(p, offset) if offset else p)

    @staticmethod
    def target(block, args):
        assert [v[1] for v in args] == [v[1] for v in block['params']]
        return f'{block["name"]}({",".join(v[0] for v in args)})'

    def branch(self, condition, yes, yes_args, no, no_args):
        assert condition[1] == 'bool'
        self.current['lines'].append(
            f'  branch {condition[0]} {self.target(yes, yes_args)} {self.target(no, no_args)}')

    def jump(self, block, args):
        self.current['lines'].append('  jump ' + self.target(block, args))

    def ret(self, value):
        assert value[1] == 'u64'
        self.current['lines'].append(f'  ret({value[0]})')

    def text(self):
        params = ','.join(f'{v}:{t}' for v, t in self.entry['params'])
        lines = [f'fn {self.name}({params}) -> (u64) effects(read,write,trap) entry(b0)']
        for block in self.blocks:
            assert block['lines'][-1].lstrip().startswith(('branch ', 'jump ', 'ret('))
            params = ','.join(f'{v}:{t}' for v, t in block['params'])
            lines.append(f'block {block["name"]}({params})')
            lines.extend(block['lines'])
        return ('\n'.join(lines) + '\nend\n').encode()


def error_block(f, cause):
    block = f.block(['mutbuf'])
    return block, cause


def fill_error(f, spec):
    block, cause = spec
    w, = f.at(block)
    f.ret(f.call('terror', w, f.c(cause)))


def emit_valid_f64():
    f = Function('f64_valid', ['mutbuf', 'u64'])
    bad = f.block([])
    dtype = f.block(['mutbuf', 'u64'])
    flags = f.block(['mutbuf', 'u64'])
    good = f.block([])
    type_error, ad_error = error_block(f, 7), error_block(f, 5)
    w, t = f.at(f.entry)
    value = f.call('valid', w, t)
    f.branch(f.compare('eq', value, f.c(0)), bad, (), dtype, (w, t))
    f.at(bad); f.ret(f.c(0))
    w, t = f.at(dtype)
    value = f.call('tensor_dtype', w, t)
    f.branch(f.compare('ne', value, f.c(4)), type_error[0], (w,), flags, (w, t))
    w, t = f.at(flags)
    value = f.get(w, f.call('dptr', w, t), 32)
    f.branch(f.compare('ne', value, f.c(0)), ad_error[0], (w,), good, ())
    f.at(good); f.ret(f.c(1))
    fill_error(f, type_error); fill_error(f, ad_error)
    return f.text()


def emit_binary_wrapper():
    f = Function('binary', ['mutbuf', 'u64', 'u64', 'u64'])
    bad = f.block([])
    decide = f.block(['mutbuf', 'u64', 'u64', 'u64'])
    old = f.block(['mutbuf', 'u64', 'u64', 'u64'])
    new = f.block(['mutbuf', 'u64', 'u64', 'u64'])
    w, op, a, b = f.at(f.entry)
    value = f.call('valid', w, a)
    f.branch(f.compare('eq', value, f.c(0)), bad, (), decide, (w, op, a, b))
    f.at(bad); f.ret(f.c(0))
    w, op, a, b = f.at(decide)
    dtype = f.call('tensor_dtype', w, a)
    f.branch(f.compare('eq', dtype, f.c(4)), new, (w, op, a, b), old, (w, op, a, b))
    args = f.at(old); f.ret(f.call('f64_previous_binary', *args))
    args = f.at(new); f.ret(f.call('f64_binary', *args))
    return f.text()


def emit_copy_wrapper():
    f = Function('to_copy_tensor', ['mutbuf', 'u64', 'u64', 'u64'])
    bad = f.block([])
    decide = f.block(['mutbuf', 'u64', 'u64', 'u64'])
    old = f.block(['mutbuf', 'u64', 'u64', 'u64'])
    new = f.block(['mutbuf', 'u64', 'u64', 'u64'])
    w, source, target, fmt = f.at(f.entry)
    value = f.call('valid', w, source)
    f.branch(f.compare('eq', value, f.c(0)), bad, (), decide, (w, source, target, fmt))
    f.at(bad); f.ret(f.c(0))
    w, source, target, fmt = f.at(decide)
    dtype = f.call('tensor_dtype', w, source)
    chosen = f.logic('or', f.compare('eq', dtype, f.c(4)), f.compare('eq', target, f.c(4)))
    f.branch(chosen, new, (w, source, target, fmt), old, (w, source, target, fmt))
    args = f.at(old); f.ret(f.call('f64_previous_to_copy_tensor', *args))
    args = f.at(new); f.ret(f.call('f64_cast_admit', *args))
    return f.text()


def emit_cast_admit():
    f = Function('f64_cast_admit', ['mutbuf', 'u64', 'u64', 'u64'])
    flags = f.block(['mutbuf', 'u64', 'u64', 'u64'])
    copy = f.block(['mutbuf', 'u64', 'u64', 'u64'])
    type_error, ad_error = error_block(f, 7), error_block(f, 5)
    w, source, target, fmt = f.at(f.entry)
    dtype = f.call('tensor_dtype', w, source)
    source_bad = f.logic('and', f.compare('ne', dtype, f.c(0)), f.compare('ne', dtype, f.c(4)))
    target_bad = f.logic('and', f.compare('ne', target, f.c(0)), f.compare('ne', target, f.c(4)))
    bad = f.logic('or', f.logic('or', source_bad, target_bad), f.compare('gt', fmt, f.c(1)))
    f.branch(bad, type_error[0], (w,), flags, (w, source, target, fmt))
    w, source, target, fmt = f.at(flags)
    requires = f.get(w, f.call('dptr', w, source), 32)
    f.branch(f.compare('ne', requires, f.c(0)), ad_error[0], (w,), copy, (w, source, target, fmt))
    args = f.at(copy); f.ret(f.call('f64_copy_tensor', *args))
    fill_error(f, type_error); fill_error(f, ad_error)
    return f.text()


def emit_convert():
    f = Function('f64_convert_value', ['u64', 'u64', 'u64'])
    same = f.block(['u64'])
    changed = f.block(['u64', 'u64'])
    widen = f.block(['u64'])
    narrow = f.block(['u64'])
    bits, source, target = f.at(f.entry)
    f.branch(f.compare('eq', source, target), same, (bits,), changed, (bits, source))
    bits, = f.at(same); f.ret(bits)
    bits, source = f.at(changed)
    f.branch(f.compare('eq', source, f.c(0)), widen, (bits,), narrow, (bits,))
    bits, = f.at(widen); f.ret(f.call('widen32', bits))
    bits, = f.at(narrow); f.ret(f.call('narrow64', bits))
    return f.text()


def emit_to_wrapper():
    types = ['readbuf', 'mutbuf', 'mutbuf', 'u64', 'u64', 'u64']
    f = Function('to_command', types)
    peek = f.block(types + ['u64'])
    dtype = f.block(types + ['u64', 'u64'])
    refuse = f.block(['mutbuf', 'mutbuf', 'u64', 'u64'])
    old = f.block(types)
    r, out, w, cp, at, end = f.at(f.entry)
    op = f.call('getr', r, cp)
    cast = f.logic('or', f.compare('eq', op, f.c(108)), f.compare('eq', op, f.c(109)))
    f.branch(cast, old, (r,out,w,cp,at,end), peek, (r,out,w,cp,at,end,op))
    r, out, w, cp, at, end, op = f.at(peek)
    source = f.call('scalar_peek_public', w, f.call('getr', r, f.offset(cp, 8)))
    f.branch(f.compare('eq', source, f.c(0)), old, (r,out,w,cp,at,end), dtype, (r,out,w,cp,at,end,op,source))
    r, out, w, cp, at, end, op, source = f.at(dtype)
    dt = f.call('tensor_dtype', w, source)
    f.branch(f.compare('eq', dt, f.c(4)), refuse, (w,out,at,op), old, (r,out,w,cp,at,end))
    w, out, at, op = f.at(refuse)
    first = f.call('getw', w, f.c(8))
    f.call('terror', w, f.c(7))
    f.ret(f.call('shape_command_finish', w,out,at,op,first,f.c(0)))
    args = f.at(old); f.ret(f.call('f64_previous_to_command', *args))
    return f.text()


def emit_dtype_audit():
    f = Function('f64_dtype_audit', ['mutbuf'])
    failed = f.block(['u64'])
    start = f.block(['mutbuf'])
    loop = f.block(['mutbuf', 'u64'])
    inspect = f.block(['mutbuf', 'u64'])
    check = f.block(['mutbuf', 'u64', 'u64'])
    advance = f.block(['mutbuf', 'u64'])
    good = f.block([])
    bad = f.block([])
    w, = f.at(f.entry)
    status = f.call('scalar_previous_dtype_audit', w)
    f.branch(f.compare('ne', status, f.c(0)), failed, (status,), start, (w,))
    status, = f.at(failed); f.ret(status)
    w, = f.at(start); f.jump(loop, (w, f.c(1)))
    w, i = f.at(loop)
    end = f.call('getw', w, f.c(8))
    f.branch(f.compare('lt', i, end), inspect, (w,i), good, ())
    w, i = f.at(inspect)
    p = f.call('dptr', w, i)
    selected = f.logic('and', f.compare('ne', f.get(w,p,304),f.c(0)),
                       f.compare('eq', f.get(w,p,576),f.c(4)))
    f.branch(selected, check, (w,i,p), advance, (w,i))
    w, i, p = f.at(check)
    fields = [24,32,40,48,56,288,384,408,584,592,600,608,616,624,632,640,648,656,664]
    nonzero = None
    for offset in fields:
        value = f.compare('ne', f.get(w,p,offset), f.c(0))
        nonzero = value if nonzero is None else f.logic('or', nonzero, value)
    f.branch(nonzero, bad, (), advance, (w,i))
    w, i = f.at(advance)
    f.jump(loop, (w, f.op('u64','int.add.wrap',(i,f.c(1)))))
    f.at(good); f.ret(f.c(0))
    f.at(bad); f.ret(f.c(9))
    return f.text()


def main():
    source_path = ROOT / 'tools/current_runtime/source/runtime.hepta'
    f64_path = ROOT / 'tools/dtype-f64/f64.hepta'
    source, numerical = source_path.read_bytes(), f64_path.read_bytes()
    assert sha(source) == BASE and sha(numerical) == F64
    before, scalar = definitions(source), definitions(numerical)
    assert len(before) == 701
    after = dict(before)
    added = {}
    reasons = {}

    def change(name, raw, reason):
        assert name in before and name not in reasons
        assert definitions(raw) == {name: raw}
        after[name], reasons[name] = raw, reason

    def add(raw):
        got = definitions(raw)
        assert len(got) == 1
        name = next(iter(got))
        assert name not in before and name not in added
        added[name] = raw

    def rename(raw, old, new):
        return once(raw, f'fn {old}(', f'fn {new}(')

    # Explicit public code 4. Private wrapped scalar code 3 remains unchanged.
    raw = once(before['dtype_width'],
        '  v18:u64 = select(v15,v16,v17)\n',
        '  v19:u64 = const() {"value":4}\n'
        '  v20:bool = compare.eq(v9,v19)\n'
        '  v21:bool = bool.or(v15,v20)\n'
        '  v18:u64 = select(v21,v16,v17)\n')
    change('dtype_width', raw, 'Only dtype 4 gains width 8; all previous widths preserved.')
    raw = once(before['typed_from_wire'],
        '  branch v6 b1(v0,v1) b2(v0,v1,v2,v3,v4)\n',
        '  v20:u64 = const() {"value":4}\n'
        '  v21:bool = compare.ne(v2,v20)\n'
        '  v22:bool = bool.and(v6,v21)\n'
        '  branch v22 b1(v0,v1) b2(v0,v1,v2,v3,v4)\n')
    change('typed_from_wire', raw, 'Factory97 permits exactly 0/1/2/4; code3 remains refused.')
    raw = once(before['tset'], '  v63:bool = bool.and(v60,v62)\n',
        '  v122:u64 = const() {"value":4}\n'
        '  v123:bool = compare.ne(v48,v122)\n'
        '  v124:bool = bool.and(v60,v123)\n'
        '  v63:bool = bool.and(v124,v62)\n')
    change('tset', raw, 'Raw mutation preserves all 64 F64 bits; bounds/version path unchanged.')
    raw = once(before['typed_fill'], '  v30:bool = bool.and(v27,v29)\n',
        '  v160:u64 = const() {"value":4}\n'
        '  v161:bool = compare.ne(v19,v160)\n'
        '  v162:bool = bool.and(v27,v161)\n'
        '  v30:bool = bool.and(v162,v29)\n')
    change('typed_fill', raw, 'Full F64 bit fill; original no_grad/version checks remain exact.')

    # Existing whole-body audits remain, with only the new dtype ceiling changed.
    raw = once(before['scalar_previous_dtype_audit'],
        '  v89:u64 = const() {"value":3}\n', '  v89:u64 = const() {"value":4}\n')
    change('scalar_previous_dtype_audit', raw, 'Owner audit admits public dtype4 and retains non-F32 noAD checks.')
    raw = once(before['dtype_audit'], '"function":"scalar_previous_dtype_audit"',
               '"function":"f64_dtype_audit"')
    change('dtype_audit', raw, 'Additional dtype4 AD/ViewInfo/Saved zero-domain audit before exact private3 audit.')
    add(emit_dtype_audit())

    # The independent numerical implementation is copied without arithmetic edits.
    numerical_names = ['pack64','add64','sub64','multiply_high','mul64','div64','widen32','narrow64']
    for name in numerical_names:
        add(scalar[name])
    for name in ['getr','shrjam','packf']:
        assert before[name] == scalar[name], name
    add(emit_valid_f64())
    add(rename(before['binary'], 'binary', 'f64_previous_binary'))
    change('binary', emit_binary_wrapper(), 'Existing command2 dispatches F64 lhs to strict F64-pair arithmetic; all old dtypes retain original body.')
    raw = rename(before['binary'], 'binary', 'f64_binary')
    assert raw.count(b'"function":"valid_f32"') == 2
    raw = raw.replace(b'"function":"valid_f32"', b'"function":"f64_valid"')
    raw = once(raw,
        '  v54:u64 = call(v38,v44,v53,v52) {"function":"tnew"}\n',
        '  v140:u64 = const() {"value":1}\n'
        '  v141:u64 = const() {"value":4}\n'
        '  v54:u64 = call(v38,v44,v53,v52,v140,v141) {"function":"typed_descriptor"}\n')
    raw = once(raw, '"function":"pointwise_layout"', '"function":"integer_pointwise_layout"')
    raw = once(raw, '"function":"scalar_binary"', '"function":"f64_scalar_binary"')
    raw = once(raw,
        '  v136:u64 = call(v110,v134,v135) {"function":"put4"}\n',
        '  v142:u64 = const() {"value":8}\n'
        '  v136:u64 = call(v110,v134,v142,v135) {"function":"typed_store"}\n')
    raw = once(raw,
        '  v139:u64 = call(v120,v126,v121,v122,v123) {"function":"record"}\n  ret(v139)\n',
        '  ret(v126)\n')
    add(raw)
    raw = rename(before['scalar_binary'], 'scalar_binary', 'f64_scalar_binary')
    for old, new in [('addf','add64'),('subf','sub64'),('mulf','mul64'),('divf','div64')]:
        raw = once(raw, f'"function":"{old}"', f'"function":"{new}"')
    add(raw)

    add(rename(before['to_copy_tensor'], 'to_copy_tensor', 'f64_previous_to_copy_tensor'))
    change('to_copy_tensor', emit_copy_wrapper(), 'F64 cast pair routes to explicit noAD/source-target admission; all old pairs use exact old body.')
    add(emit_cast_admit()); add(emit_convert())
    raw = rename(before['scalar_previous_to_copy_tensor'], 'scalar_previous_to_copy_tensor', 'f64_copy_tensor')
    raw = once(raw, '"function":"to_convert_value"', '"function":"f64_convert_value"')
    raw = once(raw,
        '  v199:u64 = const() {"value":43}\n'
        '  v200:u64 = const() {"value":0}\n'
        '  v201:u64 = call(v158,v164,v199,v159,v200) {"function":"record"}\n'
        '  ret(v201)\n', '  ret(v164)\n')
    add(raw)

    # Only the casts gain target code4. Raw factory110 and private code3 stay refused.
    raw = once(before['sd_previous_to_command'],
        '  v397:bool = compare.gt(v395,v396)\n'
        '  branch v397 b33(v377,v378,v379,v381,v383,v384) b35(v377,v378,v379,v380,v381,v382)\n',
        '  v397:bool = compare.gt(v395,v396)\n'
        '  v427:u64 = const() {"value":4}\n'
        '  v428:bool = compare.ne(v395,v427)\n'
        '  v429:bool = bool.and(v397,v428)\n'
        '  branch v429 b33(v377,v378,v379,v381,v383,v384) b35(v377,v378,v379,v380,v381,v382)\n')
    change('sd_previous_to_command', raw, 'Target4 allowed only for108/109; original private3 and raw110 guards preserved.')
    add(rename(before['to_command'], 'to_command', 'f64_previous_to_command'))
    change('to_command', emit_to_wrapper(), 'All other to/shape/sum/permute/AD entrypoints explicitly refuse an F64 source.')

    raw = once(before['command_argument'],
        '  v86:bool = compare.eq(v84,v85)\n',
        '  v122:u64 = const() {"value":4}\n'
        '  v123:bool = compare.eq(v84,v122)\n'
        '  v124:u64 = const() {"value":2}\n'
        '  v125:bool = compare.ne(v73,v124)\n'
        '  v126:u64 = const() {"value":12}\n'
        '  v127:bool = compare.ne(v73,v126)\n'
        '  v128:u64 = const() {"value":13}\n'
        '  v129:bool = compare.ne(v73,v128)\n'
        '  v130:bool = bool.and(v125,v127)\n'
        '  v131:bool = bool.and(v130,v129)\n'
        '  v132:bool = bool.and(v123,v131)\n'
        '  v133:bool = compare.eq(v84,v85)\n'
        '  v86:bool = bool.or(v133,v132)\n')
    change('command_argument', raw, 'F64 low-op tensor arguments allow only binary2,raw set12,metadata13; all old dtype3 checks remain.')
    raw = once(before['typed_command'],
        '  v60:bool = compare.eq(v58,v59)\n',
        '  v94:u64 = const() {"value":4}\n'
        '  v95:bool = compare.eq(v58,v94)\n'
        '  v96:u64 = const() {"value":100}\n'
        '  v97:bool = compare.ne(v43,v96)\n'
        '  v98:bool = bool.and(v95,v97)\n'
        '  v99:bool = compare.eq(v58,v59)\n'
        '  v60:bool = bool.or(v99,v98)\n')
    change('typed_command', raw, 'For dtype4 only96 metadata,98 raw read,100 fill remain;99/101/102 refused.')

    # These public helpers would otherwise admit new generic-width views/saves.
    for name in ['rng_strided_view', 'save_public', 'data_alias']:
        raw = before[name]
        matches = re.findall(rb'  (v\d+):bool = compare\.eq\((v\d+),(v\d+)\)\n', raw)
        candidates = [(dst, val, constant) for dst,val,constant in matches
                      if b'  '+constant+b':u64 = const() {"value":3}\n' in raw]
        assert len(candidates) == 1, name
        dst, val, constant = [x.decode() for x in candidates[0]]
        maximum = max(map(int,re.findall(rb'\bv(\d+)',raw))) + 1
        a,b,c = (f'v{maximum+i}' for i in range(3))
        old = f'  {dst}:bool = compare.eq({val},{constant})\n'
        new = (f'  {a}:u64 = const() {{"value":4}}\n'
               f'  {b}:bool = compare.eq({val},{a})\n'
               f'  {c}:bool = compare.eq({val},{constant})\n'
               f'  {dst}:bool = bool.or({c},{b})\n')
        change(name, once(raw,old,new), 'New F64 views/explicit SavedTensor are not admitted in this minimal surface; old code3 refusal exact.')

    # Copy/rebuild preserves every unrelated byte including the module header.
    candidate = source
    for name in reasons:
        candidate = once(candidate, before[name], after[name])
    candidate += b''.join(added.values())
    restore = candidate
    for name, body in reversed(list(added.items())):
        assert restore.count(body) == 1, name
        restore = restore.replace(body, b'', 1)
    for name in reversed(list(reasons)):
        restore = once(restore, after[name], before[name])
    assert restore == source
    all_functions = definitions(candidate)
    assert len(all_functions) == 701 + len(added)
    assert len(reasons) == sum(before[n] != all_functions[n] for n in before)
    calls = {x.decode() for x in re.findall(rb'\{"function":"(\w+)"\}',candidate)}
    externals = {'rng_seed','rng_restore','rng_next','rng_next64','rng_unit32','rng_unit64'}
    assert not calls - set(all_functions) - externals

    output = HERE / 'candidate'
    output.mkdir(exist_ok=False)
    for directory in ['before','after','added','frozen-f64']:
        (output/directory).mkdir()
    (output/'baseline-runtime.hepta').write_bytes(source)
    (output/'runtime.hepta').write_bytes(candidate)
    for name in reasons:
        (output/'before'/f'{name}.hepta').write_bytes(before[name])
        (output/'after'/f'{name}.hepta').write_bytes(after[name])
    for name, body in added.items():
        (output/'added'/f'{name}.hepta').write_bytes(body)
    for name, body in scalar.items():
        (output/'frozen-f64'/f'{name}.hepta').write_bytes(body)
    transition = {
        'schema':'heptatorch.public-f64-source-candidate.v1',
        'status':'SOURCE_ONLY_NOT_COMPILED_NOT_RUN',
        'baseline_sha256':BASE, 'source_sha256':sha(candidate),
        'functions_before':701, 'functions_after':len(all_functions),
        'old_functions_byte_identical':701-len(reasons),
        'old_functions_modified':len(reasons), 'functions_added':len(added),
        'full_source_inverse_to_823':True,
        'compiler_executed':False,'runtime_executed':False,'torch_executed':False,
        'descriptor_bytes':672,'public_dtype':4,'private_scalar_dtype':3,
        'step_abi_changed':False,'support_units_changed':False,
        'changed':{n:{'before_sha256':sha(before[n]),'after_sha256':sha(after[n]),'reason':why}
                   for n,why in reasons.items()},
        'added':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in added.items()},
        'frozen_f64_source_sha256':F64,
        'numerical_bodies_byte_identical':numerical_names,
        'shared_numerical_helpers_byte_identical':['getr','shrjam','packf'],
        'standalone_sqrt64_archived_not_exposed':sha(scalar['sqrt64']),
        'original_f64_oracle_denominator':55,
        'original_torch_sqrt_groups_failed':4,
        'original_torch_sqrt_mismatches':4008,
        'original_tests_or_expected_values_modified':False,
        'inputs':[{'path':str(p),'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(p.stat().st_mode)}
                  for p,b in [(source_path,source),(f64_path,numerical)]],
    }
    (output/'transition.json').write_text(json.dumps(transition,indent=2,sort_keys=True)+'\n')
    assert source_path.read_bytes()==source and f64_path.read_bytes()==numerical
    print(json.dumps({k:transition[k] for k in ['status','source_sha256','functions_after','old_functions_modified','functions_added']}))


if __name__ == '__main__':
    main()
