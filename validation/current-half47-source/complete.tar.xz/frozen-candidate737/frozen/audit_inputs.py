#!/usr/bin/env python3
"""Read-only source/input audit. Never imports Torch or runs an application."""
import ast
import hashlib
import json
import random
import re
import struct
from pathlib import Path

ROOT = Path('/workspace/scratch/fd98c6279214/HeptaTorch')
F64 = Path('/tmp/heptatorch-f64-integration-review/source-01/candidate')
RNG = Path('/workspace/scratch/fd98c6279214/f64-native719-build-source-01/source/units/rng03.hepta')
OUT = Path(__file__).resolve().parent
BASE_SHA = 'e2eedf870e306572672817cfc98bcf49d9aeacc0657c04dbaf50e5e6f5ceb66d'
SHA = lambda b: hashlib.sha256(b).hexdigest()
inputs = {}


def read(path):
    path = path.resolve()
    raw = path.read_bytes()
    inputs[str(path)] = {'bytes': len(raw), 'sha256': SHA(raw)}
    return raw


def functions(raw):
    matches = list(re.finditer(rb'^fn ([^(]+)\(', raw, re.M))
    return {m[1].decode(): raw[m.start():matches[i+1].start() if i+1 < len(matches) else len(raw)]
            for i, m in enumerate(matches)}


runtime = read(F64 / 'runtime.hepta')
assert SHA(runtime) == BASE_SHA
core = functions(runtime)
assert len(core) == 719
f16raw = read(ROOT / 'tools/dtype-f16/f16.hepta')
bf16raw = read(ROOT / 'tools/dtype-bf16/bf16.hepta')
f16, bf16, rng = functions(f16raw), functions(bf16raw), functions(read(RNG))
assert f16['round_f16'] == rng['round_f16']
assert bf16['round_bf16'] == rng['round_bf16']
assert not {'round_f16', 'widen_f16', 'round_bf16', 'widen_bf16'} & core.keys()
assert 'widen_bf16' not in bf16
rng_exports = re.search(rb'^exports\(([^)]+)\)', RNG.read_bytes(), re.M)[1].decode().split(',')
assert 'round_f16' not in rng_exports and 'round_bf16' not in rng_exports
owner = read(F64 / 'owner_f64.py')
assert SHA(owner) == 'db8dfd3ce4c845049a521a2612be4b53c295248daa748c31da3b2ccdd22dfc61'

# Execute only the exact original pure input generators. No original main,
# compiler, native call or Torch reference expression is selected.
f16script = read(ROOT / 'tests/f16_oracle.py')
f16tree = ast.parse(f16script)
selected = [n for n in f16tree.body if isinstance(n, ast.FunctionDef)
            and n.name in {'word', 'half_value', 'corpus'}]
assert {n.name for n in selected} == {'word', 'half_value', 'corpus'}
env = {'struct': struct, 'random': random}
exec(compile(ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[])),
             'frozen-f16-input-generators-only', 'exec'), env)
f16corpus = env['corpus']()
f16report = json.loads(read(ROOT / 'validation/hosted-native-f16.json'))
f16observed = next(r for r in f16report['reports'] if r['reference'] == 'pytorch')
assert f16observed['status'] == 'PASS' and f16observed['cases'] == 16
assert f16observed['source_sha256'] == SHA(f16raw)
assert f16observed['oracle_script_sha256'] == SHA(f16script)
assert len(f16corpus) == 9


def row(label, ordinal, mode, values, target, old=None):
    unit, result_unit = (4, 2) if mode == 0 else (2, 4)
    raw = b''.join(v.to_bytes(unit, 'little') for v in values)
    packet = struct.pack('<II', mode, len(values)) + raw
    if old is not None:
        assert old['request_sha256'] == SHA(packet) and old['input_count'] == len(values)
        assert old['status'] == 'PASS'
    return {'ordinal': ordinal, 'name': label, 'original_mode': mode,
            'kind': 'numeric-group-including-empty', 'input_count': len(values),
            'original_packet_bytes': len(packet), 'original_packet_sha256': SHA(packet),
            'input_raw_sha256': SHA(raw), 'input_width': unit, 'output_width': result_unit,
            'proposed_source_dtype': 0 if mode == 0 else target,
            'proposed_target_dtype': target if mode == 0 else 0,
            'proposed_tensor_sequence': [97, 108, 96, 13, 98],
            'original_input_words_preserved': True,
            'recorded_per_case_request_sha_matched': old is not None,
            'original_reference_packed_sha256': None if old is None else old['reference_packed_sha256'],
            'ordinary_Tensor_native_executed': False,
            'largest_factory_request_bytes': 160 + len(raw)}


mapped_f16 = [row(name, i, mode, values, 5, f16observed['rows'][i])
              for i, (name, mode, values) in enumerate(f16corpus)]
f16main = next(n for n in f16tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
refusal_assign = next(n for n in f16main.body if isinstance(n, ast.Assign)
                      and any(isinstance(t, ast.Name) and t.id == 'refusals' for t in n.targets))
f16refusals = eval(compile(ast.Expression(refusal_assign.value), 'f16-original-refusal-inputs', 'eval'),
                  {'struct': struct})
assert len(f16refusals) == 7
for i, (name, packet) in enumerate(f16refusals, 9):
    old = f16observed['rows'][i]
    assert old['case'] == name and old['request_sha256'] == SHA(packet) and old['status'] == 'PASS'
    mapped_f16.append({'ordinal': i, 'name': name, 'kind': 'standalone-packet-refusal',
                       'original_packet_sha256': SHA(packet), 'original_packet_bytes': len(packet),
                       'old_expected_status': 1, 'new_Tensor_case_transferred': False,
                       'reason': 'Standalone <II> packet is not the Tensor HTORQ protocol.'})

bf16script = read(ROOT / 'tests/bf16_oracle.py')
bf16tree = ast.parse(bf16script)
start = next(i for i,n in enumerate(bf16tree.body) if isinstance(n, ast.Assign)
             and any(isinstance(t, ast.Name) and t.id == 'rng' for t in n.targets))
stop = next(i for i,n in enumerate(bf16tree.body) if isinstance(n, ast.For)
            and isinstance(n.target, ast.Name) and n.target.id == 'packet')
bf16corpus = []
env = {'random': random, 'compare': lambda mode, values: bf16corpus.append((mode, values))}
exec(compile(ast.fix_missing_locations(ast.Module(body=bf16tree.body[start:stop], type_ignores=[])),
             'frozen-bf16-input-generators-only', 'exec'), env)
assert len(bf16corpus) == 17
bf16names = ['round-special-f32'] + ['round-seeded-random-block-%02d' % i for i in range(12)]
bf16names += ['round-every-seventh-upper-word-tie', 'widen-all-65536-encodings', 'round-empty', 'widen-empty']
mapped_bf16 = [row(name, i, mode, values, 6)
               for i, (name, (mode, values)) in enumerate(zip(bf16names, bf16corpus))]
bf16refusals = eval(compile(ast.Expression(bf16tree.body[stop].iter), 'bf16-original-refusal-inputs', 'eval'),
                   {'struct': struct})
bf16refusal_names = ['short-header', 'unknown-mode', 'truncated-f32', 'count-limit-plus-one', 'extra-payload']
assert len(bf16refusals) == 5
for i,(name, packet) in enumerate(zip(bf16refusal_names,bf16refusals),17):
    mapped_bf16.append({'ordinal': i, 'name': name, 'kind': 'standalone-packet-refusal',
                        'original_packet_sha256': SHA(packet), 'original_packet_bytes': len(packet),
                        'old_expected_status': 1, 'new_Tensor_case_transferred': False,
                        'reason': 'Standalone <II> packet is not the Tensor HTORQ protocol.'})
bf16report = json.loads(read(ROOT / 'validation/hosted-native-bf16.json'))
assert bf16report['native_source_sha256'] == SHA(bf16raw)
assert bf16report['comparison']['cases'] == 22 and bf16report['comparison']['failed_cases'] == 0
assert sum(len(values) for _,values in bf16corpus) == (
    bf16report['comparison']['bit_exact_non_nan'] + bf16report['comparison']['nan_classification'])

changes = {
    'dtype_width': 'Add exact 5/6 -> 2; keep all 0..4 widths and unknown -> 0.',
    'typed_from_wire': 'Factory97 explicit allow 0/1/2/4/5/6; private3 still refused.',
    'tset': 'For 5/6 reject raw bits >0xffff before any store or Version bump; retain previous checks.',
    'typed_fill': 'For 5/6 reject raw bits >0xffff before any store or Version bump; retain no_grad and version checks.',
    'command_argument': 'New 5/6 low-op Tensor arguments allow only raw set12 and metadata13; do not grant existing F64 binary2 permission.',
    'typed_command': 'New 5/6 same narrow96/98/100 surface; refuse99/101/102.',
    'to_command': 'New 5/6 permit only108/109; all other to/shape/sum/permute/AD commands refuse.',
    'to_copy_tensor': 'Intercept if either endpoint is5/6; exact cast-pair noAD admission; all old paths unchanged.',
    'sd_previous_to_command': 'Permit exact targets5/6 only for108/109; private3 and raw110 target<=2 remain unchanged.',
    'data_alias': 'Explicit refusal for5/6 in minimal no-ViewInfo scope, preserving3/4 rules.',
    'save_public': 'Explicit refusal for5/6, preserving3/4 rules.',
    'rng_strided_view': 'Explicit refusal for5/6 also closes legacy69 bypass; public111 is refused in to_command.',
    'scalar_previous_dtype_audit': 'Explicit dtype domain adds5/6, preserving all noAD/private3 checks.',
    'dtype_audit': 'Call an additional5/6 noAD/noSaved/noViewInfo audit which retains original F64/private3 checks.',
}
preserve = ['typed_descriptor','scalar_previous_typed_descriptor','scalar_previous_typed_from_wire',
            'typed_load','typed_store','typed_copy_from_wire','taddr','tget','typed_iteration_address',
            'typed_clone','dist_dense_layout','to_tensor','shape_previous_to_command',
            'f64_copy_tensor','f64_convert_value','f64_cast_admit','f64_dtype_audit',
            'version_can_bump','bump_version','storage_capacity','to_view_logical_offset']
function_rows = {}
for name in list(changes) + preserve:
    body = core[name]
    function_rows[name] = {'bytes': len(body), 'sha256': SHA(body),
                           'line': runtime[:runtime.index(body)].count(b'\n') + 1,
                           'planned_action': changes.get(name, 'Retain entire719 body unchanged in minimal conversion scope.'),
                           'callees': sorted(set(re.findall(rb'"function":"([^"]+)"',body)))}
    function_rows[name]['callees'] = [v.decode() for v in function_rows[name]['callees']]

bf16_entry = bf16['entry']
inline = re.search(rb'  v118:u64 = const\(\) \{"value":16\}\n  v119:u64 = int.shl.checked\(v117,v118\)\n', bf16_entry)[0]
comparison_spans = {}
f16_loop = next(n for n in ast.walk(f16main) if isinstance(n, ast.For)
                and isinstance(n.target,ast.Tuple) and 'index' in ast.unparse(n.target)
                and 'src' in ast.unparse(n.target))
bf16_compare = next(n for n in bf16tree.body if isinstance(n,ast.FunctionDef) and n.name=='compare')
bf16_loop = next(n for n in ast.walk(bf16_compare) if isinstance(n, ast.For))
for name,script,node in [('f16',f16script,f16_loop),('bf16',bf16script,bf16_loop)]:
    span='\n'.join(script.decode().splitlines()[node.lineno-1:node.end_lineno])+'\n'
    comparison_spans[name]={'source_span_sha256':SHA(span.encode()),'lines':[node.lineno,node.end_lineno]}

report = {
    'schema':'heptatorch.half-tensor.source-audit.v1',
    'status':'SOURCE_AND_ORIGINAL_INPUTS_AUDITED_NO_NEW_RUNTIME',
    'baseline_source_sha256':BASE_SHA,'baseline_functions':719,'Generator_merged':False,
    'proposed_public_dtype_codes':{'5':'IEEE binary16','6':'bfloat16'},
    'private_dtype3_remains_unchanged':True,'descriptor_bytes_unchanged':672,
    'new_HIA_runtime_written':False,'compiler_executed':False,'native_executed':False,'Torch_executed':False,
    'source_inputs':inputs,
    'numeric_reuse':{
        'round_f16':{'sha256':SHA(f16['round_f16']),'bytes':len(f16['round_f16']),'identical_existing_rng_body':True},
        'widen_f16':{'sha256':SHA(f16['widen_f16']),'bytes':len(f16['widen_f16']),'identical_existing_rng_body':False},
        'round_bf16':{'sha256':SHA(bf16['round_bf16']),'bytes':len(bf16['round_bf16']),'identical_existing_rng_body':True},
        'BF16_widen_inline':{'entry_sha256':SHA(bf16_entry),'span_sha256':SHA(inline),
                             'original_operation':'u64 input16 << 16','standalone_widen_function_exists':False,
                             'new_wrapper_requires_explicit_span_derivation':True},
        'baseline_rng_exports':rng_exports,'round_helpers_exported_in719':False},
    'required_changed_old_bodies':changes,'source_functions':function_rows,
    'original_comparison_spans':comparison_spans,
    'F16':{'original_denominator':16,'mapped_numeric_groups':9,'standalone_refusals_not_transferred':7,
           'total_numeric_input_values':sum(len(v) for _,_,v in f16corpus),
           'recorded_exact_non_nan':f16observed['exact_non_nan'],'recorded_nan_classification':f16observed['nan_classification'],
           'all16_frozen_request_hashes_matched':True,'rows':mapped_f16},
    'BF16':{'original_denominator':22,'mapped_numeric_groups':17,'standalone_refusals_not_transferred':5,
            'total_numeric_input_values':sum(len(v) for _,v in bf16corpus),
            'recorded_exact_non_nan':bf16report['comparison']['bit_exact_non_nan'],
            'recorded_nan_classification':bf16report['comparison']['nan_classification'],
            'per_case_labels_are_new_ordinal_descriptions':True,
            'original_aggregate_has_no_per_case_packet_hashes':True,
            'old_failed_install_run_retained':bf16report['retained_failure'],'rows':mapped_bf16},
    'minimum_next_numeric_group_denominator':26,'original38_PASS_not_transferred':True,
    'additional_tensor_owner_refusal_and_allocation_cases_required':True,
    'full_dtype_layout_gate':'OPEN','whole_pytorch_rewrite_complete':False,
}
assert len(mapped_f16)==16 and len(mapped_bf16)==22
assert max(r['largest_factory_request_bytes'] for r in mapped_f16+mapped_bf16 if 'largest_factory_request_bytes' in r)==800160
for path,pin in inputs.items():
    now=Path(path).read_bytes();assert len(now)==pin['bytes'] and SHA(now)==pin['sha256']
report['all_read_inputs_unchanged']=True
target=OUT/'source-audit.json'
target.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':report['status'],'report':str(target),'bytes':target.stat().st_size,
                  'sha256':SHA(target.read_bytes()),'native_executed':False,'Torch_executed':False}))
