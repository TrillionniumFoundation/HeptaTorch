# F16 / BF16 普通 Tensor 迁移：719 基线源码审计

## 本次结论与边界

可以在现有 672 字节 descriptor、Tensor / Storage / Version 所有权协议上接入两种 2 字节类型。建议公开编码 `5 = IEEE binary16`、`6 = bfloat16`；`3` 继续只表示原 private wrapped binary64 scalar，`4` 继续表示独立的普通 F64。

本次仅审计源码及原始测试输入，没有生成新 runtime，没有调用 HIA、编译器、链接器、Torch、远程进程或 Git。基线严格为 719 函数源 `e2eedf870e306572672817cfc98bcf49d9aeacc0657c04dbaf50e5e6f5ceb66d`，**尚未合入 Generator712**。719 的冷构建并不替代 F64 的实际 Tensor 资格，更不替代未来 F16/BF16 资格。

机器可读清单 `source-audit.json` 保存所有输入 SHA、38 个原用例的逐项映射、计划修改函数的当前完整 body SHA 与行位置，以及可原样保留函数的调用关系。`audit_inputs.py` 仅提取原测试里的纯输入生成语句；没有调用原 main、任何 reference 表达式或生产执行入口。

## 一、公开类型、ABI 与必要 guard

| 位置 | 719 当前行为 | 最窄迁移 |
|---|---|---|
| descriptor offset 576 | 0:F32、1:Bool、2:I64、3:private scalar、4:F64 | 只新增 5/6；不改变字段位置或 672 字节长度 |
| `dtype_width` | 0→4，1→1，2/3/4→8，其他→0 | 5/6→2；未知类型仍为 0 |
| `typed_from_wire` / command97 | 只准 0/1/2/4 | 显式准 0/1/2/4/5/6；3 继续 cause7 |
| `typed_descriptor` | 3 必须 rank0 且 requires_grad0 | 整函数保持；不要把“<=6”当公开类型许可 |
| `scalar_previous_typed_descriptor` | width 参数化；非 0 dtype + requires_grad1 cause5 | 整函数保持；从现有 width 得到 2 字节分配 |
| `command_argument` | F64 普通低位算子只准 2/12/13；private3 只准13 | 5/6 只准12/13，不承接 F64 的二元运算许可 |
| `typed_command` | 4 的99/101/102被拒，96/98/100可用 | 对5/6应用同样拒绝；保留旧0..4所有分支 |
| `to_command` | source4只允许108/109进入旧解析器 | source5/6同样仅允许108/109，拒绝sum/shape/permute/AD |
| `sd_previous_to_command` | 108/109 的 target4 是特例；raw110仍 target<=2 | 只给108/109加入 target5/6；不修改 raw110 或 private3 guard |
| `data_alias` / `save_public` / `rng_strided_view` | 明确拒绝3/4 | 本阶段也拒绝5/6，防止低位旧入口/command69绕过外层111拒绝 |

5/6 没有与已分配 Tensor dtype 冲突：当前完整 width 表把二者判为无效，独立 F16/BF16 packet 的 mode0/1 是另一协议，不能当作 Tensor dtype 号。源码中相同整数也用于 opcode、slot kind 或 offset；那些域不应改动。

本阶段支持的普通 Tensor 操作为：97原始位创建、13形状/布局元数据、96类型元数据、98原始位读取、12原始位单元素写入、100原始位 fill，以及108 `to` /109 `_to_copy`。存储所有权、发布/释放、弱引用、状态审计等既有管理操作继续经过原协议。此表不承诺 Python API、自动混合类型提升、二元算术、sum、sqrt、通用视图或 AD。

## 二、2 字节 Storage 追踪与一个不可省略的修改

**不能只扩展 dtype_width 和类型白名单。** `tset` 与 `typed_fill` 当前对非 I64/F64 的原始值只验证 `<= 0xffffffff`；若直接放开5/6，`typed_store(width=2)` 会静默丢弃 bit16..31。新公开5/6必须在任何 store / Version bump 前拒绝 `raw_bits > 0xffff`，保留 cause7 与整帧 rollback。该问题是源码路径分析，不是一次已执行的半精度失败。

| 路径 | 已审实际实现 | 处理 |
|---|---|---|
| `typed_load` / `typed_store` | `object_address` 解 tagged 地址，按 width 逐字节读写；小端移位 `8*i` | 可整函数复用 width2；不换成 getw/putw 的8字节写入 |
| `scalar_previous_typed_from_wire` | payload bytes 必须精确等于 numel×width；metadata 配置8字节对齐；真实 payload逐字节复制 | 通过显式公开 factory gate 后原样复用；2字节数据不要求8字节载入 |
| `scalar_previous_typed_descriptor` | shape/rank/numel限额原样，alloc(numel×width)，清完整672字节，真实新T/S/V | 原样复用；原非F32 noAD guard排除后面的F32专用梯度分配 |
| `storage_capacity` / allocator | 逻辑 Storage bytes 与16字节 extent容量分开 | 不把 `capacity` 当 `numel×2`；owner应检查 logical bytes=2×numel，另保留原extent/pool账本 |
| `taddr` | descriptor[16] 已包含真实 Storage 起点和 byte offset；按元素 strides 求偏移后乘 dtype_width | width2有效；不能额外再加一次 descriptor[232] |
| `tget` | numel界限、真实Storage live、起点差/剩余bytes及width检查后 typed_load | 原样复用 |
| `typed_iteration_address` | 按轴序计算元素地址，最后乘 dtype_width | 本阶段无需改变；随机/dropout入口不因width新增而开放 |
| command98 | read count按元素、响应长度按 count×width，tget后 typed_store到响应buffer | width2原样复用；读越界cause2，不和tset越界cause7混为一类 |
| `typed_clone` | typed_descriptor、dist_dense_layout、逐元素tget/taddr/typed_store | 数值搬运可以复用，但不能由此开放不在本阶段的clone/AD旧入口 |
| `f64_copy_tensor` 的复制骨架 | 依source逻辑顺序tget，转换后按新target布局taddr，写target width | 另派生半精度copy helper，只改明确的函数名/convert callee；不要把F64 converter改成泛型 |
| `dist_dense_layout` | 保留dense源的元素strides，非dense按既有轴序构造dense输出 | 整函数复用。strides单位仍是元素，不随width减半 |
| `version_can_bump` / `bump_version` | 操作真实Version slot，写前验证上限 | 保持完整原函数；成功12/100各一次，拒绝必须不变 |

### 非零 offset 与 stride 的范围

最小迁移沿用 F64 的“新类型结果无 ViewInfo”范围。F32输入可以是已有111构造的非零 offset、转置dense、切片、零stride或overlap view；半精度cast按`tget`读取真实输入，并创建offset0的新Storage。`preserve_format`结果仍可有非连续但dense的元素strides，所以半精度 raw read/write、同dtypecopy、回转F32必须覆盖这类实际布局。

**半精度source自身的非零storage_offset在这个范围内不可公开构造。** 不应为方便测试偷偷开放111或写入合成owner。若下一步需要完整半精度 `as_strided`，须作为另一个明确增量：审 `to_strided_view → rng_strided_view → scalar_previous_rng_strided_view`、保留base引用和共享Version、扩展新owner的ViewInfo域，再实际验证 offset×2、alias、overlap与生命周期。

`to_view_logical_offset` 仍包含 `byte_offset >> 2`，它在现有F32 backward路径使用。保持AD拒绝使本阶段不会进入该路径；不能全局把这个常量改成1，也不能据可参数化的前向读取就宣称半精度backward可用。

## 三、数值 body 复用与分区问题

| 原函数/片段 | 精确来源 SHA-256 | 迁移 |
|---|---|---|
| `round_f16`，3238B | `bfbc7cdfe038b6c70e8fbdf93b7b121c072a571764069391b23964909eec7821` | 与719的rng03私有body逐字相等；保全部字节 |
| `widen_f16`，2408B | `239efc00626676a06b57b3fb3f56a120d208c666544dfe64bd15232328d1b52f` | 原独立F16完整body逐字加入，无需新算法 |
| `round_bf16`，781B | `de58e57a97f386750e823a7f0e90064fb01536919acc10cc713b232a75648129` | 与719的rng03私有body逐字相等 |
| BF16 widen原entry两指令 | `a148fc66fe2c3c658cf50d0693f7298c468f5ac673ada87b676ef8eb698b8da7` | 原来是`const16; input16 << 16`，不存在独立widen函数；新增wrapper必须记录该片段到新SSA参数的明确派生 |

现有719 rng03只export六个RNG函数，**没有export round_f16 / round_bf16**。不能直接让新core调用这两个私有名字并声称原分区可链接。保719支持单元整字节不动时，可把两个精确body加入core；编译器已有各unit私有同名helper，但必须在新partition报告里明确出现新增core函数。另一条可审路径是只增加两个export、绑定新rng SHA及完整逆向，同时显式更新builder/partition支持pin。

Generator712候选的rng03已经export这两个round函数和`cg_putw`，但不能在719审计中借用该资格或悄悄换支持单元。若根任务先正式合并Generator，应在合成后的新baseline上重新证明并复用该已导出接口，避免多留两个重复core body；owner四参数entropy ABI也是另一独立转换。本计划未做合成。

### 新转换 helper 的明确语义

`half_cast_admit(state, source, target_dtype, format)`只接受：

- 0→5、5→0、0→6、6→0；
- 5→5、6→6的显式同dtypecopy；
- source requires_grad必须0，format仍沿用0/1。

5↔6、4↔5/6、1/2↔5/6、private3以及未知dtype应按这个有限范围明确cause7；F32 requires_grad→5/6为cause5。旧0↔4、旧0/1/2的所有路径沿用719原body。

`half_convert_value(bits, source_dtype, target_dtype)`先判断同dtype并原样返回全部16位，再分派四种转换。不能对同dtypecopy先widen再round，否则会改变NaN原始payload。BF16 widen保留原左移，不能临时添quiet-bit以迎合别的比较器。

实际108同dtype且copy=False是否返回同一Tensor，继续走原`to_tensor`的copy/format判断；109以及必须复制的108走新copy helper。原格式决策不应被一句“contiguous就复制”替代，最终别名关系由固定Torch参考实际记录。

## 四、owner与事务边界

独立owner以719的`candidate/owner_f64.py`为基底（SHA `db8dfd3ce4c845049a521a2612be4b53c295248daa748c31da3b2ccdd22dfc61`），其全部84Q字段解码、Storage extent/pool、T/S/V/weak/hold计数、强引用可达性、原F64/private3断言保留。

明确修改三处dtype域：descriptor的`dtype-code`、Weak row dtype、Hold row dtype；width表扩为`(4,1,8,8,8,2,2)`。不能写“所有原predicate不变”，应说明原0..4域保持而新域显式增加。新role要求真实liveT/S/V、logicalStorageBytes=2×numel、byteoffset0、requires_grad/op/Saved/ViewInfo相关字段为0。dtype4原role、private3的rank0/numel1/8B/Version0断言一字不改。

为97与108/109新增半精度metadata观察器：新结果必须有独立Tensor incarnation / Storage / Version、初始Version0，source完整84Q及全部Storage字节保持；真实same-dtype alias只在既有108无copy分支。12/100除完整owner复核外，另外验证原始Storage差分只覆盖应写的2字节元素，Version与Torch实际观察一致。

已有`weak_create`把descriptor dtype写入Weak row的offset24；`weak_lock`把同一值写入新Hold row的offset32，两者不做F32投影。其旧body可以保持，但新测试应实际覆盖live weak lock、原Tensor释放后只保Hold、Hold释放后weak失效的顺序；三个新增dtype域不能只扩descriptor而忘记Weak/Hold。这里的weak lock返回Storage Hold，不是凭空重建Tensor。

保持原入口事务副本、失败rollback和结束loan规则。所有新失败都应保存完整request/response、失败前后owner原字节/地址/映射、输入Storage与5056B RNG，以及最终exit/双EOF。不得仅凭cause3判断“新cast分配处已到达”；OOM应先证明descriptor页和T/S/V/Hold/Public资源足够、同限制下普通查询成功，并在解除RLIMIT后提交**同一请求**实际成功。

## 五、原16 + 22用例逐项迁移

原F16源 `85b9387deccbf67f78bc28da4994ae691b144dbaa927d66d5677d94d6f70a105`；原oracle `34940af7cd7c4dbb8de376e8e041d6c7f3820a6a6fbbea07bf3d6ec61562ccd9`。原16项请求SHA已在本次纯输入重建中全部对上冻结报告；821,554个数值输入保持原顺序。

| F16原序号 | 原分组 | 数值个数 | 新Tensor映射 |
|---|---|---:|---|
| 0 | widen-all-65536-encodings | 65,536 | 97(dtype5原位)→108(target0)→96/13/98 |
| 1 | round-all-exact-half-values | 65,536 | 97(dtype0原位)→108(target5)→96/13/98 |
| 2 | every finite boundary and neighbors | 190,464 | 同上，保原有带符号midpoint/neighbor顺序 |
| 3 | seeded F32 encodings | 100,000 | 同上，保seed43019 |
| 4 | special F32 encodings | 18 | 同上 |
| 5 | round-empty | 0 | 空F32→F16，仍实际创建/发布/释放 |
| 6 | widen-empty | 0 | 空F16→F32 |
| 7 | round count limit | 200,000 | 原整组，不缩小原输入 |
| 8 | widen count limit | 200,000 | 原整组，不缩小原输入 |
| 9–15 | short header、unknown mode、truncated F32、truncated half、extra payload、200001、u32-max | — | 7个原独立packet拒绝原样保留；不计作Tensor PASS |

原BF16源 `2f4790a050ccf24bc869c4a9a46c4be4fd740355f363b086eac512e360718469`；oracle `b6faeb43030d713cbdffb9bb0f228e561d6ce8532fd4a6cb6a3a4bdd782c0827`。原脚本没有逐case名字/报告hash；本次按原top-level输入语句和seed1729严格保序生成描述标签、原packet SHA及raw SHA，不冒称这些SHA是原hosted报告字段。

| BF16原序号 | 原输入语句 | 数值个数 | 新Tensor映射 |
|---|---|---:|---|
| 0 | special F32 words | 15 | 97(dtype0)→108(target6)→96/13/98 |
| 1 | random block i=0 | 1 | 同上 |
| 2–3 | random blocks i=1,2 | 各19 | 同上 |
| 4–12 | random blocks i=3..11 | 各1,301 | 同上，9个独立原组保持 |
| 13 | `(i<<16)|0x8000`, i步长7 | 9,363 | 同上，保原ties输入 |
| 14 | all65536 BF16 encodings | 65,536 | 97(dtype6)→108(target0)→96/13/98 |
| 15 | round-empty | 0 | 空F32→BF16 |
| 16 | widen-empty | 0 | 空BF16→F32 |
| 17–21 | short header、unknown mode、truncated F32、200001、extra payload | — | 5个原独立packet拒绝原样保留；不计作Tensor PASS |

新Tensor数值分母因此是**26个原数值组**：F16 9、BF16 17；不应报告“38/38 Tensor迁移通过”。原16/22各自报告与原BF16安装失败历史保持原状。另新增的Tensor入口、owner、copy、布局、Version和OOM组单独计数。

最大97请求按既有160B header/config加payload为800,160B；原200,000输入无需为了1MiB wire限制减半或拆掉旧分组。F32输出最大800,000B原数据仍在响应限额内。rank1轴长200,000也未超过719现有262,144限额。

### 比较规则不能混用

- F16原比较：非NaN逐bit相等；NaN检查actual分类和quiet bit、expected分类，不要求payload相等。
- BF16原比较：非NaN逐bit相等；NaN只检查actual分类，**未要求actual quiet bit**。不要将F16更强的quiet规则悄悄套给原BF16组。
- `source-audit.json`记录两条原比较loop的源码span SHA。未来producer/reader应保完整原文件和可逆派生，实际读取固定Torch结果；本次没有生成任何新数值期望。

## 六、新Tensor边界的最低验收清单

1. 两dtype各自rank0、empty、奇数numel1/3/17、含全部NaN位的原始factory/read/同dtypecopy；证明logicalStorageBytes=2N与extent padding分开，最后一个元素没有8字节越界写。
2. 12/100成功写入0、0xffff、sNaN/qNaN、±0，检查邻元素及相邻Storage不变；0x10000、0xffffffff、1<<32、MAX_U64必须完整rollback。原tset越界cause7与raw98越界cause2各保一组。
3. F32输入由已有111生成转置dense、非zero offset、切片holes、zero-stride和overlap；cast preserve与contiguous格式、回转F32、真实dense半精度source同dtypecopy都对固定Torch。无公开半精度非zero-offset输入的范围限制在报告中明确保留。
4. 108 copyFalse / copyTrue与109，包括同dtype逐bitcopy和真实Tensor/Storage/Version alias关系；FE同包引用必须走真实resolve，不由host伪造中间owner。
5. 对两个半精度dtype，双向混合0/1/2/3/4/另一半精度的二元操作、直接半精度互转、非本阶段casts、AD/explicitSaved/views/sum等明确拒绝；0↔4旧F64路径及private3原scalar32不能受影响。
6. F32 requires_grad输入→半精度以及半精度factory requires_grad=1拒绝，完整源Storage/Version/RNG不变。
7. 各方向cast的真实allocation failure与同命令恢复：例如F32零stride[262144]→半精度524,288B，半精度[131072]→F32同样524,288B。用真实资源余量/RLIMIT和完整owner映射断言，不能用事先编好的FAIL替代。
8. 每个独立child必须实际 `/proc/PID/exe`绑定新ELF、完整原始frame与owner-before/after、最终exit0/双EOF、输入前后SHA不变；任意失败保留原报告并使整组FAIL。

完成以上源码候选时，整源逆向必须精确恢复本719源；新增数值body逐字证明，必要14个旧body各留before/after和修改理由；descriptor、`HIASTKS1`三参数session-step ABI及未合Generator状态单独写清。新的函数/分区数量及ELF只能由真正新partition/coldbuild观察后绑定，不预先宣称。
