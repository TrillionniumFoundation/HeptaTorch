#!/usr/bin/env python3
"""Whole-source and consumer census; no HIA evaluation or application I/O."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
SOURCE = 'b2430af6ab7070efda67a1f7e9e2a8a83e273d57e44728b5492f0ee9d03e8fc3'
BASE = '6c9fc24a2006163d98827f0c464162dc635ded7e4fc284cbad4b30a692022f04'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def need(value, rule):
    if not value:
        raise AssertionError(rule)


def functions(raw):
    values = [(m[1].decode(),m[0]) for m in re.finditer(
        rb'^fn (\w+)\([^\n]* entry\(\w+\)\n.*?^end\n',raw,re.M|re.S)]
    need(len(values)==len(dict(values)),'no duplicate defined function names')
    return dict(values)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    source=(HERE/'candidate/runtime.hepta').read_bytes()
    parent=(HERE/'frozen/runtime730.hepta').read_bytes()
    need(sha(source)==SOURCE and sha(parent)==BASE,'whole source identities')
    current,old=functions(source),functions(parent)
    transition=json.loads((HERE/'candidate/transition.json').read_bytes())
    changed=transition['changed'];added=transition['added']
    need(len(current)==737 and len(old)==730 and len(changed)==14 and len(added)==7,'change census')
    inverse=source
    for name,row in added.items():
        raw=(HERE/'candidate/added'/f'{name}.hepta').read_bytes()
        need(sha(raw)==row['sha256'] and current[name]==raw and inverse.count(raw)==1,'added complete body '+name)
        inverse=inverse.replace(raw,b'',1)
    for name,row in changed.items():
        before=(HERE/'candidate/before'/f'{name}.hepta').read_bytes()
        after=(HERE/'candidate/after'/f'{name}.hepta').read_bytes()
        need(sha(before)==row['before_sha256'] and sha(after)==row['after_sha256']
             and old[name]==before and current[name]==after and inverse.count(after)==1,'modified complete body '+name)
        inverse=inverse.replace(after,before,1)
    need(inverse==parent,'complete source inverse to730')
    need({n for n in old if current[n]!=old[n]}==set(changed),'all unchanged parent bodies exact')
    generic=['typed_descriptor','scalar_previous_typed_descriptor','scalar_previous_typed_from_wire',
        'typed_load','typed_store','typed_copy_from_wire','typed_iteration_address',
        'taddr','tget','typed_clone','dist_dense_layout','to_tensor','shape_previous_to_command',
        'f64_copy_tensor','f64_convert_value','f64_cast_admit','f64_dtype_audit',
        'version_can_bump','bump_version','storage_capacity','to_view_logical_offset',
        'integer_result_dtype','integer_native_dropout','public_f32']
    need(all(current[n]==old[n] for n in generic),'all generic byte/shape/Version and prior dtype gates unchanged')
    original_copy=current['half_copy_tensor'].replace(b'fn half_copy_tensor(',b'fn f64_copy_tensor(',1)
    original_copy=original_copy.replace(b'"function":"half_convert_value"',b'"function":"f64_convert_value"',1)
    need(original_copy==old['f64_copy_tensor'],'entire copy/layout/allocation loop inverse')
    need(current['half_previous_to_copy_tensor'].replace(
        b'fn half_previous_to_copy_tensor(',b'fn to_copy_tensor(',1)==old['to_copy_tensor'],
        'all non-half cast paths whole body inverse')
    calls={}
    for callee in ['dtype_width','half_copy_tensor','half_cast_admit','typed_clone','typed_iteration_address',
                   'to_tensor','save_public','data_alias','command_argument']:
        token=('"function":"'+callee+'"').encode()
        calls[callee]=[{'caller':name,'calls':body.count(token),'sha256':sha(body),
                       'same_as730':name in old and body==old[name],
                       'first_source_line':source[:source.index(body)].count(b'\n')+1}
                      for name,body in current.items() if token in body]
    need(len(calls['dtype_width'])==21 and sum(r['calls'] for r in calls['dtype_width'])==26,
         'complete width2 consumer census including copied half loop')
    need([(r['caller'],r['calls']) for r in calls['half_copy_tensor']]==[('half_cast_admit',1)]
         and [(r['caller'],r['calls']) for r in calls['half_cast_admit']]==[('to_copy_tensor',1)],
         'new copy is reachable only through explicit half admission')
    owner=(HERE/'observation-01/owner737.py').read_bytes()
    deriv=json.loads((HERE/'observation-01/derivation.json').read_bytes())
    appendix=(HERE/'observation-01/half-appendix.py.txt').read_bytes()
    need(sha(owner)==deriv['owner_sha256'] and owner.endswith(appendix),'explicit owner source and appendix')
    owner_inverse=owner[:-len(appendix)].decode()
    for edit in reversed(deriv['inverse_edits']):
        need(owner_inverse.count(edit['after'])==edit['count'],'exact owner inverse replacement count')
        owner_inverse=owner_inverse.replace(edit['after'],edit['before'])
    need(owner_inverse.encode()==(HERE/'frozen/owner730.py').read_bytes(),'whole owner inverse to5700')
    ast.parse(owner)
    mapping=json.loads((HERE/'mapping-01/mapping.json').read_bytes())
    need(mapping['source_sha256']==SOURCE and mapping['numeric_groups']==26
         and mapping['standalone_refusals_not_transferred']==12,'exact distinct next numeric denominator')
    policies={
        '97':'typed_from_wire admits only0/1/2/4/5/6; original descriptor rejects non0 requires_grad; raw bytes use exact2-byte width.',
        '12/100':'new high-bit guard before original store and Version bump; all bits above0xffff cause7; ordinary bounds and no_grad flags retained.',
        '108/109':'only0→5,5→0,0→6,6→0,5→5,6→6; noAD and memory_format0/1; all prior casts take entire730 renamed body.',
        '110':'original source3 and target>2 refusal branch is not changed; it is not an additional half factory.',
        'low-op':'command_argument refuses half Tensor operands for every low-op except12/13; this includes both positions of binary ops.',
        '99/101/102':'typed_command explicitly refuses half dropout, inplace detach, and Bool-not.',
        '111..117':'to_command checks actual same-packet-resolved source dtype and rejects half before old shape/AD/reduce dispatch.',
        '69/Saved/data_alias':'rng_strided_view/save_public/data_alias independently reject half, closing older high-op paths.',
        'distributions_and_integer_ops':'unchanged public_f32, integer_result_dtype (>2), integer_native_dropout (!=2) gates remain mandatory.',
        'layout':'no half views; a permitted F32 view input uses old tget logical addressing and exact dense-layout/copy loop into offset0 owned2-byte storage.',
        'same-dtype-copy':'no numerical conversion; original raw16 payload remains exact, including NaNs. Old to_tensor alias path controls copy=False.',
    }
    result={'schema':'heptatorch.public-half737.source-contract-review.v1',
        'status':'SOURCE_ONLY_NOT_COMPILED_NOT_RUN','source_sha256':SOURCE,'baseline_sha256':BASE,
        'functions':737,'unchanged_parent_bodies':716,'modified_parent_bodies':14,'added_bodies':7,
        'whole_source_inverse_exact':True,'whole_owner_inverse_exact':True,
        'generic_bodies_preserved':{n:{'bytes':len(old[n]),'sha256':sha(old[n])} for n in generic},
        'direct_call_census':calls,'source_level_entry_policies':policies,
        'half_owner_sha256':sha(owner),'original_numeric_groups':26,'old_refusals_not_transferred':12,
        'compile_required':True,'actual_reference_required':True,'actual_owner_and_rollback_required':True,
        'old_runtime_qualification_transferred':False,'native_executed':False,'Torch_executed':False,
        'compiler_executed':False,'full_pytorch_rewrite_complete':False}
    output=args.output.resolve();need(not output.exists(),'new static receipt required')
    output.parent.mkdir(parents=True,exist_ok=True)
    raw=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode();output.write_bytes(raw)
    print(json.dumps({'status':result['status'],'bytes':len(raw),'sha256':sha(raw)}))


if __name__=='__main__':
    main()
