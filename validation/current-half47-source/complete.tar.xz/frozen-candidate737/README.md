# Ordinary F16 and BF16 Tensor source candidate

This package is a **source-only 737-function candidate** based on the exact
combined Generator/F64 730 source. No HIA compiler, linker, native application,
Torch reference, remote process, or Git mutation was run to produce it. Its
source and partition checks do not establish numerical, owner, rollback, or
full-project qualification.

| Identity | SHA-256 |
| --- | --- |
| Parent 730 source | `6c9fc24a2006163d98827f0c464162dc635ded7e4fc284cbad4b30a692022f04` |
| New 737 source | `b2430af6ab7070efda67a1f7e9e2a8a83e273d57e44728b5492f0ee9d03e8fc3` |
| New 15-unit manifest | `970bac0845bc4b3177946e54a27782816d162bf6c2298bd68c418f0463a2eae2` |
| New explicit owner source | `fb74a9a525d149678b1b0ee92913bdcdabdd4459f4cd039905e822e6a87e5830` |
| Frozen public4 owner parent | `5700ca389d9b73ab6f37cf13c7a25ae241aac9d4612e4f33f5158379a0e6cd2b` |
| Original-input mapping | `2b41d4a1e466c944028d5150a951368eec1e26fb3219b1b5d5dc78fc557e1fa1` |

The partition contains 737 core functions, 9,779 blocks, 35,314 instructions,
15 units and 748 global exports. There is no new ELF hash yet. The parent is the
frozen combined730 source before any independent PR40 cleanup. That parallel
line must be merged by an explicit new source derivation, not by silently
changing these pins or borrowing a previous runtime PASS.

## Supported source surface

Public dtype5 denotes IEEE binary16; public dtype6 denotes bfloat16. Their
Storage width is exactly two bytes. Public dtype4 remains the ordinary binary64
Tensor type. Private dtype3 remains the existing wrapped binary64 scalar and
does not become a public factory/cast dtype.

| Operation | Intended ordinary-half behavior |
| --- | --- |
| 97 typed factory | Rank0–4, explicit dtype5 or6, original raw16 bytes, no AD |
| 13 / 96 / 98 | Original metadata, dtype/width, and raw logical read paths |
| 12 raw set / 100 raw fill | Original Version rules; reject every bit above `0xffff` before mutation |
| 108 `to` / 109 `_to_copy` | Exact pairs `0→5`, `5→0`, `0→6`, `6→0`, `5→5`, `6→6`; memory formats0/1; no AD |
| Same-dtype copy | Preserve all raw16 bits, including every NaN payload; use the unchanged alias decision for `copy=False` |

Half arithmetic, mixed promotion, half-to-half cross-format conversion,
F64↔half, Bool/I64/private3↔half, half views, Saved tensors, gradients, reductions,
dropout and optimizers are outside this increment. The corresponding public
paths refuse explicitly. The original raw factory110 remains limited to its
old target codes; it is not another half factory.

F32 input views are permitted for an explicitly admitted cast. The unchanged
logical-address read and dense-layout loop reads offset/strided/overlapping
F32 input correctly at the source level and allocates an ordinary offset-zero
half result. The resulting strides may preserve a dense permutation. Actual
layout, raw bytes and rollback still require independent runtime tests.

## Complete HIA derivation

`candidate/transition.json` records every changed and added body. Removing the
seven additions and replacing the fourteen changed bodies with the frozen
before bodies reproduces the complete parent source byte-for-byte. All other
716 parent bodies remain exact.

The fourteen changed functions are `dtype_width`, `typed_from_wire`, `tset`,
`typed_fill`, `scalar_previous_dtype_audit`, `dtype_audit`, `to_copy_tensor`,
`sd_previous_to_command`, `to_command`, `command_argument`, `typed_command`,
`rng_strided_view`, `save_public` and `data_alias`. The first five extend storage
width, explicit factory admission and mutation checks; the other entry guards
prevent the generic width change from granting unrelated operations.

The additions are `widen_f16`, `half_widen_bf16`,
`half_previous_to_copy_tensor`, `half_cast_admit`, `half_convert_value`,
`half_copy_tensor` and `half_dtype_audit`. The complete original F64 copy body is
retained for F64 and copied into the half helper with only its function name and
conversion callee changed. The original complete cast body remains under the
explicit `half_previous_to_copy_tensor` name for every non-half pair.

`half_dtype_audit` first runs the unchanged F64 audit, then adds half-specific
no-AD/no-Saved/no-ViewInfo/offset-zero predicates. The old private-scalar audit
remains in the enclosing chain. Descriptors remain 672 bytes; no ABI or field
offset changes are introduced.

The existing `round_f16` and `round_bf16` bodies are reused from the unchanged
RNG module. F16 widening is the whole original standalone function. BF16
widening is exactly the original `u64(input16) << 16` instruction pair under a
recorded SSA rename. It does not add a quiet-NaN transformation. All eight F64
numeric bodies and all eleven Generator model bodies remain byte-identical.

`rng03`, `cg_model` and `owners` remain complete identical files. The real
four-argument entropy ABI and family ownership dispatcher therefore remain
unchanged. Their expected object hashes in the new manifest are requirements
for future cold reproduction; no object or previous application ELF was read,
copied or reused in this work.

## Original numerical inputs and comparison rules

`mapping-01/mapping.json` records all original per-group input bytes and new
factory-request hashes. Only pure input-generator code was selected from the
frozen original scripts; their imports, compiler calls, application calls,
Torch reference code and main functions were never executed.

| Original family | Numerical groups mapped | Input words | Original standalone refusals retained separately |
| --- | ---: | ---: | ---: |
| F16 | 9 | 821,554 | 7 |
| BF16 | 17 | 86,662 | 5 |
| Total | 26 | 908,216 | 12 |

The new Tensor sequence is factory97, cast108 and actual metadata/raw reads
13/96/98. The largest factory body is800,160 bytes, below the existing1MiB
request bound. Inputs up to200,000 elements fit the existing rank1 shape bound
without splitting or changing any original group.

F16 retains its original exact non-NaN comparison and actual-NaN class plus
quiet-bit rule. BF16 retains its original exact non-NaN comparison and
actual-NaN class rule; it receives no new payload, sign, or quiet-bit predicate.
The exact comparison source spans are retained in `mapping-01`. A future reader
must execute those spans without widening tolerances or replacing actual Torch
outputs with a host conversion model.

The original F16 report has per-request hashes and all16 were previously bound
by the frozen source audit. The BF16 aggregate does not contain per-request
hashes; the new ordinal descriptions and packet hashes are explicitly labeled
as pure input reconstruction, not an observation from that aggregate.

The original12 standalone refusal packets use a different `<II>` protocol.
They are preserved with their original bytes/hashes and do not add12 cases to
the new Tensor denominator. The historical BF16 installation failure and both
original standalone reports remain in the frozen inputs unchanged.

## Owner observer

`observation-01/owner737.py` is a separate candidate observer. Removing its new
appendix and reversing the explicit identity/domain edits restores the entire
5700 public4 owner file. Every original84-word field check still executes.
Only three Tensor/Weak/Hold dtype membership predicates and the byte-width
table extend to5/6; the report explicitly says the old dtype predicate domain
is not unchanged.

The additional half role checks an actual live Tensor, Storage and Version,
exact `2*numel` Storage bytes, zero offset, dense owned layout, absence of
AD/Saved/ViewInfo roots and complete actual Version identity. Factory and cast
metadata checks require new Tensor/Storage/Version identities, fresh Version0,
unchanged complete input descriptors, or the exact allowed same-Tensor alias.
No numeric expected value is calculated by this observer. Failure rollback
still uses the whole original owner endpoint checks. It does not claim a full
private allocation transition ledger.

The observer has not yet inspected an actual half owner. It remains a candidate
until real new raw endpoints, negative controls and allocation failures have
passed. Its explicit source binding is the new737 aggregate; it is not a
replacement for the preserved old730 observer or F64 reference producer.

## Source-only reproduction

All commands below are local Python source/byte checks. Use fresh output paths.

```sh
python -I -S -B check_source_contract.py --output /tmp/half737-source-check-new.json
python -I -S -B map_original_cases.py --output /tmp/half737-input-mapping-new
python -I -S -B emit_owner.py --output /tmp/half737-owner-new
python -I -S -B emit_candidate.py --output /tmp/half737-candidate-new
python -I -S -B partition_candidate.py --candidate /tmp/half737-candidate-new --output /tmp/half737-partition-new
python -I -S -B tools/current_runtime/build.py --manifest source/manifest.json --source-root source --check-only --output /tmp/half737-build-source-check-new
```

The canonical `tools/current_runtime/build.py` is the exact existing4-argument
builder. The packaged original `tools/stack_budget/inspect_stack.py` resolves at
its normal repository-relative path. A later root-authorized cold build uses
that builder with the fixed compiler SHA `b1c851a0896fa6071f800e1146c3c27d0c6cf85059e9a6281b46d42908a3f59f`
and entropy linker SHA `761a941fd7a2d53eb9b45869fcfc20e970640e9dd11d60f7c61a89812b61d74e`,
plus fresh `--compiler`, `--linker` and `--output` paths. It must perform15 real
compilations and one real link, check every process and both EOFs, inspect the
actual stack and bind the resulting new ELF. No such build is claimed here.

## Gates still required

The first new runtime qualification must include all26 mapped numeric groups
against a newly produced fixed-PyTorch reference, plus independent Tensor
boundaries. These include rank0/empty shapes; transposed/dense-permuted,
non-dense and zero-stride F32 source casts; same-half alias versus fresh copy;
raw16 read/write/fill and Version changes; high-bit rejection with full-owner
rollback; both mixed binary argument orders; all unsupported target pairs;
private3 preservation; no-AD and Saved/view refusals; same-packet handles; and
real allocation failure followed by the identical request succeeding after
resource recovery. These additions must receive their own written case census
and original raw/EOF evidence, not be hidden inside the old26 denominator.

A new whole-image regression of the original513, Generator131 and F6448 must
also run on the same new ELF. Their previous PASS results cannot transfer to
this source. Full PyTorch rewrite closure remains false.

The work directory retains the earlier pure authoring/parser-check failures.
They never reached a compiler, application or Torch execution. The deliverable
keeps their small original source/check receipts in `authoring-history`; it
contains no old candidate ELF, `.o`, Python bytecode, or stale generated unit
set.
