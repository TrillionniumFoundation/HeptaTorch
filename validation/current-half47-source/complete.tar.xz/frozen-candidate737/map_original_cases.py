#!/usr/bin/env python3
"""Reproduce original half *inputs* and map them to ordinary Tensor packets.

This selects only original pure input generators. It does not import Torch,
invoke HIA, evaluate conversions, or produce numerical expected values.
"""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import random
import struct


HERE = Path(__file__).resolve().parent
FROZEN = HERE / 'frozen'
SOURCE = 'b2430af6ab7070efda67a1f7e9e2a8a83e273d57e44728b5492f0ee9d03e8fc3'
PIN = {
    'f16_oracle.py': '34940af7cd7c4dbb8de376e8e041d6c7f3820a6a6fbbea07bf3d6ec61562ccd9',
    'bf16_oracle.py': 'b6faeb43030d713cbdffb9bb0f228e561d6ce8532fd4a6cb6a3a4bdd782c0827',
    'half-source-audit.json': '5bf6e611f9d9cb8392730c7f3e157066c80767746b9efc002050e44776ac9b43',
    'hosted-native-f16.json': 'b16e5e5d24e6d39a5b1a69fab1630ecd7b43297076ef1f576feec0eb28301a11',
    'hosted-native-bf16.json': '0cb540fec1b65499ceffd58512a7a16a4835bd811c744c72b4399e830a3e3dbe',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(value, rule):
    if not value:
        raise AssertionError(rule)


def inputs():
    result = {}
    for name, digest in PIN.items():
        raw = (FROZEN / name).read_bytes()
        require(sha(raw) == digest, 'exact original source/input audit: ' + name)
        result[name] = raw
    require(sha((HERE / 'candidate/runtime.hepta').read_bytes()) == SOURCE, 'candidate source identity')
    return result


def span(raw, node):
    return ('\n'.join(raw.decode().splitlines()[node.lineno - 1:node.end_lineno]) + '\n').encode()


def original_inputs(frozen):
    """Return original integer input words; never call original reference/main."""
    source = frozen['f16_oracle.py']
    tree = ast.parse(source)
    selected = [n for n in tree.body if isinstance(n, ast.FunctionDef)
                and n.name in {'word', 'half_value', 'corpus'}]
    require({n.name for n in selected} == {'word', 'half_value', 'corpus'}, 'complete F16 pure generator set')
    env = {'struct': struct, 'random': random}
    exec(compile(ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[])),
                 'original-f16-pure-inputs-only', 'exec'), env)
    f16 = env['corpus']()
    main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    refusals = next(n for n in main.body if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == 'refusals' for t in n.targets))
    f16_refusals = eval(compile(ast.Expression(refusals.value), 'original-f16-refusal-inputs', 'eval'),
                        {'struct': struct})
    comparison = next(n for n in ast.walk(main) if isinstance(n, ast.For)
                      and isinstance(n.target, ast.Tuple) and 'index' in ast.unparse(n.target)
                      and 'src' in ast.unparse(n.target))
    f16_comparison = span(source, comparison)
    f16_spans = {n.name: span(source, n) for n in selected}

    source = frozen['bf16_oracle.py']
    tree = ast.parse(source)
    start = next(i for i, n in enumerate(tree.body) if isinstance(n, ast.Assign)
                 and any(isinstance(t, ast.Name) and t.id == 'rng' for t in n.targets))
    stop = next(i for i, n in enumerate(tree.body) if isinstance(n, ast.For)
                and isinstance(n.target, ast.Name) and n.target.id == 'packet')
    selected = tree.body[start:stop]
    bf16 = []
    env = {'random': random, 'compare': lambda mode, values: bf16.append((mode, values))}
    exec(compile(ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[])),
                 'original-bf16-pure-inputs-only', 'exec'), env)
    bf16_refusals = eval(compile(ast.Expression(tree.body[stop].iter), 'original-bf16-refusal-inputs', 'eval'),
                         {'struct': struct})
    compare = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'compare')
    comparison = next(n for n in ast.walk(compare) if isinstance(n, ast.For))
    bf16_comparison = span(source, comparison)
    bf16_spans = {str(i): span(source, n) for i, n in enumerate(selected)}
    require(len(f16) == 9 and len(bf16) == 17 and len(f16_refusals) == 7 and len(bf16_refusals) == 5,
            'original 26 numeric groups and 12 nontransferred refusals')
    return f16, bf16, f16_refusals, bf16_refusals, f16_comparison, bf16_comparison, f16_spans, bf16_spans


def factory_packet(dtype, count, raw):
    # One rank1, no-AD Tensor command. This is a new protocol packet carrying
    # unchanged original input bits, not an old standalone request replay.
    config = struct.pack('<8Q', 1, 0, count, 0, 0, 0, 160, len(raw))
    body = b'HTORCH03' + struct.pack('<3Q', 1, 160 + len(raw), 0)
    body += struct.pack('<8Q', 97, dtype, 96, 0, 0, 0, 0, 0) + config + raw
    require(len(body) == 160 + len(raw) <= 1 << 20 and count <= 262144, 'actual Tensor factory bounds')
    return body


def map_groups(frozen, corpus):
    f16, bf16, f16_refusals, bf16_refusals, f16_compare, bf16_compare, f16_spans, bf16_spans = corpus
    historical = json.loads(frozen['half-source-audit.json'])
    require(sha(f16_compare) == '21772895c979945f6181d610f9fe10d5b3f5c7a645b2fd85dd8bd5d8ddb444c0',
            'complete original F16 numeric comparison loop')
    require(sha(bf16_compare) == 'a7136637404a5b300f4a55bc1a08cd2faf252ad789f0f7473c94eb2e72ad602b',
            'complete original BF16 numeric comparison loop')
    original_f16 = next(r for r in json.loads(frozen['hosted-native-f16.json'])['reports']
                       if r['reference'] == 'pytorch')
    rows, refused = [], []
    for family, target, groups in [('F16', 5, [(m, v) for _, m, v in f16]), ('BF16', 6, bf16)]:
        for ordinal, (mode, values) in enumerate(groups):
            old = historical[family]['rows'][ordinal]
            unit = 4 if mode == 0 else 2
            raw = b''.join(word.to_bytes(unit, 'little') for word in values)
            packet = struct.pack('<II', mode, len(values)) + raw
            require((len(values), sha(raw), sha(packet)) ==
                    (old['input_count'], old['input_raw_sha256'], old['original_packet_sha256']),
                    'all original input bits and complete old request: %s:%d' % (family, ordinal))
            if family == 'F16':
                require(original_f16['rows'][ordinal]['request_sha256'] == sha(packet),
                        'original observed F16 request hash')
            source_dtype, target_dtype = (0, target) if mode == 0 else (target, 0)
            body = factory_packet(source_dtype, len(values), raw)
            rows.append({
                **old, 'family': family, 'current_source_sha256': SOURCE,
                'tensor_factory_body_bytes': len(body), 'tensor_factory_body_sha256': sha(body),
                'tensor_shape': [len(values)], 'requires_grad': False,
                'public_source_dtype': source_dtype, 'public_target_dtype': target_dtype,
                'intended_commands': [97, 108, 13, 96, 98],
                'cast_fields_after_actual_token': [target_dtype, 1, 0, 0, 0, 0],
                'original_numeric_predicate_sha256': sha(f16_compare if family == 'F16' else bf16_compare),
                'new_reference_required': True, 'new_native_execution_required': True,
                'original_PASS_transferred': False,
            })
        packets = [p for _, p in f16_refusals] if family == 'F16' else bf16_refusals
        first = len(groups)
        for index, packet in enumerate(packets, first):
            old = historical[family]['rows'][index]
            require(sha(packet) == old['original_packet_sha256'], 'exact old standalone refusal bytes')
            refused.append({**old, 'family': family, 'new_Tensor_case_transferred': False,
                            'why_not_transferred': 'Original <II> standalone protocol differs from framed HTORCH03.'})
    require(len(rows) == 26 and len(refused) == 12 and sum(r['input_count'] for r in rows) == 908216,
            'fixed mapped numeric denominator and all original input counts')
    require(max(r['tensor_factory_body_bytes'] for r in rows) == 800160, 'largest exact Tensor factory request')
    result = {
        'schema': 'heptatorch.public-half737.original-input-mapping.v1',
        'status': 'PURE_INPUT_AND_SOURCE_MAPPING_ONLY_NOT_RUN',
        'source_sha256': SOURCE, 'baseline_functions': 730, 'candidate_functions': 737,
        'numeric_groups': 26, 'F16_numeric_groups': 9, 'BF16_numeric_groups': 17,
        'input_values': 908216, 'standalone_refusals_not_transferred': 12,
        'old_total_groups': 38, 'numeric': rows, 'standalone_refusals': refused,
        'original_comparison_spans': {'F16': {'bytes': len(f16_compare), 'sha256': sha(f16_compare)},
                                      'BF16': {'bytes': len(bf16_compare), 'sha256': sha(bf16_compare)}},
        'pure_input_source_spans': {
            'F16': {k: {'bytes': len(v), 'sha256': sha(v)} for k, v in f16_spans.items()},
            'BF16': {k: {'bytes': len(v), 'sha256': sha(v)} for k, v in bf16_spans.items()}},
        'original_F16_NaN_rule': 'Actual NaN class and quiet bit; expected NaN class. Non-NaNs exact bits.',
        'original_BF16_NaN_rule': 'Actual NaN class only; no new payload/sign/quiet-bit rule. Non-NaNs exact bits.',
        'additional_tensor_layout_owner_refusal_and_OOM_controls_required': True,
        'compiled': False, 'native_executed': False, 'Torch_executed': False,
        'numeric_expected_values_generated': False, 'whole_project_closed': False,
    }
    return result, f16_compare, bf16_compare, f16_spans, bf16_spans


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    original = inputs()
    result, f16, bf16, f16_sources, bf16_sources = map_groups(original, original_inputs(original))
    output = args.output.resolve()
    require(not output.exists(), 'new mapping output required')
    output.mkdir(parents=True)
    (output / 'original-f16-comparison.py.txt').write_bytes(f16)
    (output / 'original-bf16-comparison.py.txt').write_bytes(bf16)
    (output / 'input-source-spans').mkdir()
    for family, sources in [('f16', f16_sources), ('bf16', bf16_sources)]:
        for name, raw in sources.items():
            (output / 'input-source-spans' / (family + '-' + name + '.py.txt')).write_bytes(raw)
    require(inputs() == original, 'all original input files unchanged')
    result['all_inputs_unchanged'] = True
    raw = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
    (output / 'mapping.json').write_bytes(raw)
    print(json.dumps({'status': result['status'], 'groups': 26, 'not_transferred': 12,
                      'bytes': len(raw), 'sha256': sha(raw)}))


if __name__ == '__main__':
    main()
