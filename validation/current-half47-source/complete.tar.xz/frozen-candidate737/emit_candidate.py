#!/usr/bin/env python3
"""Author a source-only ordinary F16/BF16 Tensor extension of frozen 730.

No HIA tool, native process, Torch, or upstream Python oracle is executed.
The frozen small SSA text author is used only to emit new HIA text.  Existing
rounding bodies and the F16 widening body are copied or called byte-for-byte.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import shutil
import stat


HERE = Path(__file__).resolve().parent
FROZEN = HERE / 'frozen'
BASE = '6c9fc24a2006163d98827f0c464162dc635ded7e4fc284cbad4b30a692022f04'
INPUT_MANIFEST = '6d3f957e713b65564e7bfea0899a8942a5662ddcad57bd96fbfc1a4c828b784d'
AUTHOR = '5fc67de65513ea037f9a84c741e6895e14a80cb85530b8d9f94f9fc7979101f5'
ROUND_F16 = 'bfbc7cdfe038b6c70e8fbdf93b7b121c072a571764069391b23964909eec7821'
WIDEN_F16 = '239efc00626676a06b57b3fb3f56a120d208c666544dfe64bd15232328d1b52f'
ROUND_BF16 = 'de58e57a97f386750e823a7f0e90064fb01536919acc10cc713b232a75648129'
WIDEN_BF16_SPAN = 'a148fc66fe2c3c658cf50d0693f7298c468f5ac673ada87b676ef8eb698b8da7'


def require(ok, label):
    if not ok:
        raise AssertionError(label)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def jbytes(obj):
    return (json.dumps(obj, indent=2, sort_keys=True) + '\n').encode()


def read_frozen():
    raw = (FROZEN / 'inputs-manifest.json').read_bytes()
    require(sha(raw) == INPUT_MANIFEST, 'frozen manifest pin')
    records = json.loads(raw)['files']
    result = {}
    for name, row in records.items():
        path = FROZEN / name
        data = path.read_bytes()
        require(path.is_file() and not path.is_symlink(), 'regular frozen input: ' + name)
        require((len(data), sha(data), stat.S_IMODE(path.stat().st_mode)) ==
                (row['bytes'], row['sha256'], row['mode']), 'frozen input: ' + name)
        result[name] = data
    require(sha(result['runtime730.hepta']) == BASE, '730 source pin')
    require(sha(result['emit_f64.py']) == AUTHOR, 'text-author pin')
    return result


def load_author():
    spec = importlib.util.spec_from_file_location('_frozen_f64_text_author', FROZEN / 'emit_f64.py')
    module = importlib.util.module_from_spec(spec)
    # This file only defines constants and source-emission functions. Its main
    # function is never called; it is not a compiler or numerical interpreter.
    spec.loader.exec_module(module)
    return module


def emit_copy_wrapper(a):
    f = a.Function('to_copy_tensor', ['mutbuf', 'u64', 'u64', 'u64'])
    bad = f.block([])
    decide = f.block(['mutbuf', 'u64', 'u64', 'u64'])
    old = f.block(['mutbuf', 'u64', 'u64', 'u64'])
    new = f.block(['mutbuf', 'u64', 'u64', 'u64'])
    w, source, target, fmt = f.at(f.entry)
    value = f.call('valid', w, source)
    f.branch(f.compare('eq', value, f.c(0)), bad, (), decide, (w, source, target, fmt))
    f.at(bad); f.ret(f.c(0))
    w, source, target, fmt = f.at(decide)
    dtype = f.call('tensor_dtype', w, source)
    source_half = f.logic('or', f.compare('eq', dtype, f.c(5)), f.compare('eq', dtype, f.c(6)))
    target_half = f.logic('or', f.compare('eq', target, f.c(5)), f.compare('eq', target, f.c(6)))
    f.branch(f.logic('or', source_half, target_half), new, (w, source, target, fmt),
             old, (w, source, target, fmt))
    args = f.at(old); f.ret(f.call('half_previous_to_copy_tensor', *args))
    args = f.at(new); f.ret(f.call('half_cast_admit', *args))
    return f.text()


def emit_cast_admit(a):
    f = a.Function('half_cast_admit', ['mutbuf', 'u64', 'u64', 'u64'])
    flags = f.block(['mutbuf', 'u64', 'u64', 'u64'])
    copy = f.block(['mutbuf', 'u64', 'u64', 'u64'])
    type_error, ad_error = a.error_block(f, 7), a.error_block(f, 5)
    w, source, target, fmt = f.at(f.entry)
    dtype = f.call('tensor_dtype', w, source)
    s0, s5, s6 = [f.compare('eq', dtype, f.c(code)) for code in (0, 5, 6)]
    t0, t5, t6 = [f.compare('eq', target, f.c(code)) for code in (0, 5, 6)]
    p0 = f.logic('and', s0, f.logic('or', t5, t6))
    p5 = f.logic('and', s5, f.logic('or', t0, t5))
    p6 = f.logic('and', s6, f.logic('or', t0, t6))
    allowed = f.logic('or', f.logic('or', p0, p5), p6)
    allowed = f.logic('and', allowed, f.compare('le', fmt, f.c(1)))
    f.branch(allowed, flags, (w, source, target, fmt), type_error[0], (w,))
    w, source, target, fmt = f.at(flags)
    requires = f.get(w, f.call('dptr', w, source), 32)
    f.branch(f.compare('ne', requires, f.c(0)), ad_error[0], (w,), copy, (w, source, target, fmt))
    args = f.at(copy); f.ret(f.call('half_copy_tensor', *args))
    a.fill_error(f, type_error); a.fill_error(f, ad_error)
    return f.text()


def emit_convert(a):
    f = a.Function('half_convert_value', ['u64', 'u64', 'u64'])
    same = f.block(['u64'])
    changed = f.block(['u64', 'u64', 'u64'])
    narrowing = f.block(['u64', 'u64'])
    widening = f.block(['u64', 'u64'])
    f16_narrow = f.block(['u64'])
    bf16_narrow = f.block(['u64'])
    f16_widen = f.block(['u64'])
    bf16_widen = f.block(['u64'])
    bits, source, target = f.at(f.entry)
    f.branch(f.compare('eq', source, target), same, (bits,), changed, (bits, source, target))
    bits, = f.at(same); f.ret(bits)
    bits, source, target = f.at(changed)
    f.branch(f.compare('eq', source, f.c(0)), narrowing, (bits, target), widening, (bits, source))
    bits, target = f.at(narrowing)
    f.branch(f.compare('eq', target, f.c(5)), f16_narrow, (bits,), bf16_narrow, (bits,))
    bits, source = f.at(widening)
    f.branch(f.compare('eq', source, f.c(5)), f16_widen, (bits,), bf16_widen, (bits,))
    for block, callee in [(f16_narrow, 'round_f16'), (bf16_narrow, 'round_bf16'),
                          (f16_widen, 'widen_f16'), (bf16_widen, 'half_widen_bf16')]:
        bits, = f.at(block); f.ret(f.call(callee, bits))
    return f.text()


def emit_widen_bf16(a, frozen):
    old = (b'  v118:u64 = const() {"value":16}\n'
           b'  v119:u64 = int.shl.checked(v117,v118)\n')
    require(frozen.count(old) == 1 and sha(old) == WIDEN_BF16_SPAN, 'original BF16 widening span')
    f = a.Function('half_widen_bf16', ['u64'])
    bits, = f.at(f.entry)
    f.ret(f.op('u64', 'int.shl.checked', (bits, f.c(16))))
    raw = f.text()
    new = old.replace(b'v117', b'v0').replace(b'v118', b'v1').replace(b'v119', b'v2')
    require(raw == (b'fn half_widen_bf16(v0:u64) -> (u64) effects(read,write,trap) entry(b0)\n'
                    b'block b0(v0:u64)\n' + new + b'  ret(v2)\nend\n'),
            'BF16 widening is exactly original two instructions with explicit SSA renaming')
    return raw, old


def emit_dtype_audit(a):
    f = a.Function('half_dtype_audit', ['mutbuf'])
    failed = f.block(['u64'])
    start = f.block(['mutbuf'])
    loop = f.block(['mutbuf', 'u64'])
    inspect = f.block(['mutbuf', 'u64'])
    check = f.block(['mutbuf', 'u64', 'u64'])
    advance = f.block(['mutbuf', 'u64'])
    good, bad = f.block([]), f.block([])
    w, = f.at(f.entry)
    status = f.call('f64_dtype_audit', w)
    f.branch(f.compare('ne', status, f.c(0)), failed, (status,), start, (w,))
    status, = f.at(failed); f.ret(status)
    w, = f.at(start); f.jump(loop, (w, f.c(1)))
    w, i = f.at(loop)
    end = f.call('getw', w, f.c(8))
    f.branch(f.compare('lt', i, end), inspect, (w, i), good, ())
    w, i = f.at(inspect)
    p = f.call('dptr', w, i)
    dtype = f.get(w, p, 576)
    half = f.logic('or', f.compare('eq', dtype, f.c(5)), f.compare('eq', dtype, f.c(6)))
    selected = f.logic('and', f.compare('ne', f.get(w, p, 304), f.c(0)), half)
    f.branch(selected, check, (w, i, p), advance, (w, i))
    w, i, p = f.at(check)
    # New ordinary half objects are fresh, no-AD, and own dense offset-zero
    # storage. Strides may preserve a dense permutation; half views are refused.
    fields = [24, 32, 40, 48, 56, 232, 288, 384, 408,
              584, 592, 600, 608, 616, 624, 632, 640, 648, 656, 664]
    nonzero = None
    for offset in fields:
        value = f.compare('ne', f.get(w, p, offset), f.c(0))
        nonzero = value if nonzero is None else f.logic('or', nonzero, value)
    f.branch(nonzero, bad, (), advance, (w, i))
    w, i = f.at(advance)
    f.jump(loop, (w, f.op('u64', 'int.add.wrap', (i, f.c(1)))))
    f.at(good); f.ret(f.c(0))
    f.at(bad); f.ret(f.c(9))
    return f.text(), fields


def fresh(raw, count):
    start = max(map(int, re.findall(rb'\bv(\d+)', raw))) + 1
    return [f'v{start + i}' for i in range(count)]


def half_test(raw, dtype):
    a, b, c, d, e = fresh(raw, 5)
    lines = (f'  {a}:u64 = const() {{"value":5}}\n'
             f'  {b}:u64 = const() {{"value":6}}\n'
             f'  {c}:bool = compare.eq({dtype},{a})\n'
             f'  {d}:bool = compare.eq({dtype},{b})\n'
             f'  {e}:bool = bool.or({c},{d})\n')
    return lines, e


def build_candidate(inputs, a):
    source = inputs['runtime730.hepta']
    before = a.definitions(source)
    require(len(before) == 730, '730 core count')
    f16, bf16 = [a.definitions(inputs[name]) for name in ('f16.hepta', 'bf16.hepta')]
    rng = a.definitions(inputs['rng03.hepta'])
    require(sha(f16['round_f16']) == ROUND_F16 and f16['round_f16'] == rng['round_f16'], 'F16 round unchanged')
    require(sha(f16['widen_f16']) == WIDEN_F16, 'F16 widening unchanged')
    require(sha(bf16['round_bf16']) == ROUND_BF16 and bf16['round_bf16'] == rng['round_bf16'], 'BF16 round unchanged')
    require(b'round_f16' in inputs['rng03.hepta'].splitlines()[1] and
            b'round_bf16' in inputs['rng03.hepta'].splitlines()[1], '730 RNG exports both old round functions')
    after, added, reasons = dict(before), {}, {}

    def change(name, body, reason):
        require(name in before and name not in reasons and body != before[name], 'unique changed function: ' + name)
        require(a.definitions(body) == {name: body}, 'changed body framing: ' + name)
        after[name], reasons[name] = body, reason

    def add(body):
        got = a.definitions(body)
        require(len(got) == 1, 'one added body')
        name = next(iter(got))
        require(name not in before and name not in added, 'unique added body: ' + name)
        added[name] = body

    raw = before['dtype_width']; lines, test = half_test(raw, 'v9')
    width, chosen = fresh(raw + lines.encode(), 2)
    raw = a.once(raw, '  ret(v18)\n', lines + f'  {width}:u64 = const() {{"value":2}}\n'
                 f'  {chosen}:u64 = select({test},{width},v18)\n  ret({chosen})\n')
    change('dtype_width', raw, 'Exactly public 5/6 gain width2; all 0..4 widths and invalid widths remain unchanged.')

    raw = before['typed_from_wire']
    x, y, nx, ny, partial, reject = fresh(raw, 6)
    old = '  branch v22 b1(v0,v1) b2(v0,v1,v2,v3,v4)\n'
    new = (f'  {x}:u64 = const() {{"value":5}}\n  {y}:u64 = const() {{"value":6}}\n'
           f'  {nx}:bool = compare.ne(v2,{x})\n  {ny}:bool = compare.ne(v2,{y})\n'
           f'  {partial}:bool = bool.and(v22,{nx})\n  {reject}:bool = bool.and({partial},{ny})\n'
           f'  branch {reject} b1(v0,v1) b2(v0,v1,v2,v3,v4)\n')
    change('typed_from_wire', a.once(raw, old, new), 'Factory97 admits only 0/1/2/4/5/6; private3 and all other codes stay refused.')

    for name, dtype, bits, old_bad, anchor in [
        ('tset', 'v48', 'v46', 'v63', '  jump b6(v43,v44,v45,v46,v48,v49,v63)\n'),
        ('typed_fill', 'v19', 'v13', 'v31', '  branch v31 b3(v11) b4(v11,v12,v13,v14,v16,v19,v20)\n')]:
        raw = before[name]; lines, test = half_test(raw, dtype)
        maximum, high, half_high, bad = fresh(raw + lines.encode(), 4)
        lines += (f'  {maximum}:u64 = const() {{"value":65535}}\n'
                  f'  {high}:bool = compare.gt({bits},{maximum})\n'
                  f'  {half_high}:bool = bool.and({test},{high})\n'
                  f'  {bad}:bool = bool.or({old_bad},{half_high})\n')
        tail = anchor.replace(old_bad, bad)
        change(name, a.once(raw, anchor, lines + tail), 'Half high bits cause7 before any storage write or Version bump; complete prior mutation path retained.')

    change('scalar_previous_dtype_audit', a.once(before['scalar_previous_dtype_audit'],
           '  v89:u64 = const() {"value":4}\n', '  v89:u64 = const() {"value":6}\n'),
           'Managed descriptor dtype domain extends to 6; original no-AD checks for every non-F32 dtype remain exact.')
    change('dtype_audit', a.once(before['dtype_audit'], '"function":"f64_dtype_audit"',
           '"function":"half_dtype_audit"'), 'Adds an explicit half ordinary/noAD/noSaved/noView/offset-zero audit before unchanged F64/private3 audits.')
    half_audit, audit_zero = emit_dtype_audit(a); add(half_audit)

    add(f16['widen_f16'])
    bf16_widen, bf16_span = emit_widen_bf16(a, inputs['bf16.hepta']); add(bf16_widen)
    add(a.once(before['to_copy_tensor'], 'fn to_copy_tensor(', 'fn half_previous_to_copy_tensor('))
    change('to_copy_tensor', emit_copy_wrapper(a), 'Half source or target enters exact six-pair admission; every prior pair uses the entire renamed 730 body.')
    add(emit_cast_admit(a)); add(emit_convert(a))
    copy = a.once(before['f64_copy_tensor'], 'fn f64_copy_tensor(', 'fn half_copy_tensor(')
    copy = a.once(copy, '"function":"f64_convert_value"', '"function":"half_convert_value"')
    add(copy)
    require(a.once(a.once(copy, 'fn half_copy_tensor(', 'fn f64_copy_tensor('),
                   '"function":"half_convert_value"', '"function":"f64_convert_value"') == before['f64_copy_tensor'],
            'complete copy/layout/Storage loop inverse')

    raw = before['sd_previous_to_command']
    x, y, nx, ny, partial, reject = fresh(raw, 6)
    anchor = '  branch v429 b33(v377,v378,v379,v381,v383,v384) b35(v377,v378,v379,v380,v381,v382)\n'
    lines = (f'  {x}:u64 = const() {{"value":5}}\n  {y}:u64 = const() {{"value":6}}\n'
             f'  {nx}:bool = compare.ne(v395,{x})\n  {ny}:bool = compare.ne(v395,{y})\n'
             f'  {partial}:bool = bool.and(v429,{nx})\n  {reject}:bool = bool.and({partial},{ny})\n')
    change('sd_previous_to_command', a.once(raw, anchor, lines + anchor.replace('v429', reject)),
           'Only casts108/109 gain target5/6. Raw factory110 target<=2 and private3 source refusal stay byte-identical.')

    raw = before['to_command']; lines, test = half_test(raw, 'v43')
    selected, = fresh(raw + lines.encode(), 1)
    anchor = '  branch v45 b3(v15,v14,v17,v19) b4(v13,v14,v15,v16,v17,v18)\n'
    require(anchor.encode() in raw, 'to_command source guard anchor')
    lines += f'  {selected}:bool = bool.or(v45,{test})\n'
    change('to_command', a.once(raw, anchor, lines + anchor.replace('v45', selected)),
           'All non-cast to/shape/sum/AD routes refuse half input just as ordinary F64; 108/109 retain original request parsing.')

    raw = before['command_argument']; lines, test = half_test(raw, 'v84')
    unsupported, half_bad, bad = fresh(raw + lines.encode(), 3)
    lines += (f'  {unsupported}:bool = bool.and(v127,v129)\n'
              f'  {half_bad}:bool = bool.and({test},{unsupported})\n'
              f'  {bad}:bool = bool.or(v86,{half_bad})\n')
    anchor = '  branch v86 b9(v72,v73,v76) b10(v72,v76,v86)\n'
    change('command_argument', a.once(raw, anchor, lines + anchor.replace('v86', bad)),
           'Half low-op Tensor arguments allow only raw set12 and metadata13; private3 and ordinary F64 permissions are unchanged.')

    raw = before['typed_command']; lines, test = half_test(raw, 'v58')
    unsupported, bad = fresh(raw + lines.encode(), 2)
    lines += (f'  {unsupported}:bool = bool.and({test},v97)\n'
              f'  {bad}:bool = bool.or(v60,{unsupported})\n')
    anchor = '  jump b4(v36,v37,v38,v39,v40,v41,v42,v43,v44,v60)\n'
    change('typed_command', a.once(raw, anchor, lines + anchor.replace('v60', bad)),
           'Half dropout99, inplace detach101, bool-not102 are refused; metadata96/raw98/fill100 stay on existing full transaction paths.')

    for name, dtype, condition in [('rng_strided_view', 'v21', 'v23'),
                                   ('save_public', 'v10', 'v12'), ('data_alias', 'v10', 'v12')]:
        raw = before[name]; lines, test = half_test(raw, dtype)
        bad, = fresh(raw + lines.encode(), 1)
        lines += f'  {bad}:bool = bool.or({condition},{test})\n'
        matches = re.findall(rb'^  branch ' + condition.encode() + rb' .+\n', raw, re.M)
        require(len(matches) == 1, 'special guard: ' + name)
        anchor = matches[0].decode()
        change(name, a.once(raw, anchor, lines + anchor.replace(condition, bad)),
               'New half views, explicit Saved and data aliases are refused; exact old private3/F64 and valid/refusal logic remains.')

    candidate = source
    for name in reasons:
        candidate = a.once(candidate, before[name], after[name])
    candidate += b''.join(added.values())
    restored = candidate
    for name, body in reversed(list(added.items())):
        restored = a.once(restored, body, b'')
    for name in reversed(reasons):
        restored = a.once(restored, after[name], before[name])
    require(restored == source, 'whole-source inverse to frozen730')
    all_functions = a.definitions(candidate)
    require(len(reasons) == 14 and len(added) == 7 and len(all_functions) == 737, 'explicit change denominator')
    for name in before:
        require((all_functions[name] != before[name]) == (name in reasons), 'unchanged body inventory: ' + name)
    core_calls = {x.decode() for x in re.findall(rb'\{"function":"(\w+)"\}', candidate)}
    external = set(re.search(rb'^exports\(([^\n]*)\)\n', inputs['rng03.hepta'], re.M)[1].decode().split(','))
    require(not core_calls - set(all_functions) - external, 'complete closed call graph')
    for name in ('pack64', 'add64', 'sub64', 'multiply_high', 'mul64', 'div64', 'widen32', 'narrow64'):
        require(all_functions[name] == before[name], 'F64 numerical body unchanged: ' + name)
    cg = {m[1].decode(): m[0] for m in re.finditer(
        rb'^fn (\w+)\([^\n]* entry\(\w+\)\n.*?^end\n', inputs['cg_model.hepta'], re.M | re.S)}
    require(len(cg) == 11 and all(all_functions[n] == body for n, body in cg.items()), 'all eleven CG model bodies unchanged')
    return candidate, before, after, added, reasons, audit_zero, bf16_span


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    inputs = read_frozen()
    a = load_author()
    candidate, before, after, added, reasons, audit_zero, bf16_span = build_candidate(inputs, a)
    out = args.output.resolve()
    require(not out.exists(), 'new output required')
    out.mkdir(parents=True)
    for directory in ('before', 'after', 'added', 'numerical-provenance'):
        (out / directory).mkdir()
    (out / 'runtime.hepta').write_bytes(candidate)
    for name in reasons:
        (out / 'before' / (name + '.hepta')).write_bytes(before[name])
        (out / 'after' / (name + '.hepta')).write_bytes(after[name])
    for name, body in added.items():
        (out / 'added' / (name + '.hepta')).write_bytes(body)
    rng = a.definitions(inputs['rng03.hepta'])
    for name in ('round_f16', 'round_bf16'):
        (out / 'numerical-provenance' / (name + '.hepta')).write_bytes(rng[name])
    (out / 'numerical-provenance' / 'widen_f16.hepta').write_bytes(added['widen_f16'])
    (out / 'numerical-provenance' / 'bf16-original-widen-span.txt').write_bytes(bf16_span)
    transition = {
        'schema': 'heptatorch.public-half-source-transition.v1',
        'status': 'SOURCE_ONLY_NOT_COMPILED_NOT_RUN',
        'source_sha256': sha(candidate), 'source_bytes': len(candidate),
        'baseline_sha256': BASE, 'functions_before': 730, 'functions_after': 737,
        'functions_added': len(added), 'old_functions_modified': len(reasons),
        'old_functions_byte_identical': 730 - len(reasons),
        'full_source_inverse_to_730': True,
        'new_dtype_codes': {'5': 'F16', '6': 'BF16'},
        'private_scalar_dtype3_unchanged': True,
        'new_cast_pairs': [[0, 5], [5, 0], [0, 6], [6, 0], [5, 5], [6, 6]],
        'same_dtype_copy_preserves_all_raw_bits': True,
        'new_descriptor_zero_offsets': audit_zero,
        'changed': {name: {'before_sha256': sha(before[name]), 'after_sha256': sha(after[name]),
                           'reason': reason} for name, reason in reasons.items()},
        'added': {name: {'sha256': sha(body), 'bytes': len(body)} for name, body in added.items()},
        'numerical': {'round_f16': ROUND_F16, 'round_bf16': ROUND_BF16, 'widen_f16': WIDEN_F16,
                      'bf16_original_two_instruction_span_sha256': WIDEN_BF16_SPAN,
                      'bf16_ssa_mapping': {'v117': 'v0', 'v118': 'v1', 'v119': 'v2'}},
        'original_F64_numerical_bodies_unchanged': 8,
        'original_CG_model_bodies_unchanged': 11,
        'original_rng_full_unit_unchanged': True, 'original_four_arg_entropy_owner_unit_unchanged': True,
        'native_executed': False, 'compiler_executed': False, 'Torch_executed': False,
        'numerical_qualification_transferred': False, 'full_project_closed': False,
    }
    (out / 'transition.json').write_bytes(jbytes(transition))
    for path in out.rglob('*'):
        if path.is_file():
            path.chmod(0o644)
    require(read_frozen() == inputs, 'all frozen inputs unchanged after pure emission')
    print(json.dumps({k: transition[k] for k in ('status', 'source_sha256', 'source_bytes',
                                               'functions_after', 'old_functions_modified', 'functions_added')}))


if __name__ == '__main__':
    main()
