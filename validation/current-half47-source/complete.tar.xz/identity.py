"""Make explicit reversible identity edits around unchanged Half47 tasks."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = '51820849f7becec549be15babace00f00687601ae7f53bcee0e636ca02f721f9'
IMAGE = 'aa3cc8f0c8738a9505d31c9e8ba5a523b7e08b591b61fc7bfb8592295491618b'
ORIGINAL_SOURCE = 'b2430af6ab7070efda67a1f7e9e2a8a83e273d57e44728b5492f0ee9d03e8fc3'
OWNER = 'fb74a9a525d149678b1b0ee92913bdcdabdd4459f4cd039905e822e6a87e5830'
RUN = '2671a9ab7937d692e4c675a660b209e4c26e8fd97a45cf452e6088b0c2266154'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def definitions(raw):
    lines = raw.splitlines(keepends=True)
    return {n.name: b''.join(lines[n.lineno - 1:n.end_lineno])
            for n in ast.parse(raw).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}


def change(original, edits):
    raw = original
    for old, new, count in edits:
        require(raw.count(old.encode()) == count and new.encode() not in raw, 'exact identity edit count')
        raw = raw.replace(old.encode(), new.encode(), count)
    restored = raw
    for old, new, count in reversed(edits):
        require(restored.count(new.encode()) == count, 'exact inverse identity count')
        restored = restored.replace(new.encode(), old.encode(), count)
    require(restored == original, 'all original file bytes restored')
    ast.parse(raw)
    return raw, dict(before_sha256=sha(original), after_sha256=sha(raw),
                     before_bytes=len(original), after_bytes=len(raw), edits=edits,
                     whole_file_inverse_exact=True)


def derive(bind):
    original_run = bind(HERE / 'frozen737/run.py', RUN)
    original_owner = bind(HERE / 'frozen-candidate737/observation-01/owner737.py', OWNER)
    outputs, proof = {}, {}
    outputs['derived737_run.py'], proof['run'] = change(original_run, [
        ("'exact-half737-source-and-first-actual-image'", "'exact-current736-source-and-actual-image'", 1),
        ("schema='heptatorch.half737.tensor-native26.v1'",
         "schema='heptatorch.current736.half47-native.v1'", 1),
        ('inputs, plan, package,\n', 'inputs, plan, PRODUCER_MANIFEST,\n', 1),
        ('compiler_executed=False, expected_counts=TASK_COUNTS, numeric_groups=[], boundary_cases=[],',
         'compiler_executed=False, reference_producer_source_sha256=PRODUCER_SOURCE,\n'
         '        reference_producer_manifest_sha256=PRODUCER_MANIFEST,\n'
         '        expected_counts=TASK_COUNTS, numeric_groups=[], boundary_cases=[],', 1),
    ])
    before, after = definitions(original_run), definitions(outputs['derived737_run.py'])
    require(set(before) == set(after) and all(before[n] == after[n] for n in before if n != 'main'),
            'every original non-main definition is byte identical')
    require(original_run.replace(before['main'], b'', 1) ==
            outputs['derived737_run.py'].replace(after['main'], b'', 1), 'only main source bytes changed')
    begin, end = b'            tasks = []\n', b'        code = 0 if result'
    require(before['main'].split(begin, 1)[1].split(end, 1)[0] ==
            after['main'].split(begin, 1)[1].split(end, 1)[0], 'all47 task scheduling and comparison loop unchanged')
    proof['run'].update(only_main_edited=True, complete47_task_loop_unchanged=True,
        original_non_main_definitions={n: dict(bytes=len(v), sha256=sha(v)) for n, v in before.items() if n != 'main'})
    outputs['owner736.py'], proof['owner'] = change(original_owner, [
        ('half-generator737', 'half-generator-current736', 3),
        ('UNBOUND-737', 'UNBOUND-CURRENT736', 1),
        ('functions == 737', 'functions == 736', 2),
        (ORIGINAL_SOURCE, SOURCE, 1),
    ])
    proof['owner'].update(no_descriptor_or_allocation_predicates_changed=True,
                          original_full_owner_and_frame_boundary_checks_preserved=True)
    proof.update(schema='heptatorch.current736-half47.reader-identity-inverse.v1',
                 source_sha256=SOURCE, native_sha256=IMAGE, original_reference_namespace_preserved=True,
                 original239_refusal_expectations_modified=False,
                 original_numerical_predicates_modified=False, native_executed=False,
                 Torch_executed=False, compiler_executed=False, runtime_PASS_transferred=False)
    outputs['identity-derivation.json'] = (json.dumps(proof, sort_keys=True, indent=2) + '\n').encode()
    return outputs, proof
