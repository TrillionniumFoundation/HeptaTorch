#!/usr/bin/env python3
import hashlib, sys, types
from pathlib import Path
sys.dont_write_bytecode=True
path=Path(__file__).resolve().with_name("bridge.py")
raw=path.read_bytes()
if hashlib.sha256(raw).hexdigest() != 'f3b19a8dcc1a004323e033f414e801a52f12b0f0d556e6cbc005169d26fdef9e':
    raise ValueError("exact current736 Half47 bridge required")
bridge=types.ModuleType("current736_half47_bridge");bridge.__file__=str(path)
exec(compile(raw,str(path),"exec"),bridge.__dict__)
if __name__=="__main__":raise SystemExit(bridge.main())
