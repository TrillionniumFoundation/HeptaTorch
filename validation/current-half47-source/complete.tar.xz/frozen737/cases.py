"""Fixed new Tensor boundary recipes, distinct from the original26 groups."""
from common import canonical, require, sha

DTYPES = {0:'float32',1:'bool',2:'int64',3:'float64',4:'float64',5:'float16',6:'bfloat16'}
WIDTH = {0:4,1:1,2:8,3:8,4:8,5:2,6:2}


def create(name,dtype,shape,words,requires=False):
    return dict(kind='create',name=name,dtype=dtype,shape=shape,words=words,requires=requires)


def cast(name,source,target,copy=True,format=0,opcode=108):
    return dict(kind='cast',name=name,source=source,target=target,copy=copy,format=format,opcode=opcode)


def view(name,source,shape,strides,offset=0):
    return dict(kind='view',name=name,source=source,shape=shape,strides=strides,offset=offset)


def raw_words(dtype,words):
    if isinstance(words,dict):
        require(words=={'all_u16':True} and dtype in (5,6),'only-explicit-all-u16-input-recipe')
        words=range(65536)
    return b''.join(int(v).to_bytes(WIDTH[dtype],'little') for v in words)


CASES=[]
F32=[0x3f800000,0xbf800000,0x3f001000,0x3eaaaaab,1,0x7f800000]
for family,dtype in [('F16',5),('BF16',6)]:
    one=0x3c00 if dtype==5 else 0x3f80
    nan=0x7e11 if dtype==5 else 0x7fc1
    rows=[
      ('rank0',[
        create('source',0,[],[0x3f801000]),cast('half','source',dtype),
        cast('wide','half',0,opcode=109),cast('alias','half',dtype,copy=False),
        dict(kind='set',source='half',index=0,bits=0x8000),
        dict(kind='fill',source='half',bits=one)]),
      ('raw-alias-copy-Version',[
        create('half',dtype,[5],[0,0x8000,one,nan,0xffff]),
        cast('alias','half',dtype,copy=False),cast('copy','half',dtype),
        cast('copy109','half',dtype,format=1,opcode=109),
        dict(kind='set',source='half',index=2,bits=nan),
        dict(kind='fill',source='half',bits=0x8000)]),
      ('dense-permutation',[
        create('base',0,[2,3],F32),view('source','base',[3,2],[1,3]),
        cast('half','source',dtype),cast('contiguous','half',dtype,format=1),
        cast('wide','half',0,opcode=109)]),
      ('offset-strided-source',[
        create('base',0,[10],F32+F32[:4]),view('source','base',[3],[3],1),
        cast('half','source',dtype,opcode=109),cast('wide','half',0)]),
      ('zero-stride-overlap',[
        create('base',0,[3],F32[:3]),view('source','base',[2,3],[0,1]),
        cast('half','source',dtype),cast('wide','half',0,opcode=109)]),
      ('empty-rank3',[
        create('source',0,[2,0,3],[]),cast('half','source',dtype),
        cast('copy','half',dtype,opcode=109),dict(kind='fill',source='half',bits=0x8000),
        cast('wide','half',0)]),
      ('rank4-raw',[
        create('half',dtype,[1,2,1,2],[0,0x8000,one,one|0x8000]),
        cast('copy','half',dtype,format=1),cast('wide','half',0),
        dict(kind='set',source='half',index=3,bits=1)]),
      ('all65536-same-dtype-bits',[
        create('half',dtype,[65536],{'all_u16':True}),
        cast('copy','half',dtype),cast('copy109','half',dtype,opcode=109),
        cast('alias','half',dtype,copy=False)]),
    ]
    CASES += [dict(name=family+'-'+name,family=family,dtype=dtype,actions=actions) for name,actions in rows]
CASE_SHA256=sha(canonical(CASES))
BOUNDARY_CONTRACT={
    'cases':16,'rank0_and_empty_and_rank4':True,'all65536_same_dtype_payloads':True,
    'dense_permutation_nondense_offset_zero_stride_F32_source':True,
    'actual_raw_set_fill_and_shared_Version':True,'fresh_Tensor_Storage_Version_and_alias':True,
    'public_half_views_supported':False,'noAD':True,'original26_denominator_changed':False}
OOM_SPECS=[dict(name=family+'-'+direction+'-Storage-OOM-recovery',family=family,dtype=dtype,
               direction=direction,count=65536)
           for family,dtype in [('F16',5),('BF16',6)] for direction in ('narrow','widen')]
TASK_COUNTS={'numeric':26,'boundary':16,'entry':1,'allocation':4,'children':47}
