#!/usr/bin/env python3
"""First actual ordinary F16/BF16 Tensor qualification on one pinned 737 ELF."""
import sys
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import argparse
import json
import struct
import traceback

from common import (HERE, SOURCE, IMAGE, CHECKS, Inputs, bind_package, candidate_admission,
                    cold_admission, dump, parse, require, sha)
from cases import CASES, CASE_SHA256, BOUNDARY_CONTRACT, OOM_SPECS, TASK_COUNTS, raw_words
from corpus import groups, public_plan, comparison_functions
from native import Native, WIRE, make_owner


def words(raw, width):
    require(width in (2, 4) and len(raw) % width == 0, 'complete-half-or-F32-words')
    return [item[0] for item in struct.iter_unpack('<H' if width == 2 else '<I', raw)]


class Reference:
    def __init__(self, path, expected, inputs, plan, producer_manifest, comparison_proof):
        self.root = path.resolve(strict=True).parent
        self.data = parse(inputs.bind(path, expected))
        d = self.data
        require(d['schema'] == 'heptatorch.half737.tensor-reference26.v1' and d['status'] == 'OBSERVED'
                and d['Torch_executed'] is True and d['native_executed'] is False
                and d['inputs_unchanged'] is True and d['failures'] == [],
                'complete-new-real-Torch-reference')
        require(d['producer_manifest_sha256'] == producer_manifest and d['producer_source_sha256'] == SOURCE
                and d['source_admission']['source_sha256'] == SOURCE
                and d['source_admission']['whole_inverse_to730'] is True,
                'actual-producer-package-and-frozen737-namespace')
        provenance = d['oracle_provenance']
        require(provenance['status'] == 'PASS' and set(provenance['checks']) == CHECKS
                and all(value is True for value in provenance['checks'].values())
                and d['torch_version'] == '2.15.0+cpu'
                and d['torch_git_version'] == 'd0f2af8b66b20da4baa50644c0cd3f887a2eae2e'
                and d['num_threads'] == 1, 'fixed-official-wheel-and-all11-provenance-checks')
        require(d['expected_numeric_groups'] == len(d['groups']) == 26
                and d['expected_boundary_cases'] == len(d['boundary_cases']) == len(CASES) == 16
                and d['expected_allocation_references'] == len(d['allocation_recovery']) == 4
                and d['case_plan'] == [public_plan(g) for g in plan]
                and d['boundary_case_sha256'] == CASE_SHA256 and d['boundary_plan'] == CASES
                and d['boundary_contract'] == BOUNDARY_CONTRACT
                and d['old_standalone_refusals_not_transferred'] == 12,
                'original26-and-exact-new16-plus4-reference-census')
        require(d['original_comparison_inverse'] == comparison_proof
                and d['original_reference_expression_proof'] == dict(
                    F16_complete_original_Torch_function=True,
                    BF16_complete_original_Torch_branch_and_result_statement=True,
                    host_numeric_expected_values_used=False,
                    compiler_or_native_or_original_main_called=False),
                'unchanged-original-Torch-expressions-and-comparison-spans')
        self.blobs = {}
        for digest, row in d['blob_manifest'].items():
            require(digest == row['sha256'] and row['path'] == 'blobs/' + digest + '.bin',
                    'safe-exact-real-reference-blob-path')
            self.blobs[digest] = inputs.bind(self.root / row['path'], digest, row['bytes'], row['mode'])
        require(len(self.blob(d['rng'])) == 5056, 'reference-entire-RNG-state')
        for index, (group, observed) in enumerate(zip(plan, d['groups'])):
            require(observed['status'] == 'OBSERVED'
                    and all(observed[key] == value for key, value in public_plan(group).items())
                    and observed['original_function_witness_matches'] is True
                    and observed['input_unchanged'] is True, 'original-group-and-actual-expression-witness')
            require(self.blob(observed['source']['logical']) == group['raw']
                    and len(self.blob(observed['original_reference_words'])) ==
                        group['output_width'] * len(group['values'])
                    and self.blob(observed['result']['logical']) ==
                        self.blob(observed['original_reference_words'])
                    and self.blob(observed['rng']) == self.blob(d['rng']),
                    'complete-original-input-and-actual-Torch-result-words')
            require(parse(inputs.bind(self.root / ('numeric-%02d.json' % index))) == observed,
                    'numeric-standalone-reference-identical')
        for index, (spec, observed) in enumerate(zip(CASES, d['boundary_cases'])):
            require(observed['status'] == 'OBSERVED' and observed['name'] == spec['name']
                    and observed['spec'] == spec and observed['rng_unchanged'] is True
                    and self.blob(observed['rng']) == self.blob(d['rng']), 'complete-real-boundary-reference')
            require(parse(inputs.bind(self.root / ('boundary-%02d.json' % index))) == observed,
                    'boundary-standalone-reference-identical')
            labels = ['%02d-%s' % (i, action['kind']) for i, action in enumerate(spec['actions'])]
            names = [a['name'] for a in spec['actions'] if a['kind'] in ('create', 'view', 'cast')]
            labels += ['drop-' + name for name in names[::-1]]
            require([mark['label'] for mark in observed['marks']] == labels,
                    'every-original-recipe-action-and-drop-observed')
            for mark in observed['marks']:
                require(set(mark['live_roles']) == set(mark['tensors']) == set(mark['comparisons']),
                        'reference-all-live-roles-have-observation-and-comparison')
                for tensor in mark['tensors'].values():
                    self.blob(tensor['logical']); self.blob(tensor['storage'])
                for context in mark['comparisons'].values():
                    if context is not None:
                        require(context['family'] == spec['family'] and context['mode'] in (0, 1)
                                and context['input_width'] == (4 if context['mode'] == 0 else 2),
                                'boundary-original-comparison-context')
                        self.blob(context['input'])
        for index, (spec, observed) in enumerate(zip(OOM_SPECS, d['allocation_recovery'])):
            require(observed['status'] == 'OBSERVED' and observed['spec'] == spec
                    and observed['out_of_memory_is_native_resource_control_not_Torch_claim'] is True
                    and self.blob(observed['rng']) == self.blob(d['rng']), 'four-real-recovery-references')
            require(parse(inputs.bind(self.root / ('allocation-%02d.json' % index))) == observed,
                    'recovery-standalone-reference-identical')
            for key in ('source', 'result'):
                self.blob(observed[key]['logical']); self.blob(observed[key]['storage'])

    def blob(self, row):
        raw = self.blobs[row['sha256']]
        require(row['path'] == 'blobs/' + row['sha256'] + '.bin'
                and len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'bound-reference-blob-record')
        return raw


class Driver:
    def __init__(self, args, owner, directory, reference, compare):
        self.args, self.owner, self.directory, self.reference = args, owner, directory, reference
        self.compare = compare
        self.checks, self.marks, self.operations = [], [], []
        self.live = {}
        self.n = Native(args.build_directory / 'heptatorch', args.build_directory / 'runtime.hepta',
                        owner, directory, args.expected_native_sha256)
        self.gen = None
        try:
            self.gen = self.n.one(60, 1729)['value']
            self.rng = self.n.one(63, self.gen)['payload']
            self.check('complete-native-RNG-equals-fixed-Torch', self.rng, reference.blob(reference.data['rng']))
        except BaseException:
            self.n.finish()
            raise

    def check(self, label, actual, expected):
        def summarize(value):
            return dict(bytes=len(value), sha256=sha(value)) if isinstance(value, bytes) else value
        row = dict(label=label, actual=summarize(actual), expected=summarize(expected), passed=actual == expected)
        self.checks.append(row)
        require(row['passed'], 'actual-native-comparison', **row)

    def rng_unchanged(self, label):
        self.check(label + '/complete5056-RNG', self.n.one(63, self.gen)['payload'], self.rng)

    def observe(self, token, wanted, comparison=None, label='tensor', defer_original_loop=False):
        got = self.n.tensor(token)
        keys = ('dtype', 'device', 'element_size', 'shape', 'strides', 'numel', 'storage_bytes',
                'storage_offset_elements', 'storage_offset_bytes', 'version', 'requires_grad',
                'is_leaf', 'is_view', 'grad_fn', 'grad_is_none', 'retains_grad')
        for key in keys:
            self.check(label + '/' + key, got[key], wanted[key])
        self.check(label + '/base-present', got['base_tensor_identity'] is not None,
                   wanted['base_tensor_identity'] is not None)
        expected = self.reference.blob(wanted['logical'])
        self.check(label + '/logical-byte-count', len(got['logical']), len(expected))
        counts = None
        if comparison is None and not defer_original_loop:
            self.check(label + '/all-logical-bits', got['logical'], expected)
            self.check(label + '/all-physical-Storage-bits', got['storage'], self.reference.blob(wanted['storage']))
        else:
            # Numerical predicates are exactly the original per-family loops.
            # Prove their logical enumeration also covers every physical byte
            # of this owned dense result, including dense permutations.
            self.check(label + '/owned-zero-storage-offset', got['storage_offset_bytes'], 0)
            self.check(label + '/owned-storage-exact-width', got['storage_bytes'], got['numel'] * got['element_size'])
            offsets = []
            for index in range(got['numel']):
                remaining, address = index, 0
                for size, stride in zip(got['shape'][::-1], got['strides'][::-1]):
                    address += (remaining % size) * stride
                    remaining //= size
                offsets.append(address)
            require(sorted(offsets) == list(range(got['numel'])), 'all-physical-result-words-covered-once')
            if not defer_original_loop:
                counts = self.compare(comparison['family'], comparison['mode'],
                    words(self.reference.blob(comparison['input']), comparison['input_width']),
                    words(got['logical'], got['element_size']), words(expected, got['element_size']))
        self.marks.append(dict(label=label, observed={k:v for k,v in got.items() if k not in ('logical','storage')},
            logical_bytes=len(got['logical']), logical_sha256=sha(got['logical']), storage_sha256=sha(got['storage']),
            original_comparison_context=comparison, original_comparison_deferred=defer_original_loop,
            original_comparison_counts=counts))
        return got

    def mark(self, expected):
        self.check(expected['label'] + '/live-roles', list(self.live), expected['live_roles'])
        current = {name:self.observe(token, expected['tensors'][name], expected['comparisons'][name],
                    expected['label'] + '/' + name) for name,token in self.live.items()}
        for pair, relation in expected['relations'].items():
            left,right = pair.split('|')
            self.check(expected['label'] + '/' + pair + '/same-Tensor',
                current[left]['tensor_identity'] == current[right]['tensor_identity'], relation['same_Tensor'])
            self.check(expected['label'] + '/' + pair + '/same-Storage',
                current[left]['storage_identity'] == current[right]['storage_identity'], relation['same_Storage'])
        for name,wanted in expected['tensors'].items():
            for other,ref in expected['tensors'].items():
                self.check(expected['label'] + '/' + name + '/base-is-' + other,
                    current[name]['base_tensor_identity'] == current[other]['tensor_identity'],
                    wanted['base_tensor_identity'] == ref['tensor_identity'])
        self.rng_unchanged(expected['label'])

    def drop(self, name):
        token = self.live.pop(name)
        if token not in self.live.values():
            self.n.one(41, token)

    def cleanup(self):
        for name in list(self.live)[::-1]:
            self.drop(name)
        self.rng_unchanged('after-all-Tensor-release')
        self.n.one(66, self.gen)
        self.gen = None
        self.check('native-final-owner-audit', self.n.one(53)['value'], 1)
        snapshot, endpoint, raw = self.n.capture('all-public-roles-released')
        self.check('all-real-public-Tensor-slots-released', sum(r[1] for r in snapshot['tables']['1']), 0)
        self.check('all-real-generators-released', sum(r[1] for r in snapshot['tables']['7']), 0)
        self.check('all-live-Tensor-descriptor-roots-released',
            sum(bool(self.owner.w(node, 240)) for node in snapshot['nodes'].values()), 0)
        return endpoint


def numeric_case(driver, group, expected):
    driver.live['source'] = driver.n.create(group['public_source_dtype'], [len(group['values'])], group['raw'])
    driver.observe(driver.live['source'], expected['source'], label='entire-original-input')
    command = (108, driver.live['source'], group['public_target_dtype'], 1, 0)
    driver.live['result'] = driver.n.one(*command)['value']
    got = driver.observe(driver.live['result'], expected['result'], label='entire-numeric-result', defer_original_loop=True)
    actual = words(got['logical'], group['output_width'])
    wanted = words(driver.reference.blob(expected['original_reference_words']), group['output_width'])
    counts = driver.compare(group['family'], group['original_mode'], group['values'], actual, wanted)
    driver.observe(driver.live['source'], expected['source'], label='unchanged-entire-original-input')
    driver.rng_unchanged('numeric-original-group')
    return dict(public_plan(group), original_comparison=counts, actual_command=list(command),
                actual_result_sha256=sha(got['logical']), actual_result_bytes=len(got['logical']),
                complete_original_loop_executed=True, original_input_count=len(group['values']))


def boundary_case(driver, spec, expected):
    at = 0
    for event in spec['actions']:
        kind = event['kind']
        if kind == 'create':
            driver.live[event['name']] = driver.n.create(event['dtype'], event['shape'],
                raw_words(event['dtype'], event['words']), event['requires'])
        elif kind == 'view':
            driver.live[event['name']] = driver.n.view(driver.live[event['source']],
                event['shape'], event['strides'], event['offset'])
        elif kind == 'cast':
            source = driver.live[event['source']]
            before = driver.n.tensor(source)
            command = ((109, source, event['target'], event['format']) if event['opcode'] == 109 else
                       (108, source, event['target'], int(event['copy']), event['format']))
            result = driver.n.one(*command)['value']
            driver.live[event['name']] = result
            # Payload-preserving same-dtype copies compare the real source
            # and real result directly, even when conversion NaN payloads are
            # intentionally classified by the original oracle predicate.
            if before['dtype'] == ('torch.float16' if event['target'] == 5 else
                                   'torch.bfloat16' if event['target'] == 6 else 'torch.float32'):
                after = driver.n.tensor(result)
                driver.check('same-dtype-copy-preserves-all-actual16-bits', after['logical'], before['logical'])
        elif kind == 'set':
            driver.n.one(12, driver.live[event['source']], event['index'], event['bits'])
        elif kind == 'fill':
            driver.n.one(100, driver.live[event['source']], event['bits'], 0)
        else:
            raise ValueError(kind)
        driver.mark(expected['marks'][at]); at += 1
    for name in list(driver.live)[::-1]:
        driver.drop(name); driver.mark(expected['marks'][at]); at += 1
    driver.check('all-fixed-reference-marks-consumed', at, len(expected['marks']))
    return dict(reference_marks_completed=at, raw_set_fill_and_same_dtype_bits_checked=True)


def run_child(args, owner, directory, reference, compare, name, function):
    row = dict(name=name, status='FAIL', error=None, native_started=False)
    driver = None
    try:
        driver = Driver(args, owner, directory, reference, compare)
        row['native_started'] = True
        row['details'] = function(driver)
        row['cleanup_owner'] = driver.cleanup()
        row['status'] = 'PASS'
    except BaseException as error:
        row['error'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
    finally:
        if driver is not None:
            try:
                row['transport'] = driver.n.finish()
            except BaseException as error:
                row['status'] = 'FAIL'
                row['EOF_error'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
            row.update(frames=driver.n.s.frames, checks=driver.checks, observations=driver.marks,
                       operations=driver.operations)
        elif (directory / 'raw/transport.json').exists():
            # A constructor may fail after the actual child was created.
            # Preserve that execution fact and its real EOF result.
            row['transport'] = parse((directory / 'raw/transport.json').read_bytes())
            row['native_started'] = True
            row['frames'] = row['transport']['frames']
        if directory.exists():
            dump(directory / 'report.json', row)
    return row


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('candidate','build-directory','reference','output'):
        p.add_argument('--' + name, required=True, type=Path)
    for name in ('expected-source-sha256','expected-native-sha256','expected-build-sha256','expected-reference-sha256'):
        p.add_argument('--' + name, required=True)
    p.add_argument('--prepare-only', action='store_true'); args = p.parse_args()
    require(not sys.flags.optimize, 'all-original-assertions-enabled')
    require(args.expected_source_sha256 == SOURCE and args.expected_native_sha256 == IMAGE,
            'exact-half737-source-and-first-actual-image')
    args.build_directory = args.build_directory.resolve(strict=True)
    args.candidate = args.candidate.resolve(strict=True)
    out = args.output.resolve()
    for path in (HERE, args.candidate, args.build_directory, args.reference.resolve().parent):
        require(not out.is_relative_to(path) and not path.is_relative_to(out), 'fresh-output-outside-all-input-trees')
    out.mkdir(parents=True, exist_ok=False)
    inputs, code = Inputs(), 1
    result = dict(schema='heptatorch.half737.tensor-native26.v1', status='PREPARED_NOT_RUN',
        source_sha256=SOURCE, native_sha256=IMAGE, actual_build_sha256=args.expected_build_sha256,
        reference_sha256=args.expected_reference_sha256, native_executed=False, Torch_executed=False,
        compiler_executed=False, expected_counts=TASK_COUNTS, numeric_groups=[], boundary_cases=[],
        entry_groups=[], allocation_controls=[], failures=[], all_inputs_unchanged=False,
        boundary_contract=BOUNDARY_CONTRACT, original_numeric_groups=26, original_input_values=908216,
        original_comparison_predicates_modified=False, original_standalone_refusals_not_transferred=12,
        ordinary_half_AD_supported=False, full_dtype_gate_closed=False, full_project_status='HOLD',
        full_transition_recomputed=False)
    try:
        package = bind_package(inputs); result['reader_manifest_sha256'] = package
        result['source_admission'] = candidate_admission(args.candidate, inputs)
        result['cold_admission'] = cold_admission(args.build_directory, IMAGE,
            args.expected_build_sha256, args.candidate, inputs)
        plan = groups(args.candidate, inputs)
        compare, result['original_comparison_inverse'] = comparison_functions(args.candidate, inputs)
        reference = Reference(args.reference, args.expected_reference_sha256, inputs, plan, package,
                              result['original_comparison_inverse'])
        result['case_plan'] = [public_plan(g) for g in plan]
        if not args.prepare_only:
            from controls import entry_controls, allocation_control
            owner = make_owner(args.candidate, IMAGE, inputs)
            result['native_executed'] = True
            tasks = []
            for index,(group,expected) in enumerate(zip(plan,reference.data['groups'])):
                tasks.append(('numeric_groups','numeric-%02d' % index,group['name'],
                              lambda d,g=group,r=expected:numeric_case(d,g,r)))
            for index,(spec,expected) in enumerate(zip(CASES,reference.data['boundary_cases'])):
                tasks.append(('boundary_cases','boundary-%02d' % index,spec['name'],
                              lambda d,s=spec,r=expected:boundary_case(d,s,r)))
            tasks.append(('entry_groups','entry-00','public5-6-private3-and-noAD-refusals',entry_controls))
            for index,(spec,expected) in enumerate(zip(OOM_SPECS,reference.data['allocation_recovery'])):
                tasks.append(('allocation_controls','allocation-%02d' % index,spec['name'],
                              lambda d,s=spec,r=expected:allocation_control(d,s,r)))
            require(len(tasks) == 47, 'all47-independent-native-children-planned')
            for category,directory,name,function in tasks:
                row = run_child(args, owner, out / directory, reference, compare, name, function)
                result[category].append(row)
                if row['status'] != 'PASS':
                    result['failures'].append(dict(group=category,name=name,error=row['error'],EOF_error=row.get('EOF_error')))
            require([len(result[k]) for k in ('numeric_groups','boundary_cases','entry_groups','allocation_controls')]
                    == [26,16,1,4], 'all47-mandatory-tasks-completed')
            children = [row for category in ('numeric_groups','boundary_cases','entry_groups','allocation_controls')
                        for row in result[category]]
            result['native_children'] = len(children)
            result['frames'] = sum(row.get('frames',0) for row in children)
            result['status'] = 'PASS' if not result['failures'] and all(r['status'] == 'PASS' for r in children) else 'FAIL'
        code = 0 if result['status'] in ('PASS','PREPARED_NOT_RUN') else 1
    except BaseException as error:
        result['status'] = 'FAIL'
        result['failures'].append(dict(stage='admission-or-run',type=type(error).__name__,
                                      message=str(error),traceback=traceback.format_exc()))
    finally:
        try: result['all_inputs_unchanged'] = inputs.unchanged()
        except BaseException as error:
            result['status'] = 'FAIL'; result['failures'].append(dict(stage='input-recheck',error=repr(error)))
        if result['status'] == 'FAIL': code = 1
        result['inputs'] = inputs.rows; dump(out / 'report.json',result)
    print(json.dumps({k:result[k] for k in ('status','expected_counts','native_executed')}))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
