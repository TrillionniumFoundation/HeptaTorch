"""Custody and pure admission helpers; never a numerical implementation."""
import ast
import hashlib
import importlib.util
import json
import os
import re
import stat
import types
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = 'e2eedf870e306572672817cfc98bcf49d9aeacc0657c04dbaf50e5e6f5ceb66d'
IMAGE = '4ef74a024572ed6e37f33544a0b7dfbcad37d93a5e9da40afa633e0773aa3807'
BASELINE = '82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313'
CANDIDATE_MANIFEST = '14cc6731198a0524ec8ee70843d0ca2ab44c8d239b7b4fd43b48d2f3593dead5'
PARTITION_MANIFEST = '3af7c65e81673985b03cf810f849c734949a07e520d02385a4f9ff7a14c9629e'
OWNER = 'db8dfd3ce4c845049a521a2612be4b53c295248daa748c31da3b2ccdd22dfc61'
OLD_OWNER = 'c39600e7c37dea390f88cf9e74d86dfa924301456e0f32e127d82c98ad6778b0'
MAPPING = '79cbe8921e57eb32a2da20588a7e7a13acbcef05de31319dc4b66add0bab942a'
ORACLE = 'bb639f7ef669d34787986ed62e870cc61071adcba1ae4e44e325673e2f75bb03'
SUPPORT = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
CHECKS = {'python_matches', 'platform_matches', 'version_backend_matches',
          'git_matches_oracle_build_pin', 'distribution_version_matches',
          'direct_url_matches', 'direct_url_archive_sha256_matches',
          'pip_report_url_matches', 'pip_report_archive_sha256_matches',
          'pip_report_version_matches', 'pip_report_requested'}


def require(value, rule, **facts):
    if not value:
        raise AssertionError({'rule': rule, **facts})


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def dump(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate-JSON-key', key=key)
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique)


def identity(st):
    return (st.st_dev, st.st_ino, st.st_size, st.st_mode, st.st_mtime_ns, st.st_ctime_ns)


class Inputs:
    def __init__(self):
        self.rows = {}

    def bind(self, path, expected=None, size=None, mode=None):
        path = Path(path).absolute()
        require(not path.is_symlink(), 'input-is-not-symlink', path=str(path))
        before = path.stat()
        require(stat.S_ISREG(before.st_mode), 'regular-input', path=str(path))
        raw = path.read_bytes()
        after = path.stat()
        require(identity(before) == identity(after), 'input-changed-during-read', path=str(path))
        row = dict(bytes=len(raw), sha256=sha(raw), mode=stat.S_IMODE(after.st_mode),
                   identity=list(identity(after)))
        require(expected is None or row['sha256'] == expected, 'input-sha256', path=str(path),
                expected=expected, actual=row['sha256'])
        require(size is None or len(raw) == size, 'input-size', path=str(path))
        require(mode is None or row['mode'] == mode, 'input-mode', path=str(path))
        require(str(path) not in self.rows or self.rows[str(path)] == row,
                'inconsistent-input-binding', path=str(path))
        self.rows[str(path)] = row
        return raw

    def unchanged(self):
        # Never convert a failed recheck into a truthy report containing False.
        for name, row in list(self.rows.items()):
            self.bind(name, row['sha256'], row['bytes'], row['mode'])
        return True


def bind_package(inputs):
    raw = inputs.bind(HERE / 'source-manifest.json')
    manifest = parse(raw)
    expected = set(manifest['files'])
    actual = {str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()}
    require(actual == expected | {'source-manifest.json'}, 'complete-source-package-members')
    for name, row in manifest['files'].items():
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts, 'safe-source-member')
        inputs.bind(HERE / path, row['sha256'], row['bytes'], row['mode'])
    return sha(raw)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def bodies(raw):
    matches = re.findall(rb'^(fn (\w+)\([^\n]*\n.*?^end\n)', raw, re.M | re.S)
    result = {name.decode(): body for body, name in matches}
    require(len(matches) == len(result), 'unique-function-names')
    return result


def candidate_admission(directory, inputs):
    directory = Path(directory).resolve(strict=True)
    manifest = parse(inputs.bind(directory / 'source-package-manifest.json', CANDIDATE_MANIFEST))
    expected = set(manifest['files'])
    actual = {str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file()}
    require(actual == expected | {'source-package-manifest.json'}, 'complete-candidate-package')
    for name, row in manifest['files'].items():
        p = Path(name)
        require(not p.is_absolute() and '..' not in p.parts, 'safe-candidate-member')
        inputs.bind(directory / p, row['sha256'], row['bytes'], row['mode'])
    c = directory / 'candidate'
    source = inputs.bind(c / 'runtime.hepta', SOURCE)
    original = inputs.bind(c / 'baseline-runtime.hepta', BASELINE)
    before, after = bodies(original), bodies(source)
    change = parse(inputs.bind(c / 'transition.json'))
    require(len(before) == 701 and len(after) == 719 and len(change['changed']) == 15
            and len(change['added']) == 18, 'candidate-body-census')
    restored = source
    for name, row in reversed(list(change['added'].items())):
        body = inputs.bind(c / 'added' / (name + '.hepta'), row['sha256'], row['bytes'])
        require(after[name] == body and restored.count(body) == 1, 'exact-added-body', name=name)
        restored = restored.replace(body, b'', 1)
    for name, row in change['changed'].items():
        old = inputs.bind(c / 'before' / (name + '.hepta'), row['before_sha256'])
        new = inputs.bind(c / 'after' / (name + '.hepta'), row['after_sha256'])
        require(before[name] == old and after[name] == new and restored.count(new) == 1,
                'exact-modified-body', name=name)
        restored = restored.replace(new, old, 1)
    # Header handling is recorded by the frozen candidate author, not guessed.
    # This candidate retains its original module header and body separators.
    require(restored == original, 'entire-719-to-701-source-inverse')
    require(sum(before[n] == after[n] for n in before) == 686, 'all-686-original-bodies')
    numeric = bodies(inputs.bind(HERE / 'frozen/f64.hepta',
        '44a6ff00413829d3cf8f7fbd91fb96a6baf090c3c754882d4361f49ed85a2e56'))
    for name in ('pack64', 'add64', 'sub64', 'multiply_high', 'mul64', 'div64', 'widen32', 'narrow64',
                 'getr', 'shrjam', 'packf'):
        require(after[name] == numeric[name], 'whole-original-numerical-body', function=name)
    require('sqrt64' not in after, 'standalone-sqrt-not-added-to-Tensor-runtime')
    owner = inputs.bind(c / 'owner_f64.py', OWNER)
    old_owner = inputs.bind(c / 'frozen-owner-integral.py', OLD_OWNER)
    od = parse(inputs.bind(c / 'owner-derivation.json'))
    marker = b'\n\n# BEGIN EXPLICIT PUBLIC F64 OBSERVATION;'
    require(owner.count(marker) == 1, 'owner-one-additive-layer')
    base, additive = owner.split(marker, 1)
    # The frozen derivation hashes include the leading newline in the suffix.
    suffix = marker + additive
    require(sha(suffix) == od['additive_sha256'], 'owner-additive-layer-identity')
    inverse = base.decode()
    for old, new, count in reversed(od['edits']):
        require(inverse.count(new) == count, 'owner-inverse-edit-count', text=new)
        inverse = inverse.replace(new, old, count)
    require(inverse.encode() == old_owner, 'entire-original-owner-inverse')
    mapping = parse(inputs.bind(directory / 'original55-mapping.json', MAPPING))
    require(mapping['category_counts'] == {'numerical_tensor_candidate_scope': 33,
            'sqrt_not_exposed': 6, 'standalone_packet_refusal': 16}
            and mapping['original_strict_pytorch_status'] == 'FAIL'
            and mapping['original_strict_pytorch_non_nan_mismatches'] == 4008,
            'unchanged-original55-denominator-and-failures')
    initial = parse(inputs.bind(HERE / 'frozen/hosted-native-f64-initial-failure.json',
        'c0c9fbf13d763ab6cf3145451530695c05c3f29ab653c2b5fdf9cfcfa430727a'))
    require(initial['status'] == 'FAIL' and initial['strict_frozen_oracle_unchanged'] is True
            and len(initial['reports']) == 2, 'complete-original-first-failure-retained')
    original_torch = next(r for r in initial['reports'] if r['reference'] == 'pytorch')
    require(original_torch['status'] == 'FAIL' and original_torch['cases'] == 55
            and original_torch['failed_cases'] == 4, 'original55-four-strict-failures-retained')
    later = parse(inputs.bind(HERE / 'frozen/hosted-native-f64.json',
        'ffcb6b7f0ee213cef32259d3a46153a1ec2212ada9d43d4ec69c331c1f0a13c4'))
    require(later['strict_pytorch_bitwise_gate_closed'] is False and later['full_dtype_gate_closed'] is False
            and later['independent_rne_reference_accuracy_report']['sqrt_bitwise_mismatch_count'] == 4008,
            'complete-original4008-differences-and-open-gates-retained')
    return dict(schema='heptatorch.f64.tensor-source-admission.v1', source_sha256=SOURCE,
                candidate_manifest_sha256=CANDIDATE_MANIFEST, functions=719,
                whole_inverse_to_823=True, unchanged_old_bodies=686,
                original_owner_whole_inverse=True, dtype_domain_extension=[4],
                private_scalar3_preserved=True, mapping_sha256=MAPPING,
                numerical_expected_values_changed=False, runtime_qualification_transferred=False)


def cold_admission(directory, image_sha, report_sha, inputs):
    require(image_sha == IMAGE, 'exact-first-real-cold-built719-image')
    for value in (image_sha, report_sha):
        require(re.fullmatch('[0-9a-f]{64}', value) is not None, 'explicit-actual-build-and-image-pin')
    old = inputs.bind(HERE / 'frozen/admission701.py',
        '5b7b9a538877c06bce9daff0631657ae3b9ce79bcd7336d42839a01ef9cbcfde')
    edits = [
        ('de4fdf964a74be11acfeddcf5fe16656c6cfa671fc7917585a72364918387a92', SOURCE, 1),
        ('75e29e13c0a7f14395fd21acb82686279dc962615ae6bcde3176b72083cac971', image_sha, 1),
        ('current701', 'current719', 4), ('CURRENT701', 'CURRENT719', 1),
        ('== 701', '== 719', 2), ("'functions': 701", "'functions': 719", 1)]
    new = old.decode()
    for a, b, count in edits:
        require(new.count(a) == count, 'cold-admission-literal-count', text=a)
        new = new.replace(a, b, count)
    inverse = new
    for a, b, count in reversed(edits):
        require(inverse.count(b) == count, 'cold-admission-inverse-count', text=b)
        inverse = inverse.replace(b, a, count)
    require(inverse.encode() == old, 'entire-original-cold-admission-inverse')
    class Shape(ast.NodeTransformer):
        def visit_Constant(self, node):
            return ast.copy_location(ast.Constant(value=type(node.value).__name__), node)
    require(ast.dump(Shape().visit(ast.parse(new))) == ast.dump(Shape().visit(ast.parse(old))),
            'cold-admission-only-literals-changed')
    module = types.ModuleType('f64_exact_cold_admission')
    exec(compile(new, '<derived-complete-cold-admission>', 'exec'), module.__dict__)
    directory = Path(directory).resolve(strict=True)
    result = module.admit_build(directory, report_sha, directory / 'heptatorch', directory / 'runtime.hepta')
    inputs.bind(directory / 'manifest.json', PARTITION_MANIFEST)
    for name, row in result['files'].items():
        inputs.bind(name, row['sha256'], row['bytes'], row['mode'])
    result['identity_inverse'] = dict(frozen_sha256=sha(old), executed_sha256=sha(new.encode()),
        edits=edits, whole_file_inverse_exact=True, only_literal_changes=True,
        original_14_units_and_15_actual_tool_processes_retained=True,
        original_three_argument_step_ABI_retained=True)
    return result
