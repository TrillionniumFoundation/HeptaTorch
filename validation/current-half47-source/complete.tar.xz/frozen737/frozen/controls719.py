"""Real public-Tensor boundary and two independent allocation-failure controls."""
import resource
import struct
from pathlib import Path

from common import dump, require, sha
from native import WIRE


def reject(driver, label, body, expected, *, mappings=False):
    maps = Path('/proc/%d/maps' % driver.n.s.pid)
    before = maps.read_bytes() if mappings else None
    status, records = driver.n.exchange(body, label)
    driver.operations.append(dict(label=label, request_sha256=sha(body), actual_status=status,
                                  expected_status=expected, record_count=len(records)))
    driver.check(label + '/actual-frame-status', status, expected)
    driver.check(label + '/no-published-result', records, [])
    if mappings:
        after = maps.read_bytes()
        (driver.directory / (label + '.maps-before')).write_bytes(before)
        (driver.directory / (label + '.maps-after')).write_bytes(after)
        driver.check(label + '/all-mappings-unchanged', after, before)
    return status


def entry_controls(driver):
    f64 = driver.n.create(4, [2], struct.pack('<2Q', 0x3ff0000000000000, 0x8000000000000000))
    f32 = driver.n.create(0, [2], struct.pack('<2I', 0x3f800000, 0x80000000))
    boolean = driver.n.create(1, [2], b'\1\0')
    integer = driver.n.create(2, [2], struct.pack('<2Q', 1, 0))
    grad = driver.n.create(0, [2], struct.pack('<2I', 0x3f800000, 0x40000000), True)
    driver.live.update(f64=f64, f32=f32, boolean=boolean, integer=integer, f32_requires_grad=grad)
    graph = driver.n.one(114, grad, 0x3ff0000000000000)['value']
    wrapped = driver.n.one(107, graph, 1)['value']
    driver.live.update(original_scalar_graph=graph, original_private_scalar3=wrapped)
    private = struct.unpack('<4Q', driver.n.one(96, wrapped, 0)['payload'])
    driver.check('genuine-original-Saved-private-scalar3-dtype', private[0], 3)
    driver.check('genuine-private-scalar3-width', private[1], 8)
    private_meta = WIRE.meta(driver.n.one(13, wrapped))
    driver.check('genuine-private-scalar3-rank-and-numel',
                 [private_meta['rank'], private_meta['numel']], [0, 1])
    original = {name: driver.n.tensor(token) for name, token in driver.live.items()}
    refusal = lambda label, cmd, cause: reject(driver, label, WIRE.packet([cmd]), cause)
    for dtype in (3, 5, 6, 7, 255, (1 << 64) - 1):
        reject(driver, 'public-factory-dtype-' + str(dtype),
               driver.n.factory_packet(dtype, [2], struct.pack('<2Q', 1, 2)), 7)
    reject(driver, 'F64-factory-requires-grad',
           driver.n.factory_packet(4, [2], struct.pack('<2Q', 1, 2), True), 5)
    for opcode in (108, 109):
        refusal('grad-F32-to-F64-' + str(opcode), (opcode, grad, 4, 0, 0), 5)
        for target in (1, 2, 3, 5):
            refusal('F64-to-unsupported-%d-%d' % (opcode, target), (opcode, f64, target, 0, 0), 7)
        for name, token in (('Bool', boolean), ('I64', integer)):
            refusal(name + '-to-F64-' + str(opcode), (opcode, token, 4, 0, 0), 7)
        refusal('private-scalar3-to-public-F64-' + str(opcode), (opcode, wrapped, 4, 0, 0), 7)
    refusal('private3-F64-binary-left', (2, 1, wrapped, f64), 7)
    refusal('private3-F64-binary-right', (2, 1, f64, wrapped), 7)
    refusal('private3-raw-fill-remains-rejected', (100, wrapped, 0, 0), 7)
    refusal('private3-raw-set-remains-rejected', (12, wrapped, 0, 0), 7)
    for name, other in (('F32', f32), ('Bool', boolean), ('I64', integer)):
        for operation in (1, 2, 3, 4):
            for order, left, right in (('left', f64, other), ('right', other, f64)):
                refusal('mixed-%s-op%d-F64-%s' % (name, operation, order), (2, operation, left, right), 7)
    for operation in (0, 5, (1 << 64) - 1):
        refusal('unsupported-F64-binary-' + str(operation), (2, operation, f64, f64), 4)
    for label, command in (
        ('sqrt', (3, 11, f64)), ('neg', (3, 6, f64)),
        ('reshape', (17, f64, 1, 2, 0, 0, 0)), ('backward', (29, f64, 0)),
        ('Saved', (46, f64)),
        ('transpose', (6, f64, 0, 0)), ('clone', (18, f64)), ('detach', (19, f64)),
        ('data-alias', (55, f64)), ('legacy-cast99', (99, f64, 0)),
        ('requires-grad101', (101, f64, 1)), ('typed102', (102, f64, 0)),
        ('copy-invalid-format', (109, f64, 0, 2)), ('to-invalid-copy', (108, f64, 4, 2, 0)),
        ('to-reserved-word', (108, f64, 4, 0, 0, 1)),
        ('sum', (115, f64, 0, 0, 0, (1 << 64) - 1, 0, 0)),
        ('permute', (116, f64, 1, WIRE.Payload(struct.pack('<q', 0)), 0, 0, 0, 0))):
        refusal('unsupported-F64-' + label, command, 7)
    cfg = struct.pack('<10Q', 1, 2, 0, 0, 0, 1, 0, 0, 0, 0)
    for opcode in (69, 111):
        refusal('unsupported-F64-view-' + str(opcode), (opcode, f64, WIRE.Payload(cfg), 80), 7)
    # The unchanged tset out-of-bounds branch uses cause7, whereas the
    # independent typed-read range checks use cause2.
    refusal('raw-set-index-at-numel', (12, f64, 2, 0), 7)
    refusal('raw-read-after-end', (98, f64, 3, 1), 2)
    refusal('raw-read-overflow', (98, f64, (1 << 64) - 1, 1), 2)
    refusal('invalid-public-capability', (108, 1, 4, 0, 0), 1)
    stale = driver.n.create(4, [1], struct.pack('<Q', 1))
    driver.n.one(41, stale)
    refusal('stale-public-capability', (108, stale, 4, 0, 0), 1)
    valid = driver.n.factory_packet(4, [2], struct.pack('<2Q', 1, 2))
    short_payload = bytearray(valid[:-1])
    struct.pack_into('<Q', short_payload, 16, len(short_payload))
    reject(driver, 'factory-truncated-64-bit-payload', bytes(short_payload), 100)
    bad_offset = bytearray(valid)
    struct.pack_into('<Q', bad_offset, 96 + 6 * 8, 32)
    reject(driver, 'factory-data-offset-in-command-region', bytes(bad_offset), 100)
    # Whole-frame rejection is 100 in the unchanged real frame_valid body.
    for label, body in (
        ('empty-body', b''), ('short-header', bytes(31)),
        ('wrong-Tensor-magic', b'X' + valid[1:]),
        ('trailing-with-stale-length', valid + b'x'),
        ('truncated-with-stale-length', valid[:-1])):
        reject(driver, 'envelope-' + label, body, 100)
    # A new dtype4 object is created in a real transaction and resolved through
    # the original request-local FE alias. The second command must reject the
    # unsupported pair and restore every byte of the pre-frame owner.
    raw = struct.pack('<2Q', 0x3ff0000000000000, 0x4000000000000000)
    config = struct.pack('<8Q', 1, 0, 2, 0, 0, 0, 224, len(raw))
    commands = struct.pack('<8Q', 97, 4, 160, 0, 0, 0, 0, 0)
    commands += struct.pack('<8Q', 2, 1, WIRE.reference(1), f32, 0, 0, 0, 0)
    packet = b'HTORCH03' + struct.pack('<3Q', 2, 224 + len(raw), 0) + commands + config + raw
    reject(driver, 'same-packet-F64-public-alias-mixed-pair', packet, 7)
    commands = struct.pack('<8Q', 97, 4, 160, 0, 0, 0, 0, 0)
    commands += struct.pack('<8Q', 111, WIRE.reference(1), 224 + len(raw), 80, 0, 0, 0, 0)
    packet = b'HTORCH03' + struct.pack('<3Q', 2, 224 + len(raw) + len(cfg), 0) + commands + config + raw + cfg
    reject(driver, 'same-packet-F64-public-alias-view', packet, 7)
    for name, token in driver.live.items():
        after = driver.n.tensor(token)
        # Owner endpoints for every individual refusal were already compared
        # in full; this checks the public view of the original identities too.
        for key in ('logical', 'storage', 'shape', 'strides', 'version', 'tensor_identity',
                    'storage_identity', 'native_version_identity'):
            driver.check('all-entry-refusals-input-unchanged/' + name + '/' + key, after[key], original[name][key])
    driver.rng_unchanged('all-entry-refusals')
    return dict(actual_refusals=len(driver.operations), all_original_inputs_and_RNG_unchanged=True,
                every_error_complete_owner_rollback=True, same_packet_FE_alias_controls=2,
                unsupported_PyTorch_features_not_claimed_as_upstream_errors=True,
                ordinary_dtype4_does_not_accept_private_dtype3=True)


def resources(driver, label, *, pool=None):
    state, endpoint, raw = driver.n.capture(label)
    next_node = state['header']['next']
    page = next_node >> 8
    actual_pages = [r['page'] for r in state['pages']]
    available = {str(kind): sum(row[1] == 0 and row[0] < 0xffffffff
                               for row in state['tables'][str(kind)]) for kind in (1, 2, 3, 6)}
    total = sum(n for _, n in state['free_extents'])
    largest = max((n for _, n in state['free_extents']), default=0)
    require(page in actual_pages and next_node < 65536 and state['header']['incarnation'] < (1 << 64) - 1,
            'F64-output-descriptor-page-and-incarnation-preexist')
    require(min(available.values()) >= 4, 'all-new-output-and-publication-table-slots-preexist')
    require(16384 <= total <= 32768 and largest < 65536 * 8,
            'actual-free-extents-cannot-fit-F64-result', total=total, largest=largest)
    if pool is not None:
        driver.check(label + '/pool-unchanged', state['header']['pool'], pool)
    details = dict(owner=endpoint, pool=state['header']['pool'], total_free=total, largest_free=largest,
        requested_Storage_bytes=65536 * 8, required_descriptor_page=page, actual_pages=actual_pages,
        available_T_S_V_Hold_slots=available, next_node=next_node, free_extents=state['free_extents'])
    dump(driver.directory / (label + '.json'), details)
    return state, details


def allocation_control(driver, stage):
    require(stage in ('cast', 'binary'), 'two-explicit-allocation-stages')
    driver.live['backing'] = driver.n.create(0, [1], struct.pack('<I', 0x3f800000))
    driver.live['input'] = driver.n.view(driver.live['backing'], [65536], [0], 0)
    recovery = driver.reference.data['allocation_recovery']
    driver.observe(driver.live['input'], recovery['source'], label='zero-stride-input')
    if stage == 'binary':
        driver.live['wide'] = driver.n.one(108, driver.live['input'], 4, 0, 0)['value']
        driver.observe(driver.live['wide'], recovery['cast_result'], 5, 'original-F64-binary-input')
    saved_inputs = {name: driver.n.tensor(token) for name, token in driver.live.items()}
    initial, _, _ = driver.n.capture('before-actual-fillers')
    pool = initial['header']['pool']
    fillers = []
    for index in range(64):
        state, _, _ = driver.n.capture('filler-inspection')
        total = sum(n for _, n in state['free_extents'])
        if 16384 <= total <= 32768:
            break
        require(total > 32768, 'positive-free-space-before-pressure', total=total)
        amount = min(262144, (total - 32768) & ~15)
        require(amount > 0, 'positive-aligned-real-filler')
        token = driver.n.create(1, [amount], bytes(amount))
        driver.live['filler-%02d' % index] = token
        fillers.append(token)
        state, _, _ = driver.n.capture('after-real-filler')
        driver.check('real-filler-no-pool-growth', state['header']['pool'], pool)
    else:
        raise AssertionError('bounded native filler setup did not converge')
    state, ready = resources(driver, 'allocation-ready', pool=pool)
    command = ((108, driver.live['input'], 4, 1, 0) if stage == 'cast' else
               (2, 1, driver.live['wide'], driver.live['wide']))
    body = WIRE.packet([command])
    pid = driver.n.s.pid
    old = resource.prlimit(pid, resource.RLIMIT_AS)
    raw_status = Path('/proc/%d/status' % pid).read_bytes()
    (driver.directory / 'before-limit.status').write_bytes(raw_status)
    (driver.directory / 'before-limit.limits').write_bytes(Path('/proc/%d/limits' % pid).read_bytes())
    vm = int(next(row.split()[1] for row in raw_status.decode().splitlines() if row.startswith('VmSize:'))) * 1024
    page = lambda value: (value + 4095) & ~4095
    soft = vm + page(state['length'] + 16) + page(5056 + 16) + 65536
    require(old[1] == resource.RLIM_INFINITY or soft < old[1], 'new-limit-below-existing-hard-limit')
    dump(driver.directory / 'allocation-limit.json', dict(stage=stage, ready=ready, old_limit=list(old),
        current_vm_bytes=vm, applied_soft_limit=soft, request_sha256=sha(body),
        ordinary_same_capacity_transaction_allowance=page(state['length'] + 16),
        complete_RNG_query_allowance=page(5056 + 16), wire_and_small_mapping_allowance=65536,
        native_fillers=len(fillers), failure_stage='new-result-Storage-cannot-fit-original-pool'))
    resource.prlimit(pid, resource.RLIMIT_AS, (soft, old[1]))
    try:
        # Real successful transactions under exactly the failing limit.
        driver.n.one(96, driver.live['input'], 0)
        driver.rng_unchanged('ordinary-query-under-same-limit')
        resources(driver, 'same-limit-allocation-ready', pool=pool)
        reject(driver, 'actual-' + stage + '-Storage-OOM', body, 3, mappings=True)
        driver.rng_unchanged('after-actual-OOM')
    finally:
        resource.prlimit(pid, resource.RLIMIT_AS, old)
        driver.check('original-RLIMIT-restored', list(resource.prlimit(pid, resource.RLIMIT_AS)), list(old))
    for name, before in saved_inputs.items():
        after = driver.n.tensor(driver.live[name])
        for key in ('logical', 'storage', 'shape', 'strides', 'version', 'tensor_identity',
                    'storage_identity', 'native_version_identity'):
            driver.check('OOM-input-unchanged/' + name + '/' + key, after[key], before[key])
    status, records = driver.n.exchange(body, 'same-command-after-resource-recovery')
    driver.operations.append(dict(label='same-command-after-resource-recovery', request_sha256=sha(body),
                                  actual_status=status, expected_status=0, record_count=len(records)))
    driver.check('same-request-recovery-status', status, 0)
    driver.check('same-request-recovery-result-count', len(records), 1)
    driver.live['recovered'] = records[0]['value']
    driver.observe(driver.live['recovered'], recovery['cast_result' if stage == 'cast' else 'binary_result'],
                   5 if stage == 'cast' else 0, 'actual-recovered-result')
    after, _, _ = driver.n.capture('actual-after-recovery')
    driver.check('real-pool-growth-after-resource-limit-restored', after['header']['pool'] > pool, True)
    driver.rng_unchanged('after-actual-recovery')
    return dict(stage=stage, actual_status_sequence=[3, 0], identical_failure_and_recovery_request_sha256=sha(body),
                descriptor_and_table_allocation_ready=True, full_owner_rollback=True, all_mappings_restored=True,
                reference_result_observed_by_fixed_Torch=True, input_and_RNG_unchanged=True)
