#!/usr/bin/env python3
"""First actual fixed-wheel F64 Tensor reference; no native application calls."""
import argparse
import gc
import math
import runpy
import struct
import sys
import traceback
from pathlib import Path

from cases import CASES, CASE_SHA256, BOUNDARY_CONTRACT
from common import (HERE, CHECKS, LOCK, SUPPORT, Inputs, bind_package, canonical,
                    dump, parse, require, sha, candidate_admission)
from corpus import groups, batches, input_bytes, original_reference, comparator

DTYPES = {0: 'float32', 1: 'bool', 2: 'int64', 4: 'float64'}
WIDTH = {0: 4, 1: 1, 2: 8, 4: 8}


class Blobs:
    def __init__(self, root):
        self.root = root
        (root / 'blobs').mkdir(exist_ok=False)
        self.rows = {}

    def put(self, raw):
        digest = sha(raw)
        path = self.root / 'blobs' / (digest + '.bin')
        if digest not in self.rows:
            with path.open('xb') as stream:
                stream.write(raw)
            self.rows[digest] = dict(path=str(path.relative_to(self.root)), bytes=len(raw), sha256=digest,
                                     mode=path.stat().st_mode & 0o7777)
        else:
            require(path.read_bytes() == raw, 'reference-blob-dedup-exact')
        return self.rows[digest]


def tensor(torch, value, blobs):
    logical = bytes(value.detach().contiguous().reshape(-1).view(torch.uint8).tolist())
    physical = bytes(value.untyped_storage())
    return dict(dtype=str(value.dtype), device=str(value.device), element_size=value.element_size(),
        shape=list(value.shape), strides=list(value.stride()), numel=value.numel(),
        storage_bytes=value.untyped_storage().nbytes(), storage_offset_elements=value.storage_offset(),
        storage_offset_bytes=value.storage_offset() * value.element_size(), version=value._version,
        requires_grad=value.requires_grad, is_leaf=value.is_leaf, is_view=value._is_view(),
        grad_fn=None if value.grad_fn is None else type(value.grad_fn).__name__,
        grad_is_none=value.grad is None, retains_grad=value.retains_grad,
        logical=blobs.put(logical), storage=blobs.put(physical),
        tensor_identity=str(value._cdata), storage_identity=str(value.untyped_storage()._cdata),
        base_tensor_identity=None if value._base is None else str(value._base._cdata))


def factory(torch, dtype, shape, raw, requires=False):
    require(len(raw) == math.prod(shape) * WIDTH[dtype], 'reference-raw-factory-shape')
    if raw:
        # Copy bytes without passing through a Python floating-point scalar.
        # The final clone is a fresh, non-view leaf with Version zero.
        value = torch.frombuffer(bytearray(raw), dtype=getattr(torch, DTYPES[dtype])).reshape(shape).clone()
    else:
        value = torch.empty(shape, dtype=getattr(torch, DTYPES[dtype]), device='cpu')
    if requires:
        value.requires_grad_(True)
    require(value._version == 0 and not value._is_view() and value.is_leaf,
            'fresh-real-Torch-factory-contract')
    return value


def words_raw(dtype, words):
    return b''.join(int(x).to_bytes(WIDTH[dtype], 'little') for x in words)


def operation(torch, mode, left, right=None):
    if mode < 4:
        return (torch.add, torch.sub, torch.mul, torch.div)[mode](left, right)
    require(mode in (5, 6), 'sqrt-not-exposed')
    return left.to(dtype=torch.float64 if mode == 5 else torch.float32)


def observe_group(torch, group, original, blobs):
    before_rng = bytes(torch.get_rng_state().tolist())
    row = {k: v for k, v in group.items() if k != 'pairs'}
    row.update(status='OBSERVED', batches=[], reference_packed_sha256=None,
               original_reference_function_exact=True, inputs_unchanged=True)
    import hashlib
    digest = hashlib.sha256()
    for offset, batch in batches(group['pairs']):
        mode = group['mode']
        raw, other = input_bytes(mode, batch)
        left = factory(torch, 0 if mode == 5 else 4, [len(batch)], raw)
        right = factory(torch, 4, [len(batch)], other) if mode < 4 else None
        a = tensor(torch, left, blobs)
        b = tensor(torch, right, blobs) if right is not None else None
        result = operation(torch, mode, left, right)
        observed = tensor(torch, result, blobs)
        expected = original(mode, batch)
        actual = [v & (0xffffffff if mode == 6 else 0xffffffffffffffff)
                  for v in result.view(torch.int32 if mode == 6 else torch.int64).tolist()]
        require(actual == expected, 'real-Tensor-result-equals-complete-original-Torch-function',
                case=group['name'], offset=offset)
        packed = b''.join(struct.pack('<Q', value) for value in expected)
        digest.update(packed)
        require(a == tensor(torch, left, blobs) and
                (right is None or b == tensor(torch, right, blobs)), 'reference-complete-input-unchanged')
        require(bytes(torch.get_rng_state().tolist()) == before_rng, 'reference-group-RNG-unchanged')
        row['batches'].append(dict(offset=offset, count=len(batch), left=a, right=b, result=observed,
            original_reference_words=blobs.put(packed), original_function_witness_matches=True))
        del left, right, result
    row['reference_packed_sha256'] = digest.hexdigest()
    row['rng'] = blobs.put(before_rng)
    require(len(before_rng) == 5056, 'reference-RNG-width')
    return row


def observe_boundary(torch, spec, blobs):
    live, modes, marks = {}, {}, []
    before_rng = bytes(torch.get_rng_state().tolist())
    def mark(label):
        values = {name: tensor(torch, value, blobs) for name, value in live.items()}
        names = list(values)
        relations = {}
        for i, left in enumerate(names):
            for right in names[i + 1:]:
                relations[left + '|' + right] = dict(
                    same_Tensor=values[left]['tensor_identity'] == values[right]['tensor_identity'],
                    same_Storage=values[left]['storage_identity'] == values[right]['storage_identity'])
        require(bytes(torch.get_rng_state().tolist()) == before_rng, 'boundary-reference-RNG-unchanged')
        marks.append(dict(label=label, live_roles=names, tensors=values, comparison_modes=dict(modes),
                          relations=relations))
    for index, event in enumerate(spec['actions']):
        kind = event['kind']
        if kind == 'create':
            live[event['name']] = factory(torch, event['dtype'], event['shape'],
                words_raw(event['dtype'], event['words']), event['requires'])
            modes[event['name']] = 'raw'
        elif kind == 'view':
            live[event['name']] = live[event['source']].as_strided(event['shape'], event['strides'], event['offset'])
            modes[event['name']] = modes[event['source']]
        elif kind == 'cast':
            source = live[event['source']]
            fmt = torch.preserve_format if event['format'] == 0 else torch.contiguous_format
            if event['opcode'] == 109:
                value = torch.ops.aten._to_copy.default(source, dtype=getattr(torch, DTYPES[event['target']]),
                    layout=torch.strided, device=torch.device('cpu'), pin_memory=False,
                    non_blocking=False, memory_format=fmt)
            else:
                value = source.to(dtype=getattr(torch, DTYPES[event['target']]),
                                  copy=event['copy'], memory_format=fmt)
            live[event['name']] = value
            modes[event['name']] = modes[event['source']] if value.dtype == source.dtype else (
                6 if event['target'] == 0 else 5)
            del source, value
        elif kind == 'binary':
            live[event['name']] = operation(torch, event['operation'] - 1,
                live[event['left']], live[event['right']])
            modes[event['name']] = event['operation'] - 1
        elif kind in ('set', 'fill'):
            value = live[event['source']]
            raw = int(event['bits']).to_bytes(value.element_size(), 'little')
            require(value.element_size() in (4, 8), 'raw-mutation-element-width')
            integer_dtype = torch.int32 if value.element_size() == 4 else torch.int64
            integer_view = value.view(integer_dtype)
            source = torch.frombuffer(bytearray(raw), dtype=integer_dtype).reshape(())
            if kind == 'fill':
                target = integer_view
                source = source.expand_as(target)
            else:
                remaining, coordinates = event['index'], []
                require(0 <= remaining < value.numel(), 'raw-reference-index-bound')
                for dimension in reversed(value.shape):
                    coordinates.append(remaining % dimension)
                    remaining //= dimension
                target = integer_view[tuple(reversed(coordinates))]
            version = value._version
            target.copy_(source)
            require(value._version == version + 1, 'one-real-raw-mutation-increments-Version-once')
            for name, alias in live.items():
                if alias is value:
                    modes[name] = 'raw'
            del value, target, source, integer_view, alias
        else:
            raise ValueError(kind)
        mark('%02d-%s' % (index, kind))
    names = list(live)
    for name in reversed(names):
        del live[name]
        modes.pop(name)
        gc.collect()
        mark('drop-' + name)
    require(not live, 'all-boundary-reference-strong-roles-dropped')
    return dict(name=spec['name'], spec=spec, status='OBSERVED', marks=marks,
                rng=blobs.put(before_rng), rng_unchanged=True)


def observe_allocation_recovery(torch, blobs):
    """Actual values for two later native resource-failure recovery commands."""
    rng = bytes(torch.get_rng_state().tolist())
    backing = factory(torch, 0, [1], struct.pack('<I', 0x3f800000))
    value = backing.as_strided([65536], [0], 0)
    converted = value.to(torch.float64)
    added = torch.add(converted, converted)
    require(rng == bytes(torch.get_rng_state().tolist()), 'allocation-reference-RNG-unchanged')
    return dict(status='OBSERVED', element_count=65536,
        source=tensor(torch, value, blobs), cast_result=tensor(torch, converted, blobs),
        binary_result=tensor(torch, added, blobs), rng=blobs.put(rng),
        out_of_memory_is_native_resource_control_not_a_Torch_numerical_claim=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repository', required=True, type=Path)
    p.add_argument('--candidate', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--prepare-only', action='store_true')
    args = p.parse_args()
    require(not sys.flags.optimize, 'assertions-enabled')
    repo = args.repository.resolve(strict=True)
    require(Path.cwd().resolve() == repo, 'reference-cwd-is-pinned-repository')
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    inputs, report, code = Inputs(), {}, 1
    report.update(schema='heptatorch.f64.tensor-reference33.v1', status='PREPARED_NOT_RUN',
        torch_executed=False, native_executed=False, groups=[], boundary_cases=[], failures=[],
        boundary_case_sha256=CASE_SHA256, boundary_contract=BOUNDARY_CONTRACT,
        expected_groups=33, expected_boundary_cases=len(CASES), inputs_unchanged=False,
        original_strict55_modified=False, full_dtype_gate_closed=False, full_project_status='HOLD')
    try:
        report['producer_manifest_sha256'] = bind_package(inputs)
        report['candidate_admission'] = candidate_admission(args.candidate, inputs)
        mapped = parse(inputs.bind(args.candidate / 'original55-mapping.json'))
        plan = groups(inputs, mapped)
        _, report['original_comparison_inverse'] = comparator(inputs)
        report['case_plan'] = [{k: v for k, v in row.items() if k != 'pairs'} for row in plan]
        report['boundary_plan'] = CASES
        inputs.bind(repo / 'tests/pytorch_oracle.py', SUPPORT)
        lock = parse(inputs.bind(repo / 'compatibility/pytorch-oracle-lock.json', LOCK))
        inputs.bind(repo / 'compatibility/upstream-lock.json')
        if not args.prepare_only:
            inputs.bind(repo / lock['oracle']['install_report'])
            saved = sys.argv
            try:
                sys.argv = [str(repo / 'tests/pytorch_oracle.py'), str(out / 'NO_NATIVE_EXECUTION'),
                            str(out / 'oracle-provenance.json'), str(repo / 'compatibility/pytorch-oracle-lock.json')]
                ctx = runpy.run_path(str(repo / 'tests/pytorch_oracle.py'), run_name='f64_tensor_reference_only')
            finally:
                sys.argv = saved
            torch, provenance = ctx['torch'], ctx['PROVENANCE']
            require(provenance['status'] == 'PASS' and set(provenance['checks']) == CHECKS
                    and all(v is True for v in provenance['checks'].values()), 'fixed-11-Torch-provenance-checks')
            report.update(torch_executed=True, oracle_provenance=provenance,
                torch_version=str(torch.__version__), torch_git_version=torch.version.git_version,
                cpu_capability=torch._C._get_cpu_capability(), num_threads=torch.get_num_threads())
            torch.manual_seed(1729)
            initial_rng = bytes(torch.get_rng_state().tolist())
            require(len(initial_rng) == 5056, 'reference-complete-RNG-width')
            blobs = Blobs(out)
            original = original_reference(torch, inputs)
            for number, group in enumerate(plan):
                try:
                    row = observe_group(torch, group, original, blobs)
                except BaseException as error:
                    row = dict(name=group['name'], original_index=group['original_index'], status='FAIL',
                        error=dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
                    report['failures'].append(row)
                dump(out / ('numeric-%02d.json' % number), row)
                report['groups'].append(row)
            for number, spec in enumerate(CASES):
                try:
                    row = observe_boundary(torch, spec, blobs)
                except BaseException as error:
                    row = dict(name=spec['name'], status='FAIL', error=dict(type=type(error).__name__,
                        message=str(error), traceback=traceback.format_exc()))
                    report['failures'].append(row)
                dump(out / ('boundary-%02d.json' % number), row)
                report['boundary_cases'].append(row)
            report['allocation_recovery'] = observe_allocation_recovery(torch, blobs)
            require(initial_rng == bytes(torch.get_rng_state().tolist()), 'whole-reference-RNG-unchanged')
            report['rng'] = blobs.put(initial_rng)
            report['blob_manifest'] = blobs.rows
            report['status'] = 'OBSERVED' if not report['failures'] else 'FAIL'
        code = 0 if report['status'] in ('OBSERVED', 'PREPARED_NOT_RUN') else 1
    except BaseException as error:
        report['status'] = 'FAIL'
        report['failures'].append(dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
    finally:
        try:
            report['inputs_unchanged'] = inputs.unchanged()
        except BaseException as error:
            report['status'], code = 'FAIL', 1
            report['failures'].append(dict(stage='final-input-recheck', error=repr(error)))
        report['inputs'] = inputs.rows
        dump(out / 'report.json', report)
    print(__import__('json').dumps({k: report[k] for k in ('status', 'expected_groups', 'expected_boundary_cases',
                                                       'torch_executed', 'native_executed')}))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
