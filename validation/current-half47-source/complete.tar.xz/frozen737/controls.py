"""Real Tensor refusals and four independently constrained half allocations.

These are explicit current-protocol boundaries, not claims that PyTorch lacks
these features. Original standalone F16/BF16 protocol refusals stay separate.
"""
import resource
import struct
from pathlib import Path

from common import dump, require, sha
from native import WIRE


def reject(driver, label, body, expected, *, mappings=False):
    maps = Path('/proc/%d/maps' % driver.n.s.pid)
    before = maps.read_bytes() if mappings else None
    status, records = driver.n.exchange(body, label)
    driver.operations.append(dict(label=label, request_sha256=sha(body), actual_status=status,
                                  expected_status=expected, record_count=len(records)))
    driver.check(label + '/actual-frame-status', status, expected)
    driver.check(label + '/no-published-result', records, [])
    if mappings:
        after = maps.read_bytes()
        (driver.directory / (label + '.maps-before')).write_bytes(before)
        (driver.directory / (label + '.maps-after')).write_bytes(after)
        driver.check(label + '/all-mappings-unchanged', after, before)
    return status


def entry_controls(driver):
    specs = [('F32',0,struct.pack('<2I',0x3f800000,0x80000000)),
             ('Bool',1,b'\1\0'),('I64',2,struct.pack('<2Q',1,0)),
             ('F64',4,struct.pack('<2Q',0x3ff0000000000000,0x8000000000000000)),
             ('F16',5,struct.pack('<2H',0x3c00,0x8000)),
             ('BF16',6,struct.pack('<2H',0x3f80,0x8000))]
    tokens = {}
    for name,dtype,raw in specs:
        tokens[dtype] = driver.n.create(dtype,[2],raw)
        driver.live[name] = tokens[dtype]
    grad = driver.n.create(0,[2],struct.pack('<2I',0x3f800000,0x40000000),True)
    driver.live['F32_requires_grad'] = grad
    graph = driver.n.one(114,grad,0x3ff0000000000000)['value']
    driver.live['original_scalar_graph'] = graph
    wrapped = driver.n.one(107,graph,1)['value']
    tokens[3] = wrapped; driver.live['original_private_scalar3'] = wrapped
    info = struct.unpack('<4Q',driver.n.one(96,wrapped,0)['payload'])
    driver.check('real-Saved-private-scalar3-dtype-width',list(info[:2]),[3,8])
    meta = WIRE.meta(driver.n.one(13,wrapped))
    driver.check('real-private-scalar3-rank-numel',[meta['rank'],meta['numel']],[0,1])
    original = {name:driver.n.tensor(token) for name,token in driver.live.items()}
    def refusal(label,command,cause=7):
        return reject(driver,label,WIRE.packet([command]),cause)
    for dtype in (3,7,255,(1<<64)-1):
        reject(driver,'public-factory-unsupported-dtype-'+str(dtype),
               driver.n.factory_packet(dtype,[2],struct.pack('<2Q',1,2)),7)
    allowed = {(0,5),(5,0),(0,6),(6,0),(5,5),(6,6)}
    pair_count = 0
    for opcode in (108,109):
        for source in range(7):
            for target in range(7):
                if (source in (5,6) or target in (5,6)) and (source,target) not in allowed:
                    refusal('unsupported-pair-%d-%d-to-%d'%(opcode,source,target),
                            (opcode,tokens[source],target,0,0))
                    pair_count += 1
        for dtype in (5,6):
            refusal('requires-grad-F32-to-half-%d-%d'%(opcode,dtype),
                    (opcode,grad,dtype,0,0),5)
    for dtype in (5,6):
        token = tokens[dtype]
        reject(driver,'half-factory-requires-grad-'+str(dtype),
               driver.n.factory_packet(dtype,[2],struct.pack('<2H',1,2),True),5)
        for bits in (65536,1<<32,1<<63,(1<<64)-1):
            refusal('high-bits-set-%d-%d'%(dtype,bits),(12,token,0,bits))
            refusal('high-bits-fill-%d-%d'%(dtype,bits),(100,token,bits,0))
        for other_dtype,other in tokens.items():
            for operation in (1,2,3,4):
                refusal('half-binary-left-%d-%d-%d'%(dtype,other_dtype,operation),
                        (2,operation,token,other))
                if other != token:
                    refusal('half-binary-right-%d-%d-%d'%(dtype,other_dtype,operation),
                            (2,operation,other,token))
        for label,command in (
            ('sqrt',(3,11,token)),('neg',(3,6,token)),
            ('reshape',(17,token,1,2,0,0,0)),('backward',(29,token,0)),
            ('Saved',(46,token)),('transpose',(6,token,0,0)),
            ('clone',(18,token)),('detach',(19,token)),('data-alias',(55,token)),
            ('typed99',(99,token,0)),('requires-grad101',(101,token,1)),('typed102',(102,token,0)),
            ('copy-invalid-format',(109,token,0,2)),('to-invalid-copy',(108,token,dtype,2,0)),
            ('to-reserved-word',(108,token,dtype,0,0,1)),
            ('sum',(115,token,0,0,0,(1<<64)-1,0,0)),
            ('permute',(116,token,1,WIRE.Payload(struct.pack('<q',0)),0,0,0,0)),
            ('wrapped-scalar-arithmetic',(114,token,0x3ff0000000000000)),
            ('shape112',(112,token,WIRE.Payload(struct.pack('<5Q',1,2,0,0,0)),40)),
            ('shape113',(113,token,WIRE.Payload(struct.pack('<5Q',1,2,0,0,0)),40))):
            refusal('unsupported-half%d-%s'%(dtype,label),command)
        cfg = struct.pack('<10Q',1,2,0,0,0,1,0,0,0,0)
        for opcode in (69,111):
            refusal('half-view-%d-%d'%(dtype,opcode),(opcode,token,WIRE.Payload(cfg),80))
        # Raw110 has its own pre-existing target<=2 guard, before parsing its
        # raw descriptor. The new97 factory must not widen that separate ABI.
        refusal('old-raw110-target-remains-rejected-'+str(dtype),(110,dtype,0,0,0,0,0,0))
        refusal('half-set-at-numel-'+str(dtype),(12,token,2,0))
        refusal('half-read-after-end-'+str(dtype),(98,token,3,1),2)
        refusal('half-read-overflow-'+str(dtype),(98,token,(1<<64)-1,1),2)
        refusal('invalid-public-half-capability-'+str(dtype),(108,1,dtype,0,0),1)
        stale = driver.n.create(dtype,[1],struct.pack('<H',1))
        driver.n.one(41,stale)
        refusal('stale-public-half-capability-'+str(dtype),(108,stale,dtype,0,0),1)
        valid = driver.n.factory_packet(dtype,[2],struct.pack('<2H',1,2))
        short = bytearray(valid[:-1]); struct.pack_into('<Q',short,16,len(short))
        reject(driver,'truncated-two-byte-payload-'+str(dtype),bytes(short),100)
        bad = bytearray(valid); struct.pack_into('<Q',bad,96+6*8,32)
        reject(driver,'raw-payload-overlaps-command-'+str(dtype),bytes(bad),100)
        # Actually allocate a half Tensor inside one transaction, resolve the
        # FE alias, then fail. Native.exchange requires complete byte rollback.
        raw = struct.pack('<2H',1,2)
        config = struct.pack('<8Q',1,0,2,0,0,0,224,len(raw))
        first = struct.pack('<8Q',97,dtype,160,0,0,0,0,0)
        second = struct.pack('<8Q',2,1,WIRE.reference(1),tokens[0],0,0,0,0)
        body = b'HTORCH03'+struct.pack('<3Q',2,224+len(raw),0)+first+second+config+raw
        reject(driver,'same-frame-half-FE-binary-'+str(dtype),body,7)
        # The as_strided descriptor begins on an eight-byte boundary.
        padding = bytes((-len(raw)) % 8)
        cfg_at = 224+len(raw)+len(padding)
        second = struct.pack('<8Q',111,WIRE.reference(1),cfg_at,80,0,0,0,0)
        body = b'HTORCH03'+struct.pack('<3Q',2,cfg_at+len(cfg),0)+first+second+config+raw+padding+cfg
        reject(driver,'same-frame-half-FE-view-'+str(dtype),body,7)
    for label,command in (
        ('private3-set',(12,wrapped,0,0)),('private3-fill',(100,wrapped,0,0)),
        ('private3-to-half5',(108,wrapped,5,1,0)),('private3-to-half6',(109,wrapped,6,0))):
        refusal(label,command)
    valid = driver.n.factory_packet(5,[2],struct.pack('<2H',1,2))
    for label,body in (('empty',b''),('short-header',bytes(31)),('wrong-magic',b'X'+valid[1:]),
                       ('stale-length-extra',valid+b'x'),('stale-length-short',valid[:-1])):
        reject(driver,'Tensor-envelope-'+label,body,100)
    for name,token in driver.live.items():
        after = driver.n.tensor(token)
        for key in ('logical','storage','shape','strides','version','tensor_identity',
                    'storage_identity','native_version_identity'):
            driver.check('entry-input-unchanged/'+name+'/'+key,after[key],original[name][key])
    driver.rng_unchanged('all-half-entry-refusals')
    return dict(actual_refusals=len(driver.operations), unsupported_cast_pair_checks=pair_count,
        all_original_inputs_and_RNG_unchanged=True, every_error_complete_owner_rollback=True,
        same_packet_FE_alias_controls=4, raw_highbits_never_silently_truncated=True,
        private_dtype3_remains_private=True, original_standalone12_refusals_transferred=False,
        unsupported_PyTorch_features_not_claimed_as_upstream_errors=True)


def resources(driver,label,requested,*,pool=None):
    state,endpoint,raw = driver.n.capture(label)
    next_node = state['header']['next']; page = next_node >> 8
    actual_pages = [row['page'] for row in state['pages']]
    available = {str(kind):sum(row[1] == 0 and row[0] < 0xffffffff
                              for row in state['tables'][str(kind)]) for kind in (1,2,3,6)}
    total = sum(size for _,size in state['free_extents'])
    largest = max((size for _,size in state['free_extents']),default=0)
    require(page in actual_pages and next_node < 65536 and state['header']['incarnation'] < (1<<64)-1,
            'half-result-descriptor-page-and-incarnation-preexist')
    require(min(available.values()) >= 4, 'half-output-T-S-V-Hold-slots-preexist')
    require(16384 <= total <= 32768 and largest < requested, 'actual-free-extents-too-small-for-result',
            requested=requested,total_free=total,largest_free=largest)
    if pool is not None:
        driver.check(label+'/unchanged-pool-capacity',state['header']['pool'],pool)
    detail = dict(owner=endpoint,pool=state['header']['pool'],total_free=total,largest_free=largest,
        requested_Storage_bytes=requested,required_descriptor_page=page,actual_pages=actual_pages,
        available_T_S_V_Hold_slots=available,next_node=next_node,free_extents=state['free_extents'])
    dump(driver.directory/(label+'.json'),detail)
    return state,detail


def allocation_control(driver,spec,recovery):
    dtype,count = spec['dtype'],spec['count']
    require(dtype in (5,6) and count == 65536 and spec['direction'] in ('narrow','widen'),
            'four-explicit-half-allocation-recipes')
    if spec['direction'] == 'narrow':
        driver.live['backing'] = driver.n.create(0,[1],struct.pack('<I',0x3f800000))
        driver.live['input'] = driver.n.view(driver.live['backing'],[count],[0],0)
        target,requested = dtype,2*count
    else:
        one = 0x3c00 if dtype == 5 else 0x3f80
        driver.live['input'] = driver.n.create(dtype,[count],struct.pack('<H',one)*count)
        target,requested = 0,4*count
    driver.observe(driver.live['input'],recovery['source'],label='allocation-input')
    saved = {name:driver.n.tensor(token) for name,token in driver.live.items()}
    initial,_,_ = driver.n.capture('before-real-pressure-fillers'); pool = initial['header']['pool']
    fillers = []
    for index in range(64):
        state,_,_ = driver.n.capture('filler-inspection')
        total = sum(size for _,size in state['free_extents'])
        if 16384 <= total <= 32768: break
        require(total > 32768,'positive-real-pool-free-space-before-pressure',total=total)
        amount = min(262144,(total-32768)&~15)
        require(amount > 0,'positive-aligned-real-Bool-filler')
        token = driver.n.create(1,[amount],bytes(amount))
        driver.live['filler-%02d'%index] = token; fillers.append(token)
        state,_,_ = driver.n.capture('after-real-filler')
        driver.check('real-filler-does-not-grow-pool',state['header']['pool'],pool)
    else: raise AssertionError('bounded real filler setup did not converge')
    state,ready = resources(driver,'allocation-ready',requested,pool=pool)
    command = (108,driver.live['input'],target,1,0); body = WIRE.packet([command])
    pid = driver.n.s.pid; old = resource.prlimit(pid,resource.RLIMIT_AS)
    raw_status = Path('/proc/%d/status'%pid).read_bytes()
    (driver.directory/'before-limit.status').write_bytes(raw_status)
    (driver.directory/'before-limit.limits').write_bytes(Path('/proc/%d/limits'%pid).read_bytes())
    vm = int(next(row.split()[1] for row in raw_status.decode().splitlines() if row.startswith('VmSize:')))*1024
    page = lambda value:(value+4095)&~4095
    soft = vm+page(state['length']+16)+page(5056+16)+65536
    require(old[1] == resource.RLIM_INFINITY or soft < old[1], 'new-limit-below-existing-hard-limit')
    dump(driver.directory/'allocation-limit.json',dict(spec=spec,ready=ready,old_limit=list(old),
        current_vm_bytes=vm,applied_soft_limit=soft,request_sha256=sha(body),
        ordinary_same_capacity_transaction_allowance=page(state['length']+16),
        complete_RNG_query_allowance=page(5056+16),wire_and_small_mapping_allowance=65536,
        native_fillers=len(fillers),failure_stage='new-result-Storage-cannot-fit-existing-pool'))
    resource.prlimit(pid,resource.RLIMIT_AS,(soft,old[1]))
    try:
        driver.n.one(96,driver.live['input'],0)
        driver.rng_unchanged('ordinary-query-under-same-limit')
        resources(driver,'same-limit-allocation-ready',requested,pool=pool)
        reject(driver,'actual-half-Storage-OOM',body,3,mappings=True)
        driver.rng_unchanged('after-actual-half-OOM')
    finally:
        resource.prlimit(pid,resource.RLIMIT_AS,old)
        driver.check('original-RLIMIT-restored',list(resource.prlimit(pid,resource.RLIMIT_AS)),list(old))
    for name,before in saved.items():
        after = driver.n.tensor(driver.live[name])
        for key in ('logical','storage','shape','strides','version','tensor_identity',
                    'storage_identity','native_version_identity'):
            driver.check('OOM-original-input-unchanged/'+name+'/'+key,after[key],before[key])
    status,records = driver.n.exchange(body,'same-command-after-resource-recovery')
    driver.operations.append(dict(label='same-command-after-resource-recovery',request_sha256=sha(body),
                                  actual_status=status,expected_status=0,record_count=len(records)))
    driver.check('same-request-recovery-status',status,0)
    driver.check('same-request-recovery-result-count',len(records),1)
    driver.live['recovered'] = records[0]['value']
    # Both inputs contain exactly representable one; raw comparison here is
    # to the real pinned Torch result, not a host-generated expected output.
    driver.observe(driver.live['recovered'],recovery['result'],label='real-recovered-Torch-result')
    after,_,_ = driver.n.capture('after-real-recovery')
    driver.check('real-pool-growth-after-limit-restored',after['header']['pool'] > pool,True)
    driver.rng_unchanged('after-real-half-recovery')
    return dict(spec=spec,actual_status_sequence=[3,0],
        identical_failure_and_recovery_request_sha256=sha(body),requested_Storage_bytes=requested,
        descriptor_and_table_allocation_ready=True,full_owner_rollback=True,all_mappings_restored=True,
        reference_result_observed_by_fixed_Torch=True,input_and_RNG_unchanged=True)
