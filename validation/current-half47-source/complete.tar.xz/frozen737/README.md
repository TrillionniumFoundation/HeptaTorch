# First ordinary F16/BF16 Tensor qualification on 737

This source package prepares a new, real qualification. It contains no native
application image and no observed Torch outputs. Compilation alone, a source
check, a prepare report, and the older standalone dtype reports confer no
numerical PASS on this image.

## Fixed source and actual cold build

| Item | SHA-256 |
| --- | --- |
| Complete 737 HIA source | `b2430af6ab7070efda67a1f7e9e2a8a83e273d57e44728b5492f0ee9d03e8fc3` |
| Actual first 737 ELF, 3,792,896 bytes | `777f8ba35482fc1545f54b69f5a2690e7dfaf56994b10bf1b79b98e2e2a8aecc` |
| Actual first cold report, 24,738 bytes | `8348eb9aee5c15940a7e3712f783f74ce3d195ee9e14e9b4985f276f9e93b3b4` |
| Complete candidate source package manifest | `2d5197c66b5820d6671ddd8263b6c0d272a66a52eaecbd9206cd2f79c5fd661d` |
| Fifteen-unit partition manifest | `970bac0845bc4b3177946e54a27782816d162bf6c2298bd68c418f0463a2eae2` |
| Complete owner observer | `fb74a9a525d149678b1b0ee92913bdcdabdd4459f4cd039905e822e6a87e5830` |

The builder must have really compiled all 15 objects and linked them once using
the fixed compiler and `HIACGS01` four-argument entropy linker. The admission
reads all 16 original process streams, source/object/image bytes, both EOFs,
exit codes, stack observations, and input identities. The actual complete
census is 737 functions, 9,779 blocks, 35,314 instructions, and 748 exports.
Required stack is 137,840 bytes, including the 4,096-byte startup allowance.
The first actual cold report is the recommended explicit input; a later real
cold report is admissible only with the identical source/image/partition and
all the same cold-build predicates, never with substituted old object files.

## Scope and denominators

There are **47 independent native children**, each required to pass, finish
normally, and produce complete stdout/stderr EOF:

| Group | Children | Contract |
| --- | ---: | --- |
| Original F16 numerical groups | 9 | All 821,554 original input words |
| Original BF16 numerical groups | 17 | All 86,662 original input words |
| New Tensor boundary recipes | 16 | Eight recipes for each public dtype |
| New refusal matrix | 1 | Public dtype, private scalar, high bits, unsupported operations, transaction rollback |
| Real allocation pressure and recovery | 4 | F32 to each half dtype and each half dtype to F32 |

The total original numerical denominator is **26 groups / 908,216 words**.
`corpus.py` reconstructs the complete original input sequences and executes
the complete original comparison loops byte for byte. Finite outputs remain
bit exact. F16 retains its original NaN-class and quiet-bit rule. BF16 retains
its original NaN-class rule without adding a quiet-bit requirement. These
predicates are not replaced with host conversion or a new tolerance.

The **12 old standalone-protocol refusals** (seven F16 and five BF16) are
retained in the immutable candidate package and are not transferred to the
new Tensor protocol or added to the 47-child denominator. No original report
or original expected value is edited. F64, Generator, logical reductions,
autograd, and the older 513 suites have separate qualifications; this package
does not assert them all to be closed.

## Real reference, then native comparison

The reference producer runs the pinned official CPU Torch wheel
`2.15.0+cpu`, git build `d0f2af8b66b20da4baa50644c0cd3f887a2eae2e`, with one
thread. It executes all eleven original provenance checks. The actual Tensor
casts for the original26 are also compared against the original real-Torch
reference expressions. Python never generates numerical expected outputs.

The producer records actual metadata, full logical and Storage bytes,
Tensor/Storage/base identity relations, versions, complete 5,056-byte RNG
state, and standalone case JSONs plus content-addressed byte blobs. It returns
`OBSERVED` only when every group and boundary/reference recipe completed.
`OBSERVED` is not a native PASS. The producer source namespace remains **737**
even if a future separately reviewed adapter qualifies a different image.

The reader binds this exact producer package manifest, source identity, full
reference report SHA, every blob's bytes/mode/hash, all original inputs, and
all case recipes. It compares real opcode97 creation, opcode98 byte reads,
opcode12 writes, opcode100 fills, and opcode108/109 conversions. Every raw
read is independently reconstructed from the actual child's physical
Storage, stride, offset, dtype, and descriptor fields. Numerical logical
enumeration is proved to cover every physical word in each owned dense
result. Same-dtype copies compare all 65,536 payload patterns directly and
also compare the native source/result bytes, preserving NaN payloads exactly.

The 16 boundary cases cover scalar, empty rank3, rank4, signed zero, NaNs,
raw mutation and shared Version, fresh allocation and same-Tensor alias,
dense permutations, offset striding, and zero-stride overlap of F32 sources.
Half views and half AD remain explicitly unsupported.

The refusal matrix uses real private dtype3 obtained from the original
wrapped-scalar Saved path, never a fabricated ordinary dtype3 factory.
High raw bits must reject before any write or Version change. Unsupported
mixed pairs are checked in both operand orders. Same-frame FE aliases create
real half objects before an unsupported second command, requiring complete
transaction rollback. Error codes describe this HIA protocol's explicit
boundaries; they are not claims that the corresponding PyTorch operations
are invalid.

Each OOM case allocates real fillers, records actual free extents and table
slots, and requires the result descriptor page and publication resources to
preexist. Under the same actual `RLIMIT_AS`, ordinary dtype and complete RNG
queries must first succeed. The cast must then fail with cause3, identical
full owner bytes/pointer, identical mappings and unchanged inputs/RNG. The
original limit is restored in `finally`; the identical request must then
succeed and match the real Torch reference. Both narrowing result widths
(131,072 bytes) and widening widths (262,144 bytes) are separately checked.

## Custody and unchanged code

`native.py` differs from the complete retained 719 transport by four explicit
literal edits: two dtype lookup tables, owner path and function count. Its
entire `Native` and `CapturingSession` classes are byte identical. All 84
descriptor words remain observed. The explicit owner extension to5/6 is
wholly reversible to the previous730 observer and retains private3 and F64
checks. It does not claim a complete recomputation of all private allocation
transitions.

The reference Blob/tensor/factory definitions, Driver lifecycle/check/drop
functions, complete child finalizer, and refusal transport are retained
whole from the original719 qualification. `check_sources.py` proves those
whole definitions and all local imports, including the lazy `controls`
import. Frozen original oracle scripts are read as source; their native
build/run mains are never executed. Only the exact original real-Torch
expression definitions are selected for reference execution.

Partial writes, partial responses, unexpected stderr, owner decoding errors,
input mutation, child timeout, forced cleanup, missing EOF or nonzero exit
remain FAIL with raw evidence. Later groups still run after a case failure.
Every output directory is new and outside source/reference/build trees.
There is no replay-PASS or overwrite option.

## Commands for the root executor

The variable names below denote existing independently verified paths.
`HALF737_QUAL` is this package; `HALF737_CANDIDATE` is the complete source
package with `candidate/`, `source/`, `frozen/` and `observation-01/`.
`HALF737_BUILD` is the real cold directory, and `HALF737_TORCH_PYTHON` is the
pinned Torch interpreter. Outputs must be fresh sibling directories.

Pure source verification (no native or Torch execution):

```sh
"$HALF737_TORCH_PYTHON" -I -S -B "$HALF737_QUAL/check_sources.py" \
  --candidate "$HALF737_CANDIDATE" --output "$HALF737_PURE_OUTPUT"
```

Reference prepare, followed by one actual producer run from the fixed
repository working directory, each with a distinct new output:

```sh
"$HALF737_TORCH_PYTHON" -I -B "$HALF737_QUAL/reference.py" \
  --repository "$HALF737_REPOSITORY" --candidate "$HALF737_CANDIDATE" \
  --output "$HALF737_REFERENCE_PREPARE" --prepare-only
"$HALF737_TORCH_PYTHON" -I -B "$HALF737_QUAL/reference.py" \
  --repository "$HALF737_REPOSITORY" --candidate "$HALF737_CANDIDATE" \
  --output "$HALF737_REFERENCE_ACTUAL"
```

After independently reading the real reference's complete report and SHA,
native prepare and actual use the same arguments except their separate new
outputs and `--prepare-only`:

```sh
"$HALF737_TORCH_PYTHON" -I -S -B "$HALF737_QUAL/run.py" \
  --candidate "$HALF737_CANDIDATE" --build-directory "$HALF737_BUILD" \
  --reference "$HALF737_REFERENCE_ACTUAL/report.json" \
  --expected-reference-sha256 "$HALF737_ACTUAL_REFERENCE_SHA256" \
  --expected-source-sha256 b2430af6ab7070efda67a1f7e9e2a8a83e273d57e44728b5492f0ee9d03e8fc3 \
  --expected-native-sha256 777f8ba35482fc1545f54b69f5a2690e7dfaf56994b10bf1b79b98e2e2a8aecc \
  --expected-build-sha256 8348eb9aee5c15940a7e3712f783f74ce3d195ee9e14e9b4985f276f9e93b3b4 \
  --output "$HALF737_NATIVE_PREPARE" --prepare-only
```

Run the actual command once with `--output "$HALF737_NATIVE_ACTUAL"` and
without `--prepare-only`. Preparation has status `PREPARED_NOT_RUN` and
`native_executed=false`. Only the real complete 47-child result can return
native status `PASS`. Keep the entire reference and actual output trees,
the exact source packages, cold directory and process terminal receipts.

Full project and dtype closure remain **HOLD** outside this stated scope.
