"""Actual selected-image transport and complete own-child owner observation.

No arithmetic evaluator. Every byte compared is read from the selected native
process, its public wire output, or a separately bound real Torch observation.
"""
import gzip
import json
import math
import os
import select
import signal
import struct
import time
import traceback
from pathlib import Path

from common import HERE, OWNER, SOURCE, Inputs, dump, load, require, sha

WIRE = load(HERE / 'frozen/protocol.py', 'f64_tensor_original_wire')
BASE, TAG = 139264, 1 << 63
WIDTH = {0: 4, 1: 1, 2: 8, 3: 8, 4: 8, 5: 2, 6: 2}
DTYPE = {0: 'torch.float32', 1: 'torch.bool', 2: 'torch.int64', 3: 'torch.float64', 4: 'torch.float64', 5: 'torch.float16', 6: 'torch.bfloat16'}


class CapturingSession(WIRE.Session):
    """Keep exact completed writes and reads, including partial failures.

    Fork/exec, wrapper protocol constants, /proc owner and all ordinary wire
    encoders/decoders remain in the complete frozen transport. These overrides
    add immediate recording and an explicit two-stream EOF finalizer.
    """
    def __init__(self, binary, directory, image_sha):
        self.output_root = directory
        self.stderr_chunks = []
        self.stderr_eof = False
        self._finished = False
        self.finish_receipt = None
        rawdir = directory / 'raw'
        rawdir.mkdir(exist_ok=False)
        # Open evidence sinks before forking. A failed sink open must not
        # leave an otherwise unreachable application child waiting on stdin.
        self.requests = (rawdir / 'requests.frames.bin').open('xb')
        self.responses = (rawdir / 'responses.frames.bin').open('xb')
        self.stderr_capture = (rawdir / 'stderr.bin').open('xb')
        self.intent = (rawdir / 'request-intents.jsonl').open('x')
        try:
            super().__init__(binary, directory=None)
            self.directory = rawdir
            require(self.binary_sha256 == image_sha, 'selected-native-bytes-before-exec')
            self.owner(read_bytes=False)  # Wait for this actual child's frame-read boundary.
            actual = Path('/proc/%d/exe' % self.pid).read_bytes()
            require(sha(actual) == image_sha, 'actual-proc-exe-matches-selected-image')
            self.actual_image_sha256 = sha(actual)
            self.start_ticks = int(Path('/proc/%d/stat' % self.pid).read_text().rsplit(')', 1)[1].split()[19])
        except BaseException:
            if hasattr(self, 'pid') and self.pid > 0:
                try:
                    self.finish()
                except BaseException:
                    pass
            else:
                for stream in (self.requests, self.responses, self.stderr_capture, self.intent):
                    stream.close()
            raise

    def send(self, raw):
        require(self.input is not None, 'stdin-open-before-request')
        self.intent.write(json.dumps(dict(frame=self.frames + 1, intended_bytes=len(raw),
                                         intended_sha256=sha(raw))) + '\n')
        self.intent.flush()
        at = 0
        while at < len(raw):
            _, ready, _ = select.select([], [self.input], [], 30)
            require(bool(ready) and self.poll() is None, 'actual-request-write-deadline', written=at)
            count = os.write(self.input, raw[at:])
            require(count > 0, 'actual-positive-write')
            self.requests.write(raw[at:at + count])
            self.requests.flush()
            at += count

    def _stderr(self):
        raw = os.read(self.stderr, 65536)
        if raw:
            self.stderr_chunks.append(raw)
            self.stderr_capture.write(raw)
            self.stderr_capture.flush()
        else:
            self.stderr_eof = True

    def read_exact(self, fd, count, timeout=120):
        chunks = bytearray()
        deadline = time.monotonic() + timeout
        while len(chunks) < count:
            watched = [fd] + ([] if self.stderr_eof or fd == self.stderr else [self.stderr])
            ready, _, _ = select.select(watched, [], [], max(0, deadline - time.monotonic()))
            require(bool(ready), 'actual-response-read-deadline', expected=count, received=len(chunks))
            if self.stderr in ready and fd != self.stderr:
                self._stderr()
            if fd not in ready:
                continue
            raw = os.read(fd, count - len(chunks))
            require(bool(raw), 'actual-response-early-EOF', expected=count, received=len(chunks))
            chunks.extend(raw)
            if fd == self.output:
                self.responses.write(raw)
                self.responses.flush()
        return bytes(chunks)

    def receive(self):
        head = self.read_exact(self.output, 16)
        magic, size = struct.unpack('<8sQ', head)
        require(magic == b'HTOWNS01' and 32 <= size <= 1 << 20, 'actual-response-frame-header')
        body = self.read_exact(self.output, size)
        require(self.input is not None and self.poll() is None, 'response-before-stdin-EOF')
        self.frames += 1
        self.rows.append(dict(frame=self.frames, pid=self.pid, response_bytes=size, stdin_open=True))
        return body

    def finish(self):
        if self._finished:
            require(self.finish_receipt is not None and self.finish_receipt['status'] == 'PASS',
                    'previous-transport-finalization-failed')
            return self.finish_receipt
        self._finished = True
        extra, errors, output_eof, forced = bytearray(), [], False, False
        self.close_input()
        deadline = time.monotonic() + 15
        try:
            while not (output_eof and self.stderr_eof and self.poll() is not None):
                require(time.monotonic() < deadline, 'actual-child-final-EOF-deadline')
                fds = ([] if output_eof else [self.output]) + ([] if self.stderr_eof else [self.stderr])
                ready, _, _ = select.select(fds, [], [], .05)
                for fd in ready:
                    if fd == self.stderr:
                        self._stderr()
                    else:
                        raw = os.read(fd, 65536)
                        if raw:
                            extra.extend(raw)
                        else:
                            output_eof = True
                self.poll()
        except BaseException as error:
            errors.append(dict(stage='normal-finalization', error=repr(error)))
            if self.poll() is None:
                # This PID is our still-unreaped direct child. It cannot be
                # recycled until waitpid below; no process group is signaled.
                forced = True
                try:
                    os.kill(self.pid, signal.SIGKILL)
                    pid, status = os.waitpid(self.pid, 0)
                    require(pid == self.pid, 'reaped-own-child')
                    self.exit_code = os.waitstatus_to_exitcode(status)
                except BaseException as cleanup:
                    errors.append(dict(stage='own-child-kill-reap', error=repr(cleanup)))
            for fd, label in ((self.output, 'stdout'), (self.stderr, 'stderr')):
                try:
                    os.set_blocking(fd, False)
                    while True:
                        raw = os.read(fd, 65536)
                        if not raw:
                            if label == 'stdout':
                                output_eof = True
                            else:
                                self.stderr_eof = True
                            break
                        if label == 'stdout':
                            extra.extend(raw)
                        else:
                            self.stderr_chunks.append(raw)
                            self.stderr_capture.write(raw)
                except BaseException as cleanup:
                    errors.append(dict(stage='drain-' + label, error=repr(cleanup)))
        finally:
            for stream in (self.requests, self.responses, self.stderr_capture, self.intent):
                stream.flush()
                stream.close()
            for field in ('input', 'output', 'stderr'):
                fd = getattr(self, field)
                if fd is not None:
                    os.close(fd)
                    setattr(self, field, None)
            (self.output_root / 'raw/extra-stdout-after-frames.bin').write_bytes(extra)
        error_bytes = b''.join(self.stderr_chunks)
        receipt = dict(schema='heptatorch.f64.tensor-actual-transport.v1', pid=self.pid,
            start_ticks=getattr(self, 'start_ticks', None), frames=self.frames, exit_code=self.exit_code,
            actual_proc_exe_sha256=getattr(self, 'actual_image_sha256', None),
            selected_native_sha256=self.binary_sha256, stdout_EOF=output_eof, stderr_EOF=self.stderr_eof,
            stderr_bytes=len(error_bytes), stderr_sha256=sha(error_bytes),
            extra_stdout_bytes=len(extra), extra_stdout_sha256=sha(extra), forced_cleanup=forced,
            errors=errors, request_stream_sha256=sha((self.output_root / 'raw/requests.frames.bin').read_bytes()),
            response_stream_sha256=sha((self.output_root / 'raw/responses.frames.bin').read_bytes()),
            status='PASS' if self.exit_code == 0 and output_eof and self.stderr_eof and
                   not error_bytes and not extra and not forced and not errors else 'FAIL')
        try:
            receipt['selected_image_unchanged'] = sha(self.executable.read_bytes()) == self.binary_sha256
        except OSError as error:
            receipt['selected_image_unchanged'] = False
            receipt['errors'].append(dict(stage='final-image-recheck', error=repr(error)))
        if not receipt['selected_image_unchanged']:
            receipt['status'] = 'FAIL'
        self.finish_receipt = receipt
        dump(self.output_root / 'raw/transport.json', receipt)
        require(receipt['status'] == 'PASS', 'native-exit-and-both-actual-EOF', receipt=receipt)
        return receipt


class Native:
    def __init__(self, binary, source, owner_module, directory, image_sha):
        self.owner = owner_module
        self.owner.pin_profile(binary, source)
        self.directory = directory
        directory.mkdir(exist_ok=False)
        (directory / 'complete-owner').mkdir()
        self.blobs, self.boundaries = {}, []
        self.journal = (directory / 'owner-frames.jsonl').open('x')
        try:
            self.s = CapturingSession(binary, directory, image_sha)
        except BaseException:
            self.journal.close()
            raise

    def capture(self, label):
        actual = self.s.owner()
        raw, digest = actual['bytes'], sha(actual['bytes'])
        if digest not in self.blobs:
            packed = gzip.compress(raw, compresslevel=1, mtime=0)
            require(gzip.decompress(packed) == raw, 'complete-owner-compression-readback')
            relative = 'complete-owner/' + digest + '.bin.gz'
            with (self.directory / relative).open('xb') as stream:
                stream.write(packed)
            self.blobs[digest] = dict(path=relative, sha256=digest, bytes=len(raw),
                compressed_sha256=sha(packed), compressed_bytes=len(packed),
                mode=(self.directory / relative).stat().st_mode & 0o7777)
        reference = dict(label=label, pointer=actual['pointer'], length=actual['length'], sha256=digest)
        try:
            decoded = self.owner.decode_owner(raw, actual['pointer'])
            reference['checks'] = self.owner.verify_snapshot(decoded)
        except BaseException as error:
            with (self.directory / 'owner-failures.jsonl').open('a') as stream:
                stream.write(json.dumps(dict(owner=reference, error=repr(error), traceback=traceback.format_exc())) + '\n')
            raise
        return decoded, reference, raw

    def exchange(self, body, label):
        before, before_ref, before_raw = self.capture(label + '/before')
        row = dict(index=len(self.boundaries), label=label, before=before_ref,
                   request_bytes=len(body), request_sha256=sha(body))
        try:
            response = self.s.exchange(body)
            row.update(response_bytes=len(response), response_sha256=sha(response))
            after, after_ref, after_raw = self.capture(label + '/after')
            row['after'] = after_ref
            status, records = WIRE.parse(response)
            commands = []
            if len(body) >= 32 and body[:8] == b'HTORCH03':
                count = struct.unpack_from('<Q', body, 8)[0]
                if 32 + count * 64 <= len(body):
                    commands = [list(struct.unpack_from('<8Q', body, 32 + i * 64)) for i in range(count)]
            row.update(status=status, records=len(records), commands=commands)
            row['owner_check'] = self.owner.verify_frame_boundary(before, after, commands, status,
                records, body, before_raw=before_raw, after_raw=after_raw)
            if status:
                require(before_raw == after_raw and before['pointer'] == after['pointer'],
                        'actual-complete-owner-rollback')
            return status, records
        except BaseException as error:
            row['error'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
            raise
        finally:
            self.boundaries.append(row)
            self.journal.write(json.dumps(row, separators=(',', ':'), allow_nan=False) + '\n')
            self.journal.flush()

    def one(self, *command):
        status, rows = self.exchange(WIRE.packet([command]), 'command-' + str(command[0]))
        require(status == 0 and len(rows) == 1 and rows[0]['opcode'] == command[0],
                'successful-public-command', command=list(command[:4]), status=status)
        return rows[0]

    @staticmethod
    def factory_packet(dtype, shape, raw, requires=False):
        require(len(shape) <= 4, 'reader-factory-rank')
        config = struct.pack('<8Q', len(shape), int(requires), *shape, *([0] * (4 - len(shape))), 160, len(raw))
        body = b'HTORCH03' + struct.pack('<3Q', 1, 160 + len(raw), 0)
        body += struct.pack('<8Q', 97, dtype, 96, 0, 0, 0, 0, 0) + config + raw
        require(len(body) <= 1 << 20, 'real-factory-wire-size')
        return body

    def create(self, dtype, shape, raw, requires=False):
        status, rows = self.exchange(self.factory_packet(dtype, shape, raw, requires), 'typed-factory')
        require(status == 0 and len(rows) == 1 and rows[0]['opcode'] == 97,
                'actual-public-typed-factory', dtype=dtype, status=status)
        return rows[0]['value']

    def view(self, token, shape, strides, offset):
        config = struct.pack('<10Q', len(shape), *shape, *([0] * (4 - len(shape))),
                             *strides, *([0] * (4 - len(strides))), offset)
        return self.one(111, token, WIRE.Payload(config), 80)['value']

    def tensor(self, token):
        meta = WIRE.meta(self.one(13, token))
        dtype_record = self.one(96, token, 0)
        require(len(dtype_record['payload']) == 32, 'public-dtype-metadata-width')
        dtype, width, incarnation, leaf = struct.unpack('<4Q', dtype_record['payload'])
        record = self.one(98, token, 0, meta['numel'])
        require(record['value'] == meta['numel'], 'typed-read-count')
        snapshot, endpoint, raw = self.capture('tensor-read-complete-owner')
        index = self.owner.public_node(snapshot, token)
        node = snapshot['nodes'][str(index)]
        w = self.owner.w
        require(dtype in WIDTH and width == WIDTH[dtype] and dtype == w(node, 576)
                and incarnation == w(node, 320), 'dtype-public-vs-real-descriptor')
        storage = self.owner._live_row(snapshot, 2, w(node, 216), 'tensor-actual-Storage')
        version = self.owner._live_row(snapshot, 3, w(node, 224), 'tensor-actual-Version')
        start = BASE + 144 + 552 * snapshot['header']['slots']
        physical = raw[start + storage[2]:start + storage[2] + storage[3]]
        require(len(physical) == storage[3], 'complete-real-Storage-bytes')
        rank, count = w(node, 0), w(node, 8)
        shape, strides = list(node[12:12 + rank]), list(node[16:16 + rank])
        logical = bytearray()
        for i in range(count):
            remaining, at = i, w(node, 232)
            for axis in range(rank - 1, -1, -1):
                at += (remaining % shape[axis]) * strides[axis] * width
                remaining //= shape[axis]
            require(0 <= at <= len(physical) - width, 'logical-address-within-real-Storage')
            logical.extend(physical[at:at + width])
        require(bytes(logical) == record['payload'], 'public-raw-read-equals-actual-storage-addresses')
        require(meta['shape'][:rank] == shape and meta['strides'][:rank] == strides
                and meta['rank'] == rank and meta['numel'] == count and count == math.prod(shape)
                and meta['storage_id'] == w(node, 216) and meta['version_id'] == w(node, 224)
                and meta['storage_offset'] == w(node, 232) and meta['storage_bytes'] == storage[3]
                and meta['version'] == version[2] and meta['requires_grad'] == w(node, 32)
                and bool(leaf) == (w(node, 40) == 0), 'all-public-metadata-vs-actual-owner')
        base_identity = None
        if w(node, 664):
            base = snapshot['nodes'][str(w(node, 640))]
            require(w(base, 304) and w(base, 320) == w(node, 648), 'actual-ViewInfo-base-incarnation')
            base_identity = str(w(base, 320))
        return dict(dtype=DTYPE[dtype], device='cpu', element_size=width, shape=shape, strides=strides,
            numel=count, storage_bytes=storage[3], storage_offset_elements=w(node, 232) // width,
            storage_offset_bytes=w(node, 232), version=version[2], requires_grad=bool(w(node, 32)),
            is_leaf=w(node, 40) == 0, is_view=bool(w(node, 408)),
            grad_fn=None if w(node, 40) == 0 else 'NATIVE_HISTORY_PRESENT',
            grad_is_none=w(node, 248) == 0, retains_grad=bool(w(node, 384)),
            tensor_identity=str(incarnation), storage_identity=str(w(node, 216)),
            base_tensor_identity=base_identity,
            native_version_identity=w(node, 224), native_public_token=token, native_node=index,
            logical=bytes(logical), storage=physical, owner=endpoint)

    def finish(self):
        try:
            return self.s.finish()
        finally:
            if not self.journal.closed:
                self.journal.close()
                dump(self.directory / 'owner-blob-manifest.json', self.blobs)


def make_owner(candidate, image, inputs):
    path = Path(candidate) / 'observation-01/owner737.py'
    inputs.bind(path, OWNER)
    owner = load(path, 'actual_f64_owner')
    owner.bind_profile(SOURCE, image, 737)
    return owner
