"""Fixed source custody for first ordinary-half qualification; no arithmetic."""
import ast
import hashlib
import importlib.util
import json
import os
import re
import stat
import types
from pathlib import Path
HERE = Path(__file__).resolve().parent
SOURCE = 'b2430af6ab7070efda67a1f7e9e2a8a83e273d57e44728b5492f0ee9d03e8fc3'
IMAGE = '777f8ba35482fc1545f54b69f5a2690e7dfaf56994b10bf1b79b98e2e2a8aecc'
FIRST_COLD_REPORT = '8348eb9aee5c15940a7e3712f783f74ce3d195ee9e14e9b4985f276f9e93b3b4'
BASELINE = '6c9fc24a2006163d98827f0c464162dc635ded7e4fc284cbad4b30a692022f04'
OWNER = 'fb74a9a525d149678b1b0ee92913bdcdabdd4459f4cd039905e822e6a87e5830'
CANDIDATE_MANIFEST = '2d5197c66b5820d6671ddd8263b6c0d272a66a52eaecbd9206cd2f79c5fd661d'
PARTITION_MANIFEST = '970bac0845bc4b3177946e54a27782816d162bf6c2298bd68c418f0463a2eae2'
MAPPING = '2b41d4a1e466c944028d5150a951368eec1e26fb3219b1b5d5dc78fc557e1fa1'
SUPPORT = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
CHECKS = {'python_matches','platform_matches','version_backend_matches',
 'git_matches_oracle_build_pin','distribution_version_matches','direct_url_matches',
 'direct_url_archive_sha256_matches','pip_report_url_matches','pip_report_archive_sha256_matches',
 'pip_report_version_matches','pip_report_requested'}


def require(value, rule, **facts):
    if not value:
        raise AssertionError({'rule': rule, **facts})


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def dump(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate-JSON-key', key=key)
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique)


def identity(st):
    return (st.st_dev, st.st_ino, st.st_size, st.st_mode, st.st_mtime_ns, st.st_ctime_ns)


class Inputs:
    def __init__(self):
        self.rows = {}

    def bind(self, path, expected=None, size=None, mode=None):
        path = Path(path).absolute()
        require(not path.is_symlink(), 'input-is-not-symlink', path=str(path))
        before = path.stat()
        require(stat.S_ISREG(before.st_mode), 'regular-input', path=str(path))
        raw = path.read_bytes()
        after = path.stat()
        require(identity(before) == identity(after), 'input-changed-during-read', path=str(path))
        row = dict(bytes=len(raw), sha256=sha(raw), mode=stat.S_IMODE(after.st_mode),
                   identity=list(identity(after)))
        require(expected is None or row['sha256'] == expected, 'input-sha256', path=str(path),
                expected=expected, actual=row['sha256'])
        require(size is None or len(raw) == size, 'input-size', path=str(path))
        require(mode is None or row['mode'] == mode, 'input-mode', path=str(path))
        require(str(path) not in self.rows or self.rows[str(path)] == row,
                'inconsistent-input-binding', path=str(path))
        self.rows[str(path)] = row
        return raw

    def unchanged(self):
        # Never convert a failed recheck into a truthy report containing False.
        for name, row in list(self.rows.items()):
            self.bind(name, row['sha256'], row['bytes'], row['mode'])
        return True


def bind_package(inputs):
    raw = inputs.bind(HERE / 'source-manifest.json')
    manifest = parse(raw)
    expected = set(manifest['files'])
    actual = {str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()}
    require(actual == expected | {'source-manifest.json'}, 'complete-source-package-members')
    for name, row in manifest['files'].items():
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts, 'safe-source-member')
        inputs.bind(HERE / path, row['sha256'], row['bytes'], row['mode'])
    return sha(raw)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def bodies(raw):
    matches = re.findall(rb'^(fn (\w+)\([^\n]*\n.*?^end\n)', raw, re.M | re.S)
    result = {name.decode(): body for body, name in matches}
    require(len(matches) == len(result), 'unique-function-names')
    return result


def candidate_admission(directory, inputs):
    directory = Path(directory).resolve(strict=True)
    manifest_raw = inputs.bind(directory / 'package-manifest.json', CANDIDATE_MANIFEST)
    manifest = parse(manifest_raw)
    actual = {str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file()}
    require(actual == set(manifest['files']) | {'package-manifest.json'}, 'complete-half-source-package')
    for name, pin in manifest['files'].items():
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts, 'normalized-half-source-member')
        inputs.bind(directory / path, pin['sha256'], pin['bytes'], pin['mode'])
    source = inputs.bind(directory / 'candidate/runtime.hepta', SOURCE)
    original = inputs.bind(directory / 'frozen/runtime730.hepta', BASELINE)
    before, after = bodies(original), bodies(source)
    transition = parse(inputs.bind(directory / 'candidate/transition.json'))
    require(len(before) == 730 and len(after) == 737 and len(transition['changed']) == 14
            and len(transition['added']) == 7, 'complete-737-census')
    inverse = source
    for name, row in transition['added'].items():
        raw = inputs.bind(directory / 'candidate/added' / (name + '.hepta'), row['sha256'], row['bytes'])
        require(after[name] == raw and inverse.count(raw) == 1, 'whole-half-added-body', name=name)
        inverse = inverse.replace(raw, b'', 1)
    for name, row in transition['changed'].items():
        old = inputs.bind(directory / 'candidate/before' / (name + '.hepta'), row['before_sha256'])
        new = inputs.bind(directory / 'candidate/after' / (name + '.hepta'), row['after_sha256'])
        require(before[name] == old and after[name] == new and inverse.count(new) == 1,
                'whole-half-changed-body', name=name)
        inverse = inverse.replace(new, old, 1)
    require(inverse == original and sum(after[n] == before[n] for n in before) == 716,
            'entire-half737-to730-inverse')
    require(inputs.bind(directory / 'source/runtime.hepta') == source, 'partition-complete-source-copy')
    partition = parse(inputs.bind(directory / 'source/manifest.json', PARTITION_MANIFEST))
    require(len(partition['units']) == 15 and partition['runtime']['sha256'] == SOURCE,
            'exact-half737-fifteen-units')
    require([row['name'] for row in partition['units']] ==
            ['rng03'] + ['public_half_%02d' % i for i in range(12)] + ['cg_model', 'owners'],
            'exact-canonical-partition-order')
    for row in partition['units']:
        inputs.bind(directory / 'source' / row['path'], row['sha256'])
    owner = inputs.bind(directory / 'observation-01/owner737.py', OWNER)
    od = parse(inputs.bind(directory / 'observation-01/derivation.json'))
    suffix = inputs.bind(directory / 'observation-01/half-appendix.py.txt', od['appendix_sha256'])
    require(owner.endswith(suffix), 'whole-explicit-half-owner-appendix')
    prefix = owner[:-len(suffix)].decode()
    require(sha(prefix.encode()) == od['prefix_sha256'], 'half-owner-prefix-pin')
    for edit in reversed(od['inverse_edits']):
        require(prefix.count(edit['after']) == edit['count'], 'explicit-owner-inverse-count')
        prefix = prefix.replace(edit['after'], edit['before'])
    require(prefix.encode() == inputs.bind(directory / 'frozen/owner730.py',
            '5700ca389d9b73ab6f37cf13c7a25ae241aac9d4612e4f33f5158379a0e6cd2b'),
            'complete-owner-inverse-to730')
    mapping = parse(inputs.bind(directory / 'mapping-01/mapping.json', MAPPING))
    require(mapping['numeric_groups'] == 26 and mapping['input_values'] == 908216
            and mapping['standalone_refusals_not_transferred'] == 12,
            'old26-numeric-and12-nontransferred-refusal-census')
    native = inputs.bind(HERE / 'native.py')
    deriv = parse(inputs.bind(HERE / 'native-derivation.json'))
    require(sha(native) == deriv['derived_sha256'], 'derived-native-reader-pin')
    restored = native.decode()
    for edit in reversed(deriv['edits']):
        require(restored.count(edit['after']) == edit['count'], 'native-reader-inverse-count')
        restored = restored.replace(edit['after'], edit['before'])
    require(restored.encode() == inputs.bind(HERE / 'frozen/native719.py', deriv['parent_sha256']),
            'entire-frozen-transport-and-Native-class-inverse')
    return dict(schema='heptatorch.half737.source-admission.v1', source_sha256=SOURCE,
                manifest_sha256=CANDIDATE_MANIFEST, functions=737, whole_inverse_to730=True,
                old_bodies_exact=716, modified_old_bodies=14, added_bodies=7,
                whole_owner_inverse=True, exact_original_transport_inverse=True,
                private3_preserved=True, public_dtype_extension=[5,6],
                old_standalone_refusals_not_transferred=12, runtime_qualification_transferred=False)


def cold_admission(directory, image_sha, report_sha, candidate, inputs):
    directory = Path(directory).resolve(strict=True)
    for digest in (image_sha, report_sha):
        require(isinstance(digest, str) and re.fullmatch('[0-9a-f]{64}', digest), 'explicit-actual-cold-pin')
    require(image_sha == IMAGE, 'exact-first-actual-half737-image')
    bridge = load(HERE / 'cold737.py', 'half737_cold_source_bridge')
    frozen = inputs.bind(HERE / 'frozen/admission701.py', bridge.FROZEN_SHA)
    actual, proof = bridge.derive(frozen, SOURCE, image_sha)
    module = types.ModuleType('actual_half737_cold_admission')
    exec(compile(actual, 'derived-half737-cold-reader', 'exec'), module.__dict__)
    result = module.admit_build(directory, report_sha, directory / 'heptatorch', directory / 'runtime.hepta')
    for name, row in result['files'].items():
        inputs.bind(Path(name), row['sha256'], row['bytes'], row['mode'])
    built = parse(inputs.bind(directory / 'build.json', report_sha))
    manifest_raw = inputs.bind(directory / 'manifest.json', PARTITION_MANIFEST)
    require(manifest_raw == inputs.bind(Path(candidate) / 'source/manifest.json', PARTITION_MANIFEST),
            'actual-cold-exact-candidate-partition-manifest')
    manifest = parse(manifest_raw)
    require(built['blocks'] == 9779 and built['instructions'] == 35314 and built['global_exports'] == 748,
            'actual-half737-complete-compiler-census')
    for entry, unit in zip(manifest['units'], built['units']):
        require(inputs.bind(directory / (entry['name'] + '.hepta'), entry['sha256']) ==
                inputs.bind(Path(candidate) / 'source' / entry['path'], entry['sha256']),
                'all-actual-compiler-sources-exact')
        if 'expected_object_sha256' in entry:
            require(unit['object_sha256'] == entry['expected_object_sha256'], 'real-reproduced-support-object')
    for name, row in built['inputs'].items():
        inputs.bind(Path(name), row['sha256'], row['bytes'])
    stack = built['stack']
    require(stack['reserved_helper_and_startup_bytes'] == 4096
            and stack['required_stack_bytes'] == stack['maximum_path_bytes'] + 4096
            and stack['required_stack_bytes'] <= 8388608, 'actual-half-stack-and-four-arg-startup-budget')
    return dict(result, source_inverse=proof, actual_manifest_sha256=PARTITION_MANIFEST,
                actual_inputs_rechecked=True, numerical_qualification_inferred=False)
