#!/usr/bin/env python3
"""Pure source custody, original comparison and import-closure checks.

This entry does not instantiate any Native or Session class, import Torch,
run an original oracle main, or invoke any compiler or linker.
"""
import sys
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import argparse
import ast
import json
import traceback

import common
import corpus
import cases
import cold737


def spans(raw):
    lines = raw.splitlines(keepends=True)
    result = {}
    for node in ast.parse(raw).body:
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
            result[node.name] = b''.join(lines[node.lineno-1:node.end_lineno])
            if isinstance(node, ast.ClassDef):
                for member in node.body:
                    if isinstance(member, ast.FunctionDef):
                        result[node.name+'.'+member.name] = b''.join(lines[member.lineno-1:member.end_lineno])
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--candidate', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    output = args.output.resolve(); candidate = args.candidate.resolve(strict=True)
    for directory in (common.HERE, candidate):
        common.require(not output.is_relative_to(directory) and not directory.is_relative_to(output),
                       'pure-check-output-outside-bound-inputs')
    output.mkdir(parents=True, exist_ok=False)
    report = dict(schema='heptatorch.half737.qualification-source-check.v1', status='FAIL',
        native_executed=False, Torch_executed=False, compiler_executed=False, linker_executed=False)
    inputs = common.Inputs()
    try:
        report['package_manifest_sha256'] = common.bind_package(inputs)
        for path in common.HERE.rglob('*.py'):
            ast.parse(inputs.bind(path), filename=str(path))
        report['candidate'] = common.candidate_admission(candidate, inputs)
        plan = corpus.groups(candidate, inputs)
        compare, report['original_comparison_inverse'] = corpus.comparison_functions(candidate, inputs)
        _, report['cold_admission_inverse'] = cold737.derive(inputs.bind(common.HERE/'frozen/admission701.py'))
        # Build only original expression definitions. No function that uses
        # the placeholder torch=None is called by this source checker.
        _, report['original_reference_expression_proof'] = corpus.original_torch_functions(None, inputs)
        pairs = [
            ('native.py','frozen/native719.py',('CapturingSession','Native')),
            ('reference.py','frozen/reference719.py',('Blobs','tensor','factory')),
            ('run.py','frozen/run719.py',('Driver.__init__','Driver.check','Driver.rng_unchanged',
                                         'Driver.drop','Driver.cleanup','run_child')),
            ('controls.py','frozen/controls719.py',('reject',)),
        ]
        identical = []
        for current,parent,names in pairs:
            actual = spans(inputs.bind(common.HERE/current)); original = spans(inputs.bind(common.HERE/parent))
            for name in names:
                common.require(actual[name] == original[name], 'complete-original-function-or-class-body',
                               file=current, original=parent, definition=name)
                identical.append(dict(file=current,original=parent,definition=name,sha256=common.sha(actual[name])))
        report['complete_original_definitions'] = identical
        local = {path.stem:path for path in common.HERE.glob('*.py')}
        imports = []
        for path in local.values():
            for node in ast.walk(ast.parse(path.read_bytes())):
                if isinstance(node,ast.ImportFrom) and node.module in local:
                    target = local[node.module]
                    tree = ast.parse(target.read_bytes())
                    definitions = {item.name for item in tree.body if isinstance(item,(ast.FunctionDef,ast.ClassDef))}
                    definitions |= {n.id for item in tree.body if isinstance(item,ast.Assign)
                                    for target in item.targets for n in ast.walk(target) if isinstance(n,ast.Name)}
                    definitions |= {a.asname or a.name for item in tree.body if isinstance(item,(ast.Import,ast.ImportFrom))
                                    for a in item.names}
                    for name in node.names:
                        common.require(name.name in definitions, 'all-local-import-symbols-present',
                                       source=path.name,module=node.module,symbol=name.name)
                    imports.append(dict(source=path.name,line=node.lineno,module=node.module,
                                        symbols=[a.name for a in node.names]))
        report['all_local_imports_including_lazy_controls'] = imports
        common.require(cases.TASK_COUNTS == dict(numeric=26,boundary=16,entry=1,allocation=4,children=47)
                       and len(cases.CASES) == 16 and len(cases.OOM_SPECS) == 4, 'exact47-task-plan')
        report['counts'] = dict(groups=len(plan),input_words=sum(len(g['values']) for g in plan),
                               boundary=len(cases.CASES),allocation=len(cases.OOM_SPECS),children=47)
        report['comparison_negative_controls'] = []
        for family in ('F16','BF16'):
            for mode in (0,1):
                try: compare(family,mode,[0],[0],[1])
                except AssertionError:
                    report['comparison_negative_controls'].append(dict(family=family,mode=mode,rejected=True))
                else: raise AssertionError('unchanged original comparator accepted a finite mismatch')
        report['status'] = 'PASS_SOURCE_ONLY_NOT_RUN'
    except BaseException as error:
        report['error'] = dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
    finally:
        try: report['inputs_unchanged'] = inputs.unchanged()
        except BaseException as error:
            report['status'] = 'FAIL'; report['input_error'] = repr(error)
        report['inputs'] = inputs.rows
        common.dump(output/'report.json',report)
    print(json.dumps({k:report[k] for k in ('status','native_executed','Torch_executed')}))
    return 0 if report['status'] == 'PASS_SOURCE_ONLY_NOT_RUN' else 1


if __name__ == '__main__':
    raise SystemExit(main())
