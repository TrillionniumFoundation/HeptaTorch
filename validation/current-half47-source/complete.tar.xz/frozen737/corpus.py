"""Only frozen original inputs and exact original comparison source spans."""
import ast
import struct
import types
from pathlib import Path

from common import HERE, MAPPING, SOURCE, load, parse, require, sha


def groups(candidate, inputs):
    candidate = Path(candidate)
    module = load(candidate / 'map_original_cases.py', 'frozen_half_input_mapping_only')
    raw = {name: inputs.bind(candidate / 'frozen' / name, digest) for name, digest in module.PIN.items()}
    corpus = module.original_inputs(raw)
    remapped, f16loop, bf16loop, _, _ = module.map_groups(raw, corpus)
    expected = parse(inputs.bind(candidate / 'mapping-01/mapping.json', MAPPING))
    require(dict(remapped, all_inputs_unchanged=True) == expected, 'complete-original-input-remapping')
    source_groups = [(mode, values) for _, mode, values in corpus[0]] + corpus[1]
    result = []
    for row, (mode, values) in zip(expected['numeric'], source_groups):
        width = row['input_width']
        logical = b''.join(v.to_bytes(width, 'little') for v in values)
        require(mode == row['original_mode'] and sha(logical) == row['input_raw_sha256'],
                'whole-original-input-words')
        result.append(dict(row, values=values, raw=logical))
    require(len(result) == 26 and sum(len(g['values']) for g in result) == 908216,
            'all26-and908216-original-inputs')
    return result


def public_plan(group):
    return {k:v for k,v in group.items() if k not in ('values','raw')}


def comparison_functions(candidate, inputs):
    candidate = Path(candidate)
    f16 = inputs.bind(candidate / 'mapping-01/original-f16-comparison.py.txt',
        '21772895c979945f6181d610f9fe10d5b3f5c7a645b2fd85dd8bd5d8ddb444c0')
    bf16 = inputs.bind(candidate / 'mapping-01/original-bf16-comparison.py.txt',
        'a7136637404a5b300f4a55bc1a08cd2faf252ad789f0f7473c94eb2e72ad602b')
    # Preserve each complete original for-loop byte-for-byte, including its
    # indentation. Two unconditional scopes accommodate the nested F16 loop.
    a = b'''def f16_compare(mode, values, got, want):
    row = {'nan_classification':0,'exact_non_nan':0,'mismatches':[]}
    src_exp, src_fraction = (0x7f800000,0x7fffff) if mode==0 else (0x7c00,0x3ff)
    dst_exp, dst_fraction, dst_quiet = (0x7c00,0x3ff,0x200) if mode==0 else (0x7f800000,0x7fffff,0x400000)
    if True:
        if True:
''' + f16 + b'''            assert not row['mismatches'], row['mismatches']
    return row
'''
    b = b'''def bf16_compare(mode, values, found, want):
    nans=0;exact=0
    nanmask,payload,targetmask,targetpayload = (0x7f800000,0x7fffff,0x7f80,0x7f) if mode==0 else (0x7f80,0x7f,0x7f800000,0x7fffff)
''' + bf16 + b'''    return {'nan_classification':nans,'exact_non_nan':exact,'mismatches':[]}
'''
    require(a.count(f16) == b.count(bf16) == 1, 'entire-comparison-spans-kept')
    env = {}
    exec(compile(a+b, 'complete-original-half-comparison-loops', 'exec'), env)
    def compare(family, mode, values, actual, expected):
        require(len(values) == len(actual) == len(expected), 'complete-comparison-count')
        return env['f16_compare' if family == 'F16' else 'bf16_compare'](mode, values, actual, expected)
    proof = dict(schema='heptatorch.half737.original-numeric-comparison-inverse.v1',
        original_F16_span_sha256=sha(f16), original_BF16_span_sha256=sha(bf16),
        executed_wrapper_sha256=sha(a+b), whole_original_spans_byte_identical=True,
        numeric_predicates_or_tolerances_changed=False,
        F16_actual_NaN_quiet_bit_required=True, BF16_extra_quiet_bit_added=False)
    return compare, proof


def original_torch_functions(torch, inputs):
    """Select original real-Torch expressions, never compiler/native/main."""
    f16 = inputs.bind(HERE / 'frozen/f16_oracle.py',
        '34940af7cd7c4dbb8de376e8e041d6c7f3820a6a6fbbea07bf3d6ec61562ccd9')
    main = next(n for n in ast.parse(f16).body if isinstance(n,ast.FunctionDef) and n.name=='main')
    fn = next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='reference')
    env={'torch':torch,'a':types.SimpleNamespace(reference='pytorch')}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),
                 'original-f16-Torch-reference-function', 'exec'),env)
    f16_reference=env['reference']
    bf16=inputs.bind(HERE/'frozen/bf16_oracle.py',
        'b6faeb43030d713cbdffb9bb0f228e561d6ce8532fd4a6cb6a3a4bdd782c0827')
    fn=next(n for n in ast.parse(bf16).body if isinstance(n,ast.FunctionDef) and n.name=='compare')
    block=next(n for n in fn.body if isinstance(n,ast.If) and isinstance(n.test,ast.Compare)
               and isinstance(n.test.left,ast.Name) and n.test.left.id=='mode')
    want=next(n for n in fn.body if isinstance(n,ast.Assign)
              and any(isinstance(t,ast.Name) and t.id=='want' for t in n.targets))
    def original_bf16(mode,values,raw):
        if not values:return []
        scope={'torch':torch,'mode':mode,'values':values,'buf':bytearray(raw)}
        exec(compile(ast.fix_missing_locations(ast.Module(body=[block,want],type_ignores=[])),
                     'original-bf16-Torch-reference-statements','exec'),scope)
        return scope['want']
    def original(family,mode,values,raw):
        return f16_reference(mode,values,raw) if family=='F16' else original_bf16(mode,values,raw)
    proof=dict(F16_complete_original_Torch_function=True,
               BF16_complete_original_Torch_branch_and_result_statement=True,
               host_numeric_expected_values_used=False, compiler_or_native_or_original_main_called=False)
    return original,proof
