#!/usr/bin/env python3
"""Real pinned Torch half reference; no native application or HIA tool calls."""
import sys
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent))
import argparse,gc,json,math,runpy,struct,traceback
from common import HERE,SOURCE,CHECKS,LOCK,SUPPORT,Inputs,bind_package,candidate_admission,dump,parse,require,sha
from cases import CASES,CASE_SHA256,BOUNDARY_CONTRACT,DTYPES,WIDTH,OOM_SPECS,raw_words
from corpus import groups,public_plan,comparison_functions,original_torch_functions


class Blobs:
    def __init__(self, root):
        self.root = root
        (root / 'blobs').mkdir(exist_ok=False)
        self.rows = {}

    def put(self, raw):
        digest = sha(raw)
        path = self.root / 'blobs' / (digest + '.bin')
        if digest not in self.rows:
            with path.open('xb') as stream:
                stream.write(raw)
            self.rows[digest] = dict(path=str(path.relative_to(self.root)), bytes=len(raw), sha256=digest,
                                     mode=path.stat().st_mode & 0o7777)
        else:
            require(path.read_bytes() == raw, 'reference-blob-dedup-exact')
        return self.rows[digest]


def tensor(torch, value, blobs):
    logical = bytes(value.detach().contiguous().reshape(-1).view(torch.uint8).tolist())
    physical = bytes(value.untyped_storage())
    return dict(dtype=str(value.dtype), device=str(value.device), element_size=value.element_size(),
        shape=list(value.shape), strides=list(value.stride()), numel=value.numel(),
        storage_bytes=value.untyped_storage().nbytes(), storage_offset_elements=value.storage_offset(),
        storage_offset_bytes=value.storage_offset() * value.element_size(), version=value._version,
        requires_grad=value.requires_grad, is_leaf=value.is_leaf, is_view=value._is_view(),
        grad_fn=None if value.grad_fn is None else type(value.grad_fn).__name__,
        grad_is_none=value.grad is None, retains_grad=value.retains_grad,
        logical=blobs.put(logical), storage=blobs.put(physical),
        tensor_identity=str(value._cdata), storage_identity=str(value.untyped_storage()._cdata),
        base_tensor_identity=None if value._base is None else str(value._base._cdata))


def factory(torch, dtype, shape, raw, requires=False):
    require(len(raw) == math.prod(shape) * WIDTH[dtype], 'reference-raw-factory-shape')
    if raw:
        # Copy bytes without passing through a Python floating-point scalar.
        # The final clone is a fresh, non-view leaf with Version zero.
        value = torch.frombuffer(bytearray(raw), dtype=getattr(torch, DTYPES[dtype])).reshape(shape).clone()
    else:
        value = torch.empty(shape, dtype=getattr(torch, DTYPES[dtype]), device='cpu')
    if requires:
        value.requires_grad_(True)
    require(value._version == 0 and not value._is_view() and value.is_leaf,
            'fresh-real-Torch-factory-contract')
    return value


def observe_group(torch, group, original, blobs):
    rng=bytes(torch.get_rng_state().tolist())
    source=factory(torch,group['public_source_dtype'],[len(group['values'])],group['raw'])
    before=tensor(torch,source,blobs)
    value=source.to(dtype=getattr(torch,DTYPES[group['public_target_dtype']]),copy=True,
                    memory_format=torch.preserve_format)
    result=tensor(torch,value,blobs)
    expected=original(group['family'],group['original_mode'],group['values'],group['raw'])
    raw=bytes(value.contiguous().reshape(-1).view(torch.uint8).tolist())
    packed=b''.join(v.to_bytes(group['output_width'],'little') for v in expected)
    require(raw==packed,'actual-Tensor-cast-exactly-matches-original-Torch-expression',case=group['name'])
    require(before==tensor(torch,source,blobs),'reference-original-input-all-fields-and-bytes-unchanged')
    require(bytes(torch.get_rng_state().tolist())==rng,'reference-numeric-RNG-unchanged')
    return dict(public_plan(group),status='OBSERVED',source=before,result=result,
                original_reference_words=blobs.put(packed),original_function_witness_matches=True,
                input_unchanged=True,rng=blobs.put(rng))


def observe_boundary(torch,spec,blobs):
    live,comparisons,marks={},{},[]
    rng=bytes(torch.get_rng_state().tolist())
    def mark(label):
        values={name:tensor(torch,t,blobs) for name,t in live.items()}
        names=list(values);relations={}
        for i,left in enumerate(names):
            for right in names[i+1:]:
                relations[left+'|'+right]=dict(same_Tensor=values[left]['tensor_identity']==values[right]['tensor_identity'],
                    same_Storage=values[left]['storage_identity']==values[right]['storage_identity'])
        require(bytes(torch.get_rng_state().tolist())==rng,'boundary-RNG-unchanged')
        marks.append(dict(label=label,live_roles=names,tensors=values,comparisons=dict(comparisons),relations=relations))
    for index,event in enumerate(spec['actions']):
        kind=event['kind']
        if kind=='create':
            live[event['name']]=factory(torch,event['dtype'],event['shape'],
                raw_words(event['dtype'],event['words']),event['requires'])
            comparisons[event['name']]=None
        elif kind=='view':
            live[event['name']]=live[event['source']].as_strided(event['shape'],event['strides'],event['offset'])
            comparisons[event['name']]=comparisons[event['source']]
        elif kind=='cast':
            source=live[event['source']]
            dtype=event['target'];fmt=torch.preserve_format if event['format']==0 else torch.contiguous_format
            if event['opcode']==109:
                value=torch.ops.aten._to_copy.default(source,dtype=getattr(torch,DTYPES[dtype]),
                    layout=torch.strided,device=torch.device('cpu'),pin_memory=False,non_blocking=False,memory_format=fmt)
            else:
                value=source.to(dtype=getattr(torch,DTYPES[dtype]),copy=event['copy'],memory_format=fmt)
            live[event['name']]=value
            if value.dtype==source.dtype:
                comparisons[event['name']]=comparisons[event['source']]
                require(bytes(value.contiguous().reshape(-1).view(torch.uint8).tolist())==
                        bytes(source.contiguous().reshape(-1).view(torch.uint8).tolist()),'Torch-same-dtype-raw-bits-preserved')
            else:
                comparisons[event['name']]=dict(family=spec['family'],mode=0 if dtype in (5,6) else 1,
                    input_width=source.element_size(),input=blobs.put(bytes(source.contiguous().reshape(-1).view(torch.uint8).tolist())))
            del source,value
        elif kind in ('set','fill'):
            value=live[event['source']];integer={2:torch.int16,4:torch.int32,8:torch.int64}[value.element_size()]
            raw=int(event['bits']).to_bytes(value.element_size(),'little')
            original=bytes(value.contiguous().reshape(-1).view(torch.uint8).tolist())
            integer_view=value.view(integer)
            replacement=torch.frombuffer(bytearray(raw),dtype=integer).reshape(())
            if kind=='fill':
                target=integer_view;replacement=replacement.expand_as(target)
            else:
                remain=event['index'];coords=[]
                require(0<=remain<value.numel(),'reference-raw-mutation-index')
                for size in reversed(value.shape):coords.append(remain%size);remain//=size
                target=integer_view[tuple(reversed(coords))]
            version=value._version;target.copy_(replacement)
            require(value._version==version+1,'one-real-raw-mutation-Version-increment')
            # These raw mutation recipes start from exact-bit inputs or
            # replace the complete scalar/empty tensor. No old NaN tolerance
            # is converted into an exact payload requirement accidentally.
            for name,alias in live.items():
                if alias is value:comparisons[name]=None
            del value,integer_view,replacement,target,alias,original
        else:raise ValueError(kind)
        mark('%02d-%s'%(index,kind))
    for name in list(live)[::-1]:
        del live[name];comparisons.pop(name);gc.collect();mark('drop-'+name)
    return dict(name=spec['name'],spec=spec,status='OBSERVED',marks=marks,rng=blobs.put(rng),rng_unchanged=True)


def observe_recovery(torch,spec,blobs):
    rng=bytes(torch.get_rng_state().tolist());dtype=spec['dtype'];count=spec['count']
    if spec['direction']=='narrow':
        backing=factory(torch,0,[1],struct.pack('<I',0x3f800000))
        source=backing.as_strided([count],[0],0);target=dtype
    else:
        one=0x3c00 if dtype==5 else 0x3f80
        source=factory(torch,dtype,[count],struct.pack('<H',one)*count);target=0
    before=tensor(torch,source,blobs);result=source.to(dtype=getattr(torch,DTYPES[target]),copy=True)
    require(before==tensor(torch,source,blobs) and bytes(torch.get_rng_state().tolist())==rng,'recovery-input-and-RNG-unchanged')
    return dict(spec=spec,status='OBSERVED',source=before,result=tensor(torch,result,blobs),
                rng=blobs.put(rng),out_of_memory_is_native_resource_control_not_Torch_claim=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('repository','candidate','output'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--prepare-only',action='store_true');args=p.parse_args()
    require(not sys.flags.optimize,'all-original-assertions-enabled')
    repo=args.repository.resolve(strict=True);candidate=args.candidate.resolve(strict=True)
    require(Path.cwd().resolve()==repo,'fixed-Torch-repository-cwd')
    out=args.output.resolve()
    for path in (HERE,repo,candidate):require(not out.is_relative_to(path) and not path.is_relative_to(out),'isolated-reference-output')
    out.mkdir(parents=True,exist_ok=False);inputs=Inputs();code=1
    report=dict(schema='heptatorch.half737.tensor-reference26.v1',status='PREPARED_NOT_RUN',
        producer_source_sha256=SOURCE,Torch_executed=False,native_executed=False,groups=[],boundary_cases=[],
        allocation_recovery=[],failures=[],expected_numeric_groups=26,expected_boundary_cases=16,
        expected_allocation_references=4,boundary_plan=CASES,boundary_case_sha256=CASE_SHA256,
        boundary_contract=BOUNDARY_CONTRACT,old_standalone_refusals_not_transferred=12,
        inputs_unchanged=False,full_project_status='HOLD')
    try:
        report['producer_manifest_sha256']=bind_package(inputs)
        report['source_admission']=candidate_admission(candidate,inputs)
        plan=groups(candidate,inputs);report['case_plan']=[public_plan(g) for g in plan]
        _,report['original_comparison_inverse']=comparison_functions(candidate,inputs)
        inputs.bind(repo/'tests/pytorch_oracle.py',SUPPORT)
        lock=parse(inputs.bind(repo/'compatibility/pytorch-oracle-lock.json',LOCK))
        inputs.bind(repo/'compatibility/upstream-lock.json')
        if not args.prepare_only:
            inputs.bind(repo/lock['oracle']['install_report']);saved=sys.argv
            try:
                sys.argv=[str(repo/'tests/pytorch_oracle.py'),str(out/'NO_NATIVE_EXECUTION'),
                          str(out/'oracle-provenance.json'),str(repo/'compatibility/pytorch-oracle-lock.json')]
                ctx=runpy.run_path(str(repo/'tests/pytorch_oracle.py'),run_name='half737_reference_only')
            finally:sys.argv=saved
            torch,provenance=ctx['torch'],ctx['PROVENANCE']
            require(provenance['status']=='PASS' and set(provenance['checks'])==CHECKS
                    and all(v is True for v in provenance['checks'].values()),'all11-fixed-wheel-provenance-checks')
            require(str(torch.__version__)=='2.15.0+cpu'
                    and torch.version.git_version=='d0f2af8b66b20da4baa50644c0cd3f887a2eae2e'
                    and torch.get_num_threads()==1,'exact-wheel-and-thread-contract')
            report.update(Torch_executed=True,oracle_provenance=provenance,torch_version=str(torch.__version__),
                torch_git_version=torch.version.git_version,num_threads=torch.get_num_threads(),cpu_capability=torch._C._get_cpu_capability())
            torch.manual_seed(1729);rng=bytes(torch.get_rng_state().tolist());require(len(rng)==5056,'complete-RNG')
            blobs=Blobs(out);original,report['original_reference_expression_proof']=original_torch_functions(torch,inputs)
            tasks=[('groups','numeric-%02d'%i,g,lambda x:observe_group(torch,x,original,blobs)) for i,g in enumerate(plan)]
            tasks += [('boundary_cases','boundary-%02d'%i,s,lambda x:observe_boundary(torch,x,blobs)) for i,s in enumerate(CASES)]
            tasks += [('allocation_recovery','allocation-%02d'%i,s,lambda x:observe_recovery(torch,x,blobs)) for i,s in enumerate(OOM_SPECS)]
            for category,name,spec,fn in tasks:
                try:row=fn(spec)
                except BaseException as error:
                    row=dict(status='FAIL',name=spec['name'],error=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
                    report['failures'].append(dict(category=category,name=name,error=row['error']))
                dump(out/(name+'.json'),row);report[category].append(row)
            require(bytes(torch.get_rng_state().tolist())==rng,'whole-reference-RNG-unchanged')
            report['rng']=blobs.put(rng);report['blob_manifest']=blobs.rows
            report['status']='OBSERVED' if not report['failures'] else 'FAIL'
        code=0 if report['status'] in ('OBSERVED','PREPARED_NOT_RUN') else 1
    except BaseException as error:
        report['status']='FAIL';report['failures'].append(dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
    finally:
        try:report['inputs_unchanged']=inputs.unchanged()
        except BaseException as error:report['status']='FAIL';report['failures'].append(dict(stage='inputs-recheck',error=repr(error)))
        report['inputs']=inputs.rows
        if report['status']=='FAIL':code=1
        dump(out/'report.json',report)
    print(__import__('json').dumps({k:report[k] for k in ('status','Torch_executed','expected_numeric_groups','expected_boundary_cases')}))
    return code


if __name__=='__main__':raise SystemExit(main())
