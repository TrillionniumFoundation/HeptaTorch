"""Freeze the additive regression and every observed original/fixed byte."""
from pathlib import Path
import hashlib
import json
import lzma
import shutil
import tarfile

BASE = Path(__file__).resolve().parent
DEST = Path('/workspace/scratch/d26699e25fea/mixed-frozen35-accounting-extension/tombstone-addon-10')
REL = Path('validation/mixed-frozen35-accounting/tombstone-legacy-refusal')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def info(path):
    return {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes()),
            'mode': path.stat().st_mode & 0o777}


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    path.chmod(0o644)


def main():
    DEST.mkdir(parents=True, exist_ok=False)
    data = DEST / REL
    data.mkdir(parents=True)
    new_rel = Path('tests/mixed_frozen35_accounting/test_storage_tombstone_legacy_refusal.py')
    new_script = BASE / 'repository' / new_rel
    assert info(new_script)['sha256'] == '55f308ac9c3e821dd4770f9f8eb42def43113c6f78e35f63a8f6dafcf72c968c'
    (DEST / new_rel).parent.mkdir(parents=True)
    shutil.copyfile(new_script, DEST / new_rel)
    (DEST / new_rel).chmod(0o644)
    fixed = json.loads((BASE / 'observed-fixed-01/report.json').read_bytes())
    primary = json.loads((BASE / 'observed-original-traced-02/captured-primary-report.json').read_bytes())
    capture = json.loads((BASE / 'observed-original-traced-02/capture-receipt.json').read_bytes())
    proof = json.loads((BASE / 'adaptation.json').read_bytes())
    assert fixed['status'] == 'PASS' and fixed['native_cases'] == 1 and fixed['copied_negative_cases'] == 4
    assert fixed['frames'] == 6 and fixed['EOF_exit_code'] == 0 and fixed['inputs_after_unchanged']
    assert primary['status'] == 'FAIL' and capture['separate_driver_EOF_cleanup']['EOF_exit_code'] == 0
    assert proof['inverse_entire_file_byte_identical'] and proof['source_package_unchanged']

    sources = {}
    def add_tree(prefix, root):
        for path in sorted(root.rglob('*')):
            assert not path.is_symlink(), path
            if path.is_file():
                name = str(Path(prefix) / path.relative_to(root))
                assert name not in sources
                sources[name] = path
    for name in ('observed-original-01', 'observed-original-traced-02', 'observed-fixed-01'):
        add_tree(name, BASE / name)
    for name in ('capture_original_failure.py', 'build_addon.py', 'freeze_addon.py',
                 'adaptation.json', 'original.stdout', 'original.stderr', 'original-execution.json',
                 'fixed.stdout', 'fixed.stderr', 'fixed-execution.json'):
        sources[name] = BASE / name
    add_tree('inputs/repository', BASE / 'repository')
    for key in ('source', 'native', 'protocol', 'owner_client'):
        path = Path(fixed['inputs'][key]['path'])
        assert info(path)['sha256'] == fixed['inputs'][key]['sha256']
        sources['inputs/executed/' + path.name] = path
    members = {name: {'original_path': str(path), **info(path)} for name, path in sources.items()}
    archive = data / 'raw-evidence.tar.xz'
    with tarfile.open(archive, 'w:xz', preset=3, format=tarfile.PAX_FORMAT) as tar:
        for name, path in sorted(sources.items()):
            row = members[name]
            header = tarfile.TarInfo(name)
            header.size, header.mode, header.mtime = row['bytes'], row['mode'], 0
            with path.open('rb') as stream:
                tar.addfile(header, stream)
    archive.chmod(0o644)
    decoder = lzma.LZMADecompressor()
    with archive.open('rb') as stream:
        while part := stream.read(65536):
            decoder.decompress(part)
            assert not decoder.unused_data
    assert decoder.eof and not decoder.unused_data
    found = set()
    with tarfile.open(archive, 'r:xz') as tar:
        for item in tar:
            assert item.isfile() and item.name in members and item.name not in found
            found.add(item.name)
            row = members[item.name]
            raw = tar.extractfile(item).read()
            assert item.size == len(raw) == row['bytes'] and item.mode == row['mode']
            assert sha(raw) == row['sha256']
    assert found == set(members)
    for name, path in sources.items():
        assert info(path) == {k: members[name][k] for k in ('bytes', 'sha256', 'mode')}
    manifest = {'schema': 'heptatorch.tombstone-refusal-raw-evidence.v1',
                'member_count': len(members), 'expanded_file_bytes': sum(r['bytes'] for r in members.values()),
                'members': members, 'archive': info(archive), 'single_XZ_EOF_verified': True,
                'all_members_size_sha256_mode_verified': True, 'all_original_files_after_unchanged': True}
    dump(data / 'raw-evidence-manifest.json', manifest)
    copies = {
        'adaptation.json': BASE / 'adaptation.json',
        'original-execution.json': BASE / 'original-execution.json',
        'original.stderr': BASE / 'original.stderr',
        'original.stdout': BASE / 'original.stdout',
        'captured-primary-report.json': BASE / 'observed-original-traced-02/captured-primary-report.json',
        'capture-receipt.json': BASE / 'observed-original-traced-02/capture-receipt.json',
        'fixed-execution.json': BASE / 'fixed-execution.json',
        'fixed.stdout': BASE / 'fixed.stdout',
        'fixed.stderr': BASE / 'fixed.stderr',
        'report.json': BASE / 'observed-fixed-01/report.json',
        'reproduction/build_addon.py': BASE / 'build_addon.py',
        'reproduction/capture_original_failure.py': BASE / 'capture_original_failure.py',
    }
    for name, path in copies.items():
        target = data / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        target.chmod(0o644)
        assert target.read_bytes() == path.read_bytes()
    discovery = {
        'schema': 'heptatorch.mixed10-tombstone-legacy-binding-discovery.v1',
        'original_source_package_manifest_sha256': '347a9078f627a2844625f57a8f82aa06ee8c9cd47b37a3f8d44b934cf263eae1',
        'original_test_sha256': proof['original_test_sha256'],
        'original_test_and_all_source19_members_unchanged': True,
        'primary_issue': 'The original test loads observer.ORIGINAL_STRUCTURAL, which now names corrected aa8, yet expects historical defective6ea refusal.',
        'primary_failure': primary['error'],
        'secondary_issue': 'The original failure finally calls non-existent Session.stop and prevents its report from reaching disk.',
        'secondary_failure': capture['original_execution_escaped']['error'],
        'initial_unmodified_execution_report_json_exists': False,
        'initial_original_wire_frames': 3,
        'read_only_trace_reexecution_original_wire_frames': 3,
        'trace_changes_source_or_live_locals': False,
        'trace_driver_cleanup_separately_observed_EOF_exit_code': 0,
        'ROG_full35_live32_copied18_did_not_execute_this_separate_regression': True,
        'production_or_current_observer_defect': False,
        'production_or_current_observer_changed': False,
        'new_test_edit_labels': [r['label'] for r in proof['edits']],
        'whole_pytorch_gate': 'HOLD', 'full_pytorch_parity': False,
    }
    dump(data / 'discovery.json', discovery)
    readme = '''# Mixed10 tombstone legacy-refusal regression addon

This additive test corrects a host test dependency. The frozen source19 package
(manifest 347a9078...) and its original `test_storage_tombstone.py` stay intact.
The mixed10 native program and current 8361/58c9/aa8 observers are unchanged.

## Actual outcomes

The unchanged original test executed three native frames, then failed because
it loaded the already-corrected aa8 predicate while expecting original6ea to
reject the legal Storage tombstone. Its failure cleanup called a nonexistent
`Session.stop`; this secondary exception prevented its report from being
written. The complete original stderr, requests/responses and snapshots are
preserved. A separate read-only Python trace execution of the same source
captured the primary FAIL and secondary exception; its driver performed real
EOF cleanup, separately recorded. Neither original run is called a PASS.

The new entry actually passed one native case in six frames and four copied
JSON refusal controls, with EOF exit zero. It binds the exact original6ea file
before import and after execution. Only SCHEMA/SOURCE/IMAGE/PROFILE module data
identify the copied JSON snapshot; no old function body is changed. Every
original assertion remains, and seven explicit edits invert to the entire
original test bytes. Failure cleanup uses the existing real EOF method and
preserves any primary error.

## Repository CLI

Run from the repository root after the frozen source19 package and its normal
dependencies are installed:

```sh
python -S -B tests/mixed_frozen35_accounting/test_storage_tombstone_legacy_refusal.py \\
  --binary build/mixed-integer-autograd/tensor-mixed-autograd-session \\
  --source build/mixed-integer-autograd/runtime.hepta \\
  --protocol tests/retained_resource_review/protocol.py \\
  --output NEW_TOMBSTONE_OUTPUT_DIRECTORY
```

The sole additional dependency is the already-published
`tests/dtype_owner_accounting/owner640.py`, exact SHA256
6ea9e8b33164089034a2a71a03f4850e1ec18ed1a09155d7841f700ef311c833.
The script rejects a different dependency before native execution.

The regression is ownership admission, not another numerical API. Its four
negative cases alter copied JSON only. It does not replace the real full35
EOF/Version gates or the original copied18 suite. The actual ROG live32/full35
evidence remains separately frozen and did not run this extra regression.
Global PyTorch qualification remains HOLD and full parity false.

## Evidence

`raw-evidence.tar.xz` contains every original/fixed raw file, exact test and
observer inputs, protocol/client and executed native/source bytes.
The manifest binds each member's original path, size, SHA256 and mode. A complete
single-XZ EOF plus tar member set, bytes and modes check was performed before
freezing; original inputs were re-read afterward. Child JSON absolute paths and
all original report bytes are preserved. The outer archive and manifest exclude
themselves; the package manifest separately binds all delivered payloads.
'''
    (data / 'README.md').write_text(readme)
    (data / 'README.md').chmod(0o644)
    qualification = {
        'schema': 'heptatorch.mixed-tombstone-legacy-refusal-qualification.v1',
        'status': 'PASS', 'new_test_sha256': info(DEST / new_rel)['sha256'],
        'source_sha256': fixed['inputs']['source']['sha256'],
        'native_sha256': fixed['inputs']['native']['sha256'],
        'native_cases': 1, 'native_frames': 6, 'copied_negative_cases': 4,
        'numeric_API_cases': 0, 'Torch_executed': False,
        'EOF_exit_code': 0, 'inputs_after_unchanged': True,
        'report_sha256': info(data / 'report.json')['sha256'],
        'historical_original_status': 'FAIL',
        'raw_archive': info(archive), 'raw_manifest': info(data / 'raw-evidence-manifest.json'),
        'raw_member_count': len(members), 'whole_pytorch_gate': 'HOLD', 'full_pytorch_parity': False}
    dump(data / 'qualification.json', qualification)
    package_members = {str(p.relative_to(DEST)): info(p) for p in sorted(DEST.rglob('*')) if p.is_file()}
    package_manifest = {'schema': 'heptatorch.mixed-tombstone-legacy-refusal-addon-package.v1',
                        'payload_count': len(package_members),
                        'payload_bytes': sum(r['bytes'] for r in package_members.values()),
                        'files': package_members}
    dump(data / 'package-manifest.json', package_manifest)
    handoff = {'package': str(DEST), 'manifest_path': str(REL / 'package-manifest.json'),
               'manifest': info(data / 'package-manifest.json'), 'qualification': info(data / 'qualification.json'),
               'new_test_path': str(new_rel), 'new_test': info(DEST / new_rel),
               'payload_count': len(package_members), 'payload_bytes': package_manifest['payload_bytes'],
               'report': info(data / 'report.json'), 'archive': info(archive), 'raw_member_count': len(members)}
    dump(BASE / 'handoff.json', handoff)
    print(json.dumps(handoff, indent=2))


if __name__ == '__main__':
    main()
