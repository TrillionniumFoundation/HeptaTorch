#!/usr/bin/env python3
"""Source-bound transport runner; invokes original tests, never computes tensors.

ROG reuses exact native bytes from a separately recorded native cold build.
This script does not build the runtime or replace any numerical expectation.
"""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

SOURCE = '5f8ab1f7ca1593dc21b8b6a3537e210cfbc42b37ddefcb322239c5a316d88c49'
IMAGE = '69045063c00395d07fc6c0101ed1b8aba18376cb1daea54e0a01c2c5caeb49b6'
PROFILE = 'mixed-integer-556-fixed35-F32-Saved'
PINS = {
 'tests/pytorch_tensor_rng_backward_oracle.py': '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160',
 'tests/tensor_object_oracle/bridge.py': 'c2888687f8876ad3505f0e13c9aecddc45695eff22bfdd9fa16d760f9aa3dac5',
 'tests/tensor_object_oracle/lifecycle.py': '4a195d07772123342ac3a33aa878aab1663ce0d0d1dbd8ea5ddb110438fd278c',
 'tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py': '149b41c455444edeb8d25d0ad98045e29683e780f37f7e210e7985242d359597',
 'tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py': 'ee3cf72154ac9dfa31055557b3facab8fdd3e14aad03ef6000ced55ccd75ed88',
 'tests/pytorch_session_oracle.py': '35fa5fa3e1b740f901c11d46dca484079b77805004586c03ae42b35be2265577',
 'tests/pytorch_oracle.py': 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae',
 'compatibility/pytorch-oracle-lock.json': 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944',
 'build/pytorch-install.json': '35ad4841c2f2f94be7ded7f1bcc97f9592f806658ff660bfac5bdc3b0cf986ef',
}
CHECKS = {'python_matches', 'platform_matches', 'version_backend_matches',
 'git_matches_oracle_build_pin', 'distribution_version_matches', 'direct_url_matches',
 'direct_url_archive_sha256_matches', 'pip_report_url_matches',
 'pip_report_archive_sha256_matches', 'pip_report_version_matches', 'pip_report_requested'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def emit(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def file_entry(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw),
            'mode': path.stat().st_mode & 0o777}


def pin_bundle(bundle):
    manifest_path = bundle/'bundle-manifest.json'
    manifest = json.loads(manifest_path.read_bytes())
    assert manifest['native_source_sha256'] == SOURCE
    assert manifest['native_executable_sha256'] == IMAGE
    paths = {e['path'] for e in manifest['files']}
    assert len(paths) == len(manifest['files'])
    actual = {str(p.relative_to(bundle)) for p in bundle.rglob('*') if p.is_file()}
    assert actual == paths | {'bundle-manifest.json'}, (actual-paths, paths-actual)
    result = {}
    for e in manifest['files']:
        rel = Path(e['path'])
        assert not rel.is_absolute() and '..' not in rel.parts
        p = bundle/rel
        observed = file_entry(p)
        assert all(observed[k] == e[k] for k in ('bytes', 'sha256', 'mode')), e['path']
        result[e['path']] = observed
        if p.suffix == '.py':
            ast.parse(p.read_text(), filename=str(p))
    result['bundle-manifest.json'] = file_entry(manifest_path)
    build = json.loads((bundle/'native/build.json').read_bytes())
    assert build['source_sha256'] == SOURCE and build['native_sha256'] == IMAGE
    assert len(build['units']) == 11
    assert len({u['name'] for u in build['units']}) == 11
    for u in build['units']:
        assert u['compiler_exit'] == 0
        assert result['native/'+u['name']+'.hepta']['sha256'] == u['source_sha256']
        assert result['native/'+u['name']+'.o']['sha256'] == u['object_sha256']
    assert result['native/runtime.hepta']['sha256'] == SOURCE
    assert result['native/tensor-mixed-autograd-session']['sha256'] == IMAGE
    return result


def provenance(report):
    p = report['oracle_provenance']
    assert p['status'] == 'PASS' and set(p['checks']) == CHECKS
    assert all(v is True for v in p['checks'].values())


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bundle', type=Path, required=True)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--suite', choices=('prepare', 'live32', 'frozen35'), required=True)
    a = p.parse_args()
    bundle, repo, output = a.bundle.resolve(), a.repo.resolve(), a.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    report = {'schema': 'heptatorch.mixed556-remote-original-tests.v1', 'status': 'RUNNING',
        'suite': a.suite, 'argv': sys.argv, 'python_executable': sys.executable,
        'python_version': sys.version, 'cwd': str(Path.cwd()),
        'native_source_sha256': SOURCE, 'native_executable_sha256': IMAGE,
        'native_rebuilt_in_this_invocation': False,
        'native_bytes_from_separately_recorded_cold_build': True,
        'native_executed': False, 'Torch_executed': False, 'children': [],
        'whole_pytorch_gate': 'HOLD', 'pytorch_api_denominator': 2590,
        'full_pytorch_rewrite_complete': False}
    emit(output/'transport-report.json', report)
    before, source_paths = {}, {}
    started = time.monotonic()
    try:
        assert sys.version_info[:2] == (3, 12), sys.version
        report['bundle_inputs'] = pin_bundle(bundle)
        for name, expected in PINS.items():
            source = repo/name
            e = file_entry(source)
            assert e['sha256'] == expected, (name, e)
            before[name], source_paths[name] = e, source
            copied = output/'inputs/original'/name
            copied.parent.mkdir(parents=True, exist_ok=True)
            copied.write_bytes(source.read_bytes())
            copied.chmod(e['mode'])
            assert copied.read_bytes() == source.read_bytes()
        report['original_inputs'] = before
        namespace = bundle/'profile/tests/mixed_frozen35_accounting'
        native = bundle/'native/tensor-mixed-autograd-session'
        source = bundle/'native/runtime.hepta'
        def execute(name, args, timeout=3000):
            row = {'name': name, 'argv': [sys.executable, '-B', *map(str, args)],
                   'cwd': str(repo), 'timeout_seconds': timeout}
            report['children'].append(row)
            emit(output/'transport-report.json', report)
            stdout, stderr = output/(name+'.stdout'), output/(name+'.stderr')
            tick = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                try:
                    done = subprocess.run(row['argv'], cwd=repo,
                        env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'},
                        stdout=out, stderr=err, timeout=timeout, check=False)
                    row['return_code'] = done.returncode
                except BaseException:
                    row['execution_error'] = traceback.format_exc()
                    raise
                finally:
                    row['wall_seconds'] = time.monotonic()-tick
                    row['stdout'], row['stderr'] = file_entry(stdout), file_entry(stderr)
                    emit(output/'transport-report.json', report)
            assert done.returncode == 0, (name, done.returncode)
            return row
        def live_args(report_path):
            return [repo/'tests/pytorch_tensor_rng_backward_oracle.py',
                    '--native', native, '--source', source,
                    '--expected-native-sha256', IMAGE, '--expected-source-sha256', SOURCE,
                    '--repo', repo, '--output', report_path]
        def frozen_args(base):
            base.mkdir()
            return [namespace/'run_frozen35_accounted.py',
                    '--legacy-directory', repo/'tests/tensor_object_oracle',
                    '--native-source', source, '--observer-output', base/'journals',
                    '--observer-report', base/'accounted.json', '--', native, base/'original.json',
                    '--owned-reference', repo/'tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py',
                    '--session-reference', repo/'tests/pytorch_session_oracle.py',
                    '--reference', repo/'tests/pytorch_oracle.py',
                    '--lock', repo/'compatibility/pytorch-oracle-lock.json', '--repo', repo,
                    '--trace-directory', base/'wire', '--expected-native-sha256', IMAGE]
        if a.suite == 'prepare':
            execute('live32-prepare', [*live_args(output/'live32-not-run.json'), '--prepare-only'], 120)
            execute('frozen35-prepare', [*frozen_args(output/'frozen35-not-run'), '--prepare-only'], 120)
            assert json.loads((output/'live32-not-run.json').read_bytes())['status'] == 'NOT_RUN'
            assert json.loads((output/'frozen35-not-run/accounted.json').read_bytes())['status'] == 'PREPARED_NOT_RUN'
            report['status'] = 'PREPARED_NOT_RUN'
        elif a.suite == 'live32':
            report['execution_attempted'] = True
            report['native_executed'] = report['Torch_executed'] = None
            execute('live32', live_args(output/'original.json'))
            original = json.loads((output/'original.json').read_bytes())
            assert original['status'] == 'PASS' and original['cases'] == original['expected_cases'] == len(original['rows']) == 32
            assert original['failed_cases'] == 0 and all(r['status'] == 'PASS' for r in original['rows'])
            assert original['native_executable_sha256'] == IMAGE and original['native_source_sha256'] == SOURCE
            assert original['source_files_unchanged_during_run'] and all(v is True for v in original['source_files_unchanged_during_run'].values())
            provenance(original)
            assert original['pytorch_executed'] is True
            report['native_executed'] = report['Torch_executed'] = True
            report['original_report'] = file_entry(output/'original.json')
            report['counts'] = {key: original[key] for key in ('cases', 'frames', 'exact_binary32_words', 'serialized_state_bytes')}
            report['status'] = 'PASS'
        else:
            report['execution_attempted'] = True
            report['native_executed'] = report['Torch_executed'] = None
            base = output/'frozen35'
            execute('frozen35', frozen_args(base))
            execute('frozen35-report-binding', [namespace/'check_frozen35_accounted.py',
                '--observer-report', base/'accounted.json', '--original-report', base/'original.json'], 120)
            execute('copied18', ['-I', '-S', namespace/'check_owner_snapshots.py',
                '--observer', namespace/'owner_accounting_mixed.py', '--expected-profile', PROFILE,
                '--journals', base/'journals/owners', '--output', output/'copied18'], 300)
            original = json.loads((base/'original.json').read_bytes())
            provenance(original)
            report['native_executed'] = report['Torch_executed'] = True
            report['original_report'] = file_entry(base/'original.json')
            report['observer_report'] = file_entry(base/'accounted.json')
            report['copied18_report'] = file_entry(output/'copied18/report.json')
            report['counts'] = {key: original[key] for key in ('cases', 'frames', 'compared_values')}
            report['status'] = 'PASS'
    except BaseException:
        report['status'] = 'FAIL'
        report['error'] = traceback.format_exc()
    finally:
        try:
            report['bundle_after'] = pin_bundle(bundle)
            report['bundle_unchanged'] = report.get('bundle_inputs') == report['bundle_after']
            report['original_inputs_after'] = {name: file_entry(path) for name, path in source_paths.items()}
            report['original_inputs_unchanged'] = before == report['original_inputs_after']
            assert report['bundle_unchanged'] and report['original_inputs_unchanged']
        except BaseException:
            report['status'] = 'FAIL'
            report['custody_error'] = traceback.format_exc()
        report['wall_seconds'] = time.monotonic()-started
        emit(output/'transport-report.json', report)
    print(json.dumps({'status': report['status'], 'suite': a.suite, 'counts': report.get('counts'),
                      'report_sha256': sha((output/'transport-report.json').read_bytes())}))
    return 0 if report['status'] in ('PASS', 'PREPARED_NOT_RUN') else 1


if __name__ == '__main__':
    raise SystemExit(main())
