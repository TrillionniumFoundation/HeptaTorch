#!/usr/bin/env python3
"""Preserve all exact remote evidence and local byte-custody in a Git-ready packet."""
import hashlib
import io
import json
import lzma
import os
from pathlib import Path
import shutil
import tarfile

BASE = Path(__file__).resolve().parent
DURABLE = Path('/workspace/scratch/d26699e25fea/mixed-frozen35-accounting-extension')
DOWNLOAD = DURABLE/'remote-evidence-01'
OUT = DURABLE/'evidence-handoff-10'
PREFIX = Path('validation/mixed-frozen35-accounting/remote10')
ARCHIVE = '6499e621172b98fefea2f49e8f0178c5d7047e55438aa61819dd25a3395292d7'
SOURCE_MANIFEST = '347a9078f627a2844625f57a8f82aa06ee8c9cd47b37a3f8d44b934cf263eae1'

def sha(b): return hashlib.sha256(b).hexdigest()

def digest(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()

def record(p): return {'bytes':p.stat().st_size,'sha256':digest(p),'mode':p.stat().st_mode&511}

def emit(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists()
    p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');p.chmod(0o644)

def copy(src, dst, custody):
    assert src.is_file() and not src.is_symlink()
    before=record(src);dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists()
    shutil.copyfile(src,dst);dst.chmod(0o644)
    assert digest(dst)==before['sha256'] and dst.stat().st_size==before['bytes'] and record(src)==before
    custody.append({'source':str(src),'source_entry':before,'destination':dst.relative_to(OUT).as_posix(),
                    'destination_entry':record(dst),'bytes_unchanged':True,
                    'outer_file_mode_normalized_for_Git':before['mode']!=0o644})

def main():
    admission=json.loads((DOWNLOAD/'local-admission.json').read_bytes())
    assert admission['status']=='PASS_EXACT_FIXED_REMOTE_EVIDENCE'
    assert admission['full_archived_transition_recomputation']['transitions']==6344
    assert digest(DOWNLOAD/'raw-evidence.tar.xz')==ARCHIVE
    assert digest(DOWNLOAD/'source-manifest.original.json')==SOURCE_MANIFEST
    OUT.mkdir(parents=True,exist_ok=False);dest=OUT/PREFIX;dest.mkdir(parents=True)
    custody=[]
    # Already-verified original raw moves once to avoid a second 11 MiB durable copy.
    src=DOWNLOAD/'raw-evidence.tar.xz';before=record(src)
    for proc in Path('/proc').iterdir():
        if not proc.name.isdecimal():continue
        try:
            for fd in (proc/'fd').iterdir():
                try: target=os.readlink(fd)
                except OSError:continue
                assert target!=str(src),('active archive reader',str(fd))
        except (PermissionError,FileNotFoundError):pass
    target=dest/'raw-evidence.tar.xz';os.replace(src,target);target.chmod(0o644)
    assert digest(target)==before['sha256'] and target.stat().st_size==before['bytes']
    src.symlink_to(target)
    custody.append({'source':str(src),'source_entry':before,'destination':target.relative_to(OUT).as_posix(),
        'destination_entry':record(target),'bytes_unchanged':True,'outer_file_mode_normalized_for_Git':True,
        'only_completed_private_download_moved_old_path_preserved_as_symlink':True,
        'raw_tar_member_modes_not_changed':True})
    for name in ('evidence-manifest.json','evidence-receipt.json','source-manifest.original.json',
                 'local-admission.json','local-admission.stdout','local-admission.stderr','download-custody.json'):
        copy(DOWNLOAD/name,dest/name,custody)
    copy(BASE/'verify_remote_evidence.py',dest/'verify_evidence.py',custody)
    copy(BASE/'recheck_transitions.py',dest/'recheck_transitions.py',custody)
    copy(BASE/'evidence-reader-adaptation.json',dest/'reader-adaptation.json',custody)
    wanted={
        'run-live32-01/original.json':'original-live32.json',
        'run-live32-01/transport-report.json':'live32-transport.json',
        'run-frozen35-01/frozen35/original.json':'original-frozen35.json',
        'run-frozen35-01/frozen35/accounted.json':'accounted-frozen35.json',
        'run-frozen35-01/copied18/report.json':'copied18.json',
        'run-frozen35-01/transport-report.json':'frozen35-transport.json',
        'bundle/native/build.json':'cold-native-build.original.json',
        'bundle/native/profile-rebuild.json':'cold-profile-rebuild.original.json',
    }
    manifest=json.loads((dest/'evidence-manifest.json').read_bytes())
    specs={x['path']:x for x in manifest['files']};selected=set()
    with tarfile.open(target,'r|xz') as tar:
        for member in tar:
            if member.name in wanted:
                raw=tar.extractfile(member).read();e=specs[member.name]
                assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and member.mode==e['mode']
                q=dest/wanted[member.name];assert not q.exists();q.write_bytes(raw);q.chmod(0o644)
                custody.append({'archive':ARCHIVE,'member':member.name,'original_member_entry':e,
                    'destination':q.relative_to(OUT).as_posix(),'destination_entry':record(q),
                    'bytes_unchanged':True,'outer_file_mode_normalized_for_Git':e['mode']!=0o644})
                selected.add(member.name)
    assert selected==set(wanted)
    # Preserve actual H tool envelopes, 174 immutable-read chunk receipts,
    # build/adaptation sources and the complete local 9-frame + copied18 raw.
    inputs={}
    for p in sorted(BASE.iterdir()):
        if p.is_file() and not p.is_symlink() and p.suffix in ('.json','.py','.stdout','.stderr'):
            inputs['local/'+p.name]=p
    for name in ('smoke10-first','smoke10-copied18-first'):
        for p in sorted((BASE/name).rglob('*')):
            assert not p.is_symlink()
            if p.is_file():inputs['local/'+name+'/'+p.relative_to(BASE/name).as_posix()]=p
    for p in sorted((DOWNLOAD/'chunks').glob('*.json')):
        inputs['immutable-download/chunks/'+p.name]=p
    for name in ('prefix-relocation-custody.json','download-custody.json','evidence-manifest.json.read.json','evidence-receipt.json.read.json'):
        inputs['immutable-download/'+name]=DOWNLOAD/name
    specs2={k:record(v) for k,v in sorted(inputs.items())}
    aux=dest/'transport-and-local-controls.tar.xz'
    with tarfile.open(aux,'w:xz',preset=1,format=tarfile.USTAR_FORMAT) as tar:
        for name,p in sorted(inputs.items()):
            raw=p.read_bytes();e=specs2[name];assert len(raw)==e['bytes'] and sha(raw)==e['sha256']
            m=tarfile.TarInfo(name);m.size=len(raw);m.mode=e['mode'];m.mtime=0;tar.addfile(m,io.BytesIO(raw))
    seen=set()
    with tarfile.open(aux,'r|xz') as tar:
        for m in tar:
            assert m.isfile() and m.name in specs2 and m.name not in seen
            e=specs2[m.name];assert m.size==e['bytes'] and m.mode==e['mode']
            with tar.extractfile(m) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==e['sha256']
            seen.add(m.name)
    assert seen==set(specs2) and {k:record(v) for k,v in sorted(inputs.items())}==specs2
    decoder=lzma.LZMADecompressor()
    with aux.open('rb') as f:
        while not decoder.eof:
            b=f.read(65536) if decoder.needs_input else b'';assert b or not decoder.needs_input
            decoder.decompress(b,max_length=1<<20)
        assert not decoder.unused_data and not f.read(1)
    emit(dest/'transport-and-local-controls.manifest.json',{'status':'VERIFIED_EXACT_AUXILIARY_RAW',
        'archive':record(aux),'member_count':len(specs2),'expanded_bytes':sum(x['bytes'] for x in specs2.values()),
        'members':specs2,'single_XZ_EOF':True,'all_members_bytes_sizes_modes_verified':True})
    emit(dest/'copy-custody.json',{'status':'EXACT_BYTES_PRESERVED','copies':custody,
        'outer_file_modes_are_Git_compatible_0644':True,'all_archive_internal_modes_preserved':True,
        'no_original_report_JSON_or_absolute_paths_rewritten':True})
    qualification={'schema':'heptatorch.mixed556-fixed35-remote-qualification.v1',
        'status':'QUALIFIED_COMPONENT_SCOPE_ONLY','source_package_manifest_sha256':SOURCE_MANIFEST,
        'source_sha256':admission['native_source_sha256'],'native_sha256':admission['native_sha256'],
        'native_origin':'Exact portable-cold10-01/native 11 compilation units; no compilation on ROG claimed.',
        'actual_execution_environment':'Configured ROG Linux fixed Python3.12 and original2.15+cpu wheel; both original11 provenance sets all true.',
        'jobs':{'prepare':'1a1e572a979-392-392c','install_prepare':'1a1e575e730-392-392f',
                'actual_live32':'1a1e5766779-392-3930','actual_frozen35':'1a1e5768bc1-392-3931','seal':'1a1e579a3b9-392-3936'},
        'actual_live32':{'cases':32,'frames':2132,'exact_binary32_words':17455,'serialized_RNG_bytes':1137600,
                        'original_report_sha256':digest(dest/'original-live32.json')},
        'actual_frozen35':{'cases':35,'frames':6344,'compared_values':2590274,
            'state_absolute_version_differences_preserved':283,'parameter_version_mismatches':0,
            'all_original_EOF_and_postclose_Version_gates_executed':True,
            'original_report_sha256':digest(dest/'original-frozen35.json'),
            'outer_report_sha256':digest(dest/'accounted-frozen35.json')},
        'copied_controls':{'original_positive':4,'original_negative':18,'report_sha256':digest(dest/'copied18.json')},
        'local_offline_custody_admission_sha256':digest(dest/'local-admission.json'),
        'all6344_pure_archived_transitions_recomputed_exactly':True,
        'raw_archive_sha256':ARCHIVE,'raw_members':271,'raw_expanded_bytes':49233889,
        'additional_new_native_or_Torch_by_offline_reader':0,
        'domain':'Original35 F32commands1..56 with real original-T Saved Hold584/592 and exact600/208; no99/101/I64-view roles in this limited domain.',
        'general_mixed_I64_owner_controls':'Separate frozen55-member handoff; not inferred from fixed35.',
        'whole_pytorch_gate':'HOLD','pytorch_api_denominator':2590,'globally_closed_schemas':0,
        'full_pytorch_rewrite_complete':False}
    emit(dest/'qualification.json',qualification)
    readme='''# Actual mixed10 live32 and complete35 evidence

Both original scripts executed on configured ROG Linux using the exact source and ELF in qualification.json. The runtime bytes came from the recorded portable cold build; ROG did not compile them. The two original eleven-check Torch provenance records are retained in full.

Live32 passed 32 cases / 2132 frames / 17455 exact binary32 words / 1137600 serialized RNG bytes. Full35 passed 35 cases / 6344 frames / 2590274 numerical comparisons. Its original 283 absolute optimizer-state Version differences remain reported, with zero parameter Version mismatches. Every original EOF and post-close Version gate executed. The new observer accepts only the original F32 command domain, accounts actual original-T Saved slots exactly, and keeps all old numerical and refusal thresholds. Its original four positive / eighteen copied-negative controls were executed on these actual35 journals.

raw-evidence.tar.xz preserves all 271 original remote files, 49233889 expanded bytes: source, all eleven module sources and objects, native image, both original reports, wrapper report, original scripts/lock/pip report, full owner journals, raw wire, and stdout/stderr. evidence-manifest.json and evidence-receipt.json are exact remote bytes. Every immutable download chunk, all local source and process metadata, and the earlier small native9/control18 raw are in transport-and-local-controls.tar.xz with their own complete manifest. No JSON or original absolute path was rewritten. Loose transport copies use Git-compatible0644; each archive member retains its original mode.

The local reader verifies every archive member and all bytes/modes, checks the complete single XZ stream, all556 function pins and eleven actual module identities, then recomputes all6344 archived transitions through the exact frozen observer. This pure replay is not an additional native or Torch execution. Its report and stdout/stderr are included without alteration.

Run the portable custody reader from a repository containing the frozen source19 package:

```sh
python -S -B validation/mixed-frozen35-accounting/remote10/verify_evidence.py --evidence validation/mixed-frozen35-accounting/remote10 --source-package . --report NEW_ADMISSION.json
```

The source-only packet remains independent; older355/428/446/523/544 profiles and their original failures are untouched. The separate55-member general mixed-owner resource packet is not replaced. This component does not close all mixed-I64 behavior or all PyTorch. Overall HOLD /2590 APIs/0 globally closed/full=false remains.
'''
    (dest/'README.md').write_text(readme);(dest/'README.md').chmod(0o644)
    files=[{'path':p.relative_to(OUT).as_posix(),**record(p)} for p in sorted(OUT.rglob('*')) if p.is_file()]
    packet={'schema':'heptatorch.mixed556-fixed35-remote-evidence-handoff.v1','status':'FROZEN',
        'files':files,'files_count':len(files),'payload_bytes':sum(x['bytes'] for x in files),
        'source_sha256':admission['native_source_sha256'],'native_sha256':admission['native_sha256'],
        'source_package_manifest_sha256':SOURCE_MANIFEST,'raw_archive_sha256':ARCHIVE,
        'whole_pytorch_gate':'HOLD','full_pytorch_rewrite_complete':False}
    emit(dest/'evidence-package-manifest.json',packet)
    for e in files:
        p=OUT/e['path'];assert not p.is_symlink() and record(p)=={k:e[k] for k in ('bytes','sha256','mode')}
    summary={'path':str(OUT),'manifest_sha256':digest(dest/'evidence-package-manifest.json'),
        'files_count':len(files),'payload_bytes':packet['payload_bytes'],
        'qualification_sha256':digest(dest/'qualification.json'),'raw_archive_sha256':ARCHIVE}
    emit(DURABLE/'evidence-handoff-10.json',summary);print(json.dumps(summary))

if __name__=='__main__':main()
