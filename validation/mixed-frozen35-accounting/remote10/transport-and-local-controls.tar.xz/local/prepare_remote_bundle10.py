#!/usr/bin/env python3
"""Package exact cold-built native bytes and read-only test transport for ROG."""
import ast
import hashlib
import io
import json
import lzma
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
PREVIOUS = BASE.parent/'integer-frozen35-accounting-extension/remote_run.py'
COLD = BASE.parent/'mixed-integer-autograd-extension/portable-cold10-01/native'
PROFILE = BASE/'profile-10-first'
SOURCE = '5f8ab1f7ca1593dc21b8b6a3537e210cfbc42b37ddefcb322239c5a316d88c49'
IMAGE = '69045063c00395d07fc6c0101ed1b8aba18376cb1daea54e0a01c2c5caeb49b6'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def entry(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw), 'mode': path.stat().st_mode & 511}

def emit(path, value):
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')

def main():
    old = PREVIOUS.read_bytes()
    assert sha(old) == '7e7432f6d18fde557f30b1177e435cc0fae605ffbfe5185b08e8449fc0c74bec'
    source = old.decode()
    edits = [
      ('adf6cae67666273aa6fb77989080ca3b1e3632188d2d7956a6d8b71808787e62', SOURCE),
      ('b7324639bade3312981d1cbf9c2491b9fcff04fb6c3f808e9c5e1a7c2ca88f08', IMAGE),
      ('integer-tensor-544-fixed35-F32', 'mixed-integer-556-fixed35-F32-Saved'),
      ('tensor-integer-session', 'tensor-mixed-autograd-session'),
      ('heptatorch.integer544-remote-original-tests.v1', 'heptatorch.mixed556-remote-original-tests.v1'),
      ('profile/tests/integer_frozen35_accounting', 'profile/tests/mixed_frozen35_accounting'),
      ('owner_accounting_int64.py', 'owner_accounting_mixed.py'),
    ]
    receipt = []
    for before, after in edits:
        count = source.count(before)
        assert count > 0 and after not in source, before
        source = source.replace(before, after)
        receipt.append({'before': before, 'after': after, 'count': count})
    inverse = source
    for edit in reversed(receipt):
        assert inverse.count(edit['after']) == edit['count']
        inverse = inverse.replace(edit['after'], edit['before'])
    assert inverse.encode() == old
    ast.parse(source)
    runner = BASE/'remote_run.py'
    assert not runner.exists()
    runner.write_text(source); runner.chmod(0o600)
    emit(BASE/'remote-run-adaptation.json', {
      'schema': 'heptatorch.mixed556-remote-transport-adaptation.v1',
      'parent_sha256': sha(old), 'current_sha256': sha(source.encode()),
      'edits': receipt, 'inverse_exact': True,
      'original_oracles_modified': False, 'native_executed': False, 'Torch_executed': False})

    build = json.loads((COLD/'build.json').read_bytes())
    rebuild = json.loads((COLD/'profile-rebuild.json').read_bytes())
    assert build['source_sha256'] == SOURCE and build['native_sha256'] == IMAGE
    assert build['status'] == 'PASS' and build['link_exit'] == 0
    assert len(build['units']) == 11 and len({u['name'] for u in build['units']}) == 11
    assert rebuild['status'] == 'PASS' and rebuild['native_build_process_started'] is True
    assert rebuild['native_build_process_completed'] is True and rebuild['existing_mixed_image_reused'] is False
    assert rebuild['exit_code'] == 0 and rebuild['all_package_members_unchanged'] is True
    assert rebuild['actual_build_report_sha256'] == sha((COLD/'build.json').read_bytes())
    sources = {'remote_run.py': runner}
    for p in sorted(PROFILE.rglob('*')):
        if p.is_file():
            assert not p.is_symlink()
            sources['profile/'+p.relative_to(PROFILE).as_posix()] = p
    for name in ('runtime.hepta', 'tensor-mixed-autograd-session', 'build.json', 'profile-rebuild.json'):
        sources['native/'+name] = COLD/name
    for u in build['units']:
        assert u['compiler_exit'] == 0
        for suffix, field in (('.hepta', 'source_sha256'), ('.o', 'object_sha256')):
            p = COLD/(u['name']+suffix)
            assert entry(p)['sha256'] == u[field]
            sources['native/'+p.name] = p
    assert entry(COLD/'runtime.hepta')['sha256'] == SOURCE
    assert entry(COLD/'tensor-mixed-autograd-session')['sha256'] == IMAGE
    before = {rel: entry(path) for rel, path in sorted(sources.items())}
    manifest = {'schema': 'heptatorch.mixed556-remote-input-bundle.v1',
        'native_source_sha256': SOURCE, 'native_executable_sha256': IMAGE,
        'native_origin': 'exact separately cold-built bytes; no ROG compile claimed',
        'cold_build_directory': str(COLD), 'cold_rebuild_receipt_sha256': entry(COLD/'profile-rebuild.json')['sha256'],
        'files': [{'path': rel, **e} for rel, e in before.items()]}
    manifest_raw = (json.dumps(manifest, indent=2)+'\n').encode()
    (BASE/'bundle-manifest.json').write_bytes(manifest_raw)
    archive = BASE/'input-bundle.tar.xz'
    assert not archive.exists()
    with lzma.open(archive, 'wb', preset=1) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.USTAR_FORMAT) as tar:
            for rel, path in sorted(sources.items()):
                raw = path.read_bytes(); e = before[rel]
                assert len(raw) == e['bytes'] and sha(raw) == e['sha256']
                ti = tarfile.TarInfo(rel); ti.size = len(raw); ti.mode = e['mode']; ti.mtime = 0
                tar.addfile(ti, io.BytesIO(raw))
            ti = tarfile.TarInfo('bundle-manifest.json'); ti.size = len(manifest_raw); ti.mode = 0o600; ti.mtime = 0
            tar.addfile(ti, io.BytesIO(manifest_raw))
    archive_raw = archive.read_bytes()
    dec = lzma.LZMADecompressor(); plain = dec.decompress(archive_raw)
    assert dec.eof and not dec.unused_data
    with tarfile.open(fileobj=io.BytesIO(plain), mode='r:') as tar:
        members = tar.getmembers()
        assert len(members) == len(sources)+1 and len({m.name for m in members}) == len(members)
        assert {m.name for m in members} == set(sources)|{'bundle-manifest.json'}
        for m in members:
            assert m.isfile()
            raw = tar.extractfile(m).read()
            if m.name == 'bundle-manifest.json':
                assert raw == manifest_raw and m.mode == 0o600
            else:
                e = before[m.name]
                assert len(raw) == e['bytes'] and sha(raw) == e['sha256'] and m.mode == e['mode']
    assert {rel: entry(path) for rel, path in sorted(sources.items())} == before
    result = {'status': 'EXACT_REMOTE_INPUT_BUNDLE_VERIFIED', 'archive': entry(archive),
        'manifest': entry(BASE/'bundle-manifest.json'), 'member_count': len(members),
        'expanded_bytes': sum(m.size for m in members), 'expanded_tar_sha256': sha(plain),
        'runner': entry(runner), 'all_inputs_unchanged': True,
        'native_executed': False, 'Torch_executed': False}
    emit(BASE/'bundle-custody.json', result)
    print(json.dumps(result))

if __name__ == '__main__':
    main()
