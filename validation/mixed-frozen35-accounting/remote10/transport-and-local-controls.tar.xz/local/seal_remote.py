#!/usr/bin/env python3
"""Archive source-bound remote evidence without rewriting any original report."""
import argparse
import hashlib
import json
import lzma
from pathlib import Path
import stat
import sys
import tarfile


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1 << 20):
            h.update(chunk)
    return h.hexdigest()


def entry(root, path):
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode) and not path.is_symlink(), str(path)
    return {'path': str(path.relative_to(root)), 'bytes': s.st_size,
            'sha256': digest(path), 'mode': s.st_mode & 0o777}


def emit(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    root, output = a.root.resolve(), a.output.resolve()
    assert output.parent == root and not output.exists()
    output.mkdir()
    source = '5f8ab1f7ca1593dc21b8b6a3537e210cfbc42b37ddefcb322239c5a316d88c49'
    image = '69045063c00395d07fc6c0101ed1b8aba18376cb1daea54e0a01c2c5caeb49b6'
    assert digest(root/'bundle/native/runtime.hepta') == source
    assert digest(root/'bundle/native/tensor-mixed-autograd-session') == image
    children = {}
    for suite in ('live32', 'frozen35'):
        q = root/('run-'+suite+'-01')/'transport-report.json'
        raw = q.read_bytes()
        d = json.loads(raw)
        assert d['status'] in ('PASS', 'FAIL'), (suite, d['status'])
        assert d['native_source_sha256'] == source and d['native_executable_sha256'] == image
        children[suite] = {'status': d['status'], 'path': str(q.relative_to(root)),
                           'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    files = []
    for q in sorted(root.rglob('*')):
        if q == output or output in q.parents:
            continue
        assert not q.is_symlink(), str(q)
        if q.is_file():
            files.append(entry(root, q))
        else:
            assert q.is_dir(), str(q)
    assert files
    wanted = {e['path']: e for e in files}
    assert len(wanted) == len(files)
    manifest = {'schema': 'heptatorch.mixed556-remote-evidence-files.v1',
        'native_source_sha256': source, 'native_executable_sha256': image,
        'source_root': str(root), 'archive_member_paths_relative_to_source_root': True,
        'excluded_subtree': str(output.relative_to(root)),
        'exclusion_reason': 'Only the new self-referential archive/manifest/receipt output subtree is excluded.',
        'file_count': len(files), 'expanded_bytes': sum(e['bytes'] for e in files),
        'files': files, 'original_report_bytes_and_absolute_paths_not_rewritten': True,
        'suite_statuses_are_copied_from_original_transport_reports': children,
        'native_rebuilt_by_archiver': False, 'new_native_or_Torch_execution_by_archiver': False}
    emit(output/'evidence-manifest.json', manifest)
    archive = output/'raw-evidence.tar.xz'
    with tarfile.open(archive, 'w:xz', preset=3) as tf:
        for e in files:
            q = root/e['path']
            assert entry(root, q) == e, ('changed-before-archive', e['path'])
            info = tf.gettarinfo(str(q), arcname=e['path'])
            assert info.isfile() and info.size == e['bytes'] and stat.S_IMODE(info.mode) == e['mode']
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            with q.open('rb') as f:
                tf.addfile(info, f)
    tar_hash = hashlib.sha256()
    tar_size = 0
    decoder = lzma.LZMADecompressor()
    with archive.open('rb') as stream:
        while not decoder.eof:
            incoming = stream.read(65536) if decoder.needs_input else b''
            assert incoming or not decoder.needs_input, 'truncated XZ'
            chunk = decoder.decompress(incoming, max_length=1 << 20)
            tar_hash.update(chunk)
            tar_size += len(chunk)
        assert not decoder.unused_data and stream.read(1) == b'', 'trailing XZ bytes'
    verified = set()
    with tarfile.open(archive, 'r|xz') as tf:
        for member in tf:
            assert member.isfile() and member.name in wanted and member.name not in verified
            path = Path(member.name)
            assert not path.is_absolute() and '..' not in path.parts and str(path) == member.name
            e = wanted[member.name]
            assert member.size == e['bytes'] and member.mode == e['mode']
            h = hashlib.sha256()
            count = 0
            with tf.extractfile(member) as f:
                while chunk := f.read(1 << 20):
                    h.update(chunk)
                    count += len(chunk)
            assert count == e['bytes'] and h.hexdigest() == e['sha256']
            verified.add(member.name)
    assert verified == set(wanted)
    assert all(entry(root, root/e['path']) == e for e in files)
    receipt = {'schema': 'heptatorch.mixed556-remote-evidence-custody.v1',
        'status': 'COMPLETE_RAW_CUSTODY',
        'semantic_suite_statuses': children,
        'custody_status_does_not_override_any_suite_failure': True,
        'archive': {'path': str(archive), 'bytes': archive.stat().st_size,
                    'sha256': digest(archive), 'mode': archive.stat().st_mode & 0o777},
        'manifest': {'path': str(output/'evidence-manifest.json'),
                     'bytes': (output/'evidence-manifest.json').stat().st_size,
                     'sha256': digest(output/'evidence-manifest.json')},
        'member_count': len(files), 'expanded_bytes': manifest['expanded_bytes'],
        'uncompressed_tar_sha256': tar_hash.hexdigest(), 'uncompressed_tar_bytes': tar_size,
        'single_XZ_EOF_no_trailing_stream': True,
        'exact_tar_member_set_sizes_SHA256_modes_verified': True,
        'all_original_files_unchanged_before_after_archive': True,
        'original_files_removed': False, 'native_or_Torch_executed_by_archiver': False,
        'argv': sys.argv, 'python': sys.version,
        'whole_pytorch_gate': 'HOLD', 'pytorch_api_denominator': 2590,
        'full_pytorch_rewrite_complete': False}
    emit(output/'evidence-receipt.json', receipt)
    print(json.dumps({'status': receipt['status'], 'member_count': len(files),
                      'expanded_bytes': manifest['expanded_bytes'], 'archive': receipt['archive'],
                      'receipt_sha256': digest(output/'evidence-receipt.json')}))


if __name__ == '__main__':
    main()
