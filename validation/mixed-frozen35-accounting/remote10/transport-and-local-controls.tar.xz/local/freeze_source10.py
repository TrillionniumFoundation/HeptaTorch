#!/usr/bin/env python3
"""Freeze portable accounting source; native/Torch results stay separate."""
import hashlib
import json
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
OUT = Path('/workspace/scratch/d26699e25fea/mixed-frozen35-accounting-extension/source-handoff-10')

def sha(b):
    return hashlib.sha256(b).hexdigest()

def copy(source, destination):
    assert source.is_file() and not source.is_symlink()
    raw, mode = source.read_bytes(), source.stat().st_mode & 511
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists()
    shutil.copyfile(source, destination); destination.chmod(mode)
    assert destination.read_bytes() == raw and destination.stat().st_mode & 511 == mode

def main():
    OUT.mkdir(parents=True, exist_ok=False)
    for p in sorted((BASE/'profile-10-first/tests').rglob('*')):
        if p.is_file():
            copy(p, OUT/'tests'/p.relative_to(BASE/'profile-10-first/tests'))
    tests = OUT/'tests/mixed_frozen35_accounting'
    evidence = OUT/'validation/mixed-frozen35-accounting'
    copy(BASE/'build_profile10.py', tests/'build_profile.py')
    copy(BASE/'profile-10-first/source-adaptation.json', evidence/'source-adaptation.json')
    copy(Path('/workspace/scratch/d26699e25fea/mixed-integer-autograd-integration-review/fixed35-source10-review.json'), evidence/'root-source-review.json')
    copy(BASE.parent/'mixed-integer-autograd-extension/peer-full35-source-review10/receipt.json', evidence/'producer-source-review.json')
    copy(BASE/'test_profile_smoke10.py', evidence/'local-smoke-test.py')
    copy(BASE/'smoke10-first/report.json', evidence/'local-native9-report.json')
    copy(BASE/'smoke10-copied18-first/report.json', evidence/'local-copied18-report.json')
    readme = '''# Mixed10 original35 accounting source

This independent namespace targets source `5f8ab1f7ca1593dc21b8b6a3537e210cfbc42b37ddefcb322239c5a316d88c49` and ELF `69045063c00395d07fc6c0101ed1b8aba18376cb1daea54e0a01c2c5caeb49b6`: 556 core functions, 11 actual native compilation units, 640-byte descriptors, HTMXAD02 / HTOMXD02.

The full35 domain consists of the unchanged original F32 commands 1 through 56. Ordinary mul/div now keep original Tensor references in a real private 32-byte Hold at node584/592. Both Saved slots contribute separately to the exact node600 and node208 sums. Root reachability and reset closure traverse these real Tensor references. No unexplained allocation remainder is accepted. All full 80-word snapshots also pass the frozen general mixed10 checker. Dtype, history99/101, mask and I64 view roles outside this command domain are explicitly rejected by this profile.

The old 355/428/446/523/544 source profiles remain unchanged. The ten selected original pure definitions are bound to their exact legacy source. Snapshot has seven explicit modifications (one is width), and transition has one reset-closure modification; their inverses restore the complete original ASTs. Five adapted files have whole-byte inverse evidence in source-adaptation.json. The original35 numerical, metadata, Version, optimizer-state, EOF and post-close assertions remain in the unchanged original scripts.

## Exact entry points

Run from the repository root with the fixed native image and its actual source. Paths below are examples; the scripts resolve their sibling dependencies portably.

```sh
python tests/mixed_frozen35_accounting/run_frozen35_accounted.py \\
  --legacy-directory tests/tensor_object_oracle \\
  --native-source build/mixed-integer-autograd/runtime.hepta \\
  --observer-output build/frozen35-mixed-node/556 \\
  --observer-report build/pytorch-mixed-integer-frozen35.json -- \\
  build/mixed-integer-autograd/tensor-mixed-autograd-session \\
  build/pytorch-mixed-integer-frozen35-original.json \\
  --owned-reference tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \\
  --session-reference tests/pytorch_session_oracle.py \\
  --reference tests/pytorch_oracle.py \\
  --lock compatibility/pytorch-oracle-lock.json --repo . \\
  --trace-directory build/frozen35-mixed-node-wire/556 \\
  --expected-native-sha256 69045063c00395d07fc6c0101ed1b8aba18376cb1daea54e0a01c2c5caeb49b6

python tests/mixed_frozen35_accounting/check_frozen35_accounted.py \\
  --observer-report build/pytorch-mixed-integer-frozen35.json \\
  --original-report build/pytorch-mixed-integer-frozen35-original.json

python -I -S tests/mixed_frozen35_accounting/check_owner_snapshots.py \\
  --observer tests/mixed_frozen35_accounting/owner_accounting_mixed.py \\
  --expected-profile mixed-integer-556-fixed35-F32-Saved \\
  --journals build/frozen35-mixed-node/556/owners \\
  --output build/mixed-frozen35-copied18
```

The unmodified live32 runner remains a separate command. The original collector can mirror both original and outer report bytes and index the new journal and wire roots, independently of every older profile.

## Evidence boundaries

The included local reports are only a real 9-frame native smoke and the original 4 positive / 18 copied-negative control rules applied to its journal. The two source reviews executed no native program or Torch. They do not substitute for full35.

The original source-adaptation receipt is preserved as PREPARED_NOT_RUN. Separate ROG jobs later execute the original live32 and complete full35 on exact bytes from the independently recorded portable cold build. Their complete original reports, process identities, raw journals, wire logs and verified archive will be provided as a separate evidence packet; this source manifest makes no new execution claim. All 11 fixed Torch provenance checks and all original35 admission thresholds remain mandatory.

This component is not general mixed-I64 full35 coverage or complete PyTorch. The independent general owner controls are separately scoped. Overall status remains HOLD, 2590 API denominator, zero globally closed schemas, full=false.
'''
    (evidence/'README.md').write_text(readme)
    files = []
    for p in sorted(OUT.rglob('*')):
        if p.is_file():
            files.append({'path': p.relative_to(OUT).as_posix(), 'bytes': p.stat().st_size,
                          'sha256': sha(p.read_bytes()), 'mode': p.stat().st_mode & 511})
    manifest = {'schema': 'heptatorch.mixed556-fixed35-source-handoff.v1',
        'status': 'FROZEN_SOURCE_WITH_SEPARATE_EXECUTION_EVIDENCE',
        'profile': 'mixed-integer-556-fixed35-F32-Saved',
        'native_source_sha256': '5f8ab1f7ca1593dc21b8b6a3537e210cfbc42b37ddefcb322239c5a316d88c49',
        'native_sha256': '69045063c00395d07fc6c0101ed1b8aba18376cb1daea54e0a01c2c5caeb49b6',
        'parent_source_manifest_sha256': 'f9d8a75f906bae2b0003042fee2c072d9d5f62da75473cef7ca1bdf25fa5f651',
        'general_owner_package_manifest_sha256': '4c2ac36f0e96390f47ef29a2d7361de4747736037c006d6a9fc98d5b8d289040',
        'files': files, 'files_count': len(files), 'payload_bytes': sum(x['bytes'] for x in files),
        'new_execution_claimed_by_source_manifest': False,
        'source_adaptation_initial_status_preserved': 'PREPARED_NOT_RUN',
        'whole_pytorch_gate': 'HOLD', 'pytorch_api_denominator': 2590,
        'full_pytorch_rewrite_complete': False}
    p = evidence/'source-package-manifest.json'; p.write_text(json.dumps(manifest, indent=2)+'\n')
    for row in files:
        q = OUT/row['path']; assert len(q.read_bytes()) == row['bytes'] and sha(q.read_bytes()) == row['sha256'] and q.stat().st_mode & 511 == row['mode']
    print(json.dumps({'path': str(OUT), 'manifest_sha256': sha(p.read_bytes()), 'payload_files': len(files), 'payload_bytes': manifest['payload_bytes']}))

if __name__ == '__main__':
    main()
