import hashlib,json,lzma,tarfile,io,stat
from pathlib import Path,PurePosixPath
R=Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
O=R/'wrapped-f64-reference32-independent-01'
O.mkdir(exist_ok=False)
source=R/'wrapped-f64-reference32-original-packet-01'
raw=(source/'complete.tar.xz').read_bytes();mr=(source/'manifest.json').read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(raw)=='77e032dca727bd901471b95d15148e9936bf46da20c9141370e219eb4e2b273a'
assert sha(mr)=='9380a48145c632f8cabde4596d86de6968716211796ea1d42ca171c3f1e24a26'
m=json.loads(mr);d=lzma.LZMADecompressor();t=d.decompress(raw);assert d.eof and not d.unused_data
assert sha(t)==m['tar']['sha256'] and len(t)==m['tar']['bytes']
op=O/'original-packet';op.mkdir()
for n in ('complete.tar.xz','manifest.json'):
 p=source/n;q=op/n;q.write_bytes(p.read_bytes());q.chmod(stat.S_IMODE(p.stat().st_mode))
found=set()
with tarfile.open(fileobj=io.BytesIO(t),mode='r:') as tf:
 for x in tf:
  assert x.isfile() and not PurePosixPath(x.name).is_absolute() and '..' not in PurePosixPath(x.name).parts
  assert x.name not in found;found.add(x.name);b=tf.extractfile(x).read();e=m['files'][x.name]
  assert len(b)==e['bytes']==x.size and sha(b)==e['sha256'] and x.mode==e['mode']
  p=op/'payload'/x.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);p.chmod(x.mode)
assert found==set(m['files']) and len(found)==91
with tarfile.open(R/'r4-view-reshape-reference26-final-01/complete.tar.xz','r:xz') as tf:
 b=tf.extractfile('admit_actual26_r03.py').read()
assert sha(b)=='be8c14f2161dbae865a2e8fc0d79c5747a3065538f746ba850a1091d4d0429c3'
(O/'parent_admit_actual26_r03.py').write_bytes(b)
a=json.loads((op/'payload/reference/actual.json').read_bytes());e=json.loads((op/'payload/execution/execution.json').read_bytes())
r=a['rows'][0]
selected={'original_manifest':{k:v for k,v in m.items() if k not in ('files','bound_input_map')},
'source_manifest':json.loads((op/'payload/reference/source-manifest.json').read_bytes()),
'bound_input_map':m['bound_input_map'],
'files':{k:v for k,v in m['files'].items() if not k.startswith('bound-inputs/')},
'top_keys':list(a),'row_keys':list(r),'event_keys':[list(x) for x in r['events']],
'fn_before':r['events'][2]['after']['tensors']['output']['grad_fn'],'fn_after':r['final']['tensors']['output']['grad_fn'],
'provenance':a['oracle_provenance'],'environment':a['environment_before'],'execution_keys':list(e),
'first_state':list(a['full_rng_states'].items())[0],
'parent_methods_sha256':sha(b)}
(O/'inspection.json').write_text(json.dumps(selected,indent=2)+'\n')
print(json.dumps({'status':'PASS_ORIGINAL_RESTORED_FOR_PURE_ADMISSION','root':str(O),'members':91,'inspection':{'bytes':(O/'inspection.json').stat().st_size,'sha256':sha((O/'inspection.json').read_bytes())},'Torch_executed':False,'native_executed':False}))
