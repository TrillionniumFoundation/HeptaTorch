import hashlib,io,json,lzma,stat,tarfile
from pathlib import Path,PurePosixPath
R=Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
P=R/'wrapped-f64-reference32-independent-01';O=R/'wrapped-f64-reference32-final-01'
O.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def info(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode);b=p.read_bytes()
 return {'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(s.st_mode)},b
files={};data={}
def add(n,p):
 assert n not in files and not PurePosixPath(n).is_absolute() and '..'not in PurePosixPath(n).parts
 d,b=info(p);files[n]={**d,'original_path':str(p)};data[n]=b
names=['original-packet/complete.tar.xz','original-packet/manifest.json','parent_admit_actual26_r03.py',
       'admit_actual32.py','verify_packet.py','README.md','admission-01/report.json','admission-request-01.json',
       'admission-terminal-status.original.json','admission-terminal-read.original.json','admission-report-info.original.json','inspection.json']
for n in names:add(n,P/n)
for n in ('wrapped-f64-reference32-prepare-admission.py','wrapped-f64-reference32-prepare-admission.py.request.json'):
 add('preparation/'+n,R/n)
add('seal-script.py',Path(__file__));add('seal-request.json',Path(str(__file__)+'.request.json'))
assert files['admission-01/report.json']['sha256']=='767923408156d36d1f2247ce85b16f70f228bcf222a6f2068bf1b18c118f1e6d'
a=json.loads(data['admission-01/report.json'])
assert a['status']=='PASS_REFERENCE_ADMITTED' and a['checks_passed']==70859 and a['checks_failed']==0
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT)as tf:
 for n in sorted(files):
  x=tarfile.TarInfo(n);x.size=len(data[n]);x.mode=files[n]['mode'];x.mtime=0;tf.addfile(x,io.BytesIO(data[n]))
tar=buf.getvalue();raw=lzma.compress(tar,format=lzma.FORMAT_XZ,preset=6)
def write(n,v):
 p=O/n;p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n');p.chmod(0o600)
(O/'complete.tar.xz').write_bytes(raw);(O/'complete.tar.xz').chmod(0o600)
m={'schema':'heptatorch.wrapped-f64-reference32-final.v1','status':'PASS_REFERENCE_ADMITTED',
   'original_actual_job':'1a1e70727ca-392-3cb7','original_actual_sha256':'f3ecc9dd7db2ce8fbd0e424557ad5b95ac2e899a1c09cf38dad47e4fecc2b0c6',
   'pure_admission_job':'1a1e71b5aed-392-3cd7','pure_admission_sha256':files['admission-01/report.json']['sha256'],
   'checks_passed':70859,'cases':32,'operation_totals':a['operation_totals'],
   'file_count':len(files),'expanded_bytes':sum(v['bytes']for v in files.values()),'archive_bytes':len(raw),'archive_sha256':sha(raw),
   'tar_bytes':len(tar),'tar_sha256':sha(tar),'files':files,'nested_original_members':91,'nested_bound_inputs':25,
   'new_Torch_executions':0,'new_native_executions':0,'full_pytorch_rewrite_complete':False,'closed_schema_count':0}
write('manifest.json',m)
d=lzma.LZMADecompressor();t=d.decompress(raw);assert d.eof and not d.unused_data and t==tar
got=set()
with tarfile.open(fileobj=io.BytesIO(t),mode='r:')as tf:
 for x in tf:
  assert x.isfile() and x.name not in got;got.add(x.name);b=tf.extractfile(x).read();v=files[x.name]
  assert len(b)==x.size==v['bytes'] and sha(b)==v['sha256'] and x.mode==v['mode']
assert got==set(files)
for n,v in files.items():
 current,_=info(Path(v['original_path']));assert all(current[k]==v[k]for k in ('bytes','sha256','mode'))
write('verification.json',{'status':'PASS','file_count':len(files),'expanded_bytes':m['expanded_bytes'],
 'archive_sha256':sha(raw),'manifest_sha256':sha((O/'manifest.json').read_bytes()),
 'single_XZ_EOF':True,'all_bytes_modes_verified':True,'tar_sha256':sha(tar),
 'new_Torch_executions':0,'new_native_executions':0})
for n in ('verify_packet.py','README.md'):
 (O/n).write_bytes(data[n]);(O/n).chmod(files[n]['mode'])
write('outer.json',{'schema':'heptatorch.reference-final-outer.v1','files':{n:info(O/n)[0]for n in ('complete.tar.xz','manifest.json','verification.json','verify_packet.py','README.md')}})
print(json.dumps({'status':'PASS_FINAL_REFERENCE_PACKET_SEALED','directory':str(O),'members':len(files),'files':{n:info(O/n)[0]for n in ('complete.tar.xz','manifest.json','verification.json','outer.json','verify_packet.py','README.md')}}))
