"""Independently admit one immutable actual32 packet; no Torch, native, or RNE execution."""
import argparse
import ast
import collections
import email
import hashlib
import importlib.util
import io
import json
import lzma
from pathlib import Path, PurePosixPath
import stat
import tarfile
import traceback

PARENT_SHA='be8c14f2161dbae865a2e8fc0d79c5747a3065538f746ba850a1091d4d0429c3'
SOURCE_ROOT='/home/qian-qi/heptatorch-continuation-20261116/runs/wrapped-f64-reference32-01'
JOB='1a1e70727ca-392-3cb7'
KEY='heptatorch-d266-wrapped-f64-boundary32-actual-20261117-v1'
PINS={
 'original-packet/complete.tar.xz':'77e032dca727bd901471b95d15148e9936bf46da20c9141370e219eb4e2b273a',
 'original-packet/manifest.json':'9380a48145c632f8cabde4596d86de6968716211796ea1d42ca171c3f1e24a26',
 'original-packet/payload/reference/actual.json':'f3ecc9dd7db2ce8fbd0e424557ad5b95ac2e899a1c09cf38dad47e4fecc2b0c6',
 'original-packet/payload/execution/execution.json':'ffe9bb611f53958a842a44471710ab405874ea1693360fff86247c8935284401',
 'original-packet/payload/reference/source-manifest.json':'4a2ff093816267a2b20e4cbdbefa064346eec3ab462629d73d131c22ef4e537d',
 'original-packet/payload/reference/pytorch_wrapped_f64_probe.py':'c0ddafbae6ea81bd98f6066bc867f71e0b6e8d4f73e6c5d7f15f7fe3d29569a3',
 'original-packet/payload/reference/actual-execution-intent.json':'e7250e0c03de7993c610e7fd014e1e8076a88099f8d87e1c6dd7ee4ee84b24be',
 'original-packet/payload/reference/actual-request.json':'60260be643f53cfac46081f13af6c0bf87c762132524e0ad97e4c2126cb991f2',
 'original-packet/payload/reference/execute_actual_once.py':'72cceece2c7e4892b7aa9634b58b14ce8fbbdafa53594f480fc3733ffe19b536',
 'original-packet/payload/reference/root-source-review.json':'f3b79e27179881a0e5b2a2d7e7457b850cc4131440914971d1fbee9df61910ab',
 'parent_admit_actual26_r03.py':PARENT_SHA,
}
def sha(b): return hashlib.sha256(b).hexdigest()
parent_path=Path(__file__).with_name('parent_admit_actual26_r03.py')
assert sha(parent_path.read_bytes())==PARENT_SHA
spec=importlib.util.spec_from_file_location('frozen_original_reference_admission',parent_path)
parent=importlib.util.module_from_spec(spec);spec.loader.exec_module(parent)
jread=parent.jread

class Audit(parent.Audit):
    def __init__(self,root):
        super().__init__(root)
        self.saved_success=self.saved_released=self.warnings=0
        self.p=root/'original-packet/payload'
        self.ref=self.p/'reference'

    def custody(self):
        for n,pin in PINS.items():self.file(self.root/n,{'sha256':pin})
        m=jread(self.root/'original-packet/manifest.json')
        self.keys(m,('schema','status','original_actual_job','actual_sha256','execution_sha256',
          'file_count','expanded_bytes','archive','tar','bound_input_count','bound_input_map',
          'files','all_sources_unchanged','new_Torch_executions','native_executed'),'custody:manifest-schema')
        self.ck(m['status']=='PASS_ALL_ORIGINAL_BYTES_MODES_SINGLE_XZ' and m['original_actual_job']==JOB,'custody:original-job')
        raw=self.file(self.root/'original-packet/complete.tar.xz')
        self.ck(len(raw)==m['archive']['bytes']==2847488 and sha(raw)==m['archive']['sha256'],'custody:archive')
        d=lzma.LZMADecompressor(format=lzma.FORMAT_XZ);tar=d.decompress(raw)
        self.ck(d.eof and not d.unused_data,'custody:single-XZ-EOF')
        self.ck(len(tar)==m['tar']['bytes'] and sha(tar)==m['tar']['sha256'],'custody:complete-tar')
        got=set()
        with tarfile.open(fileobj=io.BytesIO(tar),mode='r:') as tf:
            for x in tf:
                self.ck(x.isfile() and not PurePosixPath(x.name).is_absolute() and '..' not in PurePosixPath(x.name).parts,'custody:safe-path')
                self.ck(x.name not in got and x.name in m['files'],'custody:unique-member')
                got.add(x.name);b=tf.extractfile(x).read();v=m['files'][x.name]
                self.ck(len(b)==x.size==v['bytes'] and sha(b)==v['sha256'] and x.mode==v['mode'],'custody:member-full-byte-mode')
                self.ck(self.file(self.p/x.name,v)==b,'custody:restored-exact-original')
        self.ck(got==set(m['files']) and len(got)==m['file_count']==91,'custody:complete-91')
        self.ck(sum(v['bytes']for v in m['files'].values())==m['expanded_bytes']==13867932,'custody:expanded-total')
        self.ck(m['all_sources_unchanged'] is True and m['new_Torch_executions']==0 and m['native_executed'] is False,'custody:byte-only-packet')
        self.manifest=m;self.mapping={k:v['archive_path'] for k,v in m['bound_input_map'].items()}
        self.e=e=jread(self.p/'execution/execution.json')
        before=jread(self.p/'execution/inputs-before.json');after=jread(self.p/'execution/inputs-after.json')
        self.ck(before==after==e['inputs_before']==e['inputs_after'],'custody:whole-before-after')
        self.ck(set(before)==set(self.mapping) and len(before)==m['bound_input_count']==e['input_file_count']==25,'custody:complete-25-inputs')
        for path,item in before.items():
            self.keys(item,('path','resolved','bytes','mode','sha256'),'custody:input-record')
            self.ck(item['path']==path and Path(item['resolved']).is_absolute(),'custody:absolute-original-path')
            mapped=m['bound_input_map'][path]
            self.ck(mapped=={**item,'archive_path':self.mapping[path]},'custody:exact-map-record')
            self.file(self.p/self.mapping[path],item)
        sm=jread(self.ref/'source-manifest.json')
        self.ck(sm['file_count']==len(sm['files'])==e['declared_inputs_count']==10,'custody:ten-declared-inputs')
        self.ck(sm['status']=='PREPARED_NOT_RUN' and sm['torch_executed'] is False and sm['native_executed'] is False,'custody:prepared-original-preserved')
        for v in sm['files']:
            path=SOURCE_ROOT+'/'+v['path']
            self.ck(path in before and all(before[path][k]==v[k] for k in ('bytes','mode','sha256')),'custody:declared-input-byte-mode')
        primary=[v for v in sm['files']if v['path'].startswith('upstream/')]
        self.ck(len(primary)==sm['primary_source_count']==e['primary_source_count']==2,'custody:two-full-primary-files')
        required={SOURCE_ROOT+'/'+v['path']for v in sm['files']}
        required|={SOURCE_ROOT+'/'+n for n in ('source-manifest.json','execute_actual_once.py','actual-request.json')}
        self.ck(required<=set(before),'custody:all-required-source-inputs')
        self.ck(e['status']=='PASS_ACTUAL_EXECUTED_AND_INPUTS_BOUND' and e['all_bound_inputs_unchanged'] is True,'execution:wrapper-status')
        for k in ('Torch_probe_started','Torch_probe_completed','stdout_closed','stderr_closed','actual_semantics_not_reclassified'):
            self.ck(e[k] is True,'execution:'+k)
        self.ck(e['probe_returncode']==0 and e['native_executed'] is False and e['wrapper_imports_Torch'] is False,'execution:one-actual-no-native')
        self.ck(e['started_at_unix_ns']<=e['probe_started_at_unix_ns']<e['probe_finished_at_unix_ns']<=e['finished_at_unix_ns'],'execution:chronology')
        for k,n in (('stdout','execution/probe.stdout'),('stderr','execution/probe.stderr'),('original_actual','reference/actual.json')):
            self.file(self.p/n,e[k])
        self.intent=intent=jread(self.ref/'actual-execution-intent.json')
        self.ck(e['original_intent']==intent and e['idempotency_key']==intent['idempotency_key']==KEY,'execution:intent')
        command=jread(self.p/'execution/actual-command.json')
        self.ck(command=={'executable':intent['executable'],'argv':[intent['executable']]+intent['args'],'cwd':intent['cwd'],'environment_inherited':True},'execution:exact-argv')
        request=jread(self.ref/'actual-request.json')
        self.ck(request['host']=='rog' and request['idempotency_key']==KEY and request['executable']==intent['executable'] and request['cwd']==intent['cwd'],'execution:original-request')
        self.ck(request['args']==['-B',SOURCE_ROOT+'/execute_actual_once.py'],'execution:wrapper-only-request')
        start=jread(self.ref/'actual-start.original.json');job=start['job']
        self.ck(job['id']==JOB and start['reused'] is False and job['idempotency_key']==KEY,'execution:unique-original-job')
        for k in ('host','executable','args','cwd','idempotency_key'):self.ck(job[k]==request[k],'execution:job-request:'+k)
        terminal=jread(self.ref/'actual-terminal-status.original.json')
        self.ck(terminal['job_id']==JOB and terminal['state']=='succeeded' and terminal['exit_code']==0,'execution:terminal-success')
        for k in ('output_complete','output_durable','terminal_publication_confirmed'):self.ck(terminal[k] is True,'execution:'+k)
        for k in ('automatic_retry','cancelled','timed_out'):self.ck(terminal[k] is False,'execution:'+k)
        logs=jread(self.ref/'actual-terminal-read.original.json')
        self.ck(logs['job_id']==JOB,'execution:log-job')
        for stream in ('stdout','stderr'):
            v=logs[stream];b=bytes.fromhex(v['bytes_hex'])
            self.ck(v['offset']==0 and v['eof'] is True and len(b)==v['size']==v['next_offset'],'execution:full-EOF:'+stream)
            self.ck(terminal['log_synced'][stream] is True and terminal['log_errors'][stream] is None and terminal['log_truncated'][stream] is False and terminal['log_bytes'][stream]=={'seen':len(b),'stored':len(b)},'execution:durable-no-truncation:'+stream)
        for n in ('actual-request-mac-info.original.json','actual-request-rog-info.original.json'):
            v=jread(self.ref/n);self.ck(v['sha256']==sha((self.ref/'actual-request.json').read_bytes()) and v['size']==len((self.ref/'actual-request.json').read_bytes()) and v['mode']==0o600,'execution:request-independent-readback')
        for n,target in (('actual-file-info.original.json','reference/actual.json'),('execution-file-info.original.json','execution/execution.json')):
            v=jread(self.ref/n);b=(self.p/target).read_bytes()
            self.ck(v['sha256']==sha(b) and v['size']==len(b) and v['mode']==0o600 and type(v['version'])is str,'execution:full-file-info:'+n)
        self.before=before

    def provenance(self):
        a=self.actual;lock=jread(self.ref/'inputs/pytorch-oracle-lock.json')
        expected=lock['oracle'];v=a['oracle_provenance'];o=v['observed'];env=self.e['environment_before']
        self.keys(v,('status','lock_path','lock_sha256','expected','observed','checks','metadata_error','release_source_equivalence'),'provenance:all-fields')
        self.ck(v['status']=='PASS' and v['metadata_error'] is None,'provenance:status')
        self.ck(v['expected']==expected and v['release_source_equivalence']==lock['release_source_equivalence'],'provenance:whole-lock')
        self.ck(v['lock_sha256']==sha((self.ref/'inputs/pytorch-oracle-lock.json').read_bytes()) and v['lock_path']==SOURCE_ROOT+'/inputs/pytorch-oracle-lock.json','provenance:lock-path-hash')
        self.ck(set(v['checks'])==parent.PROVENANCE_CHECKS and len(v['checks'])==11,'provenance:11-names')
        for k in parent.PROVENANCE_CHECKS:self.ck(v['checks'][k] is True,'provenance:'+k)
        self.keys(o,('python','platform','version','git_commit','backend_versions','distribution_version','direct_url','install_report'),'provenance:complete-observed-schema')
        self.ck(o['python']=={**expected['python'],'full_version':env['python']},'provenance:full-python')
        self.ck(o['platform']==expected['platform'] and env['platform']==o['platform']['sys_platform'] and env['machine']==o['platform']['machine'],'provenance:platform')
        self.ck(o['version']==o['distribution_version']==env['torch_distribution_version']==expected['version'],'provenance:all-installed-versions')
        self.ck(o['git_commit']==expected['git_commit'] and o['backend_versions']==expected['backend_versions'],'provenance:git-backends')
        self.ck(env['executable']==self.intent['executable'],'provenance:actual-interpreter')
        paths=[p for p in self.mapping if p.endswith('.dist-info/direct_url.json')]
        self.ck(len(paths)==1,'provenance:one-direct-url')
        direct=jread(self.p/self.mapping[paths[0]]);wheel=expected['wheel']
        canonical={'archive_info':{'hash':'sha256='+wheel['sha256'],'hashes':{'sha256':wheel['sha256']}},'url':wheel['url']}
        self.ck(o['direct_url']==env['direct_url']==direct==canonical,'provenance:all-direct-url-fields')
        pip_path=self.e['actual_pip_report']['path']
        self.ck(pip_path==self.intent['cwd']+'/'+expected['install_report'],'provenance:actual-pip-path')
        pip=jread(self.p/self.mapping[pip_path]);records=[x for x in pip['install']if x['metadata']['name']=='torch']
        self.ck(len(records)==1,'provenance:one-torch-install')
        installed=records[0]
        self.ck(installed==env['installed_torch_record'] and installed['requested'] is True and installed['is_direct'] is True and installed['is_yanked'] is False,'provenance:full-pip-record')
        self.ck(installed['download_info']==canonical and installed['metadata']['version']==expected['version'],'provenance:exact-wheel-url-hash-version')
        want={'path':expected['install_report'],'pip_version':pip['pip_version'],'download_info':installed['download_info'],'metadata_name':installed['metadata']['name'],'metadata_version':installed['metadata']['version'],'requested':installed['requested']}
        self.ck(o['install_report']==want,'provenance:full-observed-pip')
        paths=[p for p in self.mapping if p.endswith('.dist-info/METADATA')]
        self.ck(len(paths)==1,'provenance:one-installed-metadata')
        b=(self.p/self.mapping[paths[0]]).read_bytes();parsed=email.message_from_bytes(b)
        self.ck(parsed['Name']==expected['distribution'] and parsed['Version']==expected['version'] and sha(b)==wheel['metadata_sha256'],'provenance:installed-metadata-full-bytes')
        self.ck(self.e['full_observed_provenance_matches_prebound_files'] is True and self.e['all_11_provenance_true'] is True,'provenance:wrapper-flags')
        expected_env={'deterministic_algorithms':True,'deterministic_fill':True,'grad_enabled':True,'num_threads':1,'cpu_capability':'AVX512','default_dtype':'torch.float32'}
        self.ck(a['environment_before']==a['environment_after']==expected_env,'environment:full-before-after')
        for k in ('environment_unchanged','outer_rng_restored','source_files_unchanged'):self.ck(a[k] is True,'environment:'+k)

    def raw_tensor(self,x,label):
        if x is not None:self.ck(x['dtype'] in ('torch.float32','torch.float64'),label+':finite-dtype-scope')
        return super().raw_tensor(x,label)

    def scalar(self,x,spec,label):
        self.keys(x,('little_endian_hex','binary64_hex','python_type'),label+':keys')
        self.ck(x=={'little_endian_hex':spec['scalar_little_endian_hex'],'binary64_hex':spec['scalar_binary64_hex'],'python_type':'float'},label+':actual-Python-roundtrip-original-u64')

    def snapshot(self,x,label):
        self.snapshot_count+=1
        self.keys(x,('tensor_getter_order','tensors','state'),label+':schema')
        names=x['tensor_getter_order']
        self.ck(type(names)is list and len(names)==len(set(names)) and names in ([],['input'],['input','output'],['input','output','seed']),'observation:known-live-root-order')
        self.ck(list(x['tensors'])==names,label+':complete-getters')
        for name in names:
            t=x['tensors'][name];p=label+'/'+name
            self.keys(t,('raw','grad_fn','is_leaf','retains_grad','gradient'),p+':schema')
            self.raw_tensor(t['raw'],p+':raw')
            g=t['grad_fn'];self.capture(g,p+':grad-fn',('node','saved')if g['accepted']else())
            if g['accepted']:
                self.node(g['node'],p+':node')
                self.ck(type(g['saved'])is dict and list(g['saved'])==sorted(g['saved']),p+':sorted-Saved')
                self.ck(set(g['saved'])==({'_saved_other','_saved_self'}if name=='output' else set()),p+':complete-Saved-list')
                for k,event in g['saved'].items():
                    self.capture(event,p+':Saved-'+k,('value',)if event['accepted']else())
                    if event['accepted']:
                        self.primitive(event['value'],p+':Saved-'+k)
                        self.saved_success+=1
                    else:self.saved_released+=1
            for k,vkey in (('is_leaf','value'),('retains_grad','value'),('gradient','tensor')):
                z=t[k];self.capture(z,p+':'+k,(vkey,)if z['accepted']else())
                if z['accepted']:
                    if vkey=='tensor':self.raw_tensor(z['tensor'],p+':gradient')
                    else:self.boolean(z['value'],p+':'+k)
            for capture in (g,t['is_leaf'],t['retains_grad'],t['gradient']):self.warnings+=len(capture['warnings'])
        self.ck(x['state']in self.states,label+':full-RNG-reference');self.states_referenced[x['state']]+=1

    def event(self,x,label,spec):
        self.capture(x,label,('label','before','python_scalar','returned','after'))
        self.ck(x['accepted'] is True,label+':observed-operation-success')
        self.scalar(x['python_scalar'],spec,label+':scalar')
        self.snapshot(x['before'],label+':before');self.snapshot(x['after'],label+':after')
        self.primitive(x['returned'],label+':returned')

    def data(self):
        a=self.actual=jread(self.ref/'actual.json');self.provenance()
        self.keys(a,('schema','probe_sha256','primary_source_ref','case_plan','observer_origin_probe_sha256','native_executed','native_qualified','full_pytorch_rewrite_complete','pytorch_api_denominator','closed_schema_count','policy','scope','scalar_policy','getter_order','ownership_scope','saved_release_scope','inputs_sha256','status','torch_executed','cases','rows','probe_errors','operation_totals','oracle_provenance','environment_before','environment_after','environment_unchanged','outer_rng_restored','full_rng_states','source_files_unchanged','inputs_after_sha256'),'actual:complete-top-schema')
        self.ck(a['schema']=='heptatorch.wrapped-f64-multiply-reference32.v1' and a['status']=='OBSERVED','actual:original-observation-status')
        self.ck(a['native_executed'] is False and a['native_qualified'] is False and a['torch_executed'] is True,'actual:actual-only')
        self.ck(a['full_pytorch_rewrite_complete'] is False and a['closed_schema_count']==0 and a['pytorch_api_denominator']==2590,'actual:original-scope')
        self.ck(a['cases']==len(a['rows'])==32 and a['probe_errors']==[],'actual:32-complete')
        probe=(self.ref/'pytorch_wrapped_f64_probe.py').read_text();tree=ast.parse(probe)
        assignments={n.targets[0].id:n.value for n in tree.body if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
        scalars=ast.literal_eval(assignments['SCALARS']);iw=ast.literal_eval(assignments['INPUT_WORDS']);sw=ast.literal_eval(assignments['SEED_WORDS'])
        plan=[{'index':i,'name':name,'scalar_binary64_hex':word,'scalar_little_endian_hex':int(word,16).to_bytes(8,'little').hex(),'operation':'F32_tensor_times_Python_float','shape':[4],'input_binary32_hex':[f'{w:08x}'for w in iw],'seed_binary32_hex':[f'{w:08x}'for w in sw],'requires_grad':True,'retain_output_gradient':True,'retain_graph':False}for i,(name,word)in enumerate(scalars)]
        self.ck(a['case_plan']==plan==jread(self.ref/'case-plan.json'),'actual:full-input-only-plan')
        self.ck(a['probe_sha256']==sha(probe.encode()) and a['primary_source_ref']==ast.literal_eval(assignments['SOURCE_REF']) and a['observer_origin_probe_sha256']==ast.literal_eval(assignments['ORIGIN_PROBE_SHA']),'actual:fixed-source-identities')
        common=next(n.value for n in ast.walk(tree)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='common'for t in n.targets))
        for k,v in zip(common.keys,common.values):
            if isinstance(v,ast.Constant):self.ck(a[ast.literal_eval(k)]==ast.literal_eval(v),'actual:full-source-policy:'+ast.literal_eval(k))
        expected_inputs={SOURCE_ROOT+'/pytorch_wrapped_f64_probe.py':a['probe_sha256'],SOURCE_ROOT+'/inputs/pytorch_oracle.py':ast.literal_eval(assignments['SUPPORT_SHA']),SOURCE_ROOT+'/inputs/pytorch-oracle-lock.json':ast.literal_eval(assignments['LOCK_SHA'])}
        self.ck(a['inputs_sha256']==a['inputs_after_sha256']==expected_inputs,'actual:three-own-inputs-exact')
        origin=(self.ref/'source-origin/pytorch_view_reshape_probe.py').read_text();origin_tree=ast.parse(origin)
        for name in ('capture','raw_tensor','primitive','node_info','saved_attributes'):
            old=[n for n in ast.walk(origin_tree)if isinstance(n,ast.FunctionDef)and n.name==name]
            new=[n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name==name]
            self.ck(len(old)==len(new)==1,'observer:one-helper:'+name)
            self.ck(ast.get_source_segment(origin,old[0])==ast.get_source_segment(probe,new[0]) and ast.dump(old[0],include_attributes=False)==ast.dump(new[0],include_attributes=False),'observer:exact-five-original-helper-bodies:'+name)
        self.states=a['full_rng_states']
        self.ck(type(self.states)is dict and bool(self.states),'rng:nonempty-full-state-inventory')
        for key,v in self.states.items():
            self.keys(v,('bytes','hex'),'rng:state-schema');b=bytes.fromhex(v['hex'])
            self.ck(len(b)==v['bytes']==5056 and sha(b)==key,'rng:complete-5056')
        labels=['construct_input','input_requires_grad','multiply_python_float','retain_output_gradient','construct_seed','backward_default_release']
        totals=collections.Counter(attempted=0,succeeded=0,raised=0)
        for row,spec in zip(a['rows'],plan,strict=True):
            self.keys(row,set(spec)|{'state_before_setup','events','python_scalar_after_unpack','python_scalar_after_multiply','status','final','python_scalar_after_operations','state_after','state_after_explicit_roots_cleared'},'row:complete-schema')
            self.ck({k:row[k]for k in spec}==spec and row['status']=='OBSERVED','row:input-spec-status')
            self.ck([v['label']for v in row['events']]==labels,'trace:all-six-ordered-operations')
            for k in ('state_before_setup','state_after','state_after_explicit_roots_cleared'):
                self.ck(row[k]in self.states,'rng:row-full-state');self.states_referenced[row[k]]+=1
            for k in ('python_scalar_after_unpack','python_scalar_after_multiply','python_scalar_after_operations'):self.scalar(row[k],spec,'row:'+k)
            start_count=self.count
            for i,event in enumerate(row['events']):
                self.event(event,'case'+str(spec['index'])+'/event'+str(i),spec)
                totals['attempted']+=1;totals['succeeded'if event['accepted']else'raised']+=1
            self.snapshot(row['final'],'case'+str(spec['index'])+'/final')
            inp=row['events'][0]['returned']['tensor'];seed=row['events'][4]['returned']['tensor']
            self.ck(inp['binary_words']==list(iw) and seed['binary_words']==list(sw) and inp['shape']==seed['shape']==[4],'trace:literal-input-and-seed-bytes')
            mul=row['events'][2];first=mul['after']['tensors']['output'];saved=first['grad_fn']['saved']['_saved_other']['value']['tensor']
            self.ck(saved['dtype']=='torch.float64' and saved['shape']==[] and saved['storage_bytes']==8 and saved['version']==0 and saved['storage_raw_hex']==saved['logical_bytes_hex']==spec['scalar_little_endian_hex'],'trace:actual-original-eight-byte-Saved')
            self.ck(saved['binary_words']==[int(spec['scalar_binary64_hex'],16)],'trace:Saved-u64-never-F32-substituted')
            self.ck(first['grad_fn']['node']['kind']=='MulBackward0' and first['is_leaf']['value'] is False,'trace:real-Mul-edge')
            edges=first['grad_fn']['node']['next_edges']
            self.ck(len(edges)==2 and edges[0]['node']['kind']=='AccumulateGrad' and edges[0]['node']['variable']['tensor_identity']==inp['tensor_identity'] and edges[1]['node']is None,'trace:real-input-Accumulator-and-None-scalar-edge')
            final=row['final'];ig=final['tensors']['input']['gradient']['tensor'];og=final['tensors']['output']['gradient']['tensor']
            self.ck(ig is not None and og is not None and ig['version']==og['version']==0 and ig['requires_grad'] is False and og['requires_grad'] is False,'trace:actual-gradient-objects-V0')
            self.ck(og['binary_words']==list(sw) and og['shape']==seed['shape'],'trace:retained-output-gradient-raw-seed')
            self.ck(final['tensors']['output']['retains_grad']['value'] is True,'trace:retain-flag')
            released=final['tensors']['output']['grad_fn']['saved']['_saved_other']
            self.ck(released['accepted'] is False and released['error']['type']=='RuntimeError' and released['error']['message'],'trace:actual-default-Saved-release')
            for event in row['events']:
                for snap in (event['before'],event['after']):
                    if 'input'in snap['tensors']:
                        q=snap['tensors']['input']['raw']
                        self.ck(q['tensor_identity']==inp['tensor_identity'] and q['storage_identity']==inp['storage_identity'] and q['binary_words']==list(iw) and q['version']==0,'trace:unchanged-input-identity-bytes-Version')
                    if 'output'in snap['tensors']:
                        q=snap['tensors']['output']['raw']
                        self.ck(q['tensor_identity']==first['raw']['tensor_identity'] and q['storage_identity']==first['raw']['storage_identity'] and q['logical_bytes_hex']==first['raw']['logical_bytes_hex'] and q['version']==0,'trace:unchanged-output-identity-bytes-Version')
            self.rows.append({'index':spec['index'],'name':spec['name'],'original_status':row['status'],'events':6,'checks':self.count-start_count,
              'scalar_input_binary64_hex':spec['scalar_binary64_hex'],'Saved_other_observed':saved,'output_observed':first['raw'],
              'input_gradient_observed':ig,'retained_output_gradient_observed':og,'default_Saved_getter_error_observed':released['error'],
              'row_structure_sha256':sha(json.dumps(row,sort_keys=True,separators=(',',':')).encode())})
        self.ck(dict(totals)==a['operation_totals']==self.e['operation_totals']=={'attempted':192,'succeeded':192,'raised':0},'actual:all-operation-totals')
        self.ck(set(self.states_referenced)==set(self.states),'rng:exact-referenced-state-set')
        self.totals=dict(totals)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();root=args.root.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    audit=Audit(root)
    report={'schema':'heptatorch.independent-wrapped-f64-reference32-admission.v1','status':'FAIL','original_actual_job':JOB,
      'original_actual_sha256':PINS['original-packet/payload/reference/actual.json'],
      'Torch_executed':False,'native_executed':False,'compiler_executed':False,
      'original_actual_status_preserved':'OBSERVED','native_qualified':False,'full_pytorch_rewrite_complete':False,
      'closed_schema_count':0,'pytorch_api_denominator':2590,
      'numerical_scope':'Actual bytes only; no conversion or multiply expected result is synthesized.',
      'Saved_scope':'Original binary64 Tensor storage observed; no general F64 Tensor API qualification.',
      'primary_scope':'Two complete official sources bound by outer custody; probe itself loads support/lock/Torch only.'}
    try:
        audit.custody();audit.data()
        report.update(status='PASS_REFERENCE_ADMITTED',case_count=32,operation_totals=audit.totals,rows=audit.rows,
          complete_rng_state_count=len(audit.states),complete_rng_bytes=sum(v['bytes']for v in audit.states.values()),
          raw_tensor_observations=audit.raw_count,logical_bytes_verified=audit.logical_bytes,
          entire_storage_bytes_verified=audit.storage_bytes,snapshots_verified=audit.snapshot_count,
          Saved_getter_successes=audit.saved_success,Saved_getter_errors_preserved=audit.saved_released,
          warning_records_preserved=audit.warnings,all_25_original_bound_inputs_verified=True,all_11_full_provenance_verified=True)
    except BaseException as error:
        report.update(error=repr(error),failed_check=audit.failure,traceback=traceback.format_exc())
    report.update(checks_passed=audit.count if report['status']=='PASS_REFERENCE_ADMITTED'else max(0,audit.count-1),
      checks_failed=0 if report['status']=='PASS_REFERENCE_ADMITTED'else 1,categories=dict(sorted(audit.categories.items())),
      input_files=audit.inputs,reader_sha256=sha(Path(__file__).read_bytes()),parent_reader_sha256=PARENT_SHA)
    (out/'report.json').write_text(json.dumps(report,sort_keys=True,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:report.get(k)for k in ('status','case_count','checks_passed','checks_failed','failed_check')}))
    raise SystemExit(0 if report['status']=='PASS_REFERENCE_ADMITTED'else 1)
if __name__=='__main__':main()
