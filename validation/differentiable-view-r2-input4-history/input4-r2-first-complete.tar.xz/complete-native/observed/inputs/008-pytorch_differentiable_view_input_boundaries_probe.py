#!/usr/bin/env python3
"""Observe input-overlap normalization, input holes and differentiable sibling views.

Four new fixed CPU graph recipes. Original14 and multi-axis72 observations are
immutable. All values, errors, graph edges, identity and lifetime outcomes are
supplied only by the pinned Torch invocation. Seed words are inputs, never
expected output gradients.
"""
import argparse
import gc
import hashlib
import itertools
import json
from pathlib import Path
import runpy
import struct
import sys
import traceback
import warnings

SUPPORT_SHA = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK_SHA = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
SOURCE_REF = '31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457'
SOURCE_PINS = {
    'torch/csrc/autograd/FunctionsManual.cpp': 'a8603d6309822a3f93fa4fcb5ada05e2f0f7e29a1b96db64fe6f59ce0c730558',
    'torch/csrc/autograd/variable.cpp': 'ca2f1e573307069dee2fdff70ba81f161f48817cd278ad5464b9809cf23ab2c6',
}
PARENT_REFERENCE14_SHA = '2270d5ba925bcf91c56db94fac663695e69079c74edbf80aff8fa086e7c81665'
EXISTING_MULTI_AXIS72_SHA = '2512acdfeaf98f0aa8d8f44ce37dec48b926244ae274066e6e5b86e919a806e9'
CHECKS = {
    'python_matches', 'platform_matches', 'version_backend_matches',
    'git_matches_oracle_build_pin', 'distribution_version_matches',
    'direct_url_matches', 'direct_url_archive_sha256_matches',
    'pip_report_url_matches', 'pip_report_archive_sha256_matches',
    'pip_report_version_matches', 'pip_report_requested',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def plan():
    rows = [
        {'index': 0, 'name': 'zero_overlap_input_unique_output',
         'family': 'input_overlap', 'backing_recipe': 'flat3',
         'input_size': [2, 3], 'input_stride': [0, 1], 'input_storage_offset': 0,
         'view_size': [3], 'view_stride': [1], 'view_storage_offset': 0,
         'seed_phases': [
             {'name': 'finite', 'words': [0x3f800000, 0x33800000, 0xc0400000]},
             {'name': 'signed_zero_and_payloads', 'words': [0x80000000, 0x7fc12345, 0xffc23456]}]},
        {'index': 1, 'name': 'nonzero_overlap_input_unique_output',
         'family': 'input_overlap', 'backing_recipe': 'flat4',
         'input_size': [2, 3], 'input_stride': [1, 1], 'input_storage_offset': 0,
         'view_size': [4], 'view_stride': [1], 'view_storage_offset': 0,
         'seed_phases': [
             {'name': 'finite', 'words': [0x3f800000, 0x3f000000, 0x40000000, 0xbf800000]},
             {'name': 'signed_zero_and_payloads', 'words': [0x80000000, 0x7fc12345, 0xffc23456, 0]}]},
        {'index': 2, 'name': 'holes_input_storage_valid_outside_logical_footprint',
         'family': 'input_holes', 'backing_recipe': 'flat6',
         'input_size': [2, 2], 'input_stride': [3, 1], 'input_storage_offset': 0,
         'view_size': [2, 2], 'view_stride': [3, 1], 'view_storage_offset': 1,
         'seed_phases': [
             {'name': 'finite', 'words': [0x3f800000, 0x40000000, 0xc0400000, 0x3f000000]}]},
        {'index': 3, 'name': 'distinct_siblings_of_retained_intermediate_join',
         'family': 'sibling_fanout', 'backing_recipe': 'matrix',
         'middle_size': [3, 2], 'middle_stride': [1, 3], 'middle_storage_offset': 0,
         'left_size': [2, 2], 'left_stride': [3, 1], 'left_storage_offset': 0,
         'right_size': [2, 2], 'right_stride': [3, 1], 'right_storage_offset': 1,
         'root_operation': 'torch.mul(left, right)',
         'seed_phases': [
             {'name': 'first_finite', 'words': [0x3f800000, 0xc0000000, 0x40400000, 0xc0800000]},
             {'name': 'second_finite', 'words': [0x3f000000, 0xbe800000, 0x40000000, 0xbf800000]}]},
    ]
    assert len(rows) == 4 and len({row['name'] for row in rows}) == 4
    for row in rows:
        row['backward_schedule'] = [
            {'phase': phase['name'], 'retain_graph': i + 1 < len(row['seed_phases'])}
            for i, phase in enumerate(row['seed_phases'])]
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ('reference', 'lock', 'repo', 'output'):
        ap.add_argument('--' + name, type=Path, required=True)
    ap.add_argument('--prepare-only', action='store_true')
    args = ap.parse_args()
    assert Path.cwd().resolve() == args.repo.resolve()
    assert not args.output.exists()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    inputs = {p.resolve(): p.read_bytes() for p in (Path(__file__), args.reference, args.lock)}
    assert sha(inputs[args.reference.resolve()]) == SUPPORT_SHA
    assert sha(inputs[args.lock.resolve()]) == LOCK_SHA
    common = {
        'schema': 'heptatorch.differentiable-view-input-boundaries4.v1',
        'probe_sha256': sha(inputs[Path(__file__).resolve()]),
        'primary_source_ref': SOURCE_REF, 'primary_source_pins': SOURCE_PINS,
        'case_plan': plan(), 'native_executed': False, 'native_qualified': False,
        'full_pytorch_rewrite_complete': False, 'pytorch_api_denominator': 2590,
        'closed_schema_count': 0,
        'policy': 'OBSERVATION ONLY. Every output, gradient, error, identity, Version and lifetime is recorded from actual pinned Torch.',
        'scope': 'CPU float32, explicit nonnegative as_strided geometry, ordinary grad mode and first-order backward. No arbitrary Python wrapper reference-count equivalence or complete schema qualification is asserted.',
        'getter_order': 'For each live name: raw Tensor/Storage/layout/Version/requires/_base, then grad_fn, is_leaf, retains_grad, grad; Saved attributes and pairwise current gradient-edge relations follow in insertion order. These getters can refresh lazy ViewInfo history.',
        'ownership_scope': 'Only live holds named Tensor roots. Weak references hold StorageWeakRef only. All snapshots and captured events contain primitives/copies; function-local grad_fn, Saved and AccumulateGrad.variable wrappers are released before final weak checks.',
        'prior_reference14_sha256': PARENT_REFERENCE14_SHA,
        'existing_multi_axis72_sha256': EXISTING_MULTI_AXIS72_SHA,
        'seed_policy': 'Explicit raw input words. Final seeds are plain F32 clone tensors; no output gradient values are predicted.',
    }
    if args.prepare_only:
        report = {**common, 'status': 'PREPARED_NOT_RUN', 'torch_executed': False,
                  'cases': 0, 'rows': [], 'inputs_sha256': {str(p): sha(b) for p, b in inputs.items()}}
        args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
        print(json.dumps({'status': report['status'], 'planned_cases': len(plan()), 'probe_sha256': common['probe_sha256']}))
        return 0

    old_argv = sys.argv
    try:
        sys.argv = [str(args.reference), str(args.repo / 'reference-only-no-native-execution'),
                    str(args.output.with_suffix('.provenance.json')), str(args.lock)]
        context = runpy.run_path(str(args.reference), run_name='differentiable_view_input_boundaries_provenance_only')
    finally:
        sys.argv = old_argv
    torch, provenance = context['torch'], context['PROVENANCE']
    assert provenance['status'] == 'PASS' and set(provenance['checks']) == CHECKS
    assert all(value is True for value in provenance['checks'].values())
    assert torch.are_deterministic_algorithms_enabled()
    assert torch.utils.deterministic.fill_uninitialized_memory is True
    assert torch.get_num_threads() == 1
    assert torch.backends.cpu.get_cpu_capability() == 'AVX512'
    from torch.multiprocessing.reductions import StorageWeakRef
    states, rows, errors = {}, [], []

    def environment():
        return {'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
                'deterministic_fill': torch.utils.deterministic.fill_uninitialized_memory,
                'grad_enabled': torch.is_grad_enabled(), 'num_threads': torch.get_num_threads(),
                'cpu_capability': torch.backends.cpu.get_cpu_capability()}

    environment_before = environment()
    outer_rng = bytes(torch.get_rng_state().tolist())

    def rng():
        raw = bytes(torch.get_rng_state().tolist())
        assert len(raw) == 5056
        key = sha(raw)
        states.setdefault(key, {'bytes': len(raw), 'hex': raw.hex()})
        return key

    def capture(operation):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            try:
                value = operation()
                event = {'accepted': True, 'outcome': 'SUCCEEDED', 'error': None}
            except Exception as error:
                value = None
                event = {'accepted': False, 'outcome': 'RAISED',
                         'error': {'type': type(error).__name__, 'message': str(error)}}
        event['warnings'] = [{'type': type(w.message).__name__, 'message': str(w.message)} for w in caught]
        return value, event

    def raw_tensor(x):
        if x is None:
            return None
        storage = x.untyped_storage()
        raw = bytes(storage)
        width = x.element_size()
        shape, strides, offset = list(x.shape), list(x.stride()), x.storage_offset()
        logical = bytearray()
        for linear in range(x.numel()):
            quotient, at = linear, offset
            for size, stride in zip(reversed(shape), reversed(strides)):
                at += (quotient % size) * stride
                quotient //= size
            word = raw[at * width:at * width + width]
            assert len(word) == width
            logical.extend(word)
        base = x._base
        result = {'tensor_identity': str(x._cdata), 'storage_identity': str(storage._cdata),
                  'dtype': str(x.dtype), 'element_size': width, 'shape': shape, 'strides': strides,
                  'numel': x.numel(), 'storage_bytes': len(raw),
                  'storage_offset_elements': offset, 'storage_offset_bytes': offset * width,
                  'storage_raw_hex': raw.hex(), 'logical_bytes_hex': bytes(logical).hex(),
                  'binary_words': [int.from_bytes(logical[i:i + width], 'little') for i in range(0, len(logical), width)],
                  'version': x._version, 'requires_grad': x.requires_grad, 'is_view': x._is_view(),
                  'base_tensor_identity': None if base is None else str(base._cdata)}
        del base, storage
        return result

    def primitive(value):
        if isinstance(value, torch.Tensor):
            return {'tensor': raw_tensor(value)}
        if value is None or isinstance(value, (bool, int, str)):
            return value
        if isinstance(value, float):
            return {'double_bits': struct.unpack('<Q', struct.pack('<d', value))[0]}
        if isinstance(value, (tuple, list)):
            return [primitive(item) for item in value]
        return {'type': type(value).__name__, 'diagnostic_repr': repr(value)}

    def node_info(fn, depth=4):
        if fn is None:
            return None
        result = {'kind': type(fn).__name__}
        if type(fn).__name__ == 'AccumulateGrad':
            variable = fn.variable
            result['variable'] = raw_tensor(variable)
            del variable
        if depth:
            result['next_edges'] = [{'output_nr': int(nr), 'node': node_info(child, depth - 1)}
                                    for child, nr in fn.next_functions]
        return result

    def saved_attributes(fn):
        if fn is None:
            return {}
        attributes = {}
        for name in sorted(n for n in dir(fn) if n.startswith('_saved_')):
            value, event = capture(lambda name=name: getattr(fn, name))
            if event['accepted']:
                event['value'] = primitive(value)
            del value
            attributes[name] = event
        return attributes

    def tensor_observation(x, weak):
        before = raw_tensor(x)
        fn, getter = capture(lambda: x.grad_fn)
        if getter['accepted']:
            getter['node'] = node_info(fn)
        del fn
        leaf, leaf_event = capture(lambda: x.is_leaf)
        if leaf_event['accepted']:
            leaf_event['value'] = bool(leaf)
        del leaf
        retained, retained_event = capture(lambda: x.retains_grad)
        if retained_event['accepted']:
            retained_event['value'] = bool(retained)
        del retained
        grad, grad_event = capture(lambda: x.grad)
        if grad_event['accepted']:
            grad_event['tensor'] = raw_tensor(grad)
            if grad is not None:
                key = 'observed_grad_storage_' + str(grad.untyped_storage()._cdata)
                if key not in weak:
                    weak[key] = StorageWeakRef(grad.untyped_storage())
        del grad
        return {'before_grad_fn_getter': before, 'grad_fn_getter': getter,
                'requires_grad_after_grad_fn_getter': x.requires_grad,
                'is_leaf_after_grad_fn_getter': leaf_event, 'retains_grad': retained_event,
                'gradient': grad_event}

    def snapshot(live, weak):
        names = list(live)
        tensors = {name: tensor_observation(live[name], weak) for name in names}
        relations = {}
        for left_name, right_name in itertools.combinations(names, 2):
            left, right = live[left_name], live[right_name]
            relations[left_name + '|' + right_name] = {
                'same_Python_object': left is right, 'same_Tensor': left._cdata == right._cdata,
                'same_Storage': left.untyped_storage()._cdata == right.untyped_storage()._cdata,
                'same_current_Version_value': left._version == right._version}
        if len(names) > 1:
            del left, right
        current, getters, saved, edges = {}, {}, {}, {}
        for name in names:
            fn, event = capture(lambda name=name: live[name].grad_fn)
            getters[name] = event
            if event['accepted']:
                current[name] = fn
            del fn
        for name, fn in current.items():
            saved[name] = saved_attributes(fn)
            edge_rows = []
            if fn is not None:
                for child, nr in fn.next_functions:
                    edge_rows.append({'output_nr': int(nr), 'node': node_info(child),
                                      'matches_live_current_grad_fn': [other for other, candidate in current.items()
                                                                     if child is not None and child is candidate]})
                    del child
            edges[name] = edge_rows
        # No Function or Tensor wrapper is returned or added to a persistent cache.
        if current:
            del fn
        current.clear()
        return {'tensor_getter_order': names, 'tensors': tensors, 'relations': relations,
                'saved_getters_after_tensor_getters': saved, 'edge_getters': getters,
                'edges_after_all_tensor_getters': edges,
                'expired': {name: ref.expired() for name, ref in weak.items()}, 'state': rng()}

    def make_backing(kind):
        if kind == 'matrix':
            return torch.tensor([[1., 2., 3.], [4., 5., 6.]], dtype=torch.float32)
        if kind.startswith('flat'):
            return torch.tensor([float(i + 1) for i in range(int(kind[4:]))], dtype=torch.float32)
        raise AssertionError(kind)

    def make_seed(shape, words):
        count = 1
        for size in shape:
            count *= size
        assert count == len(words)
        signed = [word if word < 0x80000000 else word - 0x100000000 for word in words]
        # Intermediate int32 and dtype-view wrappers are temporary seed construction
        # only. The observed published seed is an ordinary nonview F32 clone.
        result = torch.tensor(signed, dtype=torch.int32).view(torch.float32).reshape(tuple(shape)).clone(
            memory_format=torch.contiguous_format)
        assert raw_tensor(result)['binary_words'] == words
        assert not result._is_view() and result._base is None
        return result

    def observe(spec):
        torch.manual_seed(1729)
        live, weak, events = {}, {}, []
        row = {**spec, 'state_before_setup': rng(), 'events': events}

        def event(label, operation, publish=None):
            before = snapshot(live, weak)
            value, result = capture(operation)
            result.update(label=label, before=before)
            if result['accepted']:
                result['returned'] = primitive(value)
                if isinstance(value, torch.Tensor):
                    result['returned_is_existing'] = {name: value is item for name, item in live.items()}
                if publish is not None:
                    assert isinstance(value, torch.Tensor), (label, type(value).__name__)
                    live[publish] = value
                    weak[publish + '_storage'] = StorageWeakRef(value.untyped_storage())
            del value
            result['after'] = snapshot(live, weak)
            events.append(result)
            return result['accepted']

        def drop(name):
            del live[name]
            gc.collect()

        def clear_grad(name):
            live[name].grad = None

        def new_view(source, target, size, stride, offset):
            return event('as_strided_' + target,
                         lambda: torch.as_strided(live[source], tuple(size), tuple(stride), offset), publish=target)

        def retain(name):
            return event('retain_grad_' + name, lambda: live[name].retain_grad())

        def finish():
            row['before_final_drops'] = snapshot(live, weak)
            for name in list(live):
                event('final_drop_' + name, lambda name=name: drop(name))
            assert not live
            gc.collect()
            row.update(status='OBSERVED', final_expired={name: ref.expired() for name, ref in weak.items()},
                       state_after=rng())
            return row

        if not event('construct_backing', lambda: make_backing(spec['backing_recipe']), publish='backing'):
            row['remaining_not_attempted'] = 'backing constructor raised'
            return finish()
        if spec['family'] == 'sibling_fanout':
            if not event('backing_requires_grad_true', lambda: live['backing'].requires_grad_(True)):
                row['remaining_not_attempted'] = 'backing requires request raised'
                return finish()
            for source, target in (('backing', 'middle'), ('middle', 'left'), ('middle', 'right')):
                if not new_view(source, target, spec[target + '_size'],
                                spec[target + '_stride'], spec[target + '_storage_offset']):
                    row['remaining_not_attempted'] = 'sibling graph view constructor raised'
                    return finish()
                retain(target)
            if not event('mul_distinct_sibling_views', lambda: torch.mul(live['left'], live['right']), publish='root'):
                row['remaining_not_attempted'] = 'sibling multiplication raised'
                return finish()
            root_name, gradient_names = 'root', ('backing', 'middle', 'left', 'right')
        else:
            if not event('construct_detached_strided_input',
                         lambda: torch.as_strided(live['backing'], tuple(spec['input_size']),
                                                  tuple(spec['input_stride']),
                                                  spec['input_storage_offset']).detach(), publish='input'):
                row['remaining_not_attempted'] = 'detached input constructor raised'
                return finish()
            if not event('input_requires_grad_true', lambda: live['input'].requires_grad_(True)):
                row['remaining_not_attempted'] = 'input requires request raised'
                return finish()
            if not new_view('input', 'view', spec['view_size'], spec['view_stride'], spec['view_storage_offset']):
                row['remaining_not_attempted'] = 'output view constructor raised'
                return finish()
            retain('view')
            root_name, gradient_names = 'view', ('input', 'view')

        for phase_index, phase in enumerate(spec['seed_phases']):
            if phase_index:
                for name in gradient_names:
                    event('clear_before_phase_' + str(phase_index) + '_' + name,
                          lambda name=name: clear_grad(name))
                event('drop_seed_before_phase_' + str(phase_index), lambda: drop('seed'))
            if not event('construct_seed_phase_' + str(phase_index),
                         lambda phase=phase: make_seed(live[root_name].shape, phase['words']), publish='seed'):
                row['remaining_not_attempted'] = 'explicit seed constructor raised'
                return finish()
            retained = phase_index + 1 < len(spec['seed_phases'])
            event('backward_phase_' + str(phase_index) + '_' + phase['name'],
                  lambda retained=retained: live[root_name].backward(live['seed'], retain_graph=retained))
            for name in gradient_names:
                if live[name].grad is not None:
                    event('hold_phase_' + str(phase_index) + '_' + name + '_gradient',
                          lambda name=name: live[name].grad,
                          publish='held_phase_' + str(phase_index) + '_' + name + '_grad')
        return finish()

    with torch.random.fork_rng(devices=[]):
        for spec in plan():
            try:
                rows.append(observe(spec))
            except BaseException as error:
                failure = {**spec, 'status': 'PROBE_ERROR', 'error': repr(error),
                           'traceback': traceback.format_exc()}
                errors.append(failure)
                rows.append(failure)
    environment_after = environment()
    assert environment_before == environment_after
    assert bytes(torch.get_rng_state().tolist()) == outer_rng
    assert all(path.read_bytes() == raw for path, raw in inputs.items())
    totals = {'attempted': 0, 'succeeded': 0, 'raised': 0}
    for row in rows:
        for event in row.get('events', []):
            totals['attempted'] += 1
            totals['succeeded' if event['accepted'] else 'raised'] += 1
    report = {**common, 'status': 'OBSERVED' if not errors else 'PROBE_ERROR', 'torch_executed': True,
              'oracle_provenance': provenance, 'build_configuration': torch.__config__.show(),
              'cpu_capability': torch.backends.cpu.get_cpu_capability(), 'num_threads': torch.get_num_threads(),
              'environment_before': environment_before, 'environment_after': environment_after,
              'environment_restored': True, 'original_outer_rng_restored': True,
              'source_files_unchanged': True, 'inputs_sha256': {str(p): sha(b) for p, b in inputs.items()},
              'cases': len(rows), 'rows': rows, 'states': states, 'unique_complete_states': len(states),
              'probe_errors': errors, 'probe_error_count': len(errors), 'operation_totals': totals}
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({key: report[key] for key in ('status', 'cases', 'probe_sha256', 'operation_totals', 'probe_error_count')}))
    return int(bool(errors))


if __name__ == '__main__':
    raise SystemExit(main())
