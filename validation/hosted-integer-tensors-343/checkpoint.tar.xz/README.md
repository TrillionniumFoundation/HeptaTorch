# PR33 independent hosted admission — source 343089

Both actual Native runs are admitted by the frozen r03 offline reader. The root independently repeated the complete push admission and obtained the identical 26,537,552-byte report. This review did not compile or execute HIA, start a native service, execute Torch, change production files, or change a Git ref.

## Exact source and executed jobs

Source head: `3430891413ae0eac1fdcc65eb6fcd202ad108331`.
Source tree: `a5a39214f69025502ba92e6b0fe3cfdb016c81c4`.
The sole source parent is `b9e74758e4a30389e278d0b7b034ecf53e8a550c`.
All 4,321 tracked source entries are bound to the exact Git tree; the 390 selected source files are preserved as original bytes.

| Actual component | Run | Job | Actual successful steps | Independent result |
|---|---:|---:|---:|---|
| Native PR | 43909954525 | 133448845058 | 96 | 217,481 checks; 0 failed |
| Native push | 43909769912 | 133448179659 | 96 | 217,482 checks; 0 failed |
| Quick 355 | 43909954487 | 133448844919 | 13 | Original 32/35, native 3 and copied 4+18 passed |
| Quick 428 | 43909954487 | 133448845035 | 13 | Original 32/35, native 3 and copied 4+18 passed |
| Quick 446 | 43909954487 | 133448844517 | 13 | Original 32/35, native 3 and copied 4+18 passed |

All nine officially returned checks for this source were completed/success. The executed PR/quick checkout was `0d3d68ca0adc8aa6e0d24a25002b4821b5c60b99`, with ordered parents `[a634b5ebd7e1756852c66ad510067283fe4d59a4, 3430891413ae0eac1fdcc65eb6fcd202ad108331]` and the same `a5a3…` tree. The separately observed prospective checkout `b0eccc9552ec1cae6dccbd8c026536159bec569c` has parents `[08170754bf242220d622ea2bca3c2c376b5f37d7, 343089…]` and the same tree. It is not substituted for the actually executed checkout.

## Actual evidence covered

Each Native run supplies seven original ZIPs. The review verifies the exact 77 original root reports and all 43 source-declared envelope obligations, including the previous 70 reports. It checks raw member sets, full SHA/size/mode custody, complete single-XZ streams, all source/runtime/compiler pins, real process receipts and complete input ledgers.

The new 544-function runtime is source `adf6cae67666273aa6fb77989080ca3b1e3632188d2d7956a6d8b71808787e62`, ELF `b7324639bade3312981d1cbf9c2491b9fcff04fb6c3f808e9c5e1a7c2ca88f08`. Its actual fresh coordinator executes four outer gates, including the ten-step producer, and verifies all 11 native units and 219 exact inputs. Each observed archive has 1,772 members; this count is read from, and matched against, the complete current archive rather than used as a substitute for member equality. All declared nested raw archives and the inherited twelve/ sixteen suites retain their original statuses and partial boundaries.

Both the 523 and 544 full-35 logs are independently recomputed through every one of their 6,344 original transitions, using the complete 80-word snapshots. Each retains 2,590,274 compared values, zero direct parameter-Version mismatches and the original 283 legacy state-Version differences. Full original EOF and post-close Version assertions, the original copied 18 rules, the tombstone native/copy controls, and complete 32-case live oracle provenance remain required. The new 544 full-35 observer is explicitly the F32-only fixed suite: its unrequested dtype/history tail is zero, and this gate does not claim general int64 role verification.

The retained 446 fresh execution, the 355/428/446 original main and quick gates, all old report obligations, the original distribution gaps, and historical raw gaps remain separately visible. None is reclassified by adding the new runtime.

## Final reports and the one-check count difference

| Report | SHA256 |
|---|---|
| PR sequential r03: `pr-admission-343-r03-sequential-02/report.json` | `2914eff0dc95ccb522564e571129a69a6c0740332d694ad42207b6cfe8d487b1` |
| Push r03: `push-admission-343-r03/report.json` | `9fa95d2cb38e97e3d6f6579b2fb4d8147882b7904b8609d2ac41a23365a6c5a1` |
| Root push independent repeat | Entire report bytes equal the push report above |

The check-count difference is caused by the unchanged 523 XZ loop's 1 MiB chunks. Its actual compressed archive is 4,189,036 bytes in PR and 4,211,232 bytes in push, producing four versus five `523 no concatenated XZ member` checks. Both complete EOF and tar-byte-digest assertions pass. `check-count-difference.json` and its source script document the exact cause; no assertion, result or original report is normalized to force equal counts.

## Retained failures and exact correction

The initial r02 admission remains a FAIL (`41b5ad94…`, admission false). It treated the complete `original-public-ten.cases` list as a fixed cross-profile scalar. The systematic 16-report examination found exactly 11 differing whole-owner digests and no other case-tree differences. The r03 correction preserves all ten cases, their full structure/types, 9 qualified + 1 partial scope, 1,036 actual wire frames, 5,975 exact comparisons and 7,689,264 executed rollback bytes. It binds the actual wire, statuses, EOF receipts, source hashes and the state equivalence relation. Six copied JSON/wire mutations were actually refused.

Those eleven whole-owner byte buffers were never archived by the original suite. Their before/after equality remains a **source-bound executed assertion**, not an offline recomputation of missing owner bytes. The original hashes remain untouched. `schema-correction-01/README.md`, the original diagnosis, `reader-full-r03/helper.diff` and the reversible proof describe this boundary precisely. The unchanged 6344-transition functions, copied-18 rules, numerical values, tolerances, provenance and old EOF/Version conditions remain pinned.

The first PR r03 process was terminated with exit 137 before writing a final report. Its empty streams, exact terminal output and `INTERRUPTED_NO_ADMISSION` receipt remain in `pr-admission-343-r03/`. No cause beyond the observed SIGKILL is claimed. The later PR execution used the same frozen reader in a new output directory after the push readers finished. It is the sequential PASS reported above.

## Reader and replay

Main reader SHA: `8c612cc4390c44adb4fc1c4f1f8d36484a6809d011babb9bb9f8baa9e8d5cea5`.
New helper SHA: `6ae2f53cfd97f39ca18924d7ccc606e86ccd218a84e714cff99d6f68aa6bc734`.
The previous retained and 523 evidence helpers remain byte-for-byte unchanged. Source-only reviews of the fresh coordinator and the narrow r03 correction are included separately; they are not counted as extra hosted/native runs.

Run each side sequentially into a new output directory:

```sh
python3 -B /dev/shm/heptatorch-d26699e25fea/pr33-hosted-review/reader-full-r03/review_pr33.py --bundle /dev/shm/heptatorch-d26699e25fea/pr33-hosted-review/source-343 --inputs /dev/shm/heptatorch-d26699e25fea/pr33-hosted-review/native-pr-inputs-343.json --output /dev/shm/heptatorch-d26699e25fea/pr33-independent-replay-pr
```

For push, use `native-push-inputs-343.json` and another new output directory. Original input specifications preserve their actual local and CI paths. On recovery elsewhere, create a separate local input mapping for checkpoint/source files and the 17 ZIPs; do not rewrite original reports or their CI-bound paths.

`original-zip-index-343.json` identifies all 17 original official ZIPs: 237,878,878 bytes total, exact artifact IDs/names, run/attempt, full SHA, sizes and original paths. The ZIP bodies remain external to the small checkpoint. The checkpoint includes source, complete reports, all reader revisions, the r02 failure, exit-137 interruption, official raw metadata, exact inverse proofs, source reviews and historical observer-failure inputs. It excludes signed download URLs.

**Whole-project decision remains HOLD: zero fully equivalent upstream schemas, 2,590-schema denominator and all 17 whole-project gates unresolved.** These scoped results do not add together into a full API-equivalence claim.
