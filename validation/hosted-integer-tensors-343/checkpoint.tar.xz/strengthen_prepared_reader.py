"""Add exact child-row/reference and nested legacy archive binding before admission."""
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path
P=Path(__file__).resolve().parent;OLD=P/'reader-full-r01';OUT=P/'reader-full-r02'
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(OLD/'integer_tensor_evidence.py').read_text()
assert sha(raw.encode())=='ac34239b96339e821b5315cb02d63d57969a31a78118ffcaae58878bd544c639'
changes=[(
"            if arc in files and arc not in expanded_archives and 'restoration_base' in receipt:\n                destination=PurePosixPath(receipt['restoration_base']).relative_to(root).as_posix()",
"            if 'restoration_base' in receipt:\n                audit.check('544 no omitted declared nested archive '+arc,arc in files and arc in metadata)\n            if arc not in expanded_archives and 'restoration_base' in receipt:\n                destination=PurePosixPath(receipt['restoration_base']).relative_to(root).as_posix()"
),(
"    audit.check('544 actual independent40 reference',children['independent-inplace40']['reference_sha256']==independent['reference_sha256'])",
"""    audit.check('544 actual independent40 reference',children['independent-inplace40']['reference_sha256']==independent['reference_sha256'])
    bodies={name.decode():body for body,name in re.findall(
        rb"^(fn ([A-Za-z_][A-Za-z_0-9]*)\\([^\\n]* entry\\([A-Za-z_][A-Za-z_0-9]*\\)\\n.*?^end\\n)",
        audit.integer_runtime_raw,re.M|re.S)}
    for name in (*ref_names,'independent-inplace40'):
        child=children[name];rows=child['rows']
        reference=base.decode(sources[independent['reference_path'] if name=='independent-inplace40'
            else 'validation/integer-tensors/reference/'+ref_names[name]])
        indices=child.get('reference_indices',list(range(child['cases'])))
        audit.check('544 complete exact actual reference row plan '+name,
            len(rows)==len(indices)==child['cases'] and [r['index'] for r in rows]==indices
            and [(r['index'],r['name']) for r in rows]==[(reference['rows'][i]['index'],reference['rows'][i]['name']) for i in indices]
            and all(r['status']=='PASS' and r['differences']==[] and 'error' not in r for r in rows))
        frame_key='frames' if 'frames' in child else 'native_frames'
        count_key='checks' if 'checks' in child else 'exact_checks'
        audit.check('544 exact original per-row sums '+name,
            sum(r[frame_key] for r in rows)==child[frame_key] and sum(r['checks'] for r in rows)==child[count_key])
        inputs=child['inputs_sha256'];audit.check('544 actual child input ledger nonempty '+name,bool(inputs))
        script,values=kwargs(next(r['command'] for r in producer['steps'] if r['name']==name))
        audit.check('544 actual child mandatory original input keys '+name,
            {script,values['--binary'],values['--source'],values['--reference'],values['--protocol']}<=set(inputs))
        for path,pin in inputs.items():
            p=PurePosixPath(path)
            if p.is_relative_to(root):wanted=metadata[p.relative_to(root).as_posix()]['sha256']
            else:wanted=tracked[p.relative_to(repo).as_posix()]['sha256']
            audit.check('544 every original child input bound '+name+'/'+path,pin==wanted)
        for fn,pin in child.get('physical_observer_bodies_sha256',{}).items():
            audit.check('544 physical observer exact actual HIA body '+name+'/'+fn,fn in bodies and sha(bodies[fn])==pin)
"""
),(
"        child=original(legacy_prefix+row['report'],row['report_sha256'],False)\n        status='QUALIFIED_EXPOSED_SCOPE' if name=='actual-retained12' else 'PASS'",
"""        child=original(legacy_prefix+row['report'],row['report_sha256'],False)
        arc=legacy_prefix+'evidence/'+row['archive']['archive'];receipt=original(legacy_prefix+'evidence/'+name+'.manifest.json',checked=False)
        audit.check('544 every original legacy archive fully expanded '+name,arc in expanded_archives
            and row['archive']=={k:v for k,v in receipt.items() if k not in ('members','verified_raw_expanded_copies_removed')})
        status='QUALIFIED_EXPOSED_SCOPE' if name=='actual-retained12' else 'PASS'"""
),(
"    inherited=original(legacy_prefix+'inherited16/report.json',checked=False)",
"""    retained12=original(legacy_prefix+'actual-retained12/report.json',checked=False)
    audit.check('544 retained12 complete actual reference and original11 provenance',
        retained12['inputs']['observations']=='ca8b5d3a7c679dcc5ad9a3d7b2bbd38f664c90e6474cf3e3c28496d5b716d1b3'
        and retained12['all_inputs_unchanged'] is True and len(retained12['reference_provenance_checks'])==11
        and all(v is True for v in retained12['reference_provenance_checks'].values()))
    inherited=original(legacy_prefix+'inherited16/report.json',checked=False)"""
)]
revised=raw
for before,after in changes:assert revised.count(before)==1;revised=revised.replace(before,after,1)
restored=revised
for before,after in reversed(changes):assert restored.count(after)==1;restored=restored.replace(after,before,1)
assert restored==raw
compile(revised,'integer_tensor_evidence.py','exec');OUT.mkdir();(OUT/'integer_tensor_evidence.py').write_text(revised)
main=(OLD/'review_pr33.py').read_text();before=sha(raw.encode());after=sha(revised.encode())
assert main.count(before)==1
(OUT/'review_pr33.py').write_text(main.replace(before,after,1))
for n in ('native_dropout_evidence.py','retained_evidence.py'):os.link(OLD/n,OUT/n)
oldfn={n.name:ast.get_source_segment(raw,n) for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)}
newfn={n.name:ast.get_source_segment(revised,n) for n in ast.parse(revised).body if isinstance(n,ast.FunctionDef)}
assert {n for n in oldfn if oldfn[n]!=newfn[n]}=={'review_native'}
proof={'schema':'heptatorch.pr33.pre-execution-evidence-strengthening.v1','status':'PREPARED_NOT_RUN',
    'original_helper_sha256':before,'new_helper_sha256':after,'reader_sha256':sha((OUT/'review_pr33.py').read_bytes()),
    'replacements':changes,'whole_source_inverse_exact':True,'only_changed_function':'review_native',
    'all_full6344_and_original_copied18_functions_byte_identical':True,'original_numerical_provenance_EOF_Version_gates_removed':False,
    'native_or_Torch_executed':False,'prior_prepared_r01_preserved':True}
(OUT/'strengthening-proof.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
(OUT/'helper.diff').write_text(''.join(difflib.unified_diff(raw.splitlines(True),revised.splitlines(True),fromfile='r01-prepared',tofile='r02-strengthened')))
print(json.dumps({k:v for k,v in proof.items() if k!='replacements'}))
