"""Original-byte transport only. Admission remains a separate strict reader."""
import argparse
import concurrent.futures
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import urllib.request
import zipfile

p=argparse.ArgumentParser()
p.add_argument('--private',type=Path,required=True)
p.add_argument('--role',choices=['pr','push'],required=True)
args=p.parse_args()
P=Path(__file__).resolve().parent
data=json.loads(args.private.read_text())
head='3430891413ae0eac1fdcc65eb6fcd202ad108331'
run={'pr':43909954525,'push':43909769912}[args.role]
prefixes={'native-reports':'native-reports','private-node-journals':'private-node-journals',
          'retained-gradient-native-evidence':'retained-evidence',
          'native-dropout-native-evidence':'native-dropout-evidence','dtype-node-journals':'dtype-node-journals',
          'integer-tensor-native-evidence':'integer-tensor-evidence','integer-node-journals':'integer-node-journals'}
assert len(data)==7
expected_names={prefix+'-'+str(run)+'-1-native' for prefix in prefixes}
assert {x['artifact']['name'] for x in data}==expected_names
out=P/'original-zips';out.mkdir(exist_ok=True)

def get(row):
    a=row['artifact']
    assert a['workflow_run']['head_sha']==head and a['workflow_run']['id']==run
    prefix=next(k for k in prefixes if a['name']==k+'-'+str(run)+'-1-native')
    dest=out/(prefixes[prefix]+'-'+args.role+'.zip');partial=dest.with_suffix('.partial')
    assert not dest.exists() and not partial.exists()
    result={'artifact_id':a['id'],'artifact_name':a['name'],'path':str(dest),'status':'FAIL'}
    try:
        h=hashlib.sha256();size=0
        with urllib.request.urlopen(row['url'],timeout=90) as response,partial.open('xb') as f:
            assert response.status==200
            for b in iter(lambda:response.read(1048576),b''):
                size+=len(b);assert size<=a['size_in_bytes'];h.update(b);f.write(b)
        assert size==a['size_in_bytes'] and a['digest']=='sha256:'+h.hexdigest()
        with zipfile.ZipFile(partial) as z:
            infos=z.infolist();names=[x.filename for x in infos]
            assert len(names)==len(set(names))
            for x in infos:
                n=PurePosixPath(x.filename)
                assert not n.is_absolute() and '..' not in n.parts and not stat.S_ISLNK(x.external_attr>>16)
            assert z.testzip() is None
        partial.rename(dest)
        result.update(status='ORIGINAL_BYTES_VERIFIED',bytes=size,sha256=h.hexdigest(),members=len(infos),
                      official_digest_verified=True,safe_member_paths=True,all_CRC_verified=True)
    except BaseException as error:
        result.update(exception_type=type(error).__name__,http_status=getattr(error,'code',None),partial_preserved=partial.exists())
    return result

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    rows=list(pool.map(get,data))
status='ORIGINAL_BYTES_VERIFIED' if all(x['status']=='ORIGINAL_BYTES_VERIFIED' for x in rows) else 'FAIL'
report={'schema':'heptatorch.pr33.native-original-download.v1','status':status,'role':args.role,
        'source_head':head,'run_id':run,'rows':rows,'original_bytes_rewritten':False}
raw=(json.dumps(report,indent=2,sort_keys=True)+'\n').encode()
(P/(args.role+'-download-custody.json')).write_bytes(raw)
print(json.dumps({'status':status,'files':len(rows),'bytes':sum(x.get('bytes',0) for x in rows),'sha256':hashlib.sha256(raw).hexdigest()}))
raise SystemExit(0 if status=='ORIGINAL_BYTES_VERIFIED' else 1)
