"""Freeze PR33 original source, actual admissions and all failed attempts.

Original official ZIPs stay external and are bound by an exact 17-file index.
The checkpoint contains no signed download URLs and starts no native/Torch work.
"""
import argparse
import hashlib
import io
import json
import lzma
from pathlib import Path
import stat
import tarfile

SHA=lambda b:hashlib.sha256(b).hexdigest()
HEAD='3430891413ae0eac1fdcc65eb6fcd202ad108331'
TREE='a5a39214f69025502ba92e6b0fe3cfdb016c81c4'
MAIN='8c612cc4390c44adb4fc1c4f1f8d36484a6809d011babb9bb9f8baa9e8d5cea5'
HELPER='6ae2f53cfd97f39ca18924d7ccc606e86ccd218a84e714cff99d6f68aa6bc734'

def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--work',type=Path,default=Path(__file__).resolve().parent)
    ap.add_argument('--pr',type=Path,required=True)
    ap.add_argument('--push',type=Path,required=True)
    ap.add_argument('--root-push',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args();p=a.work.resolve();a.output.mkdir(parents=True,exist_ok=False)
    assert digest(p/'reader-full-r03/review_pr33.py')==MAIN
    assert digest(p/'reader-full-r03/integer_tensor_evidence.py')==HELPER
    reports={};terminals={}
    for role,path in [('pr',a.pr),('push',a.push),('root_push',a.root_push)]:
        raw=path.read_bytes();d=json.loads(raw)
        assert d['status']=='PASS_SCOPED_HOSTED_ADMISSION' and d['admission_allowed'] is True
        assert d['source_head']==HEAD and d['expected_tree']==TREE and d['checks_failed']==0
        assert d['main_original_reports']==77 and d['required_envelopes']==43 and d['reviewer_sha256']==MAIN
        assert d['whole_project_decision']=='HOLD' and d['full_schema_parity']==0 and d['whole_pytorch_rewrite_complete'] is False
        assert d['integer_tensor_oracles']['pure_all35_transitions']['original_frames']==6344
        assert d['native_dropout_oracles']['pure_all35_transitions']['original_frames']==6344
        assert d['integer_tensor_evidence']['original_public_ten']['owner_bytes_archived_by_original_suite'] is False
        reports[role]={k:d[k] for k in ('native_run','native_attempt','native_job')}
        terminals[role]={'original_path':str(path.resolve()),'bytes':len(raw),'sha256':SHA(raw),
            'checks_passed':d['checks_passed'],'checks_failed':0,'native_run':d['native_run'],
            'native_attempt':d['native_attempt'],'native_job':d['native_job'],'status':d['status']}
    assert a.push.read_bytes()==a.root_push.read_bytes()
    failed=json.loads((p/'pr-admission-343-r02-first/report.json').read_bytes())
    assert failed['status']=='FAIL_ADMISSION_REVIEW' and failed['admission_allowed'] is False
    assert digest(p/'pr-admission-343-r02-first/report.json')=='41b5ad94512cacd51f7561d36d77e1b9f1f2422d8a3dbcf42704bb4f09540e33'
    interruption=json.loads((p/'pr-admission-343-r03/interruption-receipt.json').read_bytes())
    assert interruption['status']=='INTERRUPTED_NO_ADMISSION' and interruption['exit_code']==137
    assert interruption['final_report_exists'] is False and not (p/'pr-admission-343-r03/report.json').exists()
    index=json.loads((p/'original-zip-index-343.json').read_bytes())
    assert index['files_count']==len(index['files'])==17
    for row in index['files']:
        f=Path(row['path']);assert f.stat().st_size==row['bytes'] and digest(f)==row['sha256']
    assert sum(r['bytes'] for r in index['files'])==index['total_bytes']==237878878
    check_doc=json.loads((p/'official-final/checks.json').read_bytes());checks=check_doc['check_runs']
    assert check_doc['total_count']==len(checks)==9 and all(x['head_sha']==HEAD and x['status']=='completed' and x['conclusion']=='success' for x in checks)
    prospective=json.loads((p/'official-final/prospective-merge.json').read_bytes())
    pc=prospective.get('commit',prospective)
    assert prospective['sha']=='b0eccc9552ec1cae6dccbd8c026536159bec569c' and pc['tree']['sha']==TREE
    assert [x['sha'] for x in prospective['parents']]==['08170754bf242220d622ea2bca3c2c376b5f37d7',HEAD]
    for role,expected_run,expected_job in [('pr',43909954525,133448845058),('push',43909769912,133448179659)]:
        jobs=json.loads((p/('official-final/'+role+'-jobs.json')).read_bytes())['jobs']
        assert len(jobs)==1 and jobs[0]['id']==expected_job and len(jobs[0]['steps'])==96
        assert all(s['status']=='completed' and s['conclusion']=='success' for s in jobs[0]['steps'])
        assert reports[role]['native_run']==expected_run and reports[role]['native_job']==expected_job
    summary={'schema':'heptatorch.pr33.final-independent-hosted-checkpoint.v1','status':'PASS_SCOPED_HOSTED_ADMISSION',
        'source_head':HEAD,'source_tree':TREE,'source_parents':['b9e74758e4a30389e278d0b7b034ecf53e8a550c'],
        'executed_PR_checkout':'0d3d68ca0adc8aa6e0d24a25002b4821b5c60b99',
        'executed_PR_checkout_parents':['a634b5ebd7e1756852c66ad510067283fe4d59a4',HEAD],
        'prospective_checkout_is_not_substituted_for_executed_checkout':True,
        'separately_observed_prospective_checkout':{'sha':prospective['sha'],'tree':pc['tree']['sha'],
            'ordered_parents':[x['sha'] for x in prospective['parents']],'CI_execution_claimed_at_this_checkout':False},
        'reader_sha256':MAIN,'helper_sha256':HELPER,'terminal_admissions':terminals,
        'peer_and_root_push_entire_report_bytes_identical':True,
        'root_push_report_representation':'Exact duplicate of saved peer push report; both original paths and full SHA/size are retained here.',
        'official_checks':9,'official_native_actual_steps':{'pr':96,'push':96},'official_quick_actual_steps_per_profile':13,
        'reports_per_native_artifact':77,'envelopes_per_native_artifact':43,
        'new_native_cold_evidence':{'commands':4,'producer_steps':10,'units':11,'checked_inputs':219},
        'new_fixed35_domain':'544 F32-only 80-word owner observer; no general I64-role claim from this fixed35 gate.',
        'source_bound_rollback_without_raw_owner_bytes':'The 11 original public-ten owner equality assertions remain source-bound executed evidence; all 1036 actual wire frames are independently read.',
        'prior_schema_failure_preserved':True,'prior_137_interruption_preserved':True,
        'all_old_OPENs_partials_and_raw_gaps_preserved':True,
        'whole_project_decision':'HOLD','full_schema_parity':0,'schema_denominator':2590,'whole_pytorch_rewrite_complete':False,
        'original_ZIPs_external':{'files':17,'bytes':237878878,'index_sha256':digest(p/'original-zip-index-343.json')},
        'new_native_or_Torch_execution_by_reviewer':False,'original_report_bytes_rewritten':False}
    summary_bytes=(json.dumps(summary,indent=2,sort_keys=True)+'\n').encode()
    payload={}
    def add(name,path):
        path=path.resolve();assert path.is_file() and not path.is_symlink() and name not in payload
        payload[name]=path
    dirs=('source-343','official-first','official-final','reader-quick-r01','reader-full-r01','reader-full-r02','reader-full-r03',
          'prepare-full-r01','prepare-full-r02','source-domain-prepare-r01','quick-admission-343-01',
          'schema-correction-01','public-ten-copied-controls-r03','pr-admission-343-r02-first','pr-admission-343-r03',
          a.pr.parent.relative_to(p).as_posix(),a.push.parent.relative_to(p).as_posix())
    for name in dirs:
        for f in sorted((p/name).rglob('*')):
            if f.is_file():add(f.relative_to(p).as_posix(),f)
    for f in sorted(p.iterdir()):
        if f.is_file() and '-private.' not in f.name:
            add(f.name,f)
    source_review=Path('/dev/shm/heptatorch-d26699e25fea/integer-public-ten-reader-review-01/report.json')
    assert digest(source_review)=='3375737330e3174bce357ba13280bbc2ce886081a28de0fe4e518767990abdf4'
    add('independent-source-review/public-ten-r03.json',source_review)
    coordinator_review=Path('/dev/shm/heptatorch-d26699e25fea/integer-coordinator-source-review-01/report.json')
    assert digest(coordinator_review)=='164d043de8b441b48316ea11b9a709e289496eda048e643f05f9d8f7ab913fba'
    add('independent-source-review/fresh-coordinator.json',coordinator_review)
    history=json.loads((p/'native-pr-inputs-343.json').read_bytes())['history']
    hd=Path(history['directory'])
    for f in sorted(hd.rglob('*')):
        if f.is_file():add('historical-inputs/negative-control-alias-fix/'+f.relative_to(hd).as_posix(),f)
    add('historical-inputs/original-pr28-failure.zip',Path(history['native_first_failure_zip']))
    virtual={'FINAL.json':summary_bytes}
    files={}
    for name,f in sorted(payload.items()):
        assert not name.startswith('original-zips/') and 'private.json' not in name and '..' not in Path(name).parts
        s=f.stat();assert stat.S_ISREG(s.st_mode)
        files[name]={'sha256':digest(f),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode)}
    for name,raw in virtual.items():assert name not in files;files[name]={'sha256':SHA(raw),'bytes':len(raw),'mode':0o644}
    manifest={'schema':'heptatorch.pr33.final-checkpoint-members.v1','status':'FROZEN_SOURCE_AND_ORIGINAL_EVIDENCE',
        'source_head':HEAD,'source_tree':TREE,'files_count':len(files),'files':files,
        'ZIP_bodies_external_by_exact_index':True,'original_bytes_reserialized':False}
    manifest_bytes=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
    (a.output/'manifest.json').write_bytes(manifest_bytes)
    archive=a.output/'checkpoint.tar.xz'
    with tarfile.open(archive,'w:xz',format=tarfile.PAX_FORMAT) as stream:
        for name,row in sorted(files.items()):
            info=tarfile.TarInfo(name);info.size=row['bytes'];info.mode=row['mode'];info.mtime=0
            if name in virtual:stream.addfile(info,io.BytesIO(virtual[name]))
            else:
                with payload[name].open('rb') as raw:stream.addfile(info,raw)
        info=tarfile.TarInfo('manifest.json');info.size=len(manifest_bytes);info.mode=0o644;info.mtime=0
        stream.addfile(info,io.BytesIO(manifest_bytes))
    seen=set()
    with tarfile.open(archive,'r|xz') as stream:
        for member in stream:
            assert member.isfile() and member.name not in seen;seen.add(member.name)
            raw=stream.extractfile(member).read()
            if member.name=='manifest.json':assert raw==manifest_bytes and member.mode==0o644
            else:assert files[member.name]=={'sha256':SHA(raw),'bytes':len(raw),'mode':member.mode}
    assert seen==set(files)|{'manifest.json'}
    dec=lzma.LZMADecompressor();tar_digest=hashlib.sha256();total=0
    with archive.open('rb') as f:
        while not dec.eof:
            block=f.read(1048576) if dec.needs_input else b''
            assert block or not dec.needs_input
            raw=dec.decompress(block,max_length=1048576);tar_digest.update(raw);total+=len(raw)
        assert not dec.unused_data and f.read()==b''
    for name,f in payload.items():assert f.stat().st_size==files[name]['bytes'] and digest(f)==files[name]['sha256']
    (a.output/'FINAL.json').write_bytes(summary_bytes)
    receipt={'schema':'heptatorch.pr33.final-checkpoint-custody.v1','status':'VERIFIED',
        'archive_sha256':digest(archive),'archive_bytes':archive.stat().st_size,
        'manifest_sha256':SHA(manifest_bytes),'manifest_bytes':len(manifest_bytes),'payload_files':len(files),'tar_members':len(seen),
        'all_member_bytes_modes_sizes_verified':True,'single_XZ_complete_EOF_verified':True,
        'uncompressed_tar_bytes':total,'uncompressed_tar_sha256':tar_digest.hexdigest(),
        'all_inputs_unchanged':True,'final_sha256':SHA(summary_bytes),'source_head':HEAD,
        'archive_path':str(archive.resolve()),'external_original_ZIP_count':17,'external_original_ZIP_bytes':237878878}
    (a.output/'custody.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
