"""Bind original PR33 artifacts to their own recorded run and checkout."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--role',choices=['pr','push'],required=True);a=p.parse_args()
P=Path(__file__).resolve().parent;rawdir=P/'official-final'
old=json.loads(Path('/dev/shm/heptatorch-d26699e25fea/pr32-hosted-review/native-pr-inputs-b9.json').read_bytes())
quick=json.loads((P/'quick-inputs-343.json').read_bytes())
artifacts=json.loads((rawdir/(a.role+'-artifacts.json')).read_bytes())['artifacts']
run=json.loads((rawdir/(a.role+'-run.json')).read_bytes());jobs=json.loads((rawdir/(a.role+'-jobs.json')).read_bytes())['jobs']
assert len(jobs)==1 and run['conclusion']=='success' and run['head_sha']=='3430891413ae0eac1fdcc65eb6fcd202ad108331'
assert jobs[0]['conclusion']=='success' and len(jobs[0]['steps'])==96
names={'reports':('native-reports','native-reports'), 'journals':('private-node-journals','private-node-journals'),
       'retained_evidence':('retained-gradient-native-evidence','retained-evidence'),
       'native_dropout_evidence':('native-dropout-native-evidence','native-dropout-evidence'),
       'dtype_journals':('dtype-node-journals','dtype-node-journals'),
       'integer_tensor_evidence':('integer-tensor-native-evidence','integer-tensor-evidence'),
       'integer_journals':('integer-node-journals','integer-node-journals')}
native={'run':str(rawdir/(a.role+'-run.json')),'jobs':str(rawdir/(a.role+'-jobs.json')),'job_id':jobs[0]['id'],
        'checkout_commit':str(P/'official-first'/('merge.json' if a.role=='pr' else 'source.json'))}
for key,(prefix,filename) in names.items():
    name=f"{prefix}-{run['id']}-{run['run_attempt']}-native"
    rows=[x for x in artifacts if x['name']==name];assert len(rows)==1
    row=rows[0];path=P/'original-zips'/(filename+'-'+a.role+'.zip')
    assert path.is_file() and path.stat().st_size==row['size_in_bytes']
    with path.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
    assert row['digest']=='sha256:'+sha
    native[key]={'artifact_id':row['id'],'artifact_name':name,'bytes':row['size_in_bytes'],'sha256':sha,
                 'metadata':str(rawdir/(a.role+'-artifacts.json')),'zip':str(path)}
result=dict(quick,native=native,history=old['history'])
path=P/('native-'+a.role+'-inputs-343.json');path.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':'ORIGINAL_INPUTS_BOUND','role':a.role,'path':str(path),'source_head':result['source_head'],
                  'run':run['id'],'attempt':run['run_attempt'],'job':jobs[0]['id'],'artifacts':len(names)}))
