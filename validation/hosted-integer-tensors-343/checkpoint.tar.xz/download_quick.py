import concurrent.futures
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import urllib.request
import zipfile

P=Path(__file__).resolve().parent
rows=json.loads((P/'quick-download-private.json').read_text())
out=P/'original-zips'
out.mkdir(exist_ok=True)

def get(row):
    a=row['artifact'];profile=a['name'].split('-')[3]
    assert profile in ('355','428','446') and a['workflow_run']['head_sha']=='3430891413ae0eac1fdcc65eb6fcd202ad108331'
    path=out/('observer-'+profile+'.zip')
    partial=path.with_suffix('.partial')
    assert not path.exists() and not partial.exists()
    h=hashlib.sha256();size=0
    with urllib.request.urlopen(row['url'],timeout=60) as source,partial.open('xb') as f:
        assert source.status==200
        for b in iter(lambda:source.read(1048576),b''):
            size+=len(b);assert size<=a['size_in_bytes'];h.update(b);f.write(b)
    assert size==a['size_in_bytes'] and 'sha256:'+h.hexdigest()==a['digest']
    with zipfile.ZipFile(partial) as z:
        items=z.infolist();names=[x.filename for x in items]
        assert len(names)==len(set(names))
        for x in items:
            n=PurePosixPath(x.filename)
            assert not n.is_absolute() and '..' not in n.parts and not stat.S_ISLNK(x.external_attr>>16)
        assert z.testzip() is None
    partial.rename(path)
    return {'profile':profile,'artifact_id':a['id'],'artifact_name':a['name'],'path':str(path),
            'bytes':size,'sha256':h.hexdigest(),'zip_members':len(items),'safe_member_paths':True,
            'all_CRC_verified':True,'official_digest_verified':True}

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    result=list(pool.map(get,rows))
raw=(json.dumps({'schema':'heptatorch.pr33.quick-original-download.v1','status':'ORIGINAL_BYTES_VERIFIED',
                 'source_head':'3430891413ae0eac1fdcc65eb6fcd202ad108331','run_id':43909954487,
                 'rows':result,'original_bytes_rewritten':False},indent=2,sort_keys=True)+'\n').encode()
(P/'quick-download-custody.json').write_bytes(raw)
print(json.dumps({'files':len(result),'bytes':sum(x['bytes'] for x in result),'sha256':hashlib.sha256(raw).hexdigest()}))
