"""Freeze exact reuse of old hosted checks and add independent I64 evidence gates."""
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path

P=Path(__file__).resolve().parent
OLD=Path('/dev/shm/heptatorch-d26699e25fea/pr32-hosted-review/reader-b9-r01')
OUT=P/'reader-full-r01'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
dump=lambda path,value:path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
baseline=(OLD/'native_dropout_evidence.py').read_text()
assert sha(baseline.encode())=='1fc0cfc18323ee598f59832d447d88eba32d5007fa4545cbc708fefc04aefbc8'
tree=ast.parse(baseline)
functions={n.name:ast.get_source_segment(baseline,n) for n in tree.body if isinstance(n,ast.FunctionDef)}
core=(OUT/'integer_tensor_evidence.py').read_text()
assert 'def copied18(' not in core
changes=[('523','544'),('dtype_frozen35_accounting','integer_frozen35_accounting'),
    ('owner_accounting544.py','owner_accounting_int64.py'),
    ('owner640_storage_tombstone.py','owner640_fixed35.py'),
    ('independent_offline_fixed35_640','independent_offline_integer_fixed35_640'),
    ('f503df2d1dbce8242591e77211b96a7787201e991db8186c9f1cca6576244409',
     'd40fb59a74edfaf87113e7eac1e13587c7e8d33aa6ca1edea36a7e9da7bbde89'),
    ('pytorch-native-dropout','pytorch-integer-tensors'),
    ('native-dropout-storage-tombstone','integer-tensors-storage-tombstone'),
    ('dtype-node-journals','integer-node-journals')]
proof={}
parts=[]
for name in ('load_pure','copied18','tombstone','review_oracles','recheck_all_transitions'):
    original=functions[name];adapted=original;edits=[]
    for before,after in changes:
        count=adapted.count(before)
        if count:
            assert before!=after
            adapted=adapted.replace(before,after);edits.append({'before':before,'after':after,'count':count})
    restored=adapted
    for e in reversed(edits):
        assert restored.count(e['after'])==e['count'],(name,e)
        restored=restored.replace(e['after'],e['before'])
    assert restored==original
    if name=='review_oracles':adapted=adapted.replace('def review_oracles(', 'def inherited_review_oracles(',1)
    parts.append(adapted)
    proof[name]={'original_sha256':sha(original.encode()),'adapted_sha256':sha(adapted.encode()),
                 'edits':edits,'wrapper_name_binding_changed':name=='review_oracles',
                 'exact_inverse_original_function_bytes':True}
tail='''

def review_oracles(audit,base,spec,ctx,main_bytes,reports,sources,bundle,plan32,plan35):
    """Retain all old35 checks, then enforce the new profile's exact native body pins."""
    result=inherited_review_oracles(audit,base,spec,ctx,main_bytes,reports,sources,bundle,plan32,plan35)
    cfg=base.decode(sources['tests/integer_frozen35_accounting/profile.json'])
    raw=audit.integer_runtime_raw
    bodies={name.decode():body for body,name in re.findall(
        rb"^(fn ([A-Za-z_][A-Za-z_0-9]*)\\([^\\n]* entry\\([A-Za-z_][A-Za-z_0-9]*\\)\\n.*?^end\\n)",raw,re.M|re.S)}
    audit.check('544 entire cold HIA body count and source digest',sha(raw)==SOURCE and len(bodies)==544)
    for name,pin in cfg['function_pins'].items():
        audit.check('544 exact accounting HIA function '+name,name in bodies and sha(bodies[name])==pin)
    for target,expected in cfg['capture_callers'].items():
        callers=[name for name,body in bodies.items() if ('"function":"'+target+'"').encode() in body]
        audit.check('544 exact source caller coverage '+target,sorted(callers)==sorted(expected))
    wrapper=reports['pytorch-integer-tensors-frozen35.json']
    audit.check('544 actual complete function and caller profile',wrapper['profile']['function_pins']==cfg['function_pins']
        and wrapper['profile']['capture_callers']==cfg['capture_callers']
        and wrapper['profile']['accounting_domain']==cfg['fixed35_domain'])
    audit.check('544 additional actual adaptation source custody',
        wrapper['source_custody']['structural_profile_adaptation']['sha256']==sha(sources['tests/integer_frozen35_accounting/structural-profile-adaptation.json']))
    stone=reports['integer-tensors-storage-tombstone.json']
    audit.check('544 original6ea predicate profile binding is explicit copied-only metadata',stone['original_predicate_profile_binding']=={
        'source_sha256':SOURCE,'native_sha256':IMAGE,'profile':MODEL['name'],'function_code_changed':False,
        'purpose':'copied JSON predicate replay only; old native profile not relabelled'})
    result.update(fixed35_only_F32_domain=True,general_I64_role_verification_claimed=False,
        every_full80_word_node_has_zero_unrequested_dtype_history_roles=True,all_native_function_and_capture_pins_verified=True)
    return result
'''
helper=core+'\n\n'+'\n\n'.join(parts)+tail
compile(helper,'integer_tensor_evidence.py','exec')
(OUT/'integer_tensor_evidence.py').write_text(helper)
dump(OUT/'oracle-function-reuse.json',{'schema':'heptatorch.pr33.hosted-oracle-reuse.v1',
    'status':'PREPARED_NOT_RUN','baseline_helper_sha256':sha(baseline.encode()),'functions':proof,
    'new_helper_sha256':sha(helper.encode()),'all_original_transition_and_copied18_assertions_retained':True,
    'native_or_Torch_executed':False})
old=(P/'reader-quick-r01/review_pr33.py').read_text()
assert sha(old.encode())=='77534b5e19de029454c2d625e070278338f2c5cdf3ee93a504516ac9e4dbecea'
insert='''        integer_path=Path(__file__).with_name('integer_tensor_evidence.py')
        integer_raw=audit.read(integer_path)
        audit.check('exact independent source-bound544 evidence reader',sha(integer_raw)=='HELPER_PIN')
        integer=types.ModuleType('source_bound_integer_tensor_evidence_reader')
        integer.__file__=str(integer_path)
        exec(compile(integer_raw,integer.__file__,'exec'),integer.__dict__)
'''.replace('HELPER_PIN',sha(helper.encode()))
changes=[
    ("        sources,tracked=source_tree(audit,bundle)",insert+"        sources,tracked=source_tree(audit,bundle)"),
    ("        raise AssertionError('This prepared revision admits quick components only; full I64 evidence reader pending')\n",''),
    ("audit.check('all38 source-declared envelope obligations'","audit.check('all43 source-declared envelope obligations'"),
    ("        audit.check('70 exact original root reports; no missing or extra JSON',len(listed)==len(manifest['reports'])==70",
     "        audit.check('all old70 root report obligations retained',len(names)==70)\n"
     "        names.update({'hosted-integer-tensors-native.json','integer-tensors-ci-raw-manifest.json',\n"
     "                      'integer-tensors-storage-tombstone.json','pytorch-integer-tensors-backward.json',\n"
     "                      'pytorch-integer-tensors-frozen35.json','pytorch-integer-tensors-frozen35-original.json',\n"
     "                      'pytorch-integer-tensors-frozen35-observer-controls.json'})\n"
     "        audit.check('77 exact original root reports; no missing or extra JSON',len(listed)==len(manifest['reports'])==77"),
    ("        journals,jmetadata=audit.archive(spec['native']['journals'])",
     "        native544=integer.review_native(audit,base,spec['native']['integer_tensor_evidence'],ctx,members,reports,sources,tracked,native523)\n"
     "        oracles544=integer.review_oracles(audit,base,spec['native']['integer_journals'],ctx,members,reports,sources,bundle,plan32,plan35)\n"
     "        journals,jmetadata=audit.archive(spec['native']['journals'])"),
    ("retained_evidence=retained,native_dropout_evidence=native523,native_dropout_oracles=oracles523,",
     "retained_evidence=retained,native_dropout_evidence=native523,native_dropout_oracles=oracles523,\n"
     "                      integer_tensor_evidence=native544,integer_tensor_oracles=oracles544,"),
]
s=old
for a,b in changes:
    assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b,1)
restored=s
for a,b in reversed(changes):
    if not b:
        marker="        ctx=base.Audit.job(audit,spec['native'],workflow)";assert restored.count(marker)==1
        restored=restored.replace(marker,a+marker,1)
    else:assert restored.count(b)==1;restored=restored.replace(b,a,1)
assert restored==old
compile(s,'review_pr33.py','exec');(OUT/'review_pr33.py').write_text(s)
for name in ('retained_evidence.py','native_dropout_evidence.py'):os.link(OLD/name,OUT/name)
fns=lambda text:{n.name:ast.get_source_segment(text,n) for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert {n for n,v in fns(old).items() if fns(s)[n]!=v}=={'main'}
dump(OUT/'main-inverse.json',{'schema':'heptatorch.pr33.full-native-reader-additive-inverse.v1','status':'PREPARED_NOT_RUN',
    'original_quick_reader_sha256':sha(old.encode()),'new_reader_sha256':sha(s.encode()),'helper_sha256':sha(helper.encode()),
    'replacements':changes,'exact_inverse_original_bytes':True,'old_native_and_Torch_assertions_removed':False,
    'all_other_function_bodies_unchanged':True,'all38_previous_envelopes_and70_reports_retained':True,
    'new_envelope_obligations':5,'new_original_root_reports':7,'new_cold_gates':4,
    'extra_native_or_Torch_execution':False})
(OUT/'source.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='PR33-quick-r01',tofile='PR33-full-r01')))
print(json.dumps({'status':'PREPARED_NOT_RUN','reader_sha256':sha(s.encode()),'helper_sha256':sha(helper.encode())}))
