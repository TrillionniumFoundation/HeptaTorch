"""Authenticate the published PR33 tree; prepare the unchanged quick-only reader.

No compiler, native program or Torch is executed. Immutable selected source
members are hardlinked after byte verification to avoid duplicate RAM copies.
"""
import ast
import base64
import copy
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess

P=Path(__file__).resolve().parent
REPO=Path('/dev/shm/heptatorch-d26699e25fea/HeptaTorch-integer-tensors-integration-07')
OLD=Path('/dev/shm/heptatorch-d26699e25fea/pr32-hosted-review')
HEAD='3430891413ae0eac1fdcc65eb6fcd202ad108331'
TREE='a5a39214f69025502ba92e6b0fe3cfdb016c81c4'
BASE='a634b5ebd7e1756852c66ad510067283fe4d59a4'
PARENT='b9e74758e4a30389e278d0b7b034ecf53e8a550c'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
gitsha=lambda kind,raw:hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()

def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def dump(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

commit=json.loads((P/'official-first/source.json').read_bytes())
assert commit['sha']==HEAD and commit['tree']['sha']==TREE
assert [p['sha'] for p in commit['parents']]==[PARENT]
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert git('status','--porcelain')==b''
old_raw=(OLD/'source-b9/source-manifest.json').read_bytes()
assert sha(old_raw)=='3b33844322705b216e5776e148a8dd3280cab2f01edac21e2c43b06bf7b10409'
old=json.loads(old_raw)
rows=[]
for entry in git('ls-tree','-rtz','--full-tree',HEAD).split(b'\0'):
    if not entry:continue
    meta,name=entry.split(b'\t',1);mode,kind,oid=meta.decode().split()
    rows.append((name.decode(),mode,kind,oid))
tracked={};witness={}
for oid in {TREE}|{oid for _,_,kind,oid in rows if kind=='tree'}:
    raw=git('cat-file','tree',oid);assert gitsha('tree',raw)==oid
    witness[oid]=base64.b64encode(raw).decode()
for name,mode,kind,oid in rows:
    if kind=='tree':continue
    assert kind=='blob' and mode in ('100644','100755')
    path=REPO/name;assert path.is_file() and not path.is_symlink()
    raw=path.read_bytes();assert gitsha('blob',raw)==oid
    assert path.stat().st_mode&0o777==int(mode,8)&0o777
    tracked[name]={'git_blob':oid,'mode':mode,'bytes':len(raw),'sha256':sha(raw)}
assert len(tracked)==4321
changed={n for n,v in tracked.items() if old['all_tracked_file_digests'].get(n)!=v}
assert len(changed)==153 and set(old['all_tracked_file_digests'])<=set(tracked)
added=set(tracked)-set(old['all_tracked_file_digests'])
modified=changed-added
assert len(added)==145 and modified=={'.github/workflows/native.yml','Makefile','README.md',
    'compatibility/capabilities.json','compatibility/full-acceptance.json','docs/build.md',
    'docs/continuation-plan.md','docs/protocol.md'}
selected={r['path'] for r in old['files']}|{n for n in changed if not n.endswith(('.xz','.zip','.bin'))}
bundle=P/'source-343';bundle.mkdir()
for name in sorted(selected):
    target=bundle/'source'/name;target.parent.mkdir(parents=True,exist_ok=True)
    original=REPO/name
    if name not in changed:
        original=OLD/'source-b9/source'/name
        assert sha(original.read_bytes())==tracked[name]['sha256']
    os.link(original,target)
for name in ('review_hosted_af33.py','old50-obligations.json'):
    os.link(OLD/'source-b9'/name,bundle/name)
manifest=copy.deepcopy(old)
manifest.update(expected_tree=TREE,expected_parent=BASE,source_parents=[PARENT],
    git_tree_witnesses=witness,all_tracked_file_digests=tracked,
    files=[dict(path=n,**tracked[n]) for n in sorted(selected)],
    full_git_tree_blob_count=len(tracked),selected_file_count=len(selected))
dump(bundle/'source-manifest.json',manifest)
manifest_sha=sha((bundle/'source-manifest.json').read_bytes())
old_s=(OLD/'reader-b9-r01/review_pr32.py').read_text()
assert sha(old_s.encode())=='a3d29af49125612c2f4e4733bac0c1a15c0b475406e190b049843cb60875344f'
changes=[
    ("TREE='ae2a92e158ee95211eac8fe4109ababda210db65'",f"TREE='{TREE}'"),
    ("HEAD='b9e74758e4a30389e278d0b7b034ecf53e8a550c'",f"HEAD='{HEAD}'"),
    ("SOURCE_PARENTS=['db5fc98762e5b2f5a7ced9634e2695c420448c3b']",f"SOURCE_PARENTS=['{PARENT}']"),
    ('PULL_REQUEST=32','PULL_REQUEST=33'),
    ("SOURCE_MANIFEST='3b33844322705b216e5776e148a8dd3280cab2f01edac21e2c43b06bf7b10409'",f"SOURCE_MANIFEST='{manifest_sha}'"),
    ("m['full_git_tree_blob_count']==4176","m['full_git_tree_blob_count']==4321"),
    ("m['selected_file_count']==251",f"m['selected_file_count']=={len(selected)}"),
    ('len(named)==83 and len(qnamed)==10 and len(required)==38','len(named)==91 and len(qnamed)==10 and len(required)==43'),
    ('expected_main_root_reports=70','expected_main_root_reports=77'),
    ('heptatorch.pr32-native-dropout.independent-hosted-admission.v1','heptatorch.pr33-integer-tensors.independent-hosted-admission.v1'),
    ('heptatorch.pr32-native-dropout.hosted-admission-inputs.v1','heptatorch.pr33-integer-tensors.hosted-admission-inputs.v1'),
    ("        ctx=base.Audit.job(audit,spec['native'],workflow)",
     "        raise AssertionError('This prepared revision admits quick components only; full I64 evidence reader pending')\n        ctx=base.Audit.job(audit,spec['native'],workflow)"),
]
s=old_s
for a,b in changes:
    assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b,1)
restored=s
for a,b in reversed(changes):assert restored.count(b)==1;restored=restored.replace(b,a,1)
assert restored==old_s
compile(s,'review_pr33.py','exec')
reader=P/'reader-quick-r01';reader.mkdir();(reader/'review_pr33.py').write_text(s)
for name in ('retained_evidence.py','native_dropout_evidence.py'):os.link(OLD/'reader-b9-r01'/name,reader/name)
fns=lambda text:{n.name:ast.get_source_segment(text,n) for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
unchanged=[n for n,v in fns(old_s).items() if fns(s)[n]==v]
assert set(fns(s))-set(unchanged)=={'source_tree','main'}
workflow=(REPO/'.github/workflows/native.yml').read_bytes()
old_workflow=(OLD/'source-b9/source/.github/workflows/native.yml').read_bytes()
step_start=lambda raw:list(__import__('re').finditer(rb'^      - name: ',raw,__import__('re').M))
old_steps=step_start(old_workflow);new_steps=step_start(workflow)
def chunks(raw,starts):return [raw[x.start():starts[i+1].start() if i+1<len(starts) else len(raw)] for i,x in enumerate(starts)]
old_chunks=chunks(old_workflow,old_steps);new_chunks=chunks(workflow,new_steps)
assert len(old_chunks)==83 and len(new_chunks)==91
old_names=[x.splitlines()[0] for x in old_chunks]
kept=[x for x in new_chunks if x.splitlines()[0] in old_names]
assert [x.rstrip(b'\n') for x in kept]==[x.rstrip(b'\n') for x in old_chunks]
assert (REPO/'.github/workflows/observer-accounting.yml').read_bytes()==(OLD/'source-b9/source/.github/workflows/observer-accounting.yml').read_bytes()
proof={'schema':'heptatorch.pr33.prepared-source-and-quick-inverse.v1','status':'PREPARED_NOT_RUN',
    'source_head':HEAD,'source_tree':TREE,'source_parent':PARENT,'actual_initial_checkout_base':BASE,
    'full_source_files':len(tracked),'selected_files':len(selected),'Git_tree_witnesses':len(witness),
    'added_files':sorted(added),'modified_files':sorted(modified),'unchanged_blobs_modes_digests':len(tracked)-len(changed),
    'source_manifest_sha256':manifest_sha,'baseline_reader_sha256':sha(old_s.encode()),'reader_sha256':sha(s.encode()),
    'replacements':changes,'inverse_exact_original_bytes':True,'unchanged_function_bodies':unchanged,
    'quick_workflow_exact_original_bytes':True,'all83_old_native_step_name_shell_run_bytes_unchanged':True,
    'explicit_step_separator_blank_lines_only_ignored':True,'new_declared_steps':8,
    'native_executions':0,'Torch_executions':0,'full_native_admission_disabled_in_this_revision':True}
dump(reader/'exact-inverse.json',proof)
(reader/'source.diff').write_text(''.join(difflib.unified_diff(old_s.splitlines(True),s.splitlines(True),fromfile='b9-r01',tofile='PR33-quick-r01')))
dump(P/'source-343-custody.json',proof)
print(json.dumps({'status':'PREPARED_NOT_RUN','source_manifest_sha256':manifest_sha,'reader_sha256':sha(s.encode()),'selected_files':len(selected),'full_source_files':len(tracked),'tree':TREE}))
