def public_ten_cases(audit,base,child,old,prefix,files,metadata,sources):
    """Preserve every original case assertion; bind run-specific rollback hashes.

    The immutable Check.run compares the complete live before/after owner
    dictionaries before recording SHA(before.bytes). Those owner bytes were
    never archived by this suite. A different private state format must not be
    required to reproduce the preceding profile's whole-owner SHA. This reader
    checks the actual wire bytes, all remaining case fields and the recorded
    state equivalence relation. It does not claim an offline owner-byte replay.
    """
    label='544 original-public-ten'
    pins={
        'replay_original_ten.py':'7d57c5d84636417296a18ca5434510ecc0408d679cafac705d85d5bf4e48bc79',
        'base_replay.py':'8a9b56c837e9c7b3af47ed401a91e932fb3359a4c109157df738e5aa63e64f85',
        'materialization_replay.py':'67b8ec4e141e2837db1e7694dfd7684978ab79a0ca61989be63ad61b491462da',
        'native_release_controls.py':'43fbb5a3abb62125191266f7eec9d020717ae9f6388c171edbda6957dda255a8',
        'client.py':'dee3e4cb25ee1e5e06513e2f33478fbe274d9510ce2aaab9525815c72312946b'}
    for name,pin in pins.items():
        audit.check(label+' immutable executing source '+name,
                    sha(sources['tests/gradient_adam_distributions_review/'+name])==pin)
    def same(a,b):
        if type(a) is not type(b):return False
        if isinstance(a,dict):return set(a)==set(b) and all(same(a[k],b[k]) for k in a)
        if isinstance(a,list):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
        return a==b
    audit.check(label+' complete report schema unchanged',set(child)==set(old))
    runtime(audit,child,label)
    audit.check(label+' exact current physical observer format',child['layout']=={
        'state_format':'HTINT002','backing_format':'HTOINT02','descriptor_bytes':640})
    for key in sorted(old.keys()-{'native_sha256','source_sha256','layout','cases'}):
        audit.check(label+' complete original top-level field '+key,same(child[key],old[key]))
    audit.provenance(child['oracle_provenance'],label+' original fixed provenance')
    audit.check(label+' unchanged original ten plan and bounded result',
        type(child['cases']) is list and len(child['cases'])==len(old['cases'])==10
        and child['reference_groups']==child['executed_groups']==10
        and child['qualified_groups']==9 and child['partial_groups']==1 and child['failed_groups']==0
        and child['frames']==1036 and child['exact_comparisons']==5975 and child['rollback_bytes']==7689264)
    expected_files={prefix+'/report.json'}
    for i in range(1,11):
        expected_files.update(prefix+f'/case-{i:02d}/'+n for n in
                              ('requests.frames.bin','responses.frames.bin','transport.json'))
    audit.check(label+' exact original raw inventory without owner-byte dumps',
        {n for n in metadata if n.startswith(prefix+'/')}==expected_files)
    def bodies(raw,magic):
        rows=[];at=0
        while at<len(raw):
            assert len(raw)-at>=16 and raw[at:at+8]==magic
            size=struct.unpack_from('<Q',raw,at+8)[0]
            assert 32<=size<=1048576 and size<=len(raw)-at-16
            rows.append(raw[at+16:at+16+size]);at+=16+size
        assert at==len(raw)
        return rows
    def response(raw):
        assert len(raw)>=32
        magic,version,count,status=struct.unpack_from('<8s3Q',raw)
        assert magic==b'HTORSP03' and version==3
        if status:
            assert count==0 and len(raw)==32
            return status,[]
        codes=[];at=32
        for _ in range(count):
            assert at+32<=len(raw)
            code,error,value,size=struct.unpack_from('<4Q',raw,at);at+=32
            assert error==0 and at+size<=len(raw)
            codes.append(code);at+=size
        assert at==len(raw)
        return status,codes
    mapping={};inverse={};rollback_records=[];frames=exact=rollback_bytes=0
    for i,(current,previous) in enumerate(zip(child['cases'],old['cases']),1):
        case=label+f' case{i:02d}'
        audit.check(case+' exact keys and all non-frame fields',set(current)==set(previous)
            and all(same(current[k],previous[k]) for k in previous if k!='frame_records'))
        records=current['frame_records'];prior_records=previous['frame_records']
        root=prefix+f'/case-{i:02d}/'
        request=bodies(files[root+'requests.frames.bin'],b'HTOWNR01')
        replies=bodies(files[root+'responses.frames.bin'],b'HTOWNS01')
        transport=base.decode(files[root+'transport.json'])
        audit.check(case+' full actual trace and EOF source-bound receipt',
            type(records) is list and len(records)==len(prior_records)==len(request)==len(replies)==current['frames']
            and set(transport)=={'pid','frames','executable_sha256','rows','exit_code','responses_before_stdin_eof'}
            and transport['frames']==current['frames'] and len(transport['rows'])==current['frames']
            and transport['executable_sha256']==IMAGE and type(transport['pid']) is int and transport['pid']>0
            and transport['exit_code']==0 and transport['responses_before_stdin_eof'] is True)
        case_rollback=0
        for j,(record,prior,req,res,tr) in enumerate(zip(records,prior_records,request,replies,transport['rows']),1):
            item=case+f' frame{j}'
            audit.check(item+' exact field types and values apart from whole-owner digest',
                set(record)==set(prior) and all(same(record[k],prior[k]) for k in prior if k!='owner_sha256'))
            status,codes=response(res)
            magic,count,size,reserved=struct.unpack_from('<8s3Q',req)
            audit.check(item+' independently parsed complete raw request',magic==b'HTORCH03' and reserved==0
                and size==len(req) and 32+64*count<=len(req))
            requested=[struct.unpack_from('<Q',req,32+64*k)[0] for k in range(count)]
            audit.check(item+' actual raw hashes status command results and live frame',
                record['frame']==j and sha(req)==record['request_sha256'] and sha(res)==record['response_sha256']
                and status==record['expected_status']==record['actual_status']
                and (status!=0 or codes==requested)
                and set(tr)=={'frame','pid','response_bytes','stdin_open'} and tr=={
                    'frame':j,'pid':transport['pid'],'response_bytes':len(res),'stdin_open':True})
            if status:
                audit.check(item+' original complete executed rollback assertion',
                    record['entire_owner_unchanged'] is prior['entire_owner_unchanged'] is True
                    and type(record['owner_bytes']) is int and 0<record['owner_bytes']<=64*1048576
                    and isinstance(record['owner_sha256'],str) and re.fullmatch('[0-9a-f]{64}',record['owner_sha256']) is not None
                    and isinstance(prior['owner_sha256'],str) and re.fullmatch('[0-9a-f]{64}',prior['owner_sha256']) is not None)
                a,b=prior['owner_sha256'],record['owner_sha256']
                audit.check(item+' preserved whole-state equivalence classes',
                    mapping.get(a,b)==b and inverse.get(b,a)==a)
                mapping[a]=b;inverse[b]=a;case_rollback+=record['owner_bytes']
                rollback_records.append({'case':i,'frame':j,'owner_bytes':record['owner_bytes'],
                    'previous_profile_owner_sha256':a,'actual_profile_owner_sha256':b,
                    'request_sha256':record['request_sha256'],'response_sha256':record['response_sha256']})
            else:
                audit.check(item+' no fictitious rollback on successful frame',
                    not {'owner_sha256','owner_bytes','entire_owner_unchanged'}.intersection(record))
        audit.check(case+' exact complete rollback-byte sum',case_rollback==current['rollback_bytes'])
        frames+=len(records);exact+=current['exact_comparisons'];rollback_bytes+=case_rollback
    audit.check(label+' all original sums and eleven executed rollback observations',
        frames==child['frames'] and exact==child['exact_comparisons'] and rollback_bytes==child['rollback_bytes']
        and len(rollback_records)==11)
    return {'status':'ORIGINAL_TEN_FULL_CASES_AND_RAW_WIRE_VERIFIED',
        'frames':frames,'exact_comparisons':exact,'rollback_bytes':rollback_bytes,
        'qualified_groups':9,'partial_groups':1,'failed_groups':0,
        'rollback_observations':rollback_records,
        'all_other_case_fields_types_and_values_equal_to_original':True,
        'complete_current_wire_bytes_independently_verified':True,
        'whole_owner_before_after_equality':'SOURCE_BOUND_EXECUTED_ASSERTION',
        'owner_bytes_archived_by_original_suite':False,'offline_owner_bytes_reexecuted':False,
        'original_rollback_hashes_not_rewritten':True,'additional_native_or_Torch_execution':False}
