# PR33 r02 → r03: original-public-ten report schema correction

The r02 hosted admission remains **FAIL**, admission false, SHA `41b5ad94512cacd51f7561d36d77e1b9f1f2422d8a3dbcf42704bb4f09540e33`. Its native CI inputs, original reports and reader are unchanged. This correction changes the independent offline reader only.

## Actual discrepancy

All 16 inherited child reports were inspected together. `original-public-ten.cases` is a list of 10 complete case records. The other selected fields are scalar counters or a bounded status ledger. Comparing the complete list with the preceding 523 profile found exactly 11 different `frame_records.owner_sha256` strings. There were no other case-tree type or value differences.

The 11 observations are in cases 3 (three frames), 7 (one), 8 (four), 9 (two), and 10 (one). The original and current state equivalence classes are also preserved: the two observations of the same unchanged state retain the same digest within each run. This is not a claim that the old and new whole owners differ only in their format strings.

Both reports retain the complete original result: 10 executed cases, 9 qualified within exposed scope, 1 partial, 0 failed; 1,036 frames; 5,975 exact comparisons; 7,689,264 bytes compared by the executed rollback assertions. The old partial case is not reclassified for the new int64 interface.

## Source basis and available raw evidence

The original `Check.run` in `tests/gradient_adam_distributions_review/native_release_controls.py` reads `before = session.owner()` before an expected rejection, reads `after = session.owner()` afterwards, and executes `assert before == after`. Only then does it record `sha(before['bytes'])`. The dictionary includes the actual pointer, length, bytes and live state. The function body SHA is `61a5d03fac7973046289bd62d0987ac97283979a00e761aee5b09dffeab2a6a0`; the complete frozen source SHA is `43fbb5a3abb62125191266f7eec9d020717ae9f6388c171edbda6957dda255a8`.

The frozen client `dee3e4cb25ee1e5e06513e2f33478fbe274d9510ce2aaab9525815c72312946b` reads the current child owner through `/proc`, and its original `finish` checks successful exit and empty remaining stdout/stderr. The suite archives exactly 20 framed wire files, 10 transport receipts and its report. It does **not** archive the 11 whole-owner byte buffers. The r03 result therefore labels these observations **source-bound executed rollback assertions**, not offline recomputed owner hashes.

The new format is explicitly `HTINT002` / `HTOINT02`, descriptor width 640, source `adf6cae67666273aa6fb77989080ca3b1e3632188d2d7956a6d8b71808787e62`, ELF `b7324639bade3312981d1cbf9c2491b9fcff04fb6c3f808e9c5e1a7c2ca88f08`. Those identities are checked independently from the source tree and actual cold build. No native state or original report is rewritten.

## Exact reader change

The correction preserves every case key, scalar type, value, event, public identity, Version, fixture, open action and frame field except the declared whole-owner digest. It checks each current digest's format, the original executed rollback flag and length, and the complete old/current state equivalence relation. It also independently parses and hashes all 1,036 original request/response bodies, verifies command/result sequences and statuses, and binds all 10 actual transport/EOF receipts. The full top-level report is compared field by field apart from the explicit new source, ELF and layout identities.

The old full-6344-transition routines, all 18 copied-snapshot rules, numerical tolerances, source and wheel provenance, EOF/Version obligations, and all other inherited cases are byte-for-byte unchanged. `reader-full-r03/schema-correction-proof.json` records reversible whole-source replacements, and `helper.diff` contains the complete difference. The main reader changes only its helper SHA.

The copied-control test actually executed 4,221 positive checks and six expected refusals: changed case status, changed comparison count, missing frame, malformed current owner digest, broken same-state digest relation, and modified request bytes. It imports no production implementation, starts no native executable, and does not execute Torch. Its PASS is separate from the subsequently executed full hosted admission.
