"""Independent, byte-preserving admission of the fresh 544-function I64 run.

No HIA compiler, native executable, producer, or Torch is invoked. Original CI
paths map to authenticated source/archive namespaces. Nested raw archives are
verified through their complete single-XZ stream before their JSON is read.
"""
import ast
from collections import Counter
import copy
import gzip
import hashlib
import importlib.util
import io
import json
import lzma
from pathlib import Path, PurePosixPath
import re
import struct
import sys
import tarfile
import types

SOURCE='adf6cae67666273aa6fb77989080ca3b1e3632188d2d7956a6d8b71808787e62'
IMAGE='b7324639bade3312981d1cbf9c2491b9fcff04fb6c3f808e9c5e1a7c2ca88f08'
PARENT_SOURCE='6ffe509afce28ff15705b4c7b269eaef8f8f89f9d8b2486d4d9fa45b6be66ef3'
PARENT_IMAGE='830f0b4ef8d6ad8c6a105be56d383628b45c84e3e43905fee6812c7c52d35a51'
QUALIFIER='b158fda1ca21b9cc3f29036d3654827e38151b914d7854f4cfa59b2b930dd52e'
OBSERVER='ca011c95e1d19c40ecd365d0ba41b05cc818e5ba3d9adb8defd33c80be40e09a'
LAUNCHER='b95543285c1d6fb66aa95890bb517d7317941455048bfec04f802f788f4ef2ad'
CONTROLS='6fd5e6e03c87df707f06e6cf28d03604ff89226e21668381c3cb9817c1e83d64'
PROFILE='865285bd5aa57bb5b8e543b11a333079e2820e5a15a11bb210394652f611ac98'
COMPILER='b1c851a0896fa6071f800e1146c3c27d0c6cf85059e9a6281b46d42908a3f59f'
LINKER='aae650e8822ef0b1e74d15108ad1d0f17ec791205ed5a158ec60b709f48f0e16'
RUNTIME_LINKER='0c5176e3aa968631ae592b887c5dc3cf1e8e3f48f73593f076e9d7965ffacfd7'
FLAT='c5a9c2b95a3061e080a21298f5b26000936ed9dac519690d845b0699a15744c6'
MODEL={'name':'integer-tensor-544-fixed35-F32','source':SOURCE,'image':IMAGE}
OUTER=('producer10','resources6','owned-entry5','typed-handoff2')
PRODUCER=('cold-native-build','original-storage12','original-arithmetic30','original-dropout12',
          'alias-mutation8','integer-RNE1237','CPU-promotion20','view-base-lifetime6',
          'independent-inplace40','legacy523-behavior12')
SELF_EXCLUSIONS={'report.json','evidence-manifest.json','raw-evidence.tar.xz'}
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def literal(source,name):
    return next(ast.literal_eval(n.value) for n in ast.parse(source).body
                if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))

def kwargs(argv):
    index=next(i for i,x in enumerate(argv) if x.endswith('.py'))
    assert index>0 and len(argv[index+1:])%2==0
    result={}
    for key,value in zip(argv[index+1::2],argv[index+2::2]):
        assert key.startswith('--') and key not in result
        result[key]=value
    return argv[index],result

def runtime(audit,doc,label):
    ss=[doc[k] for k in ('source_sha256','native_source_sha256','runtime_source_sha256') if k in doc]
    es=[doc[k] for k in ('native_sha256','binary_sha256','executable_sha256','native_executable_sha256') if k in doc]
    audit.check(label+': exact544 source and ELF',bool(ss) and bool(es)
                and all(x==SOURCE for x in ss) and all(x==IMAGE for x in es))

def exact_fields(audit,doc,wanted,label):
    for key,value in wanted.items():
        audit.check(label+'/'+key,key in doc and type(doc[key]) is type(value) and doc[key]==value)

def framed(raw,magic):
    offset=0;rows=[]
    while offset<len(raw):
        assert len(raw)-offset>=16 and raw[offset:offset+8]==magic
        n=struct.unpack_from('<Q',raw,offset+8)[0]
        assert n<=1048576 and n<=len(raw)-offset-16
        rows.append(n);offset+=16+n
    assert offset==len(raw)
    return rows

def read_archive(audit,base,packed,declared,label):
    audit.check(label+': nonempty exact member table',isinstance(declared,dict) and bool(declared))
    files={};metadata={};wire={}
    with tarfile.open(fileobj=io.BytesIO(packed),mode='r|xz') as stream:
        for member in stream:
            name=base.member_name(member.name)
            audit.check(label+': ordinary unique declared member '+name,
                        member.isfile() and name not in metadata and name in declared)
            raw=stream.extractfile(member).read();pin=declared[name]
            audit.check(label+': every member exact SHA size mode '+name,
                        member.size==len(raw)==pin['bytes'] and member.mode==pin['mode'] and sha(raw)==pin['sha256'])
            metadata[name]={'bytes':len(raw),'mode':member.mode,'sha256':sha(raw)}
            if name.endswith(('.json','.py','.hepta','.gz','.xz')) or (name.endswith(('.stdout','.stderr')) and len(raw)<65536):
                files[name]=raw
            if name.endswith('.frames.bin') and ('original-public-ten/' in name or 'original-public-ten' in label):
                files[name]=raw
            if name.endswith('/requests.frames.bin'):wire[name]=framed(raw,b'HTOWNR01')
            if name.endswith('/responses.frames.bin'):wire[name]=framed(raw,b'HTOWNS01')
    audit.check(label+': exact complete member set',set(metadata)==set(declared))
    dec=lzma.LZMADecompressor();digest=hashlib.sha256();total=0;offset=0
    while not dec.eof:
        block=packed[offset:offset+1048576] if dec.needs_input else b''
        if dec.needs_input:
            audit.check(label+': XZ has input before EOF',bool(block));offset+=len(block)
        raw=dec.decompress(block,max_length=1048576);total+=len(raw);digest.update(raw)
    audit.check(label+': complete single XZ without concatenation',not dec.unused_data and offset==len(packed))
    receipt={'members':len(metadata),'decompressed_tar_bytes':total,'decompressed_tar_sha256':digest.hexdigest(),
             'single_XZ_stream_EOF':True,'all_member_bytes_modes_sizes_verified':True}
    return files,metadata,wire,receipt

def public_ten_cases(audit,base,child,old,prefix,files,metadata,sources):
    """Preserve every original case assertion; bind run-specific rollback hashes.

    The immutable Check.run compares the complete live before/after owner
    dictionaries before recording SHA(before.bytes). Those owner bytes were
    never archived by this suite. A different private state format must not be
    required to reproduce the preceding profile's whole-owner SHA. This reader
    checks the actual wire bytes, all remaining case fields and the recorded
    state equivalence relation. It does not claim an offline owner-byte replay.
    """
    label='544 original-public-ten'
    pins={
        'replay_original_ten.py':'7d57c5d84636417296a18ca5434510ecc0408d679cafac705d85d5bf4e48bc79',
        'base_replay.py':'8a9b56c837e9c7b3af47ed401a91e932fb3359a4c109157df738e5aa63e64f85',
        'materialization_replay.py':'67b8ec4e141e2837db1e7694dfd7684978ab79a0ca61989be63ad61b491462da',
        'native_release_controls.py':'43fbb5a3abb62125191266f7eec9d020717ae9f6388c171edbda6957dda255a8',
        'client.py':'dee3e4cb25ee1e5e06513e2f33478fbe274d9510ce2aaab9525815c72312946b'}
    for name,pin in pins.items():
        audit.check(label+' immutable executing source '+name,
                    sha(sources['tests/gradient_adam_distributions_review/'+name])==pin)
    def same(a,b):
        if type(a) is not type(b):return False
        if isinstance(a,dict):return set(a)==set(b) and all(same(a[k],b[k]) for k in a)
        if isinstance(a,list):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
        return a==b
    audit.check(label+' complete report schema unchanged',set(child)==set(old))
    runtime(audit,child,label)
    audit.check(label+' exact current physical observer format',child['layout']=={
        'state_format':'HTINT002','backing_format':'HTOINT02','descriptor_bytes':640})
    for key in sorted(old.keys()-{'native_sha256','source_sha256','layout','cases'}):
        audit.check(label+' complete original top-level field '+key,same(child[key],old[key]))
    audit.provenance(child['oracle_provenance'],label+' original fixed provenance')
    audit.check(label+' unchanged original ten plan and bounded result',
        type(child['cases']) is list and len(child['cases'])==len(old['cases'])==10
        and child['reference_groups']==child['executed_groups']==10
        and child['qualified_groups']==9 and child['partial_groups']==1 and child['failed_groups']==0
        and child['frames']==1036 and child['exact_comparisons']==5975 and child['rollback_bytes']==7689264)
    expected_files={prefix+'/report.json'}
    for i in range(1,11):
        expected_files.update(prefix+f'/case-{i:02d}/'+n for n in
                              ('requests.frames.bin','responses.frames.bin','transport.json'))
    audit.check(label+' exact original raw inventory without owner-byte dumps',
        {n for n in metadata if n.startswith(prefix+'/')}==expected_files)
    def bodies(raw,magic):
        rows=[];at=0
        while at<len(raw):
            assert len(raw)-at>=16 and raw[at:at+8]==magic
            size=struct.unpack_from('<Q',raw,at+8)[0]
            assert 32<=size<=1048576 and size<=len(raw)-at-16
            rows.append(raw[at+16:at+16+size]);at+=16+size
        assert at==len(raw)
        return rows
    def response(raw):
        assert len(raw)>=32
        magic,version,count,status=struct.unpack_from('<8s3Q',raw)
        assert magic==b'HTORSP03' and version==3
        if status:
            assert count==0 and len(raw)==32
            return status,[]
        codes=[];at=32
        for _ in range(count):
            assert at+32<=len(raw)
            code,error,value,size=struct.unpack_from('<4Q',raw,at);at+=32
            assert error==0 and at+size<=len(raw)
            codes.append(code);at+=size
        assert at==len(raw)
        return status,codes
    mapping={};inverse={};rollback_records=[];frames=exact=rollback_bytes=0
    for i,(current,previous) in enumerate(zip(child['cases'],old['cases']),1):
        case=label+f' case{i:02d}'
        audit.check(case+' exact keys and all non-frame fields',set(current)==set(previous)
            and all(same(current[k],previous[k]) for k in previous if k!='frame_records'))
        records=current['frame_records'];prior_records=previous['frame_records']
        root=prefix+f'/case-{i:02d}/'
        request=bodies(files[root+'requests.frames.bin'],b'HTOWNR01')
        replies=bodies(files[root+'responses.frames.bin'],b'HTOWNS01')
        transport=base.decode(files[root+'transport.json'])
        audit.check(case+' full actual trace and EOF source-bound receipt',
            type(records) is list and len(records)==len(prior_records)==len(request)==len(replies)==current['frames']
            and set(transport)=={'pid','frames','executable_sha256','rows','exit_code','responses_before_stdin_eof'}
            and transport['frames']==current['frames'] and len(transport['rows'])==current['frames']
            and transport['executable_sha256']==IMAGE and type(transport['pid']) is int and transport['pid']>0
            and transport['exit_code']==0 and transport['responses_before_stdin_eof'] is True)
        case_rollback=0
        for j,(record,prior,req,res,tr) in enumerate(zip(records,prior_records,request,replies,transport['rows']),1):
            item=case+f' frame{j}'
            audit.check(item+' exact field types and values apart from whole-owner digest',
                set(record)==set(prior) and all(same(record[k],prior[k]) for k in prior if k!='owner_sha256'))
            status,codes=response(res)
            magic,count,size,reserved=struct.unpack_from('<8s3Q',req)
            audit.check(item+' independently parsed complete raw request',magic==b'HTORCH03' and reserved==0
                and size==len(req) and 32+64*count<=len(req))
            requested=[struct.unpack_from('<Q',req,32+64*k)[0] for k in range(count)]
            audit.check(item+' actual raw hashes status command results and live frame',
                record['frame']==j and sha(req)==record['request_sha256'] and sha(res)==record['response_sha256']
                and status==record['expected_status']==record['actual_status']
                and (status!=0 or codes==requested)
                and set(tr)=={'frame','pid','response_bytes','stdin_open'} and tr=={
                    'frame':j,'pid':transport['pid'],'response_bytes':len(res),'stdin_open':True})
            if status:
                audit.check(item+' original complete executed rollback assertion',
                    record['entire_owner_unchanged'] is prior['entire_owner_unchanged'] is True
                    and type(record['owner_bytes']) is int and 0<record['owner_bytes']<=64*1048576
                    and isinstance(record['owner_sha256'],str) and re.fullmatch('[0-9a-f]{64}',record['owner_sha256']) is not None
                    and isinstance(prior['owner_sha256'],str) and re.fullmatch('[0-9a-f]{64}',prior['owner_sha256']) is not None)
                a,b=prior['owner_sha256'],record['owner_sha256']
                audit.check(item+' preserved whole-state equivalence classes',
                    mapping.get(a,b)==b and inverse.get(b,a)==a)
                mapping[a]=b;inverse[b]=a;case_rollback+=record['owner_bytes']
                rollback_records.append({'case':i,'frame':j,'owner_bytes':record['owner_bytes'],
                    'previous_profile_owner_sha256':a,'actual_profile_owner_sha256':b,
                    'request_sha256':record['request_sha256'],'response_sha256':record['response_sha256']})
            else:
                audit.check(item+' no fictitious rollback on successful frame',
                    not {'owner_sha256','owner_bytes','entire_owner_unchanged'}.intersection(record))
        audit.check(case+' exact complete rollback-byte sum',case_rollback==current['rollback_bytes'])
        frames+=len(records);exact+=current['exact_comparisons'];rollback_bytes+=case_rollback
    audit.check(label+' all original sums and eleven executed rollback observations',
        frames==child['frames'] and exact==child['exact_comparisons'] and rollback_bytes==child['rollback_bytes']
        and len(rollback_records)==11)
    return {'status':'ORIGINAL_TEN_FULL_CASES_AND_RAW_WIRE_VERIFIED',
        'frames':frames,'exact_comparisons':exact,'rollback_bytes':rollback_bytes,
        'qualified_groups':9,'partial_groups':1,'failed_groups':0,
        'rollback_observations':rollback_records,
        'all_other_case_fields_types_and_values_equal_to_original':True,
        'complete_current_wire_bytes_independently_verified':True,
        'whole_owner_before_after_equality':'SOURCE_BOUND_EXECUTED_ASSERTION',
        'owner_bytes_archived_by_original_suite':False,'offline_owner_bytes_reexecuted':False,
        'original_rollback_hashes_not_rewritten':True,'additional_native_or_Torch_execution':False}


def review_native(audit,base,spec,ctx,main_bytes,reports,sources,tracked,parent_summary):
    zipped,official=audit.archive(spec)
    audit.check('544 original native artifact run/attempt',official['workflow_run']['id']==ctx['run']['id']
        and official['name']==f"integer-tensor-native-evidence-{ctx['run']['id']}-{ctx['run']['run_attempt']}-native")
    names={'hosted-integer-tensors-native.json','integer-tensors-ci-raw-manifest.json','integer-tensors-ci-raw.tar.xz'}
    audit.check('544 original artifact exact three members',set(zipped)==names)
    for name in names-{'integer-tensors-ci-raw.tar.xz'}:
        audit.check('544 exact root report mirror '+name,zipped[name]==main_bytes[name])
    aggregate=reports['hosted-integer-tensors-native.json'];manifest=reports['integer-tensors-ci-raw-manifest.json']
    runtime(audit,aggregate,'544 fresh aggregate')
    exact_fields(audit,aggregate,{'schema':'heptatorch.integer-tensor-native-integration.v1','status':'PASS',
        'producer_mode':'FRESH_COLD_REQUIRED','producer_executed_this_invocation':True,'producer_completed_this_invocation':True,
        'all_inputs_unchanged':True,'Torch_executed_here':False,'closed_schema_count':0,'whole_pytorch_gate':'HOLD',
        'full_pytorch_rewrite_complete':False,'pytorch_api_denominator':2590,'command_count':4},'544 fresh gate')
    audit.check('544 no hidden failure or reuse receipt',not any(k in aggregate for k in
                ('error','traceback','archive_error','partial_failed_execution_evidence','reuse')))
    audit.check('544 exact coordinator bytes',sha(sources['tests/qualify_integer_tensors.py'])==QUALIFIER)
    exact_fields(audit,manifest,{'schema':'heptatorch.integer-tensor-fresh-raw-evidence.v1','status':'VERIFIED',
        'source_sha256':SOURCE,'native_sha256':IMAGE,'single_XZ_stream_EOF':True,
        'all_member_bytes_modes_sizes_verified':True},'544 complete raw manifest')
    packed=zipped['integer-tensors-ci-raw.tar.xz']
    audit.check('544 actual raw size and digest',len(packed)==manifest['archive_bytes'] and sha(packed)==manifest['archive_sha256'])
    files,metadata,wire,verified=read_archive(audit,base,packed,manifest['files'],'544 fresh raw')
    audit.check('544 exact archive metadata and self exclusions',not SELF_EXCLUSIONS.intersection(metadata)
        and all(manifest[k]==v for k,v in verified.items())
        and sum(x['bytes'] for x in metadata.values())==manifest['uncompressed_bytes'])
    complete={k:v for k,v in manifest.items() if k!='files'}
    complete.update(archive='raw-evidence.tar.xz',manifest='evidence-manifest.json',manifest_sha256=sha(zipped['integer-tensors-ci-raw-manifest.json']))
    audit.check('544 aggregate exact entire raw receipt',aggregate['complete_current_execution_evidence']==complete)
    commands=aggregate['commands']
    audit.check('544 four fresh ordered processes',len(commands)==4 and tuple(r['name'] for r in commands)==OUTER)
    script,opts=kwargs(commands[0]['argv']);repo=PurePosixPath(opts['--repository']);root=PurePosixPath(opts['--output']).parent
    parent=PurePosixPath(opts['--parent']);native=root/'producer10/native'
    audit.check('544 actual CI namespaces',repo.is_absolute() and root.is_absolute() and root.is_relative_to(repo/'build')
        and parent==repo/'build/native-dropout' and script==str(repo/'tools/integer_tensors/qualify.py')
        and opts['--output']==str(root/'producer10'))
    required=set();referenced=set()
    def source(name):
        assert name in tracked;required.add(str(repo/name));return tracked[name]
    def original(name,pin=None,checked=True):
        assert name in metadata and name in files
        if pin is not None:audit.check('544 original child SHA '+name,metadata[name]['sha256']==pin)
        if checked:required.add(str(root/name))
        return base.decode(files[name])
    def source_argv(argv,label,checked=False):
        script,values=kwargs(argv);path=PurePosixPath(script).relative_to(repo).as_posix()
        audit.check(label+': actual source script in target tree',path in tracked)
        if checked:source(path)
        referenced.add(path)
        for v in values.values():
            p=PurePosixPath(v)
            if p.is_absolute() and p.is_relative_to(repo) and not p.is_relative_to(repo/'build'):
                n=p.relative_to(repo).as_posix()
                if n in tracked:referenced.add(n)
        return values
    for name in ('tests/qualify_integer_tensors.py','tools/integer_tensors/profile.json','tools/native_dropout/profile.json'):source(name)
    definitions=base.decode(sources['tools/integer_tensors/profile.json']);parent_profile=base.decode(sources['tools/native_dropout/profile.json'])
    exact_fields(audit,definitions,{'source_sha256':SOURCE,'native_sha256':IMAGE,'functions':544,'blocks':7263,
        'instructions':26361,'descriptor_bytes':640,'state_format':'HTINT002','backing_format':'HTOINT02'},'544 frozen profile')
    declared=literal(sources['tests/qualify_integer_tensors.py'],'MANIFESTS')
    audit.check('544 exact five source manifests',len(declared)==len(aggregate['manifests'])==5)
    for actual,(name,pin,count) in zip(aggregate['manifests'],declared):
        source(name);raw=sources[name]
        audit.check('544 exact manifest source and receipt '+name,sha(raw)==pin and actual=={
            'path':name,'sha256':pin,'members':count,'all_bytes_modes_lengths_verified':True})
        rows=base.decode(raw)['files'];rows=[dict(row,path=k) for k,row in rows.items()] if isinstance(rows,dict) else rows
        audit.check('544 manifest unique complete set '+name,len(rows)==len({r['path'] for r in rows})==count)
        for row in rows:
            wanted=source(row['path'])
            audit.check('544 manifest member belongs to target tree '+row['path'],row['sha256']==wanted['sha256']
                and row['bytes']==wanted['bytes'] and row['mode']==int(wanted['mode'],8)&0o777)
    for row in commands:
        name=row['name'];values=source_argv(row['argv'],'544 '+name,True)
        audit.check('544 actual process completed '+name,row['status']=='PASS' and row['exit_code']==0
            and row['process_started'] is row['process_completed'] is True and type(row['pid']) is int and row['pid']>0
            and values['--output']==str(root/name))
        audit.check('544 original full argv '+name,base.decode(files[name+'.argv.json'])==row['argv'])
        doc=original(row['report'],row['report_sha256']);runtime(audit,doc,'544 '+name)
        audit.check('544 original successful child '+name,doc['status']=='PASS')
        for suffix in ('stdout','stderr'):
            pin=metadata[name+'.'+suffix]
            audit.check('544 original outer stream '+name+'/'+suffix,row[suffix]=={'bytes':pin['bytes'],'sha256':pin['sha256']})
    # Child archives are compacted only after their complete original bytes are
    # verified. Reconstruct virtual paths without rewriting the CI originals.
    expanded_receipts=[];expanded_archives=set()
    def expand(archive_path,receipt_path,destination,checked=False):
        if checked:
            required.update((str(root/archive_path),str(root/receipt_path)))
        receipt=original(receipt_path,checked=False);blob=files[archive_path]
        audit.check('544 nested archive original bytes '+archive_path,
            sha(blob)==receipt['archive_sha256'] and len(blob)==receipt['archive_bytes']
            and receipt['all_member_bytes_sizes_modes_verified'] is True and receipt['xz_complete_EOF_verified'] is True
            and receipt['archive']==PurePosixPath(archive_path).name
            and PurePosixPath(receipt['restoration_base'])==root/destination)
        nf,nm,nw,nv=read_archive(audit,base,blob,receipt['members'],'544 nested '+archive_path)
        audit.check('544 nested original complete counts '+archive_path,
            len(nm)==receipt['member_count'] and sum(x['bytes'] for x in nm.values())==receipt['original_bytes'])
        for n,pin in nm.items():
            key=destination+'/'+n
            if key in metadata:audit.check('544 compacted duplicate unchanged '+key,metadata[key]==pin)
            metadata[key]=pin
        for n,raw in nf.items():
            key=destination+'/'+n
            if key in files:audit.check('544 original expanded bytes equal '+key,files[key]==raw)
            files[key]=raw
        wire.update({destination+'/'+n:v for n,v in nw.items()})
        expanded_archives.add(archive_path);expanded_receipts.append(dict(nv,path=archive_path,archive_sha256=sha(blob)))
        return receipt,nv
    producer=original('producer10/report.json')
    exact_fields(audit,producer,{'schema':'heptatorch.integer-tensor-portable-qualification.v1','status':'PASS','step_count':10,
        'all_package_members_unchanged':True,'native_cold_rebuild_executed':True,'all_named_gate_statuses_and_counts_matched':True,
        'original54_reference_indices_exactly_once':list(range(54)),'pinned_Torch_executed_here':False},'544 actual producer10')
    audit.check('544 complete producer order and immutable inputs',len(producer['steps'])==10
        and tuple(r['name'] for r in producer['steps'])==PRODUCER
        and producer['package_manifest_sha256']==tracked['tools/integer_tensors/package-manifest.json']['sha256']
        and producer['profile_sha256']==tracked['tools/integer_tensors/profile.json']['sha256']
        and producer['independent_inplace40_package_sha256']==tracked['validation/int64-inplace-review/package-manifest.json']['sha256'])
    fixed={
        'cold-native-build':{'units_reproduced_exactly':11,'native_build_process_started':True,'native_build_process_completed':True,'existing_integer_image_reused':False,'all_package_members_unchanged':True},
        'original-storage12':{'cases':12,'passed':12,'failed':0,'frames':235,'reference_indices':list(range(12))},
        'original-arithmetic30':{'cases':30,'passed':30,'failed':0,'frames':1122,'reference_indices':list(range(12,42))},
        'original-dropout12':{'cases':12,'passed':12,'failed':0,'frames':333,'reference_indices':list(range(42,54))},
        'alias-mutation8':{'cases':8,'passed':8,'native_frames':516,'exact_checks':2792},
        'integer-RNE1237':{'cases':5,'integers':1237,'native_frames':60,'exact_checks':1282},
        'CPU-promotion20':{'cases':20,'passed':20,'original_mixed_operations':40,'native_frames':2280,'exact_checks':10580},
        'view-base-lifetime6':{'cases':6,'passed':6,'native_frames':450,'exact_checks':2046,'native_role_checks':168},
        'independent-inplace40':{'cases':40,'passed':40,'native_frames':1747,'exact_checks':7178,'raw_words':2958,'rng_bytes':808960,'rollback_bytes':13980480},
        'legacy523-behavior12':{'step_count':12,'existing_native_units_verified':11,'all_expected_statuses_and_counts_matched':True}}
    children={};raw_receipts=[]
    for row in producer['steps']:
        name=row['name'];values=source_argv(row['command'],'544 producer '+name)
        audit.check('544 original producer process '+name,row['status']=='PASS' and row['exit_code']==0 and row['process_started'] is True)
        child=original('producer10/'+row['report'],row['report_sha256']);children[name]=child
        runtime(audit,child,'544 producer '+name);exact_fields(audit,child,{'status':'PASS',**fixed[name]},'544 producer fixed '+name)
        if name!='cold-native-build':
            field='source_files_unchanged' if name=='independent-inplace40' else 'all_inputs_unchanged'
            audit.check('544 producer unchanged exact input '+name,child[field] is True)
        for suffix in ('stdout','stderr'):
            n='producer10/'+name+'.'+suffix;required.add(str(root/n))
            audit.check('544 producer original stream '+n,metadata[n]['sha256']==row[suffix+'_sha256'])
        if name!='cold-native-build':
            arc='producer10/evidence/'+row['archive']['archive'];rec='producer10/evidence/'+name+'.manifest.json'
            receipt,verified=expand(arc,rec,'producer10/'+name,True)
            audit.check('544 producer exact raw archive receipt '+name,
                row['archive']=={k:v for k,v in receipt.items() if k not in ('members','expanded_verified_raw_removed')})
            raw_receipts.append(dict(verified,gate=name,archive_sha256=receipt['archive_sha256']))
    audit.check('544 coordinator binds every producer original and raw archive',aggregate['producer_admission']=={
        'report_sha256':metadata['producer10/report.json']['sha256'],'steps':10,'actual_cold_build_verified':True,
        'raw_archives':raw_receipts,'original_bounded_legacy_statuses_preserved':True})
    # Recursively authenticate all compacted legacy gates too, including their
    # original inherited16 raw bytes. A nested archive is never silently skipped.
    while True:
        pending=[]
        for name,raw in list(files.items()):
            if not name.endswith('.manifest.json'):continue
            receipt=base.decode(raw)
            if not isinstance(receipt,dict) or not isinstance(receipt.get('members'),dict) or 'archive' not in receipt:continue
            arc=str(PurePosixPath(name).parent/receipt['archive'])
            if 'restoration_base' in receipt:
                audit.check('544 no omitted declared nested archive '+arc,arc in files and arc in metadata)
            if arc not in expanded_archives and 'restoration_base' in receipt:
                destination=PurePosixPath(receipt['restoration_base']).relative_to(root).as_posix()
                pending.append((arc,name,destination))
        if not pending:break
        for arc,rec,dest in pending:expand(arc,rec,dest)
    build=original('producer10/native/build.json')
    audit.check('544 real eleven unit compile/link',build['status']=='PASS' and build['link_exit']==0
        and len(build['units'])==len({u['name'] for u in build['units']})==11
        and build['compiler_sha256']==COMPILER and build['linker_sha256']==LINKER)
    for key in ('parent_source_sha256','parent_native_sha256','source_sha256','native_sha256','functions','blocks','instructions',
                'descriptor_bytes','state_format','backing_format','units'):
        audit.check('544 actual exact profile '+key,build[key]==definitions[key])
    for name,pin in [('runtime.hepta',SOURCE),('tensor-integer-session',IMAGE)]:
        n='producer10/native/'+name;required.add(str(root/n));audit.check('544 actual cold product '+name,metadata[n]['sha256']==pin)
    unit_members={}
    for unit in build['units']:
        audit.check('544 actual compiler success '+unit['name'],unit['compiler_exit']==0)
        for suffix,kind in (('.hepta','source'),('.o','object')):
            n='producer10/native/'+unit['name']+suffix;required.add(str(root/n));unit_members[unit['name']+suffix]=metadata[n]
            audit.check('544 every actual source/object '+n,metadata[n]['sha256']==unit[kind+'_sha256'])
    audit.integer_runtime_raw=files['producer10/native/runtime.hepta']
    audit.check('544 exact build receipt',aggregate['new_build']=={'build_report_sha256':metadata['producer10/native/build.json']['sha256'],
        'source_sha256':SOURCE,'native_sha256':IMAGE,'actual_units_verified':11})
    cold=children['cold-native-build'];source_argv(cold['command'],'544 actual builder')
    audit.check('544 exact builder result and source',cold['exit_code']==0
        and cold['actual_build_report_sha256']==metadata['producer10/native/build.json']['sha256']
        and cold['profile_sha256']==tracked['tools/integer_tensors/profile.json']['sha256']
        and cold['package_manifest_sha256']==tracked['tools/integer_tensors/package-manifest.json']['sha256'])
    for suffix in ('stdout','stderr'):
        audit.check('544 original builder stream '+suffix,metadata['producer10/native/builder.'+suffix]['sha256']==cold[suffix+'_sha256'])
    references=definitions['fixed_references'];audit.check('544 exactly five unchanged fixed references',producer['fixed_references']==references and len(references)==5)
    for name,pin in references.items():
        raw=sources['validation/integer-tensors/reference/'+name];doc=base.decode(raw)
        audit.check('544 immutable actual reference '+name,sha(raw)==pin['sha256'] and len(raw)==pin['bytes']
            and doc['status']=='OBSERVED' and doc['cases']==pin['cases'] and doc['probe_error_count']==0
            and doc['probe_sha256']==pin['probe_sha256'] and doc['source_files_unchanged'] is True)
        audit.provenance(doc['oracle_provenance'],'544 original fixed reference '+name)
    independent=definitions['independent_inplace40'];raw=sources[independent['reference_path']];doc=base.decode(raw)
    audit.check('544 independent original40 immutable reference',sha(raw)==independent['reference_sha256']
        and doc['status']=='OBSERVED' and doc['cases']==40 and doc['probe_error_count']==0 and doc['source_files_unchanged'] is True
        and sha(sources[independent['runner_path']])==independent['runner_sha256'])
    audit.provenance(doc['oracle_provenance'],'544 independent actual40 reference')
    ref_names={'original-storage12':'torch-int64-tensor-reference.json','original-arithmetic30':'torch-int64-tensor-reference.json',
        'original-dropout12':'torch-int64-tensor-reference.json','alias-mutation8':'torch-int64-alias-reference.json',
        'integer-RNE1237':'torch-int64-f32-rne.json','CPU-promotion20':'torch-int64-promotion-reference.json','view-base-lifetime6':'torch-int64-view-base-lifetime.json'}
    for name,ref in ref_names.items():audit.check('544 actual child reference '+name,children[name]['reference_sha256']==references[ref]['sha256'])
    audit.check('544 actual independent40 reference',children['independent-inplace40']['reference_sha256']==independent['reference_sha256'])
    bodies={name.decode():body for body,name in re.findall(
        rb"^(fn ([A-Za-z_][A-Za-z_0-9]*)\([^\n]* entry\([A-Za-z_][A-Za-z_0-9]*\)\n.*?^end\n)",
        audit.integer_runtime_raw,re.M|re.S)}
    for name in (*ref_names,'independent-inplace40'):
        child=children[name];rows=child['rows']
        reference=base.decode(sources[independent['reference_path'] if name=='independent-inplace40'
            else 'validation/integer-tensors/reference/'+ref_names[name]])
        indices=child.get('reference_indices',list(range(child['cases'])))
        audit.check('544 complete exact actual reference row plan '+name,
            len(rows)==len(indices)==child['cases'] and [r['index'] for r in rows]==indices
            and [(r['index'],r['name']) for r in rows]==[(reference['rows'][i]['index'],reference['rows'][i]['name']) for i in indices]
            and all(r['status']=='PASS' and r['differences']==[] and 'error' not in r for r in rows))
        frame_key='frames' if 'frames' in child else 'native_frames'
        count_key='checks' if 'checks' in child else 'exact_checks'
        audit.check('544 exact original per-row sums '+name,
            sum(r[frame_key] for r in rows)==child[frame_key] and sum(r['checks'] for r in rows)==child[count_key])
        inputs=child['inputs_sha256'];audit.check('544 actual child input ledger nonempty '+name,bool(inputs))
        script,values=kwargs(next(r['command'] for r in producer['steps'] if r['name']==name))
        audit.check('544 actual child mandatory original input keys '+name,
            {script,values['--binary'],values['--source'],values['--reference'],values['--protocol']}<=set(inputs))
        for path,pin in inputs.items():
            p=PurePosixPath(path)
            if p.is_relative_to(root):wanted=metadata[p.relative_to(root).as_posix()]['sha256']
            else:wanted=tracked[p.relative_to(repo).as_posix()]['sha256']
            audit.check('544 every original child input bound '+name+'/'+path,pin==wanted)
        for fn,pin in child.get('physical_observer_bodies_sha256',{}).items():
            audit.check('544 physical observer exact actual HIA body '+name+'/'+fn,fn in bodies and sha(bodies[fn])==pin)

    legacy=children['legacy523-behavior12'];legacy_prefix='producer10/legacy523-behavior12/'
    old_counts={
        'typed-slice':{'frames':48},'typed-lifetimes':{'frames':343},'bool-logical-not':{'frames':66},'dtype-admission101':{'frames':126},
        'owned-allocation':{'frames':120},'history-mul-controls8':{'cases':8,'passed':8,'frames':216},
        'actual-native-dropout28':{'cases':28,'frames':1816},'original-native-dropout8':{'cases':8,'passed':8,'frames':140},
        'actual-existing-optimizer6':{'cases':6,'passed':6,'frames':2114},'actual-sgd-effective-layout6':{'cases':6,'passed':6,'frames':891},
        'actual-retained12':{'variants_executed':12,'variants_qualified':12,'unexpected_failures':0},
        'inherited16':{'step_count':16,'all_sources_unchanged':True}}
    audit.check('544 complete original12 behavior order',len(legacy['steps'])==12 and [r['name'] for r in legacy['steps']]==list(old_counts))
    for row in legacy['steps']:
        name=row['name'];source_argv(row['command'],'544 original12 '+name)
        child=original(legacy_prefix+row['report'],row['report_sha256'],False)
        arc=legacy_prefix+'evidence/'+row['archive']['archive'];receipt=original(legacy_prefix+'evidence/'+name+'.manifest.json',checked=False)
        audit.check('544 every original legacy archive fully expanded '+name,arc in expanded_archives
            and row['archive']=={k:v for k,v in receipt.items() if k not in ('members','verified_raw_expanded_copies_removed')})
        status='QUALIFIED_EXPOSED_SCOPE' if name=='actual-retained12' else 'PASS'
        audit.check('544 actual original bounded child '+name,row['exit_code']==0 and row['status']==child['status']==status)
        exact_fields(audit,child,old_counts[name],'544 unchanged legacy counters '+name)
        for suffix in ('stdout','stderr'):
            audit.check('544 legacy original stream '+name+'/'+suffix,metadata[legacy_prefix+name+'.'+suffix]['sha256']==row[suffix+'_sha256'])
    retained12=original(legacy_prefix+'actual-retained12/report.json',checked=False)
    audit.check('544 retained12 complete actual reference and original11 provenance',
        retained12['inputs']['observations']=='ca8b5d3a7c679dcc5ad9a3d7b2bbd38f664c90e6474cf3e3c28496d5b716d1b3'
        and retained12['all_inputs_unchanged'] is True and len(retained12['reference_provenance_checks'])==11
        and all(v is True for v in retained12['reference_provenance_checks'].values()))
    inherited=original(legacy_prefix+'inherited16/report.json',checked=False)
    frozen=base.decode(sources['validation/native-dropout/reports/inherited-16.json'])
    audit.check('544 inherited23+partial14 never relabelled',inherited['inherited_optimizer_mapping']==frozen['inherited_optimizer_mapping']
        and len(inherited['steps'])==16 and [(r['name'],r['report_status']) for r in inherited['steps']]==[(r['name'],r['report_status']) for r in frozen['steps']])
    public_ten_receipt=None
    for row in inherited['steps']:
        source_argv(row['command'],'544 original16 '+row['name'])
        child=original(legacy_prefix+'inherited16/'+row['report_path'],row['report_sha256'],False)
        old=base.decode(sources['validation/native-dropout/reports/inherited-'+row['name']+'.json'])
        audit.check('544 inherited original scope status '+row['name'],row['exit_code']==0 and child['status']==row['report_status'])
        for key in ('counts','qualified_groups','partial_groups','failed_groups','qualified_variants','unrepresented_variants','failed_variants',
                    'qualified','failed','mismatch_fields','cases','passed','refusal_cases','unexpected_failures','failures','qualified_exposed_scope',
                    'partial_cases','open_not_executed_cases','state_version_difference_observations','state_creation_difference_observations',
                    'adam_compared_values_with_different_bits','native_step_Tensor_absence_observations','Adam_different_bits',
                    'parameter_values_versions_gradient_presence_and_skip_passed'):
            if key in old:
                if row['name']=='original-public-ten' and key=='cases':
                    public_ten_receipt=public_ten_cases(audit,base,child,old,
                        legacy_prefix+'inherited16/original-public-ten',files,metadata,sources)
                else:exact_fields(audit,child,{key:old[key]},'544 original16 preserved '+row['name'])
        for suffix in ('stdout','stderr'):
            audit.check('544 inherited original streams '+row['name']+'/'+suffix,metadata[legacy_prefix+'inherited16/'+row['name']+'.'+suffix]['sha256']==row[suffix+'_sha256'])
    resource_fields={
        'resources6':{'case_count':6,'passed':6,'failed':0,'frames_before_EOF':527,'checks':157,'complete_rollback_bytes':44811376,
            'module_count':11,'native_executed':True,'complete_six_case_plan_selected':True,'source_custody_after':True},
        'owned-entry5':{'case_count':5,'passed':5,'linked_modules':12,'native_probe_processes':46,'interactive_frames':33,
            'complete_owner_bytes_compared':32155104,'source_custody_after':True},
        'typed-handoff2':{'case_count':2,'passed':2,'failed':0,'linked_modules':23,'frame_count':13,'rollback_bytes':1398048,
            'EOF_exit_code':0,'source_custody_after':True,'previous_source_sha256':PARENT_SOURCE,'previous_native_sha256':PARENT_IMAGE}}
    for name,fields in resource_fields.items():exact_fields(audit,original(name+'/report.json'),fields,'544 fixed outer '+name)
    checked=aggregate['checked_inputs'];audit.check('544 nonempty complete actual input ledger',isinstance(checked,dict) and bool(checked))
    stack=PurePosixPath(opts['--compiler']).parents[1]
    tools={opts['--compiler']:COMPILER,opts['--linker']:LINKER,opts['--flat-compiler']:FLAT,str(stack/'native/stack-linker-runtime'):RUNTIME_LINKER}
    required.update(tools)
    parent_report=reports['hosted-native-dropout-native.json'];parent_checked=parent_report['checked_inputs']
    _,parent_opts=kwargs(parent_report['commands'][0]['argv']);parent_live=PurePosixPath(parent_opts['--output'])/'native'
    parents={'build.json':aggregate['parent_build']['build_report_sha256'],'runtime.hepta':PARENT_SOURCE,'tensor-dtype-dropout-session':PARENT_IMAGE}
    for unit in parent_profile['units']:
        for suffix,field in (('.hepta','source_sha256'),('.o','object_sha256')):parents[unit['name']+suffix]=unit[field]
    audit.check('544 parent is same actual fresh523 build',aggregate['parent_build']==parent_report['new_build']
                and parent_summary['status']=='ACTUAL_FRESH_523_EVIDENCE_VERIFIED')
    required.update(str(parent/name) for name in parents)
    audit.check('544 exact required checked-input set',required==set(checked),required_count=len(required),actual_count=len(checked))
    categories=Counter()
    for path,pin in checked.items():
        p=PurePosixPath(path)
        if p.is_relative_to(root):
            expected=metadata[p.relative_to(root).as_posix()];categories['current_archived_output']+=1
        elif p.is_relative_to(parent):
            name=p.relative_to(parent).as_posix();assert name in parents
            expected=parent_checked[str(parent_live/name)];categories['fresh_parent_build']+=1
            audit.check('544 exact parent source/object '+name,expected['sha256']==parents[name])
        elif path in tools:
            expected=parent_checked[path];categories['pinned_native_tool']+=1
            audit.check('544 actual same frozen compiler/linker '+path,expected['sha256']==tools[path])
        elif p.is_relative_to(repo):
            expected=tracked[p.relative_to(repo).as_posix()];categories['target_tree_source']+=1
        else:audit.check('544 no unknown input namespace '+path,False);raise AssertionError(path)
        mode=int(expected['mode'],8)&0o777 if isinstance(expected['mode'],str) else expected['mode']
        audit.check('544 every input exact original SHA bytes mode '+path,set(pin)=={'sha256','bytes','mode'}
            and pin['sha256']==expected['sha256'] and pin['bytes']==expected['bytes'] and pin['mode']==mode)
    transport_count=transport_frames=0
    for name,raw in files.items():
        if not name.endswith('/transport.json'):continue
        d=base.decode(raw)
        if not {'frames','rows','exit_code','responses_before_stdin_eof'}<=set(d):continue
        prefix=str(PurePosixPath(name).parent);request=wire[prefix+'/requests.frames.bin'];response=wire[prefix+'/responses.frames.bin']
        audit.check('544 complete live request/response/EOF '+name,d['frames']==len(d['rows'])==len(request)==len(response)
            and d['exit_code']==0 and d['responses_before_stdin_eof'] is True
            and all(r['pid']==d['pid'] and r['stdin_open'] is True and r['frame']==i+1 and r['response_bytes']==response[i] for i,r in enumerate(d['rows'])))
        transport_count+=1;transport_frames+=len(request)
    audit.check('544 original live traces present',transport_count>0 and transport_frames>0)
    audit.check('544 separate live32/full35 not inferred',aggregate['separate_required_CI_gates']=={
        'live32':'NOT_EXECUTED_BY_NATIVE_COORDINATOR','complete_accounted35_and_copied18':'NOT_EXECUTED_BY_NATIVE_COORDINATOR',
        'no_inference_from_old_profile_or_inherited_suites':True})
    exact_fields(audit,aggregate['counts'],{'producer_top_level_steps':10,'legacy_behavior_gates':12,'inherited_named_suites_with_original_OPENs':16,
        'actual_reference_foundation_cases':54,'alias_reference_cases':8,'RNE_integers':1237,'promotion_reference_cases':20,
        'view_base_reference_cases':6,'independent_inplace_reference_cases':40,'native_resource_controls':6,'native_entry_controls':5,'native_typed_directions':2},'544 bounded counters')
    return {'status':'ACTUAL_FRESH_544_EVIDENCE_VERIFIED','source_sha256':SOURCE,'native_sha256':IMAGE,'coordinator_sha256':QUALIFIER,
        'outer_commands':4,'producer_steps':10,'actual_units':11,'actual_archive_members':manifest['members'],
        'actual_archive_bytes':len(packed),'all_original_members_SHA_size_mode_verified':True,'single_XZ_EOF':True,
        'nested_archives':expanded_receipts,'checked_inputs':len(checked),'checked_input_categories':dict(categories),
        'actual_transport_count':transport_count,'actual_transport_frames':transport_frames,'unit_members':unit_members,
        'old_legacy_status_boundaries_preserved':True,'original_public_ten':public_ten_receipt,
        'additional_native_or_Torch_execution':False}

def source_inverses(audit,sources):
    prefix='tests/integer_frozen35_accounting/'
    proof=base_decode(sources['validation/integer-frozen35-accounting/profile-adaptation.json'])
    audit.check('544 source-only adaptation remains source-only',proof['status']=='SOURCE_PREPARED_NOT_EXECUTED'
        and proof['no_native_or_Torch_execution_by_adapter'] is True and proof['all_legacy_numeric_and_18_refusal_assertions_retained'] is True)
    names={'owner640_fixed35.py':'owner640_storage_tombstone.py','owner_accounting_int64.py':'owner_accounting523.py',
           'run_frozen35_accounted.py':'run_frozen35_accounted.py','check_frozen35_accounted.py':'check_frozen35_accounted.py',
           'check_owner_snapshots.py':'check_owner_snapshots.py','test_storage_tombstone.py':'test_storage_tombstone.py'}
    audit.check('544 exact six declared inverse files',set(proof['inverse_proofs'])==set(names))
    for name,parent in names.items():
        row=proof['inverse_proofs'][name];raw=sources[prefix+name];old=sources['tests/dtype_frozen35_accounting/'+parent]
        audit.check('544 exact original/derived source pins '+name,sha(raw)==row['derived_sha256'] and sha(old)==row['original_sha256'])
        restored=raw.decode();old_text=old.decode();end=len(restored)
        for edit in reversed(row['edits']):
            a,b=edit['new_start'],edit['new_end']
            audit.check('544 inverse bounded nonoverlapping hunk '+name,0<=a<=b<=end
                and restored[a:b]==edit['after'] and old_text[edit['old_start']:edit['old_end']]==edit['before'])
            restored=restored[:a]+edit['before']+restored[b:];end=a
        audit.check('544 complete byte-for-byte parent inverse '+name,restored.encode()==old)
    manifest=base_decode(sources['validation/integer-frozen35-accounting/source-package-manifest.json'])
    rows=manifest['files'];rows=[dict(r,path=k) for k,r in rows.items()] if isinstance(rows,dict) else rows
    audit.check('544 complete observer source manifest',len(rows)==len({r['path'] for r in rows})==manifest['files_count']
        and manifest['status']=='PREPARED_NOT_RUN' and manifest['full35_executed_by_source_handoff'] is False)
    for row in rows:
        raw=sources[row['path']]
        audit.check('544 observer manifest every actual source '+row['path'],sha(raw)==row['sha256'] and len(raw)==row['bytes'])

def base_decode(raw):
    def unique(pairs):
        result={}
        for k,v in pairs:assert k not in result;result[k]=v
        return result
    return json.loads(raw,object_pairs_hook=unique)


def load_pure(audit,bundle,sources):
    path=bundle/'source/tests/integer_frozen35_accounting/owner_accounting_int64.py'
    audit.check('544 pure full80word observer exact source',sha(path.read_bytes())==OBSERVER)
    spec=importlib.util.spec_from_file_location('independent_offline_integer_fixed35_640',path)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    audit.check('544 exact source profile loaded without native capture',sha((path.parent/'profile.json').read_bytes())==PROFILE
        and module.DESC_BYTES==640 and module.CONFIG['source_sha256']==SOURCE and module.CONFIG['native_sha256']==IMAGE)
    for key,relative,pin in (
        ('legacy_owner_rules','tests/integer_frozen35_accounting/legacy_owner_rules.py','281f1ea437046a9cd884de2c8da34f38649a3b6482ade23123ac4aa992faed64'),
        ('structural_owner640','tests/integer_frozen35_accounting/owner640_fixed35.py','d40fb59a74edfaf87113e7eac1e13587c7e8d33aa6ca1edea36a7e9da7bbde89'),
        ('original_structural_owner640','tests/dtype_owner_accounting/owner640.py','6ea9e8b33164089034a2a71a03f4850e1ec18ed1a09155d7841f700ef311c833')):
        audit.check('544 pure dependency exact '+key,sha(sources[relative])==pin)
    return module

def copied18(audit,base,members,report,pure,sources):
    audit.check('544 copied18 original exact source and outcomes',report['status']=='PASS_OBSERVER_CONTROLS_ONLY'
        and report['failures']==0 and report['positive_cases']==len(report['positive_rows'])==4
        and report['negative_cases']==len(report['negative_rows'])==18 and report['observer_sha256']==OBSERVER
        and report['controls_sha256']==CONTROLS and report['expected_profile']==MODEL['name']
        and report['original_journals_unchanged'] is report['observer_source_unchanged'] is True
        and all(report[k] is False for k in ('native_executed','Torch_executed','native_memory_read','native_memory_written')))
    audit.check('544 copied-control original source bytes archived',
        sha(base.one_suffix(members,'/copied-controls/executed-controls.py'))==CONTROLS
        and sha(base.one_suffix(members,'/copied-controls/observer-under-test.py'))==OBSERVER)
    tree=ast.parse(sources['tests/integer_frozen35_accounting/check_owner_snapshots.py'])
    calls=sorted((n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='run'),key=lambda n:n.lineno)
    rules=[(ast.literal_eval(n.args[0]),ast.literal_eval(n.args[1]),ast.literal_eval(n.args[3])) for n in calls]
    audit.check('544 all18 exact original rules and order',len(rules)==18
        and [(r['case'],r['expected_rule']) for r in report['negative_rows']]==[(n,r) for n,_,r in rules])
    audit.check('544 four original real-positive categories',{r['case'] for r in report['positive_rows']}=={
        'materialization','compound-construction','reset-with-private-gradient','failed-frame-rollback'})
    chosen={}
    for row in report['positive_rows']:
        event=base.event_input(members,row['journal'],row['event'])
        audit.check('544 positive original event hash '+row['case'],row['status']=='PASS' and sha(base.canonical(event))==row['input_sha256']
            and event['recorded_result']==row['result'] and event['before']['profile']==event['after']['profile']==MODEL['name'])
        result=pure.verify_transition(event['before'],event['after'],event['tickets'],event['commands'],event['status'])
        audit.check('544 pure JSON positive exact result '+row['case'],result==row['result'])
        chosen[row['case']]=event
    for row,(name,parent,rule) in zip(report['negative_rows'],rules):
        packed=base.one_suffix(members,'/negative-inputs/'+name+'.json.gz');raw=gzip.decompress(packed);changed=base.decode(raw);original=chosen[parent]
        audit.check('544 negative exact saved input '+name,sha(packed)==row['compressed_sha256'] and sha(raw)==row['input_sha256']
            and row['status']=='PASS_EXPECTED_REJECTION' and row['expected_rule']==row['actual_rule']==rule)
        audit.check('544 isolated copied-negative original-side preservation '+name,changed['before']==original['before']
            and base.canonical(changed)!=base.canonical(original)
            and row['source_event']=={'journal':original['path'],'event':original['ordinal']}
            and all(changed[k]==original[k] for k in ('path','ordinal','commands','status','recorded_result')))
        try:pure.verify_transition(changed['before'],changed['after'],changed['tickets'],changed['commands'],changed['status'])
        except AssertionError as error:
            detail=error.args[0] if error.args else None
            audit.check('544 pure JSON exact old rejection '+name,isinstance(detail,dict) and detail.get('observer_rule')==rule)
        else:audit.check('544 pure JSON exact old rejection '+name,False)
    for path,pin in report['input_files'].items():
        name=base.original_build_relative(path)
        audit.check('544 every copied control original input '+name,name in members and len(members[name])==pin['bytes'] and sha(members[name])==pin['sha256'])
    return {'actual_prior_native_journals':True,'pure_positive_cases_rechecked':4,'pure_negative_cases_rechecked':18,
            'original_18_rule_names_unchanged':True,'new_native_or_Torch_executions':0}

def tombstone(audit,base,members,report,pure,sources):
    audit.check('544 actual tombstone fixed native1 copied4 workload',report['schema']=='heptatorch.Storage-tombstone-observer-regression.v1'
        and report['status']=='PASS' and report['native_executed'] is True and report['Torch_executed'] is False
        and report['native_cases']==1 and report['copied_negative_cases']==len(report['negative_rows'])==4
        and report['frames']==6 and report['EOF_exit_code']==0 and report['inputs_after_unchanged'] is True
        and report['numeric_API_cases']==0 and report['whole_pytorch_gate']=='HOLD' and report['full_pytorch_parity'] is False)
    audit.check('544 original tombstone test source',report['inputs']['executed_test']['sha256']==sha(sources['tests/integer_frozen35_accounting/test_storage_tombstone.py']))
    snapshots={}
    for name,pin in report['snapshot_files'].items():
        packed=base.one_suffix(members,'/storage-tombstone/'+pin['path']);raw=gzip.decompress(packed)
        audit.check('544 actual tombstone full snapshot '+name,len(raw)==pin['bytes'] and sha(raw)==pin['sha256'] and sha(packed)==pin['compressed_sha256'])
        value=base.decode(raw);pure.verify_snapshot(value);snapshots[name]=value
    audit.check('544 all four tombstone states',set(snapshots)=={'before-last-strong-drop','after-last-strong-drop','after-expired-weak-lock','after-last-weak-drop'})
    before=snapshots['before-last-strong-drop'];after=snapshots['after-last-strong-drop']
    slots=[i for i,r in enumerate(before['tables']['2']) if r==report['before_storage']]
    audit.check('544 unique actual expired Storage row',len(slots)==1)
    slot=slots[0];prior=before['tables']['2'][slot];expired=after['tables']['2'][slot]
    audit.check('544 actual retained requested-byte metadata',prior[3:8]==[12,16,1,2,0]
        and expired==report['expired_storage']==[prior[0],1,0,12,0,0,1,1]
        and sum(n for _,n in after['free_extents'])==sum(n for _,n in before['free_extents'])+16)
    audit.check('544 failed Weak lock exact committed state',snapshots['after-expired-weak-lock']==after and report['weak_lock_rollback_bytes']>0)
    audit.check('544 last Weak releases exact tombstone row',snapshots['after-last-weak-drop']['tables']['2'][slot]==[prior[0]]+[0]*7)
    audit.check('544 original6ea error preserved',report['preserved_original_observer_refusal']['observer_rule']=='expired-Storage-extent')
    rules=[('expired-offset-nonzero',2,16,'expired-Storage-extent'),
           ('expired-rounded-nonzero',4,16,'expired-Storage-extent'),
           ('expired-requested-outside-pool',3,after['header']['pool']+1,'expired-Storage-requested-bound'),
           ('expired-requested-changed',3,8,'expired-Storage-requested-preserved')]
    audit.check('544 all four exact tombstone refusal rows',[(r['case'],r['expected_rule']) for r in report['negative_rows']]==[(n,rule) for n,_,_,rule in rules])
    # Reconstruct the exact original drop command from the archived third request.
    raw=base.one_suffix(members,'/storage-tombstone/transport/requests.frames.bin');offset=0;bodies=[]
    while offset<len(raw):
        assert raw[offset:offset+8]==b'HTOWNR01'
        n=struct.unpack_from('<Q',raw,offset+8)[0];bodies.append(raw[offset+16:offset+16+n]);offset+=16+n
    audit.check('544 original tombstone six request frames',offset==len(raw) and len(bodies)==6)
    command=list(struct.unpack_from('<8Q',bodies[2],32));assert command[0]==41
    result=pure.verify_transition(before,after,[],[command])
    audit.check('544 pure original tombstone transition',result==report['transition'])
    for row,(name,index,value,rule) in zip(report['negative_rows'],rules):
        raw=gzip.decompress(base.one_suffix(members,'/storage-tombstone/'+name+'.json.gz'))
        changed=base.decode(raw);expected=copy.deepcopy(after);expected['tables']['2'][slot][index]=value
        audit.check('544 exact one-word copied tombstone mutation '+name,changed==expected and sha(raw)==row['input_sha256']
            and row['status']=='PASS_EXPECTED_REJECTION' and row['actual_rule']==rule)
        try:pure.verify_transition(before,changed,[],[command])
        except AssertionError as error:
            detail=error.args[0] if error.args else None
            audit.check('544 independent pure tombstone refusal '+name,isinstance(detail,dict) and detail.get('observer_rule')==rule)
        else:audit.check('544 independent pure tombstone refusal '+name,False)
    return {'native_cases_executed_by_CI':1,'native_frames':6,'copied_refusals_rechecked':4,'extra_native_or_Torch_executions':0}

def inherited_review_oracles(audit,base,spec,ctx,main_bytes,reports,sources,bundle,plan32,plan35):
    source_inverses(audit,sources)
    pure=load_pure(audit,bundle,sources)
    live=audit.live32(main_bytes['pytorch-integer-tensors-backward.json'],MODEL,'main544 live32',plan32)
    saved=base.OBSERVER,base.LAUNCHER
    base.OBSERVER,base.LAUNCHER=OBSERVER,LAUNCHER
    try:
        d,w=audit.frozen35(main_bytes['pytorch-integer-tensors-frozen35.json'],main_bytes['pytorch-integer-tensors-frozen35-original.json'],
                         MODEL,'pytorch-integer-tensors-frozen35-original.json','main544 frozen35',plan35)
    finally:base.OBSERVER,base.LAUNCHER=saved
    audit.pip_binding(main_bytes['pytorch-install.json'],[live['oracle_provenance'],d['oracle_provenance']],'main544 actual install')
    for key,path in {
        'legacy_owner_rules':'tests/integer_frozen35_accounting/legacy_owner_rules.py',
        'structural_owner640':'tests/integer_frozen35_accounting/owner640_fixed35.py',
        'original_structural_owner640':'tests/dtype_owner_accounting/owner640.py',
        'storage_tombstone_correction':'tests/integer_frozen35_accounting/storage-tombstone-correction.json',
        'accounting_profile':'tests/integer_frozen35_accounting/profile.json'}.items():
        audit.check('544 full35 actual additional source custody '+key,w['source_custody'][key]['sha256']==sha(sources[path]))
    audit.check('544 real full80word profile and inverse',w['profile']['descriptor_bytes']==640
        and w['profile']['source_constructor_costs'] is True and w['profile']['inverse_proof']==pure.inverse_proof())
    members,official=audit.archive(spec)
    audit.check('544 dtype journal original artifact same run and attempt',official['workflow_run']['id']==ctx['run']['id']
        and official['name']==f"integer-node-journals-{ctx['run']['id']}-{ctx['run']['run_attempt']}-native")
    mirror_names=('pytorch-integer-tensors-frozen35.json','pytorch-integer-tensors-frozen35-original.json',
                  'pytorch-integer-tensors-frozen35-observer-controls.json','integer-tensors-storage-tombstone.json',
                  'pytorch-integer-tensors-backward.json','pytorch-install.json')
    audit.custody(members,official,ctx,{n:main_bytes[n] for n in mirror_names},'544 complete original journals')
    audit.journals(members,d['rows'],'544 actual frozen35 full640')
    # The snapshot verifier consumes the real full80-word structure; no576 projection is made.
    total_snapshots=0
    for name,packed in members.items():
        if not name.endswith('/snapshots.jsonl.gz'):
            continue
        for line in gzip.decompress(packed).splitlines():
            item=base.decode(line);snapshot=item['snapshot']
            audit.check('544 complete full80word snapshot '+name,all(len(n)==80 for n in snapshot['nodes'].values())
                and snapshot['profile']==MODEL['name'] and sha(base.canonical(snapshot))==item['sha256'])
            pure.verify_snapshot(snapshot);total_snapshots+=1
    audit.check('544 full35 snapshots actually present',total_snapshots>0)
    transitions=recheck_all_transitions(audit,base,members,d['rows'],pure)
    neg=copied18(audit,base,members,reports['pytorch-integer-tensors-frozen35-observer-controls.json'],pure,sources)
    stone=tombstone(audit,base,members,reports['integer-tensors-storage-tombstone.json'],pure,sources)
    return {'status':'ACTUAL_544_LIVE32_FROZEN35_AND_RAW_VERIFIED','live32':32,'frozen35':35,'frames':6344,'compared_values':2590274,
        'legacy_state_version_differences_preserved':283,'direct_parameter_version_mismatches':0,
        'all35_original_EOF_and_Version_postconditions_executed':True,'full640_snapshot_count':total_snapshots,
        'pure_all35_transitions':transitions,'copied18':neg,'tombstone':stone,'extra_native_or_Torch_executions':0}

def recheck_all_transitions(audit,base,members,rows,pure):
    """Recompute every original full640 event from original immutable snapshots."""
    all_paths={n for n in members if n.endswith('/events.json')};seen=set();total=0;ledger=[]
    audit.check('544 full35 transition case coverage',len(rows)==len({r['case'] for r in rows})==35)
    for row in rows:
        folder=base.original_build_relative(row['private_node_observer']['snapshot_directory'])
        ep=folder+'/events.json';sp=folder+'/snapshots.jsonl.gz'
        audit.check('544 exact case event path '+row['case'],ep in all_paths and ep not in seen and sp in members)
        seen.add(ep);events=base.decode(members[ep]);snapshots={}
        for line in gzip.decompress(members[sp]).splitlines():
            item=base.decode(line);key=item['sha256'];snapshot=item['snapshot']
            audit.check('544 full-transition original snapshot '+row['case'],
                key not in snapshots and sha(base.canonical(snapshot))==key and snapshot['profile']==MODEL['name'])
            snapshots[key]=snapshot
        audit.check('544 transition exact original frame count '+row['case'],
            len(events)==row['frames']==row['private_node_observer']['frames_checked'])
        used=set()
        for ordinal,event in enumerate(events):
            audit.check('544 transition actual exact schema '+row['case']+'/'+str(ordinal),
                set(event)=={'before','after','tickets','commands','expected_status','result','error'}
                and event['error'] is None and type(event['expected_status']) is int
                and event['before'] in snapshots and event['after'] in snapshots)
            used.update((event['before'],event['after']))
            result=pure.verify_transition(snapshots[event['before']],snapshots[event['after']],
                                          event['tickets'],event['commands'],event['expected_status'])
            audit.check('544 pure original full640 transition '+row['case']+'/'+str(ordinal),result==event['result'])
            total+=1
        audit.check('544 transition no unreferenced or omitted snapshots '+row['case'],used==set(snapshots))
        ledger.append({'case':row['case'],'path':ep,'events':len(events),'events_sha256':sha(members[ep])})
    audit.check('544 every archived journal belongs to exactly one original case',seen==all_paths)
    audit.check('544 all6344 original transitions independently recomputed',total==6344)
    return {'original_cases':35,'original_frames':total,'all_original_results_recomputed_equal':True,
            'case_journals':ledger,'native_or_Torch_executed':False}

def review_oracles(audit,base,spec,ctx,main_bytes,reports,sources,bundle,plan32,plan35):
    """Retain all old35 checks, then enforce the new profile's exact native body pins."""
    result=inherited_review_oracles(audit,base,spec,ctx,main_bytes,reports,sources,bundle,plan32,plan35)
    cfg=base.decode(sources['tests/integer_frozen35_accounting/profile.json'])
    raw=audit.integer_runtime_raw
    bodies={name.decode():body for body,name in re.findall(
        rb"^(fn ([A-Za-z_][A-Za-z_0-9]*)\([^\n]* entry\([A-Za-z_][A-Za-z_0-9]*\)\n.*?^end\n)",raw,re.M|re.S)}
    audit.check('544 entire cold HIA body count and source digest',sha(raw)==SOURCE and len(bodies)==544)
    for name,pin in cfg['function_pins'].items():
        audit.check('544 exact accounting HIA function '+name,name in bodies and sha(bodies[name])==pin)
    for target,expected in cfg['capture_callers'].items():
        callers=[name for name,body in bodies.items() if ('"function":"'+target+'"').encode() in body]
        audit.check('544 exact source caller coverage '+target,sorted(callers)==sorted(expected))
    wrapper=reports['pytorch-integer-tensors-frozen35.json']
    audit.check('544 actual complete function and caller profile',wrapper['profile']['function_pins']==cfg['function_pins']
        and wrapper['profile']['capture_callers']==cfg['capture_callers']
        and wrapper['profile']['accounting_domain']==cfg['fixed35_domain'])
    audit.check('544 additional actual adaptation source custody',
        wrapper['source_custody']['structural_profile_adaptation']['sha256']==sha(sources['tests/integer_frozen35_accounting/structural-profile-adaptation.json']))
    stone=reports['integer-tensors-storage-tombstone.json']
    audit.check('544 original6ea predicate profile binding is explicit copied-only metadata',stone['original_predicate_profile_binding']=={
        'source_sha256':SOURCE,'native_sha256':IMAGE,'profile':MODEL['name'],'function_code_changed':False,
        'purpose':'copied JSON predicate replay only; old native profile not relabelled'})
    result.update(fixed35_only_F32_domain=True,general_I64_role_verification_claimed=False,
        every_full80_word_node_has_zero_unrequested_dtype_history_roles=True,all_native_function_and_capture_pins_verified=True)
    return result
