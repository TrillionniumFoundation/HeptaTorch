"""Explain executed check multiplicities; never normalize admission inputs."""
from collections import Counter
import hashlib,json,re,zipfile
from pathlib import Path
P=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
paths={'pr':P/'pr-admission-343-r03-sequential-02/report.json','push':P/'push-admission-343-r03/report.json'}
reports={k:json.loads(p.read_bytes()) for k,p in paths.items()}
# These replacements apply solely to a diagnostic Counter of already-passed
# check labels. They are not used by any reader, on original JSON, on a digest,
# on an expected value, or on a gate result.
def label_category(s):
    s=re.sub(r'/build/(\.[^ /]+-review)\.[^ /]+',r'/build/\1.RUN',s)
    s=s.replace('native-pr-inputs-343.json','native-ROLE-inputs-343.json').replace('native-push-inputs-343.json','native-ROLE-inputs-343.json')
    s=re.sub(r'/official-final/(?:pr|push)-(run|jobs|artifacts)\.json',r'/official-final/ROLE-\1.json',s)
    s=re.sub(r'/original-zips/([^ /]+)-(?:pr|push)\.zip',r'/original-zips/\1-ROLE.zip',s)
    s=s.replace('/official-first/merge.json','/official-first/CHECKOUT.json').replace('/official-first/source.json','/official-first/CHECKOUT.json')
    s=s.replace('PR merge parents bind exact base and head','actual checkout identity bound').replace('direct checkout exact source head','actual checkout identity bound')
    return re.sub(r'/((?:positive-)?snapshots)/[0-9a-f]{64}\.json\.gz',r'/\1/CURRENT-SNAPSHOT.json.gz',s)

counter={k:Counter(label_category(x['check']) for x in r['checks']) for k,r in reports.items()}
assert counter['pr']-counter['push']==Counter()
assert counter['push']-counter['pr']==Counter({'523 no concatenated XZ member':1})
source=P/'reader-full-r03/native_dropout_evidence.py';raw=source.read_bytes()
assert sha(raw)=='1fc0cfc18323ee598f59832d447d88eba32d5007fa4545cbc708fefc04aefbc8'
literal=b"    for offset in range(0,len(packed),1048576):\n        audit.check('523 no concatenated XZ member',not dec.eof)"
assert literal in raw
rows={}
for role in paths:
    with zipfile.ZipFile(P/'original-zips'/('native-dropout-evidence-'+role+'.zip')) as z:
        packed=z.read('native-dropout-ci-raw.tar.xz')
    n=(len(packed)+1048575)//1048576
    checks=reports[role]['checks']
    actual=sum(x['check']=='523 no concatenated XZ member' for x in checks)
    assert actual==n and all(x['passed'] is True for x in checks)
    assert sum(x['check']=='523 complete single XZ EOF and tar-byte digest' and x['passed'] for x in checks)==1
    rows[role]={'report_sha256':sha(paths[role].read_bytes()),'checks_passed':reports[role]['checks_passed'],
        'packed_native_dropout_XZ_bytes':len(packed),'packed_native_dropout_XZ_sha256':sha(packed),
        'chunk_bytes':1048576,'executed_per_chunk_assertions':actual,'complete_single_XZ_EOF_and_tar_digest_passed':True}
assert rows['pr']['packed_native_dropout_XZ_bytes']==4189036
assert rows['push']['packed_native_dropout_XZ_bytes']==4211232
result={'schema':'heptatorch.pr33.executed-check-count-explanation.v1','status':'EXACT_CAUSE_VERIFIED',
    'source_sha256':sha(raw),'source_literal':literal.decode(),'rows':rows,
    'diagnostic_label_categories_only':True,'all_other_check_category_multiplicities_equal':True,
    'only_extra_push_check':'523 no concatenated XZ member',
    'cause':'The two actual compressed archives straddle 4 MiB. The unchanged 1 MiB loop executes four versus five checks; both full EOF and tar-byte-digest checks pass.',
    'admission_rules_changed':False,'original_reports_or_values_normalized':False,'extra_native_or_Torch_executions':0}
out=P/'check-count-difference.json';assert not out.exists()
out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2))
