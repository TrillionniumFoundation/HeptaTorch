"""Read-only admission of fresh native523 evidence and its separate oracle.

No producer, compiler, native ELF or Torch is executed here. Original CI paths
are mapped to authenticated archive/source namespaces without rewriting them.
"""
import ast
from collections import Counter
import copy
import gzip
import hashlib
import importlib.util
import io
import json
import lzma
from pathlib import Path, PurePosixPath
import struct
import sys
import tarfile
import types

SOURCE='6ffe509afce28ff15705b4c7b269eaef8f8f89f9d8b2486d4d9fa45b6be66ef3'
IMAGE='830f0b4ef8d6ad8c6a105be56d383628b45c84e3e43905fee6812c7c52d35a51'
QUALIFIER='5c997334bfbb3fc11accce45a6a5f770f0f61f35f19b08d140b28fae8451440b'
OBSERVER='4cd9c3d1fafd1eee04ac1b2b8bb720a099d53dc821b25b9cf4380e6c67b36a71'
LAUNCHER='1dca385159d332ed75adb57c1173b6a0b010597adabf5fe38001d97d1ea769d2'
CONTROLS='f011b4f60988516ee0e7137156ad4c3986bc39ec27cc09b12b9d48aa787f5753'
PROFILE='83f673c3f1ff4fe3fa7a2f35749326ff8eeeaa60df570da080bc82d8712e683b'
PARENT_SOURCE='666230f05cc6942470006d1f184135321d8cbc26a6c6ba0bf7e3cf9857fe515b'
PARENT_IMAGE='7568c0a4ec40d82d3a0b46d1e8a27499dd96e8fe3fd15433523131a196da89b5'
COMPILER='b1c851a0896fa6071f800e1146c3c27d0c6cf85059e9a6281b46d42908a3f59f'
LINKER='aae650e8822ef0b1e74d15108ad1d0f17ec791205ed5a158ec60b709f48f0e16'
RUNTIME_LINKER='0c5176e3aa968631ae592b887c5dc3cf1e8e3f48f73593f076e9d7965ffacfd7'
FLAT='c5a9c2b95a3061e080a21298f5b26000936ed9dac519690d845b0699a15744c6'
MODEL={'name':'dtype-native-dropout-523','source':SOURCE,'image':IMAGE}
OUTER=('producer13','actual-identity9','actual-detach26','typed-handoff2','owned-entry5','owner640')
PRODUCER=('cold-native-build','typed-slice','typed-lifetimes','bool-logical-not','dtype-admission101',
          'owned-allocation','history-mul-controls8','actual-native-dropout28','original-native-dropout8',
          'actual-existing-optimizer6','actual-sgd-effective-layout6','actual-retained12','inherited16')
SELF_EXCLUSIONS={'report.json','evidence-manifest.json','raw-evidence.tar.xz'}
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def kwargs(argv):
    index=next(i for i,x in enumerate(argv) if x.endswith('.py'))
    assert index>0 and len(argv[index+1:])%2==0
    out={}
    for k,v in zip(argv[index+1::2],argv[index+2::2]):
        assert k.startswith('--') and k not in out
        out[k]=v
    return argv[index],out

def runtime(audit,doc,label):
    ss=[doc[k] for k in ('source_sha256','native_source_sha256','runtime_source_sha256') if k in doc]
    es=[doc[k] for k in ('native_sha256','binary_sha256','executable_sha256','native_executable_sha256') if k in doc]
    audit.check(label+': exact523 source and ELF',bool(ss) and bool(es) and all(s==SOURCE for s in ss) and all(e==IMAGE for e in es))

def shape_fields(value):
    """Only fixed scope/identity labels, never OS paths, PIDs or native values."""
    result={k:value[k] for k in ('name','case','index','family','variant','status','reference_status') if k in value}
    for key in ('rows','variants','records'):
        if isinstance(value.get(key),list):
            result[key]=[shape_fields(x) for x in value[key] if isinstance(x,dict)]
    return result

def stream_frames(raw,magic):
    offset=0;rows=[]
    while offset<len(raw):
        assert len(raw)-offset>=16 and raw[offset:offset+8]==magic
        size=struct.unpack_from('<Q',raw,offset+8)[0]
        assert size<=1048576 and size<=len(raw)-offset-16
        rows.append(size);offset+=16+size
    assert offset==len(raw)
    return rows

def raw_archive(audit,base,packed,manifest):
    audit.check('523 raw exact manifest schema and byte-only status',
        manifest['schema']=='heptatorch.native-dropout-fresh-raw-evidence.v1' and manifest['status']=='VERIFIED'
        and manifest['source_sha256']==SOURCE and manifest['native_sha256']==IMAGE
        and manifest['all_member_bytes_modes_sizes_verified'] is True and manifest['xz_stream_verified_through_EOF'] is True)
    listed=manifest['files']
    audit.check('523 actual archive nonempty complete manifest',bool(listed) and len(listed)==manifest['members']
        and sum(x['bytes'] for x in listed.values())==manifest['uncompressed_bytes'] and not SELF_EXCLUSIONS.intersection(listed))
    audit.check('523 actual archive exact bytes',len(packed)==manifest['archive_bytes'] and sha(packed)==manifest['archive_sha256'])
    files={};seen=set();wire={}
    with tarfile.open(fileobj=io.BytesIO(packed),mode='r|xz') as stream:
        for member in stream:
            name=base.member_name(member.name)
            audit.check('523 raw ordinary unique member '+name,member.isfile() and name not in seen and name in listed)
            seen.add(name);expected=listed[name]
            raw=stream.extractfile(member).read()
            audit.check('523 raw exact SHA length mode '+name,
                member.size==len(raw)==expected['bytes'] and member.mode==expected['mode'] and sha(raw)==expected['sha256'])
            if name.endswith(('.json','.py','.hepta','.gz')) or (name.endswith(('.stdout','.stderr')) and len(raw)<65536):
                files[name]=raw
            if name.endswith('/requests.frames.bin'):
                wire[name]=stream_frames(raw,b'HTOWNR01')
            elif name.endswith('/responses.frames.bin'):
                wire[name]=stream_frames(raw,b'HTOWNS01')
    audit.check('523 full archive member set equality',seen==set(listed))
    dec=lzma.LZMADecompressor();total=0;h=hashlib.sha256()
    for offset in range(0,len(packed),1048576):
        audit.check('523 no concatenated XZ member',not dec.eof)
        chunk=dec.decompress(packed[offset:offset+1048576]);total+=len(chunk);h.update(chunk)
    audit.check('523 complete single XZ EOF and tar-byte digest',dec.eof and not dec.unused_data
        and total==manifest['decompressed_tar_bytes'] and h.hexdigest()==manifest['decompressed_tar_sha256'])
    return files,listed,wire

def review_native(audit,base,spec,ctx,main_bytes,reports,sources,tracked,parent_summary):
    z,official=audit.archive(spec)
    audit.check('523 native evidence official run and attempt',official['workflow_run']['id']==ctx['run']['id']
        and official['name']==f"native-dropout-native-evidence-{ctx['run']['id']}-{ctx['run']['run_attempt']}-native")
    audit.check('523 native evidence exact three members',set(z)=={'hosted-native-dropout-native.json','native-dropout-ci-raw-manifest.json','native-dropout-ci-raw.tar.xz'})
    for name in ('hosted-native-dropout-native.json','native-dropout-ci-raw-manifest.json'):
        audit.check('523 exact main artifact mirror '+name,z[name]==main_bytes[name])
    aggregate=reports['hosted-native-dropout-native.json'];manifest=reports['native-dropout-ci-raw-manifest.json']
    runtime(audit,aggregate,'523 fresh aggregate')
    audit.check('523 actual fresh successful producer, never historical reuse',aggregate['schema']=='heptatorch.native-dropout-native-integration.v1'
        and aggregate['status']=='PASS' and aggregate['producer_mode']=='FRESH_COLD_REQUIRED'
        and aggregate['producer_executed_this_invocation'] is True and aggregate['producer_completed_this_invocation'] is True
        and aggregate['all_inputs_unchanged'] is True and aggregate['Torch_executed_here'] is False
        and aggregate['closed_schema_count']==0 and aggregate['whole_pytorch_gate']=='HOLD'
        and aggregate['full_pytorch_rewrite_complete'] is False and aggregate['pytorch_api_denominator']==2590
        and not any(k in aggregate for k in ('error','traceback','archive_error','partial_failed_execution_evidence')))
    audit.check('523 exact frozen coordinator source',sha(sources['tests/qualify_native_dropout.py'])==QUALIFIER)
    files,metadata,wire=raw_archive(audit,base,z['native-dropout-ci-raw.tar.xz'],manifest)
    complete=aggregate['complete_current_execution_evidence']
    audit.check('523 aggregate binds fresh archive and exact manifest',
        complete=={'archive':'raw-evidence.tar.xz','archive_sha256':sha(z['native-dropout-ci-raw.tar.xz']),
                   'archive_bytes':len(z['native-dropout-ci-raw.tar.xz']),'manifest':'evidence-manifest.json',
                   'manifest_sha256':sha(z['native-dropout-ci-raw-manifest.json']),'members':len(metadata),
                   'all_members_verified':True,'xz_stream_verified_through_EOF':True})
    commands=aggregate['commands']
    audit.check('523 all six actual outer commands in order',len(commands)==6 and tuple(x['name'] for x in commands)==OUTER)
    script,opts=kwargs(commands[0]['argv']);repo=PurePosixPath(opts['--repository']);root=PurePosixPath(opts['--output']).parent
    parent=PurePosixPath(opts['--parent']);native=root/'producer/native'
    audit.check('523 CI output and source root namespace',repo.is_absolute() and root.is_absolute()
        and root.is_relative_to(repo/'build') and script==str(repo/'tools/native_dropout/qualify.py')
        and opts['--output']==str(root/'producer'))
    required=set();referenced_sources=set()
    def source(name):
        required.add(str(repo/name));return tracked[name]
    def original(name,pin=None):
        assert name in metadata
        if pin is not None:audit.check('523 original child hash '+name,metadata[name]['sha256']==pin)
        required.add(str(root/name));return base.decode(files[name])
    def source_argv(argv,label,custody=True):
        script,values=kwargs(argv);name=PurePosixPath(script).relative_to(repo).as_posix()
        if custody:source(name)
        audit.check(label+': source script admitted in exact target tree',name in tracked)
        for key,value in values.items():
            p=PurePosixPath(value)
            if p.is_absolute() and p.is_relative_to(repo) and not p.is_relative_to(repo/'build'):
                n=p.relative_to(repo).as_posix()
                if n in tracked:referenced_sources.add(n)
        return values
    source('tests/qualify_native_dropout.py')
    source('tools/native_dropout/profile.json');source('tools/retained_gradients/profile.json')
    source('validation/dtype-resource-review/cli.json')
    definitions=base.decode(sources['tools/native_dropout/profile.json'])
    audit.check('523 profile descriptor/counts exact',definitions['source_sha256']==SOURCE and definitions['native_sha256']==IMAGE
        and definitions['descriptor_bytes']==640 and definitions['functions']==523 and len(definitions['units'])==11)
    parent_profile=base.decode(sources['tools/retained_gradients/profile.json'])
    manifests=ast.literal_eval(next(n.value for n in ast.parse(sources['tests/qualify_native_dropout.py']).body
                       if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='MANIFESTS'))
    audit.check('523 exact four declared input manifests',len(aggregate['manifests'])==len(manifests)==4)
    for received,(name,pin,count) in zip(aggregate['manifests'],manifests):
        source(name);raw=sources[name]
        audit.check('523 manifest immutable source '+name,sha(raw)==pin and received['path']==name and received['sha256']==pin
            and received['members']==count and received['all_bytes_modes_lengths_verified'] is True)
        rows=base.decode(raw)['files'];rows=[dict(v,path=k) for k,v in rows.items()] if isinstance(rows,dict) else rows
        audit.check('523 complete declared input members '+name,len(rows)==count and len({x['path'] for x in rows})==count)
        reloc={}
        for row in rows:
            n=row['path']
            if name=='validation/native-dropout/production-handoff-manifest.json' and n=='handoff.json':
                reloc[n]='validation/native-dropout/production-handoff.json';n=reloc[n]
            expected=source(n)
            audit.check('523 manifest input exact target bytes '+n,
                row['sha256']==expected['sha256'] and row.get('bytes',row.get('size'))==expected['bytes']
                and ('mode' not in row or row['mode']==int(expected['mode'],8)&0o777))
        audit.check('523 explicit input relocation '+name,received['explicit_metadata_relocations']==reloc)
    for row in commands:
        name=row['name'];values=source_argv(row['argv'],'523 '+name)
        audit.check('523 outer process really completed '+name,row['status']=='PASS' and row['exit_code']==0
            and row['launch_attempted'] is row['process_started'] is row['process_completed'] is True and type(row['pid']) is int and row['pid']>0)
        audit.check('523 original argv '+name,base.decode(files[name+'.argv.json'])==row['argv'])
        child=original(row['report'],row['report_sha256']);runtime(audit,child,'523 '+name)
        audit.check('523 original outer child succeeded '+name,child['status']=='PASS')
        for suffix in ('stdout','stderr'):
            m=metadata[name+'.'+suffix]
            audit.check('523 outer original stream '+name+'/'+suffix,row[suffix]=={'bytes':m['bytes'],'sha256':m['sha256']})
    producer=original('producer/report.json')
    audit.check('523 actual cold producer13 complete',producer['status']=='PASS' and producer['step_count']==len(producer['steps'])==13
        and tuple(x['name'] for x in producer['steps'])==PRODUCER and producer['all_package_members_unchanged'] is True
        and producer['all_expected_statuses_and_counts_matched'] is True and producer['package_manifest_sha256']==tracked['tools/native_dropout/package-manifest.json']['sha256']
        and producer['profile_sha256']==tracked['tools/native_dropout/profile.json']['sha256'])
    audit.check('523 aggregate producer receipt exact',aggregate['producer_admission']=={
        'report_sha256':metadata['producer/report.json']['sha256'],'steps':13,'all_exact_labels_admitted':True,'original_inherited_partial_reports_preserved':True})
    fixed_counts={
        'cold-native-build':{'units_reproduced_exactly':11},'typed-slice':{'frames':48},'typed-lifetimes':{'frames':343},
        'bool-logical-not':{'frames':66},'dtype-admission101':{'frames':126},'owned-allocation':{'frames':120},
        'history-mul-controls8':{'cases':8,'passed':8,'frames':216},'actual-native-dropout28':{'cases':28,'frames':1816},
        'original-native-dropout8':{'cases':8,'passed':8,'frames':140},'actual-existing-optimizer6':{'cases':6,'passed':6,'frames':2114},
        'actual-sgd-effective-layout6':{'cases':6,'passed':6,'frames':891},
        'actual-retained12':{'variants_executed':12,'variants_qualified':12,'unexpected_failures':0},
        'inherited16':{'step_count':16,'all_sources_unchanged':True}}
    children={}
    for row in producer['steps']:
        name=row['name'];source_argv(row['command'],'523 producer '+name)
        status='QUALIFIED_EXPOSED_SCOPE' if name=='actual-retained12' else 'PASS'
        child=original('producer/'+row['report'],row['report_sha256']);children[name]=child;runtime(audit,child,'523 producer '+name)
        audit.check('523 producer original executed status '+name,row['exit_code']==0 and row['status']==row['expected_status']==child['status']==status)
        for suffix in ('stdout','stderr'):
            n='producer/'+name+'.'+suffix;required.add(str(root/n))
            audit.check('523 producer original stream '+name+'/'+suffix,row[suffix+'_sha256']==metadata[n]['sha256'])
        for key,value in fixed_counts[name].items():
            audit.check('523 fixed producer count '+name+'/'+key,type(child[key]) is type(value) and child[key]==value)
    build=original('producer/native/build.json');runtime(audit,build,'523 fresh build')
    audit.check('523 actual eleven native complete compilation units',build['status']=='PASS' and build['link_exit']==0
        and build['compiler_sha256']==COMPILER and build['linker_sha256']==LINKER
        and len(build['units'])==len({u['name'] for u in build['units']})==11)
    for key in ('source_sha256','native_sha256','functions','blocks','instructions','descriptor_bytes','state_format','backing_format','units'):
        audit.check('523 exact profile build '+key,build[key]==definitions[key])
    for name,pin in [('runtime.hepta',SOURCE),('tensor-dtype-dropout-session',IMAGE)]:
        required.add(str(native/name));audit.check('523 actual cold product bytes '+name,metadata['producer/native/'+name]['sha256']==pin)
    for unit in build['units']:
        audit.check('523 real compiler exit '+unit['name'],unit['compiler_exit']==0)
        for suffix,kind in (('.hepta','source'),('.o','object')):
            n='producer/native/'+unit['name']+suffix;required.add(str(root/n))
            audit.check('523 actual source/object bytes '+n,metadata[n]['sha256']==unit[kind+'_sha256'])
    audit.check('523 aggregate cold product identity',aggregate['new_build']=={'build_report_sha256':metadata['producer/native/build.json']['sha256'],
        'source_sha256':SOURCE,'native_sha256':IMAGE,'actual_units_verified':11})
    checked=aggregate['checked_inputs']
    audit.check('523 nonempty complete input custody ledger',isinstance(checked,dict) and bool(checked))
    tools={opts['--compiler']:COMPILER,opts['--linker']:LINKER,opts['--flat-compiler']:FLAT}
    stack=PurePosixPath(opts['--compiler']).parents[1]
    tools[str(stack/'native/stack-linker-runtime')]=RUNTIME_LINKER
    required.update(tools)
    parents={'runtime.hepta':PARENT_SOURCE,'tensor-retained-session':PARENT_IMAGE,'build.json':aggregate['parent_build']['build_report_sha256']}
    for unit in parent_profile['units']:
        for suffix,kind in (('.hepta','source'),('.o','object')):
            parents[unit['name']+suffix]=unit[kind+'_sha256']
            audit.check('523 parent matches independently read fresh446 unit '+unit['name']+suffix,
                parent_summary['unit_members'][unit['name']+suffix]['sha256']==unit[kind+'_sha256'])
    required.update(str(parent/name) for name in parents)
    required_top=set(required)
    audit.check('523 complete required input set no vacuous omissions',required_top==set(checked),required_count=len(required_top),actual_count=len(checked))
    categories=Counter()
    for path,pin in checked.items():
        p=PurePosixPath(path)
        if p.is_relative_to(root):
            name=p.relative_to(root).as_posix();expected=metadata[name];categories['current_archived_output']+=1
        elif p.is_relative_to(parent):
            name=p.relative_to(parent).as_posix()
            audit.check('523 parent exact declared member '+name,name in parents and pin['sha256']==parents[name])
            expected=pin;categories['frozen_parent_build']+=1
        elif path in tools:
            audit.check('523 tool exact frozen hash '+p.name,pin['sha256']==tools[path]);expected=pin;categories['pinned_native_tool']+=1
        elif p.is_relative_to(repo):
            name=p.relative_to(repo).as_posix();expected=tracked[name];categories['target_tree_source']+=1
        else:
            audit.check('523 no unknown external input namespace '+path,False);raise AssertionError(path)
        mode=int(expected['mode'],8)&0o777 if isinstance(expected['mode'],str) else expected['mode']
        audit.check('523 every input exact bytes SHA mode '+path,
            set(pin)=={'bytes','mode','sha256'} and pin['bytes']==expected['bytes'] and pin['sha256']==expected['sha256'] and pin['mode']==mode)
    for name in ('tools/native_dropout/profile.json','tools/retained_gradients/profile.json'):
        audit.check('523 profile immutable source input '+name,checked[str(repo/name)]['sha256']==tracked[name]['sha256'])
    # The fixed actual references are source inputs, not conclusions from a candidate.
    for name,pin in definitions['fixed_references'].items():
        path='validation/native-dropout/reference/'+name;raw=sources[path];doc=base.decode(raw)
        audit.check('523 exact fixed actual observation '+name,sha(raw)==pin['sha256'] and doc['status']=='OBSERVED'
            and doc['cases']==pin['cases'] and doc['probe_error_count']==0)
        audit.provenance(doc['oracle_provenance'],'523 fixed reference '+name)
    retained=children['actual-retained12']
    audit.check('523 actual retained12 original reference and full provenance',retained['inputs']['observations']=='ca8b5d3a7c679dcc5ad9a3d7b2bbd38f664c90e6474cf3e3c28496d5b716d1b3'
        and retained['all_inputs_unchanged'] is True and len(retained['reference_provenance_checks'])==11
        and all(v is True for v in retained['reference_provenance_checks'].values()))
    # Full inherited reports retain their original scope classes, not merely a parent PASS.
    inherited=children['inherited16'];frozen=base.decode(sources['validation/native-dropout/reports/inherited-16.json'])
    audit.check('523 inherited23 plus originalpartial14 ledger unchanged',inherited['inherited_optimizer_mapping']==frozen['inherited_optimizer_mapping'])
    own_manifest_name='tools/retained_gradients/package-manifest.json'
    own_manifest=base.decode(sources[own_manifest_name])['files']
    audit.check('523 inherited actual complete13 source inputs',len(own_manifest)==13
        and set(inherited['own_inputs_sha256'])=={str(repo/name) for name in own_manifest}
        and inherited['package_manifest_sha256']==tracked[own_manifest_name]['sha256']
        and inherited['parent_manifest_sha256']==tracked['tools/gradient_adam_distributions/package-manifest.json']['sha256'])
    for name,pin in own_manifest.items():
        audit.check('523 inherited original input actual SHA '+name,inherited['own_inputs_sha256'][str(repo/name)]==pin['sha256']==tracked[name]['sha256'])
    audit.check('523 all original inherited16 ordered names/status',
        [(x['name'],x['report_status']) for x in inherited['steps']]==[(x['name'],x['report_status']) for x in frozen['steps']]
        and len(inherited['steps'])==16)
    for row in inherited['steps']:
        source_argv(row['command'],'523 inherited '+row['name'],custody=False)
        name='producer/inherited16/'+row['report_path'];doc=original(name,row['report_sha256'])
        audit.check('523 original inherited child status '+row['name'],row['exit_code']==0 and doc['status']==row['report_status'])
        frozen_name='validation/native-dropout/reports/inherited-'+row['name']+'.json'
        old=base.decode(sources[frozen_name])
        audit.check('523 inherited scope ledger unchanged '+row['name'],shape_fields(doc)==shape_fields(old))
        for key in ('counts','qualified_groups','partial_groups','failed_groups','qualified_variants','unrepresented_variants',
                    'failed_variants','qualified','failed','mismatch_fields','cases','passed','refusal_cases',
                    'parameter_values_versions_gradient_presence_and_skip_passed','unexpected_failures',
                    'state_version_difference_observations','state_creation_difference_observations',
                    'adam_compared_values_with_different_bits','native_step_Tensor_absence_observations',
                    'Adam_different_bits','qualified_exposed_scope','partial_cases','open_not_executed_cases','failures'):
            if key in old:audit.check('523 inherited original exact counter '+row['name']+'/'+key,type(doc[key]) is type(old[key]) and doc[key]==old[key])
        for suffix in ('stdout','stderr'):
            n='producer/inherited16/'+row['name']+'.'+suffix
            audit.check('523 inherited child stream '+n,metadata[n]['sha256']==row[suffix+'_sha256'])
    identity=original('actual-identity9/report.json')
    audit.check('523 actual9 independent complete fixed workload',identity['recipes']==identity['passing_recipes']==9
        and identity['native_sessions']==identity['passed_sessions']==13 and identity['frames']==963 and identity['assertions']==6888
        and identity['inputs_unchanged'] is identity['reference_unchanged'] is identity['native_executed'] is True
        and identity['reference_sha256']=='de7db2f985873be797bd7e167fb374f82b5690021e0a0541d2fb4f7a36b7ad83'
        and all(r['status']=='PASS' and r['native_exit_code']==0 for r in identity['rows']))
    resource=base.decode(sources['validation/dtype-resource-review/cli.json'])
    for specrow in resource['commands']:
        child=original(specrow['name']+'/report.json')
        for key,value in specrow['required'].items():
            audit.check('523 fixed resource scope '+specrow['name']+'/'+key,type(child[key]) is type(value) and child[key]==value)
    owner=original('owner640/report.json')
    audit.check('523 independent640 actual4 and copied24 scope',owner['native_case_count']==4 and owner['native_frames']==68
        and owner['copied_negative_controls']==24 and owner['unit_count']==11
        and owner['native_executed_this_invocation'] is owner['inputs_unchanged'] is owner['frozen_355_428_446_observer_unchanged'] is True
        and owner['executable_rebuilt_this_invocation'] is False)
    for child in owner['children']:
        script,args=kwargs(child['argv']);audit.check('523 owner child source exact',PurePosixPath(script).relative_to(repo).as_posix() in tracked)
        # Embedded originals are checked against the exact report bytes, never reconstructed as custody.
        path='owner640/'+base.member_name(child['report']['path'])
        raw=files[path]
        audit.check('523 owner original child receipt '+child['name'],child['exit_code']==0 and child['report']['sha256']==sha(raw)
            and child['report']['bytes']==len(raw) and child['observed']==base.decode(raw))
    owner_pure=recheck_owner640(audit,base,files,owner,sources)
    # Every live transport recorded in this execution is backed by complete framed bytes.
    transport_count=0;transport_frames=0
    for name,raw in files.items():
        if not name.endswith('/transport.json'):
            continue
        t=base.decode(raw)
        if not {'frames','rows','exit_code','responses_before_stdin_eof'}<=set(t):
            continue
        prefix=str(PurePosixPath(name).parent)
        req=wire[prefix+'/requests.frames.bin'];resp=wire[prefix+'/responses.frames.bin']
        audit.check('523 real interactive transport '+name,t['frames']==len(t['rows'])==len(req)==len(resp)
            and t['exit_code']==0 and t['responses_before_stdin_eof'] is True
            and all(r['pid']==t['pid'] and r['stdin_open'] is True and r['frame']==i+1 and r['response_bytes']==resp[i] for i,r in enumerate(t['rows'])))
        transport_count+=1;transport_frames+=len(req)
    audit.check('523 fresh transport evidence nonempty',transport_count>0 and transport_frames>0)
    audit.check('523 separate live32/frozen35 never inferred from native suites',aggregate['separate_required_CI_gates']=={
        'live32':'NOT_EXECUTED_BY_NATIVE_COORDINATOR','frozen35_with_640_accounting':'NOT_EXECUTED_BY_NATIVE_COORDINATOR','no_inference_from_inherited16':True})
    return {'status':'ACTUAL_FRESH_523_EVIDENCE_VERIFIED','source_sha256':SOURCE,'native_sha256':IMAGE,
        'coordinator_sha256':QUALIFIER,'outer_commands':6,'producer_steps':13,'actual_units':11,
        'actual_archive_members':len(metadata),'actual_archive_bytes':len(z['native-dropout-ci-raw.tar.xz']),
        'actual_uncompressed_bytes':manifest['uncompressed_bytes'],'all_member_bytes_SHA_modes_verified':True,
        'single_XZ_EOF':True,'required_input_count':len(required_top),'checked_input_count':len(checked),
        'checked_input_categories':dict(categories),'actual_transport_count':transport_count,'actual_transport_frames':transport_frames,
        'independent_owner_original_pure_recheck':owner_pure,'argv_source_dependencies_in_exact_Git_tree':sorted(referenced_sources),
        'historical_failures_preserved':True,'whole_project_decision':'HOLD','full_schema_parity':0}

def recheck_owner640(audit,base,files,owner,sources):
    """Pure JSON replay of the separately scoped original4/24 observer evidence."""
    raw=sources['tests/dtype_owner_accounting/owner640.py']
    audit.check('523 original4/24 structural observer remains frozen6ea',sha(raw)=='6ea9e8b33164089034a2a71a03f4850e1ec18ed1a09155d7841f700ef311c833')
    pure=types.ModuleType('independent_original640_pure');exec(compile(raw,'<frozen-original640>','exec'),pure.__dict__)
    native=base.decode(files['owner640/native-controls/observed/report.json'])
    copied=base.decode(files['owner640/copied-controls/observed/report.json'])
    names=['bool-mask-Saved-Weak-Hold-and-ordinary-rollback','captured-Accumulator-refresh-and-real-unrooted-cycle',
           'weak-captured-retain-hook-and-public-gradient','SGD-Adam-private-Tensor-roots-and-public-state-gradient-alias']
    audit.check('523 original4 exact native cases and68 events',native['status']=='PASS' and native['native_executed'] is True
        and native['Torch_executed'] is False and native['case_count']==native['passed']==len(native['cases'])==4 and native['failed']==0
        and [x['name'] for x in native['cases']]==names and all(x['status']=='PASS' and x['eof_exit_code']==0 for x in native['cases'])
        and native['frames_before_EOF']==len(native['events'])==68 and native['observer_sha256']==sha(raw))
    snapshots={}
    for key,pin in native['snapshots'].items():
        packed=files['owner640/native-controls/observed/'+base.member_name(pin['path'])];plain=gzip.decompress(packed)
        snapshot=base.decode(plain)
        audit.check('523 original640 snapshot exact bytes',sha(packed)==pin['compressed_sha256'] and len(plain)==pin['bytes']
            and sha(plain)==key and pure.canonical(snapshot)==plain)
        pure.verify_snapshot(snapshot);snapshots[key]=snapshot
    audit.check('523 original640 complete referenced snapshots',bool(snapshots)
        and set(snapshots)=={e[k] for e in native['events'] for k in ('before','after')})
    def response(event):
        raw=bytes.fromhex(event['response_hex']);assert raw[:8]==b'HTORSP03' and len(raw)>=32
        version,count,status=struct.unpack_from('<3Q',raw,8);assert version==3 and status==event['actual_status']
        rows=[];position=32
        for _ in range(count):
            op,err,value,size=struct.unpack_from('<4Q',raw,position);position+=32
            assert err==0 and size<=len(raw)-position
            rows.append({'opcode':op,'value':value,'payload':raw[position:position+size]});position+=size
        assert position==len(raw);return rows
    isolated=0;snapshot_only=0;ledgers=[]
    for index,event in enumerate(native['events']):
        before,after=snapshots[event['before']],snapshots[event['after']]
        audit.check('523 original640 exact observed snapshot summary',pure.verify_snapshot(after)==event['snapshot_summary'])
        if event['ledger']['status']=='SNAPSHOT_ONLY':
            audit.check('523 four original snapshot-only exclusions preserved',event['actual_status']==0 and event['command_words'][0][0] in (58,72))
            snapshot_only+=1;ledgers.append({'event':index,'status':'SNAPSHOT_ONLY'})
        else:
            result=pure.verify_isolated_transition(before,after,event['command_words'][0],response(event),event['actual_status'])
            audit.check('523 original640 isolated transition result exact',result==event['ledger']);isolated+=1
            ledgers.append({'event':index,'status':'PASS','result':result})
    audit.check('523 original64 isolated and4 snapshot-only counts',isolated==64 and snapshot_only==4
        and copied['original_event_ledgers']==ledgers and copied['original_isolated_ledgers_rechecked']==64
        and copied['original_setup_snapshot_only']==4)
    audit.check('523 original24 pure-negative exact scope',copied['status']=='PASS' and copied['negative_control_count']==len(copied['controls'])==24
        and copied['expected_refusals']==24 and copied['unexpected_acceptances']==0
        and copied['input_bytes_unchanged'] is True)
    for row in copied['controls']:
        packed=files['owner640/copied-controls/observed/'+base.member_name(row['path'])];plain=gzip.decompress(packed);changed=base.decode(plain)
        audit.check('523 original copied640 exact mutation bytes '+row['name'],sha(packed)==row['compressed_sha256']
            and row['status']=='EXPECTED_REFUSAL' and row['observed_error']['observer_rule']==row['expected_rule'])
        try:
            if row['kind']=='copied-snapshot':
                audit.check('523 isolated640 negative realparent '+row['name'],row['parent_snapshot_sha256'] in snapshots
                    and sha(plain)==row['mutated_snapshot_sha256'] and changed!=snapshots[row['parent_snapshot_sha256']])
                pure.verify_snapshot(changed)
            else:
                audit.check('523 isolated640 copiedtransition originalevent '+row['name'],row['kind']=='copied-transition'
                    and sha(plain)==row['mutated_payload_sha256'] and changed['event']==native['events'][row['original_event_index']])
                pure.verify_snapshot(changed['before']);pure.verify_snapshot(changed['after'])
                event=changed['event'];pure.verify_isolated_transition(changed['before'],changed['after'],event['command_words'][0],response(event),event['actual_status'])
        except AssertionError as error:
            detail=error.args[0] if error.args else None
            audit.check('523 original640 independent exact rejection '+row['name'],isinstance(detail,dict) and detail.get('observer_rule')==row['expected_rule'])
        else:audit.check('523 original640 independent exact rejection '+row['name'],False)
    return {'native_cases_from_original_CI':4,'native_frames_from_original_CI':68,'pure_snapshot_count':len(snapshots),
            'pure_isolated_transitions':isolated,'snapshot_only_events_kept_distinct':snapshot_only,
            'pure_negative_refusals':24,'native_or_Torch_executed':False}

def load_pure(audit,bundle,sources):
    path=bundle/'source/tests/dtype_frozen35_accounting/owner_accounting523.py'
    audit.check('523 pure full80word observer exact source',sha(path.read_bytes())==OBSERVER)
    spec=importlib.util.spec_from_file_location('independent_offline_fixed35_640',path)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    audit.check('523 exact source profile loaded without native capture',sha((path.parent/'profile.json').read_bytes())==PROFILE
        and module.DESC_BYTES==640 and module.CONFIG['source_sha256']==SOURCE and module.CONFIG['native_sha256']==IMAGE)
    for key,relative,pin in (
        ('legacy_owner_rules','tests/dtype_frozen35_accounting/legacy_owner_rules.py','281f1ea437046a9cd884de2c8da34f38649a3b6482ade23123ac4aa992faed64'),
        ('structural_owner640','tests/dtype_frozen35_accounting/owner640_storage_tombstone.py','f503df2d1dbce8242591e77211b96a7787201e991db8186c9f1cca6576244409'),
        ('original_structural_owner640','tests/dtype_owner_accounting/owner640.py','6ea9e8b33164089034a2a71a03f4850e1ec18ed1a09155d7841f700ef311c833')):
        audit.check('523 pure dependency exact '+key,sha(sources[relative])==pin)
    return module

def source_inverses(audit,sources):
    prefix='tests/dtype_frozen35_accounting/'
    for name,proof_name,old_name in (
        ('run_frozen35_accounted.py','launcher-adaptation.json','run_frozen35_accounted.py'),
        ('check_frozen35_accounted.py','report-checker-adaptation.json','check_frozen35_accounted.py'),
        ('check_owner_snapshots.py','negative-controls-adaptation.json','check_owner_snapshots.py')):
        raw=sources[prefix+name];proof=json.loads(sources[prefix+proof_name])
        # All declared edits are finite, source-bound and exactly reversible.
        audit.check('523 declared source inverse current pin '+name,sha(raw)==proof['derived_sha256'])
        restored=raw.decode()
        for edit in reversed(proof['edits']):
            audit.check('523 inverse multiplicity '+name,restored.count(edit['after'])==edit.get('count',1))
            restored=restored.replace(edit['after'],edit['before'])
        audit.check('523 original frozen algorithm exact inverse '+name,
            restored.encode()==sources['tests/private_node_accounting/'+old_name] and sha(restored.encode())==proof['original_sha256'])

def copied18(audit,base,members,report,pure,sources):
    audit.check('523 copied18 original exact source and outcomes',report['status']=='PASS_OBSERVER_CONTROLS_ONLY'
        and report['failures']==0 and report['positive_cases']==len(report['positive_rows'])==4
        and report['negative_cases']==len(report['negative_rows'])==18 and report['observer_sha256']==OBSERVER
        and report['controls_sha256']==CONTROLS and report['expected_profile']==MODEL['name']
        and report['original_journals_unchanged'] is report['observer_source_unchanged'] is True
        and all(report[k] is False for k in ('native_executed','Torch_executed','native_memory_read','native_memory_written')))
    audit.check('523 copied-control original source bytes archived',
        sha(base.one_suffix(members,'/copied-controls/executed-controls.py'))==CONTROLS
        and sha(base.one_suffix(members,'/copied-controls/observer-under-test.py'))==OBSERVER)
    tree=ast.parse(sources['tests/dtype_frozen35_accounting/check_owner_snapshots.py'])
    calls=sorted((n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='run'),key=lambda n:n.lineno)
    rules=[(ast.literal_eval(n.args[0]),ast.literal_eval(n.args[1]),ast.literal_eval(n.args[3])) for n in calls]
    audit.check('523 all18 exact original rules and order',len(rules)==18
        and [(r['case'],r['expected_rule']) for r in report['negative_rows']]==[(n,r) for n,_,r in rules])
    audit.check('523 four original real-positive categories',{r['case'] for r in report['positive_rows']}=={
        'materialization','compound-construction','reset-with-private-gradient','failed-frame-rollback'})
    chosen={}
    for row in report['positive_rows']:
        event=base.event_input(members,row['journal'],row['event'])
        audit.check('523 positive original event hash '+row['case'],row['status']=='PASS' and sha(base.canonical(event))==row['input_sha256']
            and event['recorded_result']==row['result'] and event['before']['profile']==event['after']['profile']==MODEL['name'])
        result=pure.verify_transition(event['before'],event['after'],event['tickets'],event['commands'],event['status'])
        audit.check('523 pure JSON positive exact result '+row['case'],result==row['result'])
        chosen[row['case']]=event
    for row,(name,parent,rule) in zip(report['negative_rows'],rules):
        packed=base.one_suffix(members,'/negative-inputs/'+name+'.json.gz');raw=gzip.decompress(packed);changed=base.decode(raw);original=chosen[parent]
        audit.check('523 negative exact saved input '+name,sha(packed)==row['compressed_sha256'] and sha(raw)==row['input_sha256']
            and row['status']=='PASS_EXPECTED_REJECTION' and row['expected_rule']==row['actual_rule']==rule)
        audit.check('523 isolated copied-negative original-side preservation '+name,changed['before']==original['before']
            and base.canonical(changed)!=base.canonical(original)
            and row['source_event']=={'journal':original['path'],'event':original['ordinal']}
            and all(changed[k]==original[k] for k in ('path','ordinal','commands','status','recorded_result')))
        try:pure.verify_transition(changed['before'],changed['after'],changed['tickets'],changed['commands'],changed['status'])
        except AssertionError as error:
            detail=error.args[0] if error.args else None
            audit.check('523 pure JSON exact old rejection '+name,isinstance(detail,dict) and detail.get('observer_rule')==rule)
        else:audit.check('523 pure JSON exact old rejection '+name,False)
    for path,pin in report['input_files'].items():
        name=base.original_build_relative(path)
        audit.check('523 every copied control original input '+name,name in members and len(members[name])==pin['bytes'] and sha(members[name])==pin['sha256'])
    return {'actual_prior_native_journals':True,'pure_positive_cases_rechecked':4,'pure_negative_cases_rechecked':18,
            'original_18_rule_names_unchanged':True,'new_native_or_Torch_executions':0}

def tombstone(audit,base,members,report,pure,sources):
    audit.check('523 actual tombstone fixed native1 copied4 workload',report['schema']=='heptatorch.Storage-tombstone-observer-regression.v1'
        and report['status']=='PASS' and report['native_executed'] is True and report['Torch_executed'] is False
        and report['native_cases']==1 and report['copied_negative_cases']==len(report['negative_rows'])==4
        and report['frames']==6 and report['EOF_exit_code']==0 and report['inputs_after_unchanged'] is True
        and report['numeric_API_cases']==0 and report['whole_pytorch_gate']=='HOLD' and report['full_pytorch_parity'] is False)
    audit.check('523 original tombstone test source',report['inputs']['executed_test']['sha256']==sha(sources['tests/dtype_frozen35_accounting/test_storage_tombstone.py']))
    snapshots={}
    for name,pin in report['snapshot_files'].items():
        packed=base.one_suffix(members,'/storage-tombstone/'+pin['path']);raw=gzip.decompress(packed)
        audit.check('523 actual tombstone full snapshot '+name,len(raw)==pin['bytes'] and sha(raw)==pin['sha256'] and sha(packed)==pin['compressed_sha256'])
        value=base.decode(raw);pure.verify_snapshot(value);snapshots[name]=value
    audit.check('523 all four tombstone states',set(snapshots)=={'before-last-strong-drop','after-last-strong-drop','after-expired-weak-lock','after-last-weak-drop'})
    before=snapshots['before-last-strong-drop'];after=snapshots['after-last-strong-drop']
    slots=[i for i,r in enumerate(before['tables']['2']) if r==report['before_storage']]
    audit.check('523 unique actual expired Storage row',len(slots)==1)
    slot=slots[0];prior=before['tables']['2'][slot];expired=after['tables']['2'][slot]
    audit.check('523 actual retained requested-byte metadata',prior[3:8]==[12,16,1,2,0]
        and expired==report['expired_storage']==[prior[0],1,0,12,0,0,1,1]
        and sum(n for _,n in after['free_extents'])==sum(n for _,n in before['free_extents'])+16)
    audit.check('523 failed Weak lock exact committed state',snapshots['after-expired-weak-lock']==after and report['weak_lock_rollback_bytes']>0)
    audit.check('523 last Weak releases exact tombstone row',snapshots['after-last-weak-drop']['tables']['2'][slot]==[prior[0]]+[0]*7)
    audit.check('523 original6ea error preserved',report['preserved_original_observer_refusal']['observer_rule']=='expired-Storage-extent')
    rules=[('expired-offset-nonzero',2,16,'expired-Storage-extent'),
           ('expired-rounded-nonzero',4,16,'expired-Storage-extent'),
           ('expired-requested-outside-pool',3,after['header']['pool']+1,'expired-Storage-requested-bound'),
           ('expired-requested-changed',3,8,'expired-Storage-requested-preserved')]
    audit.check('523 all four exact tombstone refusal rows',[(r['case'],r['expected_rule']) for r in report['negative_rows']]==[(n,rule) for n,_,_,rule in rules])
    # Reconstruct the exact original drop command from the archived third request.
    raw=base.one_suffix(members,'/storage-tombstone/transport/requests.frames.bin');offset=0;bodies=[]
    while offset<len(raw):
        assert raw[offset:offset+8]==b'HTOWNR01'
        n=struct.unpack_from('<Q',raw,offset+8)[0];bodies.append(raw[offset+16:offset+16+n]);offset+=16+n
    audit.check('523 original tombstone six request frames',offset==len(raw) and len(bodies)==6)
    command=list(struct.unpack_from('<8Q',bodies[2],32));assert command[0]==41
    result=pure.verify_transition(before,after,[],[command])
    audit.check('523 pure original tombstone transition',result==report['transition'])
    for row,(name,index,value,rule) in zip(report['negative_rows'],rules):
        raw=gzip.decompress(base.one_suffix(members,'/storage-tombstone/'+name+'.json.gz'))
        changed=base.decode(raw);expected=copy.deepcopy(after);expected['tables']['2'][slot][index]=value
        audit.check('523 exact one-word copied tombstone mutation '+name,changed==expected and sha(raw)==row['input_sha256']
            and row['status']=='PASS_EXPECTED_REJECTION' and row['actual_rule']==rule)
        try:pure.verify_transition(before,changed,[],[command])
        except AssertionError as error:
            detail=error.args[0] if error.args else None
            audit.check('523 independent pure tombstone refusal '+name,isinstance(detail,dict) and detail.get('observer_rule')==rule)
        else:audit.check('523 independent pure tombstone refusal '+name,False)
    return {'native_cases_executed_by_CI':1,'native_frames':6,'copied_refusals_rechecked':4,'extra_native_or_Torch_executions':0}

def review_oracles(audit,base,spec,ctx,main_bytes,reports,sources,bundle,plan32,plan35):
    source_inverses(audit,sources)
    pure=load_pure(audit,bundle,sources)
    live=audit.live32(main_bytes['pytorch-native-dropout-backward.json'],MODEL,'main523 live32',plan32)
    saved=base.OBSERVER,base.LAUNCHER
    base.OBSERVER,base.LAUNCHER=OBSERVER,LAUNCHER
    try:
        d,w=audit.frozen35(main_bytes['pytorch-native-dropout-frozen35.json'],main_bytes['pytorch-native-dropout-frozen35-original.json'],
                         MODEL,'pytorch-native-dropout-frozen35-original.json','main523 frozen35',plan35)
    finally:base.OBSERVER,base.LAUNCHER=saved
    audit.pip_binding(main_bytes['pytorch-install.json'],[live['oracle_provenance'],d['oracle_provenance']],'main523 actual install')
    for key,path in {
        'legacy_owner_rules':'tests/dtype_frozen35_accounting/legacy_owner_rules.py',
        'structural_owner640':'tests/dtype_frozen35_accounting/owner640_storage_tombstone.py',
        'original_structural_owner640':'tests/dtype_owner_accounting/owner640.py',
        'storage_tombstone_correction':'tests/dtype_frozen35_accounting/storage-tombstone-correction.json',
        'accounting_profile':'tests/dtype_frozen35_accounting/profile.json'}.items():
        audit.check('523 full35 actual additional source custody '+key,w['source_custody'][key]['sha256']==sha(sources[path]))
    audit.check('523 real full80word profile and inverse',w['profile']['descriptor_bytes']==640
        and w['profile']['source_constructor_costs'] is True and w['profile']['inverse_proof']==pure.inverse_proof())
    members,official=audit.archive(spec)
    audit.check('523 dtype journal original artifact same run and attempt',official['workflow_run']['id']==ctx['run']['id']
        and official['name']==f"dtype-node-journals-{ctx['run']['id']}-{ctx['run']['run_attempt']}-native")
    mirror_names=('pytorch-native-dropout-frozen35.json','pytorch-native-dropout-frozen35-original.json',
                  'pytorch-native-dropout-frozen35-observer-controls.json','native-dropout-storage-tombstone.json',
                  'pytorch-native-dropout-backward.json','pytorch-install.json')
    audit.custody(members,official,ctx,{n:main_bytes[n] for n in mirror_names},'523 complete original journals')
    audit.journals(members,d['rows'],'523 actual frozen35 full640')
    # The snapshot verifier consumes the real full80-word structure; no576 projection is made.
    total_snapshots=0
    for name,packed in members.items():
        if not name.endswith('/snapshots.jsonl.gz'):
            continue
        for line in gzip.decompress(packed).splitlines():
            item=base.decode(line);snapshot=item['snapshot']
            audit.check('523 complete full80word snapshot '+name,all(len(n)==80 for n in snapshot['nodes'].values())
                and snapshot['profile']==MODEL['name'] and sha(base.canonical(snapshot))==item['sha256'])
            pure.verify_snapshot(snapshot);total_snapshots+=1
    audit.check('523 full35 snapshots actually present',total_snapshots>0)
    transitions=recheck_all_transitions(audit,base,members,d['rows'],pure)
    neg=copied18(audit,base,members,reports['pytorch-native-dropout-frozen35-observer-controls.json'],pure,sources)
    stone=tombstone(audit,base,members,reports['native-dropout-storage-tombstone.json'],pure,sources)
    return {'status':'ACTUAL_523_LIVE32_FROZEN35_AND_RAW_VERIFIED','live32':32,'frozen35':35,'frames':6344,'compared_values':2590274,
        'legacy_state_version_differences_preserved':283,'direct_parameter_version_mismatches':0,
        'all35_original_EOF_and_Version_postconditions_executed':True,'full640_snapshot_count':total_snapshots,
        'pure_all35_transitions':transitions,'copied18':neg,'tombstone':stone,'extra_native_or_Torch_executions':0}

def recheck_all_transitions(audit,base,members,rows,pure):
    """Recompute every original full640 event from original immutable snapshots."""
    all_paths={n for n in members if n.endswith('/events.json')};seen=set();total=0;ledger=[]
    audit.check('523 full35 transition case coverage',len(rows)==len({r['case'] for r in rows})==35)
    for row in rows:
        folder=base.original_build_relative(row['private_node_observer']['snapshot_directory'])
        ep=folder+'/events.json';sp=folder+'/snapshots.jsonl.gz'
        audit.check('523 exact case event path '+row['case'],ep in all_paths and ep not in seen and sp in members)
        seen.add(ep);events=base.decode(members[ep]);snapshots={}
        for line in gzip.decompress(members[sp]).splitlines():
            item=base.decode(line);key=item['sha256'];snapshot=item['snapshot']
            audit.check('523 full-transition original snapshot '+row['case'],
                key not in snapshots and sha(base.canonical(snapshot))==key and snapshot['profile']==MODEL['name'])
            snapshots[key]=snapshot
        audit.check('523 transition exact original frame count '+row['case'],
            len(events)==row['frames']==row['private_node_observer']['frames_checked'])
        used=set()
        for ordinal,event in enumerate(events):
            audit.check('523 transition actual exact schema '+row['case']+'/'+str(ordinal),
                set(event)=={'before','after','tickets','commands','expected_status','result','error'}
                and event['error'] is None and type(event['expected_status']) is int
                and event['before'] in snapshots and event['after'] in snapshots)
            used.update((event['before'],event['after']))
            result=pure.verify_transition(snapshots[event['before']],snapshots[event['after']],
                                          event['tickets'],event['commands'],event['expected_status'])
            audit.check('523 pure original full640 transition '+row['case']+'/'+str(ordinal),result==event['result'])
            total+=1
        audit.check('523 transition no unreferenced or omitted snapshots '+row['case'],used==set(snapshots))
        ledger.append({'case':row['case'],'path':ep,'events':len(events),'events_sha256':sha(members[ep])})
    audit.check('523 every archived journal belongs to exactly one original case',seen==all_paths)
    audit.check('523 all6344 original transitions independently recomputed',total==6344)
    return {'original_cases':35,'original_frames':total,'all_original_results_recomputed_equal':True,
            'case_journals':ledger,'native_or_Torch_executed':False}
