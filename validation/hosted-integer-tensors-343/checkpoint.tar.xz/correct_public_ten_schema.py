"""Narrow correction for an original full-case list, preserving r02 and its FAIL."""
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path

P=Path(__file__).resolve().parent;OLD=P/'reader-full-r02';OUT=P/'reader-full-r03'
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(OLD/'integer_tensor_evidence.py').read_text()
assert sha(raw.encode())=='bbe16815684e1295b6355cb8b6e65ba5f3e0ca80fcb0cf929df7f197693d060b'
fragment=(P/'schema-correction-01/public_ten_validator.py').read_text()
changes=[
    ("            if name.endswith('/requests.frames.bin'):wire[name]=framed(raw,b'HTOWNR01')",
     "            if name.endswith('.frames.bin') and ('original-public-ten/' in name or 'original-public-ten' in label):\n                files[name]=raw\n            if name.endswith('/requests.frames.bin'):wire[name]=framed(raw,b'HTOWNR01')"),
    ('def review_native(audit,base,spec,ctx,main_bytes,reports,sources,tracked,parent_summary):',
     fragment+'\n\ndef review_native(audit,base,spec,ctx,main_bytes,reports,sources,tracked,parent_summary):'),
    ("    for row in inherited['steps']:\n        source_argv(row['command'],'544 original16 '+row['name'])",
     "    public_ten_receipt=None\n    for row in inherited['steps']:\n        source_argv(row['command'],'544 original16 '+row['name'])"),
    ("            if key in old:exact_fields(audit,child,{key:old[key]},'544 original16 preserved '+row['name'])",
     "            if key in old:\n                if row['name']=='original-public-ten' and key=='cases':\n                    public_ten_receipt=public_ten_cases(audit,base,child,old,\n                        legacy_prefix+'inherited16/original-public-ten',files,metadata,sources)\n                else:exact_fields(audit,child,{key:old[key]},'544 original16 preserved '+row['name'])"),
    ("        'old_legacy_status_boundaries_preserved':True,'additional_native_or_Torch_execution':False}",
     "        'old_legacy_status_boundaries_preserved':True,'original_public_ten':public_ten_receipt,\n        'additional_native_or_Torch_execution':False}")]
revised=raw
for before,after in changes:
    assert revised.count(before)==1
    revised=revised.replace(before,after,1)
restored=revised
for before,after in reversed(changes):
    assert restored.count(after)==1
    restored=restored.replace(after,before,1)
assert restored==raw
compile(revised,'integer_tensor_evidence.py','exec')
OUT.mkdir()
(OUT/'integer_tensor_evidence.py').write_text(revised)
main=(OLD/'review_pr33.py').read_text();before=sha(raw.encode());after=sha(revised.encode())
assert main.count(before)==1
(OUT/'review_pr33.py').write_text(main.replace(before,after,1))
for n in ('native_dropout_evidence.py','retained_evidence.py'):os.link(OLD/n,OUT/n)
oldfn={n.name:ast.get_source_segment(raw,n) for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)}
newfn={n.name:ast.get_source_segment(revised,n) for n in ast.parse(revised).body if isinstance(n,ast.FunctionDef)}
changed=sorted(n for n in oldfn if oldfn[n]!=newfn[n])
assert changed==['read_archive','review_native'] and set(newfn)-set(oldfn)=={'public_ten_cases'}
failed=P/'pr-admission-343-r02-first/report.json'
assert sha(failed.read_bytes())=='41b5ad94512cacd51f7561d36d77e1b9f1f2422d8a3dbcf42704bb4f09540e33'
proof={'schema':'heptatorch.pr33.public-ten-case-schema-correction.v1','status':'PREPARED_NOT_RUN',
    'prior_failed_admission_sha256':sha(failed.read_bytes()),'prior_admission_remains_false':True,
    'original_helper_sha256':before,'new_helper_sha256':after,'reader_sha256':sha((OUT/'review_pr33.py').read_bytes()),
    'fragment_sha256':sha(fragment.encode()),'replacements':changes,'whole_source_inverse_exact':True,
    'changed_existing_functions':changed,'added_function':'public_ten_cases',
    'all_full6344_and_original_copied18_functions_byte_identical':True,
    'main_change_only_helper_SHA':True,'original_numerical_provenance_EOF_Version_gates_removed':False,
    'case_tree_comparison':'Every original type/value except declared whole-owner digest; all 1036 original request/response bytes bound.',
    'rollback_evidence':'11 source-bound executed full before/after assertions; their owner bytes were not archived, so no offline owner-byte reexecution claim.',
    'all_16_original_child_field_types_systematically_reviewed':True,
    'diagnosis_sha256':sha((P/'schema-correction-01/systematic-original16.json').read_bytes()),
    'native_or_Torch_executed':False,'prior_r02_source_and_FAIL_preserved':True}
(OUT/'schema-correction-proof.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
(OUT/'helper.diff').write_text(''.join(difflib.unified_diff(raw.splitlines(True),revised.splitlines(True),fromfile='r02-original-FAIL',tofile='r03-schema-corrected')))
print(json.dumps({k:v for k,v in proof.items() if k!='replacements'},indent=2))
