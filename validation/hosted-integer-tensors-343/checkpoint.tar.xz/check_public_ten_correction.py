"""Read archived bytes once, then test the r03 correction on copied JSON/wire."""
import argparse
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import tarfile
import traceback
import zipfile

sha=lambda b:hashlib.sha256(b).hexdigest()
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for n in ('reader','artifact','bundle','output'):ap.add_argument('--'+n,type=Path,required=True)
    a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    helper=load('public_ten_corrected_reader',a.reader)
    base=load('immutable_old_admission',a.bundle/'review_hosted_af33.py')
    blobs={};metadata={}
    def expand(packed,destination=''):
        with tarfile.open(fileobj=io.BytesIO(packed),mode='r|xz') as stream:
            for m in stream:
                name=base.member_name(m.name);assert m.isfile()
                name=(destination+'/' if destination else '')+name
                raw=stream.extractfile(m).read();pin={'bytes':len(raw),'mode':m.mode,'sha256':sha(raw)}
                assert name not in metadata or metadata[name]==pin;metadata[name]=pin
                if name.endswith(('.json','.xz')) or ('original-public-ten/' in name and name.endswith('.frames.bin')):
                    blobs[name]=raw
    packed=a.artifact.read_bytes()
    with zipfile.ZipFile(io.BytesIO(packed)) as z:
        names={Path(n).name:n for n in z.namelist()}
        aggregate=base.decode(z.read(names['hosted-integer-tensors-native.json']))
        expand(z.read(names['integer-tensors-ci-raw.tar.xz']))
    argv=aggregate['commands'][0]['argv'];root=PurePosixPath(argv[argv.index('--output')+1]).parent
    expanded=set()
    while True:
        pending=[]
        for name,raw in list(blobs.items()):
            if not name.endswith('.manifest.json'):continue
            d=base.decode(raw)
            if isinstance(d,dict) and isinstance(d.get('members'),dict) and 'restoration_base' in d:
                arc=str(PurePosixPath(name).parent/d['archive'])
                if arc not in expanded:pending.append((arc,PurePosixPath(d['restoration_base']).relative_to(root).as_posix()))
        if not pending:break
        for arc,destination in pending:expand(blobs[arc],destination);expanded.add(arc)
    prefix='producer10/legacy523-behavior12/inherited16/original-public-ten'
    files={n:b for n,b in blobs.items() if n.startswith(prefix+'/')}
    meta={n:b for n,b in metadata.items() if n.startswith(prefix+'/')}
    actual=base.decode(files[prefix+'/report.json'])
    oldpath=a.bundle/'source/validation/native-dropout/reports/inherited-original-public-ten.json'
    old=base.decode(oldpath.read_bytes())
    sources={('tests/gradient_adam_distributions_review/'+n):(a.bundle/'source/tests/gradient_adam_distributions_review'/n).read_bytes()
             for n in ('replay_original_ten.py','base_replay.py','materialization_replay.py','native_release_controls.py','client.py')}
    audit=base.Audit(a.bundle,a.output)
    positive=helper.public_ten_cases(audit,base,actual,old,prefix,files,meta,sources)
    assert all(r['passed'] for r in audit.checks)
    def bad_status(d,f):d['cases'][0]['status']='PARTIAL'
    def bad_count(d,f):d['cases'][0]['exact_comparisons']-=1
    def missing_frame(d,f):d['cases'][0]['frame_records'].pop()
    def bad_digest(d,f):d['cases'][2]['frame_records'][61]['owner_sha256']='not-a-SHA'
    def broken_equivalence(d,f):d['cases'][2]['frame_records'][119]['owner_sha256']='a'*64
    def wire_change(d,f):
        key=prefix+'/case-01/requests.frames.bin';raw=bytearray(f[key]);raw[-1]^=1;f[key]=bytes(raw)
    plans=[('original-case-status',bad_status,'exact keys and all non-frame fields'),
           ('original-exact-comparisons',bad_count,'exact keys and all non-frame fields'),
           ('missing-original-frame',missing_frame,'full actual trace and EOF source-bound receipt'),
           ('invalid-current-owner-digest',bad_digest,'original complete executed rollback assertion'),
           ('broken-state-equivalence',broken_equivalence,'preserved whole-state equivalence classes'),
           ('changed-actual-request-bytes',wire_change,'actual raw hashes status command results and live frame')]
    rows=[]
    for name,mutate,expected in plans:
        doc=copy.deepcopy(actual);current_files=dict(files);mutate(doc,current_files)
        attempt=base.Audit(a.bundle,a.output)
        try:helper.public_ten_cases(attempt,base,doc,old,prefix,current_files,meta,sources)
        except AssertionError as error:
            assert attempt.checks and attempt.checks[-1]['passed'] is False
            assert expected in attempt.checks[-1]['check'],(name,str(error))
            rows.append({'name':name,'status':'EXPECTED_REFUSAL','failed_check':attempt.checks[-1]['check']})
        else:raise AssertionError(('mutation wrongly admitted',name))
    assert base.decode(files[prefix+'/report.json'])==actual and a.artifact.read_bytes()==packed
    report={'schema':'heptatorch.pr33.public-ten-correction-copied-controls.v1','status':'PASS_COPIED_CONTROLS_ONLY',
        'reader_sha256':sha(a.reader.read_bytes()),'script_sha256':sha(Path(__file__).read_bytes()),
        'original_artifact_sha256':sha(packed),'original_report_sha256':sha(files[prefix+'/report.json']),
        'previous_profile_report_sha256':sha(oldpath.read_bytes()),'positive_check_count':len(audit.checks),
        'positive':positive,'negative_controls':rows,'negative_cases':len(rows),
        'only_copied_JSON_and_wire_mutated':True,'original_bytes_unchanged':True,
        'native_or_Torch_executed':False,'hosted_full_admission_not_claimed_by_this_control':True}
    (a.output/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('positive','negative_controls')},indent=2))
if __name__=='__main__':main()
