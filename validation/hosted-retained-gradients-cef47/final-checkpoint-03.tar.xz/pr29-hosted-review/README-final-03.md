# PR31 independent hosted admission

**Result: PASS_SCOPED_HOSTED_ADMISSION — 106,570 checks passed, zero failed.**

This review binds PR31 head
`cef47b8fc36e4afefad4b4c4e53625f8f62e0a57`, tree
`09f37b090c0773d53db2bef527017fe9f0e298bf`, and parent
`7e7e37be38457d88f214d45f261924983dc96b56`.
The directory's earlier `pr29` label is historical; it does not identify the
separate int64 pull request.

## Executed hosted evidence

| Evidence | Actual run/job | Scope verified |
| --- | --- | --- |
| Main Native HIA | 43873971659 / 133322084171, attempt 1 | All 80 actual steps; 63 original root reports plus their manifest; 33 declared report envelopes |
| Quick 355 | 43873971672 / 133322084782 | All 13 steps; native 3 controls, copied-snapshot 4 positive + 18 negative controls, live 32 and frozen 35 |
| Quick 428 | 43873971672 / 133322084713 | All 13 steps and the same complete scoped gates |
| Quick 446 | 43873971672 / 133322084267 | All 13 steps and the same complete scoped gates |

The main pipeline separately executed live32 and frozen35 on all three exact
images. Each frozen35 report retains 6,344 frames, 2,590,274 value comparisons,
zero direct parameter Version mismatches and 283 explicitly recorded legacy
state Version differences. Its original inner report, EOF/exit checks,
post-close Version assertions and input plans are bound to their original
bytes. The eleven fixed-wheel provenance checks, original pip record and
source/image identities are verified for every corresponding live report.

The main journal ZIP has 440 members. Each quick ZIP has 185 members. Source
head/tree, checkout parents, run attempt, snapshot profile, nonempty native
control rows, complete original journal bytes and the exact 18 copied corruption
rules are checked. The copied JSON controls were re-evaluated without launching
native code or PyTorch.

## Actual retained446 cold evidence

The c71 coordinator executed its producer in this main CI invocation:
`producer_executed_this_invocation=true`, `producer_receipt_reused=false`.
The old local e981 reused receipt is not substituted.

The separate official retained-evidence ZIP contains the original aggregate,
raw manifest and XZ archive. Its aggregate and manifest are byte-identical to
the main report ZIP mirrors. All **2,053 archive members**, totaling
127,290,308 expanded file bytes, passed SHA-256, size and mode checks, exact set
equality and full XZ-trailer reading. The count comes from this actual archive.

All **2,275 required input records** are present and verified: 2,055 current
outputs including the two manifest/archive self-exclusions, 21 frozen parent
build products, 197 exact target-tree source files and two pinned native tools.
All 65 typed-handoff subtree members match its explicit inventory. The fresh
10-frame typed transport is complete; the separate old interrupted archive gap
remains recorded as UNKNOWN and is not reconstructed.

The producer's original 17 groups and six additional outer groups are complete:
strict retained12, two original optimizer case14 subobservations, eight resource
cases, two typed directions, source-to-unit review and five extension groups
executed by six commands. Every original child report, script, command and
stream is bound. All nine compiled source/object units match the frozen profile,
source `666230f05cc6942470006d1f184135321d8cbc26a6c6ba0bf7e3cf9857fe515b`
and ELF `7568c0a4ec40d82d3a0b46d1e8a27499dd96e8fe3fd15433523131a196da89b5`.

## Preserved boundaries and failures

The previous 58 report obligations remain present, including the oldest 50
plans and classifications. The old optimizer report stays 18 qualified + 1
partial + 5 open; the inherited union remains 23 qualified + the original
partial14 before the separate two-observation additive receipt. This does not
claim the complete Optimizer API.

The distribution ledger still contains 18 unrepresented cases, with four
additional side-effect differences for the ordinary atomic API. The old 93/94
contract failure, historical raw gap, original 30ea 3-PASS/32-FAIL hosted report
and first 48e copied-control failures remain original failures. No previously
skipped postcondition is retroactively marked successful.

The whole-project decision remains **HOLD**, full-schema parity **0 of 2,590**,
and `whole_pytorch_rewrite_complete=false`.

## Reader correction history

The quick checkpoint remains unchanged: 52,088 checks passed with main pending.
The first full reader stopped after 17,223 passing checks because it counted a
generic Make output fragment globally rather than inside the one retained
target. Revision02 fixes only that source-binding scope. Its next run stopped
after 18,081 passing checks because the reader assumed one boolean field schema
for both fixed references. Original optimizer24 uses exactly three immutable
source flags; retained12 uses a boolean. Revision03 explicitly verifies each
original schema, rejecting empty or truthy substitute dictionaries.

Both failed reports, their executed readers, exact source differences and
inverse proofs remain in the checkpoint. A separate read-only schema audit
records 30 actual fixed-reference, producer and child report structures. No
official report, original numeric or Version assertion, source hash, provenance
gate, EOF obligation or fresh-producer requirement changed.

## Reproduce the offline admission

```sh
python3 -I -S -B \
  /dev/shm/heptatorch-d26699e25fea/pr29-hosted-review/revision-03/review_pr29.py \
  --bundle /dev/shm/heptatorch-d26699e25fea/pr29-hosted-review/prepared-source-04 \
  --inputs /dev/shm/heptatorch-d26699e25fea/pr29-hosted-review/full-inputs-01.json \
  --output /dev/shm/heptatorch-d26699e25fea/pr31-full-replay-NEW
```

The output directory must be new. For relocation, create a separate input file
changing only local artifact path strings. Preserve every original CI report's
bound absolute path; the reader verifies source-relative mappings and SHA-256
rather than rewriting those reports.

This reader and its review do not rerun native programs or PyTorch. The separate
official-status receipt verifies all nine exact-head checks and the successful
80-step push job, while explicitly making no push-artifact admission claim or
merge action.
