#!/usr/bin/env python3
"""Freeze this offline PR31 review, without copying official ZIPs or executing runtimes."""
import hashlib
import io
import json
import lzma
from pathlib import Path
import stat
import tarfile

BASE = Path('/dev/shm/heptatorch-d26699e25fea')
REVIEW = BASE / 'pr29-hosted-review'
OUT = REVIEW / 'final-checkpoint-03'
ARCHIVE = REVIEW / 'final-checkpoint-03.tar.xz'


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def info(path):
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode), str(path)
    return {'bytes': s.st_size, 'mode': stat.S_IMODE(s.st_mode), 'sha256': digest(path)}


def main():
    assert not OUT.exists() and not ARCHIVE.exists()
    OUT.mkdir()
    files = {}
    root_names = [
        'README-final-03.md', 'README-quick-01.md', 'full-inputs-01.json',
        'quick-inputs-01.json', 'migration-custody.json', 'official-status-01.json',
        'prepare_sources.py', 'review_pr29.py', 'retained_evidence.py',
        'freeze_final_checkpoint.py',
    ]
    directories = [
        'prepared-reader-01', 'prepared-reader-02', 'prepared-reader-03',
        'prepared-source-01', 'prepared-source-02', 'prepared-source-03',
        'prepared-source-04', 'quick-admission-01', 'quick-checkpoint-01',
        'full-admission-01', 'full-admission-02', 'full-admission-03',
        'revision-02', 'revision-03',
    ]
    for name in root_names:
        p = REVIEW / name
        files[p.relative_to(BASE).as_posix()] = p
    for directory in directories:
        for p in sorted((REVIEW / directory).rglob('*')):
            if p.is_file():
                assert '__pycache__' not in p.parts
                files[p.relative_to(BASE).as_posix()] = p
    official_names = {
        'quick': ['run.json', 'jobs.json', 'artifacts.json', 'merge-checkout.json',
                  'source-commit.json', 'download-custody.json'],
        'main': ['run.json', 'jobs.json', 'artifacts.json', 'merge-checkout.json',
                 'source-commit.json', 'pr.json', 'checks.json', 'push-jobs.json',
                 'main.json', 'download-custody.json'],
    }
    for part, names in official_names.items():
        for name in names:
            p = BASE / 'pr31-hosted-artifacts' / part / name
            files[p.relative_to(BASE).as_posix()] = p
    identities = {name: info(p) for name, p in sorted(files.items())}
    inputs = json.loads((REVIEW / 'full-inputs-01.json').read_bytes())
    external = []
    for record in [q['artifact'] for q in inputs['quick']] + [inputs['native'][k] for k in ('reports', 'journals', 'retained_evidence')]:
        p = Path(record['zip'])
        actual = info(p)
        assert actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256']
        external.append({'path': str(p), 'artifact_id': record['artifact_id'], **actual})
    history_files = {}
    for p in sorted(Path(inputs['history']['directory']).rglob('*')):
        if p.is_file():
            history_files[str(p)] = info(p)
    p = Path(inputs['history']['native_first_failure_zip'])
    history_files[str(p)] = info(p)
    report = json.loads((REVIEW / 'full-admission-03/report.json').read_bytes())
    assert report['status'] == 'PASS_SCOPED_HOSTED_ADMISSION'
    assert report['admission_allowed'] is True
    assert (report['checks_passed'], report['checks_failed']) == (106570, 0)
    manifest = {
        'schema': 'heptatorch.pr31.peer-final-checkpoint.v1',
        'pull_request': 31,
        'source_head': inputs['source_head'],
        'source_tree': '09f37b090c0773d53db2bef527017fe9f0e298bf',
        'source_parent': '7e7e37be38457d88f214d45f261924983dc96b56',
        'status': 'PASS_SCOPED_HOSTED_ADMISSION',
        'checks_passed': 106570, 'checks_failed': 0,
        'native_or_torch_executions_by_reviewer': 0,
        'members': identities,
        'external_original_zips_not_duplicated': external,
        'external_original_failure_inputs_not_duplicated': history_files,
        'preserved_history': ['first Make-scope reader failure', 'second reference-schema reader failure',
                              'all original reader/preparation versions including incomplete ENOSPC preparation',
                              'unchanged quick PASS with main pending', 'original official metadata bytes'],
        'whole_pytorch_rewrite_complete': False,
        'full_schema_parity': {'qualified': 0, 'total': 2590},
        'whole_program_decision': 'HOLD',
        'archive_excludes': ['this archive', 'archive verification receipt', 'six separately preserved official ZIPs'],
    }
    mp = OUT / 'manifest.json'
    mp.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    files[mp.relative_to(BASE).as_posix()] = mp
    expected = {**identities, mp.relative_to(BASE).as_posix(): info(mp)}
    with tarfile.open(ARCHIVE, 'w:xz', preset=6) as tar:
        for name, p in sorted(files.items()):
            meta = expected[name]
            t = tarfile.TarInfo(name)
            t.size = meta['bytes']; t.mode = meta['mode']; t.mtime = 0
            t.uid = t.gid = 0; t.uname = t.gname = ''
            with p.open('rb') as f:
                tar.addfile(t, f)
    seen = set()
    expanded = 0
    with tarfile.open(ARCHIVE, 'r:xz') as tar:
        for member in tar:
            assert member.isfile() and member.name in expected and member.name not in seen
            seen.add(member.name)
            meta = expected[member.name]
            assert member.size == meta['bytes'] and member.mode == meta['mode']
            h = hashlib.sha256()
            stream = tar.extractfile(member)
            for block in iter(lambda: stream.read(1 << 20), b''):
                h.update(block)
            assert h.hexdigest() == meta['sha256'], member.name
            expanded += member.size
    assert seen == set(expected)
    with lzma.open(ARCHIVE, 'rb') as stream:
        for _ in iter(lambda: stream.read(1 << 20), b''):
            pass
    assert {name: info(p) for name, p in files.items()} == expected
    receipt = {
        'schema': 'heptatorch.verified-review-archive.v1',
        'status': 'PASS', 'archive': {'path': str(ARCHIVE), **info(ARCHIVE)},
        'manifest': {'path': str(mp), **info(mp)},
        'member_count': len(seen), 'expanded_file_bytes': expanded,
        'complete_member_set_sha_bytes_mode_verified': True,
        'full_xz_trailer_read': True, 'all_sources_unchanged_after': True,
        'original_zip_files_duplicated': 0,
    }
    rp = OUT / 'archive-verification.json'
    rp.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps(receipt, sort_keys=True))


if __name__ == '__main__':
    main()
