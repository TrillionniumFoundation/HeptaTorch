"""Independent, offline validation of the actual retained-446 CI evidence ZIP.

This module reads and hashes originals only. It never imports the producer,
loads an ELF, invokes a compiler, installs Torch, or rewrites a CI path.
"""
import ast
from collections import Counter
import hashlib
import io
import json
import lzma
from pathlib import PurePosixPath
import re
import struct
import tarfile

SOURCE='666230f05cc6942470006d1f184135321d8cbc26a6c6ba0bf7e3cf9857fe515b'
IMAGE='7568c0a4ec40d82d3a0b46d1e8a27499dd96e8fe3fd15433523131a196da89b5'
QUALIFIER='c71d40ea111b9c80e9d0987f7cd42729cc3f47ecf5a86b7e5d4ecf0659ec0ee2'
COMPILER='b1c851a0896fa6071f800e1146c3c27d0c6cf85059e9a6281b46d42908a3f59f'
LINKER='aae650e8822ef0b1e74d15108ad1d0f17ec791205ed5a158ec60b709f48f0e16'
REFERENCE12='ca8b5d3a7c679dcc5ad9a3d7b2bbd38f664c90e6474cf3e3c28496d5b716d1b3'
REFERENCE24='7ad0a2e718300a33c91a9212f14ada3c0c7997be7fc77f64bb557c2ecd858160'
EXCLUDED=['evidence-manifest.json','raw-evidence.tar.xz','report.json']

def sha(raw): return hashlib.sha256(raw).hexdigest()
def literal(source,name):
    values={}
    for node in ast.parse(source).body:
        if not isinstance(node,ast.Assign) or len(node.targets)!=1 or not isinstance(node.targets[0],ast.Name): continue
        class Resolve(ast.NodeTransformer):
            def visit_Name(self,n):
                if n.id not in values: raise ValueError(n.id)
                return ast.parse(repr(values[n.id]),mode='eval').body
        try: values[node.targets[0].id]=ast.literal_eval(Resolve().visit(node.value))
        except (ValueError,TypeError): continue
        if node.targets[0].id==name: return values[name]
    raise AssertionError(('missing literal constant',name))

def identity_fields(value):
    keys={'name','case','index','family','variant','status','reference_status','native_executed'}
    result={k:value[k] for k in keys if k in value}
    for key in ('rows','cases','variants','records'):
        if isinstance(value.get(key),list): result[key]=[identity_fields(x) for x in value[key] if isinstance(x,dict)]
    return result

def frozen_summary(audit,current,expected,label):
    audit.check(label+': exact frozen summary schema',set(current)==set(expected))
    for key,value in expected.items():
        if not isinstance(value,(dict,list)):
            audit.check(label+': frozen scalar '+key,type(current[key]) is type(value) and current[key]==value)
    audit.check(label+': fixed classification order',identity_fields(current)==identity_fields(expected))

def options(command):
    assert command[1:4]==['-I','-S','-B'] and len(command[5:])%2==0
    result={}
    for key,value in zip(command[5::2],command[6::2]):
        assert key.startswith('--') and key not in result
        result[key]=value
    return result

def frames(raw,magic):
    result=[];offset=0
    while offset<len(raw):
        assert len(raw)-offset>=16 and raw[offset:offset+8]==magic
        size=struct.unpack_from('<Q',raw,offset+8)[0]
        assert size<=1048576 and size<=len(raw)-offset-16
        result.append(raw[offset+16:offset+16+size]);offset+=16+size
    assert offset==len(raw)
    return result

class Bytes:
    def __init__(self,audit,base,aggregate,files,metadata,sources,tracked):
        self.audit,self.base=audit,base
        self.aggregate=aggregate;self.files=files;self.metadata=metadata
        self.sources,self.tracked=sources,tracked
        self.root=PurePosixPath(aggregate['producer']['current_receipt_directory']).parent
        self.repo=PurePosixPath(aggregate['commands'][0]['command'][4]).parents[2]
        assert self.root.is_absolute() and self.repo.is_absolute()
    def relative(self,path,root):
        path=PurePosixPath(path)
        assert path.is_absolute() and '..' not in path.parts
        return path.relative_to(root).as_posix()
    def record(self,record,label,relative=None,source=None):
        if source is None:
            name=self.relative(record['path'],self.root)
            if relative is not None: self.audit.check(label+': original output location',name==relative)
            raw=self.files[name];meta=self.metadata[name]
        else:
            name=self.relative(record['path'],self.repo)
            self.audit.check(label+': original source location',name==source)
            raw=self.sources[source];meta=self.tracked[source]
        expected_mode=(int(meta['mode'],8)&0o7777) if isinstance(meta['mode'],str) else meta['mode']
        self.audit.check(label+': original record bytes',record['sha256']==sha(raw)==meta['sha256']
                         and record['bytes']==len(raw)==meta['bytes']
                         and ('mode' not in record or record['mode']==expected_mode))
        if 'report' in record:
            self.audit.check(label+': embedded parsed record equals original JSON',record['report']==self.base.decode(raw))
        return self.base.decode(raw) if 'report' in record else raw
    def stream(self,record,label): return self.record(record,label)
    def runtime(self,value,label):
        source=[value[k] for k in ('source_sha256','native_source_sha256','runtime_source_sha256') if k in value]
        image=[value[k] for k in ('native_sha256','native_executable_sha256','executable_sha256','binary_sha256') if k in value]
        self.audit.check(label+': exact retained runtime',bool(source) and all(x==SOURCE for x in source)
                         and bool(image) and all(x==IMAGE for x in image))

def unpack(audit,base,archive,manifest):
    audit.check('446 raw manifest status and explicit self-reference policy',
                manifest['schema']=='heptatorch.retained-integration-evidence.v1'
                and manifest['status']=='COMPLETE_BYTES_VERIFIED'
                and manifest['all_member_lengths_SHA256_modes_verified'] is True
                and manifest['complete_XZ_trailer_verified'] is True
                and manifest['expanded_originals_unchanged'] is True
                and manifest['expanded_originals_deleted'] is False
                and manifest['excluded_top_level_only']==EXCLUDED)
    listed=manifest['files']
    audit.check('446 archive count comes from this actual manifest',len(listed)==manifest['file_count'] and len(listed)>0
                and manifest['expanded_bytes']==sum(x['bytes'] for x in listed.values())
                and not (set(EXCLUDED)&set(listed)))
    audit.check('446 manifest binds actual archive bytes',manifest['archive']['path']=='raw-evidence.tar.xz'
                and manifest['archive']['sha256']==sha(archive) and manifest['archive']['bytes']==len(archive))
    files={}
    with tarfile.open(fileobj=io.BytesIO(archive),mode='r:xz') as tf:
        for item in tf:
            name=base.member_name(item.name)
            audit.check('446 unique ordinary evidence member '+name,item.isfile() and name not in files and name in listed)
            raw=tf.extractfile(item).read();meta=listed[name]
            audit.check('446 every evidence member exact original bytes '+name,
                        item.size==len(raw)==meta['bytes'] and item.mode==meta['mode'] and sha(raw)==meta['sha256'])
            files[name]=raw
    audit.check('446 no missing or extra archived member',set(files)==set(listed))
    expanded=0
    with lzma.LZMAFile(io.BytesIO(archive),'rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''): expanded+=len(block)
    audit.check('446 full XZ stream and footer read',expanded==manifest['tar_stream_bytes'])
    return files

def review_retained_evidence(audit,base,spec,ctx,main_bytes,reports,sources,tracked):
    z,official=audit.archive(spec)
    audit.check('446 evidence artifact official same-run identity',official['workflow_run']['id']==ctx['run']['id']
                and official['name']==f"retained-gradient-native-evidence-{ctx['run']['id']}-{ctx['run']['run_attempt']}-native")
    audit.check('446 exact three-file artifact; no implicit historical archive',set(z)=={
        'retained-gradients-ci-raw.tar.xz','retained-gradients-ci-raw-manifest.json','hosted-retained-gradients-native.json'})
    raw=z['hosted-retained-gradients-native.json']
    audit.check('446 aggregate mirror is exact main-report bytes',raw==main_bytes['hosted-retained-gradients-native.json'])
    audit.check('446 raw manifest mirror is exact main-report bytes',
                z['retained-gradients-ci-raw-manifest.json']==main_bytes['retained-gradients-ci-raw-manifest.json'])
    d=base.decode(raw);m=base.decode(z['retained-gradients-ci-raw-manifest.json'])
    audit.check('446 actual default fresh producer; never reuse local e981',
                d['schema']=='heptatorch.retained-gradients-integration-qualification.v1' and d['status']=='PASS'
                and d['source_sha256']==SOURCE and d['native_sha256']==IMAGE
                and d['integration_script_sha256']==QUALIFIER==sha(sources['tests/qualify_retained_gradients.py'])
                and d['producer_executed_this_invocation'] is True and d['producer_receipt_reused'] is False
                and not any(k.startswith('producer_reuse') for k in d))
    audit.check('446 scoped counters retain zero full schema closure',d['Torch_executed_here'] is d['production_host_numerics'] is False
                and d['overall_decision']=='HOLD' and d['pytorch_api_denominator']==2590
                and d['newly_closed_pytorch_api_rows']==d['full_schema_parity']==0
                and d['full_rewrite_complete'] is False and d['all_inputs_unchanged'] is True)
    e=d['complete_current_execution_evidence']
    audit.check('446 aggregate binds full current archive and manifest',
                e['archive']['sha256']==sha(z['retained-gradients-ci-raw.tar.xz'])
                and e['archive']['bytes']==len(z['retained-gradients-ci-raw.tar.xz'])
                and e['manifest']['sha256']==sha(z['retained-gradients-ci-raw-manifest.json'])
                and e['manifest']['bytes']==len(z['retained-gradients-ci-raw-manifest.json'])
                and e['file_count']==m['file_count'] and e['expanded_bytes']==m['expanded_bytes']
                and e['all_member_bytes_and_modes_verified'] is e['complete_XZ_trailer_verified'] is True
                and e['excluded_top_level_only']==EXCLUDED)
    files=unpack(audit,base,z['retained-gradients-ci-raw.tar.xz'],m)
    bind=Bytes(audit,base,d,files,m['files'],sources,tracked)
    required_inputs={str(bind.root/name) for name in files}
    required_inputs.update(str(bind.root/name) for name in ('raw-evidence.tar.xz','evidence-manifest.json'))
    required_inputs.update(str(bind.repo/name) for name in (
        'tests/qualify_retained_gradients.py','compatibility/pytorch-oracle-lock.json',
        'tools/retained_gradients/profile.json','tools/gradient_adam_distributions/profile.json'))
    audit.check('446 actual executed qualifier archived',files['executed-integration.py']==sources['tests/qualify_retained_gradients.py'])
    recipes=re.findall(rb'(?m)^test-retained-gradients:[^\n]*\n(?:\t[^\n]*\n)+',sources['Makefile'])
    audit.check('446 unique source-bound Make target recipe',len(recipes)==1)
    recipe=recipes[0]
    audit.check('446 original output root identifies the actual CI checkout',
                bind.root.parent.parent==bind.repo/'build' and bind.root.name=='observed'
                and re.fullmatch(r'\.retained-gradient-review\.[A-Za-z0-9]{6}',bind.root.parent.name) is not None
                and recipe.count(b'mktemp -d "$(CURDIR)/build/.retained-gradient-review.XXXXXX"')==1
                and recipe.count(b'--output "$$review/observed"')==1
                and recipe.count(b'tests/qualify_retained_gradients.py --repo "$(CURDIR)"')==1)
    code=sources['tests/qualify_retained_gradients.py']
    expected_steps=literal(code,'STEPS')
    expected_outer=[('producer17','tools/retained_gradients/qualify.py','producer/report.json'),
                    ('retained-actual12','tests/retained_nonleaf_review/replay_retained_nonleaf.py','retained-actual12/report.json'),
                    ('optimizer-case14-additive','tests/retained_nonleaf_review/replay_optimizer_retained_admission.py','optimizer-case14-additive/report.json'),
                    ('resources8','tests/retained_resource_review/test_resources.py','resources8/report.json'),
                    ('typed-handoff2','tests/retained_resource_review/test_typed_handoff.py','typed-handoff2/report.json'),
                    ('source-review','tests/retained_resource_review/source_review.py','source-review/report.json'),
                    ('frozen-extension-five-groups','tests/retained_extension_review/run_regressions.py','extension-regressions/report.json')]
    audit.check('446 all seven actual outer commands',len(d['commands'])==7
                and [x['name'] for x in d['commands']]==[x[0] for x in expected_outer])
    for row,(name,script,output) in zip(d['commands'],expected_outer):
        args=options(row['command'])
        required_inputs.add(str(bind.repo/script))
        audit.check('446 actual command and immutable script '+name,row['exit_code']==0
                    and row['runner_sha256']==sha(sources[script])==tracked[script]['sha256']
                    and PurePosixPath(row['command'][4])==bind.repo/script
                    and PurePosixPath(args['--output'])==bind.root/PurePosixPath(output).parent)
        bind.record(row['child'],'446 outer child '+name,relative=output)
        for kind in ('stdout','stderr'):
            bind.record(row[kind],'446 actual command stream '+name+'/'+kind,relative='logs/'+name+'.'+kind)
    producer=d['producer'];p=bind.record(producer['original_report'],'446 producer original17',relative='producer/report.json')
    bind.runtime(p,'446 original17')
    audit.check('446 producer recorded real compilation and all17 complete',p['schema']=='heptatorch.retained-gradient-cold-qualification.v1'
                and p['status']=='PASS' and p['native_executed'] is p['all_sources_unchanged'] is p['native_build_reproduced_exactly'] is True
                and p['step_count']==len(p['steps'])==len(p['suite_reports'])==len(producer['children'])==17
                and [s['name'] for s in p['steps']]==[s[0] for s in expected_steps])
    audit.check('446 original producer path is this invocation',producer['recorded_producer_directory']==producer['current_receipt_directory']
                ==str(bind.root/'producer') and producer['original_absolute_paths_and_argv_unchanged'] is True)
    own=base.decode(sources['tools/retained_gradients/package-manifest.json'])
    audit.check('446 all13 authoritative executed producer inputs',p['own_inputs_sha256']=={
        str(bind.repo/name):v['sha256'] for name,v in own['files'].items()}
                and p['package_manifest_sha256']==sha(sources['tools/retained_gradients/package-manifest.json'])
                and p['parent_manifest_sha256']==sha(sources['tools/gradient_adam_distributions/package-manifest.json']))
    adapters=literal(code,'ADAPTER_STEPS')
    for step,(name,filename,reference_name) in zip(p['steps'],expected_steps):
        args=options(step['command'])
        if name=='cold-native-build': script='tools/retained_gradients/build.py';relative='native/build.json'
        else:
            script=('tests/retained_gradient_regression/' if name in adapters else 'tests/gradient_adam_distributions_review/')+filename
            relative=name+'/report.json'
        child=producer['children'][name]
        current=bind.record(child,'446 producer child '+name,relative='producer/'+relative)
        frozen_name='validation/retained-gradients/reports/retained-portable-qualification-01/'+name+'.json'
        required_inputs.update((str(bind.repo/script),str(bind.repo/frozen_name)))
        expected=base.decode(sources[frozen_name])
        frozen_summary(audit,current,expected,'446 original17 '+name)
        bind.runtime(current,'446 original17 '+name)
        audit.check('446 exact executed producer argv and report '+name,
                    step['exit_code']==0 and PurePosixPath(step['command'][4])==bind.repo/script
                    and child['actual_script_sha256']==sha(sources[script])
                    and step['report_path']==relative and step['report_sha256']==child['sha256']
                    and step['report_status']==current['status'] and child['original_step']==step
                    and child['frozen_original_report_sha256']==sha(sources[frozen_name])
                    and p['suite_reports'][name]=={'path':relative,'sha256':child['sha256']}
                    and PurePosixPath(args['--output'])==bind.root/'producer'/PurePosixPath(relative).parent)
        for stream in ('stdout','stderr'):
            raw_stream=files['producer/'+name+'.'+stream]
            audit.check('446 original producer stream '+name+'/'+stream,
                        sha(raw_stream)==step[stream+'_sha256']==child['original_streams'][stream]['sha256']
                        and len(raw_stream)==child['original_streams'][stream]['bytes'])
        if reference_name is not None:
            ref='validation/gradient-adam-distributions/reference/'+reference_name
            required_inputs.add(str(bind.repo/ref))
            refpin=tracked[ref]['sha256']
            pins=[current[k] for k in ('reference_sha256','observations_sha256','actual_reference_sha256') if k in current]
            audit.check('446 original fixed reference binding '+name,bool(pins) and all(x==refpin for x in pins)
                        and PurePosixPath(args.get('--reference',args.get('--observations')))==bind.repo/ref)
        if 'oracle_provenance' in current: audit.provenance(current['oracle_provenance'],'446 '+name)
    cold=producer['children']['cold-native-build']['report']
    profile=base.decode(sources['tools/retained_gradients/profile.json'])
    for key in ('functions','blocks','instructions','descriptor_bytes','state_format','backing_format','source_sha256','native_sha256','units'):
        audit.check('446 exact cold native field '+key,cold[key]==profile[key])
    audit.check('446 actual nine independent native admissions',cold['status']=='PASS' and cold['link_exit']==0
                and cold['module_count']==len(cold['units'])==9 and cold['compiler_sha256']==COMPILER and cold['linker_sha256']==LINKER
                and all(row['compiler_exit']==0 for row in cold['units']))
    audit.check('446 original build receipt retains native source and image',
                producer['native']['all_nine_module_sources_and_objects_verified'] is True
                and producer['native']['source_sha256']==SOURCE and producer['native']['native_sha256']==IMAGE)
    # The detailed child record additionally contains original-script/stream
    # metadata; compare only its byte-bound record portion to the build receipt.
    nb=producer['native']['receipt']
    bind.record(nb,'446 full native build receipt',relative='producer/native/build.json')
    audit.check('446 cold ELF and authoritative HIA exact bytes',sha(files['producer/native/runtime.hepta'])==SOURCE
                and sha(files['producer/native/tensor-retained-session'])==IMAGE
                and len(files['producer/native/tensor-retained-session'])==cold['native_bytes']==profile['native_bytes'])
    units={}
    for row in cold['units']:
        for extension,kind in (('.hepta','source'),('.o','object')):
            name=row['name']+extension;original=files['producer/native/'+name]
            audit.check('446 actual native unit byte identity '+name,sha(original)==row[kind+'_sha256'])
            units[name]={'bytes':len(original),'sha256':sha(original)}
    bridge=base.decode(files['producer/distribution-build-field-bridge.json'])
    audit.check('446 distribution build alias changes no original field',bridge==dict(cold,runtime_source_sha256=SOURCE,executable_sha256=IMAGE)
                and p['distribution_receipt_bridge']['sha256']==sha(files['producer/distribution-build-field-bridge.json'])
                and p['distribution_receipt_bridge']['original_cold_build_sha256']==producer['children']['cold-native-build']['sha256'])
    manifests=literal(code,'MANIFESTS')+(('tools/gradient_adam_distributions/package-manifest.json',
                                       sha(sources['tools/gradient_adam_distributions/package-manifest.json']),45),)
    relocations=literal(code,'RELOCATIONS')
    audit.check('446 all six frozen input manifests',len(d['frozen_manifests'])==len(manifests)==6)
    for row,(path,pin,count) in zip(d['frozen_manifests'],manifests):
        required_inputs.add(str(bind.repo/path))
        value=base.decode(sources[path]);declared=value['files']
        records=[dict(v,path=k) for k,v in declared.items()] if isinstance(declared,dict) else declared
        expected_relocations={}
        audit.check('446 frozen package manifest '+path,row['sha256']==pin==sha(sources[path])
                    and row['file_count']==len(records)==count and PurePosixPath(row['path'])==bind.repo/path
                    and row['all_member_bytes_hashes_declared_modes_verified'] is True)
        for record in records:
            installed=relocations.get((path,record['path']),record['path'])
            required_inputs.add(str(bind.repo/installed))
            if installed!=record['path']: expected_relocations[record['path']]=installed
            authoritative=tracked[installed]
            audit.check('446 immutable package member '+installed,record['sha256']==authoritative['sha256']
                        and record['bytes']==authoritative['bytes']
                        and ('mode' not in record or record['mode']==(int(authoritative['mode'],8)&0o7777)))
        audit.check('446 explicit doc relocation only '+path,row['explicit_document_path_relocations']==expected_relocations)
    refs=d['fixed_actual_references']
    audit.check('446 references were not regenerated',refs['eleven_provenance_checks_each'] is True and refs['Torch_reexecuted'] is False)
    for key,name,pin in (('retained12','torch-retained-nonleaf.json',REFERENCE12),('optimizer24','original-optimizer-observations.json',REFERENCE24)):
        original=bind.record(refs[key],'446 exact original actual reference '+key,
                             source='validation/retained-nonleaf-review/reference/'+name)
        audit.check('446 fixed actual reference status '+key,refs[key]['sha256']==pin and original['status']=='OBSERVED'
                    and original['native_executed'] is False and original['source_files_unchanged'] is True)
        audit.provenance(original['oracle_provenance'],'446 actual '+key)
    children=d['new_review_children']
    names={'retained_actual12':'retained-actual12/report.json','optimizer_case14_additive':'optimizer-case14-additive/report.json',
           'resources8':'resources8/report.json','typed_handoff2':'typed-handoff2/report.json',
           'source_review':'source-review/report.json','inherited_extensions':'extension-regressions/report.json'}
    audit.check('446 all six separate outer child records',set(children)==set(names))
    current={k:bind.record(children[k],'446 new actual child '+k,relative=n) for k,n in names.items()}
    r=current['retained_actual12'];frozen=base.decode(sources['validation/retained-nonleaf-review/actual12-native-01.json'])
    bind.runtime(r,'446 strict actual12')
    audit.check('446 strict original12 all variants actually executed',r['status']=='QUALIFIED_EXPOSED_SCOPE'
                and r['variants_executed']==r['variants_qualified']==len(r['rows'])==12 and r['unexpected_failures']==0
                and r['all_inputs_unchanged'] is True and r['inputs']['observations']==REFERENCE12
                and r['inputs']['binary']==IMAGE and r['inputs']['source']==SOURCE
                and [(x['case'],x['variant'],x['reference_json_pointer']) for x in r['rows']]
                    ==[(x['case'],x['variant'],x['reference_json_pointer']) for x in frozen['rows']]
                and r['adam_parameter_moment_tolerance']==frozen['adam_parameter_moment_tolerance']
                and all(x['responses_before_stdin_eof'] is True and x['exit_code']==0
                        and x['status']=='QUALIFIED_EXPOSED_SCOPE' for x in r['rows'])
                and r['reference_provenance_checks']==refs['retained12']['report']['oracle_provenance']['checks'])
    r=current['optimizer_case14_additive']
    audit.check('446 row14 two original subobservations only',r['status']=='ORIGINAL_RETAINED_NONLEAF_SUBOBSERVATION_QUALIFIED'
                and r['reference_outcomes_matched']==2 and r['exit_code']==0
                and r['all_responses_before_stdin_eof'] is r['all_inputs_unchanged'] is True
                and r['original_frozen_replay_modified'] is r['original_frozen_report_reclassified'] is False
                and r['other_original_24_observations_reexecuted'] is False
                and r['inputs']['observations']==REFERENCE24 and r['inputs']['binary']==IMAGE and r['inputs']['source']==SOURCE)
    r=current['resources8'];bind.runtime(r,'446 resources8')
    audit.check('446 eight actual resource cases',r['status']=='PASS' and r['case_count']==r['passed']==len(r['cases'])==8
                and r['failed']==0 and r['input_custody_after'] is True)
    r=current['typed_handoff2'];bind.runtime(r,'446 typed2')
    audit.check('446 two real linear typed directions',r['status']=='PASS' and r['case_count']==r['passed']==len(r['cases'])==2
                and r['failed']==0 and r['linked_modules']==19 and len(r['units'])==18
                and r['compiler_sha256']==COMPILER and r['linker_sha256']==LINKER
                and r['previous_source_sha256']==base.PROFILES['428']['source']
                and r['previous_native_sha256']==base.PROFILES['428']['image']
                and r['raw_pointer_import'] is r['owner_descriptor_memcpy'] is False
                and r['all_source_custody_unchanged'] is True and all(x['inverse_byte_identical'] is True for x in r['units']))
    requests=frames(files['typed-handoff2/transport/requests.frames.bin'],b'HTOWNR01')
    responses=frames(files['typed-handoff2/transport/responses.frames.bin'],b'HTOWNS01')
    audit.check('446 fresh complete actual typed raw transport',len(requests)==len(responses)==len(r['frames'])==r['frame_count']==10)
    for q,a,record in zip(requests,responses,r['frames']):
        audit.check('446 fresh typed original frame bytes',sha(q)==record['request_sha256'] and sha(a)==record['response_sha256'])
    fresh=d['fresh_typed_handoff_raw']
    audit.check('446 fresh typed run does not reconstruct old raw gap',fresh['complete_fresh_raw_transport'] is True
                and fresh['original_interrupted_execution_reconstructed'] is False
                and fresh['request_frames']==fresh['response_frames']==10)
    actual_typed_files={name.removeprefix('typed-handoff2/') for name in files if name.startswith('typed-handoff2/')}
    audit.check('446 typed inventory includes every actual archived member',
                bool(actual_typed_files) and set(fresh['files'])==actual_typed_files)
    for name,meta in fresh['files'].items():
        audit.check('446 typed complete raw inventory '+name,m['files']['typed-handoff2/'+name]==meta)
    audit.check('446 typed actual inventory cardinality',fresh['file_count']==len(fresh['files'])
                and fresh['expanded_bytes']==sum(x['bytes'] for x in fresh['files'].values()))
    r=current['source_review'];bind.runtime(r,'446 source review')
    audit.check('446 source-to-unit read-only boundary',r['status']=='PASS' and r['source_functions']==446 and r['parent_functions']==428
                and r['unchanged_parent_bodies']==410 and r['all446_core_bodies_in_exactly_one_actual_unit'] is True
                and r['all_inputs_unchanged'] is True and r['native_executed_by_this_review'] is r['Torch_executed_by_this_review'] is False)
    r=current['inherited_extensions'];bind.runtime(r,'446 inherited extensions')
    expected_extension=base.decode(sources['validation/retained-extension-review/report.json'])
    audit.check('446 five extension groups with all six actual commands',r['status']=='PASS'
                and r['commands_executed']==r['successful_commands']==len(r['suites'])==6
                and r['regression_groups']==5 and r['input_custody_after'] is True
                and [x['name'] for x in r['suites']]==[x['name'] for x in expected_extension['suites']]
                and r['cross6_adapter']==expected_extension['cross6_adapter']
                and r['cross6_adapter']['inverse_byte_identical'] is True)
    for row in r['suites']:
        raw_child=files['extension-regressions/children/'+row['name']+'/report.json']
        audit.check('446 original extension actual child '+row['name'],row['exit_code']==0 and sha(raw_child)==row['report_sha256']
                    and len(raw_child)==row['report_bytes'] and base.decode(raw_child)==row['report'])
        for kind in ('stdout','stderr'):
            meta=m['files']['extension-regressions/logs/'+row['name']+'.'+kind]
            audit.check('446 original extension stream '+row['name']+'/'+kind,meta=={k:row[kind][k] for k in ('bytes','mode','sha256')})
    oldfail=bind.record(d['original_93_94_negative'],'446 old genuine contract failure',
                        source='validation/retained-gradients/reports/old-93-94-contract-failure.json')
    audit.check('446 original 93/94 unknown-command test remains FAIL',oldfail['status']=='FAIL')
    gap=bind.record(d['historical_raw_gap'],'446 historical raw gap',source='validation/retained-resource-review/qualification.json')
    recovery=gap['recovery']
    audit.check('446 earlier incomplete archive is not relabeled',recovery['original_archive_complete'] is False
                and recovery['original_typed_raw_frames_missing'] is True
                and recovery['missing_original_bytes_reconstructed'] is False
                and recovery['original_process_completion']=='UNKNOWN')
    ledger=d['distribution_ledger']
    audit.check('446 all18 distribution gaps plus four ordinary transaction differences preserved',ledger['reference_cases']==183
                and ledger['unrepresented_zero_based_indices']==base.OPEN_DIST
                and ledger['atomic_difference_zero_based_indices']==base.ATOMIC_DIFF and ledger['all_rng_complete'] is False)
    for name,explicit in (('distribution-atomic-183',False),('distribution-explicit-183',True)):
        r=producer['children'][name]['report']
        counts={'PASS':165,'OPEN_UNREPRESENTED':18} if explicit else {'PASS':161,'OPEN_TRANSACTION_DIFFERENCE':4,'OPEN_UNREPRESENTED':18}
        audit.check('446 fixed183 unchanged classification '+name,r['reference_cases']==len(r['rows'])==183
                    and r['counts']==dict(Counter(x['status'] for x in r['rows']))==counts)
        for i,row in enumerate(r['rows']):
            expected='OPEN_UNREPRESENTED' if i in base.OPEN_DIST else ('OPEN_TRANSACTION_DIFFERENCE' if not explicit and i in base.ATOMIC_DIFF else 'PASS')
            audit.check('446 original183 exact index/status '+name+'/'+str(i),row['index']==i and row['status']==expected)
    history=d['historical_optimizer_mapping']
    audit.check('446 historical optimizer mapping stays18+1+5 and prior23+1',history['unchanged_original_classification']==[18,1,5]
                and history['inherited_union_before_additive_retain']=={'qualified_exposed_scope':23,'partial_cases':1,'partial_one_based_indices':[14]}
                and history['old_report_reclassified'] is False
                and history['original_24_report']==producer['children']['original-optimizer-24-mapping'])
    b=d['optimizer_case14_additive_boundary']
    audit.check('446 additive closure scope is not a rewritten old report',b['same_original_reference_24_sha256']==REFERENCE24
                and all(b[k] is True for k in ('original_report_keeps_18_qualified_1_partial_5_open',
                    'inherited_union_keeps_23_qualified_plus_partial14','additive_two_original_subobservations_passed',
                    'separate_actual_retained_12_variants_passed')) and b['full_optimizer_API_closure_claimed'] is False)
    audit.check('446 exact aggregate scoped counts',d['counts']=={
        'producer_steps':17,'retained_actual_variants':12,'additive_original_case14_subobservations':2,
        'resource_cases':8,'typed_directions':2,'read_only_source_review':1,'extension_groups':5,'extension_commands':6})
    open_domains=d['unclosed_domains']
    audit.check('446 all explicitly recorded unresolved domains retained',
                open_domains=={'distribution_unrepresented_cases':18,'ordinary_distribution_atomic_side_effect_differences':4,
                  'incoming_materialization_unrepresented_variants':3,'legacy_presence_state_lifecycle_observations':[8,65],
                  'legacy_gradient_clear_state_and_step_observations':[11,9,30],'legacy_gradient_clear_Adam_word_differences':6,
                  'bool_native_dropout_other_dtypes_devices_higher_order_full_API':'OPEN',
                  'historical_raw_archive_gap':'PRESERVED; fresh typed execution is separate complete evidence',
                  'live32_frozen35':'SEPARATE; no admission inferred by this aggregate'})
    # Every checked current output is verified against the actual archive.
    # Every repository input is verified against our immutable target-tree
    # inventory. Only explicitly pinned compiled parent/tool products are
    # admitted outside those two namespaces.
    parent_profile=base.decode(sources['tools/gradient_adam_distributions/profile.json'])
    parent=d['parent_native'];parent_root=PurePosixPath(parent['path'])
    audit.check('446 parent is exact frozen428 native identity',parent['source_sha256']==base.PROFILES['428']['source']
                and parent['native_sha256']==base.PROFILES['428']['image']
                and parent['all_nine_module_sources_and_objects_verified'] is True)
    parent_record=parent['receipt'];parent_build=parent_record['report']
    for k in ('functions','blocks','instructions','descriptor_bytes','source_sha256','native_sha256','units'):
        audit.check('446 actual parent build field '+k,parent_build[k]==parent_profile[k])
    parent_pins={'runtime.hepta':base.PROFILES['428']['source'],'tensor-gradient-adam-distributions-session':base.PROFILES['428']['image'],
                 'build.json':parent_record['sha256']}
    for row in parent_profile['units']:
        parent_pins[row['name']+'.hepta']=row['source_sha256'];parent_pins[row['name']+'.o']=row['object_sha256']
    required_inputs.update(str(parent_root/name) for name in parent_pins)
    producer_options=options(d['commands'][0]['command'])
    typed_command=next(x for x in d['commands'] if x['name']=='typed-handoff2')
    typed_options=options(typed_command['command'])
    required_inputs.update((producer_options['--compiler'],producer_options['--linker']))
    stack_root=PurePosixPath(typed_options['--stack-build'])
    required_inputs.update(str(stack_root/'native'/name) for name in ('stack-module-compiler','stack-linker-session'))
    audit.check('446 complete required input custody cannot be empty or partial',
                bool(d['checked_inputs']) and required_inputs<=set(d['checked_inputs']),
                required_count=len(required_inputs),observed_count=len(d['checked_inputs']),
                missing=sorted(required_inputs-set(d['checked_inputs'])))
    categories=Counter()
    for path,meta in d['checked_inputs'].items():
        value=PurePosixPath(path)
        audit.check('446 checked-input structure '+path,value.is_absolute() and '..' not in value.parts
                    and base.plain_sha(meta['sha256']) and isinstance(meta['bytes'],int) and meta['bytes']>=0
                    and isinstance(meta['mode'],int))
        if value.is_relative_to(bind.root):
            name=value.relative_to(bind.root).as_posix()
            if name=='raw-evidence.tar.xz': expected={'sha256':sha(z['retained-gradients-ci-raw.tar.xz']),'bytes':len(z['retained-gradients-ci-raw.tar.xz']),'mode':m['archive']['mode']}
            elif name=='evidence-manifest.json': expected={'sha256':sha(z['retained-gradients-ci-raw-manifest.json']),'bytes':len(z['retained-gradients-ci-raw-manifest.json']),'mode':e['manifest']['mode']}
            else: expected=m['files'][name]
            audit.check('446 checked current raw output '+name,meta==expected);categories['current_archived_output']+=1
        elif value.is_relative_to(parent_root):
            name=value.relative_to(parent_root).as_posix()
            audit.check('446 checked compiled parent product '+name,name in parent_pins and meta['sha256']==parent_pins[name]);categories['frozen_parent_build']+=1
        elif value.is_relative_to(bind.repo) and value.relative_to(bind.repo).as_posix() in tracked:
            name=value.relative_to(bind.repo).as_posix();expected=tracked[name]
            audit.check('446 checked exact target-tree input '+name,meta['sha256']==expected['sha256'] and meta['bytes']==expected['bytes']
                        and meta['mode']==(int(expected['mode'],8)&0o7777));categories['target_tree_source']+=1
        else:
            audit.check('446 only exact native tool products outside known roots',
                        (value.name=='stack-module-compiler' and meta['sha256']==COMPILER)
                        or (value.name=='stack-linker-session' and meta['sha256']==LINKER))
            categories['pinned_native_tool']+=1
    return {'status':'ACTUAL_FRESH_CI_EVIDENCE_VERIFIED','source_sha256':SOURCE,'native_sha256':IMAGE,
            'integration_script_sha256':QUALIFIER,'producer_executed_this_invocation':True,'producer_receipt_reused':False,
            'actual_archive_file_count':m['file_count'],'actual_archive_expanded_bytes':m['expanded_bytes'],
            'all_archive_members_bytes_SHA_modes_verified':True,'complete_XZ_trailer_read':True,
            'actual_outer_commands':len(d['commands']),'producer_steps':17,'new_outer_groups':6,
            'checked_input_count':len(d['checked_inputs']),'required_input_count':len(required_inputs),
            'checked_input_categories':dict(categories),
            'unit_members':units,'historical_typed_raw_gap_preserved':True,'old93_94_failure_preserved':True,
            'full_optimizer_API_closed':False,'full_rewrite_complete':False}
