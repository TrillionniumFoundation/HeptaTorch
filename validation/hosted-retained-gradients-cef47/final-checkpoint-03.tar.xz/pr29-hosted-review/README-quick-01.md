# PR31 independent hosted review — quick checkpoint

This checkpoint belongs to **PR31**, head
`cef47b8fc36e4afefad4b4c4e53625f8f62e0a57`, tree
`09f37b090c0773d53db2bef527017fe9f0e298bf`, based on
`7e7e37be38457d88f214d45f261924983dc96b56`.
The directory name `pr29-hosted-review` predates the assigned pull-request number.
It does not refer to the separate int64 PR29.

## Executed scope

The three official artifacts from run `43873971672`, attempt 1, have each been
checked against the original GitHub run, job, artifact, source-commit and merge
checkout JSON. The original JSON and ZIP bytes are preserved. Each quick job
completed all 13 actual steps successfully and exported 185 original files.

| Profile | Job | Native controls | Copied snapshot controls | Live oracle | Frozen oracle |
| --- | --- | --- | --- | --- | --- |
| 355 | 133322084782 | 3 / 13 frames | 4 positive + 18 negative | 32 passed | 35 passed |
| 428 | 133322084713 | 3 / 13 frames | 4 positive + 18 negative | 32 passed | 35 passed |
| 446 | 133322084267 | 3 / 13 frames | 4 positive + 18 negative | 32 passed | 35 passed |

The offline reviewer completed **52,088 checks with no failures**. It rechecked
the copied JSON controls without running a native program or PyTorch. The
unchanged frozen oracle's inner report, original EOF/exit checks, post-close
version checks, 6,344 frames, 2,590,274 comparisons and 283 recorded legacy state
version differences are required independently for each profile. The live
oracle's original plan and all 11 provenance checks are also required.

The result is `PASS_QUICK_COMPONENTS_MAIN_PENDING`, with
`admission_allowed=false`. Main CI, its cold producer execution and its retained
native evidence are **not admitted by this checkpoint**. Full-schema parity
remains 0 of 2,590 and the whole-project decision remains HOLD.

## Exact replay

From the existing shared paths:

```sh
python3 -I -S -B \
  /dev/shm/heptatorch-d26699e25fea/pr29-hosted-review/review_pr29.py \
  --bundle /dev/shm/heptatorch-d26699e25fea/pr29-hosted-review/prepared-source-04 \
  --inputs /dev/shm/heptatorch-d26699e25fea/pr29-hosted-review/quick-inputs-01.json \
  --quick-only \
  --output /dev/shm/heptatorch-d26699e25fea/pr29-hosted-review/quick-replay-NEW
```

The output directory must not already exist. Relocation changes only the path
strings in a new input specification and the CLI arguments. Original hosted
reports retain their CI absolute paths; the reviewer binds those paths by the
source-bound basename/hash mapping rather than rewriting them.

`prepared-source-04` is the complete source checkpoint. Its manifest binds all
3,833 tracked files and exact Git tree objects, with 98 selected source/receipt
files carried for offline interpretation. The first two earlier preparation
snapshots and the incomplete ENOSPC attempt remain separate historical records.
Only `prepared-source-04` is used here.

The quick artifact originals remain under
`/dev/shm/heptatorch-d26699e25fea/pr31-hosted-artifacts/quick/`.
The checkpoint archive carries the reader, source bundle, executed quick report,
input specification and original API JSON. It references the three original ZIPs
by exact length and SHA-256; it does not make a second copy of them.

## Main-CI gate prepared for later execution

The same reader, without `--quick-only`, requires the actual main run's original
reports ZIP, private-node journal ZIP and separate retained-native-evidence ZIP.
It binds 33 declared envelopes and 63 exact root reports, retaining all old 58
reports and their status/plan obligations. The retained qualifier must be the
exact c71 source and must have run the producer freshly in that CI invocation:
reuse is rejected. The actual archive inventory determines its member count;
the historical local reused receipt and its 2,051 members are not substituted.

The added evidence reader requires a nonempty, complete `checked_inputs` set and
exact equality between the typed-handoff inventory and its archived subtree.
Those two source-review findings were corrected before this checkpoint; no
hosted report or numeric expectation was modified.
