#!/usr/bin/env python3
"""Freeze the prepared PR29 source tree; never execute native or Torch."""
import argparse
import ast
import base64
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess

TREE = '09f37b090c0773d53db2bef527017fe9f0e298bf'
BASE = '7e7e37be38457d88f214d45f261924983dc96b56'
BASE_READER = '123aa0b96823a5f78d14a1998ab5cb992ac7172b65304b11905bc0d457967f59'
OLD50 = '7bdb005879b75e38105e68b44e08981680bf29742881ea9cb2936d58a5e9f34b'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def gitsha(kind, raw): return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def dump(path, value): path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--publish-manifest',type=Path,required=True)
    p.add_argument('--baseline',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    m=json.loads(a.publish_manifest.read_bytes())
    assert m['expected_tree']==TREE and m['base_commit']==BASE
    root=Path(m['root'])
    env=os.environ.copy()
    env['GIT_OBJECT_DIRECTORY']=m['objects']
    env['GIT_ALTERNATE_OBJECT_DIRECTORIES']=m['alternate_objects']
    def git(*args):
        return subprocess.run(['git',*args],cwd=root,env=env,capture_output=True,check=True).stdout
    flat={}
    for row in git('ls-tree','-rz',TREE).split(b'\0'):
        if not row: continue
        header,name=row.split(b'\t',1)
        mode,kind,oid=header.decode().split()
        assert kind=='blob' and mode in ('100644','100755')
        flat[name.decode()]={'mode':mode,'git_blob':oid}
    old_manifest=json.loads((a.baseline/'published-source-manifest.json').read_bytes())
    selected={r['path'] for r in old_manifest['files']}
    selected.update({
        'Makefile',
        'tests/qualify_retained_gradients.py',
        'tests/private_node_accounting/restore_native_inputs.py',
        'tests/private_node_accounting/test_native_accounting.py',
        'tools/retained_gradients/profile.json',
        'tools/retained_gradients/package-manifest.json',
        'tools/retained_gradients/build.py',
        'tools/retained_gradients/qualify.py',
        'tools/gradient_adam_distributions/package-manifest.json',
        'validation/retained-gradients/frozen-handoff-manifest.json',
        'validation/retained-nonleaf-review/frozen-handoff-manifest.json',
        'validation/retained-resource-review/frozen-handoff-manifest.json',
        'validation/retained-extension-review/frozen-handoff-manifest.json',
        'validation/retained-resource-review/qualification.json',
        'validation/retained-gradients/reports/old-93-94-contract-failure.json',
        'validation/retained-nonleaf-review/actual12-native-01.json',
        'validation/retained-nonleaf-review/reference/torch-retained-nonleaf.json',
        'validation/retained-nonleaf-review/reference/original-optimizer-observations.json',
        'validation/retained-extension-review/report.json',
        'validation/retained-integration-review/failure-custody-02/source-delta.json',
        'validation/retained-integration-review/failure-custody-02/report.json',
        'validation/retained-observer-profile/inverse-proof.json',
    })
    selected.update(n for n in flat if n.startswith('validation/retained-observer-profile/baseline-af33/') and n.endswith('.py'))
    # These authoritative sources and frozen receipts are small enough to ship
    # as exact bytes. Large original archives remain in the repository; their
    # full identity stays in the unchanged package manifests.
    selected.update(n for n in flat if n.startswith('validation/retained-gradients/reports/retained-portable-qualification-01/') and n.endswith('.json'))
    selected.update(n for n in flat if n.startswith(('tests/retained_nonleaf_review/','tests/retained_resource_review/','tests/retained_extension_review/','tests/retained_gradient_regression/')) and n.endswith('.py'))
    selected.update(n for n in flat if n.startswith('tests/gradient_adam_distributions_review/') and n.endswith('.py'))
    a.output.mkdir(parents=True,exist_ok=False)
    rows=[]
    witnesses={}
    def tree_bytes(oid):
        if oid not in witnesses:
            raw=git('cat-file','tree',oid)
            assert gitsha('tree',raw)==oid
            witnesses[oid]=base64.b64encode(raw).decode()
        return base64.b64decode(witnesses[oid])
    def entries(raw):
        pos=0; result={}
        while pos<len(raw):
            end=raw.index(b'\0',pos)
            mode,name=raw[pos:end].split(b' ',1)
            oid=raw[end+1:end+21].hex()
            assert len(oid)==40 and name not in result
            result[name.decode()]=(mode.decode(),oid)
            pos=end+21
        assert pos==len(raw)
        return result
    tracked={}
    for name in sorted(flat):
        path=root/name
        before=path.stat()
        blob=hashlib.sha1(b'blob '+str(before.st_size).encode()+b'\0')
        digest=hashlib.sha256()
        count=0
        with path.open('rb') as stream:
            for block in iter(lambda:stream.read(1048576),b''):
                count+=len(block);blob.update(block);digest.update(block)
        after=path.stat()
        assert count==before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns,name
        assert blob.hexdigest()==flat[name]['git_blob'],name
        tracked[name]={**flat[name],'bytes':count,'sha256':digest.hexdigest()}
        # Preserve a verifiable path from this blob through real Git tree
        # objects all the way to the predeclared immutable target tree.
        oid=TREE
        parts=PurePosixPath(name).parts
        for part in parts[:-1]:
            mode,oid=entries(tree_bytes(oid))[part]
            assert mode=='40000'
        mode,blob=entries(tree_bytes(oid))[parts[-1]]
        assert mode==flat[name]['mode'] and blob==flat[name]['git_blob']
        if name not in selected:
            continue
        raw=path.read_bytes()
        assert sha(raw)==tracked[name]['sha256'] and len(raw)==tracked[name]['bytes']
        target=a.output/'source'/name
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(raw)
        rows.append({'path':name,**flat[name],'bytes':len(raw),'sha256':sha(raw)})
    for name,pin in (('review_hosted_af33.py',BASE_READER),('old50-obligations.json',OLD50)):
        raw=(a.baseline/name).read_bytes();assert sha(raw)==pin
        (a.output/name).write_bytes(raw)
    manifest={'schema':'heptatorch.pr29.prepared-source-tree.v1','status':'PREPARED_NOT_RUN',
              'official_source_head':None,'expected_tree':TREE,'expected_parent':BASE,
              'native_executed':False,'Torch_executed':False,'files':rows,
              'selected_file_count':len(rows),'full_git_tree_blob_count':len(flat),
              'all_tracked_file_digests':tracked,
              'git_tree_witnesses':witnesses,'baseline_reader_sha256':BASE_READER,
              'old50_sha256':OLD50,'publication_head_must_be_bound_before_admission':True}
    dump(a.output/'source-manifest.json',manifest)
    print(json.dumps({'status':'PREPARED_NOT_RUN','files':len(rows),'bytes':sum(r['bytes'] for r in rows),
                      'manifest_sha256':sha((a.output/'source-manifest.json').read_bytes())}))
if __name__=='__main__': raise SystemExit(main())
