def dptr(w: mutbuf, t: u64) -> u64:
    page = getw(w, 4096 + (t >> 8) * 8)
    return page + (t & 255) * 448

def descriptor_page(w: mutbuf, slot: u64) -> u64:
    address = 4096 + (slot >> 8) * 8
    if getw(w, address) == 0:
        page = alloc(w, 114688)
        if getw(w, 0) != 0:
            return 0
        putw(w, address, page)
        putw(w, 6144 + (slot >> 8) * 8, getw(w, 80))
    return 1

def descriptor(w: mutbuf, rank: u64, shape: u64, requires: u64, own: u64) -> u64:
    if getw(w, 0) != 0:
        return 0
    if rank > 4 or requires > 1:
        return terror(w, 2)
    location = object_address(w, shape)
    if location > length(w) or 32 > length(w) - location:
        return terror(w, 2)
    slot = getw(w, 8)
    if slot >= 65536:
        return terror(w, 3)
    if getw(w, 120) == 18446744073709551615:
        return terror(w, 8)
    n = 1
    axis = 0
    while axis < rank:
        d = getw(w, shape + axis * 8)
        if d > 262144:
            return terror(w, 3)
        if d == 0:
            n = 0
        axis = axis + 1
    if n != 0:
        axis = 0
        while axis < rank:
            n = n * getw(w, shape + axis * 8)
            if n > 16777216:
                return terror(w, 3)
            axis = axis + 1
    if descriptor_page(w, slot) == 0:
        return 0
    if storage_capacity(w, 1, 0) == 0:
        return 0
    if own != 0 and storage_capacity(w, 3, 0) == 0:
        return 0
    p = dptr(w, slot)
    memory_fill(w, p, 448, 0)
    putw(w, p, rank)
    putw(w, p + 8, n)
    putw(w, p + 32, requires)
    putw(w, p + 64, choose(own != 0, slot, 0))
    putw(w, p + 200, 2)
    putw(w, p + 304, 1)
    putw(w, 120, getw(w, 120) + 1)
    putw(w, p + 320, getw(w, 120))
    axis = rank
    stride = 1
    while axis > 0:
        axis = axis - 1
        d = getw(w, shape + axis * 8)
        putw(w, p + 96 + axis * 8, d)
        putw(w, p + 128 + axis * 8, stride)
        if d != 0:
            stride = stride * d
    tid = so_slot_new(w, 1)
    tp = so_slot_lookup(w, 1, tid)
    putw(w, p + 192, tid)
    putw(w, p + 240, 1)
    so_uput(w, tp + 48, slot)
    if own != 0:
        data = alloc(w, n * 4)
        if getw(w, 0) != 0:
            return 0
        hid = getw(w, 80)
        hp = so_slot_lookup(w, 6, hid)
        sid = so_uget(w, hp + 16)
        vid = so_slot_new(w, 3)
        vp = so_slot_lookup(w, 3, vid)
        so_uput(w, vp + 24, 1)
        so_uput(w, tp + 16, sid)
        so_uput(w, tp + 24, vid)
        so_uput(w, tp + 40, n * 4)
        putw(w, p + 16, data)
        putw(w, p + 216, sid)
        putw(w, p + 224, vid)
        so_slot_drop(w, 6, hid)
    if requires != 0:
        work = alloc(w, n * 4)
        if getw(w, 0) != 0:
            return 0
        putw(w, p + 160, work)
        putw(w, p + 256, getw(w, 80))
    putw(w, 8, slot + 1)
    return slot

def init_state(w: mutbuf, slots: u64, pool: u64) -> u64:
    if length(w) != 139264 + so_state_size(slots, pool):
        return 0
    fill_range(w, 0, length(w), 0)
    so_state_init(w, slots, pool)
    putw(w, 8, 1)
    putw(w, 64, 3544407954084549704)
    return 1

def state_header(w: mutbuf) -> u64:
    if length(w) == 0:
        return 0
    if length(w) < 139264 + 2352 + 131072:
        return 7
    if so_state_header(w) != 0 or getw(w, 64) != 3544407954084549704:
        return 7
    if getw(w, 0) != 0 or getw(w, 48) != 0 or getw(w, 56) != 0:
        return 7
    if getw(w, 88) != 0 or getw(w, 96) != 0 or getw(w, 104) != 0 or (getw(w, 112) != 0):
        return 7
    if getw(w,3968) != 0 or getw(w,3976) != 0 or getw(w,3984) != 0:
        return 7
    next = getw(w, 8)
    if next == 0 or next > 65536 or getw(w, 40) >= next:
        return 7
    if getw(w, 32) == 0 and getw(w, 40) != 0:
        return 7
    i = 0
    while i < 256:
        base = getw(w, 4096 + i * 8)
        hid = getw(w, 6144 + i * 8)
        if base != 0:
            hp = so_slot_lookup(w, 6, hid)
            if hp == 0 or so_uget(w, hp + 24) != 1:
                return 7
            sp = so_storage_live(w, so_uget(w, hp + 16))
            if sp == 0 or so_uget(w, sp + 24) != 114688:
                return 7
            if base != 9223372036854775808 + so_uget(w, sp + 16):
                return 7
        elif hid != 0:
            return 7
        i = i + 1
    return 0

def so_state_init(w: mutbuf, slots: u64, pool: u64) -> u64:
    so_uput(w, 0, 3550034227914298440)
    so_uput(w, 8, 2)
    so_uput(w, 16, slots)
    so_uput(w, 24, pool)
    so_uput(w, 32, 1)
    so_uput(w, 48, 1)
    free = 128 + slots * 512
    so_uput(w, free, 0)
    so_uput(w, free + 8, pool)
    return 0

def so_state_header(w: mutbuf) -> u64:
    if length(w) < 144:
        return 9
    if so_uget(w, 0) != 3550034227914298440 or so_uget(w, 8) != 2 or so_uget(w, 48) != 1:
        return 9
    slots = so_uget(w, 16)
    pool = so_uget(w, 24)
    size = so_state_size(slots, pool)
    if size == 0 or size + 139264 != length(w) or so_uget(w, 32) > slots + 1:
        return 9
    i = 56
    while i < 128:
        if so_uget(w, i) != 0:
            return 9
        i = i + 8
    return 0

def entry(s: readbuf, o: mutbuf, w: mutbuf, scratch: mutbuf) -> u32:
    if length(o) < 32:
        return 0
    reply_error(o, 0)
    error = frame_valid(s)
    if error != 0:
        reply_error(o, error)
        return 32
    putw(w, 0, 0)
    putw(w, 48, 0)
    putw(w, 56, 0)
    count = getr(s, 8)
    if count != 0:
        putw(w, 96, 8192)
    end = 32 + count * 64
    i = 0
    at = 32
    halted = 0
    while i < count and halted == 0:
        if at > length(o) - 32:
            putw(o, 24, 3)
            return at
        putw(w, 104, i)
        code = getr(s, 32 + i * 64)
        if code >= 91 and code <= 94:
            next = gradient_object_command(s,o,w,32+i*64,at)
        elif code >= 71 and code <= 79 or code == 90:
            next = owned_optimizer_command(s, o, w, 32 + i * 64, at, end)
        elif code >= 60 and code <= 69:
            next = rng_command(s, o, w, scratch, 32 + i * 64, at, end)
        else:
            next = command(s, o, w, 32 + i * 64, at, end)
        if getw(w,0) == 0 and getw(w,3968) != 0:
            graph_collect_since(w,getw(w,8))
        error = getw(w, 0)
        if error != 0:
            putw(o, 24, error)
            return next
        putw(w, getw(w, 96) + i * 8, getw(o, at + 16))
        if getr(s, 32 + i * 64) == 58 and getw(o, at + 16) != 0:
            halted = 1
        at = next
        i = i + 1
        putw(o, 16, i)
    if count != 0:
        fill_range(w, 8192, count * 8, 0)
        putw(w, 96, 0)
        putw(w, 104, 0)
    putw(w, 80, 0)
    if getw(w, 0) != 0:
        reply_error(o, getw(w, 0))
        return 32
    return at

def record(w: mutbuf, t: u64, op: u64, a: u64, b: u64) -> u64:
    result = record_body(w, t, op, a, b)
    if result == 0:
        return 0
    p = dptr(w, t)
    if op == 10 or op == 16:
        putw(w,p+408,1)
    if getw(w, p + 32) == 0:
        putw(w, p + 40, 0)
        putw(w, p + 48, 0)
        putw(w, p + 56, 0)
        return result
    count = gradient_parent_count(w, t)
    i = 0
    while i < count:
        parent = graph_parent_at(w, t, i)
        flag = 0
        if parent != 0:
            q = dptr(w, parent)
            flag = getw(w, q + 32)
            if flag != 0 and getw(w, q + 40) == 0:
                if getw(w, q + 88) >= 4294967295:
                    return terror(w, 8)
                putw(w, q + 88, getw(w, q + 88) + 1)
        if op == 37 or op == 38:
            putw(w, getw(w, p + 184) + 16 + i * 16, flag)
        else:
            putw(w, p + 72 + i * 8, flag)
        i = i + 1
    return result

def partial_apply_node(w: mutbuf, t: u64) -> u64:
    p = dptr(w, t)
    op = getw(w, p + 40)
    if op == 0:
        return gradient_accumulate(w,t)
    if op >= 1 and op <= 4:
        back_binary(w, t)
    if op == 5 or op == 6 or op == 10 or (op >= 11 and op <= 17):
        back_unary(w, t)
    if op == 7 or op == 8:
        back_reduce(w, t)
    if op == 18 or op == 19:
        back_axis(w, t)
    if op == 20 or op == 21:
        back_softmax(w, t)
    if op >= 22 and op <= 24:
        back_spatial(w, t)
    if op == 25:
        back_matmul(w, t)
    if op == 26:
        back_index_select(w, t)
    if op == 27:
        back_gather(w, t)
    if op == 37 or op == 38:
        back_concat(w, t)
    if op == 39 or op == 40:
        back_indexed_add(w, t)
    return choose(getw(w, 0) == 0, 1, 0)

def graph_node_release(w: mutbuf, t: u64) -> u64:
    p = dptr(w, t)
    if getw(w, p + 312) != 0 or getw(w, p + 88) != 0 or getw(w,p+400) != 0:
        return terror(w, 9)
    if getw(w, p + 40) != 0:
        j = 0
        while j < gradient_parent_count(w, t):
            if graph_release_edge(w, graph_parent_at(w, t, j), graph_edge_enabled(w, t, j)) == 0:
                return 0
            j = j + 1
    saved_release(w, getw(w, p + 280))
    saved_release(w, getw(w, p + 288))
    saved_release(w, getw(w, p + 296))
    tensor_row_release(w, t)
    hold_release(w, getw(w, p + 248))
    hold_release(w, getw(w, p + 256))
    hold_release(w, getw(w, p + 264))
    hold_release(w, getw(w, p + 272))
    putw(w, p + 304, 0)
    return choose(getw(w, 0) == 0, 1, 0)

def graph_reset(w: mutbuf, keep: u64) -> u64:
    if getw(w, 0) != 0:
        return 0
    old_next = getw(w, 8)
    if keep >= old_next or keep > 65535:
        return terror(w, 7)
    if getw(w, 32) != 0 and keep != getw(w, 40):
        return terror(w, 7)
    if getw(w, 32) == 18446744073709551615:
        return terror(w, 8)
    i = 1
    while i <= keep:
        p = dptr(w, i)
        if getw(w, p + 304) == 0 or getw(w, p + 200) != 1:
            return terror(w, 6)
        if getw(w, p + 40) != 0 or getw(w, p + 64) != i:
            return terror(w, 6)
        i = i + 1
    i = keep + 1
    while i < old_next:
        putw(w, dptr(w, i) + 200, 0)
        i = i + 1
    graph_collect(w)
    if getw(w, 0) != 0:
        return 0
    highest = keep
    i = keep + 1
    while i < old_next:
        p = dptr(w, i)
        if getw(w, p + 304) != 0:
            highest = i
        else:
            memory_fill(w, p, 448, 0)
        i = i + 1
    page = (highest >> 8) + 1
    while page < 256:
        hold_release(w, getw(w, 6144 + page * 8))
        putw(w, 4096 + page * 8, 0)
        putw(w, 6144 + page * 8, 0)
        page = page + 1
    putw(w, 8, highest + 1)
    putw(w, 40, keep)
    putw(w, 32, getw(w, 32) + 1)
    return 1

def graph_audit(w: mutbuf) -> u64:
    status = 0
    budget = 0
    i = 1
    while i < getw(w, 8) and status == 0:
        p = dptr(w, i)
        if getw(w, p + 304) != 0:
            count = gradient_parent_count(w, i)
            if count > 16777216 - budget:
                status = 3
            else:
                budget = budget + count
                j = 0
                while j < count and status == 0:
                    parent = graph_parent_at(w, i, j)
                    flag = graph_edge_enabled(w, i, j)
                    if flag > 1 or parent >= i:
                        status = 9
                    elif parent != 0:
                        q = dptr(w, parent)
                        if getw(w, q + 304) == 0:
                            status = 9
                        else:
                            putw(w, q + 376, getw(w, q + 376) + 1)
                            if flag != 0 and getw(w, q + 40) == 0:
                                putw(w, q + 368, getw(w, q + 368) + 1)
                    elif flag != 0:
                        status = 9
                    j = j + 1
        i = i + 1
    i = 1
    while i < getw(w, 8):
        p = dptr(w, i)
        if status == 0 and getw(w, p + 304) != 0:
            if getw(w, p + 88) != getw(w, p + 368) or getw(w, p + 208) != getw(w, p + 376) + getw(w, p + 312) + getw(w,p+400):
                status = 9
        putw(w, p + 368, 0)
        putw(w, p + 376, 0)
        i = i + 1
    return status

def optimizer_audit(w: mutbuf) -> u64:
    if gradient_audit(w) != 0:
        return 9
    slots = so_uget(w, 16)
    budget = 0
    j = 1
    while j <= slots:
        row = so_slot_at(w, 8, j)
        if so_uget(w, row + 8) == 1:
            count = so_uget(w, row + 32)
            if count > 4096:
                return 9
            if count * count > 16777216 - budget:
                return 3
            budget = budget + count * count
        j = j + 1
    i = 1
    while i < getw(w, 8):
        p = dptr(w, i)
        if getw(w, p + 336) != 0 or getw(w, p + 368) != 0 or getw(w, p + 376) != 0:
            return 9
        if getw(w, p + 304) != 0:
            if getw(w, p + 320) == 0 or getw(w, p + 320) > getw(w, 120):
                return 9
        i = i + 1
    status = graph_audit(w)
    j = 1
    while j <= slots and status == 0:
        row = so_slot_at(w, 8, j)
        if so_uget(w, row + 8) == 1:
            status = optimizer_audit_record(w, row)
            other_index = 1
            while other_index < j and status == 0:
                other = so_slot_at(w, 8, other_index)
                if so_uget(w, other + 8) == 1 and so_uget(w, other + 16) == so_uget(w, row + 16):
                    status = 9
                other_index = other_index + 1
            other_index = 1
            while other_index <= slots and status == 0:
                other = so_slot_at(w, 7, other_index)
                if so_uget(w, other + 8) == 1 and so_uget(w, other + 16) == so_uget(w, row + 16):
                    status = 9
                other_index = other_index + 1
        j = j + 1
    i = 1
    while i < getw(w, 8):
        p = dptr(w, i)
        if getw(w, p + 304) != 0:
            if getw(w, p + 336) != getw(w, p + 312) or getw(w, p + 208) < getw(w, p + 312):
                status = 9
        elif getw(w, p + 312) != 0 or getw(w, p + 336) != 0:
            status = 9
        putw(w, p + 336, 0)
        i = i + 1
    return status

def optimizer_sgd_element(w: mutbuf, gp: u64, parameter: u64, buffer: u64, created: u64, index: u64) -> u64:
    p = dptr(w, parameter)
    grad = tgrad(w,parameter,index)
    if getw(w, gp + 40) != 0:
        grad = negf(grad)
    address = taddr(w, parameter, index)
    parameter_value = get4(w, address)
    decay = getw(w, gp + 24)
    if absf(decay) != 0:
        grad = addf(grad, mulf(decay, parameter_value))
    if buffer != 0:
        value = grad
        state_address = taddr(w, buffer, index)
        if created == 0:
            value = addf(mulf(get4(w, state_address), getw(w, gp + 8)), mulf(subf(1065353216, getw(w, gp + 16)), grad))
        put4(w, state_address, value)
        if getw(w, gp + 32) != 0:
            grad = addf(grad, mulf(getw(w, gp + 8), value))
        else:
            grad = value
    put4(w, address, addf(parameter_value, mulf(negf(getw(w, gp)), grad)))
    return 1

def optimizer_sgd_occurrence(w: mutbuf, gp: u64, item: u64) -> u64:
    parameter = getw(w, item)
    if parameter == 0:
        return 1
    p = dptr(w, parameter)
    n = getw(w, p + 8)
    if getw(w, p + 360) == 0 or gradient_binding(w,parameter) == 0:
        return terror(w, 9)
    if version_can_bump(w, parameter, 1) == 0:
        return 0
    momentum = getw(w, gp + 8)
    buffer = getw(w, item + 8)
    created = 0
    if absf(momentum) != 0:
        if buffer == 0:
            buffer = optimizer_new_momentum(w, parameter)
            if buffer == 0:
                return 0
            putw(w, item + 8, buffer)
            putw(w, item + 24, 1)
            created = 1
        elif version_can_bump(w, buffer, 2) == 0:
            return 0
    i = 0
    while i < n:
        optimizer_sgd_element(w, gp, parameter, buffer, created, i)
        i = i + 1
    if absf(momentum) != 0 and created == 0:
        bump_version(w, buffer)
        bump_version(w, buffer)
    return bump_version(w, parameter)

def optimizer_new_momentum(w: mutbuf, parameter: u64) -> u64:
    p = dptr(w, parameter)
    t = descriptor(w, getw(w, p), p + 96, 0, 1)
    if t == 0:
        return 0
    q = dptr(w, t)
    g = gradient_binding(w,parameter)
    if g == 0:
        return 0
    gp = dptr(w,g)
    if is_dense(w, g) != 0:
        j = 0
        while j < getw(w, p):
            putw(w, q + 128 + j * 8, getw(w, gp + 128 + j * 8))
            j = j + 1
    if private_tensor_retain(w, t, getw(w, q + 320)) == 0:
        return 0
    putw(w, q + 200, 0)
    return t
def gradient_binding(w:mutbuf, t:u64) -> u64:
    p = dptr(w,t)
    g = getw(w,p+384)
    if g == 0:
        if getw(w,p+392) != 0 or getw(w,p+360) != 0:
            return terror(w,9)
        return 0
    q = private_tensor(w,g,getw(w,p+392))
    if q == 0 or getw(w,q+400) == 0:
        return terror(w,9)
    return g

def gradient_reference_retain(w:mutbuf, g:u64, incarnation:u64) -> u64:
    q = private_tensor(w,g,incarnation)
    if q == 0:
        return terror(w,9)
    if getw(w,q+400) >= 4294967295:
        return terror(w,8)
    if node_retain(w,g) == 0:
        return 0
    putw(w,q+400,getw(w,q+400)+1)
    return 1

def gradient_reference_release(w:mutbuf, g:u64, incarnation:u64) -> u64:
    q = private_tensor(w,g,incarnation)
    if q == 0 or getw(w,q+400) == 0:
        return terror(w,9)
    putw(w,q+400,getw(w,q+400)-1)
    return node_release(w,g)

def gradient_unbind(w:mutbuf, t:u64) -> u64:
    p = dptr(w,t)
    g = gradient_binding(w,t)
    if getw(w,0) != 0:
        return 0
    if g != 0:
        incarnation = getw(w,p+392)
        putw(w,p+384,0)
        putw(w,p+392,0)
        putw(w,p+360,0)
        if gradient_reference_release(w,g,incarnation) == 0:
            return 0
    return 1

def gradient_shape_matches(w:mutbuf, t:u64, g:u64) -> u64:
    p = dptr(w,t)
    q = dptr(w,g)
    rank = getw(w,p)
    if getw(w,q) != rank:
        return 0
    j = 0
    while j < rank:
        if getw(w,p+96+j*8) != getw(w,q+96+j*8):
            return 0
        j = j+1
    return 1

def gradient_cycle_push(w:mutbuf, t:u64, forbidden:u64) -> u64:
    if t == 0:
        return 1
    if t == forbidden:
        return terror(w,7)
    if valid(w,t) == 0:
        return 0
    p = dptr(w,t)
    if getw(w,p+416) == 0:
        putw(w,p+416,1)
        putw(w,p+440,getw(w,3984))
        putw(w,3984,t)
    return 1

def gradient_cycle_check(w:mutbuf, t:u64, g:u64) -> u64:
    if getw(w,3984) != 0:
        return terror(w,9)
    gradient_cycle_push(w,g,t)
    budget = 0
    while getw(w,3984) != 0 and getw(w,0) == 0:
        current = getw(w,3984)
        p = dptr(w,current)
        putw(w,3984,getw(w,p+440))
        putw(w,p+440,0)
        gradient_cycle_push(w,getw(w,p+384),t)
        count = gradient_parent_count(w,current)
        if count > 16777216-budget:
            terror(w,3)
        else:
            budget = budget+count
            j = 0
            while j < count and getw(w,0) == 0:
                gradient_cycle_push(w,graph_parent_at(w,current,j),t)
                j = j+1
    i = 1
    while i < getw(w,8):
        p = dptr(w,i)
        putw(w,p+416,0)
        putw(w,p+440,0)
        i = i+1
    putw(w,3984,0)
    return choose(getw(w,0) == 0,1,0)

def gradient_assign(w:mutbuf, t:u64, g:u64) -> u64:
    if valid(w,t) == 0:
        return 0
    p = dptr(w,t)
    if g == 0:
        return gradient_unbind(w,t)
    if valid(w,g) == 0:
        return 0
    if t == g or gradient_shape_matches(w,t,g) == 0:
        return terror(w,2)
    if gradient_binding(w,t) == g:
        return 1
    if gradient_cycle_check(w,t,g) == 0:
        return 0
    incarnation = getw(w,dptr(w,g)+320)
    if gradient_reference_retain(w,g,incarnation) == 0:
        return 0
    if gradient_unbind(w,t) == 0:
        return 0
    putw(w,p+384,g)
    putw(w,p+392,incarnation)
    putw(w,p+360,1)
    return 1

def gradient_get_public(w:mutbuf, id:u64) -> u64:
    t = public_node(w,id)
    if t == 0:
        return 0
    if getw(w,dptr(w,t)+360) == 0:
        return 0
    g = gradient_binding(w,t)
    if g == 0:
        return 0
    return publish_tensor(w,g)

def gradient_present(w:mutbuf, id:u64) -> u64:
    t = public_node(w,id)
    if t == 0:
        return 0
    return getw(w,dptr(w,t)+360)

def tgrad(w:mutbuf, t:u64, index:u64) -> u64:
    if valid(w,t) == 0:
        return 0
    p = dptr(w,t)
    if getw(w,p+40) != 0:
        return terror(w,5)
    if index >= getw(w,p+8):
        return terror(w,7)
    if getw(w,p+360) == 0:
        return 0
    g = gradient_binding(w,t)
    if g == 0:
        return 0
    return tget(w,g,index)

def gradient_new(w:mutbuf, t:u64) -> u64:
    p = dptr(w,t)
    if getw(w,p+384) != 0 or getw(w,p+360) != 0:
        return terror(w,9)
    g = descriptor(w,getw(w,p),p+96,0,1)
    if g == 0:
        return 0
    q = dptr(w,g)
    if is_dense(w,t) != 0:
        j = 0
        while j < getw(w,p):
            putw(w,q+128+j*8,getw(w,p+128+j*8))
            j = j+1
    incarnation = getw(w,q+320)
    if gradient_reference_retain(w,g,incarnation) == 0:
        return 0
    putw(w,p+384,g)
    putw(w,p+392,incarnation)
    putw(w,q+200,0)
    return g

def ensure_backward_work(w:mutbuf, limit:u64, epoch:u64) -> u64:
    i = 1
    while i <= limit:
        p = dptr(w,i)
        if getw(w,p+304) != 0 and getw(w,p+168) == epoch:
            if getw(w,p+40) == 0 and getw(w,p+32) != 0 and getw(w,p+384) == 0:
                if gradient_new(w,i) == 0:
                    return 0
            if getw(w,p+256) == 0:
                address = alloc(w,getw(w,p+8)*4)
                if address == 0:
                    return 0
                putw(w,p+160,address)
                putw(w,p+256,getw(w,80))
        i = i+1
    return 1

def gradient_accumulate(w:mutbuf, t:u64) -> u64:
    p = dptr(w,t)
    if getw(w,p+32) == 0:
        return 1
    g = gradient_binding(w,t)
    if g == 0:
        return terror(w,9)
    present = getw(w,p+360)
    bumps = 1
    if present == 0 and is_dense(w,t) == 0:
        bumps = 0
    if version_can_bump(w,g,bumps) == 0:
        return 0
    src = getw(w,p+160)
    i = 0
    while i < getw(w,p+8):
        address = taddr(w,g,i)
        value = get4(w,src+i*4)
        if present != 0:
            value = addf(get4(w,address),value)
        put4(w,address,value)
        i = i+1
    if bumps != 0:
        bump_version(w,g)
    putw(w,p+360,1)
    return 1

def release_backward_scratch(w:mutbuf, limit:u64, epoch:u64) -> u64:
    i = 1
    while i <= limit:
        p = dptr(w,i)
        if getw(w,p+304) != 0 and getw(w,p+168) == epoch:
            if hold_release(w,getw(w,p+256)) == 0:
                return 0
            putw(w,p+256,0)
            putw(w,p+160,0)
            if getw(w,p+360) == 0:
                if gradient_unbind(w,i) == 0:
                    return 0
        i = i+1
    return 1

def gradient_detach_inplace(w:mutbuf, g:u64) -> u64:
    p = dptr(w,g)
    if getw(w,p+40) != 0:
        if getw(w,p+408) != 0 or getw(w,p+208) != getw(w,p+312)+getw(w,p+400):
            return terror(w,5)
        j = 0
        while j < gradient_parent_count(w,g):
            if graph_release_edge(w,graph_parent_at(w,g,j),graph_edge_enabled(w,g,j)) == 0:
                return 0
            j = j+1
        saved_release(w,getw(w,p+280))
        saved_release(w,getw(w,p+288))
        saved_release(w,getw(w,p+296))
        hold_release(w,getw(w,p+256))
        hold_release(w,getw(w,p+264))
        hold_release(w,getw(w,p+272))
        putw(w,p+40,0)
        putw(w,p+48,0)
        putw(w,p+56,0)
        putw(w,p+72,0)
        putw(w,p+80,0)
        putw(w,p+160,0)
        putw(w,p+184,0)
        putw(w,p+256,0)
        putw(w,p+264,0)
        putw(w,p+272,0)
        putw(w,p+280,0)
        putw(w,p+288,0)
        putw(w,p+296,0)
        putw(w,p+328,0)
        putw(w,p+344,0)
        putw(w,p+352,0)
    putw(w,p+32,0)
    return choose(getw(w,0) == 0,1,0)

def zero_grad_none(w:mutbuf, t:u64) -> u64:
    if valid(w,t) == 0:
        return 0
    if getw(w,dptr(w,t)+40) != 0:
        return terror(w,5)
    return gradient_unbind(w,t)

def zero_grad(w:mutbuf, t:u64) -> u64:
    if valid(w,t) == 0:
        return 0
    p = dptr(w,t)
    if getw(w,p+40) != 0:
        return terror(w,5)
    if getw(w,p+360) == 0:
        return 1
    g = gradient_binding(w,t)
    if g == 0 or version_can_bump(w,g,1) == 0:
        return 0
    if gradient_detach_inplace(w,g) == 0:
        return 0
    i = 0
    while i < getw(w,p+8):
        put4(w,taddr(w,g,i),0)
        i = i+1
    return bump_version(w,g)

def gradient_object_command(s:readbuf, o:mutbuf, w:mutbuf, cp:u64, at:u64) -> u64:
    code = getr(s,cp)
    a = getr(s,cp+8)
    b = getr(s,cp+16)
    first = getw(w,8)
    result = 0
    field = 3
    while field < 8:
        if getr(s,cp+field*8) != 0:
            terror(w,7)
        field = field+1
    if code != 92 and b != 0:
        terror(w,7)
    if getw(w,0) == 0:
        if code == 91:
            result = gradient_get_public(w,a)
        elif code == 92:
            t = public_node(w,a)
            g = public_optional(w,b)
            if t != 0 and getw(w,0) == 0:
                result = gradient_assign(w,t,g)
        else:
            terror(w,4)
    if getw(w,0) == 0:
        finish_command(w,first)
    status = getw(w,0)
    if status != 0:
        result = 0
    putw(o,at,code)
    putw(o,at+8,status)
    putw(o,at+16,result)
    putw(o,at+24,0)
    return at+32

def gradient_gc_enqueue(w:mutbuf, t:u64) -> u64:
    if t == 0:
        return 1
    p = dptr(w,t)
    if getw(w,p+304) == 0 or getw(w,p+200) != 0 or getw(w,p+432) != 0:
        return 1
    if getw(w,p+208) != 0:
        if getw(w,p+312) != 0 or getw(w,p+400) != 0 or getw(w,p+88) != 0 or getw(w,p+240) == 0:
            return 1
    putw(w,p+432,1)
    putw(w,p+424,0)
    tail = getw(w,3976)
    if tail == 0:
        putw(w,3968,t)
    else:
        putw(w,dptr(w,tail)+424,t)
    putw(w,3976,t)
    return 1

def node_release(w:mutbuf, t:u64) -> u64:
    if t == 0:
        return 1
    p = dptr(w,t)
    refs = getw(w,p+208)
    if refs == 0:
        return terror(w,9)
    putw(w,p+208,refs-1)
    return gradient_gc_enqueue(w,t)

def tensor_row_release(w:mutbuf, t:u64) -> u64:
    p = dptr(w,t)
    if getw(w,p+240) == 0:
        return 1
    if getw(w,p+400) != 0 or getw(w,p+312) != 0 or getw(w,p+88) != 0:
        return terror(w,9)
    if gradient_unbind(w,t) == 0:
        return 0
    tid = getw(w,p+192)
    tp = so_slot_lookup(w,1,tid)
    if tp == 0:
        return terror(w,9)
    if so_version_release(w,so_uget(w,tp+24)) != 0 or so_storage_release(w,so_uget(w,tp+16)) != 0:
        return terror(w,9)
    if so_slot_drop(w,1,tid) != 0:
        return terror(w,9)
    putw(w,p+240,0)
    return 1

def graph_collect_since(w:mutbuf, first:u64) -> u64:
    i = getw(w,8)-1
    while i >= first and i > 0:
        p = dptr(w,i)
        if getw(w,p+304) != 0 and getw(w,p+200) == 0:
            if getw(w,p+208) == 0:
                gradient_gc_enqueue(w,i)
            elif getw(w,p+312) == 0 and getw(w,p+88) == 0 and getw(w,p+400) == 0:
                tensor_row_release(w,i)
        i = i-1
    budget = 0
    while getw(w,3968) != 0 and getw(w,0) == 0:
        if budget >= 131070:
            return terror(w,9)
        budget = budget+1
        current = getw(w,3968)
        p = dptr(w,current)
        putw(w,3968,getw(w,p+424))
        if getw(w,3968) == 0:
            putw(w,3976,0)
        putw(w,p+424,0)
        putw(w,p+432,0)
        if getw(w,p+304) != 0 and getw(w,p+200) == 0 and getw(w,p+208) == 0:
            graph_node_release(w,current)
        elif getw(w,p+304) != 0 and getw(w,p+200) == 0 and getw(w,p+312) == 0 and getw(w,p+400) == 0 and getw(w,p+88) == 0:
            tensor_row_release(w,current)
    return choose(getw(w,0) == 0,1,0)

def gradient_audit(w:mutbuf) -> u64:
    status = 0
    if getw(w,3968) != 0 or getw(w,3976) != 0 or getw(w,3984) != 0:
        return 9
    i = 1
    while i < getw(w,8) and status == 0:
        p = dptr(w,i)
        if getw(w,p+416) != 0 or getw(w,p+424) != 0 or getw(w,p+432) != 0 or getw(w,p+440) != 0:
            status = 9
        i = i+1
    i = 1
    while i < getw(w,8) and status == 0:
        p = dptr(w,i)
        if getw(w,p+304) != 0:
            if getw(w,p+24) != 0 or getw(w,p+248) != 0 or getw(w,p+360) > 1:
                status = 9
            g = getw(w,p+384)
            if g == 0:
                if getw(w,p+392) != 0 or getw(w,p+360) != 0:
                    status = 9
            else:
                q = private_tensor(w,g,getw(w,p+392))
                if q == 0 or getw(w,p+360) != 1 or gradient_shape_matches(w,i,g) == 0:
                    status = 9
                else:
                    putw(w,q+416,getw(w,q+416)+1)
        i = i+1
    i = 1
    while i < getw(w,8):
        p = dptr(w,i)
        if getw(w,p+304) != 0:
            if getw(w,p+400) != getw(w,p+416):
                status = 9
        elif getw(w,p+400) != 0 or getw(w,p+416) != 0:
            status = 9
        putw(w,p+416,0)
        i = i+1
    return status
