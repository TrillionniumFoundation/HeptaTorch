    def node_info(fn, depth=4):
        if fn is None:
            return None
        result = {'kind': type(fn).__name__}
        if type(fn).__name__ == 'AccumulateGrad':
            variable = fn.variable
            result['variable'] = raw_tensor(variable)
            del variable
        if depth:
            result['next_edges'] = [{'output_nr': int(nr), 'node': node_info(child, depth - 1)}
                                    for child, nr in fn.next_functions]
        return result
