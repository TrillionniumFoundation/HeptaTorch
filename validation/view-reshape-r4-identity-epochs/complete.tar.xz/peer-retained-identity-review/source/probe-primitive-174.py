    def primitive(value):
        if isinstance(value, torch.Tensor):
            return {'tensor': raw_tensor(value)}
        if value is None or isinstance(value, (bool, int, str)):
            return value
        if isinstance(value, float):
            return {'double_bits': struct.unpack('<Q', struct.pack('<d', value))[0]}
        if isinstance(value, (tuple, list)):
            return [primitive(item) for item in value]
        return {'type': type(value).__name__, 'diagnostic_repr': repr(value)}
