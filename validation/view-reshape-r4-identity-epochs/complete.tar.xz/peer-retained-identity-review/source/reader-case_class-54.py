def case_class(support):
    class ShapeCase(support.Case):
        def node_info(self, index, depth=4):
            if not index:
                return None
            memory = self.mem()
            node = memory.node(index)
            if node[5] == 0:
                target = node[76] & 65535
                if not target:
                    target = index
                result = {'kind': 'AccumulateGrad', 'variable': memory.tensor(target)}
                if depth:
                    result['next_edges'] = []
                return result
            kinds = {**support.KINDS, 10: 'TBackward0', 16: 'ViewBackward0',
                     17: 'CloneBackward0', 45: 'ReshapeAliasBackward0', 46: 'UnsafeViewBackward0'}
            assert node[5] in kinds, ('unmapped_actual_native_node', index, node[5])
            result = {'kind': kinds[node[5]]}
            if depth:
                count = 2 if node[5] == 3 else 1
                result['next_edges'] = [
                    {'output_nr': 0, 'node': self.node_info(node[6+i], depth-1) if node[9+i] else None}
                    for i in range(count)]
            return result

        def saved_attributes(self, token, expected):
            node = self.mem().node(self.mem().public_node(token))
            if node[5] not in (16, 45, 46):
                return super().saved_attributes(token, expected)
            # Fixed generated view/reshape derivatives save input sym_sizes only.
            # Read the real captured parent descriptor, never the reference plan.
            self.check('Saved_attribute_names', ['_saved_self_sym_sizes'], list(expected))
            observed = {}
            if '_saved_self_sym_sizes' in expected:
                event = expected['_saved_self_sym_sizes']
                parent = self.mem().node(node[6])
                value = list(parent[12:12+parent[0]])
                self.check('_saved_self_sym_sizes/accepted', event['accepted'], True)
                self.check('_saved_self_sym_sizes/warnings', event['warnings'], [])
                self.check('_saved_self_sym_sizes/value', value, event['value'])
                observed['_saved_self_sym_sizes'] = support.event_normal(True, True, value)
            return observed

        def execute(self, event, event_index):
            label = event['label']
            self.snapshot(event['before'], 'event%02d/%s/before' % (event_index, label))
            self.current_path = 'event%02d/%s/operation' % (event_index, label)
            commands, token, publish, status, record = [], None, None, 0, None
            wanted = expected_status(event, support)
            self.check('operation_warning_surface', event['warnings'], [])
            family = self.row['family']
            if label == 'construct_backing':
                count = self.row['backing_elements']
                dtype = self.row['dtype']
                shape = [2, 3] if family in UNSUPPORTED_FAMILIES else [count]
                if dtype == 'float32':
                    data = struct.pack('<' + 'f' * count, *range(1, count+1))
                    code = 0
                elif dtype == 'bool':
                    data = bytes(i % 2 for i in range(count))
                    code = 1
                elif dtype == 'int64':
                    pattern = [0, 1, -1, 16777217, -16777219, (1 << 62) + 3, -(1 << 62) + 3, 9]
                    data = struct.pack('<' + 'q' * count, *(pattern[i % len(pattern)] for i in range(count)))
                    code = 2
                else:
                    raise AssertionError(('UNMAPPED_DTYPE', dtype))
                token = self.n.create(code, shape, data)
                publish = 'backing'
            elif label in ('construct_mul_input', 'construct_mul_middle'):
                assert family in UNSUPPORTED_FAMILIES
                self.check('wrapped_scalar_input_literal', event['accepted'], True, True)
                command = (114, self.live['backing'], 0x4000000000000000)
                status, record = self.issue(command, label)
                commands.append(command)
                token = record['value'] if status == 0 else None
                publish = 'input' if label == 'construct_mul_input' else 'middle'
            elif label == 'construct_transpose_input':
                assert family == 'nonleaf_mul_transpose'
                command = (6, self.live['middle'], 0, 1)
                status, record = self.issue(command, label)
                commands.append(command)
                token = record['value'] if status == 0 else None
                publish = 'input'
            elif label.startswith('construct_') and label[len('construct_'):] in (
                    'detached_input', 'own_requires_view', 'derived_requires_view'):
                self.check('input_family', label[len('construct_'):], family, True)
                command = self.view(self.live['backing'], self.row['input_size'],
                                    self.row['input_stride'], self.row['input_storage_offset'])
                status, record = self.issue(command, label + '/true_view')
                commands.append(command)
                token = record['value'] if status == 0 else None
                if status == 0 and family == 'detached_input':
                    temporary = token
                    command = (19, temporary)
                    status, record = self.issue(command, label + '/detach')
                    commands.append(command)
                    token = record['value'] if status == 0 else None
                    command = (41, temporary)
                    cleanup_status, _ = self.issue(command, label + '/drop_temporary')
                    commands.append(command)
                    self.check('temporary_view_release', cleanup_status, 0, True)
                publish = 'input'
            elif label in ('backing_requires_grad_true', 'input_requires_grad_true'):
                name = 'backing' if label.startswith('backing_') else 'input'
                command = (90, self.live[name], 1)
                status, record = self.issue(command, label)
                commands.append(command)
                token = self.live[name] if status == 0 else None
            elif label in ('target_view', 'target_reshape'):
                operation = self.row['operation']
                assert label == 'target_' + operation
                dims = self.row['target_shape']
                cfg = struct.pack('<5Q', len(dims), *(v & ((1 << 64)-1) for v in dims),
                                  *([0] * (4-len(dims))))
                command = (112 if operation == 'view' else 113,
                           self.live['input'], self.n.w.Payload(cfg), 40)
                status, record = self.issue(command, label)
                token = record['value'] if status == 0 else None
                publish = 'result'
                commands.append(command)
            elif label.startswith('retain_grad_'):
                command = (93, self.live[label[len('retain_grad_'):]])
                status, record = self.issue(command, label)
                commands.append(command)
            elif label.startswith('construct_seed_phase_'):
                index = int(label[len('construct_seed_phase_'):])
                phase = self.row['seed_phases'][index]
                # Result shape is only used to construct the actual explicit input
                # seed; no target gradient/layout/Version is computed.
                shape = event['returned']['tensor']['shape']
                pattern = phase['repeating_input_words']
                words = [pattern[i % len(pattern)] for i in range(math.prod(shape))]
                self.check('declared_seed_words', words, event['returned']['tensor']['binary_words'], True)
                token = self.n.create(0, shape, struct.pack('<' + 'I' * len(words), *words))
                publish = 'seed'
            elif label.startswith('backward_phase_'):
                match = re.fullmatch(r'backward_phase_([0-9]+)_(.+)', label)
                assert match
                index = int(match[1])
                assert self.row['seed_phases'][index]['name'] == match[2]
                retained = index + 1 < len(self.row['seed_phases'])
                command = (58, self.live['result'], self.live['seed'], int(retained))
                status, record = self.issue(command, label, partial=True)
                commands.append(command)
            elif label == 'backward_retry_after_default':
                assert family in UNSUPPORTED_FAMILIES
                command = (58, self.live['result'], self.live['seed'], 0)
                status, record = self.issue(command, label, partial=True)
                commands.append(command)
            elif label.startswith('hold_phase_'):
                match = re.fullmatch(r'hold_phase_([0-9]+)_(.+)_gradient', label)
                assert match
                index, name = int(match[1]), match[2]
                assert index < len(self.row['seed_phases'])
                command = (91, self.live[name])
                status, record = self.issue(command, label)
                token = record['value'] if status == 0 else None
                publish = 'held_phase_' + str(index) + '_' + name + '_grad'
                commands.append(command)
            elif label.startswith('clear_before_phase_'):
                match = re.fullmatch(r'clear_before_phase_([0-9]+)_(.+)', label)
                assert match and 0 < int(match[1]) < len(self.row['seed_phases'])
                command = (92, self.live[match[2]], 0)
                status, record = self.issue(command, label)
                commands.append(command)
            elif label == 'mutate_result_fill_nograd':
                dtype = self.row['dtype']
                value = (self.n.w.bits(42.) if dtype == 'float32' else
                         1 if dtype == 'bool' else ((1 << 64)-9) if dtype == 'int64' else None)
                assert value is not None
                command = (100, self.live['result'], value, 1)
                status, record = self.issue(command, label)
                token = self.live['result'] if status == 0 else None
                commands.append(command)
            elif label.startswith('drop_seed_before_phase_') or label.startswith('final_drop_'):
                name = ('seed' if label.startswith('drop_seed_before_phase_')
                        else label[len('final_drop_'):])
                drop_token = self.live[name]
                if sum(t == drop_token for t in self.live.values()) == 1:
                    command = (41, drop_token)
                    status, record = self.issue(command, label)
                    commands.append(command)
                del self.live[name]
            else:
                raise AssertionError(('UNMAPPED_NEW_EVENT', label))
            self.check('normalized_operation_status', status, wanted)
            operation = {'label': label, 'normalized_actual_status': status,
                         'normalized_reference_status': wanted, 'reference_event': event_index,
                         'commands': commands, 'record': record}
            if wanted == 0 and status != 0:
                self.operations.append(operation)
                raise support.RequiredOperationFailed(('native rejected accepted operation', label, status))
            if wanted != 0 and status == 0:
                self.operations.append(operation)
                raise support.RequiredOperationFailed(('native accepted rejected operation', label, wanted))
            if status == 0:
                returned = event.get('returned')
                if isinstance(returned, dict) and 'tensor' in returned:
                    self.check('returned_Tensor_present', bool(token), True, True)
                    actual = self.raw_tensor(token)
                    self.tensor(returned['tensor'], actual, 'returned_Tensor')
                    self.check('returned_is_existing', {name: t == token for name, t in self.live.items()},
                               event['returned_is_existing'])
                    operation['returned_tensor'] = actual
                else:
                    self.check('returned_primitive', returned, None)
                if publish is not None:
                    self.check('publish_new_name', publish in self.live, False, True)
                    weak_name = publish + '_storage'
                    if weak_name in self.weak:
                        self.check('replaced_Weak_is_seed_phase', label.startswith('construct_seed_phase_'), True, True)
                        self.check('replaced_Weak_later_phase', int(label[len('construct_seed_phase_'):]) > 0, True, True)
                        old_weak = self.weak[weak_name]
                        command = (42, token)
                        weak_status, weak_record = self.issue(command, label + '/new_Weak')
                        commands.append(command)
                        self.check('replacement_Weak_create_status', weak_status, 0, True)
                        command = (44, old_weak)
                        weak_status, _ = self.issue(command, label + '/release_previous_Weak')
                        commands.append(command)
                        self.check('previous_Weak_release_status', weak_status, 0, True)
                        self.live[publish] = token
                        self.weak[weak_name] = weak_record['value']
                    else:
                        self.published(publish, token)
            self.operations.append(operation)
            self.snapshot(event['after'], 'event%02d/%s/after' % (event_index, label))
    return ShapeCase
