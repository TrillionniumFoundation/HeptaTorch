    def saved_attributes(fn):
        if fn is None:
            return {}
        attributes = {}
        for name in sorted(n for n in dir(fn) if n.startswith('_saved_')):
            value, event = capture(lambda name=name: getattr(fn, name))
            if event['accepted']:
                event['value'] = primitive(value)
            del value
            attributes[name] = event
        return attributes
