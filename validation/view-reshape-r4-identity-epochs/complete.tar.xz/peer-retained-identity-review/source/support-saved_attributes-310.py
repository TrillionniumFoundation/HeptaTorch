    def saved_attributes(self, token, expected):
        index = self.mem().public_node(token)
        node = self.mem().node(index)
        op = node[5]
        keys = ('_saved_size', '_saved_storage_offset', '_saved_stride') if op == 44 else (
               ('_saved_other', '_saved_self') if op == 3 else ())
        self.check('Saved_attribute_names', list(keys), list(expected))
        observed = {}
        for name in keys:
            if name not in expected:
                continue
            event = expected[name]
            if op == 44:
                value = (list(node[12:12+node[0]]) if name == '_saved_size'
                         else list(node[16:16+node[0]]) if name == '_saved_stride'
                         else node[29] // {0:4,1:1,2:8}[node[72]])
                self.check(name + '/accepted', event['accepted'], True)
                self.check(name + '/value', value, event['value'])
                self.check(name + '/warnings', event['warnings'], [])
                observed[name] = event_normal(True, True, value)
            else:
                self.check(name + '/warnings', event['warnings'], [])
                slot = 1 if name == '_saved_other' else 0
                before = self.mem()
                publics = {i: bool(before.node(i)[25]) for i in range(1, before.q(8))
                           if before.node(i)[38] and before.node(i)[30]}
                status, record = self.issue((107, token, slot), name)
                self.check(name + '/normalized_status', status, expected_status(event))
                if status == 0:
                    got = record['value']
                    actual = self.raw_tensor(got) if got else None
                    value = event['value']
                    expected_tensor = value.get('tensor') if isinstance(value, dict) else None
                    self.tensor(expected_tensor, actual, name + '/original_saved_tensor')
                    observed[name] = event_normal(True, True, {'tensor': actual} if got else None)
                    if got:
                        saved_node = self.mem().public_node(got)
                        self.close_temporary(got, publics.get(saved_node, False))
                else:
                    observed[name] = {'accepted': False, 'normalized_wire_status': status}
        return observed
