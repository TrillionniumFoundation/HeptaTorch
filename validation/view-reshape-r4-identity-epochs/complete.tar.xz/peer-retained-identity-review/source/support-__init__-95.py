    def __init__(self, args, observer, reference, row, directory):
        self.args, self.observer, self.reference, self.row = args, observer, reference, row
        self.directory = directory
        directory.mkdir(parents=True, exist_ok=False)
        self.n = observer.Native(args.binary, args.source, args.protocol, directory)
        self.live, self.weak, self.tmap, self.treverse = {}, {}, {}, {}
        self.smap, self.sreverse = {}, {}
        self.failures, self.operations, self.snapshots, self.owner_records = [], [], [], []
        self.checks = self.words = self.rng_bytes = self.rollback_bytes = 0
        self.owner_blobs = {}
        self.current_path = 'initialization'
        self.gen = self.n.one(60, 1729)['value']
        start = bytes.fromhex(reference['states'][row['state_before_setup']]['hex'])
        self.n.one(64, self.gen, self.n.w.Payload(start), len(start))
        self.check('initial_rng', self.n.one(63, self.gen)['payload'], start)
        self.rng_bytes += len(start)
