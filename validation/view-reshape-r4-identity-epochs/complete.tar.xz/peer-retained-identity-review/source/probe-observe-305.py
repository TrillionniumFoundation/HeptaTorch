    def observe(spec):
        torch.manual_seed(1729)
        live, weak, events = {}, {}, []
        row = {**spec, 'state_before_setup': rng(), 'events': events}

        def event(label, operation, publish=None):
            before = snapshot(live, weak)
            value, result = capture(operation)
            result.update(label=label, before=before)
            if result['accepted']:
                result['returned'] = primitive(value)
                if isinstance(value, torch.Tensor):
                    result['returned_is_existing'] = {name: value is item for name, item in live.items()}
                if publish is not None:
                    assert isinstance(value, torch.Tensor), (label, type(value).__name__)
                    live[publish] = value
                    # RHS creation precedes replacement/destruction of an older
                    # Weak with this key, exactly as Python assignment evaluates.
                    weak[publish + '_storage'] = StorageWeakRef(value.untyped_storage())
            del value
            result['after'] = snapshot(live, weak)
            events.append(result)
            return result['accepted']

        def drop(name):
            del live[name]
            gc.collect()

        def clear_grad(name):
            live[name].grad = None

        def finish():
            row['before_final_drops'] = snapshot(live, weak)
            for name in list(live):
                event('final_drop_' + name, lambda name=name: drop(name))
            assert not live
            gc.collect()
            row.update(status='OBSERVED', final_expired={name: ref.expired() for name, ref in weak.items()},
                       state_after=rng())
            return row

        if not event('construct_backing', lambda: make_backing(spec), publish='backing'):
            row['remaining_not_attempted'] = 'backing constructor raised'
            return finish()
        family = spec['family']
        if family in ('nonleaf_mul', 'nonleaf_mul_transpose'):
            if not event('backing_requires_grad_true', lambda: live['backing'].requires_grad_(True)):
                row['remaining_not_attempted'] = 'backing requires request raised'
                return finish()
            if family == 'nonleaf_mul':
                ready = event('construct_mul_input', lambda: live['backing'] * 2., publish='input')
            else:
                ready = event('construct_mul_middle', lambda: live['backing'] * 2., publish='middle')
                if ready:
                    ready = event('construct_transpose_input', lambda: live['middle'].t(), publish='input')
            if not ready:
                row['remaining_not_attempted'] = 'nonleaf input construction raised'
                return finish()
        else:
            def make_input():
                value = torch.as_strided(live['backing'], tuple(spec['input_size']),
                                         tuple(spec['input_stride']), spec['input_storage_offset'])
                if family == 'detached_input':
                    value = value.detach()
                return value
            if not event('construct_' + family, make_input, publish='input'):
                row['remaining_not_attempted'] = 'input geometry construction raised'
                return finish()
            if family == 'derived_requires_view':
                ready = event('backing_requires_grad_true', lambda: live['backing'].requires_grad_(True))
            elif spec['requires_grad']:
                ready = event('input_requires_grad_true', lambda: live['input'].requires_grad_(True))
            else:
                ready = True
            if not ready:
                row['remaining_not_attempted'] = 'requires request raised'
                return finish()

        def reshape_target():
            return getattr(live['input'], spec['operation'])(tuple(spec['target_shape']))
        accepted = event('target_' + spec['operation'], reshape_target, publish='result')
        if not accepted:
            row['remaining_not_attempted'] = 'target view/reshape raised; no result Tensor exists'
            return finish()

        gradient_names = [name for name in ('backing', 'middle', 'input', 'result')
                          if name in live and live[name].requires_grad]
        for name in gradient_names:
            if not live[name].is_leaf:
                event('retain_grad_' + name, lambda name=name: live[name].retain_grad())

        if live['result'].requires_grad:
            for phase_index, (phase_name, pattern) in enumerate(SEED_PHASES):
                if phase_index:
                    for name in gradient_names:
                        event('clear_before_phase_' + str(phase_index) + '_' + name,
                              lambda name=name: clear_grad(name))
                    event('drop_seed_before_phase_' + str(phase_index), lambda: drop('seed'))
                words = [pattern[i % len(pattern)] for i in range(live['result'].numel())]
                if not event('construct_seed_phase_' + str(phase_index),
                             lambda words=words: make_seed(live['result'].shape, words), publish='seed'):
                    row['remaining_not_attempted'] = 'explicit seed constructor raised'
                    return finish()
                retain = phase_index + 1 < len(SEED_PHASES)
                event('backward_phase_' + str(phase_index) + '_' + phase_name,
                      lambda retain=retain: live['result'].backward(live['seed'], retain_graph=retain))
                for name in gradient_names:
                    if live[name].grad is not None:
                        event('hold_phase_' + str(phase_index) + '_' + name + '_gradient',
                              lambda name=name: live[name].grad,
                              publish='held_phase_' + str(phase_index) + '_' + name + '_grad')
            if family in ('nonleaf_mul', 'nonleaf_mul_transpose'):
                event('backward_retry_after_default',
                      lambda: live['result'].backward(live['seed']))
        else:
            row['backward_not_attempted'] = 'actual result.requires_grad is false'

        def fill_output():
            value = True if spec['dtype'] == 'bool' else (-9 if spec['dtype'] == 'int64' else 42.)
            with torch.no_grad():
                return live['result'].fill_(value)
        event('mutate_result_fill_nograd', fill_output)
        return finish()
