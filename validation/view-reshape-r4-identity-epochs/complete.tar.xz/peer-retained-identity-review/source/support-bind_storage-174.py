    def bind_storage(self, expected, actual):
        if expected in self.smap:
            self.check('Storage_identity_stable', actual, self.smap[expected])
        else:
            self.check('Storage_identity_injective', self.sreverse.get(actual), None)
            self.smap[expected], self.sreverse[actual] = actual, expected
