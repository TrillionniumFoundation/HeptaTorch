    def bind_tensor(self, expected, actual):
        key = (expected['tensor_identity'], expected['storage_identity'])
        value = actual['native_incarnation']
        if key in self.tmap:
            self.check('Tensor_identity_stable', value, self.tmap[key])
        else:
            self.check('Tensor_identity_injective', self.treverse.get(value), None)
            self.tmap[key], self.treverse[value] = value, key
        self.bind_storage(expected['storage_identity'], actual['native_storage_id'])
