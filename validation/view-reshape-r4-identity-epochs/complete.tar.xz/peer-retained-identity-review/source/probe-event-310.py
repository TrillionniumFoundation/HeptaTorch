        def event(label, operation, publish=None):
            before = snapshot(live, weak)
            value, result = capture(operation)
            result.update(label=label, before=before)
            if result['accepted']:
                result['returned'] = primitive(value)
                if isinstance(value, torch.Tensor):
                    result['returned_is_existing'] = {name: value is item for name, item in live.items()}
                if publish is not None:
                    assert isinstance(value, torch.Tensor), (label, type(value).__name__)
                    live[publish] = value
                    # RHS creation precedes replacement/destruction of an older
                    # Weak with this key, exactly as Python assignment evaluates.
                    weak[publish + '_storage'] = StorageWeakRef(value.untyped_storage())
            del value
            result['after'] = snapshot(live, weak)
            events.append(result)
            return result['accepted']
