    def snapshot(live, weak):
        names = list(live)
        tensors = {name: tensor_observation(live[name], weak) for name in names}
        relations = {}
        for left_name, right_name in itertools.combinations(names, 2):
            left, right = live[left_name], live[right_name]
            relations[left_name + '|' + right_name] = {
                'same_Python_object': left is right, 'same_Tensor': left._cdata == right._cdata,
                'same_Storage': left.untyped_storage()._cdata == right.untyped_storage()._cdata,
                'same_current_Version_value': left._version == right._version}
        if len(names) > 1:
            del left, right
        current, getters, saved, edges = {}, {}, {}, {}
        for name in names:
            fn, event = capture(lambda name=name: live[name].grad_fn)
            getters[name] = event
            if event['accepted']:
                current[name] = fn
            del fn
        for name, fn in current.items():
            saved[name] = saved_attributes(fn)
            edge_rows = []
            if fn is not None:
                for child, nr in fn.next_functions:
                    edge_rows.append({'output_nr': int(nr), 'node': node_info(child),
                                      'matches_live_current_grad_fn': [other for other, candidate in current.items()
                                                                     if child is not None and child is candidate]})
                    del child
            edges[name] = edge_rows
        # No Function or Tensor wrapper is returned or added to a persistent cache.
        if current:
            del fn
        current.clear()
        return {'tensor_getter_order': names, 'tensors': tensors, 'relations': relations,
                'saved_getters_after_tensor_getters': saved, 'edge_getters': getters,
                'edges_after_all_tensor_getters': edges,
                'expired': {name: ref.expired() for name, ref in weak.items()}, 'state': rng()}
