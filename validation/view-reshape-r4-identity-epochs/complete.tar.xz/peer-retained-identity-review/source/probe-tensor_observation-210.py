    def tensor_observation(x, weak):
        before = raw_tensor(x)
        fn, getter = capture(lambda: x.grad_fn)
        if getter['accepted']:
            getter['node'] = node_info(fn)
        del fn
        leaf, leaf_event = capture(lambda: x.is_leaf)
        if leaf_event['accepted']:
            leaf_event['value'] = bool(leaf)
        del leaf
        retained, retained_event = capture(lambda: x.retains_grad)
        if retained_event['accepted']:
            retained_event['value'] = bool(retained)
        del retained
        grad, grad_event = capture(lambda: x.grad)
        if grad_event['accepted']:
            grad_event['tensor'] = raw_tensor(grad)
            if grad is not None:
                key = 'observed_grad_storage_' + str(grad.untyped_storage()._cdata)
                if key not in weak:
                    weak[key] = StorageWeakRef(grad.untyped_storage())
        del grad
        return {'before_grad_fn_getter': before, 'grad_fn_getter': getter,
                'requires_grad_after_grad_fn_getter': x.requires_grad,
                'is_leaf_after_grad_fn_getter': leaf_event, 'retains_grad': retained_event,
                'gradient': grad_event}
