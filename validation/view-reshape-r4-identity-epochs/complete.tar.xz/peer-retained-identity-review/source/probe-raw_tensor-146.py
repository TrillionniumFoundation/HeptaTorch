    def raw_tensor(x):
        if x is None:
            return None
        storage = x.untyped_storage()
        raw = bytes(storage)
        width = x.element_size()
        shape, strides, offset = list(x.shape), list(x.stride()), x.storage_offset()
        logical = bytearray()
        for linear in range(x.numel()):
            quotient, at = linear, offset
            for size, stride in zip(reversed(shape), reversed(strides)):
                at += (quotient % size) * stride
                quotient //= size
            word = raw[at * width:at * width + width]
            assert len(word) == width
            logical.extend(word)
        base = x._base
        result = {'tensor_identity': str(x._cdata), 'storage_identity': str(storage._cdata),
                  'dtype': str(x.dtype), 'element_size': width, 'shape': shape, 'strides': strides,
                  'numel': x.numel(), 'storage_bytes': len(raw),
                  'storage_offset_elements': offset, 'storage_offset_bytes': offset * width,
                  'storage_raw_hex': raw.hex(), 'logical_bytes_hex': bytes(logical).hex(),
                  'binary_words': [int.from_bytes(logical[i:i + width], 'little') for i in range(0, len(logical), width)],
                  'version': x._version, 'requires_grad': x.requires_grad, 'is_view': x._is_view(),
                  'base_tensor_identity': None if base is None else str(base._cdata)}
        del base, storage
        return result
