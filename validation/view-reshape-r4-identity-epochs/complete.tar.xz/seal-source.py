#!/usr/bin/env python3
"""Seal existing identity source/plan/prepare/peer evidence; no new reader/native/Torch."""
import ast,hashlib,json,lzma,os,stat,tarfile,traceback
from pathlib import Path,PurePosixPath
R=Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
OUT=R/'hia-shape26-identity-epoch-handoff-01'
ROOT=R/'root-r4-identity-epoch-source-01'
PLAN=R/'root-r4-identity-epoch-plan-01'
PREP=R/'root-r4-identity-epoch-reader-prepare-01/report.json'
VERIFY=R/'hia-shape26-identity-epoch-verify-packet-01.py'
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(p):
 assert p.is_file() and not p.is_symlink(),str(p)
 h=hashlib.sha256();count=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);count+=len(b)
 return {'bytes':count,'sha256':h.hexdigest(),'mode':stat.S_IMODE(p.stat().st_mode)}
def dump(p,x):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n')
 p.chmod(0o600)
def write(p,b,mode=0o600):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
 p.chmod(mode)
def canon(n):
 q=PurePosixPath(n);assert n and not q.is_absolute() and '..' not in q.parts and str(q)==n,n
 return n
def checkpin(p,h):assert meta(p)['sha256']==h,(str(p),meta(p),h)
OUT.mkdir(exist_ok=False)
payload={};before={}
def add(n,p,pin=None):
 canon(n);assert n not in payload,n
 if pin:checkpin(p,pin)
 payload[n]=p;before[str(p)]=meta(p)
def add_review(label,root,pin):
 mf=root/'manifest.json';checkpin(mf,pin);j=json.loads(mf.read_bytes())['files']
 actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
 assert actual==set(j)|{'manifest.json'},(root,actual-set(j))
 for n,w in j.items():
  p=root/n;assert meta(p)=={k:w[k] for k in ('bytes','sha256','mode')},str(p)
  add(label+'/'+n,p,w['sha256'])
 add(label+'/manifest.json',mf,pin)
checkpin(PREP,'e04e7a73204b9285c06fa4476f07b884cd1be13319ea7fa4aee32bbc080c56da')
prep=json.loads(PREP.read_bytes());assert prep['status']=='PREPARED_NOT_RUN' and prep['native_executed'] is False
assert prep['all_inputs_unchanged'];assert len(prep['inputs_sha256'])==38
core={
 'source/identity_epochs.py':(ROOT/'identity_epochs.py','225472f6c7b00e8a7feefa876b025548d55aeca8a4ec5ffbf909a3e5d4d6d20b'),
 'source/replay_shape26_epoch_r1.py':(ROOT/'replay_shape26_epoch_r1.py','b37c58e597e3c180736133ee4ac7826b76dd9b0ac41d7b902b3057eabc7297a6'),
 'source/reader-source-inverse.json':(ROOT/'reader-source-inverse.json','d5b2c9b48d4b328666b27bfd6383ff16d085b8d060b16b43f469bd9db63ce05d'),
 'source/replay_shape26_r3.py':(R/'replay_shape26_r3.py','af290dad8ed2c815a1fe17c98296a39a451ba2de7673c16b97608ad16fc645a2'),
 'root-original-execution/root-pure-execution-receipts.json':(ROOT/'root-pure-execution-receipts.json','2c1c5e64cc619d1c2bd93c47ebea8b303aea3e3979ed614f63dd7fe296ba46dd'),
 'root-original-execution/plan/identity-epoch-plan.json':(PLAN/'identity-epoch-plan.json','d60cbd621e927434994b869edf93115eec7b1a3ec6b685041a90b14c9958becb'),
 'root-original-execution/plan/derived-identity-labels.json':(PLAN/'derived-identity-labels.json','55bfbae88f659a178aee35e08e680389ff81b0a3adb7d3b8ee2280d5edec195b'),
 'root-original-execution/prepare/report.json':(PREP,'e04e7a73204b9285c06fa4476f07b884cd1be13319ea7fa4aee32bbc080c56da'),
 'peer-original-execution/api-receipts.json':(R/'hia-identity-epoch-peer-process-capture-01.json','5e2b20ee336b1e922f1e23bf11c6a172e22881f6a8e4fbb74259974088a96d05'),
}
for n,(p,h) in core.items():add(n,p,h)
add_review('peer-retained-identity-review',R/'hia-shape26-retained-identity-review-01',
 'f85f10032d63f0974ea825993177e7d5517d3613d29b0dc608a8d40f997243c5')
add_review('peer-epoch-adapter-review',R/'hia-shape26-epoch-adapter-source-review-01',
 '661070b9250a0eea1b795e2b0e6244304eafcb4dd0a7f5b14da34bf05a571ff0')
for name in ('hia-shape26-retained-identity-review-01.py','hia-shape26-retained-identity-review-request-20261117-v1.json',
 'hia-shape26-epoch-adapter-source-review-01.py','hia-shape26-epoch-source-peer-review-request-20261117-v1.json'):
 add('peer-original-execution/'+name,R/name)
add('official-primary/variable.cpp',R/'root-upstream-variable-ca2f.cpp','ca2f1e573307069dee2fdff70ba81f161f48817cd278ad5464b9809cf23ab2c6')
mapping={str(p):n for n,p in payload.items()}
native=R/'differentiable-view-r4-scalar06-native-build-01/candidate-r4-scalar06'
external=[]
for original,pin in prep['inputs_sha256'].items():
 p=Path(original);checkpin(p,pin);before[str(p)]=meta(p)
 member=mapping.get(str(p))
 if member is None:
  if p.is_relative_to(native):
   if p.name=='build.json':
    member='original-prepare-native/build.json';add(member,p,pin)
  elif p.name=='actual.json':
   assert pin=='fecf1956790f78a9b1238f535c1c7cce9f1237b211c389ac0736d88687bbb9c9'
  else:
   if p.name=='pytorch_view_reshape_probe.py':member='reference/'+p.name
   elif p.name in ('protocol.py','owner_client.py','native_observer_shape02.py','replay_direct_view14.py'):member='support/'+p.name
   else:raise AssertionError('Unclassified prepare input '+original)
   add(member,p,pin)
 external.append({'original_path':original,**meta(p),'packet_member':member,
  'disposition':'exact_original_copy' if member else 'external_original_byte_pin_not_duplicated'})
assert len(external)==38
old=(R/'replay_shape26_r3.py').read_bytes();new=(ROOT/'replay_shape26_epoch_r1.py').read_bytes()
inv=json.loads((ROOT/'reader-source-inverse.json').read_bytes());x=new
assert len(inv['edits'])==9
for edit in reversed(inv['edits']):
 a,b=edit['after'].encode(),edit['before'].encode();assert x.count(a)==1;x=x.replace(a,b)
assert x==old
for p in (ROOT/'identity_epochs.py',ROOT/'replay_shape26_epoch_r1.py',R/'replay_shape26_r3.py',VERIFY):ast.parse(p.read_bytes())
dump(OUT/'prepare-input-inventory.json',{'schema':'heptatorch.identity-epoch.original-prepare-inputs.v1',
 'original_prepare_report_sha256':meta(PREP)['sha256'],'input_count':38,'inputs':external,
 'all_checked_now':True,'not_new_prepare':True,'source06_only':True})
add('prepare-input-inventory.json',OUT/'prepare-input-inventory.json')
dump(OUT/'external-original-reference.json',{'schema':'heptatorch.identity-epoch.external-reference.v1',
 'original_reference':next(x for x in external if x['sha256']=='fecf1956790f78a9b1238f535c1c7cce9f1237b211c389ac0736d88687bbb9c9'),
 'derived_labels_member':'root-original-execution/plan/derived-identity-labels.json',
 'original_reference_bytes_unmodified':True,'original_reference_not_duplicated':True,
 'lifetime_scope':'Labels derive from the original record and pinned getter/retention source. No new Torch Weak or deallocation observation is claimed.'})
add('external-original-reference.json',OUT/'external-original-reference.json')
command=['python3','-I','-S','-B','source/replay_shape26_epoch_r1.py',
 '--binary','NATIVE/tensor-shape-scalar-session','--source','NATIVE/runtime.hepta','--build-report','NATIVE/build.json',
 '--protocol','support/protocol.py','--observer','support/native_observer_shape02.py',
 '--reference','ORIGINAL_REFERENCE26/actual.json','--probe','reference/pytorch_view_reshape_probe.py',
 '--support-reader','support/replay_direct_view14.py','--identity-adapter','source/identity_epochs.py',
 '--parent-reader','source/replay_shape26_r3.py','--expected-source-sha256',prep['source_sha256'],
 '--expected-native-sha256',prep['native_sha256'],'--expected-observer-sha256',prep['observer_sha256'],
 '--expected-reference-sha256',prep['reference_sha256'],'--expected-functions','656','--expected-native-units','13',
 '--prepare-only','--output','NEW_PREPARE_OUTPUT']
dump(OUT/'portable-command.json',{'argv':command,'executed_here':False,
 'path_placeholders':['NATIVE','ORIGINAL_REFERENCE26','NEW_PREPARE_OUTPUT'],
 'scope':'Reproduces original source06 prepare inputs. A successor image requires its own exact source/image/functions/units pins; this packet does not claim successor execution.'})
add('portable-command.json',OUT/'portable-command.json')
readme="""# Original26 identity epoch source and custody packet

This packet preserves existing source, original pure plan/prepare outputs and independent source reviews. Forming and verifying it executes no native program, compiler, emitter, Torch probe, identity admission, or reader.

The root source module binds the original fecf reference and 4dd probe. It derives two released-Saved-scalar lifetime boundaries and 208 identity-label annotations; 24 rows remain identical. Original raw address fields remain available through the exact inverse. These are source-qualified labels derived from original observations, not new Torch Weak-expiration measurements. All numerical words, layout, Version, live aliases, errors, RNG, observed Weak booleans and original comparator bodies remain unchanged.

The new reader b37c has nine explicit edits which reverse in whole bytes to af290. Its four non-main functions are exact originals. Base52c3 support, protocol7a30, owner clientdee3 and observer59019 are included as original bytes. Neither reader nor production is qualified by this packet.

Original root plan job3d4b and prepare job3d4f requests, launch/status/read responses and complete double-EOF streams are preserved in root-original-execution/root-pure-execution-receipts.json. The prepare report remains PREPARED_NOT_RUN and binds all38 inputs. Independent retained/source audit9368328 and epoch source audit5bd5 are preserved with their original manifests, scripts and process receipts. The original read transport failure is also retained.

The 18MB original actual26 and already built06 executable/runtime/unit products are not duplicated. prepare-input-inventory.json includes their complete original paths, sizes, SHA256 and modes, with explicit copy or external dispositions. The full derived-label document is included; it does not replace the original oracle for admission. Original source05 and06 native failures remain historical failures; this packet does not relabel them.

All archived copies preserve original byte content and POSIX mode, including0600/0660 source and metadata. This is not a Git-mode-normalized installation. Any later installation must record an explicit mode/path mapping.

Pure verification:
  python3 -I -S -B verify_packet.py --archive complete.tar.xz --manifest manifest.json --report NEW_VERIFICATION.json
Optional --restore NEW_DIRECTORY extracts only validated regular members, preserving their recorded modes. Optional --original-reference PATH verifies the original fecf reference. A source06 prepare command is provided in portable-command.json; it was not run by this sealer. All13 exact unit source/object files must exist next to NATIVE/build.json.

Full PyTorch status remains HOLD and qualified API count remains0.
"""
write(OUT/'README.md',readme.encode());add('README.md',OUT/'README.md')
add('verify_packet.py',VERIFY)
add('seal-source.py',Path(__file__))
files={n:{**meta(p),'original_path':str(p)} for n,p in sorted(payload.items())}
archive=OUT/'complete.tar.xz'
with tarfile.open(archive,'w:xz',format=tarfile.USTAR_FORMAT,preset=6) as tf:
 for n,p in sorted(payload.items()):
  x=tarfile.TarInfo(n);x.size=files[n]['bytes'];x.mode=files[n]['mode'];x.uid=x.gid=0;x.mtime=0
  with p.open('rb') as f:tf.addfile(x,f)
archive.chmod(0o600)
d=lzma.LZMADecompressor(format=lzma.FORMAT_XZ);ht=hashlib.sha256();nt=0
with archive.open('rb') as f:
 while not d.eof:
  raw=f.read(65536);assert raw;out=d.decompress(raw);ht.update(out);nt+=len(out)
 assert not d.unused_data and not f.read(1)
seen=set()
with tarfile.open(archive,'r:xz') as tf:
 for x in tf:
  assert x.isfile() and not x.islnk() and not x.issym() and x.name in files and x.name not in seen
  canon(x.name);seen.add(x.name);want=files[x.name];assert x.size==want['bytes'] and stat.S_IMODE(x.mode)==want['mode']
  h=hashlib.sha256();n=0
  with tf.extractfile(x) as f:
   for raw in iter(lambda:f.read(1048576),b''):h.update(raw);n+=len(raw)
  assert n==want['bytes'] and h.hexdigest()==want['sha256'],x.name
assert seen==set(files)
for p,m in before.items():assert meta(Path(p))==m,('input changed',p)
dump(OUT/'manifest.json',{'schema':'heptatorch.identity-epoch.source-evidence-archive.v1','files':files,
 'archive':meta(archive),'tar':{'bytes':nt,'sha256':ht.hexdigest()},
 'self_exclusions':['complete.tar.xz','manifest.json','summary.json','delivery-manifest.json'],
 'original_input_count':38,'all_original_inputs_unchanged':True})
summary={'status':'PASS_TRANSPORT_AND_CUSTODY_ONLY','native_executed':False,'Torch_executed':False,
 'compiler_executed':False,'emitter_executed':False,'reader_executed':False,'identity_admission_executed':False,
 'archive':meta(archive),'manifest':meta(OUT/'manifest.json'),'member_count':len(files),
 'member_bytes':sum(x['bytes'] for x in files.values()),'single_XZ_EOF':True,
 'whole_tar_sha256':ht.hexdigest(),'all_member_size_sha_mode_verified':True,
 'all_original_inputs_unchanged':True,'original_prepare_inputs':38,
 'reader_inverse_edits':9,'reader_whole_inverse_equals_af290':True,
 'original_reference_external':True,'original_native_build_external':True,
 'root_plan_original_status':'PASS_PURE_LIFETIME_QUALIFIED_LABELS',
 'root_prepare_original_status':'PREPARED_NOT_RUN',
 'root_pure_execution_receipt_sha256':'2c1c5e64cc619d1c2bd93c47ebea8b303aea3e3979ed614f63dd7fe296ba46dd',
 'independent_source_report_sha256':'5bd5e704b84f97bd0aa261d70814e677d41af15688e89fe5fec9ff390613b881',
 'independent_original_identity_report_sha256':'9368328f9c180bd6687bc842faa94318e825060b877fdfa1af753d011a67438a',
 'full_pytorch_status':'HOLD','qualified_pytorch_api_count':0}
dump(OUT/'summary.json',summary)
# A loose original-byte verifier for convenient use; the identical source is inside the archive.
write(OUT/'verify_packet.py',VERIFY.read_bytes(),stat.S_IMODE(VERIFY.stat().st_mode))
delivery={}
for p in sorted(OUT.iterdir()):
 if p.is_file():delivery[p.name]=meta(p)
dump(OUT/'delivery-manifest.json',{'schema':'heptatorch.identity-epoch.delivery.v1','files':delivery,
 'self_exclusion':'delivery-manifest.json','native_executed':False,'Torch_executed':False})
print(json.dumps({'summary':meta(OUT/'summary.json'),'archive':meta(archive),'manifest':meta(OUT/'manifest.json'),
 'delivery_manifest':meta(OUT/'delivery-manifest.json'),'members':len(files),'bytes':summary['member_bytes']}))
