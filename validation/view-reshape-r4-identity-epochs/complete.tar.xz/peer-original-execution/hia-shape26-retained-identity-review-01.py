#!/usr/bin/env python3
"""Source-bound read-only audit of original shape26 ephemeral Saved identities."""
import ast, hashlib, json
from pathlib import Path
R=Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
OUT=R/'hia-shape26-retained-identity-review-01'
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f: f.write(json.dumps(x,indent=2,sort_keys=True,allow_nan=False)+'\n')
def meta(p):
    b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b),'mode':p.stat().st_mode&511}
pins={
 'actual26':(R/'differentiable-view-r4-shape-reference26-01/actual.json','fecf1956790f78a9b1238f535c1c7cce9f1237b211c389ac0736d88687bbb9c9'),
 'probe':(R/'differentiable-view-r4-shape-reference26-01/pytorch_view_reshape_probe.py','4dd374419e4b21a9c814c855d846481730a12ea57a30dcf229a6b962f07021c5'),
 'reader':(R/'replay_shape26_r3.py','af290dad8ed2c815a1fe17c98296a39a451ba2de7673c16b97608ad16fc645a2'),
 'support':(R/'to-view-recovery-integration-01/repo/tests/differentiable_view_native_review/replay_direct_view14.py','52c3b3242a73fb412102c83c5ba47cf8d95a4eb3c01e56f41bfe593066506d05'),
 'variable':(R/'root-upstream-variable-ca2f.cpp','ca2f1e573307069dee2fdff70ba81f161f48817cd278ad5464b9809cf23ab2c6'),
 'native26':(R/'r4-scalar06-native26-first-01/observed/report.json','afe47e394b3334f22f503e606f806e6abc8b3eef32ad5c5884cb3051d0dec598'),
 'retained_apply':(R/'r4-scalar06-semantic-diagnostic-source-01/retained_apply.hepta','ed1ff2b69533cb4d90310c79e7210f20a4ba174df8b7e43c349b2f541a7a2b58'),
 'retained_reserve_one':(R/'r4-scalar06-semantic-diagnostic-source-01/retained_reserve_one.hepta','f43282c671a84f6fd6d466981cb0cc1a38f83c956760e99be8bf3df4dde6a486'),
 'retained_sum_layout':(R/'r4-scalar06-semantic-diagnostic-source-01/retained_sum_layout.hepta','395309be2d369d1a29d905be32208ef15976050fa8d069726eb9b02391222301')
}
raw={};before={}
for k,(p,pin) in pins.items():
    assert p.is_file() and not p.is_symlink()
    raw[k]=p.read_bytes();before[str(p)]=meta(p);assert sha(raw[k])==pin,(k,sha(raw[k]))
OUT.mkdir(exist_ok=False)
source_sections=[]
for kind,names in [('probe',('raw_tensor','primitive','node_info','saved_attributes','tensor_observation','snapshot','event','observe')),
                   ('support',('__init__','bind_storage','bind_tensor','saved_attributes')),
                   ('reader',('case_class',))]:
    text=raw[kind].decode();lines=text.splitlines(keepends=True);tree=ast.parse(text)
    for node in ast.walk(tree):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name in names:
            b=''.join(lines[node.lineno-1:node.end_lineno]).encode()
            rel='source/'+kind+'-'+node.name+'-'+str(node.lineno)+'.py'
            p=OUT/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
            source_sections.append({'file':rel,'origin':str(pins[kind][0]),'origin_sha256':pins[kind][1],
                                    'first_line':node.lineno,'last_line':node.end_lineno,**meta(p)})
v=raw['variable'];start=v.index(b'void VariableHooks::retain_grad(');end=v.index(b'bool VariableHooks::retains_grad(',start)
vp=OUT/'source/variable-retain-grad.cpp';vp.write_bytes(v[start:end])
source_sections.append({'file':str(vp.relative_to(OUT)),'origin':str(pins['variable'][0]),
                        'origin_sha256':pins['variable'][1],**meta(vp)})
assert b'var->mutable_grad() = var->grad() + grad;' in v[start:end]
assert b'c10::weak_intrusive_ptr<c10::TensorImpl>' in v[start:end]
for k in ('retained_apply','retained_reserve_one','retained_sum_layout'):
    (OUT/('source/'+k+'.hepta')).write_bytes(raw[k])
data=json.loads(raw['actual26'])
assert len(data['rows'])==26 and data['status']=='OBSERVED'
def raw_tensors(value,path=()):
    if isinstance(value,dict):
        if all(k in value for k in ('tensor_identity','storage_identity','dtype','shape')):
            yield path,value
        for k,x in value.items():yield from raw_tensors(x,path+(str(k),))
    elif isinstance(value,list):
        for i,x in enumerate(value):yield from raw_tensors(x,path+(str(i),))
def id_record(t):
    keys=('tensor_identity','storage_identity','dtype','shape','strides','storage_bytes',
          'element_size','storage_offset_bytes','logical_bytes_hex','storage_raw_hex','version',
          'requires_grad','is_view','base_tensor_identity')
    return {k:t[k] for k in keys if k in t}
def roots(snapshot):
    rows=[]
    for name,o in snapshot['tensors'].items():
        rows.append({'live_dictionary_name':name,'root_kind':'live Tensor',
                     'tensor':id_record(o['before_grad_fn_getter'])})
        g=o.get('gradient',{}).get('tensor')
        if g is not None:
            rows.append({'live_dictionary_name':name,'root_kind':'current .grad',
                         'tensor':id_record(g)})
    return rows
case_summaries=[]
for i,release_idx,later_idx,old_name in [(22,16,20,'input'),(25,20,20,'middle')]:
    row=data['rows'][i]
    old=row['events'][release_idx]['before']['saved_getters_after_tensor_getters'][old_name]['_saved_other']
    assert old['accepted'] is True
    old_t=old['value']['tensor']
    assert old_t['dtype']=='torch.float64' and old_t['shape']==[] and old_t['storage_bytes']==8
    selected=sorted(set((release_idx,later_idx)))
    events=[]
    for j in selected:
        event=row['events'][j]
        item={'event_index':j,'operation':{k:x for k,x in event.items() if k not in ('before','after')}}
        for phase in ('before','after'):
            snap=event[phase]
            item[phase]={
                'json_pointer':'/rows/%d/events/%d/%s'%(i,j,phase),
                'live_dictionary_order':snap['tensor_getter_order'],
                'live_roots_and_current_gradients':roots(snap),
                'all_live_relations':snap['relations'],
                'all_saved_getters':snap['saved_getters_after_tensor_getters'],
                'all_observed_weak_expiry':snap['expired'],
                'complete_original_tensor_observations':snap['tensors']
            }
        events.append(item)
    # All original occurrences of these raw addresses are copied, not inferred.
    occurrences=[]
    for path,t in raw_tensors(row):
        if t['storage_identity']==old_t['storage_identity'] or t['tensor_identity']==old_t['tensor_identity']:
            occurrences.append({'json_pointer':'/rows/%d/'%i+'/'.join(path),'tensor':id_record(t)})
    after=row['events'][release_idx]['after']
    failed_getter=after['saved_getters_after_tensor_getters'][old_name]['_saved_other']
    assert failed_getter['accepted'] is False
    old_live_before=[x for x in roots(row['events'][release_idx]['before'])
        if x['tensor']['storage_identity']==old_t['storage_identity'] or x['tensor']['tensor_identity']==old_t['tensor_identity']]
    assert old_live_before==[]
    newer=[x for x in occurrences if x['tensor']['storage_identity']==old_t['storage_identity']
           and x['tensor']['dtype']=='torch.float32' and x['tensor']['storage_bytes']==24]
    assert newer
    projection={'case_index':i,'family':row['family'],'original_Saved_other':old_t,
                'Saved_not_an_explicit_live_or_gradient_root_before_release':True,
                'release_event':release_idx,'later_event':later_idx,
                'post_release_Saved_getter':failed_getter,'events':events,
                'complete_original_address_occurrences':occurrences}
    fn='case-%02d-projection.json'%i;dump(OUT/fn,projection)
    case_summaries.append({'case_index':i,'family':row['family'],'file':fn,
        'old_tensor':old_t['tensor_identity'],'old_storage':old_t['storage_identity'],
        'old_dtype':old_t['dtype'],'old_storage_bytes':8,'release_event':release_idx,
        'release_label':row['events'][release_idx]['label'],
        'post_release_Saved_error':failed_getter,'first_new_24byte_F32_occurrence':newer[0],
        'old_Saved_absent_from_explicit_live_roots_before_release':True})
notes=[
 'The probe records raw TensorImpl/StorageImpl addresses as decimal strings. These are observations, not globally unique generation IDs.',
 'raw_tensor deletes temporary base/storage wrappers; saved_attributes converts the getter Tensor to primitive fields and deletes its local value.',
 'snapshot only holds grad_fn wrappers in a local dictionary then clears it. No Saved.other Tensor/Storage Weak is installed. Actual G StorageWeak and live held_phase_* Tensor roots remain tracked separately.',
 'For case22 event16 and case25 event20 the original Saved.other getter changes from accepted real F64 rank0/8B to RuntimeError during the declared default backward, and the original scalar has no explicit live/gradient root.',
 'The exact same opaque Storage address later names an F32 rank2/24B G; case25 also reuses the Tensor address. These are different object lifetimes. Permanent maps keyed by raw address therefore overconstrain this trace.',
 'The fixed upstream retained hook allocates a clone for absent G and an out-of-place oldG+incoming for present G. The HIA retained_reserve_one/retained_apply similarly create a replacement G. There is no public-reference-dependent in-place retained update branch.',
 'No numerical, Version, simultaneous live-alias, live-held-G identity, Weak expiry, EOF or rollback expectation is changed by this source audit. The original26 native report remains FAIL24/26.',
 'The needed successor reader must use explicit lifetime/source-justified epochs, preserve all still-live identities, and never infer a new epoch merely to accept a native mismatch. This review does not implement or qualify that reader.',
 'Separate retained NaN and case25 Version/layout differences remain production obligations. Root owns the successor identity reader; scope owns production.'
]
after={str(p):meta(p) for p,_ in pins.values()}
assert before==after
report={'schema':'heptatorch.shape26-retained-identity-source-review.v1',
        'status':'SOURCE_AND_ORIGINAL_BYTES_REVIEW_COMPLETE','native_executed':False,
        'Torch_executed':False,'compiler_executed':False,'emitter_executed':False,
        'inputs_before':before,'inputs_after':after,'all_inputs_unchanged':True,
        'source_sections':source_sections,'cases':case_summaries,'findings':notes,
        'original_native_report_sha256':pins['native26'][1],
        'original_native_report_status_unchanged':True,'whole_pytorch_gate':'HOLD'}
dump(OUT/'report.json',report)
manifest={'schema':'heptatorch.shape26-retained-identity-review-members.v1',
 'files':{str(p.relative_to(OUT)):meta(p) for p in sorted(OUT.rglob('*')) if p.is_file()}}
dump(OUT/'manifest.json',manifest)
print(json.dumps({'status':report['status'],'native_executed':False,'Torch_executed':False,
                  'report':meta(OUT/'report.json'),'manifest':meta(OUT/'manifest.json'),
                  'files':len(manifest['files'])},sort_keys=True))
