#!/usr/bin/env python3
"""Pure source review; does not import or run either reader/identity module."""
import ast,hashlib,json
from pathlib import Path
R=Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
P=R/'root-r4-identity-epoch-source-01';O=R/'hia-shape26-epoch-adapter-source-review-01'
sha=lambda b:hashlib.sha256(b).hexdigest()
def info(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b),'mode':p.stat().st_mode&511}
def dump(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
inputs={
 P/'identity_epochs.py':'225472f6c7b00e8a7feefa876b025548d55aeca8a4ec5ffbf909a3e5d4d6d20b',
 P/'replay_shape26_epoch_r1.py':'b37c58e597e3c180736133ee4ac7826b76dd9b0ac41d7b902b3057eabc7297a6',
 R/'replay_shape26_r3.py':'af290dad8ed2c815a1fe17c98296a39a451ba2de7673c16b97608ad16fc645a2',
 R/'to-view-recovery-integration-01/repo/tests/differentiable_view_native_review/replay_direct_view14.py':'52c3b3242a73fb412102c83c5ba47cf8d95a4eb3c01e56f41bfe593066506d05',
 R/'hia-shape26-retained-identity-review-01/report.json':'9368328f9c180bd6687bc842faa94318e825060b877fdfa1af753d011a67438a'}
raw={p:p.read_bytes() for p in inputs}
for p,pin in inputs.items():assert sha(raw[p])==pin
iv=P/'reader-source-inverse.json';raw[iv]=iv.read_bytes();proof=json.loads(raw[iv])
before={str(p):info(p) for p in raw};O.mkdir(exist_ok=False)
new=raw[P/'replay_shape26_epoch_r1.py'];parent=raw[R/'replay_shape26_r3.py'];inverse=new
for edit in reversed(proof['edits']):
 a,b=edit['after'].encode(),edit['before'].encode()
 assert inverse.count(a)==1,edit['label']
 inverse=inverse.replace(a,b)
assert inverse==parent and len(proof['edits'])==9
def defs(b):
 t=b.decode();lines=t.splitlines(keepends=True)
 return {n.name:''.join(lines[n.lineno-1:n.end_lineno]).encode()
         for n in ast.parse(t).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=defs(new),defs(parent)
unchanged=[k for k in b if a[k]==b[k]]
assert set(b)-set(unchanged)=={'main'}
assert all(a[k]==b[k] for k in ('load','expected_status','case_class','admit_reference'))
adapter=raw[P/'identity_epochs.py'];tree=ast.parse(adapter)
assert not any(isinstance(n,(ast.Import,ast.ImportFrom)) and ('torch' in ast.unparse(n) or 'subprocess' in ast.unparse(n)) for n in ast.walk(tree))
facts=[
 'Complete 13309-byte identity module read. admit binds exact original fecf reference and 4dd probe before deriving labels; no native input is used by retirement_proofs.',
 'A retirement needs real MulBackward0 Saved.other, F64 rank0/8B/V0/nonview metadata, successful final-phase backward with retain_false defined by pinned probe, and every old Saved-owner getter reporting original release error.',
 'Full before-snapshot tensor traversal excludes current public, gradient, ultimate-base and other Saved aliases. Previously observed G StorageWeak is forbidden. Scalar-local getter ownership is substantiated by independent 9368328 source/actual projection.',
 'Every before snapshot retains old epoch. Only the post-operation observations and future references receive new Tensor/Storage labels. The original whole JSON inverse is enforced by the module.',
 'No literal case number, allocator address, numeric gradient or native outcome grants an epoch. Original raw reference files are unchanged.',
 'Original same-live-Tensor/Storage relations, values, layout, Version, Saved error fields, RNG, Weak expiry booleans and EOF expectations are not edited.',
 'The derived G Weak key uses the same Storage epoch as gradient/tensor comparison, matching unchanged support.grad() creation and check_expired().',
 'The original52c3 global reverse maps remain injective and never reset. A later epoch must still map to a distinct native incarnation/generation rather than reuse a live native object.',
 'The copied-control source implements five exact rejection rules and one explicit live-Saved no-retirement check. This review does not rerun those controls or duplicate the full original JSON admission.',
 'All non-main original top-level reader functions have exact source bytes. Nine explicit edits are reversed in actual bytes to af290. Main still admits original reference first, captures new adapter/parent before execution, writes proof separately and preserves all original failure identities.',
 'This is a narrow source review with no confirmed blocker. It does not qualify target production, repeat native/Torch/prepare, or resolve remaining retained NaN/layout/Version failures.'
]
after={str(p):info(p) for p in raw};assert before==after
report={'schema':'heptatorch.shape26-identity-epoch-independent-source-review.v1',
 'status':'SOURCE_REVIEW_NO_CONFIRMED_BLOCKER','native_executed':False,'Torch_executed':False,
 'reader_executed':False,'adapter_admission_executed':False,'copied_controls_executed':False,
 'source_only_exact_inverse_checked':True,'inverse_edits':9,'whole_inverse_equals_parent':True,
 'unchanged_top_level_functions':unchanged,'inputs_before':before,'inputs_after':after,
 'all_inputs_unchanged':True,'findings':facts,'whole_pytorch_gate':'HOLD'}
dump(O/'report.json',report)
dump(O/'input-custody.json',before)
(Path(O/'review-source.py')).write_bytes(Path(__file__).read_bytes())
manifest={'files':{p.name:info(p) for p in sorted(O.iterdir()) if p.is_file()},
 'native_executed':False,'Torch_executed':False}
dump(O/'manifest.json',manifest)
print(json.dumps({'status':report['status'],'report':info(O/'report.json'),'manifest':info(O/'manifest.json')}))
