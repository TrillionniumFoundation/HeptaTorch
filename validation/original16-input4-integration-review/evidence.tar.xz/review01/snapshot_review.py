import pathlib,json,hashlib,stat,difflib,traceback,sys
root=pathlib.Path("/home/qian-qi/heptatorch-continuation-20261116")
repo=root/"runs/to-view-recovery-integration-01/repo"
out=root/"runs/hia-original16-ci-independent-review-01"
out.mkdir(exist_ok=False)
def sha(b): return hashlib.sha256(b).hexdigest()
def write(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);p.chmod(0o644)
write(out/"snapshot_review.py",sys.argv[1].encode() if len(sys.argv)>1 else b"source is retained in durable process argv\n")
pins={"Makefile":"843155367735e173f2cee30859e2cd287516961fb5f651955b33d4bbf4932b2d",".github/workflows/native.yml":"aa0d217db07f0c3776c445454b5aebcb334344c2dfbcae7b72933e57a1de4295"}
report={"status":"RUNNING","native_executed":False,"Torch_executed":False,"files":{},"deltas":{}}
try:
 for rel,pin in pins.items():
  src=repo/rel;b=src.read_bytes()
  assert sha(b)==pin,(rel,sha(b),pin)
  write(out/"source"/rel,b)
  prev=root/"runs/differentiable-view-integration-independent-review-01/source"/rel
  old=prev.read_bytes();write(out/"previous111"/rel,old)
  op=difflib.SequenceMatcher(None,old.splitlines(keepends=True),b.splitlines(keepends=True),autojunk=False).get_opcodes()
  report["files"][rel]={"sha256":sha(b),"bytes":len(b),"original_mode":stat.S_IMODE(src.stat().st_mode),"previous_sha256":sha(old),"previous_bytes":len(old)}
  changes=[{"tag":tag,"old_start":i,"old_end":j,"new_start":k,"new_end":l} for tag,i,j,k,l in op if tag!="equal"]
  assert all(x["tag"]=="insert" for x in changes),(rel,changes)
  restored=b"".join(b.splitlines(keepends=True)[k:l] for tag,i,j,k,l in op if tag=="equal")
  assert restored==old
  report["deltas"][rel]=changes
  diff="".join(difflib.unified_diff(old.decode().splitlines(True),b.decode().splitlines(True),fromfile="previous111/"+rel,tofile="source/"+rel))
  write(out/"diff"/(rel.replace("/","_")+".diff"),diff.encode())
 for rel in ["validation/tensor-to-original16-recovery/package-manifest.json","validation/tensor-to-original16-recovery/replay-commands.json","validation/tensor-to-original-source-recovery/package-manifest.json","tests/differentiable_view_input4_review/prepare_reference.py"]:
  src=repo/rel; b=src.read_bytes();write(out/"inputs"/rel,b)
  report["files"][rel]={"sha256":sha(b),"bytes":len(b),"original_mode":stat.S_IMODE(src.stat().st_mode)}
  if rel.endswith(".json"):
   obj=json.loads(b)
   print(json.dumps({"path":rel,"type":type(obj).__name__,"keys":list(obj) if isinstance(obj,dict) else None,"sample":list(obj.items())[:1] if isinstance(obj,dict) and "package-manifest" in rel else obj if "replay-commands" in rel else None}))
 report["status"]="SOURCE_SNAPSHOT_AND_EXACT_ADDITION_INVERSE_PASS"
except BaseException as e:
 report.update(status="FAIL",error=repr(e),traceback=traceback.format_exc());raise
finally:
 write(out/"snapshot-report.json",(json.dumps(report,indent=2,sort_keys=True)+"\n").encode())
 print(json.dumps({"output":str(out),"report_sha256":sha((out/"snapshot-report.json").read_bytes()),"status":report["status"],"deltas":report["deltas"]}))
