import pathlib,json,hashlib,stat,subprocess,shlex,ast,traceback,sys
root=pathlib.Path("/home/qian-qi/heptatorch-continuation-20261116")
repo=root/"runs/to-view-recovery-integration-01/repo"
out=root/"runs/hia-original16-ci-independent-review-02"
def sha(b): return hashlib.sha256(b).hexdigest()
def write(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);p.chmod(0o644)
write(out/"pure_make_review.py",sys.argv[1].encode())
report={"status":"RUNNING","native_executions":0,"Torch_executions":0,"checks":[],"commands":[],"packages":{}}
def check(name,condition,detail=None):
 report["checks"].append({"name":name,"passed":bool(condition),"detail":detail})
 if not condition: raise AssertionError((name,detail))
def fm(p): 
 st=p.stat();b=p.read_bytes();return {"bytes":len(b),"sha256":sha(b),"mode":stat.S_IMODE(st.st_mode)}
try:
 snap=json.loads((out/"snapshot-report.json").read_bytes())
 check("source_snapshot_pass",snap["status"]=="SOURCE_SNAPSHOT_AND_EXACT_ADDITION_INVERSE_PASS")
 for rel,pin in {"validation/tensor-to-original16-recovery/package-manifest.json":"ea5e5a2d8a8547b41caec9391ad8c641d45dcffb155ee09cb331e339b7513f50","validation/tensor-to-original-source-recovery/package-manifest.json":"f769663e271d95138decfcc7e8da333d97bef2a647d49e60e42e17a5049f6591"}.items():
  b=(repo/rel).read_bytes();check(rel+" frozen pin",sha(b)==pin)
  m=json.loads(b);files=m["files"];check(rel+" nonempty count",len(files)>0 and len(files)==m["file_count"],len(files))
  before={}
  for name,want in files.items():
   p=repo/name
   check(name+" safe regular",p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(repo.resolve()))
   got=fm(p);check(name+" original exact metadata",got==want,got);before[name]=got
  report["packages"][rel]={"manifest_sha256":pin,"count":len(files),"files":before}
 commands=json.loads((repo/"validation/tensor-to-original16-recovery/replay-commands.json").read_bytes())
 check("four ordered suites",[x["name"] for x in commands["commands"]]==["copy4","reduction4","lanes2","branches6"])
 for rel,m in commands["existing_dependencies"].items():
  p=repo/rel;g=fm(p);check(rel+" fixed dependency",g["sha256"]==m["sha256"] and g["bytes"]==m["bytes"],g)
 make=(out/"source/Makefile").read_text()
 check("Make dryrun no parse-time shell", "$(shell" not in make)
 for entry in commands["commands"]:
  name=entry["name"];target="test-tensor-to-recovered-bits-"+name
  argv=["/usr/bin/make","--no-print-directory","-f",str(out/"source/Makefile"),"-n",target,"HEPTA_STACK_BUILD="+str(root/"runs/dview-r1-fixed-toolchain-cold-02/hepta-stack-budget")]
  result=subprocess.run(argv,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
  write(out/"make"/(name+".stdout"),result.stdout);write(out/"make"/(name+".stderr"),result.stderr)
  report["commands"].append({"argv":argv,"returncode":result.returncode,"stdout_sha256":sha(result.stdout),"stderr_sha256":sha(result.stderr),"native_executed":False})
  check(name+" make -n exit",result.returncode==0,result.stderr.decode())
  lines=result.stdout.decode().replace("\\\n"," ").splitlines()
  candidates=[shlex.split(line) for line in lines if "tests/tensor_to_original16_review/replay_as_strided_"+name+".py" in line]
  check(name+" one actual CLI",len(candidates)==1,candidates)
  check(name+" exact frozen argv",candidates[0]==entry["argv"],candidates[0])
  reader=repo/entry["argv"][4];raw=reader.read_bytes();check(name+" reader unchanged",sha(raw)==entry["reader_sha256"])
  tree=ast.parse(raw);options=set()
  for node in ast.walk(tree):
   if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=="add_argument":
    for a in node.args:
     if isinstance(a,ast.Constant) and isinstance(a.value,str) and a.value.startswith("--"): options.add(a.value)
  supplied={a for a in entry["argv"][5:] if a.startswith("--")}
  check(name+" parser accepts every supplied option",supplied<=options,{"supplied":sorted(supplied),"supported":sorted(options)})
  check(name+" original reference",sha((repo/entry["argv"][entry["argv"].index("--reference")+1]).read_bytes())==entry["reference_sha256"])
  check(name+" same frozen source and image pins",entry["argv"][entry["argv"].index("--expected-source-sha256")+1]==commands["source_sha256"] and entry["argv"][entry["argv"].index("--expected-native-sha256")+1]==commands["native_sha256"])
 for rel,m in report["packages"].items():
  for p,before in m["files"].items(): check(p+" unchanged after",fm(repo/p)==before)
 for rel,pin in [("source/Makefile","843155367735e173f2cee30859e2cd287516961fb5f651955b33d4bbf4932b2d"),("source/.github/workflows/native.yml","9f5a4acf05c25a2639417c4b0960c51439137dfef3af1a1a4d53e3c9e8d35a08")]:
  check("immutable "+rel,sha((out/rel).read_bytes())==pin)
 old=(root/"runs/hia-original16-ci-independent-review-01/snapshot_review.py").read_bytes()
 new=(out/"snapshot_review.py").read_bytes()
 inverse=new.replace(b"hia-original16-ci-independent-review-02",b"hia-original16-ci-independent-review-01").replace(b"9f5a4acf05c25a2639417c4b0960c51439137dfef3af1a1a4d53e3c9e8d35a08",b"aa0d217db07f0c3776c445454b5aebcb334344c2dfbcae7b72933e57a1de4295").replace(b'restored=b"".join(b"".join(b.splitlines(keepends=True)[k:l]) for tag,i,j,k,l in op if tag=="equal")',b'restored=b"".join(b.splitlines(keepends=True)[k:l] for tag,i,j,k,l in op if tag=="equal")')
 check("reviewer correction exact inverse",inverse==old)
 report["reviewer_first_failure"]={"report_sha256":"ed008171f98630c7b69f777ae5831c73c1f207383f556ec8650ba63edb3deaa5","classification":"reviewer_only_list_join_TypeError_before_workflow_read","source_sha256":sha(old),"successor_sha256":sha(new),"inverse_sha256":sha(inverse),"native_executions":0}
 report["status"]="PASS_PURE_PACKAGES_AND_FOUR_MAKE_DRY_RUNS"
except BaseException as e:
 report.update(status="FAIL",error=repr(e),traceback=traceback.format_exc());raise
finally:
 write(out/"pure-make-report.json",(json.dumps(report,indent=2,sort_keys=True)+"\n").encode())
 print(json.dumps({"status":report["status"],"report_sha256":sha((out/"pure-make-report.json").read_bytes()),"checks":len(report["checks"]),"commands":len(report["commands"]),"report":str(out/"pure-make-report.json")}))
