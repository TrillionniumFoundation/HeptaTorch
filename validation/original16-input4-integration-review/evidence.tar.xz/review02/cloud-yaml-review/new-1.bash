status=0
make test-differentiable-view-input4-reference \
  > build/differentiable-view-input4-reference.make.stdout \
  2> build/differentiable-view-input4-reference.make.stderr || status=$?
cat build/differentiable-view-input4-reference.make.stdout
cat build/differentiable-view-input4-reference.make.stderr >&2
if [ -f build/differentiable-view-input4-reference/report.json ]; then
  cp build/differentiable-view-input4-reference/report.json build/differentiable-view-input4-reference.json
  python3 -I -S -B tools/emit_ci_report.py build/differentiable-view-input4-reference.json
fi
exit "$status"
