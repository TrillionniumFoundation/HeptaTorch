import pathlib,hashlib,yaml,json,subprocess,fnmatch,traceback
out=pathlib.Path("/dev/shm/heptatorch-d26699e25fea/hia-original16-ci-yaml-review-02")
raw=(out/"workflow.part0").read_bytes()+(out/"workflow.part1").read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(raw)=="9f5a4acf05c25a2639417c4b0960c51439137dfef3af1a1a4d53e3c9e8d35a08"
(out/"native.yml").write_bytes(raw);(out/"native.yml").chmod(0o644)
report={"status":"RUNNING","workflow_sha256":sha(raw),"yaml_library_version":yaml.__version__,"new_native_executions":0,"new_Torch_executions":0,"checks":[],"new_bash_syntax":[]}
def check(name,test,detail=None):
 report["checks"].append({"name":name,"passed":bool(test),"detail":detail});assert test,(name,detail)
try:
 obj=yaml.safe_load(raw)
 steps=[step for job in obj["jobs"].values() for step in job.get("steps",[])]
 runs=[x for x in steps if "run" in x]
 check("all114_declared_steps",len(steps)==114,len(steps))
 check("all99_shell_blocks",len(runs)==99,len(runs))
 check("unique_step_names",len({x["name"] for x in steps})==len(steps))
 names=["Replay all four recovered AsStrided suites against their immutable original16 observations","Restore all fixed input4 observation bytes and original file modes"]
 new=[next(x for x in steps if x["name"]==name) for name in names]
 for index,step in enumerate(new):
  body=step["run"];p=out/("new-"+str(index)+".bash");p.write_text(body);p.chmod(0o644)
  proc=subprocess.run(["/usr/bin/bash","-n",str(p)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (out/("new-"+str(index)+".stdout")).write_bytes(proc.stdout)
  (out/("new-"+str(index)+".stderr")).write_bytes(proc.stderr)
  report["new_bash_syntax"].append({"name":step["name"],"script_sha256":sha(body.encode()),"argv":["/usr/bin/bash","-n",str(p)],"returncode":proc.returncode,"stdout_sha256":sha(proc.stdout),"stderr_sha256":sha(proc.stderr)})
  check(step["name"]+" syntax",proc.returncode==0,proc.stderr.decode())
 first=new[0]["run"];second=new[1]["run"]
 check("four_suites_explicit_order","for suite in copy4 reduction4 lanes2 branches6; do" in first)
 check("each_original_make_status_retained",'|| case_status=$?' in first and 'if [ "$case_status" -ne 0 ]; then status="$case_status"; fi' in first)
 check("first_exit_remains_nonzero",'exit "$status"' in first)
 check("both_top_make_streams_saved",'> "build/tensor-to-recovered-bits/$suite.make.stdout"' in first and '2> "build/tensor-to-recovered-bits/$suite.make.stderr"' in first)
 check("only_parent_created",'mkdir -p build/tensor-to-recovered-bits\n' in first and all("$suite" not in line for line in first.splitlines() if line.strip().startswith("mkdir")))
 check("reference_restore_top_streams_saved","> build/differentiable-view-input4-reference.make.stdout" in second and "2> build/differentiable-view-input4-reference.make.stderr" in second)
 check("restore_exit_retained","|| status=$?" in second and 'exit "$status"' in second)
 art=next(x for x in steps if x["name"]=="Export complete original16 replays and fixed input4 reference restoration")
 report["artifact"]=art
 check("artifact_always",art["if"]=="always()")
 check("artifact_action_pin",art["uses"]=="actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02")
 paths=art["with"]["path"].splitlines()
 check("original16_raw_artifact","build/tensor-to-recovered-bits/" in paths)
 check("original16_top_reports","build/tensor-to-recovered-bits-*.json" in paths)
 check("input4_original_modes_payload","build/differentiable-view-input4-reference/" in paths)
 check("input4_restore_report","build/differentiable-view-input4-reference.json" in paths)
 for p in ["build/differentiable-view-input4-reference.make.stdout","build/differentiable-view-input4-reference.make.stderr"]:
  check("input4 stream artifact "+p,any(fnmatch.fnmatchcase(p,g) for g in paths),paths)
 report["step_count"]=len(steps);report["run_block_count"]=len(runs);report["status"]="PASS_YAML_INCREMENTAL_BASH_AND_ARTIFACT_SOURCE"
except BaseException as e:
 report.update(status="FAIL",error=repr(e),traceback=traceback.format_exc());raise
finally:
 p=out/"report.json";p.write_text(json.dumps(report,indent=2,sort_keys=True)+"\n");p.chmod(0o644)
 print(json.dumps({"status":report["status"],"checks":len(report["checks"]),"path":str(p),"sha256":sha(p.read_bytes())}))
