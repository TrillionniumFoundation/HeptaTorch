status=0
mkdir -p build/tensor-to-recovered-bits
for suite in copy4 reduction4 lanes2 branches6; do
  case_status=0
  make "test-tensor-to-recovered-bits-$suite" HEPTA_STACK_BUILD="$RUNNER_TEMP/hepta-stack-budget" \
    > "build/tensor-to-recovered-bits/$suite.make.stdout" \
    2> "build/tensor-to-recovered-bits/$suite.make.stderr" || case_status=$?
  cat "build/tensor-to-recovered-bits/$suite.make.stdout"
  cat "build/tensor-to-recovered-bits/$suite.make.stderr" >&2
  if [ "$case_status" -ne 0 ]; then status="$case_status"; fi
  report="build/tensor-to-recovered-bits/$suite/report.json"
  if [ -f "$report" ]; then
    cp "$report" "build/tensor-to-recovered-bits-$suite.json"
    python3 -I -S -B tools/emit_ci_report.py "build/tensor-to-recovered-bits-$suite.json"
  fi
done
exit "$status"
