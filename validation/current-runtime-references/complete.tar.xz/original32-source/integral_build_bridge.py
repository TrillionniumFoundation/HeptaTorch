"""Only frozen source and actual699 build admission; no Tensor evaluator."""
import importlib.util
from pathlib import Path
import sys

from admit_reference32 import file_bytes, require, sha

MANIFEST = "6eee1fcd26367af3fba97488118e419788d64f41f90901b37cc594fe38154a9f"
PARENT_MANIFEST = "f13a204f5071c07b34ab35ee1b4a6dc90163137b0762fb57bd8c34abb0c8b277"
MODULES = {
    "admit_reference24.py":"51574abd55b8ddae6e6dfe5b0a8acdaf70c4a508d8c5303901ad59d95982e99c",
    "admit_integral_build.py":"ff912896c2442ff18057ca1853c2da707c944fc24e70a0906c571bd4b0d82293",
    "replay_integral24.py":"359a1bcd46488ff223db6b9bdd35906ce97a40c92f020e4c21cca673ac651f3d"}

def load(path, name):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def admit_build(binding_path,binding_sha256,inputs,*,integral_root,parent_root):
    integral_root,parent_root=Path(integral_root).resolve(),Path(parent_root).resolve()
    file_bytes(integral_root/"source-manifest.json",MANIFEST,inputs)
    file_bytes(parent_root/"source-manifest.json",PARENT_MANIFEST,inputs)
    for name,digest in MODULES.items():
        file_bytes(integral_root/name,digest,inputs)
    # No unbound module is imported. The complete package admission below also
    # binds every owner/observer/dependency source before any Native constructor.
    sys.path.insert(0,str(integral_root))
    replay=load(integral_root/"replay_integral24.py","integral699_original32_source_admission")
    replay.admit_integral_package(integral_root,MANIFEST,parent_root,inputs)
    current=inputs[str((integral_root/"native_observer_integral.py").resolve())]["raw"]
    old=inputs[str((parent_root/"native_observer_sum02.py").resolve())]["raw"]
    def constructor(raw):
        base=raw.index(b"class Native(ParentNative):")
        start=raw.index(b"    def __init__(",base)
        end=raw.index(b"\n    def ",start+1)
        return raw[start:end]
    original_ctor,current_ctor=constructor(old),constructor(current)
    require(current_ctor==original_ctor and len(current_ctor)==2514 and
            sha(current_ctor)=="3ed7a51cb5ee0879851b47890f9fa62ec88bef246fd3f37f222150f990571bc5",
            "whole-original2514-Native-constructor-byte-identical")
    build=load(integral_root/"admit_integral_build.py","integral699_original32_actual_build_admission")
    binding,report,summary=build.admit_build(binding_path,binding_sha256,inputs)
    require(report["functions"]==699 and len(report["units"])==14 and
            binding["runtime"]["sha256"]=="afd54444849ed10f7b4af53231c9db6542854b70f33e3927f8b05dfbb23ed1e3",
            "original32-executes-the-new699-image")
    return binding,report,dict(summary,
        original_Native_constructor_bytes=2514,
        original_Native_constructor_sha256=sha(current_ctor),
        original_Native_constructor_unchanged=True,
        original_reference24_replayed=False)
