"""Pure admission for the immutable actual32 and all frozen source inputs.

This module performs byte/schema/source/provenance validation only. It never
imports Torch, launches a process or evaluates Tensor arithmetic.
"""
import hashlib
import itertools
import json
from pathlib import Path, PurePosixPath
import re
import stat
import struct

REFERENCE_SHA = "c14e4b18f657429ad5dac5498c3abcae303b6a7e7550db7d15a3c9179bdcd728"
PROBE_SHA = "e462376e2c380c44ff1bcbf452169d2356ea0502ca2d2a4ad45cb99c1d0ed50d"
CONTRACT_SHA = "85e5e639e04ff63fc219fc63e716642a1564c205976156006b7fccd9f22a0c92"
MANIFEST_SHA = "7db1e860e6387a0d48b98769eb9f124211a90b92bfb62a07e55eb294ab4ef780"
SUPPORT_SHA = "ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae"
LOCK_SHA = "ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944"
PIP_SHA = "35ad4841c2f2f94be7ded7f1bcc97f9592f806658ff660bfac5bdc3b0cf986ef"
INVENTORY_SHA = "d204c5a8268a0d0f0a1dd162b5e0ab184beee83310bcad643b084deb691f3f49"
UPSTREAM = "31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457"
CHECK_NAMES = {
    "python_matches", "platform_matches", "version_backend_matches",
    "git_matches_oracle_build_pin", "distribution_version_matches",
    "direct_url_matches", "direct_url_archive_sha256_matches",
    "pip_report_url_matches", "pip_report_archive_sha256_matches",
    "pip_report_version_matches", "pip_report_requested"}
TENSOR_KEYS = {
    "tensor_identity", "storage_identity", "dtype", "device", "element_size",
    "shape", "strides", "numel", "storage_bytes", "storage_offset_elements",
    "storage_offset_bytes", "storage_raw_hex", "storage_sha256",
    "logical_bytes_hex", "logical_sha256", "binary_words", "version",
    "requires_grad", "is_view", "base_tensor_identity"}
SNAPSHOT_KEYS = {
    "tensor_getter_order", "tensors", "relations", "saved_getters_after_tensor_getters",
    "edge_getters", "edges_after_all_tensor_getters", "expired", "state"}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def require(condition, assertion_label, **facts):
    if not condition:
        raise AssertionError({"reference_rule": assertion_label, **facts})

def product(shape):
    out = 1
    for item in shape:
        out *= item
    return out

def file_bytes(path, expected=None, inputs=None):
    requested = Path(path)
    require(not requested.is_symlink(), "regular-input-no-symlink", path=str(requested))
    path = requested.resolve()
    before = path.stat()
    require(stat.S_ISREG(before.st_mode), "regular-input", path=str(path))
    raw = path.read_bytes()
    after = path.stat()
    require((before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
            (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
            "stable-input-read", path=str(path))
    record = {"path": str(path), "bytes": len(raw), "mode": stat.S_IMODE(after.st_mode),
              "sha256": sha(raw)}
    if expected is not None:
        require(record["sha256"] == expected, "exact-input-sha256", path=str(path))
    if inputs is not None:
        if str(path) in inputs:
            require(inputs[str(path)]["record"] == record and inputs[str(path)]["raw"] == raw,
                    "same-input-reread", path=str(path))
        else:
            inputs[str(path)] = {"record": record, "raw": raw}
    return raw, record

def check_capture(item, path):
    require(isinstance(item, dict) and type(item.get("accepted")) is bool, "capture", path=path)
    accepted = item["accepted"]
    require(item.get("outcome") == ("SUCCEEDED" if accepted else "RAISED"),
            "capture-outcome", path=path)
    if accepted:
        require(item.get("error") is None, "capture-success-error", path=path)
    else:
        error = item.get("error")
        require(isinstance(error, dict) and set(error) == {"type", "message"} and
                all(isinstance(error[x], str) and error[x] for x in error),
                "capture-error-record", path=path)
    warnings = item.get("warnings")
    require(isinstance(warnings, list), "capture-warnings", path=path)
    for warning in warnings:
        require(isinstance(warning, dict) and set(warning) == {"type", "message"} and
                all(isinstance(warning[x], str) for x in warning),
                "capture-warning-record", path=path)

def check_tensor(tensor, path):
    if tensor is None:
        return
    require(isinstance(tensor, dict) and set(tensor) == TENSOR_KEYS, "tensor-fields", path=path)
    require(tensor["dtype"] == "torch.float32" and tensor["device"] == "cpu" and
            tensor["element_size"] == 4, "scoped-tensor-dtype-device", path=path)
    for field in ("tensor_identity", "storage_identity"):
        require(isinstance(tensor[field], str) and tensor[field].isdigit() and int(tensor[field]) > 0,
                "tensor-observed-identity", path=path, field=field)
    base = tensor["base_tensor_identity"]
    require(base is None or isinstance(base, str) and base.isdigit() and int(base) > 0,
            "base-observed-identity", path=path)
    shape, strides = tensor["shape"], tensor["strides"]
    require(isinstance(shape, list) and isinstance(strides, list) and len(shape) == len(strides) <= 4,
            "tensor-rank", path=path)
    require(all(type(v) is int and 0 <= v <= 262144 for v in shape) and
            all(type(v) is int and 0 <= v < (1 << 63) for v in strides),
            "tensor-geometry-values", path=path)
    require(tensor["numel"] == product(shape), "tensor-numel", path=path)
    for field in ("storage_bytes", "storage_offset_elements", "storage_offset_bytes", "version"):
        require(type(tensor[field]) is int and tensor[field] >= 0, "tensor-unsigned", field=field, path=path)
    require(tensor["storage_offset_bytes"] == tensor["storage_offset_elements"] * 4,
            "tensor-byte-offset", path=path)
    for field in ("requires_grad", "is_view"):
        require(type(tensor[field]) is bool, "tensor-bool", field=field, path=path)
    require(tensor["is_view"] == (base is not None), "observed-base-view-consistency", path=path)
    physical = bytes.fromhex(tensor["storage_raw_hex"])
    logical = bytes.fromhex(tensor["logical_bytes_hex"])
    require(physical.hex() == tensor["storage_raw_hex"] and logical.hex() == tensor["logical_bytes_hex"],
            "canonical-byte-hex", path=path)
    require(len(physical) == tensor["storage_bytes"] and sha(physical) == tensor["storage_sha256"],
            "all-physical-bytes", path=path)
    require(len(logical) == 4 * tensor["numel"] and sha(logical) == tensor["logical_sha256"],
            "all-logical-bytes", path=path)
    # Integer address decoding of recorded bytes is an observer, not a sum kernel.
    copied = bytearray()
    for linear in range(tensor["numel"]):
        quotient = linear
        offset = tensor["storage_offset_elements"]
        for size, stride in zip(reversed(shape), reversed(strides)):
            offset += (quotient % size) * stride
            quotient //= size
        require(0 <= 4*offset <= len(physical)-4, "observed-storage-bound", path=path)
        copied.extend(physical[4*offset:4*offset+4])
    require(bytes(copied) == logical, "logical-from-recorded-physical", path=path)
    words = list(struct.unpack("<"+"I"*tensor["numel"], logical))
    require(words == tensor["binary_words"], "exact-recorded-F32-words", path=path)

def check_primitive(value, path):
    if value is None or type(value) in (bool, int, str):
        return
    if isinstance(value, list):
        for i, item in enumerate(value):
            check_primitive(item, path+"/"+str(i))
        return
    require(isinstance(value, dict), "primitive-schema", path=path)
    if set(value) == {"tensor"}:
        check_tensor(value["tensor"], path+"/tensor")
    elif set(value) == {"double_bits"}:
        require(type(value["double_bits"]) is int and 0 <= value["double_bits"] < (1 << 64),
                "primitive-double-bits", path=path)
    else:
        # Unexpected Python objects remain an explicit unsupported-observation
        # blocker in the native layer, while the original reference is preserved.
        require(set(value) == {"type", "diagnostic_repr"} and
                all(isinstance(v, str) for v in value.values()),
                "diagnostic-primitive-schema", path=path)

def check_node(node, depth, path):
    if node is None:
        return
    keys = {"kind"} | ({"next_edges"} if depth else set())
    if node.get("kind") == "AccumulateGrad":
        keys.add("variable")
    require(isinstance(node, dict) and set(node) == keys and isinstance(node["kind"], str),
            "node-fields", path=path)
    if "variable" in node:
        check_tensor(node["variable"], path+"/variable")
    if depth:
        require(isinstance(node["next_edges"], list), "node-next-edges", path=path)
        for i, edge in enumerate(node["next_edges"]):
            require(set(edge) == {"output_nr", "node"} and type(edge["output_nr"]) is int
                    and edge["output_nr"] >= 0, "edge-schema", path=path)
            check_node(edge["node"], depth-1, path+"/edge/"+str(i))

def check_snapshot(snapshot, states, path):
    require(isinstance(snapshot, dict) and set(snapshot) == SNAPSHOT_KEYS,
            "snapshot-fields", path=path)
    names = snapshot["tensor_getter_order"]
    require(isinstance(names, list) and len(names) == len(set(names)) and
            all(isinstance(name, str) and name for name in names), "snapshot-order", path=path)
    for field in ("tensors", "saved_getters_after_tensor_getters", "edge_getters",
                  "edges_after_all_tensor_getters"):
        require(set(snapshot[field]) == set(names), "snapshot-complete-name-set", field=field, path=path)
    for name in names:
        tensor = snapshot["tensors"][name]
        require(set(tensor) == {"before_grad_fn_getter", "grad_fn_getter",
                               "requires_grad_after_grad_fn_getter", "is_leaf_after_grad_fn_getter",
                               "retains_grad", "gradient"}, "tensor-getter-fields", path=path)
        check_tensor(tensor["before_grad_fn_getter"], path+"/"+name+"/before")
        require(type(tensor["requires_grad_after_grad_fn_getter"]) is bool,
                "requires-after-getter", path=path)
        for field in ("grad_fn_getter", "is_leaf_after_grad_fn_getter", "retains_grad", "gradient"):
            capture = tensor[field]
            check_capture(capture, path+"/"+name+"/"+field)
            suffix = ({"node"} if field == "grad_fn_getter" else
                      {"tensor"} if field == "gradient" else {"value"}) if capture["accepted"] else set()
            require(set(capture) == {"accepted", "outcome", "error", "warnings"} | suffix,
                    "getter-capture-fields", field=field, path=path)
            if capture["accepted"]:
                if field == "grad_fn_getter":
                    check_node(capture["node"], 4, path+"/"+name+"/fn")
                elif field == "gradient":
                    check_tensor(capture["tensor"], path+"/"+name+"/gradient")
                else:
                    require(type(capture["value"]) is bool, "getter-bool", path=path)
        check_capture(snapshot["edge_getters"][name], path+"/"+name+"/edge-getter")
        require(set(snapshot["edge_getters"][name]) == {"accepted", "outcome", "error", "warnings"},
                "edge-getter-fields", path=path)
        saved = snapshot["saved_getters_after_tensor_getters"][name]
        require(isinstance(saved, dict) and list(saved) == sorted(saved),
                "Saved-getter-order", path=path)
        for key, capture in saved.items():
            require(key.startswith("_saved_"), "Saved-getter-name", path=path)
            check_capture(capture, path+"/"+name+"/"+key)
            expected_keys = {"accepted", "outcome", "error", "warnings"} | (
                {"value"} if capture["accepted"] else set())
            require(set(capture) == expected_keys, "Saved-capture-fields", path=path)
            if capture["accepted"]:
                check_primitive(capture["value"], path+"/"+name+"/"+key)
        for i, edge in enumerate(snapshot["edges_after_all_tensor_getters"][name]):
            require(set(edge) == {"output_nr", "node", "matches_live_current_grad_fn"} and
                    type(edge["output_nr"]) is int and edge["output_nr"] >= 0,
                    "snapshot-edge-schema", path=path)
            check_node(edge["node"], 4, path+"/"+name+"/edge"+str(i))
            matches = edge["matches_live_current_grad_fn"]
            require(isinstance(matches, list) and len(matches) == len(set(matches)) and
                    set(matches) <= set(names), "edge-identity-names", path=path)
    pairs = [a+"|"+b for a, b in itertools.combinations(names, 2)]
    require(list(snapshot["relations"]) == pairs, "all-live-pair-relations", path=path)
    for pair, relations in snapshot["relations"].items():
        require(set(relations) == {"same_Python_object", "same_Tensor", "same_Storage",
                                   "same_current_Version_value"} and
                all(type(value) is bool for value in relations.values()),
                "relation-fields", path=path)
        # The wire has Tensor ownership, not arbitrary Python wrapper counts.
        require(relations["same_Python_object"] == relations["same_Tensor"],
                "unsupported-Python-wrapper-multiplicity", path=path, pair=pair)
        a, b = pair.split("|")
        left = snapshot["tensors"][a]["before_grad_fn_getter"]
        right = snapshot["tensors"][b]["before_grad_fn_getter"]
        require(relations["same_Tensor"] == (left["tensor_identity"] == right["tensor_identity"])
                and relations["same_Storage"] == (left["storage_identity"] == right["storage_identity"]),
                "relation-real-identities", path=path)
    require(isinstance(snapshot["expired"], dict) and
            all(isinstance(k, str) and type(v) is bool for k, v in snapshot["expired"].items()),
            "Weak-observation-fields", path=path)
    require(snapshot["state"] in states, "snapshot-full-state", path=path)

def admit_provenance(data, lock, pip):
    provenance = data["oracle_provenance"]
    expected = lock["oracle"]
    require(provenance["status"] == "PASS" and provenance["expected"] == expected and
            provenance["metadata_error"] is None and provenance["lock_sha256"] == LOCK_SHA and
            provenance["release_source_equivalence"] == lock["release_source_equivalence"],
            "oracle-lock-complete")
    checks, observed = provenance["checks"], provenance["observed"]
    require(set(checks) == CHECK_NAMES and all(v is True for v in checks.values()), "eleven-checks")
    require(observed["python"]["implementation"] == expected["python"]["implementation"] and
            observed["python"]["version"] == expected["python"]["version"] and
            isinstance(observed["python"]["full_version"], str) and observed["python"]["full_version"],
            "actual-python")
    require(observed["platform"] == expected["platform"] and observed["version"] == expected["version"]
            and observed["git_commit"] == expected["git_commit"] and
            observed["backend_versions"] == expected["backend_versions"] and
            observed["distribution_version"] == expected["version"], "actual-installed-build")
    wheel = expected["wheel"]
    direct = {"url": wheel["url"], "archive_info": {
        "hash": "sha256="+wheel["sha256"], "hashes": {"sha256": wheel["sha256"]}}}
    require(observed["direct_url"] == direct, "complete-PEP610-origin")
    records = [row for row in pip["install"] if row.get("metadata", {}).get("name", "").lower() == "torch"]
    require(len(records) == 1, "single-Torch-install-record")
    installed = records[0]
    require(installed["requested"] is True and installed["metadata"]["version"] == expected["version"]
            and installed["download_info"] == direct, "complete-wheel-install-origin")
    wanted_report = {"path": expected["install_report"], "pip_version": pip.get("pip_version"),
                     "download_info": installed["download_info"],
                     "metadata_name": installed["metadata"]["name"],
                     "metadata_version": installed["metadata"]["version"],
                     "requested": installed["requested"]}
    require(observed["install_report"] == wanted_report, "complete-observed-install-report")
    return {"all_eleven_recomputed": True, "installed_distribution_and_full_origin_compared": True}

def admit_reference(reference_path, source_root, inputs):
    root = Path(source_root).resolve()
    actual_raw, _ = file_bytes(reference_path, REFERENCE_SHA, inputs)
    manifest_raw, manifest_record = file_bytes(root/"source-manifest.json", MANIFEST_SHA, inputs)
    manifest = json.loads(manifest_raw)
    require(manifest["schema"] == "heptatorch.sum-dims-reference32-source-manifest.v1"
            and manifest["status"] == "SOURCE_ONLY_NOT_RUN" and manifest["case_count"] == 32,
            "frozen-reference-source-manifest")
    files = manifest["files"]
    require(len(files) == 38 and len({x["path"] for x in files}) == 38, "reference-payload-complete")
    by_relative = {}
    for entry in files:
        rel = PurePosixPath(entry["path"])
        require(not rel.is_absolute() and ".." not in rel.parts and rel.as_posix() == entry["path"],
                "safe-source-path")
        raw, record = file_bytes(root/entry["path"], entry["sha256"], inputs)
        require(record["bytes"] == entry["bytes"] and record["mode"] == entry["mode"],
                "frozen-source-bytes-mode", path=entry["path"])
        by_relative[entry["path"]] = (raw, record)
    for relative, digest in (("pytorch_sum_dims_probe.py", PROBE_SHA), ("case-contract.json", CONTRACT_SHA),
                             ("inputs/pytorch_oracle.py", SUPPORT_SHA), ("inputs/pytorch-oracle-lock.json", LOCK_SHA),
                             ("inputs/pytorch-install.json", PIP_SHA), ("inputs/upstream-lock.json", INVENTORY_SHA)):
        require(by_relative[relative][1]["sha256"] == digest, "known-reference-input", path=relative)
    contract = json.loads(by_relative["case-contract.json"][0])
    require(contract["case_count"] == 32 and len(contract["cases"]) == 32 and
            [row["index"] for row in contract["cases"]] == list(range(32)) and
            contract["expected_outputs_present"] is False and contract["expected_gradients_present"] is False and
            contract["expected_acceptance_present"] is False, "case-contract")
    primary = json.loads(by_relative["primary-sources.json"][0])
    require(primary["commit"] == UPSTREAM and len(primary["files"]) == 12, "primary-source-set")
    for relative, pin in primary["files"].items():
        raw, record = by_relative["upstream/"+relative]
        require(record["sha256"] == pin["sha256"] and len(raw) == pin["bytes"] and
                hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest() == pin["git_blob_sha1"],
                "primary-full-bytes-SHA-Gitblob", path=relative)
    data = json.loads(actual_raw)
    require(data["schema"] == "heptatorch.sum-dims-f32-reference32.v1" and data["status"] == "OBSERVED"
            and data["cases"] == 32 and data["planned_cases"] == 32 and len(data["rows"]) == 32,
            "complete-observed-reference")
    require(data["probe_sha256"] == PROBE_SHA and data["case_contract_sha256"] == CONTRACT_SHA
            and data["source_manifest_sha256"] == MANIFEST_SHA and
            data["primary_source_ref"] == UPSTREAM and data["primary_source_pins"] == primary["files"] and
            data["primary_files_read_and_sha256_gitblob_verified"] is True,
            "reference-source-bindings")
    require(data["case_plan"] == contract["cases"] and data["probe_error_count"] == 0 and
            data["setup_error_count"] == 0 and not data["probe_errors"], "all32-observed-no-setup-error")
    require(data["torch_executed"] is True and data["native_executed"] is False and
            data["compiler_executed"] is False and data["native_qualified"] is False and
            data["closed_schema_count"] == 0 and data["pytorch_api_denominator"] == 2590 and
            data["project_gates_remain_hold"] is True and data["full_pytorch_rewrite_complete"] is False,
            "reference-not-native-qualification")
    require(data["num_threads"] == 1 and data["cpu_capability"] == "AVX512" and
            data["environment_before"] == data["environment_after"] and
            data["environment_before"] == {"deterministic_algorithms": True, "deterministic_fill": True,
                "grad_enabled": True, "num_threads": 1, "cpu_capability": "AVX512"} and
            data["environment_restored_within_probe"] is True and data["original_outer_rng_restored"] is True,
            "actual-fixed-ISA-and-environment")
    require(isinstance(data["build_configuration"], str) and data["build_configuration"],
            "actual-build-configuration-preserved")
    provenance = admit_provenance(data, json.loads(by_relative["inputs/pytorch-oracle-lock.json"][0]),
                                  json.loads(by_relative["inputs/pytorch-install.json"][0]))
    before, after = data["inputs_before"], data["inputs_after"]
    require(before == after and data["source_files_unchanged"] is True and not data["changed_inputs"],
            "reference-inputs-unchanged")
    require(len(before) == 41 and len({item["path"] for item in before}) == 41,
            "reference-input-set-count")
    source_records = {record["path"]: record for _, record in by_relative.values()}
    source_records[manifest_record["path"]] = manifest_record
    actual_records = {item["path"]: item for item in before}
    require(set(source_records) <= set(actual_records), "all-reference-source-input-records")
    require(all(actual_records[path] == record for path, record in source_records.items()),
            "all-reference-source-byte-mode-records")
    external = set(actual_records)-set(source_records)
    require(len(external) == 2, "two-explicit-external-reference-inputs")
    external_pins = {PIP_SHA, INVENTORY_SHA}
    require({actual_records[path]["sha256"] for path in external} == external_pins,
            "external-pip-upstream-records")
    for path in external:
        _, record = file_bytes(path, actual_records[path]["sha256"], inputs)
        require(record == actual_records[path], "external-reference-bytes-mode", path=path)
    states = data["states"]
    require(isinstance(states, dict) and states and data["unique_complete_states"] == len(states),
            "nonempty-full-RNG-state-set")
    for key, state in states.items():
        raw = bytes.fromhex(state["hex"])
        require(set(state) == {"bytes", "hex"} and state["bytes"] == len(raw) == 5056 and sha(raw) == key,
                "complete-RNG-bytes", key=key)
    operations = {"attempted": 0, "succeeded": 0, "raised": 0}
    backwards = dict(operations)
    targets = {"attempted": 0, "accepted": 0, "raised": 0, "not_attempted": 0}
    snapshot_count = 0
    for index, (row, spec) in enumerate(zip(data["rows"], contract["cases"])):
        require(all(row[key] == value for key, value in spec.items()) and row["index"] == index and
                row["status"] == "OBSERVED" and row["setup_error"] is False and row["probe_error"] is None,
                "immutable-case-input-and-status", index=index)
        require(row["state_before_setup"] in states and row["state_after"] in states,
                "case-complete-RNG", index=index)
        require(isinstance(row["events"], list) and row["events"], "case-events-nonempty", index=index)
        target_events = [x for x in row["events"] if x["label"] == "sum_dim_IntList"]
        require(row["target_attempted"] is True and len(target_events) == 1 and
                target_events[0]["accepted"] is row["target_accepted"], "one-actual-target", index=index)
        targets["attempted"] += 1
        targets["accepted" if row["target_accepted"] else "raised"] += 1
        for number, event in enumerate(row["events"]):
            path = "case%02d/event%03d/%s" % (index, number, event["label"])
            check_capture(event, path)
            require(isinstance(event["label"], str) and event["label"], "event-label", path=path)
            for side in ("before", "after"):
                check_snapshot(event[side], states, path+"/"+side)
                snapshot_count += 1
            if event["accepted"]:
                require("returned" in event, "successful-return-record", path=path)
                check_primitive(event["returned"], path+"/return")
                if isinstance(event["returned"], dict) and "tensor" in event["returned"]:
                    require(set(event["returned_is_existing"]) == set(event["before"]["tensor_getter_order"])
                            and all(type(v) is bool for v in event["returned_is_existing"].values()),
                            "all-returned-object-relations", path=path)
            else:
                require("returned" not in event and "returned_is_existing" not in event,
                        "failed-event-no-invented-return", path=path)
            operations["attempted"] += 1
            operations["succeeded" if event["accepted"] else "raised"] += 1
            if event["label"].startswith("backward_"):
                backwards["attempted"] += 1
                backwards["succeeded" if event["accepted"] else "raised"] += 1
        check_snapshot(row["before_final_drops"], states, "case%02d/before-final" % index)
        snapshot_count += 1
        require(isinstance(row["final_expired"], dict) and
                all(type(v) is bool for v in row["final_expired"].values()), "final-Weak", index=index)
        require(row["events"][-1]["after"]["tensor_getter_order"] == [], "all-final-public-roots-dropped",
                index=index)
    require(operations["attempted"] == 626, "all-original626-events")
    require(operations == data["operation_totals"] and backwards == data["backward_totals"]
            and targets == data["target_totals"], "recomputed-event-totals")
    require(targets == {"attempted": 32, "accepted": 28, "raised": 4, "not_attempted": 0}
            and backwards == {"attempted": 49, "succeeded": 46, "raised": 3},
            "fixed-original32-terminal-counts")
    return data, contract, {"status": "ADMITTED_ACTUAL_ONLY_REFERENCE", "case_count": 32,
                           "snapshots_checked": snapshot_count, "operation_totals": operations,
                           "backward_totals": backwards, "target_totals": targets,
                           "source_payload_files": 38, "primary_source_files": 12,
                           "provenance": provenance, "reference_sha256": REFERENCE_SHA,
                           "native_executed_here": False, "Torch_executed_here": False}
