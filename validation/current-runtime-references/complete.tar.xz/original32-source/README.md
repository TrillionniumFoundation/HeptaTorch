# Original Sum32 on the Integral699 image

This is a source-only regression adapter. It has not imported or executed Python, a native image, an emitter, a compiler, or Torch during authoring.

The reference remains the original 39,045,926-byte actual Torch32 report, SHA256 c14e4b18f657429ad5dac5498c3abcae303b6a7e7550db7d15a3c9179bdcd728. Every one of its 32 cases and 626 events remains in the denominator. The reference and all numerical, identity, lifetime, Version, Saved, error, seed, RNG and byte comparisons are unchanged. No case filter, replacement tensor arithmetic, tolerance or NaN canonicalization is introduced.

## Exact inherited comparison

The complete SumCase region is 27,544 bytes, SHA256 191bdc7d1f69679912345ddca8efcf4e06bc1f29659ec7d65c1b349a17b68a54. The region starts at the LF preceding `def case_class(` and ends immediately before the LF preceding `def unchanged_inputs(`. It is byte-identical to the original frozen source03.

The complete 26,961-byte `admit_reference32.py` is copied without edits. The 2,514-byte Native constructor in the current integral observer is byte-identical to the original Sum03 constructor, SHA256 3ed7a51cb5ee0879851b47890f9fa62ec88bef246fd3f37f222150f990571bc5.

`source-inverse.json` records all 16 literal changes to the full replay file and the zero-edit copy of the reference admitter. Both directions reconstruct complete original files. New package/build bridge code only checks frozen inputs; it does not evaluate tensors.

## Actual current image

The external binding is /home/qian-qi/heptatorch-continuation-20261116/runs/sum-integral-native24-binding-01/actual-build-binding.json, SHA256 f4c01d40a9c59fdcc8b5b3d794b3aaff332ec56a01a8d20361681080d18d82e0. It binds actual source afd54444849ed10f7b4af53231c9db6542854b70f33e3927f8b05dfbb23ed1e3, ELF fec4f5cd7f80591fee98378cb5a8a85b6e71c5e4a7f0a00a739dad16afc24c28, and build 989dc70472c8ae8fd73c2daec6b5ea810bf3b2bda2d03aff29ddba51cbefffc6: 699 functions, 9,300 blocks, 33,297 instructions and 14 units.

The strict build admission from the frozen integral-native24 package checks the full 27-member emitted set, all four original admission objects, complete 696-to-699 inverse, full source package, all 14 fresh objects, all 15 process invocations/streams/EOF records, and preserved prior Sum inverse files. This adapter does not transfer any earlier 696 PASS result.

The integral package is a checked source dependency; its actual24 reference is not replayed here. The sole expected observations for this suite are the unchanged original c14e Torch32 report.

## Future exact invocation

Use the separately frozen request candidates under /home/qian-qi/heptatorch-continuation-20261116/runs/sum-integral-regression-candidates-01. They name the final package SHA256 and use the absolute interpreter with original module imports enabled:

```text
/usr/bin/python3 -E -S -B /home/qian-qi/heptatorch-continuation-20261116/runs/sum-integral-original32-source-01/replay_original_sum32.py
  --reference /home/qian-qi/heptatorch-continuation-20261116/runs/sum-dims-f32-reference32-actual-01/actual.json
  --reference-source-root /home/qian-qi/heptatorch-continuation-20261116/runs/sum-dims-f32-reference32-source-01
  --native-binding /home/qian-qi/heptatorch-continuation-20261116/runs/sum-integral-native24-binding-01/actual-build-binding.json
  --native-binding-sha256 f4c01d40a9c59fdcc8b5b3d794b3aaff332ec56a01a8d20361681080d18d82e0
  --parent-native-package /home/qian-qi/heptatorch-continuation-20261116/runs/sum-dims-native32-source-03
  --integral-native-package /home/qian-qi/heptatorch-continuation-20261116/runs/sum-integral-native24-source-01
  --package-sha256 <exact source-manifest SHA256>
  --output <fresh independent directory>
  --prepare-only
```

The actual candidate changes only the final mode to `--execute-native` and uses a distinct fresh output/key. Root owns submission. Prepare runs complete input/reference/build admission and creates no Native session. Actual requires all 32 cases and all 626 events; unsupported observations are BLOCKED and original failures are retained.

Source files and their manifest are immutable. Outputs and request files remain outside this exact nine-payload directory. A future failure requires a new revision and exact inverse; it must not be repaired in place.

Full project status remains HOLD. This finite regression is not complete sum schema, derivative, device, resource-failure or dtype qualification.
