#!/usr/bin/env python3
"""Observe concrete CPU view/reshape geometry, AD, alias and lifetime.

Twenty-six fixed input recipes distinguish infer-size errors, stride-compatible
views, reshape alias and actual contiguous-clone/unsafe-view fallback.
All acceptance, data, gradients, layout, Version, graph and Weak outcomes come
only from the pinned Torch invocation. No expected outputs are synthesized.
"""
import argparse
import gc
import hashlib
import itertools
import json
from pathlib import Path
import runpy
import struct
import sys
import traceback
import warnings

SUPPORT_SHA = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK_SHA = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
SOURCE_REF = '31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457'
SOURCE_PINS = {
    'aten/src/ATen/TensorUtils.cpp': '4c161d9d0e1354675be09577c90e02f4532226997314d3bd62ab46c7ab997956',
    'aten/src/ATen/native/TensorShape.cpp': 'ea89ebf0352140a392c29db196c010e8c715b9f98f774b47e8a25e0ca8d542ba',
    'aten/src/ATen/InferSize.h': 'f4c67085c123752bc40927e9dddad9d1a5cd8f2f62e79aae1b451c9384c8369f',
    'torch/csrc/autograd/FunctionsManual.cpp': 'a8603d6309822a3f93fa4fcb5ada05e2f0f7e29a1b96db64fe6f59ce0c730558',
    'torch/csrc/autograd/variable.cpp': 'ca2f1e573307069dee2fdff70ba81f161f48817cd278ad5464b9809cf23ab2c6',
}
PARENT_REFERENCE14_SHA = '2270d5ba925bcf91c56db94fac663695e69079c74edbf80aff8fa086e7c81665'
EXISTING_MULTI_AXIS72_SHA = '2512acdfeaf98f0aa8d8f44ce37dec48b926244ae274066e6e5b86e919a806e9'
CHECKS = {
    'python_matches', 'platform_matches', 'version_backend_matches',
    'git_matches_oracle_build_pin', 'distribution_version_matches',
    'direct_url_matches', 'direct_url_archive_sha256_matches',
    'pip_report_url_matches', 'pip_report_archive_sha256_matches',
    'pip_report_version_matches', 'pip_report_requested',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


CASE_PLAN = json.loads("[\n  {\n    \"index\": 0,\n    \"name\": \"view_contiguous_infer\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      2,\n      3\n    ],\n    \"input_stride\": [\n      3,\n      1\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      -1\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 1,\n    \"name\": \"view_holed_chunk\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      2,\n      3\n    ],\n    \"input_stride\": [\n      6,\n      2\n    ],\n    \"input_storage_offset\": 1,\n    \"target_shape\": [\n      3,\n      2\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 2,\n    \"name\": \"view_transpose_chunk_split\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      3,\n      2\n    ],\n    \"input_stride\": [\n      1,\n      3\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      3,\n      1,\n      2\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 3,\n    \"name\": \"view_transpose_flatten\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      3,\n      2\n    ],\n    \"input_stride\": [\n      1,\n      3\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      6\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 4,\n    \"name\": \"view_singleton_stride_ignored\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      2,\n      1,\n      3\n    ],\n    \"input_stride\": [\n      6,\n      999,\n      2\n    ],\n    \"input_storage_offset\": 1,\n    \"target_shape\": [\n      6\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 5,\n    \"name\": \"view_expanded_chunk_split\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      2,\n      3\n    ],\n    \"input_stride\": [\n      0,\n      1\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      2,\n      1,\n      3\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 6,\n    \"name\": \"view_expanded_flatten\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      2,\n      3\n    ],\n    \"input_stride\": [\n      0,\n      1\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      6\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 7,\n    \"name\": \"view_empty_same_shape\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 0,\n    \"input_size\": [\n      2,\n      0,\n      3\n    ],\n    \"input_stride\": [\n      17,\n      101,\n      2\n    ],\n    \"input_storage_offset\": 7,\n    \"target_shape\": [\n      2,\n      0,\n      3\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 8,\n    \"name\": \"view_empty_infer\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 0,\n    \"input_size\": [\n      2,\n      0,\n      3\n    ],\n    \"input_stride\": [\n      17,\n      101,\n      2\n    ],\n    \"input_storage_offset\": 7,\n    \"target_shape\": [\n      -1\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 9,\n    \"name\": \"view_empty_ambiguous_infer\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 0,\n    \"input_size\": [\n      2,\n      0,\n      3\n    ],\n    \"input_stride\": [\n      17,\n      101,\n      2\n    ],\n    \"input_storage_offset\": 7,\n    \"target_shape\": [\n      0,\n      -1\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 10,\n    \"name\": \"view_two_inferred_dimensions\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      2,\n      3\n    ],\n    \"input_stride\": [\n      3,\n      1\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      -1,\n      -1\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 11,\n    \"name\": \"view_invalid_negative_dimension\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      2,\n      3\n    ],\n    \"input_stride\": [\n      3,\n      1\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      -2,\n      3\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 12,\n    \"name\": \"view_invalid_element_count\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      2,\n      3\n    ],\n    \"input_stride\": [\n      3,\n      1\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      5\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 13,\n    \"name\": \"view_scalar_to_singletons\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [],\n    \"input_stride\": [],\n    \"input_storage_offset\": 2,\n    \"target_shape\": [\n      1,\n      1\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 14,\n    \"name\": \"reshape_holed_alias\",\n    \"operation\": \"reshape\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      2,\n      3\n    ],\n    \"input_stride\": [\n      6,\n      2\n    ],\n    \"input_storage_offset\": 1,\n    \"target_shape\": [\n      3,\n      2\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 15,\n    \"name\": \"reshape_transpose_copy\",\n    \"operation\": \"reshape\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      3,\n      2\n    ],\n    \"input_stride\": [\n      1,\n      3\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      -1\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 16,\n    \"name\": \"reshape_expanded_copy\",\n    \"operation\": \"reshape\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      2,\n      3\n    ],\n    \"input_stride\": [\n      0,\n      1\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      -1\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 17,\n    \"name\": \"reshape_empty_same_shape\",\n    \"operation\": \"reshape\",\n    \"dtype\": \"float32\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 0,\n    \"input_size\": [\n      2,\n      0,\n      3\n    ],\n    \"input_stride\": [\n      17,\n      101,\n      2\n    ],\n    \"input_storage_offset\": 7,\n    \"target_shape\": [\n      2,\n      0,\n      3\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 18,\n    \"name\": \"bool_view_holed\",\n    \"operation\": \"view\",\n    \"dtype\": \"bool\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      2,\n      3\n    ],\n    \"input_stride\": [\n      6,\n      2\n    ],\n    \"input_storage_offset\": 1,\n    \"target_shape\": [\n      -1\n    ],\n    \"requires_grad\": false\n  },\n  {\n    \"index\": 19,\n    \"name\": \"int64_view_transpose_chunk\",\n    \"operation\": \"view\",\n    \"dtype\": \"int64\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      3,\n      2\n    ],\n    \"input_stride\": [\n      1,\n      3\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      3,\n      1,\n      2\n    ],\n    \"requires_grad\": false\n  },\n  {\n    \"index\": 20,\n    \"name\": \"bool_reshape_transpose_copy\",\n    \"operation\": \"reshape\",\n    \"dtype\": \"bool\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      3,\n      2\n    ],\n    \"input_stride\": [\n      1,\n      3\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      -1\n    ],\n    \"requires_grad\": false\n  },\n  {\n    \"index\": 21,\n    \"name\": \"int64_reshape_transpose_copy\",\n    \"operation\": \"reshape\",\n    \"dtype\": \"int64\",\n    \"family\": \"detached_input\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      3,\n      2\n    ],\n    \"input_stride\": [\n      1,\n      3\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      -1\n    ],\n    \"requires_grad\": false\n  },\n  {\n    \"index\": 22,\n    \"name\": \"view_nonleaf_mul_input\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"nonleaf_mul\",\n    \"backing_elements\": 6,\n    \"input_size\": [\n      2,\n      3\n    ],\n    \"input_stride\": [\n      3,\n      1\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      3,\n      2\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 23,\n    \"name\": \"view_own_requires_leaf_view\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"own_requires_view\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      2,\n      3\n    ],\n    \"input_stride\": [\n      3,\n      1\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      3,\n      2\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 24,\n    \"name\": \"view_derived_requires_none_edge\",\n    \"operation\": \"view\",\n    \"dtype\": \"float32\",\n    \"family\": \"derived_requires_view\",\n    \"backing_elements\": 16,\n    \"input_size\": [\n      2,\n      3\n    ],\n    \"input_stride\": [\n      3,\n      1\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      3,\n      2\n    ],\n    \"requires_grad\": true\n  },\n  {\n    \"index\": 25,\n    \"name\": \"reshape_nonleaf_transpose_copy\",\n    \"operation\": \"reshape\",\n    \"dtype\": \"float32\",\n    \"family\": \"nonleaf_mul_transpose\",\n    \"backing_elements\": 6,\n    \"input_size\": [\n      3,\n      2\n    ],\n    \"input_stride\": [\n      1,\n      3\n    ],\n    \"input_storage_offset\": 0,\n    \"target_shape\": [\n      -1\n    ],\n    \"requires_grad\": true\n  }\n]")
SEED_PHASES = (
    ('finite', (0x3f800000, 0xc0000000, 0x40400000, 0, 0x80000000, 0x3f000000)),
    ('signed_zero_and_payloads', (0x80000000, 0x7fc12345, 0xffc23456, 0x3f800000, 0x7fc00001, 0xffc00002)),
)


def plan():
    rows = [dict(row) for row in CASE_PLAN]
    assert len(rows) == 26 and len({row['name'] for row in rows}) == 26
    for row in rows:
        assert row['operation'] in ('view', 'reshape')
        assert row['dtype'] in ('float32', 'bool', 'int64')
        assert len(row['input_size']) == len(row['input_stride']) <= 4
        assert len(row['target_shape']) <= 4
        row['seed_phases'] = [{'name': name, 'repeating_input_words': list(words)}
                              for name, words in SEED_PHASES]
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ('reference', 'lock', 'repo', 'output'):
        ap.add_argument('--' + name, type=Path, required=True)
    ap.add_argument('--prepare-only', action='store_true')
    args = ap.parse_args()
    assert Path.cwd().resolve() == args.repo.resolve()
    assert not args.output.exists()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    inputs = {p.resolve(): p.read_bytes() for p in (Path(__file__), args.reference, args.lock)}
    assert sha(inputs[args.reference.resolve()]) == SUPPORT_SHA
    assert sha(inputs[args.lock.resolve()]) == LOCK_SHA
    common = {
        'schema': 'heptatorch.concrete-view-reshape-reference26.v1',
        'probe_sha256': sha(inputs[Path(__file__).resolve()]),
        'primary_source_ref': SOURCE_REF, 'primary_source_pins': SOURCE_PINS,
        'case_plan': plan(), 'native_executed': False, 'native_qualified': False,
        'full_pytorch_rewrite_complete': False, 'pytorch_api_denominator': 2590,
        'closed_schema_count': 0,
        'policy': 'OBSERVATION ONLY. Every output, gradient, error, identity, Version and lifetime is recorded from actual pinned Torch.',
        'scope': 'CPU concrete-size view/reshape on F32/bool/int64; rank at most four; first-order AD only for F32. Setup as_strided is explicit and separately observed. No arbitrary Python-wrapper refcount equivalence, dynamic SymInt execution or complete schema qualification is asserted.',
        'getter_order': 'For each live name: raw Tensor/Storage/layout/Version/requires/_base, then grad_fn, is_leaf, retains_grad, grad; Saved attributes and pairwise current gradient-edge relations follow in insertion order. These getters can refresh lazy ViewInfo history.',
        'ownership_scope': 'Only live holds named Tensor roots. Weak references hold StorageWeakRef only. All snapshots and captured events contain primitives/copies; function-local grad_fn, Saved and AccumulateGrad.variable wrappers are released before final weak checks.',
        'prior_reference14_sha256': PARENT_REFERENCE14_SHA,
        'existing_multi_axis72_sha256': EXISTING_MULTI_AXIS72_SHA,
        'seed_policy': 'Explicit raw input words. Final seeds are plain F32 clone tensors; no output gradient values are predicted.',
    }
    if args.prepare_only:
        report = {**common, 'status': 'PREPARED_NOT_RUN', 'torch_executed': False,
                  'cases': 0, 'rows': [], 'inputs_sha256': {str(p): sha(b) for p, b in inputs.items()}}
        args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
        print(json.dumps({'status': report['status'], 'planned_cases': len(plan()), 'probe_sha256': common['probe_sha256']}))
        return 0

    old_argv = sys.argv
    try:
        sys.argv = [str(args.reference), str(args.repo / 'reference-only-no-native-execution'),
                    str(args.output.with_suffix('.provenance.json')), str(args.lock)]
        context = runpy.run_path(str(args.reference), run_name='concrete_view_reshape_provenance_only')
    finally:
        sys.argv = old_argv
    torch, provenance = context['torch'], context['PROVENANCE']
    assert provenance['status'] == 'PASS' and set(provenance['checks']) == CHECKS
    assert all(value is True for value in provenance['checks'].values())
    assert torch.are_deterministic_algorithms_enabled()
    assert torch.utils.deterministic.fill_uninitialized_memory is True
    assert torch.get_num_threads() == 1
    assert torch.backends.cpu.get_cpu_capability() == 'AVX512'
    from torch.multiprocessing.reductions import StorageWeakRef
    states, rows, errors = {}, [], []

    def environment():
        return {'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
                'deterministic_fill': torch.utils.deterministic.fill_uninitialized_memory,
                'grad_enabled': torch.is_grad_enabled(), 'num_threads': torch.get_num_threads(),
                'cpu_capability': torch.backends.cpu.get_cpu_capability()}

    environment_before = environment()
    outer_rng = bytes(torch.get_rng_state().tolist())

    def rng():
        raw = bytes(torch.get_rng_state().tolist())
        assert len(raw) == 5056
        key = sha(raw)
        states.setdefault(key, {'bytes': len(raw), 'hex': raw.hex()})
        return key

    def capture(operation):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            try:
                value = operation()
                event = {'accepted': True, 'outcome': 'SUCCEEDED', 'error': None}
            except Exception as error:
                value = None
                event = {'accepted': False, 'outcome': 'RAISED',
                         'error': {'type': type(error).__name__, 'message': str(error)}}
        event['warnings'] = [{'type': type(w.message).__name__, 'message': str(w.message)} for w in caught]
        return value, event

    def raw_tensor(x):
        if x is None:
            return None
        storage = x.untyped_storage()
        raw = bytes(storage)
        width = x.element_size()
        shape, strides, offset = list(x.shape), list(x.stride()), x.storage_offset()
        logical = bytearray()
        for linear in range(x.numel()):
            quotient, at = linear, offset
            for size, stride in zip(reversed(shape), reversed(strides)):
                at += (quotient % size) * stride
                quotient //= size
            word = raw[at * width:at * width + width]
            assert len(word) == width
            logical.extend(word)
        base = x._base
        result = {'tensor_identity': str(x._cdata), 'storage_identity': str(storage._cdata),
                  'dtype': str(x.dtype), 'element_size': width, 'shape': shape, 'strides': strides,
                  'numel': x.numel(), 'storage_bytes': len(raw),
                  'storage_offset_elements': offset, 'storage_offset_bytes': offset * width,
                  'storage_raw_hex': raw.hex(), 'logical_bytes_hex': bytes(logical).hex(),
                  'binary_words': [int.from_bytes(logical[i:i + width], 'little') for i in range(0, len(logical), width)],
                  'version': x._version, 'requires_grad': x.requires_grad, 'is_view': x._is_view(),
                  'base_tensor_identity': None if base is None else str(base._cdata)}
        del base, storage
        return result

    def primitive(value):
        if isinstance(value, torch.Tensor):
            return {'tensor': raw_tensor(value)}
        if value is None or isinstance(value, (bool, int, str)):
            return value
        if isinstance(value, float):
            return {'double_bits': struct.unpack('<Q', struct.pack('<d', value))[0]}
        if isinstance(value, (tuple, list)):
            return [primitive(item) for item in value]
        return {'type': type(value).__name__, 'diagnostic_repr': repr(value)}

    def node_info(fn, depth=4):
        if fn is None:
            return None
        result = {'kind': type(fn).__name__}
        if type(fn).__name__ == 'AccumulateGrad':
            variable = fn.variable
            result['variable'] = raw_tensor(variable)
            del variable
        if depth:
            result['next_edges'] = [{'output_nr': int(nr), 'node': node_info(child, depth - 1)}
                                    for child, nr in fn.next_functions]
        return result

    def saved_attributes(fn):
        if fn is None:
            return {}
        attributes = {}
        for name in sorted(n for n in dir(fn) if n.startswith('_saved_')):
            value, event = capture(lambda name=name: getattr(fn, name))
            if event['accepted']:
                event['value'] = primitive(value)
            del value
            attributes[name] = event
        return attributes

    def tensor_observation(x, weak):
        before = raw_tensor(x)
        fn, getter = capture(lambda: x.grad_fn)
        if getter['accepted']:
            getter['node'] = node_info(fn)
        del fn
        leaf, leaf_event = capture(lambda: x.is_leaf)
        if leaf_event['accepted']:
            leaf_event['value'] = bool(leaf)
        del leaf
        retained, retained_event = capture(lambda: x.retains_grad)
        if retained_event['accepted']:
            retained_event['value'] = bool(retained)
        del retained
        grad, grad_event = capture(lambda: x.grad)
        if grad_event['accepted']:
            grad_event['tensor'] = raw_tensor(grad)
            if grad is not None:
                key = 'observed_grad_storage_' + str(grad.untyped_storage()._cdata)
                if key not in weak:
                    weak[key] = StorageWeakRef(grad.untyped_storage())
        del grad
        return {'before_grad_fn_getter': before, 'grad_fn_getter': getter,
                'requires_grad_after_grad_fn_getter': x.requires_grad,
                'is_leaf_after_grad_fn_getter': leaf_event, 'retains_grad': retained_event,
                'gradient': grad_event}

    def snapshot(live, weak):
        names = list(live)
        tensors = {name: tensor_observation(live[name], weak) for name in names}
        relations = {}
        for left_name, right_name in itertools.combinations(names, 2):
            left, right = live[left_name], live[right_name]
            relations[left_name + '|' + right_name] = {
                'same_Python_object': left is right, 'same_Tensor': left._cdata == right._cdata,
                'same_Storage': left.untyped_storage()._cdata == right.untyped_storage()._cdata,
                'same_current_Version_value': left._version == right._version}
        if len(names) > 1:
            del left, right
        current, getters, saved, edges = {}, {}, {}, {}
        for name in names:
            fn, event = capture(lambda name=name: live[name].grad_fn)
            getters[name] = event
            if event['accepted']:
                current[name] = fn
            del fn
        for name, fn in current.items():
            saved[name] = saved_attributes(fn)
            edge_rows = []
            if fn is not None:
                for child, nr in fn.next_functions:
                    edge_rows.append({'output_nr': int(nr), 'node': node_info(child),
                                      'matches_live_current_grad_fn': [other for other, candidate in current.items()
                                                                     if child is not None and child is candidate]})
                    del child
            edges[name] = edge_rows
        # No Function or Tensor wrapper is returned or added to a persistent cache.
        if current:
            del fn
        current.clear()
        return {'tensor_getter_order': names, 'tensors': tensors, 'relations': relations,
                'saved_getters_after_tensor_getters': saved, 'edge_getters': getters,
                'edges_after_all_tensor_getters': edges,
                'expired': {name: ref.expired() for name, ref in weak.items()}, 'state': rng()}

    def make_backing(spec):
        dtype = getattr(torch, spec['dtype'])
        if spec['family'] in ('nonleaf_mul', 'nonleaf_mul_transpose'):
            return torch.tensor([[1., 2., 3.], [4., 5., 6.]], dtype=dtype)
        count = spec['backing_elements']
        if count == 0:
            return torch.empty((0,), dtype=dtype)
        if spec['dtype'] == 'bool':
            values = [bool(i % 2) for i in range(count)]
        elif spec['dtype'] == 'int64':
            pattern = [0, 1, -1, 16777217, -16777219, (1 << 62) + 3, -(1 << 62) + 3, 9]
            values = [pattern[i % len(pattern)] for i in range(count)]
        else:
            values = [float(i + 1) for i in range(count)]
        return torch.tensor(values, dtype=dtype)

    def make_seed(shape, words):
        count = 1
        for size in shape:
            count *= size
        assert count == len(words)
        signed = [word if word < 0x80000000 else word - 0x100000000 for word in words]
        # Intermediate int32 and dtype-view wrappers are temporary seed construction
        # only. The observed published seed is an ordinary nonview F32 clone.
        result = torch.tensor(signed, dtype=torch.int32).view(torch.float32).reshape(tuple(shape)).clone(
            memory_format=torch.contiguous_format)
        assert raw_tensor(result)['binary_words'] == words
        assert not result._is_view() and result._base is None
        return result

    def observe(spec):
        torch.manual_seed(1729)
        live, weak, events = {}, {}, []
        row = {**spec, 'state_before_setup': rng(), 'events': events}

        def event(label, operation, publish=None):
            before = snapshot(live, weak)
            value, result = capture(operation)
            result.update(label=label, before=before)
            if result['accepted']:
                result['returned'] = primitive(value)
                if isinstance(value, torch.Tensor):
                    result['returned_is_existing'] = {name: value is item for name, item in live.items()}
                if publish is not None:
                    assert isinstance(value, torch.Tensor), (label, type(value).__name__)
                    live[publish] = value
                    # RHS creation precedes replacement/destruction of an older
                    # Weak with this key, exactly as Python assignment evaluates.
                    weak[publish + '_storage'] = StorageWeakRef(value.untyped_storage())
            del value
            result['after'] = snapshot(live, weak)
            events.append(result)
            return result['accepted']

        def drop(name):
            del live[name]
            gc.collect()

        def clear_grad(name):
            live[name].grad = None

        def finish():
            row['before_final_drops'] = snapshot(live, weak)
            for name in list(live):
                event('final_drop_' + name, lambda name=name: drop(name))
            assert not live
            gc.collect()
            row.update(status='OBSERVED', final_expired={name: ref.expired() for name, ref in weak.items()},
                       state_after=rng())
            return row

        if not event('construct_backing', lambda: make_backing(spec), publish='backing'):
            row['remaining_not_attempted'] = 'backing constructor raised'
            return finish()
        family = spec['family']
        if family in ('nonleaf_mul', 'nonleaf_mul_transpose'):
            if not event('backing_requires_grad_true', lambda: live['backing'].requires_grad_(True)):
                row['remaining_not_attempted'] = 'backing requires request raised'
                return finish()
            if family == 'nonleaf_mul':
                ready = event('construct_mul_input', lambda: live['backing'] * 2., publish='input')
            else:
                ready = event('construct_mul_middle', lambda: live['backing'] * 2., publish='middle')
                if ready:
                    ready = event('construct_transpose_input', lambda: live['middle'].t(), publish='input')
            if not ready:
                row['remaining_not_attempted'] = 'nonleaf input construction raised'
                return finish()
        else:
            def make_input():
                value = torch.as_strided(live['backing'], tuple(spec['input_size']),
                                         tuple(spec['input_stride']), spec['input_storage_offset'])
                if family == 'detached_input':
                    value = value.detach()
                return value
            if not event('construct_' + family, make_input, publish='input'):
                row['remaining_not_attempted'] = 'input geometry construction raised'
                return finish()
            if family == 'derived_requires_view':
                ready = event('backing_requires_grad_true', lambda: live['backing'].requires_grad_(True))
            elif spec['requires_grad']:
                ready = event('input_requires_grad_true', lambda: live['input'].requires_grad_(True))
            else:
                ready = True
            if not ready:
                row['remaining_not_attempted'] = 'requires request raised'
                return finish()

        def reshape_target():
            return getattr(live['input'], spec['operation'])(tuple(spec['target_shape']))
        accepted = event('target_' + spec['operation'], reshape_target, publish='result')
        if not accepted:
            row['remaining_not_attempted'] = 'target view/reshape raised; no result Tensor exists'
            return finish()

        gradient_names = [name for name in ('backing', 'middle', 'input', 'result')
                          if name in live and live[name].requires_grad]
        for name in gradient_names:
            if not live[name].is_leaf:
                event('retain_grad_' + name, lambda name=name: live[name].retain_grad())

        if live['result'].requires_grad:
            for phase_index, (phase_name, pattern) in enumerate(SEED_PHASES):
                if phase_index:
                    for name in gradient_names:
                        event('clear_before_phase_' + str(phase_index) + '_' + name,
                              lambda name=name: clear_grad(name))
                    event('drop_seed_before_phase_' + str(phase_index), lambda: drop('seed'))
                words = [pattern[i % len(pattern)] for i in range(live['result'].numel())]
                if not event('construct_seed_phase_' + str(phase_index),
                             lambda words=words: make_seed(live['result'].shape, words), publish='seed'):
                    row['remaining_not_attempted'] = 'explicit seed constructor raised'
                    return finish()
                retain = phase_index + 1 < len(SEED_PHASES)
                event('backward_phase_' + str(phase_index) + '_' + phase_name,
                      lambda retain=retain: live['result'].backward(live['seed'], retain_graph=retain))
                for name in gradient_names:
                    if live[name].grad is not None:
                        event('hold_phase_' + str(phase_index) + '_' + name + '_gradient',
                              lambda name=name: live[name].grad,
                              publish='held_phase_' + str(phase_index) + '_' + name + '_grad')
            if family in ('nonleaf_mul', 'nonleaf_mul_transpose'):
                event('backward_retry_after_default',
                      lambda: live['result'].backward(live['seed']))
        else:
            row['backward_not_attempted'] = 'actual result.requires_grad is false'

        def fill_output():
            value = True if spec['dtype'] == 'bool' else (-9 if spec['dtype'] == 'int64' else 42.)
            with torch.no_grad():
                return live['result'].fill_(value)
        event('mutate_result_fill_nograd', fill_output)
        return finish()

    with torch.random.fork_rng(devices=[]):
        for spec in plan():
            try:
                rows.append(observe(spec))
            except BaseException as error:
                failure = {**spec, 'status': 'PROBE_ERROR', 'error': repr(error),
                           'traceback': traceback.format_exc()}
                errors.append(failure)
                rows.append(failure)
    environment_after = environment()
    assert environment_before == environment_after
    assert bytes(torch.get_rng_state().tolist()) == outer_rng
    assert all(path.read_bytes() == raw for path, raw in inputs.items())
    totals = {'attempted': 0, 'succeeded': 0, 'raised': 0}
    for row in rows:
        for event in row.get('events', []):
            totals['attempted'] += 1
            totals['succeeded' if event['accepted'] else 'raised'] += 1
    report = {**common, 'status': 'OBSERVED' if not errors else 'PROBE_ERROR', 'torch_executed': True,
              'oracle_provenance': provenance, 'build_configuration': torch.__config__.show(),
              'cpu_capability': torch.backends.cpu.get_cpu_capability(), 'num_threads': torch.get_num_threads(),
              'environment_before': environment_before, 'environment_after': environment_after,
              'environment_restored': True, 'original_outer_rng_restored': True,
              'source_files_unchanged': True, 'inputs_sha256': {str(p): sha(b) for p, b in inputs.items()},
              'cases': len(rows), 'rows': rows, 'states': states, 'unique_complete_states': len(states),
              'probe_errors': errors, 'probe_error_count': len(errors), 'operation_totals': totals}
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({key: report[key] for key in ('status', 'cases', 'probe_sha256', 'operation_totals', 'probe_error_count')}))
    return int(bool(errors))


if __name__ == '__main__':
    raise SystemExit(main())
