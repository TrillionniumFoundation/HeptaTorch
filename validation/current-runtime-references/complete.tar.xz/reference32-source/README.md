# SumDims F32 reference32: frozen source candidate

Status: SOURCE_ONLY_NOT_RUN. The probe CLI has not been run. No Torch, HIA native,
emitter or compiler was executed. A separate stdlib-only AST parse validates Python
syntax and authored literal input geometry; it calls no function from the probe.

## Purpose and finite scope

This candidate records the actual fixed PyTorch source/wheel pair for CPU F32
sum.dim_IntList. It covers ranks 0 through 4, concrete nonnegative layouts, one
thread and the pinned AVX512 CPU environment. There are exactly 32 separately
numbered recipes: 28 geometry/numeric/AD observations and 4 dim-boundary
observations. No expected acceptance, error, output shape, numeric result,
gradient or lifetime is stored. The source-only labels for intended kernel routes
are derived from the pinned source; they are not runtime dispatch instrumentation.

The full schema remains OPEN and the project remains HOLD. HIA source01 emission,
compilation and qualification are separate root-owned evidence. This reference
package asserts no HIA execution result or emitted function count and does not
extend any earlier finite PASS.

## Files and invocation

The exact runnable request is outside the payload manifest in
actual-process-request-candidate.json, and is explicitly NOT_SUBMITTED in the
companion actual-execution-intent.json. Future authorized execution must use its
single stable key. The probe reads its exact source-manifest SHA from the CLI and
binds every payload before importing the support module.

The request invokes the existing fixed 3.12 Torch venv with python -B, under
repo-pr28-repair, with these probe arguments:

- --repo: the fixed existing reference repository
- --source-manifest: this directory's source-manifest.json
- --source-manifest-sha256: the exact final manifest SHA
- --output-dir: a new runs/sum-dims-f32-reference32-actual-01 directory

The output directory must not exist. The expected original result location is
actual.json there; unexpected preflight/runtime failure goes to failure.json.
The fixed support's own provenance refusal, if any, is preserved separately.
The h_process_start request, terminal status and complete stdout/stderr with
independent EOF must be captured by the unique executor. None exists for an
actual run at this handoff.

## Input and source custody

The payload includes the original 61,783-byte ef8 support, ca2 lock, exact 35ad
pip report, d204 upstream inventory and the original 4dd374 observer source.
It also contains all 12 complete fixed upstream files listed in
primary-sources.json, with SHA256, length and Git blob identity. Future execution
checks the actual repository's pip and inventory bytes against these copies.
It records every before/after mode, size and SHA and rejects a changed input.
The actual 11-check provenance object is recorded whole, including the lock,
observed distribution/direct URL/install metadata and release-source equivalence.
A downstream admission reader must compare the complete recorded provenance;
eleven true flags alone are not sufficient.

The probe calls the support with a non-main runpy name and an intentionally
unused native path. It calls no native, subprocess, compiler or emitter function.
The support only initializes and proves the pinned Torch environment in this
usage. The 12 primary files are actually read and hash-checked by the probe;
their identities are not merely copied into a claim.

## The 32 recipes

| Cases | Geometry / operation obligation |
| --- | --- |
| 0-3 | rank0 None, empty dim list, axis0 and axis-1; signed zero and signed payload inputs |
| 4-7 | rank3 size-one strides; None/[] versus explicit-all, keepdim false/true, unsorted and negative axes |
| 8-11 | wrapped duplicate, scalar duplicate, positive and negative out-of-range dims; actual errors only |
| 12-15 | empty reduced/kept axes, explicit F32 dtype, rank4 singleton axes, nonstandard strides and offset7 |
| 16-17 | scalar inner: stride2, four row_sum ILP lanes; finite cancellation / different NaN payloads |
| 18-19 | scalar outer width5: four-column cascade and one-column tail; cancellation / payloads |
| 20-21 | AVX512 vector inner width81: 64+16+1 and scalar tail before final lane fold |
| 22-23 | AVX512 vector outer width81: 64-column cascade, 16-vector and one-scalar tails |
| 24-25 | rank4 dims[2,0] nonadjacent reduction, noncoalesced chunks and output +=; cancellation / payloads |
| 26 | real permute -> preserve clone -> sum, retained chain, explicit keepdim seed with odd singleton strides |
| 27 | actual expand -> detached own leaf, input zero strides, observed G contract and result mutation |
| 28 | wrong backward seed, then valid backward, then downstream Mul Saved.other mutation/error ordering |
| 29 | nonleaf Tensor-factor Mul input mutated after sum forward; metadata-only sum edge and upstream Saved/release |
| 30 | drop public backing/input before backward; actual Weak and explicit later recovery of captured leaf/G |
| 31 | rank1 vector boundary16+1, all-negative-zero input |

case-contract.json contains every raw input word and exact dims/layout/seed
recipe. Input words were serialized as integer literals during source authoring.
No floating arithmetic was used to create expected values. Numerical input
positions deliberately separate ILP groups, vector tails, different reduced
chunks and different NaN operands. Cases24/25 cannot be replaced by sequential
single-axis sums. Any future output bit mismatch, including payload/sign or
zero sign, remains visible and blocks that observed subset; no rtol/atol or
canonicalization fallback is permitted.

## Observer and AD order

Nine original helper functions remain exact; raw_tensor adds only CPU device and
two SHA fields. helper-origin-proof.json gives each exact body pin and the two
literal inverse edits. The actual Tensor/Storage read and getter order is retained:
raw -> grad_fn -> is_leaf -> retains_grad -> grad; then current nodes, Saved
getters and edge identity relations. The pointer strings are observed identities,
not cross-process addresses. Version integers are not claimed to be exposed
Version-counter identities.

Input and seed constructors use int32 raw words followed by actual dtype-view and
clone. The constructor records/asserts only the requested input bits. Logical
byte extraction reads actual Storage using actual shape/stride/offset; it
performs no Tensor numerical operation or expected-value emulation.

Only live holds persistent strong Tensor roots. Weak uses StorageWeakRef.
Snapshot Function, Tensor, Saved and AccumulateGrad.variable wrappers are local
and released. No observer callback is registered on autograd. Retain_grad is an
explicit tested operation. Held gradients are individually named public roots.
Case30 intentionally publishes the captured leaf only after backward; this
additional root is visible in the event log and dropped explicitly.

All accepted operations and all actual exceptions are captured with complete
before/after snapshots, warnings and error strings. Target refusals remain
observations; setup failures and probe failures are separate. Partial event
history is retained on an observer failure. Setup failures do not become native
failures and an OBSERVED result does not assert any schema closure.

Each snapshot contains whole Storage hex, logical hex/words, S/T identities,
dtype/width/device, strides/offset, Version, views, graph/Saved information, G and
a complete 5056-byte RNG state reference. The RNG table stores the full bytes.
The fixed support initializes the known environment; the probe's fork restores
the post-support RNG state. It does not claim restoration of a pre-support state
that it never captured.

## Explicit boundaries

This is one finite F32 CPU first-order reference group. It does not cover out
overloads, implicit promotion, multi-threading, another CPU ISA/backend, arbitrary
ranks/sizes, complete schema closure, higher-order derivatives, malformed wire,
allocation-failure injection or all signaling-NaN behavior. The malformed
dimension cases are ordinary calls on valid Tensors. Original older references,
the frozen SumDims source01 and all earlier failures are unchanged.

During source preparation an inherited environment-helper span initially duplicated
two environment/RNG reads. Before writing/freezing the probe, that duplicate was
removed; both draft and final AST-only receipts are preserved. The final source and
literal input contract were parsed again without importing or calling the probe.

