#!/usr/bin/env python3
"""Revision03 native32 comparison candidate, delivered SOURCE_ONLY_NOT_RUN.

Expected observations are exclusively the immutable actual Torch32 JSON.
Every original case and event remains present. Missing native observations
are BLOCKED and numeric/identity discrepancies are FAIL, never substituted.
The actual corrected source, ELF and emission must be separately bound.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import struct
import sys
import traceback

from admit_reference32 import (admit_reference, file_bytes, product, require,
                               sha, REFERENCE_SHA, CONTRACT_SHA)
from admit_build import admit_build

PARENT_CASE = "52c3b3242a73fb412102c83c5ba47cf8d95a4eb3c01e56f41bfe593066506d05"
PARENT_OBSERVER = "59019b5c4aeae0d7e04b362354bd9ca55917d2196791d3d18c4908a05fdbba8b"
PARENT_OWNER = "e54509ceba0ef3bf171f5fc1018665dc97e56eeccec0cba1e8c14f9a7ed81501"
PROTOCOL = "7a30d7bca140e3a4cc9d63a3e6930b92d2ffd60ad4503895419d8a63e67c8bd9"
CLIENT = "dee3e4cb25ee1e5e06513e2f33478fbe274d9510ce2aaab9525815c72312946b"
SOURCE_REVISION = "sum-source03"
ORIGINAL_SOURCE02_PACKAGE = "670ae1fbcb487a54d13a50570bb10bd86b0a19cb0e74dbcb7eec66122d4b9564"
ORIGINAL_PACKAGE = "9b3ff11fb8a4e2d08020049b892cc42f4717ac68c744cffce88d68f55cd07660"
U64_MAX = (1 << 64)-1

def write_json(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")

def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, Path(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def admit_package(root, expected_sha, inputs):
    raw, _ = file_bytes(root/"source-manifest.json", expected_sha, inputs)
    manifest = json.loads(raw)
    require(manifest["schema"] == "heptatorch.sum-dims-native32.source-only.v3"
            and manifest["status"] == "SOURCE_ONLY_NOT_RUN"
            and manifest["source_revision"] == SOURCE_REVISION
            and manifest["source_sha256"] == "be841bf3468b4ce6ce66daead602d540839dadb1f8ceca2fd3b5940ff2e6d545" and manifest["actual_child_binding"] == "PENDING",
            "native32-package-profile")
    files = manifest["files"]
    required = {"replay_sum32.py", "admit_reference32.py", "admit_build.py",
                "native_observer_sum02.py", "owner_sum47_48.py", "observer-inverse.json",
                "profile.json", "coverage-contract.json", "README.md",
                "actual-build-binding.json", "execution-request-placeholder.json",
                "vendor/replay_direct_view14.py", "vendor/native_observer_shape02.py",
                "vendor/owner_view05.py", "vendor/protocol.py", "vendor/owner_client.py",
                "revision01-source-manifest.json", "revision01-inverse.json",
                "revision02-source-manifest.json", "revision02-inverse.json",
                "publication-core-inverse.json", "case30-publication-proof.json",
                "publication-copied-controls.py"}
    require(set(files) == required and manifest["file_count"] == len(required),
            "exact-native32-payload-set")
    total = 0
    for relative, pin in files.items():
        parts = PurePosixPath(relative)
        require(not parts.is_absolute() and ".." not in parts.parts and parts.as_posix() == relative,
                "safe-native32-member")
        value, record = file_bytes(root/relative, pin["sha256"], inputs)
        require({k: record[k] for k in ("sha256", "bytes", "mode")} == pin,
                "native32-original-member-byte-mode", member=relative)
        total += len(value)
    require(total == manifest["payload_bytes"], "native32-full-payload-byte-count")
    # Validate source03 -> source02 for every original payload before applying
    # the unchanged original source02 -> source01 and parent-owner inverses.
    # This in-memory ancestry view is never executed or used as a current input;
    # the caller's inputs still contain only the actual source03 bytes/modes.
    parent2_raw = inputs[str((root/"revision02-source-manifest.json").resolve())]["raw"]
    require(sha(parent2_raw) == ORIGINAL_SOURCE02_PACKAGE, "frozen-complete-source02-manifest")
    parent2 = json.loads(parent2_raw)
    proof2 = json.loads(inputs[str((root/"revision02-inverse.json").resolve())]["raw"])
    require(set(proof2["files"]) == set(parent2["files"]) and len(parent2["files"]) == 18,
            "all-eighteen-source02-payloads-have-whole-byte-inverse")
    ancestral_inputs = {}
    for name, pin in parent2["files"].items():
        entry = proof2["files"][name]
        current = inputs[str((root/name).resolve())]["raw"]
        require(entry["before_sha256"] == pin["sha256"] and
                entry["after_sha256"] == sha(current), "source03-inverse-current-and-parent-pin", path=name)
        restored = current
        for change in reversed(entry["edits"]):
            before, after = change["before"].encode(), change["after"].encode()
            require(before and after and type(change["count"]) is int and change["count"] > 0
                    and restored.count(after) == change["count"], "source03-inverse-exact-occurrence", path=name)
            restored = restored.replace(after, before)
        require(len(restored) == pin["bytes"] and sha(restored) == pin["sha256"],
                "source03-whole-byte-inverse-exact-source02", path=name)
        forward = restored
        for change in entry["edits"]:
            before, after = change["before"].encode(), change["after"].encode()
            require(forward.count(before) == change["count"], "source03-forward-exact-occurrence", path=name)
            forward = forward.replace(before, after)
        require(forward == current, "source03-whole-byte-forward-exact", path=name)
        ancestral_inputs[str((root/name).resolve())] = {
            "raw":restored, "record":{"path":str((root/name).resolve()), **pin}}
    require(proof2["original_source02_manifest_sha256"] == ORIGINAL_SOURCE02_PACKAGE,
            "source03-complete-parent-custody-bound")
    inputs, files = ancestral_inputs, parent2["files"]
    for name, digest in (("replay_direct_view14.py", PARENT_CASE),
                         ("native_observer_shape02.py", PARENT_OBSERVER),
                         ("owner_view05.py", PARENT_OWNER),
                         ("protocol.py", PROTOCOL), ("owner_client.py", CLIENT)):
        require(files["vendor/"+name]["sha256"] == digest, "immutable-parent-helper", name=name)
    inverse = json.loads(inputs[str((root/"observer-inverse.json").resolve())]["raw"])
    for entry in inverse["whole_file_inverses"]:
        old = inputs[str((root/entry["original"]).resolve())]["raw"]
        new = inputs[str((root/entry["adapted"]).resolve())]["raw"]
        suffix = entry["additive_suffix"].encode()
        require(new.endswith(suffix), "explicit-additive-suffix", path=entry["adapted"])
        reconstructed = new[:-len(suffix)]
        for change in reversed(entry["replacements"]):
            before, after = change["before"].encode(), change["after"].encode()
            require(reconstructed.count(after) == change["occurrences"],
                    "inverse-replacement-occurrence", path=entry["adapted"])
            reconstructed = reconstructed.replace(after, before)
        require(reconstructed == old and sha(old) == entry["original_sha256"],
                "whole-original-byte-inverse", path=entry["adapted"])
    require(len(inverse["whole_file_inverses"]) == 2 and
            inverse["original_case_file_imported_unmodified"] == PARENT_CASE,
            "complete-two-observer-inverses")
    original_raw = inputs[str((root/"revision01-source-manifest.json").resolve())]["raw"]
    require(sha(original_raw) == ORIGINAL_PACKAGE, "frozen-source01-manifest")
    original = json.loads(original_raw)
    revision = json.loads(inputs[str((root/"revision01-inverse.json").resolve())]["raw"])
    require(set(revision["files"]) == set(original["files"])
            and len(revision["files"]) == 16, "whole-source01-revision-coverage")
    for old_name, proof in revision["files"].items():
        new_name = proof["new_path"]
        require(new_name in files, "revision02-real-file", path=new_name)
        actual = inputs[str((root/new_name).resolve())]["raw"]
        require(sha(actual) == proof["new_sha256"], "revision02-inverse-new-pin", path=new_name)
        restored = actual
        for edit in reversed(proof["edits"]):
            before, after = edit["before"].encode(), edit["after"].encode()
            require(restored.count(after) == edit["occurrences"],
                    "revision02-inverse-exact-occurrence", path=new_name)
            restored = restored.replace(after, before)
        require(sha(restored) == original["files"][old_name]["sha256"] == proof["old_sha256"]
                and len(restored) == original["files"][old_name]["bytes"],
                "revision02-whole-source01-byte-inverse", path=new_name)
    return manifest

def normalized_status(event):
    if event["accepted"]:
        return 0
    error = event["error"]
    kind, message = error["type"], error["message"]
    if kind == "RuntimeError" and re.fullmatch(r"dim [0-9]+ appears multiple times in the list of dims", message):
        return 7
    if kind == "IndexError" and message.startswith("Dimension out of range (expected to be in range of ["):
        return 2
    if kind == "RuntimeError" and message.startswith("Mismatch in shape: grad_output[0] has a shape of "):
        return 2
    if kind == "RuntimeError" and ("backward through the graph a second time" in message
                                    or "saved tensors have already been freed" in message):
        return 10
    if kind == "RuntimeError" and "modified by an inplace operation" in message and "version" in message:
        return 6
    raise UnsupportedObservation("unmapped-actual-exception", {"error": error})

class UnsupportedObservation(Exception):
    def __init__(self, reason, facts=None):
        self.reason, self.facts = reason, facts or {}
        super().__init__(reason)

def case_class(parent, owner):
    class SumCase(parent.Case):
        # The original class remains byte-identical in vendor. These methods
        # add new roles and inputs; inherited check/issue/compare_node/gradient/
        # snapshot/expired logic retains the original predicates.
        def __init__(self, args, observer, reference, row, spec, directory):
            self.spec, self.blockers, self.completed_events = spec, [], []
            self.active_event = None
            self.unmapped_observations = []
            self.seed_geometry_sources = []
            try:
                super().__init__(args, observer, reference, row, directory)
            except BaseException:
                if hasattr(self, "n"):
                    try:
                        self.n.finish()
                    except BaseException as cleanup_error:
                        write_json(directory/"constructor-cleanup-error.json",
                                   {"error": repr(cleanup_error)})
                raise

        def blocked(self, reason, **facts):
            item = {"path": self.current_path, "reason": reason, **facts}
            self.blockers.append(item)
            return item

        def tensor(self, expected, actual, label):
            super().tensor(expected, actual, label)
            if expected is not None and actual is not None:
                old = self.current_path
                self.current_path += "/"+label
                for name in ("device", "storage_offset_bytes", "storage_sha256", "logical_sha256"):
                    self.check(name, actual[name], expected[name])
                self.current_path = old

        def node_info(self, index, depth=4):
            if not index:
                return None
            memory = self.mem()
            node = memory.node(index)
            op = node[5]
            if op == 0:
                raw = self.n.s.owner()
                snapshot = owner.decode_owner(raw["bytes"], raw["pointer"])
                owner.verify_snapshot(snapshot)
                target = owner.accumulator_target(snapshot, index)
                actual = memory.tensor(target)
                self.check("Accumulator-real-target-incarnation",
                           actual["native_incarnation"],
                           snapshot["nodes"][str(target)][40], True)
                result = {"kind": "AccumulateGrad", "variable": actual}
                if depth:
                    result["next_edges"] = []
                return result
            kinds = {3: "MulBackward0", 17: "CloneBackward0",
                     43: "ToCopyBackward0", 44: "AsStridedBackward0",
                     47: "SumBackward1", 48: "PermuteBackward0"}
            if op not in kinds:
                raise UnsupportedObservation("native-history-kind-outside-revision02-mapping",
                                             {"node": index, "opcode": op})
            result = {"kind": kinds[op]}
            if depth:
                count = 2 if op == 3 else 1
                result["next_edges"] = [
                    {"output_nr": 0,
                     "node": self.node_info(node[6+i], depth-1) if node[9+i] else None}
                    for i in range(count)]
            return result

        def add_weak(self, name, token):
            # Execute Python's RHS StorageWeakRef creation before replacing the
            # existing name. Release the former Weak after the actual new42.
            fresh = self.n.one(42, token)["value"]
            previous = self.weak.get(name)
            if previous is not None:
                self.n.one(44, previous)
            self.weak[name] = fresh

        def saved_attributes(self, token, expected):
            memory = self.mem()
            index = memory.public_node(token)
            node = memory.node(index)
            if node[5] not in (47, 48):
                if node[5] not in (0, 3, 17, 43, 44):
                    raise UnsupportedObservation("unmapped-original-Saved-getter-role",
                                                 {"node": index, "opcode": node[5]})
                return super().saved_attributes(token, expected)
            raw = self.n.s.owner()
            snapshot = owner.decode_owner(raw["bytes"], raw["pointer"])
            owner.verify_snapshot(snapshot)
            if node[5] == 47:
                metadata = owner.sum_metadata(snapshot, index)
                values = {"_saved_dim": metadata["original_u64_axes"],
                          "_saved_keepdim": metadata["keepdim"],
                          "_saved_self_sym_sizes": metadata["sizes"]}
            else:
                metadata = owner.permute_metadata(snapshot, index)
                values = {"_saved_dims": metadata["original_u64_axes"]}
            self.check("shape-Saved-exact-attribute-set", list(expected), list(values))
            observed = {}
            for name, value in values.items():
                if name not in expected:
                    continue
                event = expected[name]
                self.check(name+"/accepted", event["accepted"], True)
                self.check(name+"/outcome", event["outcome"], "SUCCEEDED")
                self.check(name+"/error", event["error"], None)
                self.check(name+"/warnings", event["warnings"], [])
                self.check(name+"/exact-value", value, event.get("value"))
                observed[name] = {"accepted": True, "outcome": "SUCCEEDED",
                                  "error": None, "warnings": [], "value": value,
                                  "native_node_words_176_184": metadata["raw_words_176_184"]}
            return observed

        def snapshot(self, expected, label):
            before_count = len(self.snapshots)
            super().snapshot(expected, label)
            self.check("exact-one-snapshot-appended", len(self.snapshots), before_count+1, True)
            self.snapshots[-1]["unmapped_observation_blockers_so_far"] = len(self.blockers)
            # Base snapshot already compares raw geometry, complete words,
            # identities, graph edges, getter statuses, retains, G, weak and
            # full5056 RNG. Compare the otherwise silent capture error/warning
            # fields explicitly instead of inferring them from summary counts.
            for name in expected["tensor_getter_order"]:
                wanted = expected["tensors"][name]
                for field in ("grad_fn_getter", "is_leaf_after_grad_fn_getter", "retains_grad", "gradient"):
                    capture = wanted[field]
                    self.check(name+"/"+field+"/successful-error-none", capture["error"], None)
                    self.check(name+"/"+field+"/successful-outcome", capture["outcome"], "SUCCEEDED")
                    if field != "gradient":
                        self.check(name+"/"+field+"/no-warning", capture["warnings"], [])
                self.check(name+"/edge-getter-error", expected["edge_getters"][name]["error"], None)
            # Python's warning message is a retained frontend diagnostic; the
            # native wire has no text stream for warnings. Its actual condition
            # and count/type are compared by the original gradient method.

        def issue_one(self, command, label, partial=False):
            return self.issue(command, label, partial=partial)

        def make_tensor(self, shape, words):
            self.check("input-shape-rank", len(shape) <= 4, True, True)
            self.check("input-literal-word-count", len(words), product(shape), True)
            self.check("input-u32-values", all(type(x) is int and 0 <= x < (1 << 32) for x in words),
                       True, True)
            raw = struct.pack("<"+"I"*len(words), *words)
            return self.n.create(0, list(shape), raw, requires=0)

        def phase(self, index):
            self.check("phase-index-domain", 0 <= index < len(self.spec["seed_phases"]), True, True)
            return self.spec["seed_phases"][index]

        def seed_input(self, event, phase_index):
            phase = self.phase(phase_index)
            pattern = phase["pattern_u32"]
            if self.spec["seed_layout"] == "strided_singletons":
                geometry = self.spec["seed_geometry"]
                command = self.view(self.live["seed_backing"], geometry["shape"],
                                    geometry["stride"], geometry["storage_offset"])
                status, record = self.issue_one(command, event["label"])
                return status, record["value"] if status == 0 else None, [command], record
            # The original probe uses the *observed Torch result shape* solely
            # to construct a literal seed. Use that same pre-operation recorded
            # shape, not a shape calculated by a host sum or by the native result.
            recorded = event["before"]["tensors"]["result"]["before_grad_fn_getter"]
            shape = recorded["shape"]
            count = recorded["numel"]
            self.check("recorded-seed-shape-numel", product(shape), count, True)
            words = [pattern[i % len(pattern)] for i in range(count)]
            self.seed_geometry_sources.append({"event": self.active_event,
                "source": "original_actual_before.result.shape_only",
                "shape": shape, "numel": count, "literal_phase": phase_index,
                "no_reference_gradient_used_as_input": True})
            token = self.make_tensor(shape, words)
            return 0, token, [{"semantic": "typed97-literal-seed", "shape": shape, "u32": words}], None

        def event_plan(self, event):
            label, spec = event["label"], self.spec
            commands, token, publish, record, status = [], None, None, None, 0
            if label == "construct_backing":
                token = self.make_tensor(spec["backing_shape"], spec["backing_u32"])
                publish = "backing"
                commands = [{"semantic": "typed97-backing", "shape": spec["backing_shape"],
                             "u32": spec["backing_u32"]}]
            elif label in ("backing_requires_grad_true", "input_requires_grad_true"):
                name = "backing" if label.startswith("backing") else "input"
                command = (90, self.live[name], 1)
                status, record = self.issue_one(command, label)
                token, commands = self.live[name] if status == 0 else None, [command]
            elif label == "construct_permuted_middle":
                axes = spec["permutation"]
                payload = 0 if not axes else self.n.w.Payload(struct.pack("<"+"q"*len(axes), *axes))
                command = (116, self.live["backing"], len(axes), payload, 0, 0, 0, 0)
                status, record = self.issue_one(command, label)
                token, publish, commands = record["value"] if status == 0 else None, "middle", [command]
            elif label == "construct_preserve_clone_input":
                command = (18, self.live["middle"])
                status, record = self.issue_one(command, label)
                token, publish, commands = record["value"] if status == 0 else None, "input", [command]
            elif label == "construct_input_factor":
                token = self.make_tensor(spec["backing_shape"], spec["factor_u32"])
                publish = "input_factor"
                commands = [{"semantic": "typed97-literal-input-factor", "shape": spec["backing_shape"],
                             "u32": spec["factor_u32"]}]
            elif label in ("construct_nonleaf_mul_input", "construct_downstream_mul"):
                left, right, publish = (("backing", "input_factor", "input")
                    if label == "construct_nonleaf_mul_input" else ("result", "saved_factor", "downstream"))
                command = (2, 3, self.live[left], self.live[right])
                status, record = self.issue_one(command, label)
                token, commands = record["value"] if status == 0 else None, [command]
            elif label in ("construct_actual_expanded_view", "construct_detached_strided_input"):
                # The expanded view has no AD history because backing.requires
                # is false here. A true111 view reproduces its real T/S/base/V
                # without substituting any differentiable Expand edge.
                self.check("construction-backing-nonrequires",
                           self.raw_tensor(self.live["backing"])["requires_grad"], False, True)
                command = self.view(self.live["backing"], spec["input_shape"],
                                    spec["input_stride"], spec["input_storage_offset"])
                status, record = self.issue_one(command, label)
                commands = [command]
                token = record["value"] if status == 0 else None
                publish = "expanded" if label == "construct_actual_expanded_view" else "input"
                if label == "construct_detached_strided_input" and status == 0:
                    temporary = token
                    detach = (19, temporary)
                    status, record = self.issue_one(detach, label+"/detach")
                    commands.append(detach)
                    token = record["value"] if status == 0 else None
                    close = (41, temporary)
                    self.n.one(*close)
                    commands.append(close)
            elif label == "detach_expanded_input":
                command = (19, self.live["expanded"])
                status, record = self.issue_one(command, label)
                token, publish, commands = record["value"] if status == 0 else None, "input", [command]
            elif label == "sum_dim_IntList":
                axes = spec["dim"]
                count = U64_MAX if axes is None else len(axes)
                payload = 0 if not axes else self.n.w.Payload(struct.pack("<"+"q"*len(axes), *axes))
                dtype = U64_MAX if spec["dtype_argument"] is None else 0
                command = (115, self.live["input"], count, payload, int(spec["keepdim"]), dtype, 0, 0)
                status, record = self.issue_one(command, label)
                token, publish, commands = record["value"] if status == 0 else None, "result", [command]
            elif label.startswith("retain_grad_"):
                command = (93, self.live[label[len("retain_grad_"):]])
                status, record = self.issue_one(command, label)
                commands = [command]
            elif label.startswith("construct_seed_backing_phase_"):
                phase_index = int(label[len("construct_seed_backing_phase_"):])
                phase, geometry = self.phase(phase_index), spec["seed_geometry"]
                words = [phase["pattern_u32"][i % len(phase["pattern_u32"])]
                         for i in range(geometry["backing_elements"])]
                token = self.make_tensor([len(words)], words)
                publish = "seed_backing"
                commands = [{"semantic": "typed97-literal-seed-backing", "u32": words}]
            elif label.startswith("construct_seed_phase_"):
                phase_index = int(label[len("construct_seed_phase_"):])
                status, token, commands, record = self.seed_input(event, phase_index)
                publish = "seed"
            elif label == "construct_wrong_geometry_seed":
                shape = spec["wrong_seed_shape"]
                words = [0x3f800000]*product(shape)
                token = self.make_tensor(shape, words)
                publish = "wrong_seed"
                commands = [{"semantic": "typed97-literal-wrong-geometry-seed", "shape": shape, "u32": words}]
            elif label == "construct_downstream_factor":
                actual = event["before"]["tensors"]["result"]["before_grad_fn_getter"]
                words = [0x40000000]*actual["numel"]
                token = self.make_tensor(actual["shape"], words)
                publish = "saved_factor"
                commands = [{"semantic": "typed97-literal-downstream-factor",
                             "shape": actual["shape"], "u32": words}]
            elif label.startswith("hold_") and label.endswith("_gradient"):
                middle = label[len("hold_"):-len("_gradient")]
                names = [name for name in self.live if middle.endswith("_"+name)]
                self.check("unambiguous-held-gradient-parent", len(names), 1, True)
                name = names[0]
                prefix = middle[:-(len(name)+1)]
                command = (91, self.live[name])
                status, record = self.issue_one(command, label)
                token = record["value"] if status == 0 else None
                publish, commands = "held_"+prefix+"_"+name+"_grad", [command]
            elif label.startswith("clear_before_"):
                if label.startswith("clear_before_saved_error_"):
                    name = label[len("clear_before_saved_error_"):]
                else:
                    match = re.fullmatch(r"clear_before_phase_([0-9]+)_(.+)", label)
                    self.check("clear-phase-label", match is not None, True, True)
                    name = match.group(2)
                command = (92, self.live[name], 0)
                status, record = self.issue_one(command, label)
                commands = [command]
            elif label.startswith("backward_"):
                root, seed, retain = "result", "seed", False
                if label.startswith("backward_phase_"):
                    match = re.fullmatch(r"backward_phase_([0-9]+)_(.+)", label)
                    self.check("backward-phase-label", match is not None, True, True)
                    phase_index = int(match.group(1))
                    self.check("actual-phase-name", match.group(2), self.phase(phase_index)["name"], True)
                    retain = phase_index+1 < len(spec["seed_phases"])
                elif label == "backward_wrong_seed_geometry":
                    seed, retain = "wrong_seed", True
                elif label == "backward_valid_before_saved_construction":
                    retain = True
                elif label == "backward_after_saved_factor_mutation":
                    root = "downstream"
                elif label not in ("backward_after_public_input_drops", "backward_retry_after_default"):
                    raise UnsupportedObservation("unmapped-backward-label", {"label": label})
                command = (58, self.live[root], self.live[seed], int(retain))
                status, record = self.issue_one(command, label, partial=True)
                commands = [command]
            elif label in ("mutate_saved_factor_after_forward", "mutate_sum_input_value_before_backward",
                           "mutate_result_to_observe_version_and_alias"):
                name = {"mutate_saved_factor_after_forward": "saved_factor",
                        "mutate_sum_input_value_before_backward": "input",
                        "mutate_result_to_observe_version_and_alias": "result"}[label]
                command = (100, self.live[name], 0x42280000, 1)
                status, record = self.issue_one(command, label)
                token, commands = self.live[name] if status == 0 else None, [command]
            elif label == "publish_actual_captured_leaf_after_backward":
                # Issue the actual public getter. No owner-derived private token
                # is used as an input and no extra Tensor is kept alive.
                command = (117, self.live["result"], 0, 0, 0, 0, 0, 0)
                status, record = self.issue_one(command, label)
                token = record["value"] if status == 0 else None
                publish, commands = "recovered_input", [command]
            elif label.startswith("final_drop_") or label.startswith("drop_"):
                if label.startswith("final_drop_"):
                    name = label[len("final_drop_"):]
                elif label.startswith("drop_seed_before_phase_"):
                    name = "seed"
                elif label.startswith("drop_seed_backing_before_phase_"):
                    name = "seed_backing"
                else:
                    name = {"drop_backing_before_backward": "backing",
                            "drop_input_before_backward": "input",
                            "drop_result_before_recovered_input": "result",
                            "drop_recovered_input": "recovered_input"}.get(label)
                self.check("explicit-drop-existing-name", name in self.live, True, True)
                dropped = self.live[name]
                if sum(item == dropped for item in self.live.values()) == 1:
                    command = (41, dropped)
                    status, record = self.issue_one(command, label)
                    commands = [command]
                if status == 0:
                    del self.live[name]
            else:
                raise UnsupportedObservation("unmapped-frozen-event-label", {"label": label})
            return status, record, token, publish, commands

        def execute(self, event, event_index):
            self.active_event = event_index
            label = event["label"]
            self.snapshot(event["before"], "event%03d/%s/before" % (event_index, label))
            self.current_path = "event%03d/%s/operation" % (event_index, label)
            wanted = normalized_status(event)
            status, record, token, publish, commands = self.event_plan(event)
            self.check("normalized-operation-status", status, wanted)
            operation = {"label": label, "reference_event": event_index,
                         "normalized_actual_status": status, "normalized_reference_status": wanted,
                         "reference_error": event["error"], "reference_warnings": event["warnings"],
                         "native_diagnostic_text_available": False,
                         "commands": parent.safe(commands), "record": parent.safe(record)}
            self.check("operation-warning-list", event["warnings"], [])
            if (wanted == 0) != (status == 0):
                self.operations.append(operation)
                raise parent.RequiredOperationFailed(("native/reference acceptance mismatch", label, status, wanted))
            if status == 0:
                returned = event["returned"]
                if isinstance(returned, dict) and "tensor" in returned:
                    self.check("returned-Tensor-present", bool(token), True, True)
                    actual = self.raw_tensor(token)
                    self.tensor(returned["tensor"], actual, "returned_Tensor")
                    self.check("returned-is-existing",
                               {name: value == token for name, value in self.live.items()},
                               event["returned_is_existing"])
                    operation["returned_tensor"] = actual
                else:
                    self.check("returned-primitive", returned, None)
                if publish is not None:
                    self.check("published-name-currently-absent", publish not in self.live, True, True)
                    self.published(publish, token)
            self.operations.append(operation)
            self.snapshot(event["after"], "event%03d/%s/after" % (event_index, label))
            self.completed_events.append(event_index)

        def run(self):
            error = None
            terminal_block = None
            try:
                for i, event in enumerate(self.row["events"]):
                    if event["label"].startswith("final_drop_") and not getattr(self, "final_snap_done", False):
                        self.snapshot(self.row["before_final_drops"], "before_final_drops")
                        self.final_snap_done = True
                    self.execute(event, i)
                if not getattr(self, "final_snap_done", False):
                    self.snapshot(self.row["before_final_drops"], "before_final_drops")
                self.current_path = "final"
                self.check("all-public-names-dropped", self.live, {})
                self.check_expired(self.row["final_expired"])
                rng = self.n.one(63, self.gen)["payload"]
                expected_rng = bytes.fromhex(self.reference["states"][self.row["state_after"]]["hex"])
                self.check("final-complete5056MT", rng, expected_rng)
                self.rng_bytes += len(expected_rng)
                self.check("final-native-audit", self.n.one(53)["value"], 1)
                self.owner("final_before_observer_release")
                for token in self.weak.values():
                    self.n.one(44, token)
                self.n.one(66, self.gen)
            except UnsupportedObservation as unsupported:
                terminal_block = self.blocked(unsupported.reason, **unsupported.facts)
                try:
                    self.owner("unsupported_observation_original_owner")
                except BaseException as nested:
                    error = {"type": type(nested).__name__, "message": str(nested),
                             "at": self.current_path, "traceback": traceback.format_exc()}
            except BaseException as failure:
                error = {"type": type(failure).__name__, "message": str(failure),
                         "traceback": traceback.format_exc(), "at": self.current_path}
                try:
                    self.owner("first_failure")
                except BaseException as nested:
                    error["owner_capture_error"] = repr(nested)
            finally:
                try:
                    self.n.finish()
                except BaseException as failure:
                    if error is None:
                        error = {"type": "EOF_FAILURE", "message": repr(failure), "at": self.current_path}
                    else:
                        error["EOF_failure"] = repr(failure)
            missing = [i for i in range(len(self.row["events"])) if i not in self.completed_events]
            status = ("FAIL" if error is not None or self.failures else
                      "BLOCKED" if self.blockers or missing else "PASS")
            report = {"index": self.row["index"], "name": self.row["name"], "status": status,
                "assertions": self.checks, "exact_words": self.words,
                "full_rng_bytes": self.rng_bytes, "rollback_bytes": self.rollback_bytes,
                "frames": self.n.s.frames, "exit_code": self.n.s.exit_code,
                "error": error, "mismatches": self.failures, "blockers": self.blockers,
                "terminal_blocker": terminal_block, "operations": self.operations,
                "snapshots": self.snapshots, "owner_records": self.owner_records,
                "owner_blobs": self.owner_blobs,
                "complete_frame_owner_blobs": self.n.owner_blobs,
                "complete_frame_count": len(self.n.boundaries),
                "full_transition_recomputed": False,
                "reference_event_count": len(self.row["events"]),
                "completed_reference_events": self.completed_events,
                "unattempted_reference_events": [
                    {"index": i, "label": self.row["events"][i]["label"]} for i in missing],
                "seed_geometry_sources": self.seed_geometry_sources,
                "schema_closure": False, "full_project_status": "HOLD"}
            write_json(self.directory/"report.json", parent.safe(report))
            return report
    return SumCase

def unchanged_inputs(inputs):
    errors = []
    for name, entry in inputs.items():
        try:
            raw, record = file_bytes(name)
            require(record == entry["record"] and raw == entry["raw"], "input-byte-mode-final")
        except BaseException as error:
            errors.append({"path": name, "error": repr(error)})
    return errors

def main():
    require(not sys.flags.optimize, "assertions-must-remain-enabled")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--reference-source-root", type=Path, required=True)
    parser.add_argument("--native-binding", type=Path, required=True)
    parser.add_argument("--native-binding-sha256", required=True)
    parser.add_argument("--package-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare-only", action="store_true")
    mode.add_argument("--execute-native", action="store_true")
    args = parser.parse_args()
    root, output = Path(__file__).resolve().parent, args.output.resolve()
    require(output != root and not output.is_relative_to(root), "independent-new-output")
    output.mkdir(parents=True, exist_ok=False)
    inputs, reports = {}, []
    result = {"schema": "heptatorch.sum-dims-native32.comparison.v3",
        "status": "PREPARING", "case_count": 32, "reference_case_count": 32,
        "reference_sha256": REFERENCE_SHA, "case_contract_sha256": CONTRACT_SHA,
        "source_revision": SOURCE_REVISION, "source_sha256": None,
        "native_sha256": None, "functions": None, "units": None,
        "descriptor_bytes": 672, "state_format": "HTSUM003", "backing_format": "HTOSUM03",
        "native_executed": False, "Torch_executed": False, "compiler_executed": False,
        "schema_closure": False, "full_project_status": "HOLD",
        "cases": reports, "all_observations_supported": False,
        "all32_execution_index": [{"index": i, "status": "NOT_RUN"} for i in range(32)],
        "source01_semantic_gaps_preserved_as_history": [
            "original-Saved-dim-list", "true-permute-case26", "AccumulateGrad-variable-publication-case30"],
        "corrected_source03_outcome": "NOT_RUN"}
    exit_code = 1
    try:
        package = admit_package(root, args.package_sha256, inputs)
        reference, contract, ref_summary = admit_reference(
            args.reference, args.reference_source_root, inputs)
        binding, build, build_summary = admit_build(
            args.native_binding, args.native_binding_sha256, inputs)
        result.update(reference_admission=ref_summary, build_admission=build_summary,
                      source_sha256=binding["runtime"]["sha256"],
                      functions=build["functions"], blocks=build["blocks"], instructions=build["instructions"],
                      units=binding["profile"]["units"],
                      native_sha256=binding["binary"]["sha256"],
                      package_sha256=args.package_sha256,
                      actual_build_binding_sha256=args.native_binding_sha256)
        if args.prepare_only:
            result["status"] = "PREPARED_NOT_RUN"
            result["case_records"] = [
                {"index": spec["index"], "name": spec["name"], "status": "NOT_RUN",
                 "original_event_count": len(row["events"]), "filtered": False}
                for spec, row in zip(contract["cases"], reference["rows"])]
            exit_code = 0
        else:
            parent = load_module(root/"vendor"/"replay_direct_view14.py", "original_case52c3")
            owner = load_module(root/"owner_sum47_48.py", "strict_owner_sum47_48")
            observer = load_module(root/"native_observer_sum02.py", "native_observer_sum02")
            observer.configure(owner, binding["runtime"]["sha256"], binding["binary"]["sha256"], build["functions"])
            Case = case_class(parent, owner)
            run_args = argparse.Namespace(binary=Path(binding["binary"]["path"]),
                source=Path(binding["runtime"]["path"]), protocol=root/"vendor"/"protocol.py")
            result["native_executed"] = True
            for spec, row in zip(contract["cases"], reference["rows"]):
                # No --case/filter option exists. Even blocked/crashed records
                # retain a row for every original index.
                case_directory = output/("case-%02d" % spec["index"])
                try:
                    case = Case(run_args, observer, reference, row, spec, case_directory)
                    report = case.run()
                except BaseException as failure:
                    report = {"index": spec["index"], "name": spec["name"],
                        "status": "FAIL", "error": {"type": type(failure).__name__,
                        "message": str(failure), "traceback": traceback.format_exc()},
                        "reference_event_count": len(row["events"]),
                        "completed_reference_events": [],
                        "unattempted_reference_events": [
                            {"index": i, "label": event["label"]} for i, event in enumerate(row["events"])],
                        "schema_closure": False, "full_project_status": "HOLD"}
                    case_directory.mkdir(exist_ok=True)
                    if not (case_directory/"report.json").exists():
                        write_json(case_directory/"report.json", report)
                reports.append(report)
                result["all32_execution_index"][spec["index"]] = {
                    "index": spec["index"], "status": report["status"]}
            require(len(reports) == 32 and [r["index"] for r in reports] == list(range(32)),
                    "all-original32-case-records")
            result["passed"] = sum(r["status"] == "PASS" for r in reports)
            result["blocked"] = sum(r["status"] == "BLOCKED" for r in reports)
            result["failed"] = sum(r["status"] == "FAIL" for r in reports)
            result["original_event_count"] = sum(len(row["events"]) for row in reference["rows"])
            result["completed_reference_events"] = sum(len(r["completed_reference_events"]) for r in reports)
            require(result["original_event_count"] == 626 and
                    result["passed"] + result["blocked"] + result["failed"] == 32,
                    "complete32-and626-denominators")
            complete = result["passed"] == 32 and result["completed_reference_events"] == 626
            result["status"] = "FAIL" if result["failed"] else "BLOCKED" if not complete else "PASS"
            result["all_observations_supported"] = complete
            result["corrected_source03_outcome"] = result["status"]
            result["exact_Python_diagnostic_text_generated_by_native"] = False
            result["exception_scope"] = "Original text retained; actual wire cause, acceptance, prefix and rollback compared."
            exit_code = 0 if complete else 1
    except BaseException as failure:
        result.update(status="FAIL", error={"type": type(failure).__name__,
                      "message": str(failure), "traceback": traceback.format_exc()})
    finally:
        errors = unchanged_inputs(inputs)
        result["input_recheck_errors"] = errors
        result["all_inputs_unchanged"] = not errors
        result["checked_inputs"] = {name: value["record"] for name, value in inputs.items()}
        if errors:
            result["status"], exit_code = "FAIL", 1
        write_json(output/"report.json", result)
    return exit_code

if __name__ == "__main__":
    raise SystemExit(main())
