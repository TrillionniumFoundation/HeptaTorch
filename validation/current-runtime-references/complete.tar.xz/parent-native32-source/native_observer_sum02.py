"""Transport and read-only native-owned-byte observation; no Tensor evaluator."""
import hashlib
import importlib.util
from pathlib import Path
import re
import struct

PROTOCOL='7a30d7bca140e3a4cc9d63a3e6930b92d2ffd60ad4503895419d8a63e67c8bd9'
TAG=1<<63
BASE=139264
VIEW_BASE_FIELD=640
MASK=(1<<64)-1
sha=lambda b:hashlib.sha256(b).hexdigest()


def wire(path):
    assert sha(path.read_bytes())==PROTOCOL
    spec=importlib.util.spec_from_file_location('int64_test_transport',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


class ParentNative:
    def __init__(self,binary,source,protocol,output):
        self.w=wire(protocol);self.s=self.w.Session(binary.resolve(),directory=output/'raw')
        raw=source.read_bytes();self.observer_bodies={}
        for name in ('object_address','so_data_base','so_slot_at','dptr'):
            self.observer_bodies[name]=re.search(rb'^fn '+name.encode()+rb'\(.*?^end\n',raw,re.M|re.S).group()
        assert b'{"value":139264}' in self.observer_bodies['object_address'] and b'{"value":552}' in self.observer_bodies['so_data_base'] and b'{"value":672}' in self.observer_bodies['dptr']

    def one(self,*cmd):return self.s.run([cmd])[0]

    def create(self,dtype,shape,raw,requires=0):
        cfg=struct.pack('<8Q',len(shape),requires,*shape,*([0]*(4-len(shape))),160,len(raw))
        packet=b'HTORCH03'+struct.pack('<3Q',1,160+len(raw),0)+struct.pack('<8Q',97,dtype,96,0,0,0,0,0)+cfg+raw
        status,records=self.w.parse(self.s.exchange(packet));assert status==0 and len(records)==1,('create',status)
        return records[0]['value']

    def view(self,token,shape,strides,offset):
        cfg=struct.pack('<10Q',len(shape),*shape,*([0]*(4-len(shape))),*strides,*([0]*(4-len(shape))),offset)
        return self.one(69,token,self.w.Payload(cfg),80)['value']

    def memory(self):return Memory(self.s.owner()['bytes'])

    def tensor(self,token):
        meta=self.w.meta(self.one(13,token));dtype,width,inc,leaf=struct.unpack('<4Q',self.one(96,token,0)['payload'])
        logical=self.one(98,token,0,meta['numel'])['payload'];memory=self.memory();node=memory.public_node(token);observed=memory.tensor(node)
        assert observed['logical_bytes_hex']==logical.hex() and observed['native_incarnation']==inc and observed['native_storage_id']==meta['storage_id'] and observed['native_version_id']==meta['version_id']
        assert observed['element_size']==width and observed['is_leaf']==bool(leaf) and observed['version']==meta['version']
        assert observed['storage_offset_elements']*width==meta['storage_offset'] and observed['shape']==meta['shape'][:meta['rank']] and observed['strides']==meta['strides'][:meta['rank']]
        observed['native_public_token']=token
        return observed

    def finish(self):return self.s.finish()


class Memory:
    def __init__(self,raw):
        self.raw=raw;assert len(raw)>BASE+128
        assert raw[64:72] in (b'HTSUM003',) and raw[BASE:BASE+8] in (b'HTOSUM03',)
        self.slots=self.q(BASE+16);self.pool=self.q(BASE+24);self.start=BASE+144+552*self.slots
        assert self.start+self.pool==len(raw)

    def q(self,at):
        assert 0<=at<=len(self.raw)-8
        return struct.unpack_from('<Q',self.raw,at)[0]

    def row(self,kind,token):
        slot=token&0xffffff;assert token>>24&255==kind and 0<slot<=self.slots
        at=BASE+128+((kind-1)*self.slots+slot-1)*64;value=struct.unpack_from('<8Q',self.raw,at)
        assert value[0]==token>>32 and value[1]==1
        return value

    def public_node(self,token):
        row=self.row(1,token);node=row[6];d=self.node(node);assert d[24]==token and d[25]==1 and d[30]==1
        return node

    def node(self,index):
        assert 0<index<self.q(8)
        address=self.q(4096+(index>>8)*8);assert address&TAG
        at=self.start+(address&(TAG-1))+(index&255)*672
        assert at<=len(self.raw)-672
        return struct.unpack_from('<84Q',self.raw,at)

    def tensor(self,index):
        node=self.node(index);assert node[38]==1 and node[30]==1
        self.row(1,node[24]);storage=self.row(2,node[27]);version=self.row(3,node[28])
        assert storage[5]>0 and storage[7]==0
        rank,n=node[0],node[1];shape=list(node[12:12+rank]);strides=list(node[16:16+rank]);dtype=node[72];width={0:4,1:1,2:8,3:8}[dtype]
        assert node[29]%width==0;offset=node[29];physical_at=self.start+storage[2]
        assert physical_at<=len(self.raw) and storage[3]<=len(self.raw)-physical_at
        physical=self.raw[physical_at:physical_at+storage[3]];logical=bytearray()
        for i in range(n):
            remaining=i;address=offset
            for axis in range(rank-1,-1,-1):address+=(remaining%shape[axis])*strides[axis]*width;remaining//=shape[axis]
            assert address<=len(physical) and width<=len(physical)-address
            logical.extend(physical[address:address+width])
        root=None
        if node[83] != 0:
            rootnode=self.node(node[80]);assert rootnode[38] and rootnode[40]==node[81];root=rootnode[40]
        return {'dtype':{0:'torch.float32',1:'torch.bool',2:'torch.int64',3:'torch.float64'}[dtype],'element_size':width,
                'shape':shape,'strides':strides,'numel':n,'storage_bytes':storage[3],
                'storage_offset_elements':offset//width,'version':version[2],
                'requires_grad':bool(node[4]),'is_leaf':node[5]==0,'is_view':bool(node[51]),
                'grad_fn':None if node[5]==0 else 'NATIVE_HISTORY_PRESENT',
                'logical_bytes':len(logical),'logical_bytes_hex':logical.hex(),'storage_bytes_hex':physical.hex(),
                'native_node':index,'native_incarnation':node[40],'native_storage_id':node[27],
                'native_version_id':node[28],'native_base_incarnation':root}


# BEGIN ADDITIVE SUMDIMS REVISION02 OBSERVATION
import json
import lzma
import os
import signal
import time
import traceback

_OWNER = None

def configure(owner_module, source_sha256, actual_native_sha256, functions):
    global _OWNER
    assert _OWNER is None or _OWNER is owner_module
    owner_module.bind_profile(source_sha256, actual_native_sha256, functions)
    _OWNER = owner_module


_ParentMemory = Memory
class Memory(_ParentMemory):
    def tensor(self, index):
        row = super().tensor(index)
        logical = bytes.fromhex(row['logical_bytes_hex'])
        physical = bytes.fromhex(row['storage_bytes_hex'])
        return {**row, 'device': 'cpu',
                'storage_offset_bytes': row['storage_offset_elements'] * row['element_size'],
                'logical_sha256': sha(logical), 'storage_sha256': sha(physical)}


class Native(ParentNative):
    """Live byte transport. Every actual frame retains both complete owner endpoints."""
    def __init__(self, binary, source, protocol, output):
        assert _OWNER is not None, 'actual image binding required before child start'
        _OWNER.pin_profile(binary, source)
        self.owner_blobs, self.boundaries = {}, []
        self.observation_output, self.frame_journal = output, None
        try:
            super().__init__(binary, source, protocol, output)
            self.frame_journal = (output / 'owner-frames.jsonl').open('x')
            exchange_original = self.s.exchange

            def exchange(body):
                assert body[:8] == b'HTORCH03' and len(body) >= 32
                count, declared, reserved = struct.unpack_from('<3Q', body, 8)
                assert declared == len(body) and reserved == 0 and 32+64*count <= len(body)
                commands = [list(struct.unpack_from('<8Q', body, 32+64*i)) for i in range(count)]
                before, before_ref, before_raw = self.capture_owner('before')
                row = {'frame': self.s.frames+1, 'request_sha256': sha(body),
                       'request_bytes': len(body), 'commands': commands, 'before': before_ref}
                try:
                    raw = exchange_original(body)
                    row.update(frame=self.s.frames, response_sha256=sha(raw), response_bytes=len(raw))
                    after, after_ref, after_raw = self.capture_owner('after')
                    row['after'] = after_ref
                    status, records = self.w.parse(raw)
                    row.update(frame_status=status, record_count=len(records))
                    row['checks'] = _OWNER.verify_frame_boundary(
                        before, after, commands, status, records, body,
                        before_raw=before_raw, after_raw=after_raw)
                    return raw
                except BaseException as error:
                    row['observer_error'] = {'type': type(error).__name__, 'message': str(error),
                                             'traceback': traceback.format_exc()}
                    raise
                finally:
                    self.frame_journal.write(json.dumps(row, separators=(',', ':'), allow_nan=False)+'\n')
                    self.frame_journal.flush()
                    self.boundaries.append(row)

            self.s.exchange = exchange
        except BaseException:
            if hasattr(self, 's'):
                try:
                    self.finish()
                except BaseException:
                    pass
            raise

    def capture_owner(self, label):
        raw_owner = self.s.owner()
        digest = sha(raw_owner['bytes'])
        # Preserve raw bytes before decoding/checking. A first structural failure
        # must retain the actual offending owner, not just a traceback.
        if digest not in self.owner_blobs:
            folder = self.observation_output / 'complete-owner'
            folder.mkdir(exist_ok=True)
            path = folder / (digest+'.bin.xz')
            packed = lzma.compress(raw_owner['bytes'], format=lzma.FORMAT_XZ,
                                   check=lzma.CHECK_CRC64)
            decoder = lzma.LZMADecompressor(format=lzma.FORMAT_XZ)
            decoded = decoder.decompress(packed)
            assert decoder.eof and not decoder.unused_data and decoded == raw_owner['bytes']
            with path.open('xb') as stream:
                stream.write(packed)
            self.owner_blobs[digest] = {'path': str(path.relative_to(self.observation_output)),
                                       'bytes': len(raw_owner['bytes']), 'sha256': digest,
                                       'compressed_bytes': len(packed), 'compressed_sha256': sha(packed),
                                       'mode': path.stat().st_mode & 0o7777}
        reference = {'label': label, 'frame': self.s.frames, 'pointer': raw_owner['pointer'],
                     'length': raw_owner['length'], 'sha256': digest}
        try:
            snapshot = _OWNER.decode_owner(raw_owner['bytes'], raw_owner['pointer'])
            reference['verified_summary'] = _OWNER.verify_snapshot(snapshot)
            return snapshot, reference, raw_owner['bytes']
        except BaseException as error:
            reference['error'] = {'type': type(error).__name__, 'message': str(error),
                                  'traceback': traceback.format_exc()}
            with (self.observation_output/'owner-observation-failures.jsonl').open('a') as stream:
                stream.write(json.dumps(reference, allow_nan=False)+'\n')
            raise

    def finish(self):
        if getattr(self, '_finished', False):
            return
        self._finished = True
        session = self.s
        errors = []
        stderr = b''
        stdout = b''
        eof = {'stderr': False, 'output': False}
        forced = False
        try:
            session.close_input()
            deadline = time.monotonic() + 10
            while session.poll() is None:
                if time.monotonic() >= deadline:
                    raise TimeoutError('native EOF exit deadline')
                time.sleep(.001)
        except BaseException as error:
            errors.append({'stage': 'stdin-close-and-wait', 'error': repr(error)})
        finally:
            try:
                if session.poll() is None:
                    forced = True
                    try:
                        os.kill(session.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    pid, status = os.waitpid(session.pid, 0)
                    assert pid == session.pid
                    session.exit_code = os.waitstatus_to_exitcode(status)
            except BaseException as error:
                errors.append({'stage': 'kill-reap', 'error': repr(error)})
            # Drain both streams independently; do not set EOF merely because
            # the process ended, a read failed, or a descriptor was absent.
            for field, basename in (('stderr', 'stderr.bin'), ('output', 'extra-stdout-after-frames.bin')):
                chunks = []
                try:
                    fd = getattr(session, field)
                    assert fd is not None, ('missing-original-stream', field)
                    while True:
                        part = os.read(fd, 65536)
                        if not part:
                            eof[field] = True
                            break
                        chunks.append(part)
                except BaseException as error:
                    errors.append({'stage': 'drain-'+field, 'error': repr(error)})
                raw = b''.join(chunks)
                if field == 'stderr':
                    stderr = raw
                else:
                    stdout = raw
                try:
                    with (self.observation_output/'raw'/basename).open('xb') as stream:
                        stream.write(raw)
                except BaseException as error:
                    errors.append({'stage': 'save-'+field, 'error': repr(error)})
            for field in ('output', 'stderr', 'marker', 'ack', 'read_control'):
                try:
                    fd = getattr(session, field, None)
                    if fd is not None:
                        os.close(fd)
                        setattr(session, field, None)
                except BaseException as error:
                    errors.append({'stage': 'close-'+field, 'error': repr(error)})
            for name in ('requests', 'responses'):
                try:
                    stream = getattr(session, name, None)
                    if stream is not None and not stream.closed:
                        stream.close()
                except BaseException as error:
                    errors.append({'stage': 'close-'+name, 'error': repr(error)})
            if self.frame_journal is not None and not self.frame_journal.closed:
                self.frame_journal.close()
            transport = {'pid': session.pid, 'frames': session.frames,
                         'executable_sha256': session.binary_sha256,
                         'rows': session.rows, 'exit_code': session.exit_code,
                         'responses_before_stdin_eof': True,
                         'stdout_eof': eof['output'], 'stderr_eof': eof['stderr'],
                         'stderr_bytes': len(stderr), 'stderr_sha256': sha(stderr),
                         'extra_stdout_bytes': len(stdout), 'extra_stdout_sha256': sha(stdout),
                         'complete_owner_boundaries': len(self.boundaries),
                         'owner_blobs': self.owner_blobs,
                         'full_transition_recomputed': False,
                         'forced_cleanup': forced, 'cleanup_errors': errors}
            with (self.observation_output/'raw'/'transport.json').open('x') as stream:
                stream.write(json.dumps(transport, indent=2, allow_nan=False)+'\n')
        assert sha(session.executable.read_bytes()) == session.binary_sha256
        assert not errors and not forced, errors
        assert eof == {'stderr': True, 'output': True}
        assert session.exit_code == 0 and not stderr and not stdout, (
            session.exit_code, stderr, stdout)
# END ADDITIVE SUMDIMS REVISION02 OBSERVATION
