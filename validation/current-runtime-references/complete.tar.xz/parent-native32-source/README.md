# SumDims native32 revision03

Status: **SOURCE_ONLY_NOT_RUN**. This package has not been parsed, imported,
prepared or executed by its author. The whole project remains **HOLD**.
The original source02 directory and failing reports remain immutable.

## Exact scope and source lineage

All 32 cases and all 626 original events use the unchanged immutable actual
Torch32 JSON c14e4b18f657429ad5dac5498c3abcae303b6a7e7550db7d15a3c9179bdcd728.
The complete 27,544-byte `case_class` is byte-identical to source02, SHA
191bdc7d1f69679912345ddca8efcf4e06bc1f29659ec7d65c1b349a17b68a54.
There are no case filters, tolerances, altered expected words, extra native
queries, or host Tensor arithmetic. The reference admission and the five
original vendor helpers remain byte-identical. All original 84Q snapshot
invariants and nonzero frame-header rollback rules remain present.
Command58 runtime errors are success-frame payloads and retain the original
partial-prefix comparisons; they are not converted to atomic header errors.

The actual root-emitted source is
be841bf3468b4ce6ce66daead602d540839dadb1f8ceca2fd3b5940ff2e6d545:
696 functions, 9,216 blocks, 32,990 instructions and 14 emitted units,
HTSUM003/HTOSUM03 with 672-byte descriptors. The actual emission manifest is
c545a70923207f90cb9cce9054c4fa8f5ade9d960a71cc7f45c8d1a763b759fa,
30 members / 5,523,330 bytes. The fixed compiler04 driver is c90344da… and
must produce native-build.v4/source_revision04. The included template deliberately leaves the final ELF and build report
PENDING; a separately frozen binding records the actual root build. An external, separately frozen
actual binding is mandatory before prepare or native execution. The template
cannot be passed as an admitted build.

`admit_build.py` rechecks every actual emitted/source/object/stream member,
14 fresh compiler processes plus the link process, and both whole-runtime
inverse chains: source03 → source02 → source01. It also checks every original
658 parent body, including 647 unchanged / 11 modified and all 38 additions.
The complete author package and 30-member emission are pinned separately.
The source03 arithmetic change is verified as two call targets and four tags;
no previous native PASS is transferred.

## Precise command117 correction

The original source02 run had 21 PASS / 11 FAIL and stopped case30 at its ninth
completed event. Its original failure is preserved. Root's pure endpoint
diagnostic ce36926c… checked 5,047 conditions against the complete 699,024-byte
before/after owners. Only three bytes changed: one Trow-generation byte and
two target-descriptor publication bytes. All Tensor Storage and complete RNG
bytes were unchanged. The descriptor page itself is a private Hold Storage,
so the original blanket Hold-hash comparison incorrectly rejected publication.

The new predicate retains every original target/incarnation/84Q/Trow/table
check. It then requires the original full raw endpoints, binds both hashes,
resolves the actual descriptor-page Hold, reverses only target words192/200
and the already-proven publication Trow fields, and compares the entire
172,032-byte page and entire owner. No descriptor page is excluded.
Every other Hold, Tensor Storage and all RNG bytes remain exact. Missing raw
bytes, wrong identity, extra mutations or stale-view refresh remain refusals.

`capture_owner` returns `(snapshot, reference, raw_bytes)`; these are the same
bytes already archived as complete-owner XZ files. `Native.exchange` passes
them to `verify_frame_boundary(..., before_raw=..., after_raw=...)`.
There is no extra native observation. RecordedTransport must supply the same
actual archived raw endpoints; reconstructed or summary-only owners are not
admissible.

`publication-copied-controls.py` is a source-only candidate for one positive
original publication and eight copied refusals. It decodes original source02
bytes with the original source02 decoder, then evaluates only the new pure
publication predicate. It never labels old bytes HTSUM003 or claims a new
native execution. Its runtime result is NOT_RUN until root executes it.

## Future exact commands (root execution only)

After freezing this manifest, pure publication controls:

```sh
/usr/bin/python3 -B /home/qian-qi/heptatorch-continuation-20261116/runs/sum-dims-native32-source-03/publication-copied-controls.py --package-sha256 <THIS_MANIFEST_SHA> --output <NEW_PURE_CONTROL_OUTPUT>
```

After the actual compiler04 result is independently bound:

```sh
/usr/bin/python3 -B /home/qian-qi/heptatorch-continuation-20261116/runs/sum-dims-native32-source-03/replay_sum32.py --reference /home/qian-qi/heptatorch-continuation-20261116/runs/sum-dims-f32-reference32-actual-01/actual.json --reference-source-root /home/qian-qi/heptatorch-continuation-20261116/runs/sum-dims-f32-reference32-source-01 --native-binding <ACTUAL_SOURCE03_BINDING_JSON> --native-binding-sha256 <ACTUAL_BINDING_SHA> --package-sha256 <THIS_MANIFEST_SHA> --output <NEW_OUTPUT> --prepare-only
```

Only an independently scheduled actual request replaces `--prepare-only`
with `--execute-native`. No process request is submitted by this package.
The original 76-case suite must separately run on the same new image; its
old result does not qualify this build.

## Reversible source custody

`revision02-source-manifest.json` is the exact original670ae source manifest.
`revision02-inverse.json` reverses all18 original payloads, including metadata;
unchanged files have an empty edit list. All old source02→source01 and parent
observer inverses are preserved verbatim and checked after restoring the
ancestral bytes in memory. Those ancestral bytes are never executed as current
source, and current checked-input records retain actual source03 bytes/modes.
The field-level core inverse and original diagnostic pins are separate files.

Current delivery modes are individually pinned as0660. Original0600/0660
modes are recorded separately in the explicit original-to-delivery mapping. No Git mode
normalization or installation is performed here.

# Historical source02 README — exact original text follows

# SumDims native32 comparison candidate, revision02

Status: **SOURCE_ONLY_NOT_RUN**. No Python import, AST parse, prepare process,
emitter, compiler, native executable or Torch operation was executed while
preparing this candidate. The whole project remains **HOLD**; no schema closure
is claimed.

The source01 package remains immutable at:
/home/qian-qi/heptatorch-continuation-20261116/runs/sum-dims-native32-source-01
Its original manifest is included verbatim. Its original source b222c7a588225933ccb0ea03f8adae97c94ec737c498dce75cd12ab6d7678de9
and ELF cb72c18bed65d0c92c888881185b8a22df91307c2b0c497294d76833a044d667
are not admissible as the corrected source02 child.

## What this candidate compares

All 32 original cases and all 626 actual Torch events remain in order. There is
no case selector or filter. The exact original actual JSON is
c14e4b18f657429ad5dac5498c3abcae303b6a7e7550db7d15a3c9179bdcd728,
39,045,926 bytes. The immutable case contract is
85e5e639e04ff63fc219fc63e716642a1564c205976156006b7fccd9f22a0c92.
Neither file is regenerated or edited.

The original source/provenance admission module is byte-identical to revision01.
It checks all frozen source inputs, wheel/support/lock/pip provenance, the actual
one-thread AVX512 configuration, complete original observation shapes and all
logical/physical words. Native input words come only from the literal input
contract; seed geometry follows the original probe's observed result shape.
There is no host Tensor, sum, gradient or floating-point arithmetic model.
Integer address decoding only reads the actual owner bytes.

The unchanged 52c3 Case supplies all inherited comparison predicates. Exact
logical and complete Storage bytes, F32 words, offsets, sizes, strides, Tensor
identity/Storage relations, every actual Version value, retained gradients,
graph edges, Saved access, Weak expiry and all 5,056 RNG bytes are compared.
Each request/response and both complete owner endpoints are retained. Header
errors require complete pointer/length/byte rollback. Backward partial results
retain their native status/counters and compare the actual before/after gradient
prefix; counters are not presented as Torch observations.

Original Python errors and warnings remain intact in the evidence. The HIA
protocol emits numeric causes, not Python exception prose. The finite comparison
therefore checks actual acceptance, normalized cause, warning conditions/counts,
state effects and rollback; it does not claim native generation of Python text.

## Corrected roles, without substitutions

- Command115 is the real dim-list Sum, AD47. Native176/184 carries input sizes,
  canonical mask, keepdim, implicit-all and original optional axis spelling.
  Count5 means None and count0 means an empty list. Signed bytes are decoded to
  Python arbitrary-precision integers and exposed as the actual raw uint64
  spelling. Thus None, [], input ordering and negative axes remain distinct.
- Command116 is real permute, AD48. It accepts the original signed64 permutation
  payload. No transpose chain or AsStrided operation substitutes for it. The
  observer checks normalized and original axes, the immediate captured edge,
  actual size/stride permutation, and shared Storage/Version/byte offset.
- Command117 executes the actual AccumulateGrad.variable getter. The observer
  resolves the pre-existing enabled immediate AccumulateGrad edge and its
  actual strong Tensor target. It verifies that publication changes only the
  real Trow generation/public token and Tensor public flag, preserves all
  other 84 node words, retains the same incarnation/S/V/extent/retained state,
  and introduces no extra node, Storage, Version or strong ownership root.
  The comparison does not keep an extra public input alive to satisfy case30.

The 48 offset check uses real word232. The frozen history_snapshot copies that
word but does not copy legacy word64. Both captured history and a Tensor whose
Trow was released may be rowless; their metadata is not an extra Storage owner.
For a live48 Tensor, the original 640/648/656/664 ViewInfo rules are required.
When its real Trow is released, that base root must disappear. The original
600/208 ownership equations, full graph closure, retained/captured roles,
Saved pairs, Storage/Version, Weak generations, free extents and all transient
checks remain unchanged.

The original generic isolated-transition checker still refuses unsupported
ViewInfo transitions. This candidate reports full_transition_recomputed=false.
It adds exact publication and metadata endpoint checks, not a claim that an
arbitrary allocation ledger was replayed.

## Two independent exact inverse proofs

observer-inverse.json reconstructs the entire original e545 84Q owner and 59019
raw observer, byte for byte. Only identity literals, names that allow wrappers,
and the explicit additive suffix are adapted. No old predicate is projected
out, skipped or weakened.

revision01-inverse.json covers every one of the 16 original revision01 payloads.
Applying each recorded replacement in reverse reconstructs that file's exact
SHA and byte length from the included original manifest. The original reference
admission and all five vendor files stay byte-identical.

These are source preparation string/byte proofs, not Python execution results.
Any actual source check or native run must write its own new report.

## Actual child binding is deliberately pending

The bundled actual-build-binding.json is a non-executable PENDING template.
Root has now reported the first actual source02 emission, job3f6b:
source6b461ac615c10478f8d37c32f7d1ac30e902e54fb1ca08b42d7c48e74c11aae0,
696 functions, 9,216 blocks, 32,990 instructions and **14 actual units**. These
counts are distinct from the earlier source01 plan of13. They are pinned for
the future byte check. The ELF, final emitted-member manifest and build process
receipts remain PENDING; this packet has not executed or independently admitted
that emission. A future actual binding supplies every complete original file.

The separate final binding must name its exact full SHA on the CLI. Before
starting any child, admit_build.py requires:

1. All nine actual authors and the complete frozen source package, including
   modes, plus all original emitted members and their exact generated bytes.
2. Whole parent c436, complete source-map parent annotations, unchanged648,
   all10 parent changes, original alias/literal inverses and the complete
   generated fragment, not only reported counts.
3. The complete original source01 emission25 members, modes and bytes, plus
   source01-to02-body-inverse.json. The actual674 unchanged,13 modified and9
   added bodies must reconstruct the entire b222 runtime in its original order.
4. All14 actual fresh unit sources and ELF objects, exact link order/request,
   and all15 compiler/link process records, original stdin identities, both
   full output streams, return codes and EOF. A restored image cannot satisfy
   the fresh-build predicate. The new emission has29 members including its inverse.
5. HTSUM002/HTOSUM02, descriptor672, commands115/116/117 and AD47/48.
6. All before/after bound input bytes and modes unchanged.

If the actual successor emitter/build schema differs from this explicit
candidate contract, the pre-child gate refuses it. Such a schema change needs
a separately recorded reader revision; it cannot be silently accepted.

## Future invocation only

The complete argument template is execution-request-placeholder.json.
A later scheduled invocation uses:

/usr/bin/python3 -B replay_sum32.py --reference <original_actual.json> --reference-source-root <frozen_reference_source01> --native-binding <separately_frozen_actual_source02_binding.json> --native-binding-sha256 <binding_sha> --package-sha256 <this_manifest_sha> --output <new_output> --prepare-only

After an actual child is available and reviewed, --execute-native replaces
--prepare-only. A dedicated child is used for each case. Exit0 qualification
requires all32 PASS, all626 events completed, complete EOF, no unmatched
observation and unchanged bound inputs. A genuine unsupported observation is
BLOCKED with its original event retained; any mismatch is FAIL. There are no
tolerances, NaN canonicalization, missing-case exclusions or expectation edits.

No process request, idempotency key or job has been submitted by this packet.
