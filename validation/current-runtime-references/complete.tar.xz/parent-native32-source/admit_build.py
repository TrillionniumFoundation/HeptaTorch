"""Pure byte and original-process custody admission for a future SumDims build.

No emission, compilation, linking, executable loading or Torch import occurs here.
The binary hash is supplied by a separately frozen actual-build binding; absence
of that binding is a hard pre-child refusal.
"""
import json
from pathlib import Path
import re
import struct
from admit_reference32 import file_bytes, require, sha

SOURCE_REVISION = "sum-source03"
PARENT = "c436e21c45355891f8423f174a47e7c40fc8e1d6aef9a112043fac8787255d7a"
AUTHOR_MANIFEST = "febcfeb843ac3e2b72298e60d4cdb5d99d383bccd9024e3829451c6a55e6f588"
PRIOR_MANIFEST = "9bdab384fa4bb07d5d4d38a83bcf09183ce346b3411f94049016f6f5ec8e76d8"
PRIOR_SOURCE = "b222c7a588225933ccb0ea03f8adae97c94ec737c498dce75cd12ab6d7678de9"
PRIOR_REPORT = "f2c937417aca3c9043b44c44b9737ab18ced176276d11060413e13bb966e2e4a"
HEADER = b"hia-asm.v1 hepta.hia.program.v8 sum_dims_runtime\n"
ACTUAL_EMITTED_SOURCE03 = "be841bf3468b4ce6ce66daead602d540839dadb1f8ceca2fd3b5940ff2e6d545"
SOURCE02 = "6b461ac615c10478f8d37c32f7d1ac30e902e54fb1ca08b42d7c48e74c11aae0"
SOURCE02_MANIFEST = "fd26e9634a918b06a92ec437a701ec6594f068397b870cc1e43a4ec4bb34a6be"
SOURCE02_REPORT = "f3900be686df1ee6ece31736a1259f8bc997ae7c4708c1155eb78554f99a41d3"
SOURCE01_INVERSE = "09446f7748f9910695b9600afd08906708c3c83c40b2dcd8820840f8102a6d57"
ACTUAL_EMITTED_COUNTS = {"functions": 696, "blocks": 9216, "instructions": 32990, "units": 14}
FUNCTIONS = re.compile(rb"^(fn ([A-Za-z_][A-Za-z_0-9]*)\([^\n]* entry\([A-Za-z_][A-Za-z_0-9]*\)\n.*?^end\n)", re.M | re.S)

def split_functions(raw):
    matches = FUNCTIONS.findall(raw)
    result = {name.decode(): body for body, name in matches}
    require(len(matches) == len(result) and result, "unique-nonempty-HIA-function-set")
    return result

def admit_build(binding_path, binding_sha256, inputs):
    require(re.fullmatch("[0-9a-f]{64}", binding_sha256) is not None, "actual-binding-SHA-required")
    binding_raw, _ = file_bytes(binding_path, binding_sha256, inputs)
    binding = json.loads(binding_raw)
    require(binding["schema"] == "heptatorch.sum-dims-native32.actual-build-binding.v3"
            and binding["status"] == "ACTUAL_BUILD_BOUND"
            and binding["source_revision"] == SOURCE_REVISION,
            "placeholder-cannot-execute")
    required_files = {"build_report", "runtime", "binary", "emission_manifest",
                      "emission_report", "driver", "author_manifest", "parent_runtime"}
    required = {"schema", "status", "source_revision", "profile", "author_inputs"} | required_files
    require(set(binding) == required, "exact-actual-binding-fields")
    contents = {}
    for name in sorted(required_files):
        pin = binding[name]
        require(set(pin) == {"path", "sha256", "bytes", "mode"}, "actual-binding-file-fields", name=name)
        require(re.fullmatch("[0-9a-f]{64}", pin["sha256"]) is not None,
                "actual-full-pin-required", name=name)
        raw, record = file_bytes(pin["path"], pin["sha256"], inputs)
        require(record == pin, "actual-binding-full-byte-mode", name=name)
        contents[name] = raw
    profile = binding["profile"]
    fixed_profile = {"state_format": "HTSUM003", "backing_format": "HTOSUM03",
                     "descriptor_bytes": 672,
                     "native_basename": "tensor-sum-dims-session",
                     "public_commands": [115, 116, 117], "autograd_operations": [47, 48]}
    require(set(profile) == set(fixed_profile) | {"functions", "blocks", "instructions", "units",
                "build_schema", "driver_revision"}, "actual-profile-field-set")
    for key, value in fixed_profile.items():
        require(profile[key] == value and type(profile[key]) is type(value),
                "actual-corrected-profile", field=key)
    require(all(type(profile[key]) is int and profile[key] > 0
                for key in ("functions", "blocks", "instructions", "units"))
            and profile["functions"] == 696 and 3 <= profile["units"] <= 256,
            "actual-source02-counts-must-be-bound")
    require(all(profile[key] == value for key, value in ACTUAL_EMITTED_COUNTS.items()),
            "actual-source02-emission-counts-696-and14-not-old13")
    unit_count = profile["units"]
    require(profile["build_schema"] == "heptatorch.sum-dims-f32.native-build.v4"
            and profile["driver_revision"] == "04",
            "actual-build-report-schema")
    SOURCE = binding["runtime"]["sha256"]
    require(SOURCE == ACTUAL_EMITTED_SOURCE03, "actual-corrected-source02-whole-source-pin")
    DRIVER = binding["driver"]["sha256"]
    require(DRIVER == "c90344da0547fba9cfeee04262d961a7d3dd10763195ab1b705572174dcec269",
            "fixed-reviewed-cold-driver04-whole-source")
    EMISSION_MANIFEST = binding["emission_manifest"]["sha256"]
    require(EMISSION_MANIFEST == "c545a70923207f90cb9cce9054c4fa8f5ade9d960a71cc7f45c8d1a763b759fa",
            "actual-source03-sealed-thirty-member-emission-manifest")
    EMISSION_REPORT = binding["emission_report"]["sha256"]
    require(SOURCE != "b222c7a588225933ccb0ea03f8adae97c94ec737c498dce75cd12ab6d7678de9"
            and binding["binary"]["sha256"] != "cb72c18bed65d0c92c888881185b8a22df91307c2b0c497294d76833a044d667",
            "source01-is-not-corrected-source02")
    require(SOURCE != SOURCE02 and binding["binary"]["sha256"] !=
            "50290e0237329466e691fef6862e92c253b0711fe1cb95e1930faa6a0750ff9c",
            "source02-image-cannot-substitute-new-source03")
    require(sha(contents["parent_runtime"]) == PARENT, "fixed658-parent-whole-source")
    parent_bodies = split_functions(contents["parent_runtime"])
    require(len(parent_bodies) == 658, "complete-frozen-parent-function-count")
    authors = binding["author_inputs"]
    required_authors = {"authoring_support.py", "parent_emitter.py", "emit_source.py",
                        "sum_dims_overlay.py", "sum_dims_geometry.py", "sum_dims_kernel.py",
                        "sum_dims_runtime.py", "sum_dims_views.py", "prior_emission.py"}
    require(isinstance(authors, dict) and set(authors) == required_authors,
            "complete-source02-author-input-set")
    author_manifest = json.loads(contents["author_manifest"])
    require(author_manifest["schema"] == "heptatorch.sum-dims-f32.source-handoff.v3"
            and sha(contents["author_manifest"]) == AUTHOR_MANIFEST
            and author_manifest["status"] == "SOURCE_ONLY_NOT_EXECUTED"
            and author_manifest["source_revision"] == "source03"
            and isinstance(author_manifest["files"], dict)
            and author_manifest["payload_count"] == len(author_manifest["files"]) == 22
            and author_manifest["payload_bytes"] == 476626
            and sum(pin["bytes"] for pin in author_manifest["files"].values()) == 476626
            and author_manifest["author_file_count"] == len(author_manifest["author_files"]) == 9
            and set(author_manifest["author_files"]) == required_authors
            and required_authors <= set(author_manifest["files"]),
            "frozen-source02-complete-author-package")
    author_root = Path(binding["author_manifest"]["path"]).resolve().parent
    for relative, pin in author_manifest["files"].items():
        rel = Path(relative)
        require(not rel.is_absolute() and ".." not in rel.parts and rel.as_posix() == relative,
                "source02-package-safe-member", member=relative)
        require(set(pin) == {"sha256", "bytes", "mode"}, "source02-package-pin-fields")
        raw, record = file_bytes(author_root/relative, pin["sha256"], inputs)
        require({key: record[key] for key in pin} == pin,
                "all-source02-package-original-byte-mode", member=relative)
    for name, pin in authors.items():
        require(set(pin) == {"path", "sha256", "bytes", "mode"}, "exact-author-pin-fields")
        raw, record = file_bytes(pin["path"], pin["sha256"], inputs)
        require(record == pin and Path(pin["path"]).resolve() == author_root/name
                and {key: pin[key] for key in ("sha256", "bytes", "mode")} == author_manifest["files"][name],
                "original-source02-author-bytes", name=name)
    runtime, image = contents["runtime"], contents["binary"]
    require(sha(runtime) == SOURCE and image.startswith(b"\x7fELF"), "actual-child-source-ELF")
    require(sha(contents["emission_manifest"]) == EMISSION_MANIFEST, "fixed-actual-emission-manifest")
    emission = json.loads(contents["emission_manifest"])
    require(emission["status"] == "ACTUAL_EMISSION_SEALED"
            and emission["schema"] == "heptatorch.sum-dims-f32.actual-emission-members.v1"
            and emission["source_sha256"] == SOURCE
            and emission["file_count"] == len(emission["files"])
            and emission["emission_report_sha256"] == EMISSION_REPORT
            and emission["parent_source_sha256"] == PARENT,
            "complete-actual-emission")
    names = ["rng03"]+["sum_dims_%02d" % i for i in range(unit_count-2)]+["owners"]
    required_emission = required_authors | {name+".hepta" for name in names} | {
        "runtime.hepta", "source-map.json", "sum-dims-source-custody.json",
        "sum-dims-fragment.hepta", "report.json", "source01-to02-body-inverse.json",
        "source02-to03-body-inverse.json"}
    require(set(emission["files"]) == required_emission,
            "complete-source02-emission-member-set")
    require(emission["files"]["runtime.hepta"]["sha256"] == SOURCE
            and emission["files"]["report.json"]["sha256"] == EMISSION_REPORT
            and all(emission["files"][name]["sha256"] == pin["sha256"]
                    for name, pin in authors.items()),
            "emission-runtime-report-and-authors-bound")
    require(sum(x["bytes"] for x in emission["files"].values()) == emission["payload_bytes"],
            "emission-byte-count")
    for relative, pin in emission["files"].items():
        require(Path(relative).name == relative, "emission-relative-member")
        raw, record = file_bytes(Path(emission["emission_directory"])/relative, pin["sha256"], inputs)
        require({k: record[k] for k in ("sha256", "bytes", "mode")} == pin,
                "original-emitted-byte-mode", path=relative)
    build = json.loads(contents["build_report"])
    directory = Path(binding["build_report"]["path"]).resolve().parent
    expected = {
        "schema": profile["build_schema"],
        "source_revision": profile["driver_revision"], "status": "PASS_NATIVE_BUILD_ONLY",
        "source_sha256": SOURCE, "native_sha256": sha(image), "native_bytes": len(image),
        "native_basename": profile["native_basename"], "functions": profile["functions"],
        "blocks": profile["blocks"], "instructions": profile["instructions"], "descriptor_bytes": 672,
        "state_format": "HTSUM003", "backing_format": "HTOSUM03",
        "units_planned": unit_count, "units_compiled": unit_count, "objects_reused": False,
        "result_executable_executed": False, "torch_executed": False,
        "runtime_qualified": False, "schema_closure": False, "full_project_status": "HOLD",
        "all_inputs_unchanged": True, "link_exit": 0, "link_stderr_bytes": 0,
        "emission_manifest_sha256": EMISSION_MANIFEST, "emission_report_sha256": EMISSION_REPORT,
        "parent_source_sha256": PARENT}
    for name, value in expected.items():
        require(build[name] == value and type(build[name]) is type(value),
                "actual-build-fixed-field", name=name)
    require(Path(binding["binary"]["path"]).resolve() == directory/"tensor-sum-dims-session"
            and Path(binding["runtime"]["path"]).resolve() == directory/"runtime.hepta",
            "actual-build-local-products")
    require(binding["binary"]["mode"] == 0o500, "actual-result-mode")
    declared = build["checked_inputs"]
    require(isinstance(declared, dict) and declared, "nonempty-build-input-custody")
    for path, pin in declared.items():
        require(set(pin) == {"sha256", "bytes", "mode"}, "build-input-fields", path=path)
        _, record = file_bytes(path, pin["sha256"], inputs)
        require({k: record[k] for k in pin} == pin, "build-input-byte-mode", path=path)
    required_hashes = {DRIVER, PARENT, AUTHOR_MANIFEST, EMISSION_MANIFEST, build["compiler_sha256"],
                       build["linker_sha256"]} | {p["sha256"] for p in emission["files"].values()}
    require(required_hashes <= {p["sha256"] for p in declared.values()}, "build-required-input-custody")
    require(build["emission_member_count"] == len(required_emission)
            and build["emission_member_inventory"] == emission["files"],
            "build-complete-emission-member-set")
    driver, _ = file_bytes(directory/"build-driver.py", DRIVER, inputs)
    # Tool hashes are read as fixed literal declarations from this exact admitted
    # driver; no compiler Python module is imported and its main is never called.
    pins = {}
    for name in ("COMPILER", "LINKER"):
        match = re.search(rb"^"+name.encode()+rb" = '([0-9a-f]{64})'$", driver, re.M)
        require(match is not None, "fixed-driver-tool-literal", name=name)
        pins[name] = match.group(1).decode()
    require(build["compiler_sha256"] == pins["COMPILER"] and build["linker_sha256"] == pins["LINKER"],
            "exact-compiler-linker-pins")
    raw_original, _ = file_bytes(directory/"emission-original-manifest.json", EMISSION_MANIFEST, inputs)
    require(raw_original == contents["emission_manifest"], "original-emission-manifest-copy")
    emitted_report_raw, _ = file_bytes(directory/"emission-original-report.json", EMISSION_REPORT, inputs)
    emitted_report = json.loads(emitted_report_raw)
    require(emitted_report_raw == contents["emission_report"], "actual-emission-report-binding")
    require(emitted_report["source_sha256"] == SOURCE
            and emitted_report["functions"] == profile["functions"]
            and emitted_report["blocks"] == profile["blocks"]
            and emitted_report["instructions"] == profile["instructions"]
            and emitted_report["units_planned"] == unit_count and emitted_report["all_inputs_unchanged"] is True
            and emitted_report["schema"] == "heptatorch.sum-dims-f32.source-emission.v3"
            and emitted_report["public_commands"] == [115, 116, 117]
            and emitted_report["autograd_operations"] == [47, 48]
            and emitted_report["status"] == "SOURCE_EMITTED_NOT_COMPILED"
            and emitted_report["state_format"] == "HTSUM003"
            and emitted_report["backing_format"] == "HTOSUM03"
            and emitted_report["compiler_executed"] is False
            and emitted_report["native_executed"] is False and emitted_report["torch_executed"] is False,
            "actual-emitter-not-restored-build")
    require(emitted_report["authoring_inputs_sha256"] ==
            {name: pin["sha256"] for name, pin in authors.items()}, "actual-emitter-all-authors")
    for path, digest in emitted_report["parent_inputs_sha256"].items():
        file_bytes(path, digest, inputs)
    for relative in ("source-map.json", "sum-dims-source-custody.json", "sum-dims-fragment.hepta",
                     "source01-to02-body-inverse.json", "source02-to03-body-inverse.json"):
        pin = emission["files"][relative]
        raw, _ = file_bytes(directory/relative, pin["sha256"], inputs)
        require(len(raw) == pin["bytes"], "exact-generated-companion", path=relative)
    body_map = split_functions(runtime)
    require(len(body_map) == profile["functions"] and HEADER+b"".join(body_map.values()) == runtime
            and len(re.findall(rb"^block ", runtime, re.M)) == profile["blocks"]
            and runtime.count(b" = ") == profile["instructions"], "complete-source-counts")
    source_map = json.loads(inputs[str((directory/"source-map.json").resolve())]["raw"])
    require(len(source_map) == profile["functions"] and {x["name"] for x in source_map} == set(body_map)
            and all(sha(body_map[x["name"]]) == x["sha256"]
                    and x["parent_sha256"] == (sha(parent_bodies[x["name"]]) if x["name"] in parent_bodies else None)
                    and x["unchanged_parent"] is (parent_bodies.get(x["name"]) == body_map[x["name"]])
                    for x in source_map),
            "complete-core-function-source-map")
    custody = json.loads(inputs[str((directory/"sum-dims-source-custody.json").resolve())]["raw"])
    fragment_raw = inputs[str((directory/"sum-dims-fragment.hepta").resolve())]["raw"]
    fragment = split_functions(fragment_raw)
    changed = sorted(name for name in parent_bodies if body_map.get(name) != parent_bodies[name])
    unchanged = sorted(name for name in parent_bodies if body_map.get(name) == parent_bodies[name])
    added = sorted(set(body_map)-set(parent_bodies))
    aliases = {"to_command": "sd_previous_to_command",
               "incoming_describe": "sd_previous_incoming_describe",
               "gradient_direct": "sd_previous_gradient_direct",
               "partial_check_node": "sd_previous_partial_check_node",
               "partial_apply_node": "sd_previous_partial_apply_node"}
    required_changed = set(aliases) | {"entry", "init_state", "state_header", "so_state_init", "so_state_header",
                                       "gradient_accumulate"}
    require(set(parent_bodies) <= set(body_map) and set(changed) == required_changed
            and len(unchanged) == 647 and custody["changed_parent_functions"] == changed
            and custody["unchanged_parent_functions"] == unchanged and custody["added_functions"] == added,
            "exact-whole-parent-diff-and-inherited648")
    require(set(fragment) == set(aliases) | (set(added)-set(aliases.values()))
            and all(body_map[name] == body for name, body in fragment.items()),
            "complete-generated-fragment-not-a-count-summary")
    receipts = custody["whole_inverse_records"]
    require(len(receipts) == 11, "eleven-whole-inverse-records-including-one-arithmetic-call")
    alias_receipts = {row["parent"]: row for row in receipts if row["kind"] == "name-only-parent-alias"}
    transformed = {row["function"]: row for row in receipts if row["kind"] != "name-only-parent-alias"}
    require(set(alias_receipts) == set(aliases) and set(transformed) == required_changed-set(aliases),
            "whole-inverse-exact-receipt-set")
    for original, alias in aliases.items():
        before, after = parent_bodies[original], body_map[alias]
        expected_alias = before.replace(("fn "+original+"(").encode(), ("fn "+alias+"(").encode(), 1)
        row = alias_receipts[original]
        require(after == expected_alias and row["alias"] == alias and
                row["before_sha256"] == sha(before) and row["after_sha256"] == sha(after)
                and row["whole_file_inverse"] is True, "exact-parent-name-only-alias", name=original)
    for name, row in transformed.items():
        before, after = parent_bodies[name], body_map[name]
        old, new = row["old"].encode(), row["new"].encode()
        require(old and new and before.count(old) == after.count(new) == 1
                and before.replace(old, new) == after and after.replace(new, old) == before
                and row["before_sha256"] == sha(before) and row["after_sha256"] == sha(after)
                and row["whole_file_inverse"] is True, "exact-parent-literal-inverse", name=name)
    require(custody["parent_source_sha256"] == PARENT and
            custody["source_inputs_sha256"] ==
            {name: authors[name]["sha256"] for name in
                ("sum_dims_geometry.py", "sum_dims_kernel.py", "sum_dims_runtime.py", "sum_dims_views.py")},
            "exact-source02-fragment-author-inputs")
    # Bind and independently reverse the current six-body source03 transition.
    # The unchanged source01 verifier below still consumes the actual source02
    # runtime/report and the original 09446 document, not a recomputed substitute.
    require(emitted_report["prior_actual_emission_source_sha256"] == SOURCE02
            and emitted_report["prior_actual_emission_manifest_sha256"] == SOURCE02_MANIFEST,
            "actual-source02-baseline-bound-by-source03")
    source02_candidates = [path for path, digest in emitted_report["parent_inputs_sha256"].items()
                           if digest == SOURCE02_MANIFEST]
    require(len(source02_candidates) == 1, "unique-complete-source02-manifest-input")
    old2_manifest_raw, old2_manifest_record = file_bytes(source02_candidates[0], SOURCE02_MANIFEST, inputs)
    old2_manifest = json.loads(old2_manifest_raw)
    require(old2_manifest["schema"] == "heptatorch.sum-dims-f32.actual-emission-members.v1"
            and old2_manifest["status"] == "ACTUAL_EMISSION_SEALED"
            and old2_manifest["source_sha256"] == SOURCE02
            and old2_manifest["parent_source_sha256"] == PARENT
            and old2_manifest["emission_report_sha256"] == SOURCE02_REPORT
            and old2_manifest["file_count"] == len(old2_manifest["files"]) == 29
            and old2_manifest["payload_bytes"] == 5434940,
            "complete-source02-original29-member-manifest")
    old2_root = Path(old2_manifest["emission_directory"])
    old2_entries = list(old2_root.iterdir())
    require(all(not p.is_symlink() and p.is_file() for p in old2_entries)
            and {p.name for p in old2_entries} == set(old2_manifest["files"]),
            "source02-original-directory-exact-set")
    old2_members = {}
    for name, pin in old2_manifest["files"].items():
        require(Path(name).name == name and name not in (".", "..")
                and set(pin) == {"bytes", "sha256", "mode"}, "safe-original-source02-member")
        raw, record = file_bytes(old2_root/name, pin["sha256"], inputs)
        require({key:record[key] for key in pin} == pin and
                emitted_report["parent_inputs_sha256"][str((old2_root/name).resolve())] == pin["sha256"],
                "source02-all29-original-bytes-modes-and-emitter-inputs", name=name)
        old2_members[name] = raw
    require(sum(map(len, old2_members.values())) == 5434940
            and sha(old2_members["runtime.hepta"]) == SOURCE02
            and sha(old2_members["report.json"]) == SOURCE02_REPORT
            and sha(old2_members["source01-to02-body-inverse.json"]) == SOURCE01_INVERSE,
            "source02-complete-original-byte-total-and-fixed-ancestry")
    old2_bodies = split_functions(old2_members["runtime.hepta"])
    old2_report = json.loads(old2_members["report.json"])
    require(len(old2_bodies) == 696 and HEADER+b"".join(old2_bodies.values()) == old2_members["runtime.hepta"]
            and old2_report["schema"] == "heptatorch.sum-dims-f32.source-emission.v2"
            and old2_report["source_sha256"] == SOURCE02
            and old2_report["functions"] == 696 and old2_report["blocks"] == 9216
            and old2_report["instructions"] == 32990 and old2_report["units_planned"] == 14,
            "source02-complete-runtime-order-and-actual-topology")
    current_inverse_raw = inputs[str((directory/"source02-to03-body-inverse.json").resolve())]["raw"]
    current_inverse = json.loads(current_inverse_raw)
    changed2 = sorted(name for name in old2_bodies if body_map.get(name) != old2_bodies[name])
    unchanged2 = sorted(name for name in old2_bodies if body_map.get(name) == old2_bodies[name])
    expected_changed2 = {"gradient_accumulate", "sd_store_accumulate", "init_state",
                         "state_header", "so_state_init", "so_state_header"}
    require(set(body_map) == set(old2_bodies) and set(changed2) == expected_changed2
            and len(unchanged2) == 690, "source03-exact690-unchanged6-modified0-added")
    require(current_inverse["schema"] == "heptatorch.sum-dims-f32.actual-source02-to03-inverse.v1"
            and current_inverse["status"] == "EXACT_SOURCE_INVERSE_NOT_RUNTIME_QUALIFIED"
            and current_inverse["actual_source02_manifest_sha256"] == SOURCE02_MANIFEST
            and current_inverse["actual_source02_runtime_sha256"] == SOURCE02
            and current_inverse["current_runtime_sha256"] == SOURCE
            and current_inverse["source02_functions"] == current_inverse["current_functions"] == 696
            and current_inverse["unchanged_functions"] == unchanged2
            and current_inverse["changed_functions"] == changed2
            and current_inverse["added_functions"] == []
            and current_inverse["added_bodies"] == {}
            and current_inverse["original_function_order"] == list(old2_bodies)
            and current_inverse["full_runtime_inverse_matches_original_bytes"] is True
            and all(current_inverse[key] is False for key in
                    ("compiler_executed", "native_executed", "torch_executed", "runtime_qualified")),
            "source03-complete-actual-body-inverse-document")
    records2 = current_inverse["changed_body_inverse"]
    require(len(records2) == 6 and [r["function"] for r in records2] == changed2,
            "source03-exact-six-whole-body-records")
    restored2 = dict(body_map)
    for row in records2:
        name = row["function"]
        before, after = row["before_utf8"].encode(), row["after_utf8"].encode()
        require(before == old2_bodies[name] and after == body_map[name]
                and sha(before) == row["before_sha256"] and sha(after) == row["after_sha256"],
                "source03-original-and-current-whole-body", name=name)
        if name == "gradient_accumulate":
            old = b'  v226:u64 = call(v225,v214) {"function":"addf"}\n'
            new = b'  v226:u64 = call(v225,v214) {"function":"scalar_add_preserving_bits"}\n'
        elif name == "sd_store_accumulate":
            old = b'{"function":"sd_carry_add"}'
            new = b'{"function":"scalar_add_preserving_bits"}'
        else:
            outer = name in ("init_state", "state_header")
            old_tag = b"HTSUM002" if outer else b"HTOSUM02"
            new_tag = b"HTSUM003" if outer else b"HTOSUM03"
            old = ('{"value":'+str(int.from_bytes(old_tag,"little"))+'}').encode()
            new = ('{"value":'+str(int.from_bytes(new_tag,"little"))+'}').encode()
        require(before.count(old) == after.count(new) == 1
                and before.replace(old,new) == after and after.replace(new,old) == before,
                "source03-only-two-arithmetic-callees-and-four-tags", name=name)
        restored2[name] = before
    require(restored2 == old2_bodies and
            HEADER+b"".join(restored2[name] for name in current_inverse["original_function_order"]) ==
            old2_members["runtime.hepta"], "source03-whole-runtime-inverse-exact-source02")
    require(emitted_report["source02_transition"] == {
        "prior_functions":696,"current_functions":696,"unchanged":690,"modified":6,"added":0,
        "whole_runtime_inverse":True,"inverse_sha256":sha(current_inverse_raw)},
        "source03-actual-emission-full-six-body-inverse-bound")
    require(inputs[str((directory/"source01-to02-body-inverse.json").resolve())]["raw"] ==
            old2_members["source01-to02-body-inverse.json"], "original09446-companion-byte-identical")
    # Preserve the original source01 verification statements and their expected
    # old counts by supplying the real immutable source02 pair here.
    current_SOURCE, current_body_map, current_emitted_report = SOURCE, body_map, emitted_report
    SOURCE, body_map, emitted_report = SOURCE02, old2_bodies, old2_report
    # The new companion carries every complete old/new body, not a summary count.
    # Reconstruct the immutable source01 runtime in its original function order.
    require(emitted_report["prior_actual_emission_source_sha256"] == PRIOR_SOURCE
            and emitted_report["prior_actual_emission_manifest_sha256"] == PRIOR_MANIFEST,
            "actual-source01-baseline-bound-by-new-emission")
    prior_candidates = [path for path, digest in emitted_report["parent_inputs_sha256"].items()
                        if digest == PRIOR_MANIFEST]
    require(len(prior_candidates) == 1, "unique-original-source01-manifest-input")
    prior_raw, _ = file_bytes(prior_candidates[0], PRIOR_MANIFEST, inputs)
    prior_manifest = json.loads(prior_raw)
    require(prior_manifest["schema"] == "heptatorch.sum-dims-f32.actual-emission-members.v1"
            and prior_manifest["status"] == "ACTUAL_EMISSION_SEALED"
            and prior_manifest["source_sha256"] == PRIOR_SOURCE
            and prior_manifest["parent_source_sha256"] == PARENT
            and prior_manifest["emission_report_sha256"] == PRIOR_REPORT
            and prior_manifest["file_count"] == len(prior_manifest["files"]) == 25
            and prior_manifest["payload_bytes"] == 4998609,
            "complete-original-source01-emission-manifest")
    prior_root = Path(prior_manifest["emission_directory"])
    prior_members = {}
    prior_entries = list(prior_root.iterdir())
    require(all(not p.is_symlink() and p.is_file() for p in prior_entries)
            and {p.name for p in prior_entries} == set(prior_manifest["files"]),
            "original-source01-exact-directory-set")
    for name, pin in prior_manifest["files"].items():
        require(Path(name).name == name and name not in (".", "..")
                and set(pin) == {"sha256", "bytes", "mode"}, "safe-original-source01-member")
        raw, record = file_bytes(prior_root/name, pin["sha256"], inputs)
        require({key: record[key] for key in pin} == pin
                and emitted_report["parent_inputs_sha256"][str((prior_root/name).resolve())] == pin["sha256"],
                "original-source01-all-bytes-modes-and-emitter-inputs", name=name)
        prior_members[name] = raw
    require(sum(map(len, prior_members.values())) == 4998609
            and sha(prior_members["runtime.hepta"]) == PRIOR_SOURCE
            and sha(prior_members["report.json"]) == PRIOR_REPORT,
            "source01-all-original-member-bytes")
    prior_bodies = split_functions(prior_members["runtime.hepta"])
    require(len(prior_bodies) == 687 and
            HEADER+b"".join(prior_bodies.values()) == prior_members["runtime.hepta"],
            "source01-original-complete-function-order")
    inverse_raw = inputs[str((directory/"source01-to02-body-inverse.json").resolve())]["raw"]
    inverse = json.loads(inverse_raw)
    inverse_changed = sorted(name for name in prior_bodies if body_map.get(name) != prior_bodies[name])
    inverse_added = sorted(set(body_map)-set(prior_bodies))
    inverse_unchanged = sorted(name for name in prior_bodies if body_map.get(name) == prior_bodies[name])
    expected_modified = {
        "sd_pack_metadata", "sd_validate_metadata", "sd_sum_tensor", "to_command", "incoming_describe",
        "gradient_direct", "partial_check_node", "partial_apply_node", "entry", "init_state",
        "state_header", "so_state_init", "so_state_header"}
    expected_added = {
        "sd_pack_original_dimensions", "sd_validate_original_dimensions", "sd_permute_tensor",
        "sd_permute_validate_metadata", "sd_permute_gradient_layout", "sd_permute_backward",
        "sd_permute_command", "sd_accumulator_variable", "sd_accumulator_command"}
    require(set(prior_bodies) <= set(body_map) and set(inverse_changed) == expected_modified
            and set(inverse_added) == expected_added and len(inverse_unchanged) == 674,
            "exact-source01-674-unchanged13-modified9-added")
    require(inverse["schema"] == "heptatorch.sum-dims-f32.actual-source01-to02-inverse.v1"
            and inverse["status"] == "EXACT_SOURCE_INVERSE_NOT_RUNTIME_QUALIFIED"
            and inverse["actual_source01_manifest_sha256"] == PRIOR_MANIFEST
            and inverse["actual_source01_runtime_sha256"] == PRIOR_SOURCE
            and inverse["current_runtime_sha256"] == SOURCE
            and inverse["source01_functions"] == 687 and inverse["current_functions"] == 696
            and inverse["unchanged_functions"] == inverse_unchanged
            and inverse["changed_functions"] == inverse_changed
            and inverse["added_functions"] == inverse_added
            and inverse["original_function_order"] == list(prior_bodies)
            and inverse["full_runtime_inverse_matches_original_bytes"] is True
            and all(inverse[key] is False for key in
                    ("compiler_executed", "native_executed", "torch_executed", "runtime_qualified")),
            "complete-source01-inverse-document")
    records = inverse["changed_body_inverse"]
    require(len(records) == 13 and [row["function"] for row in records] == inverse_changed
            and set(inverse["added_bodies"]) == set(inverse_added), "exact-source01-inverse-record-set")
    reconstructed = dict(body_map)
    for row in records:
        name = row["function"]
        before, after = row["before_utf8"].encode(), row["after_utf8"].encode()
        require(before == prior_bodies[name] and after == body_map[name]
                and sha(before) == row["before_sha256"] and sha(after) == row["after_sha256"],
                "original-and-current-whole-function-inverse", name=name)
        reconstructed[name] = before
    for name, row in inverse["added_bodies"].items():
        require(row["body_utf8"].encode() == body_map[name] and row["sha256"] == sha(body_map[name]),
                "exact-whole-added-body", name=name)
        del reconstructed[name]
    require(reconstructed == prior_bodies and
            HEADER+b"".join(reconstructed[name] for name in inverse["original_function_order"]) ==
            prior_members["runtime.hepta"], "whole-runtime-inverse-byteexact-source01")
    require(emitted_report["source01_transition"] == {
        "prior_functions": 687, "current_functions": 696, "unchanged": 674, "modified": 13, "added": 9,
        "whole_runtime_inverse": True, "inverse_sha256": sha(inverse_raw)},
        "actual-emission-full-inverse-bound")
    # Resume current-image compilation admission only after both original
    # whole-runtime inverse chains have been independently verified.
    SOURCE, body_map, emitted_report = current_SOURCE, current_body_map, current_emitted_report
    ancestry = {
        "ancestor_runtime_sha256": PRIOR_SOURCE,
        "ancestor_manifest_sha256": PRIOR_MANIFEST,
        "source01_to02_inverse_sha256": SOURCE01_INVERSE,
        "unchanged":674,"modified":13,"added":9,
        "whole_runtime_reverse_and_forward_checked":True}
    require(current_inverse["source01_ancestry"] == emitted_report["source01_ancestry"] == ancestry,
            "exact-original-source01-ancestry-in-new-emission-and-inverse")
    require(build["source02_transition_admission"] == emission["source02_transition"],
            "compiler-and-independent-emission-admission-exact-current-lineage")
    admitted_transition = build["source02_transition_admission"]
    for key, value in emitted_report["source02_transition"].items():
        require(admitted_transition[key] == value, "current-lineage-compact-fields", field=key)
    require(admitted_transition["source01_transition_admission"] == old2_manifest["source01_transition"],
            "unchanged-original-source01-admission-object-exact")
    require(admitted_transition["prior_manifest"] == old2_manifest_record
            and admitted_transition["prior_runtime_sha256"] == SOURCE02
            and admitted_transition["current_runtime_sha256"] == SOURCE
            and admitted_transition["old_members_verified"] == 29
            and admitted_transition["original_function_order_verified"] is True
            and admitted_transition["changed_functions"] == changed2
            and admitted_transition["added_functions"] == []
            and admitted_transition["all_690_unchanged_bodies_verified"] is True
            and admitted_transition["only_two_call_targets_and_four_tags_changed"] is True
            and admitted_transition["source01_ancestry"] == ancestry,
            "new-full-lineage-record-matches-independent-byte-recomputation")
    for key, expected_raw in (("inverse", current_inverse_raw),
                              ("source01_inverse_copy", old2_members["source01-to02-body-inverse.json"])):
        pin = admitted_transition[key]
        require(set(pin) == {"path","bytes","sha256","mode"}, "exact-current-lineage-companion-pin", key=key)
        raw, record = file_bytes(pin["path"], pin["sha256"], inputs)
        require(record == pin and raw == expected_raw,
                "exact-current-lineage-companion-original-bytes-mode", key=key)
    require(build["source_package_admission"] == {
        "manifest":emission["source_package"],"payload_count":22,"payload_bytes":476626,
        "author_count":9,"all_package_bytes_and_modes_verified":True},
        "new-complete-author-package-admission-bound")
    units = build["units"]
    require(len(units) == unit_count and [u["name"] for u in units] == names
            and [u["name"] for u in emitted_report["units"]] == names,
            "exact-actual-unit-order")
    objects, core = [], {}
    for unit, emitted in zip(units, emitted_report["units"]):
        name = unit["name"]
        source, _ = file_bytes(directory/(name+".hepta"), unit["source_sha256"], inputs)
        obj, _ = file_bytes(directory/(name+".o"), unit["object_sha256"], inputs)
        require(source == inputs[str((Path(emission["emission_directory"])/(name+".hepta")).resolve())]["raw"],
                "actual-unit-source-equals-emission", name=name)
        require(unit["source_sha256"] == emitted["source_sha256"]
                and len(obj) == unit["object_bytes"] and obj.startswith(b"\x7fELF")
                and unit["compiler_exit"] == 0 and unit["compiler_stderr_bytes"] == 0,
                "actual-compiled-object", name=name)
        unit_bodies = split_functions(source)
        require(len(unit_bodies) == unit["functions"] == emitted["functions"]
                and len(re.findall(rb"^block ", source, re.M)) == unit["blocks"] == emitted["blocks"]
                and source.count(b" = ") == unit["instructions"] == emitted["instructions"],
                "unit-source-topology", name=name)
        if name not in ("rng03", "owners"):
            require(not set(core) & set(unit_bodies), "unit-duplicate-core-body", name=name)
            core.update(unit_bodies)
        objects.append(obj)
    require(core == body_map, "all-core-bodies-in-real-units")
    processes = build["processes"]
    require(len(processes) == unit_count+1 and [p["label"] for p in processes] == names+["link"],
            "all-real-compiler-processes-plus-link")
    request = b"HIASTKS1"+struct.pack("<3Q", unit_count, 4, 0)+b"step"
    request += b"".join(struct.pack("<Q", len(obj))+obj for obj in objects)
    raw_request, _ = file_bytes(directory/"link.request.bin", sha(request), inputs)
    require(raw_request == request, "exact-link-order-and-object-bytes")
    for i, process in enumerate(processes):
        label = process["label"]
        expected_stdin = request if label == "link" else inputs[str((directory/(label+".hepta")).resolve())]["raw"]
        wanted_tool = pins["LINKER" if label == "link" else "COMPILER"]
        require(process["started"] is True and process["completed"] is True
                and process["returncode"] == 0 and process["stdout_EOF"] is True and process["stderr_EOF"] is True
                and process["env"] == {"PATH": ""} and not process["cleanup_errors"]
                and not process["evidence_write_errors"] and not process["additional_partial_streams"]
                and "primary_error" not in process, "real-process-success-and-EOF", label=label)
        require(len(process["argv"]) == 1 and
                declared[str(Path(process["argv"][0]).resolve())]["sha256"] == wanted_tool,
                "real-process-executable-pin", label=label)
        require(process["stdin_sha256"] == sha(expected_stdin)
                and process["stdin_bytes"] == len(expected_stdin), "real-process-input-bytes", label=label)
        for channel in ("stdout", "stderr"):
            relative = process[channel+"_path"]
            require(Path(relative).name == relative, "safe-process-stream-path")
            raw, _ = file_bytes(directory/relative, process[channel+"_sha256"], inputs)
            require(len(raw) == process[channel+"_bytes"], "complete-process-stream", label=label)
            if channel == "stderr":
                require(raw == b"", "empty-process-stderr", label=label)
            elif label == "link":
                require(raw == image, "linked-image-equals-original-link-stdout")
            else:
                require(raw == objects[i], "object-equals-original-compiler-stdout", label=label)
        argv_raw, _ = file_bytes(directory/(label+".argv.json"), inputs=None)
        require(json.loads(argv_raw) == process, "original-process-record", label=label)
        file_bytes(directory/(label+".argv.json"), sha(argv_raw), inputs)
    return binding, build, {"status": "ADMITTED_ACTUAL_BUILD_ONLY", "source_sha256": SOURCE,
        "native_sha256": sha(image), "functions": profile["functions"], "units": unit_count,
        "compiler_processes": unit_count, "link_processes": 1,
        "complete_process_streams": 2*(unit_count+1), "emitted_member_count": len(required_emission),
        "result_executed_here": False, "Torch_executed_here": False}
