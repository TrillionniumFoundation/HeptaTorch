"""Pure copied-state controls for the narrow command117 publication proof.

The positive endpoints are the original source02 archived bytes. They are
decoded and structurally checked by the original source02 owner module.
Only the new publication function is then applied as a pure byte predicate;
the old bytes are never decoded as HTSUM003 or called a source03 native run.
"""
import argparse
import copy
import json
import lzma
from pathlib import Path
import struct
import sys
import traceback
from admit_reference32 import file_bytes, require, sha
from replay_sum32 import admit_package, load_module, write_json, unchanged_inputs

HERE = Path(__file__).resolve().parent
CONFIG = Path("/home/qian-qi/heptatorch-continuation-20261116/runs/sum117-owner-endpoint-diagnostic-source-01/configuration.json")
CONFIG_SHA = "fc1260d665012fc97ab95788140cdde88896869fac585ec39c6d9695c60dad36"
FORBIDDEN = []


def audit(event, args):
    bad = event.startswith(("subprocess.", "socket.", "os.exec", "os.spawn", "os.fork", "pty.")) or event == "os.system"
    if event == "open" and args and isinstance(args[0], str):
        bad = bad or args[0] == "/proc" or args[0].startswith("/proc/")
    if event == "import" and args:
        bad = bad or str(args[0]).split(".")[0] in ("torch", "numpy")
    if bad:
        FORBIDDEN.append({"event":event,"args":repr(args)})
        raise RuntimeError("forbidden copied-control action: " + event)


def bound(pin, inputs):
    raw, record = file_bytes(pin["path"], pin["sha256"], inputs)
    require(record == pin, "copied-control-original-file-byte-mode")
    return raw


def run(inputs, args):
    admit_package(HERE, args.package_sha256, inputs)
    raw, _ = file_bytes(CONFIG, CONFIG_SHA, inputs)
    config = json.loads(raw)
    pins = config["inputs"]
    old_source = bound(pins["owner"], inputs)
    require(sha(old_source) == "2d961e62d91ba71bcbdbc7490e0900ca92fa8482a01249aac635546d56860d7b",
            "original-owner-decoder-exact")
    original = load_module(Path(pins["owner"]["path"]), "source02_original_control_decoder")
    fixed_binding = json.loads(bound(pins["binding"], inputs))
    original.bind_profile(fixed_binding["runtime"]["sha256"], fixed_binding["binary"]["sha256"], 696)
    current = load_module(HERE/"owner_sum47_48.py", "source03_publication_predicate_only")
    # Deliberately do not bind or decode old raw bytes as the new profile.
    journal = [json.loads(line) for line in bound(pins["journal"], inputs).splitlines()]
    row = journal[-1]
    require(row["frame"] == 480 and row["commands"] == [[117,8606711810,0,0,0,0,0,0]],
            "fixed-original-publication-frame")
    snapshots, owners = {}, {}
    for side in ("before","after"):
        packed = bound(pins[side+"_xz"], inputs)
        decoder = lzma.LZMADecompressor(format=lzma.FORMAT_XZ)
        data = decoder.decompress(packed, max_length=699025)
        require(decoder.eof and not decoder.unused_data and len(data) == 699024
                and sha(data) == config[side+"_raw_sha256"], "copied-control-original-XZ-EOF")
        snapshot = original.decode_owner(data, row[side]["pointer"])
        require(original.verify_snapshot(snapshot) == row[side]["verified_summary"],
                "copied-control-original84Q-qualification")
        owners[side], snapshots[side] = data, snapshot
    before, after = snapshots["before"], snapshots["after"]
    command = row["commands"][0]
    raw_responses = bound(pins["responses"], inputs)
    at, bodies = 0, []
    while at < len(raw_responses):
        magic, size = struct.unpack_from("<8sQ", raw_responses, at)
        require(magic == b"HTOWNS01" and at+16+size <= len(raw_responses), "copied-control-wire-frame")
        bodies.append(raw_responses[at+16:at+16+size])
        at += 16+size
    require(at == len(raw_responses) and len(bodies) == 480 and
            sha(bodies[-1]) == config["response_sha256"], "copied-control-complete-wire-EOF")
    response = bodies[-1]
    require(struct.unpack_from("<8s3Q", response) == (b"HTORSP03",3,1,0), "copied-control-successful-wire")
    op, error, token, size = struct.unpack_from("<4Q", response,32)
    require((op,error,size,len(response)) == (117,0,0,64), "copied-control-original-record")
    record = {"opcode":op,"value":token,"payload":b""}
    positive = current.verify_accumulator_publication(before, after, command, record,
                    before_raw=owners["before"], after_raw=owners["after"])
    require(positive["publication_byte_proof"]["whole_owner_inverse_sha256"] ==
            config["before_raw_sha256"], "positive-original-publication-inverse")
    results = [{"name":"original-publication","status":"PASS_PURE_PREDICATE",
                "native_executed":False,"proof":positive}]
    target = positive["target"]
    page = next(p for p in before["pages"] if p["page"] == target >> 8)
    pool_start = 139264+144+552*before["header"]["slots"]
    page_start = pool_start+(page["address"] & ((1<<63)-1))
    target_node = before["nodes"][str(target)]
    storage = before["tables"]["2"][(target_node[27]&0xffffff)-1]
    tensor_at = pool_start+storage[2]
    generators = [(i,r) for i,r in enumerate(before["tables"]["7"],1) if r[1]]
    require(len(generators) == 1, "one-real-original-generator-for-copied-control")
    _, gr = generators[0]
    hr = before["tables"]["6"][(gr[2]&0xffffff)-1]
    sr = before["tables"]["2"][(hr[2]&0xffffff)-1]
    require(sr[3] == 5056, "complete-real-generator-storage")
    rng_at = pool_start+sr[2]+256

    def rejected(name, after_snapshot, after_bytes, rec=record, before_bytes=owners["before"]):
        try:
            current.verify_accumulator_publication(before, after_snapshot, command, rec,
                    before_raw=before_bytes, after_raw=after_bytes)
        except AssertionError as error:
            results.append({"name":name,"status":"PASS_EXACT_REFUSAL",
                            "refusal":error.args[0],"native_executed":False})
            return
        raise AssertionError({"copied_control_not_rejected":name})

    rejected("missing-before-raw",after,owners["after"],before_bytes=None)
    rejected("truncated-after-raw",after,owners["after"][:-1])
    for name, offset in (("changed-Tensor-physical-byte",tensor_at),
                         ("changed-RNG-MT-word",rng_at),
                         ("changed-unused-descriptor-page-byte",page_start+672*256-1),
                         ("changed-free-pool-byte",len(owners["after"])-1)):
        data = bytearray(owners["after"])
        data[offset] ^= 1
        data = bytes(data)
        snap = original.decode_owner(data,row["after"]["pointer"])
        # These changes do not alter structural roles. The new full byte proof
        # must reject them even while the unchanged original84Q rules pass.
        original.verify_snapshot(snap)
        rejected(name,snap,data)
    false_record = dict(record)
    false_record["value"] = command[1]
    rejected("returned-different-existing-Tensor",after,owners["after"],rec=false_record)
    false_snapshot = copy.deepcopy(after)
    key = str(page["hold"])
    false_snapshot["hold_regions"][key]["sha256"] = before["hold_regions"][key]["sha256"]
    rejected("forged-descriptor-Hold-digest",false_snapshot,owners["after"])
    require(len(results) == 9 and sum(r["status"] == "PASS_EXACT_REFUSAL" for r in results) == 8,
            "one-positive-and-eight-required-copied-controls")
    return {"status":"PASS_PURE_PUBLICATION_CONTROLS","positive_count":1,"copied_refusal_count":8,
            "results":results,"original_source02_native_failure_preserved":True,
            "old_owner_decode_tags_not_rewritten":True,
            "new_native_result_inferred":False,"native_executed":False,
            "Torch_executed":False,"general_transition_qualification":False}


def main():
    require(not sys.flags.optimize,"copied-controls-assertions-required")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-sha256",required=True)
    parser.add_argument("--output",type=Path,required=True)
    args = parser.parse_args()
    sys.addaudithook(audit)
    output = args.output.resolve()
    require(output != HERE and not output.is_relative_to(HERE),"independent-control-output")
    output.mkdir(parents=True,exist_ok=False)
    inputs, result, code = {}, {}, 1
    try:
        result = run(inputs,args)
        require(not FORBIDDEN,"no-forbidden-control-action")
        code = 0
    except BaseException as error:
        result.update(status="FAIL_PURE_CONTROLS",error=repr(error),traceback=traceback.format_exc())
    finally:
        errors = unchanged_inputs(inputs)
        result.update(schema="heptatorch.sum117.publication-copied-controls.v1",
                      checked_inputs={name:value["record"] for name,value in inputs.items()},
                      all_inputs_unchanged=not errors,input_recheck_errors=errors,
                      forbidden_actions=FORBIDDEN,native_or_Torch_or_compiler_invocations=0)
        if errors or FORBIDDEN:
            result["status"],code = "FAIL_PURE_CONTROLS",1
        write_json(output/"report.json",result)
    print(json.dumps({"status":result["status"],"report":str(output/"report.json")}))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
