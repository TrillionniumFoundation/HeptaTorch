#!/usr/bin/env python3
"""Future actual-only CPU Bool/I64 sum.dim_IntList reference; 24 fixed recipes.

Source preparation does not execute this program. All output and gradient values,
acceptance, errors, Version and lifetime outcomes come from the pinned Torch run.
Raw integer words in case-contract.json are inputs, never expected results.
"""
import argparse
import gc
import hashlib
import itertools
import json
from pathlib import Path, PurePosixPath
import runpy
import stat
import struct
import sys
import traceback
import warnings
import weakref

PARENT_REFERENCE_MANIFEST = '7db1e860e6387a0d48b98769eb9f124211a90b92bfb62a07e55eb294ab4ef780'
INTEGRAL_SOURCE_MANIFEST = 'cbdb6b7331f1d4f4cf2e1d88cb9306cc17875d9051feca47c958646f04dec6a6'
INTEGRAL_CONTRACT_SHA = '9a225a36915650ba805c019b8d97046e7027ca8a8a2b2e246010b9554a3ef4f7'
SOURCE_REF = '31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457'
SUPPORT_SHA = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK_SHA = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
PIP_SHA = '35ad4841c2f2f94be7ded7f1bcc97f9592f806658ff660bfac5bdc3b0cf986ef'
INVENTORY_SHA = 'd204c5a8268a0d0f0a1dd162b5e0ab184beee83310bcad643b084deb691f3f49'
PARENT_HELPER_SOURCE_SHA = '4dd374419e4b21a9c814c855d846481730a12ea57a30dcf229a6b962f07021c5'
SOURCE_PINS = json.loads("{\"aten/src/ATen/ExpandUtils.h\":{\"sha256\":\"476def62f23809be59744491baf187dc1099ef7b483d65b68e46d71f148d5fc7\",\"bytes\":17062,\"git_blob_sha1\":\"4bb43c8ac1aa8340e9805320fc0436efdef2c3bb\"},\"aten/src/ATen/ExpandUtils.cpp\":{\"sha256\":\"69c16cc97348ebb3135eb8c1d0f175736aa7190799266dee7421b0d642690f17\",\"bytes\":8092,\"git_blob_sha1\":\"ff9b4573c9568ef7323ae446efa76368b6c0244c\"},\"aten/src/ATen/native/TensorShape.cpp\":{\"sha256\":\"ea89ebf0352140a392c29db196c010e8c715b9f98f774b47e8a25e0ca8d542ba\",\"bytes\":172416,\"git_blob_sha1\":\"99e06c707bca016f1989af21f5cec0a4b380c9a2\"},\"tools/autograd/derivatives.yaml\":{\"sha256\":\"4a4d1ae1ddea605f57594de991da2c92e89ae11d6aa6edf348107589b548082c\",\"bytes\":188779,\"git_blob_sha1\":\"d0ee6fb1e7b5261eb1e02eaf07cf08deff09a95f\"},\"aten/src/ATen/native/ReduceOps.cpp\":{\"sha256\":\"78054c6d5573ea7afe615eb85c0f31797db660e5823b4977e9539957663c5be2\",\"bytes\":88621,\"git_blob_sha1\":\"1e258bcb470369314fdd0a22ddfe67a494fc62e7\"},\"aten/src/ATen/native/ReduceOpsUtils.h\":{\"sha256\":\"edb1e0e7f9c3b669c27dd366150a5e0e5dbbcb2f6dc5ff0ca8d7df2eb43c6fcf\",\"bytes\":16702,\"git_blob_sha1\":\"b316e54b10927e00e699efb3bdef2a565feefcb2\"},\"aten/src/ATen/native/cpu/SumKernel.cpp\":{\"sha256\":\"d9e19a2a6646fc6dac5ea041b8badaf6bd5b8492899899dfff09db650edd5e0d\",\"bytes\":23903,\"git_blob_sha1\":\"14641f37fef0d5a0ff3e787510f249519a9447b6\"},\"torch/csrc/autograd/FunctionsManual.cpp\":{\"sha256\":\"a8603d6309822a3f93fa4fcb5ada05e2f0f7e29a1b96db64fe6f59ce0c730558\",\"bytes\":322787,\"git_blob_sha1\":\"94f18a437f6e0edf57d44872d46c011b2b1b6853\"},\"aten/src/ATen/TensorIterator.cpp\":{\"sha256\":\"a71a7ec9ba0532bf1380aa8ebc92975e4acb31414cd4b8eeeba650afe9e4490c\",\"bytes\":64558,\"git_blob_sha1\":\"427a732b852ce00864bbfbf3bc5e3ac2233555fd\"},\"aten/src/ATen/WrapDimUtilsMulti.h\":{\"sha256\":\"48f80c8bd54e81310980e5c6ae37bb47cd751592c16644f138369a85fa7aab23\",\"bytes\":1037,\"git_blob_sha1\":\"4cb41b151165b0dd5b1b10a45ae35e9564d4c1f8\"},\"aten/src/ATen/native/TensorIteratorReduce.cpp\":{\"sha256\":\"5619f1002090dbea04fc0f7355b814d8dbfcce02e342d4cd06ea441ce15a8fbe\",\"bytes\":6098,\"git_blob_sha1\":\"ce2987eb251ae1ebeeb6e11558060af991201d20\"},\"aten/src/ATen/TensorIteratorInternal.h\":{\"sha256\":\"b3e2145354d4c4827d7ac8aa483748a13681efdce3bc2265711101e56508e50d\",\"bytes\":1922,\"git_blob_sha1\":\"9792494c8b5ab786d92615c1c3c544fc23281b24\"}}")
CHECKS = {
    'python_matches', 'platform_matches', 'version_backend_matches',
    'git_matches_oracle_build_pin', 'distribution_version_matches',
    'direct_url_matches', 'direct_url_archive_sha256_matches',
    'pip_report_url_matches', 'pip_report_archive_sha256_matches',
    'pip_report_version_matches', 'pip_report_requested',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_record(path):
    assert not path.is_symlink(), str(path)
    meta = path.stat()
    assert stat.S_ISREG(meta.st_mode), str(path)
    raw = path.read_bytes()
    assert len(raw) == meta.st_size, str(path)
    return raw, {'path': str(path), 'bytes': len(raw), 'mode': stat.S_IMODE(meta.st_mode),
                 'sha256': sha(raw)}


def bind_inputs(args):
    root = Path(__file__).resolve().parent
    manifest_raw, manifest_record = file_record(args.source_manifest.resolve())
    assert manifest_record['sha256'] == args.source_manifest_sha256
    manifest = json.loads(manifest_raw)
    assert manifest['schema'] == 'heptatorch.sum-integral.reference24-source-manifest.v1'
    assert manifest['status'] == 'SOURCE_ONLY_NOT_RUN'
    assert args.source_manifest.resolve() == root / 'source-manifest.json'
    inputs, records = {str(args.source_manifest.resolve()): manifest_raw}, [manifest_record]

    def add(path, wanted):
        path = path.resolve()
        raw, record = file_record(path)
        assert all(record[name] == wanted[name] for name in ('bytes', 'mode', 'sha256')), str(path)
        if str(path) in inputs:
            assert inputs[str(path)] == raw
        else:
            inputs[str(path)] = raw
            records.append(record)
        return raw

    paths = [entry['path'] for entry in manifest['files']]
    assert len(paths) == len(set(paths)) and paths
    for entry in manifest['files']:
        rel = PurePosixPath(entry['path'])
        assert not rel.is_absolute() and '..' not in rel.parts and str(rel) == entry['path']
        add(root / entry['path'], entry)
    assert inputs[str(root / 'pytorch_sum_integral_probe.py')] == Path(__file__).read_bytes()

    # Complete original packages are inputs. Their prior statuses are not
    # borrowed as the result of this independent actual observation.
    for directory, pin, schema, count, mapping in [
        (args.parent_reference_dir, PARENT_REFERENCE_MANIFEST,
         'heptatorch.sum-dims-reference32-source-manifest.v1', 38, False),
        (args.integral_source_dir, INTEGRAL_SOURCE_MANIFEST,
         'heptatorch.sum-integral.source-handoff.v1', 26, True),
    ]:
        path = directory / 'source-manifest.json'
        raw, record = file_record(path)
        assert record['sha256'] == pin
        inputs[str(path)] = raw
        records.append(record)
        package = json.loads(raw)
        assert package['schema'] == schema and len(package['files']) == count
        entries = package['files'].items() if mapping else (
            (entry['path'], entry) for entry in package['files'])
        for name, entry in entries:
            rel = PurePosixPath(name)
            assert not rel.is_absolute() and '..' not in rel.parts and str(rel) == name
            add(directory / name, entry)
    assert inputs[str(root / 'provenance/pytorch_sum_dims_probe.py')] == inputs[
        str(args.parent_reference_dir / 'pytorch_sum_dims_probe.py')]
    assert sha(inputs[str(root / 'provenance/pytorch_sum_dims_probe.py')]) == 'e462376e2c380c44ff1bcbf452169d2356ea0502ca2d2a4ad45cb99c1d0ed50d'
    assert sha(inputs[str(args.integral_source_dir / 'case-contract.json')]) == INTEGRAL_CONTRACT_SHA
    assert inputs[str(root / 'case-contract.json')] == inputs[str(args.integral_source_dir / 'case-contract.json')]

    for name, pin in [('pytorch_oracle.py', SUPPORT_SHA), ('pytorch-oracle-lock.json', LOCK_SHA),
                      ('pytorch-install.json', PIP_SHA), ('upstream-lock.json', INVENTORY_SHA),
                      ('original-view-reshape-probe.py', PARENT_HELPER_SOURCE_SHA)]:
        assert sha(inputs[str(args.parent_reference_dir / 'inputs' / name)]) == pin
    primary_index = json.loads(inputs[str(args.parent_reference_dir / 'primary-sources.json')])
    assert primary_index['commit'] == SOURCE_REF and primary_index['files'] == SOURCE_PINS
    for relative, pin in SOURCE_PINS.items():
        raw = inputs[str(args.parent_reference_dir / 'upstream' / relative)]
        assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256']
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == pin['git_blob_sha1']
    extra_primary = json.loads(inputs[str(root / 'integral-primary-sources.json')])
    assert extra_primary['commit'] == SOURCE_REF
    for name, pin in extra_primary['files'].items():
        raw = inputs[str(args.integral_source_dir / name)]
        assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256']
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == pin['git_blob_sha1']
    lock = json.loads(inputs[str(args.parent_reference_dir / 'inputs/pytorch-oracle-lock.json')])
    assert lock['inventory_commit'] == SOURCE_REF
    for actual, frozen in [
        (args.repo / lock['oracle']['install_report'], args.parent_reference_dir / 'inputs/pytorch-install.json'),
        (args.repo / 'compatibility/upstream-lock.json', args.parent_reference_dir / 'inputs/upstream-lock.json'),
    ]:
        raw, record = file_record(actual.resolve())
        assert raw == inputs[str(frozen)], str(actual)
        if str(actual.resolve()) not in inputs:
            inputs[str(actual.resolve())] = raw
            records.append(record)
    plan = json.loads(inputs[str(root / 'case-contract.json')])
    assert plan['schema'] == 'heptatorch.sum-integral.reference-case-contract.v1'
    assert plan['status'] == 'SOURCE_ONLY_NOT_OBSERVED' and plan['fixed_pytorch_commit'] == SOURCE_REF
    assert plan['core_case_count'] == 24 and len(plan['cases']) == 24
    assert [row['id'] for row in plan['cases']] == list(range(24))
    assert len({row['label'] for row in plan['cases']}) == 24
    for row in plan['cases']:
        literal, target = row['input'], row['target']
        assert row['expected_numeric_output'] is None and row['expected_error_text'] is None
        assert literal['dtype'] in ('Bool', 'Int64') and literal['requires_grad'] is False
        assert len(literal['shape']) == len(literal['strides']) <= 4
        assert all(type(d) is int and 0 <= d <= 262144 for d in literal['shape'])
        assert all(type(d) is int and 0 <= d <= (2**63 - 1)//8 for d in literal['strides'])
        assert type(literal['storage_offset']) is int and literal['storage_offset'] >= 0
        width = 1 if literal['dtype'] == 'Bool' else 8
        for word in literal['base_storage_words']:
            assert isinstance(word, str) and len(word) == width*2
            assert word == word.lower() and all(c in '0123456789abcdef' for c in word)
            if width == 1:
                assert word in ('00', '01')
        assert target['operator'] == 'torch.sum' and target['dtype'] in ('None', 'Int64')
        assert type(target['keepdim']) is bool
        axes = target['dimension_argument']
        assert axes is None or (isinstance(axes, list) and all(type(axis) is int for axis in axes))
    return root, inputs, records, plan, lock


def run(args, root, inputs, before_records, contract, lock):
    common = {
        'schema': 'heptatorch.sum-integral.reference24.v1',
        'probe_sha256': sha(inputs[str(Path(__file__).resolve())]),
        'source_manifest_sha256': args.source_manifest_sha256,
        'primary_source_ref': SOURCE_REF, 'primary_source_pins': SOURCE_PINS,
        'primary_files_read_and_sha256_gitblob_verified': True,
        'additional_integral_primary_sources': json.loads(inputs[str(root / 'integral-primary-sources.json')]),
        'bound_parent_reference_manifest_sha256': PARENT_REFERENCE_MANIFEST,
        'bound_integral_source_manifest_sha256': INTEGRAL_SOURCE_MANIFEST,
        'case_contract_sha256': sha(inputs[str(root / 'case-contract.json')]),
        'case_plan': contract['cases'], 'planned_cases': 24,
        'native_executed': False, 'compiler_executed': False, 'native_qualified': False,
        'full_pytorch_rewrite_complete': False, 'pytorch_api_denominator': 2590,
        'closed_schema_count': 0, 'project_gates_remain_hold': True,
        'policy': 'OBSERVATION ONLY. No expected numeric outputs, gradients, acceptance, errors or lifetimes are synthesized.',
        'numeric_policy': 'Every Bool byte and complete I64 word is recorded exactly. Overflow and empty Version are only actual observations. No float conversion, expected reduction or comparison-to-HIA occurs.',
        'scope': 'CPU Bool/I64 concrete rank0-4 sum.dim_IntList, default or explicit I64 output. Fixed single-thread AVX512 wheel. Actual no-grad refusals; no invented gradient or full schema closure.',
        'route_scope': 'Kernel route obligations are source-derived geometry classifications, not a dynamic dispatch trace or runtime proof.',
        'getter_order': 'Each live name: raw Tensor/Storage/layout/Version/requires/_base, grad_fn, is_leaf, retains_grad, grad. Then all current nodes, Saved getters and edge relations. The order is explicit and may refresh lazy ViewInfo.',
        'ownership_scope': 'Only live owns persistent named Tensor roots; held_result is an explicit alias in live. weak contains StorageWeakRef; tensor_weak contains weakref.ref only. Getter locals are released before weak observation. No weak outcome is predicted.',
        'version_scope': 'Recorded Version integers and mutation observations do not by themselves expose a Version-counter address.',
        'inputs_before': before_records,
    }
    old_argv = sys.argv
    try:
        sys.argv = [str(args.parent_reference_dir / 'inputs/pytorch_oracle.py'),
                    str(args.output_dir / 'NO_NATIVE_EXECUTABLE_USED'),
                    str(args.output_dir / 'provenance-failure-original.json'),
                    str(args.parent_reference_dir / 'inputs/pytorch-oracle-lock.json')]
        context = runpy.run_path(str(args.parent_reference_dir / 'inputs/pytorch_oracle.py'),
                                 run_name='sum_integral_reference_provenance_only')
    finally:
        sys.argv = old_argv
    torch, provenance = context['torch'], context['PROVENANCE']
    assert provenance['expected'] == lock['oracle']
    assert provenance['status'] == 'PASS' and set(provenance['checks']) == CHECKS
    assert all(value is True for value in provenance['checks'].values())
    assert torch.are_deterministic_algorithms_enabled()
    assert torch.utils.deterministic.fill_uninitialized_memory is True
    assert torch.get_num_threads() == 1
    assert torch.backends.cpu.get_cpu_capability() == 'AVX512'
    from torch.multiprocessing.reductions import StorageWeakRef
    states, rows, errors = {}, [], []

    def environment():
        return {'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
                'deterministic_fill': torch.utils.deterministic.fill_uninitialized_memory,
                'grad_enabled': torch.is_grad_enabled(), 'num_threads': torch.get_num_threads(),
                'cpu_capability': torch.backends.cpu.get_cpu_capability()}

    environment_before = environment()
    outer_rng = bytes(torch.get_rng_state().tolist())

    def rng():
        raw = bytes(torch.get_rng_state().tolist())
        assert len(raw) == 5056
        key = sha(raw)
        states.setdefault(key, {'bytes': len(raw), 'hex': raw.hex()})
        return key

    def capture(operation):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            try:
                value = operation()
                event = {'accepted': True, 'outcome': 'SUCCEEDED', 'error': None}
            except Exception as error:
                value = None
                event = {'accepted': False, 'outcome': 'RAISED',
                         'error': {'type': type(error).__name__, 'message': str(error)}}
        event['warnings'] = [{'type': type(w.message).__name__, 'message': str(w.message)} for w in caught]
        return value, event

    def raw_tensor(x):
        if x is None:
            return None
        storage = x.untyped_storage()
        raw = bytes(storage)
        width = x.element_size()
        shape, strides, offset = list(x.shape), list(x.stride()), x.storage_offset()
        logical = bytearray()
        for linear in range(x.numel()):
            quotient, at = linear, offset
            for size, stride in zip(reversed(shape), reversed(strides)):
                at += (quotient % size) * stride
                quotient //= size
            word = raw[at * width:at * width + width]
            assert len(word) == width
            logical.extend(word)
        base = x._base
        result = {'tensor_identity': str(x._cdata), 'storage_identity': str(storage._cdata),
                  'dtype': str(x.dtype), 'device': str(x.device), 'element_size': width, 'shape': shape, 'strides': strides,
                  'numel': x.numel(), 'storage_bytes': len(raw),
                  'storage_offset_elements': offset, 'storage_offset_bytes': offset * width,
                  'storage_raw_hex': raw.hex(), 'storage_sha256': sha(raw),
                  'logical_bytes_hex': bytes(logical).hex(), 'logical_sha256': sha(bytes(logical)),
                  'binary_words': [int.from_bytes(logical[i:i + width], 'little') for i in range(0, len(logical), width)],
                  'version': x._version, 'requires_grad': x.requires_grad, 'is_view': x._is_view(),
                  'base_tensor_identity': None if base is None else str(base._cdata)}
        del base, storage
        return result

    def primitive(value):
        if isinstance(value, torch.Tensor):
            return {'tensor': raw_tensor(value)}
        if value is None or isinstance(value, (bool, int, str)):
            return value
        if isinstance(value, float):
            return {'double_bits': struct.unpack('<Q', struct.pack('<d', value))[0]}
        if isinstance(value, (tuple, list)):
            return [primitive(item) for item in value]
        return {'type': type(value).__name__, 'diagnostic_repr': repr(value)}

    def node_info(fn, depth=4):
        if fn is None:
            return None
        result = {'kind': type(fn).__name__}
        if type(fn).__name__ == 'AccumulateGrad':
            variable = fn.variable
            result['variable'] = raw_tensor(variable)
            del variable
        if depth:
            result['next_edges'] = [{'output_nr': int(nr), 'node': node_info(child, depth - 1)}
                                    for child, nr in fn.next_functions]
        return result

    def saved_attributes(fn):
        if fn is None:
            return {}
        attributes = {}
        for name in sorted(n for n in dir(fn) if n.startswith('_saved_')):
            value, event = capture(lambda name=name: getattr(fn, name))
            if event['accepted']:
                event['value'] = primitive(value)
            del value
            attributes[name] = event
        return attributes

    def tensor_observation(x, weak):
        before = raw_tensor(x)
        fn, getter = capture(lambda: x.grad_fn)
        if getter['accepted']:
            getter['node'] = node_info(fn)
        del fn
        leaf, leaf_event = capture(lambda: x.is_leaf)
        if leaf_event['accepted']:
            leaf_event['value'] = bool(leaf)
        del leaf
        retained, retained_event = capture(lambda: x.retains_grad)
        if retained_event['accepted']:
            retained_event['value'] = bool(retained)
        del retained
        grad, grad_event = capture(lambda: x.grad)
        if grad_event['accepted']:
            grad_event['tensor'] = raw_tensor(grad)
            if grad is not None:
                key = 'observed_grad_storage_' + str(grad.untyped_storage()._cdata)
                if key not in weak:
                    weak[key] = StorageWeakRef(grad.untyped_storage())
        del grad
        return {'before_grad_fn_getter': before, 'grad_fn_getter': getter,
                'requires_grad_after_grad_fn_getter': x.requires_grad,
                'is_leaf_after_grad_fn_getter': leaf_event, 'retains_grad': retained_event,
                'gradient': grad_event}

    def snapshot(live, weak):
        names = list(live)
        tensors = {name: tensor_observation(live[name], weak) for name in names}
        relations = {}
        for left_name, right_name in itertools.combinations(names, 2):
            left, right = live[left_name], live[right_name]
            relations[left_name + '|' + right_name] = {
                'same_Python_object': left is right, 'same_Tensor': left._cdata == right._cdata,
                'same_Storage': left.untyped_storage()._cdata == right.untyped_storage()._cdata,
                'same_current_Version_value': left._version == right._version}
        if len(names) > 1:
            del left, right
        current, getters, saved, edges = {}, {}, {}, {}
        for name in names:
            fn, event = capture(lambda name=name: live[name].grad_fn)
            getters[name] = event
            if event['accepted']:
                current[name] = fn
            del fn
        for name, fn in current.items():
            saved[name] = saved_attributes(fn)
            edge_rows = []
            if fn is not None:
                for child, nr in fn.next_functions:
                    edge_rows.append({'output_nr': int(nr), 'node': node_info(child),
                                      'matches_live_current_grad_fn': [other for other, candidate in current.items()
                                                                     if child is not None and child is candidate]})
                    del child
            edges[name] = edge_rows
        # No Function or Tensor wrapper is returned or added to a persistent cache.
        if current:
            del fn
        current.clear()
        return {'tensor_getter_order': names, 'tensors': tensors, 'relations': relations,
                'saved_getters_after_tensor_getters': saved, 'edge_getters': getters,
                'edges_after_all_tensor_getters': edges,
                'expired': {name: ref.expired() for name, ref in weak.items()}, 'state': rng()}

    def make_backing(spec):
        literal = spec['input']
        dtype = torch.bool if literal['dtype'] == 'Bool' else torch.int64
        words = literal['base_storage_words']
        if not words:
            assert 0 in literal['shape']
            return torch.empty((0,), dtype=dtype, device='cpu')
        if dtype == torch.bool:
            raw = bytes(int(word, 16) for word in words)
        else:
            raw = b''.join(struct.pack('<Q', int(word, 16)) for word in words)
        # Input interpretation only; no expected reduction is computed.
        value = torch.frombuffer(bytearray(raw), dtype=dtype).clone()
        observed = raw_tensor(value)
        assert observed['storage_raw_hex'] == raw.hex()
        assert observed['logical_bytes_hex'] == raw.hex()
        return value

    def observe(spec, row):
        torch.manual_seed(1729)
        live, weak, tensor_weak, events = {}, {}, {}, row['events']
        row['state_before_setup'] = rng()

        def full_snapshot():
            result = snapshot(live, weak)
            # Each weakref call becomes bool immediately; no temporary Tensor
            # is retained into another observation or the next event.
            result['tensor_weak_alive'] = {name: ref() is not None for name, ref in tensor_weak.items()}
            return result

        def event(label, operation, publish=None):
            before = full_snapshot()
            value, result = capture(operation)
            result.update(label=label, before=before)
            if result['accepted']:
                result['returned'] = primitive(value)
                if isinstance(value, torch.Tensor):
                    result['returned_is_existing'] = {name: value is item for name, item in live.items()}
                if publish is not None:
                    assert isinstance(value, torch.Tensor), (label, type(value).__name__)
                    assert publish not in live
                    live[publish] = value
                    weak[publish + '_storage'] = StorageWeakRef(value.untyped_storage())
                    tensor_weak[publish + '_tensor'] = weakref.ref(value)
            del value
            result['after'] = full_snapshot()
            events.append(result)
            return result['accepted']

        def setup(label, operation, publish=None):
            accepted = event(label, operation, publish)
            if not accepted:
                row['setup_error'] = True
                row['remaining_not_attempted'] = 'setup operation raised: ' + label
            return accepted

        def drop(name):
            del live[name]
            gc.collect()

        def recipe():
            if not setup('construct_backing', lambda: make_backing(spec), publish='backing'):
                return
            literal, target = spec['input'], spec['target']
            if not setup('construct_strided_input',
                         lambda: torch.as_strided(live['backing'], tuple(literal['shape']),
                                                  tuple(literal['strides']), literal['storage_offset']),
                         publish='input'):
                return
            dtype = None if target['dtype'] == 'None' else torch.int64
            row['target_attempted'] = True
            accepted = event('sum_dim_IntList',
                             lambda: torch.sum(live['input'], dim=target['dimension_argument'],
                                               keepdim=target['keepdim'], dtype=dtype),
                             publish='result')
            row['target_accepted'] = accepted
            if accepted:
                event('result_requires_grad_true', lambda: live['result'].requires_grad_(True))
                if not setup('construct_explicit_integer_seed',
                             lambda: torch.ones_like(live['result']), publish='seed'):
                    return
                event('backward_integer_result', lambda: live['result'].backward(live['seed']))
                event('hold_result', lambda: live['result'], publish='held_result')
            event('drop_input', lambda: drop('input'))
            event('drop_backing', lambda: drop('backing'))
            if accepted:
                event('drop_result', lambda: drop('result'))
                event('drop_seed', lambda: drop('seed'))
                event('drop_held_result', lambda: drop('held_result'))

        try:
            recipe()
        except BaseException as error:
            row['probe_error'] = {'type': type(error).__name__, 'message': str(error),
                                  'traceback': traceback.format_exc()}
        row['before_final_drops'] = full_snapshot()
        for name in list(live):
            event('final_drop_' + name, lambda name=name: drop(name))
        assert not live
        gc.collect()
        row['final_expired'] = {name: ref.expired() for name, ref in weak.items()}
        row['final_tensor_weak_alive'] = {name: ref() is not None for name, ref in tensor_weak.items()}
        row['state_after'] = rng()
        row['status'] = ('PROBE_ERROR' if row['probe_error'] is not None else
                         'SETUP_ERROR' if row['setup_error'] else 'OBSERVED')
        return row

    with torch.random.fork_rng(devices=[]):
        for spec in contract['cases']:
            row = {**spec, 'index': spec['id'], 'name': spec['label'], 'status': 'STARTED', 'events': [],
                   'target_attempted': False, 'target_accepted': None,
                   'setup_error': False, 'probe_error': None}
            try:
                observe(spec, row)
            except BaseException as error:
                row.update(status='PROBE_ERROR',
                           probe_error={'type': type(error).__name__, 'message': str(error),
                                        'traceback': traceback.format_exc()},
                           partial_cleanup_not_observed=True)
            rows.append(row)
            if row['status'] != 'OBSERVED':
                errors.append({'index': spec['id'], 'name': spec['label'],
                               'status': row['status'], 'probe_error': row.get('probe_error')})
    environment_after = environment()
    outer_rng_restored = bytes(torch.get_rng_state().tolist()) == outer_rng
    after_records, changed_inputs = [], []
    for before in before_records:
        path = Path(before['path'])
        try:
            raw, record = file_record(path)
            after_records.append(record)
            if raw != inputs[str(path)] or record != before:
                changed_inputs.append({'before': before, 'after': record})
        except BaseException as error:
            changed_inputs.append({'before': before,
                                   'read_error': {'type': type(error).__name__, 'message': str(error)}})
    operation_totals = {'attempted': 0, 'succeeded': 0, 'raised': 0}
    backward_totals = {'attempted': 0, 'succeeded': 0, 'raised': 0}
    targets = {'attempted': 0, 'accepted': 0, 'raised': 0, 'not_attempted': 0}
    for row in rows:
        if row.get('target_attempted'):
            targets['attempted'] += 1
            targets['accepted' if row.get('target_accepted') else 'raised'] += 1
        else:
            targets['not_attempted'] += 1
        for item in row.get('events', []):
            operation_totals['attempted'] += 1
            operation_totals['succeeded' if item['accepted'] else 'raised'] += 1
            if item['label'].startswith('backward_'):
                backward_totals['attempted'] += 1
                backward_totals['succeeded' if item['accepted'] else 'raised'] += 1
    complete = (not errors and len(rows) == 24 and not changed_inputs and
                environment_before == environment_after and outer_rng_restored)
    report = {
        **common, 'status': 'OBSERVED' if complete else 'OBSERVATION_INCOMPLETE',
        'torch_executed': True, 'oracle_provenance': provenance,
        'build_configuration': torch.__config__.show(),
        'cpu_capability': torch.backends.cpu.get_cpu_capability(), 'num_threads': torch.get_num_threads(),
        'environment_before': environment_before, 'environment_after': environment_after,
        'environment_restored_within_probe': environment_before == environment_after,
        'rng_restore_scope': 'State immediately after the fixed support initialized its documented environment.',
        'original_outer_rng_restored': outer_rng_restored,
        'source_files_unchanged': not changed_inputs, 'inputs_after': after_records,
        'changed_inputs': changed_inputs, 'cases': len(rows), 'rows': rows,
        'states': states, 'unique_complete_states': len(states),
        'probe_errors': errors, 'probe_error_count': sum(r['status'] == 'PROBE_ERROR' for r in rows),
        'setup_error_count': sum(r['status'] == 'SETUP_ERROR' for r in rows),
        'operation_totals': operation_totals, 'backward_totals': backward_totals,
        'target_totals': targets, 'observation_is_not_native_qualification': True,
    }
    raw = (json.dumps(report, indent=2, allow_nan=False) + '\n').encode()
    output = args.output_dir / 'actual.json'
    with output.open('xb') as handle:
        handle.write(raw)
    print(json.dumps({'status': report['status'], 'cases': len(rows),
                      'actual_bytes': len(raw), 'actual_sha256': sha(raw),
                      'target_totals': targets, 'backward_totals': backward_totals,
                      'probe_error_count': report['probe_error_count'],
                      'setup_error_count': report['setup_error_count']}, allow_nan=False))
    return 0 if complete else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--parent-reference-dir', type=Path, required=True)
    parser.add_argument('--integral-source-dir', type=Path, required=True)
    parser.add_argument('--source-manifest', type=Path, required=True)
    parser.add_argument('--source-manifest-sha256', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    args.repo = args.repo.resolve()
    args.parent_reference_dir = args.parent_reference_dir.resolve()
    args.integral_source_dir = args.integral_source_dir.resolve()
    args.output_dir = args.output_dir.resolve()
    assert Path.cwd().resolve() == args.repo
    assert not args.output_dir.exists(), str(args.output_dir)
    args.output_dir.mkdir(parents=True, exist_ok=False)
    phase = 'input_binding_before_torch'
    try:
        root, inputs, before, contract, lock = bind_inputs(args)
        phase = 'actual_observation'
        return run(args, root, inputs, before, contract, lock)
    except BaseException as error:
        failure = {
            'schema': 'heptatorch.sum-integral.reference24.failure.v1',
            'status': 'NOT_RUN' if phase == 'input_binding_before_torch' else 'PROBE_ERROR',
            'phase': phase, 'native_executed': False, 'compiler_executed': False,
            'torch_executed': False if phase == 'input_binding_before_torch' else None,
            'torch_execution_note': 'If phase is actual_observation, inspect original support output; no completed status is inferred.',
            'error': {'type': type(error).__name__, 'message': str(error),
                      'traceback': traceback.format_exc()},
        }
        with (args.output_dir / 'failure.json').open('x') as handle:
            handle.write(json.dumps(failure, indent=2, allow_nan=False) + '\n')
        raise


if __name__ == '__main__':
    raise SystemExit(main())
