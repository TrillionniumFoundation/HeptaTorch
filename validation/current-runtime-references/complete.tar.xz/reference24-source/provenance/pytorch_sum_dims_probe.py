#!/usr/bin/env python3
"""Future actual-only CPU F32 sum.dim_IntList reference; 32 fixed recipes.

Source preparation does not execute this program. All output and gradient values,
acceptance, errors, Version and lifetime outcomes come from the pinned Torch run.
Raw integer words in case-contract.json are inputs, never expected results.
"""
import argparse
import gc
import hashlib
import itertools
import json
from pathlib import Path, PurePosixPath
import runpy
import stat
import struct
import sys
import traceback
import warnings

SOURCE_REF = '31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457'
SUPPORT_SHA = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK_SHA = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
PIP_SHA = '35ad4841c2f2f94be7ded7f1bcc97f9592f806658ff660bfac5bdc3b0cf986ef'
INVENTORY_SHA = 'd204c5a8268a0d0f0a1dd162b5e0ab184beee83310bcad643b084deb691f3f49'
PARENT_HELPER_SOURCE_SHA = '4dd374419e4b21a9c814c855d846481730a12ea57a30dcf229a6b962f07021c5'
SOURCE_PINS = json.loads("{\"aten/src/ATen/ExpandUtils.h\":{\"sha256\":\"476def62f23809be59744491baf187dc1099ef7b483d65b68e46d71f148d5fc7\",\"bytes\":17062,\"git_blob_sha1\":\"4bb43c8ac1aa8340e9805320fc0436efdef2c3bb\"},\"aten/src/ATen/ExpandUtils.cpp\":{\"sha256\":\"69c16cc97348ebb3135eb8c1d0f175736aa7190799266dee7421b0d642690f17\",\"bytes\":8092,\"git_blob_sha1\":\"ff9b4573c9568ef7323ae446efa76368b6c0244c\"},\"aten/src/ATen/native/TensorShape.cpp\":{\"sha256\":\"ea89ebf0352140a392c29db196c010e8c715b9f98f774b47e8a25e0ca8d542ba\",\"bytes\":172416,\"git_blob_sha1\":\"99e06c707bca016f1989af21f5cec0a4b380c9a2\"},\"tools/autograd/derivatives.yaml\":{\"sha256\":\"4a4d1ae1ddea605f57594de991da2c92e89ae11d6aa6edf348107589b548082c\",\"bytes\":188779,\"git_blob_sha1\":\"d0ee6fb1e7b5261eb1e02eaf07cf08deff09a95f\"},\"aten/src/ATen/native/ReduceOps.cpp\":{\"sha256\":\"78054c6d5573ea7afe615eb85c0f31797db660e5823b4977e9539957663c5be2\",\"bytes\":88621,\"git_blob_sha1\":\"1e258bcb470369314fdd0a22ddfe67a494fc62e7\"},\"aten/src/ATen/native/ReduceOpsUtils.h\":{\"sha256\":\"edb1e0e7f9c3b669c27dd366150a5e0e5dbbcb2f6dc5ff0ca8d7df2eb43c6fcf\",\"bytes\":16702,\"git_blob_sha1\":\"b316e54b10927e00e699efb3bdef2a565feefcb2\"},\"aten/src/ATen/native/cpu/SumKernel.cpp\":{\"sha256\":\"d9e19a2a6646fc6dac5ea041b8badaf6bd5b8492899899dfff09db650edd5e0d\",\"bytes\":23903,\"git_blob_sha1\":\"14641f37fef0d5a0ff3e787510f249519a9447b6\"},\"torch/csrc/autograd/FunctionsManual.cpp\":{\"sha256\":\"a8603d6309822a3f93fa4fcb5ada05e2f0f7e29a1b96db64fe6f59ce0c730558\",\"bytes\":322787,\"git_blob_sha1\":\"94f18a437f6e0edf57d44872d46c011b2b1b6853\"},\"aten/src/ATen/TensorIterator.cpp\":{\"sha256\":\"a71a7ec9ba0532bf1380aa8ebc92975e4acb31414cd4b8eeeba650afe9e4490c\",\"bytes\":64558,\"git_blob_sha1\":\"427a732b852ce00864bbfbf3bc5e3ac2233555fd\"},\"aten/src/ATen/WrapDimUtilsMulti.h\":{\"sha256\":\"48f80c8bd54e81310980e5c6ae37bb47cd751592c16644f138369a85fa7aab23\",\"bytes\":1037,\"git_blob_sha1\":\"4cb41b151165b0dd5b1b10a45ae35e9564d4c1f8\"},\"aten/src/ATen/native/TensorIteratorReduce.cpp\":{\"sha256\":\"5619f1002090dbea04fc0f7355b814d8dbfcce02e342d4cd06ea441ce15a8fbe\",\"bytes\":6098,\"git_blob_sha1\":\"ce2987eb251ae1ebeeb6e11558060af991201d20\"},\"aten/src/ATen/TensorIteratorInternal.h\":{\"sha256\":\"b3e2145354d4c4827d7ac8aa483748a13681efdce3bc2265711101e56508e50d\",\"bytes\":1922,\"git_blob_sha1\":\"9792494c8b5ab786d92615c1c3c544fc23281b24\"}}")
CHECKS = {
    'python_matches', 'platform_matches', 'version_backend_matches',
    'git_matches_oracle_build_pin', 'distribution_version_matches',
    'direct_url_matches', 'direct_url_archive_sha256_matches',
    'pip_report_url_matches', 'pip_report_archive_sha256_matches',
    'pip_report_version_matches', 'pip_report_requested',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_record(path):
    assert not path.is_symlink(), str(path)
    meta = path.stat()
    assert stat.S_ISREG(meta.st_mode), str(path)
    raw = path.read_bytes()
    assert len(raw) == meta.st_size, str(path)
    return raw, {'path': str(path), 'bytes': len(raw), 'mode': stat.S_IMODE(meta.st_mode),
                 'sha256': sha(raw)}


def bind_inputs(args):
    root = Path(__file__).resolve().parent
    manifest_raw, manifest_record = file_record(args.source_manifest.resolve())
    assert manifest_record['sha256'] == args.source_manifest_sha256
    manifest = json.loads(manifest_raw)
    assert manifest['schema'] == 'heptatorch.sum-dims-reference32-source-manifest.v1'
    assert manifest['status'] == 'SOURCE_ONLY_NOT_RUN'
    entries = manifest['files']
    assert isinstance(entries, list) and entries
    paths = [entry['path'] for entry in entries]
    assert len(paths) == len(set(paths))
    inputs, records = {str(args.source_manifest.resolve()): manifest_raw}, [manifest_record]
    for entry in entries:
        rel = PurePosixPath(entry['path'])
        assert not rel.is_absolute() and '..' not in rel.parts and rel.as_posix() == entry['path']
        path = root / entry['path']
        raw, record = file_record(path)
        assert record['bytes'] == entry['bytes'] and record['sha256'] == entry['sha256'], entry['path']
        assert record['mode'] == entry['mode'], entry['path']
        inputs[str(path)] = raw
        records.append(record)
    required = {'pytorch_sum_dims_probe.py', 'case-contract.json', 'primary-sources.json',
                'inputs/pytorch_oracle.py', 'inputs/pytorch-oracle-lock.json',
                'inputs/pytorch-install.json', 'inputs/upstream-lock.json',
                'inputs/original-view-reshape-probe.py'}
    required.update('upstream/' + path for path in SOURCE_PINS)
    assert required <= set(paths)
    assert inputs[str(root / 'pytorch_sum_dims_probe.py')] == Path(__file__).read_bytes()
    for name, pin in [('pytorch_oracle.py', SUPPORT_SHA), ('pytorch-oracle-lock.json', LOCK_SHA),
                      ('pytorch-install.json', PIP_SHA), ('upstream-lock.json', INVENTORY_SHA),
                      ('original-view-reshape-probe.py', PARENT_HELPER_SOURCE_SHA)]:
        assert sha(inputs[str(root / 'inputs' / name)]) == pin
    primary_index = json.loads(inputs[str(root / 'primary-sources.json')])
    assert primary_index['commit'] == SOURCE_REF and primary_index['files'] == SOURCE_PINS
    for relative, pin in SOURCE_PINS.items():
        raw = inputs[str(root / 'upstream' / relative)]
        assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256']
        git_blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        assert git_blob == pin['git_blob_sha1'], relative
    lock = json.loads(inputs[str(root / 'inputs/pytorch-oracle-lock.json')])
    assert lock['inventory_commit'] == SOURCE_REF
    external_pairs = [
        (args.repo / lock['oracle']['install_report'], root / 'inputs/pytorch-install.json'),
        (args.repo / 'compatibility/upstream-lock.json', root / 'inputs/upstream-lock.json'),
    ]
    for actual, frozen in external_pairs:
        raw, record = file_record(actual.resolve())
        assert raw == inputs[str(frozen)], str(actual)
        inputs[str(actual.resolve())] = raw
        records.append(record)
    plan = json.loads(inputs[str(root / 'case-contract.json')])
    assert plan['schema'] == 'heptatorch.sum-dims-f32-reference32.case-contract.v1'
    assert plan['status'] == 'SOURCE_ONLY_NOT_RUN' and plan['primary_source_ref'] == SOURCE_REF
    assert plan['case_count'] == 32 and len(plan['cases']) == 32
    assert plan['expected_outputs_present'] is False and plan['expected_gradients_present'] is False
    assert plan['expected_acceptance_present'] is False
    assert [row['index'] for row in plan['cases']] == list(range(32))
    assert len({row['name'] for row in plan['cases']}) == 32
    for row in plan['cases']:
        assert row['dtype'] == 'float32' and row['device'] == 'cpu'
        assert len(row['input_shape']) == len(row['input_stride']) <= 4
        assert all(type(d) is int and 0 <= d <= 262144 for d in row['input_shape'])
        assert all(type(s) is int and 0 <= s <= (2**63 - 1) // 4 for s in row['input_stride'])
        assert all(type(word) is int and 0 <= word <= 0xffffffff for word in row['backing_u32'])
        assert row['dim'] is None or (isinstance(row['dim'], list) and
                                     all(type(d) is int for d in row['dim']))
        assert type(row['keepdim']) is bool and row['dtype_argument'] in (None, 'float32')
    return root, inputs, records, plan, lock


def run(args, root, inputs, before_records, contract, lock):
    common = {
        'schema': 'heptatorch.sum-dims-f32-reference32.v1',
        'probe_sha256': sha(inputs[str(Path(__file__).resolve())]),
        'source_manifest_sha256': args.source_manifest_sha256,
        'primary_source_ref': SOURCE_REF, 'primary_source_pins': SOURCE_PINS,
        'primary_files_read_and_sha256_gitblob_verified': True,
        'case_contract_sha256': sha(inputs[str(root / 'case-contract.json')]),
        'case_plan': contract['cases'], 'planned_cases': 32,
        'native_executed': False, 'compiler_executed': False, 'native_qualified': False,
        'full_pytorch_rewrite_complete': False, 'pytorch_api_denominator': 2590,
        'closed_schema_count': 0, 'project_gates_remain_hold': True,
        'policy': 'OBSERVATION ONLY. No expected numeric outputs, gradients, acceptance, errors or lifetimes are synthesized.',
        'numeric_policy': 'Every F32 bit is recorded exactly. Different NaN payload/sign and signed zero remain distinct. No tolerance, nan canonicalization or comparison-to-HIA occurs.',
        'scope': 'CPU F32 concrete rank0-4 sum.dim_IntList; single-thread AVX512, fixed wheel and source. First-order AD; no out/inplace overload, dtype promotion, other backend or full schema closure.',
        'route_scope': 'Kernel route obligations are source-derived geometry classifications, not a dynamic dispatch trace or runtime proof.',
        'getter_order': 'Each live name: raw Tensor/Storage/layout/Version/requires/_base, grad_fn, is_leaf, retains_grad, grad. Then all current nodes, Saved getters and edge relations. The order is explicit and may refresh lazy ViewInfo.',
        'ownership_scope': 'Only live owns persistent named Tensor roots. Weak contains StorageWeakRef only. Snapshot Tensor/Function locals are released before return. No weak outcome is predicted.',
        'version_scope': 'Recorded Version integers and mutation observations do not by themselves expose a Version-counter address.',
        'inputs_before': before_records,
    }
    old_argv = sys.argv
    try:
        sys.argv = [str(root / 'inputs/pytorch_oracle.py'),
                    str(args.output_dir / 'NO_NATIVE_EXECUTABLE_USED'),
                    str(args.output_dir / 'provenance-failure-original.json'),
                    str(root / 'inputs/pytorch-oracle-lock.json')]
        context = runpy.run_path(str(root / 'inputs/pytorch_oracle.py'),
                                 run_name='sum_dims_reference_provenance_only')
    finally:
        sys.argv = old_argv
    torch, provenance = context['torch'], context['PROVENANCE']
    assert provenance['expected'] == lock['oracle']
    assert provenance['status'] == 'PASS' and set(provenance['checks']) == CHECKS
    assert all(value is True for value in provenance['checks'].values())
    assert torch.are_deterministic_algorithms_enabled()
    assert torch.utils.deterministic.fill_uninitialized_memory is True
    assert torch.get_num_threads() == 1
    assert torch.backends.cpu.get_cpu_capability() == 'AVX512'
    from torch.multiprocessing.reductions import StorageWeakRef
    states, rows, errors = {}, [], []

    def environment():
        return {'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
                'deterministic_fill': torch.utils.deterministic.fill_uninitialized_memory,
                'grad_enabled': torch.is_grad_enabled(), 'num_threads': torch.get_num_threads(),
                'cpu_capability': torch.backends.cpu.get_cpu_capability()}

    environment_before = environment()
    outer_rng = bytes(torch.get_rng_state().tolist())

    def rng():
        raw = bytes(torch.get_rng_state().tolist())
        assert len(raw) == 5056
        key = sha(raw)
        states.setdefault(key, {'bytes': len(raw), 'hex': raw.hex()})
        return key

    def capture(operation):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            try:
                value = operation()
                event = {'accepted': True, 'outcome': 'SUCCEEDED', 'error': None}
            except Exception as error:
                value = None
                event = {'accepted': False, 'outcome': 'RAISED',
                         'error': {'type': type(error).__name__, 'message': str(error)}}
        event['warnings'] = [{'type': type(w.message).__name__, 'message': str(w.message)} for w in caught]
        return value, event

    def raw_tensor(x):
        if x is None:
            return None
        storage = x.untyped_storage()
        raw = bytes(storage)
        width = x.element_size()
        shape, strides, offset = list(x.shape), list(x.stride()), x.storage_offset()
        logical = bytearray()
        for linear in range(x.numel()):
            quotient, at = linear, offset
            for size, stride in zip(reversed(shape), reversed(strides)):
                at += (quotient % size) * stride
                quotient //= size
            word = raw[at * width:at * width + width]
            assert len(word) == width
            logical.extend(word)
        base = x._base
        result = {'tensor_identity': str(x._cdata), 'storage_identity': str(storage._cdata),
                  'dtype': str(x.dtype), 'device': str(x.device), 'element_size': width, 'shape': shape, 'strides': strides,
                  'numel': x.numel(), 'storage_bytes': len(raw),
                  'storage_offset_elements': offset, 'storage_offset_bytes': offset * width,
                  'storage_raw_hex': raw.hex(), 'storage_sha256': sha(raw),
                  'logical_bytes_hex': bytes(logical).hex(), 'logical_sha256': sha(bytes(logical)),
                  'binary_words': [int.from_bytes(logical[i:i + width], 'little') for i in range(0, len(logical), width)],
                  'version': x._version, 'requires_grad': x.requires_grad, 'is_view': x._is_view(),
                  'base_tensor_identity': None if base is None else str(base._cdata)}
        del base, storage
        return result

    def primitive(value):
        if isinstance(value, torch.Tensor):
            return {'tensor': raw_tensor(value)}
        if value is None or isinstance(value, (bool, int, str)):
            return value
        if isinstance(value, float):
            return {'double_bits': struct.unpack('<Q', struct.pack('<d', value))[0]}
        if isinstance(value, (tuple, list)):
            return [primitive(item) for item in value]
        return {'type': type(value).__name__, 'diagnostic_repr': repr(value)}

    def node_info(fn, depth=4):
        if fn is None:
            return None
        result = {'kind': type(fn).__name__}
        if type(fn).__name__ == 'AccumulateGrad':
            variable = fn.variable
            result['variable'] = raw_tensor(variable)
            del variable
        if depth:
            result['next_edges'] = [{'output_nr': int(nr), 'node': node_info(child, depth - 1)}
                                    for child, nr in fn.next_functions]
        return result

    def saved_attributes(fn):
        if fn is None:
            return {}
        attributes = {}
        for name in sorted(n for n in dir(fn) if n.startswith('_saved_')):
            value, event = capture(lambda name=name: getattr(fn, name))
            if event['accepted']:
                event['value'] = primitive(value)
            del value
            attributes[name] = event
        return attributes

    def tensor_observation(x, weak):
        before = raw_tensor(x)
        fn, getter = capture(lambda: x.grad_fn)
        if getter['accepted']:
            getter['node'] = node_info(fn)
        del fn
        leaf, leaf_event = capture(lambda: x.is_leaf)
        if leaf_event['accepted']:
            leaf_event['value'] = bool(leaf)
        del leaf
        retained, retained_event = capture(lambda: x.retains_grad)
        if retained_event['accepted']:
            retained_event['value'] = bool(retained)
        del retained
        grad, grad_event = capture(lambda: x.grad)
        if grad_event['accepted']:
            grad_event['tensor'] = raw_tensor(grad)
            if grad is not None:
                key = 'observed_grad_storage_' + str(grad.untyped_storage()._cdata)
                if key not in weak:
                    weak[key] = StorageWeakRef(grad.untyped_storage())
        del grad
        return {'before_grad_fn_getter': before, 'grad_fn_getter': getter,
                'requires_grad_after_grad_fn_getter': x.requires_grad,
                'is_leaf_after_grad_fn_getter': leaf_event, 'retains_grad': retained_event,
                'gradient': grad_event}

    def snapshot(live, weak):
        names = list(live)
        tensors = {name: tensor_observation(live[name], weak) for name in names}
        relations = {}
        for left_name, right_name in itertools.combinations(names, 2):
            left, right = live[left_name], live[right_name]
            relations[left_name + '|' + right_name] = {
                'same_Python_object': left is right, 'same_Tensor': left._cdata == right._cdata,
                'same_Storage': left.untyped_storage()._cdata == right.untyped_storage()._cdata,
                'same_current_Version_value': left._version == right._version}
        if len(names) > 1:
            del left, right
        current, getters, saved, edges = {}, {}, {}, {}
        for name in names:
            fn, event = capture(lambda name=name: live[name].grad_fn)
            getters[name] = event
            if event['accepted']:
                current[name] = fn
            del fn
        for name, fn in current.items():
            saved[name] = saved_attributes(fn)
            edge_rows = []
            if fn is not None:
                for child, nr in fn.next_functions:
                    edge_rows.append({'output_nr': int(nr), 'node': node_info(child),
                                      'matches_live_current_grad_fn': [other for other, candidate in current.items()
                                                                     if child is not None and child is candidate]})
                    del child
            edges[name] = edge_rows
        # No Function or Tensor wrapper is returned or added to a persistent cache.
        if current:
            del fn
        current.clear()
        return {'tensor_getter_order': names, 'tensors': tensors, 'relations': relations,
                'saved_getters_after_tensor_getters': saved, 'edge_getters': getters,
                'edges_after_all_tensor_getters': edges,
                'expired': {name: ref.expired() for name, ref in weak.items()}, 'state': rng()}

    def make_seed(shape, words):
        count = 1
        for size in shape:
            count *= size
        assert count == len(words)
        signed = [word if word < 0x80000000 else word - 0x100000000 for word in words]
        # Intermediate int32 and dtype-view wrappers are temporary seed construction
        # only. The observed published seed is an ordinary nonview F32 clone.
        result = torch.tensor(signed, dtype=torch.int32).view(torch.float32).reshape(tuple(shape)).clone(
            memory_format=torch.contiguous_format)
        assert raw_tensor(result)['binary_words'] == words
        assert not result._is_view() and result._base is None
        return result


    def make_backing(spec):
        return make_seed(tuple(spec['backing_shape']), spec['backing_u32'])

    def observe(spec, row):
        torch.manual_seed(1729)
        live, weak, events = {}, {}, row['events']
        row['state_before_setup'] = rng()

        def event(label, operation, publish=None):
            before = snapshot(live, weak)
            value, result = capture(operation)
            result.update(label=label, before=before)
            if result['accepted']:
                result['returned'] = primitive(value)
                if isinstance(value, torch.Tensor):
                    result['returned_is_existing'] = {name: value is item for name, item in live.items()}
                if publish is not None:
                    assert isinstance(value, torch.Tensor), (label, type(value).__name__)
                    live[publish] = value
                    # Actual Python RHS-before-replacement Weak assignment.
                    weak[publish + '_storage'] = StorageWeakRef(value.untyped_storage())
            del value
            result['after'] = snapshot(live, weak)
            events.append(result)
            return result['accepted']

        def setup(label, operation, publish=None):
            accepted = event(label, operation, publish)
            if not accepted:
                row['setup_error'] = True
                row['remaining_not_attempted'] = 'setup operation raised: ' + label
            return accepted

        def drop(name):
            del live[name]
            gc.collect()

        def clear_grad(name):
            live[name].grad = None

        def fill(name, value):
            with torch.no_grad():
                return live[name].fill_(value)

        def publish_seed(phase_index, phase):
            if spec['seed_layout'] == 'strided_singletons':
                geometry = spec['seed_geometry']
                words = [phase['pattern_u32'][i % len(phase['pattern_u32'])]
                         for i in range(geometry['backing_elements'])]
                if not setup('construct_seed_backing_phase_' + str(phase_index),
                             lambda words=words: make_seed((len(words),), words),
                             publish='seed_backing'):
                    return False
                return setup('construct_seed_phase_' + str(phase_index),
                             lambda: torch.as_strided(live['seed_backing'],
                                                      tuple(geometry['shape']),
                                                      tuple(geometry['stride']),
                                                      geometry['storage_offset']),
                             publish='seed')
            # Only the actual output shape determines seed allocation. These
            # repeated literal words remain inputs, not computed gradients.
            observed_shape = tuple(live['result'].shape)
            words = [phase['pattern_u32'][i % len(phase['pattern_u32'])]
                     for i in range(live['result'].numel())]
            return setup('construct_seed_phase_' + str(phase_index),
                         lambda words=words, shape=observed_shape: make_seed(shape, words),
                         publish='seed')

        def hold_gradients(label, names):
            for name in names:
                if name in live and live[name].grad is not None:
                    event('hold_' + label + '_' + name + '_gradient',
                          lambda name=name: live[name].grad,
                          publish='held_' + label + '_' + name + '_grad')

        def recover_captured_leaf():
            fn = live['result'].grad_fn
            edge = None
            try:
                edge = fn.next_functions[0][0]
                return edge.variable
            finally:
                del edge, fn

        def recipe():
            if not setup('construct_backing', lambda: make_backing(spec), publish='backing'):
                return
            family = spec['family']
            if family in ('permuted_clone', 'nonleaf_mutation'):
                if not setup('backing_requires_grad_true', lambda: live['backing'].requires_grad_(True)):
                    return
                if family == 'permuted_clone':
                    if not setup('construct_permuted_middle',
                                 lambda: live['backing'].permute(tuple(spec['permutation'])),
                                 publish='middle'):
                        return
                    if not setup('construct_preserve_clone_input',
                                 lambda: live['middle'].clone(memory_format=torch.preserve_format),
                                 publish='input'):
                        return
                else:
                    if not setup('construct_input_factor',
                                 lambda: make_seed(tuple(spec['backing_shape']), spec['factor_u32']),
                                 publish='input_factor'):
                        return
                    if not setup('construct_nonleaf_mul_input',
                                 lambda: live['backing'] * live['input_factor'], publish='input'):
                        return
            elif family == 'expanded_detached_leaf':
                if not setup('construct_actual_expanded_view',
                             lambda: live['backing'].expand(tuple(spec['input_shape'])),
                             publish='expanded'):
                    return
                if not setup('detach_expanded_input', lambda: live['expanded'].detach(), publish='input'):
                    return
                if not setup('input_requires_grad_true', lambda: live['input'].requires_grad_(True)):
                    return
            else:
                if not setup('construct_detached_strided_input',
                             lambda: torch.as_strided(live['backing'], tuple(spec['input_shape']),
                                                      tuple(spec['input_stride']),
                                                      spec['input_storage_offset']).detach(),
                             publish='input'):
                    return
                if spec['requires_grad']:
                    if not setup('input_requires_grad_true', lambda: live['input'].requires_grad_(True)):
                        return

            def target():
                return torch.sum(live['input'], dim=spec['dim'], keepdim=spec['keepdim'],
                                 dtype=None if spec['dtype_argument'] is None else torch.float32)

            row['target_attempted'] = True
            row['target_accepted'] = event('sum_dim_IntList', target, publish='result')
            if not row['target_accepted']:
                row['remaining_not_attempted'] = 'actual target raised; no result Tensor exists'
                return
            gradient_names = [name for name in ('backing', 'middle', 'input', 'result')
                              if name in live and live[name].requires_grad]
            for name in gradient_names:
                if not live[name].is_leaf:
                    event('retain_grad_' + name, lambda name=name: live[name].retain_grad())
            if not live['result'].requires_grad:
                row['backward_not_attempted'] = 'actual result.requires_grad is false'
                return

            if family == 'lifetime':
                if not publish_seed(0, spec['seed_phases'][0]):
                    return
                event('drop_backing_before_backward', lambda: drop('backing'))
                event('drop_input_before_backward', lambda: drop('input'))
                event('backward_after_public_input_drops',
                      lambda: live['result'].backward(live['seed']))
                event('publish_actual_captured_leaf_after_backward',
                      recover_captured_leaf, publish='recovered_input')
                hold_gradients('after_drops', ['result', 'recovered_input'])
                event('drop_result_before_recovered_input', lambda: drop('result'))
                if 'recovered_input' in live:
                    event('drop_recovered_input', lambda: drop('recovered_input'))
                return

            if family == 'saved_error':
                wrong_shape = tuple(spec['wrong_seed_shape'])
                count = 1
                for size in wrong_shape:
                    count *= size
                wrong_words = [0x3f800000] * count
                if not setup('construct_wrong_geometry_seed',
                             lambda: make_seed(wrong_shape, wrong_words), publish='wrong_seed'):
                    return
                event('backward_wrong_seed_geometry',
                      lambda: live['result'].backward(live['wrong_seed'], retain_graph=True))
                if not publish_seed(0, spec['seed_phases'][0]):
                    return
                event('backward_valid_before_saved_construction',
                      lambda: live['result'].backward(live['seed'], retain_graph=True))
                hold_gradients('before_saved_error', gradient_names)
                for name in gradient_names:
                    event('clear_before_saved_error_' + name, lambda name=name: clear_grad(name))
                # This separate Tensor input is actual downstream Mul Saved.other.
                # Its words are inputs; no Saved rejection result is prefilled.
                factor_shape = tuple(live['result'].shape)
                factor_words = [0x40000000] * live['result'].numel()
                if not setup('construct_downstream_factor',
                             lambda: make_seed(factor_shape, factor_words), publish='saved_factor'):
                    return
                if not setup('construct_downstream_mul',
                             lambda: live['result'] * live['saved_factor'], publish='downstream'):
                    return
                event('retain_grad_downstream', lambda: live['downstream'].retain_grad())
                event('mutate_saved_factor_after_forward', lambda: fill('saved_factor', 42.))
                event('backward_after_saved_factor_mutation',
                      lambda: live['downstream'].backward(live['seed']))
                hold_gradients('after_saved_error', gradient_names + ['downstream'])
                return

            if family == 'nonleaf_mutation':
                event('mutate_sum_input_value_before_backward', lambda: fill('input', 42.))

            for phase_index, phase in enumerate(spec['seed_phases']):
                if phase_index:
                    for name in gradient_names:
                        event('clear_before_phase_' + str(phase_index) + '_' + name,
                              lambda name=name: clear_grad(name))
                    for name in ('seed', 'seed_backing'):
                        if name in live:
                            event('drop_' + name + '_before_phase_' + str(phase_index),
                                  lambda name=name: drop(name))
                if not publish_seed(phase_index, phase):
                    return
                retain = phase_index + 1 < len(spec['seed_phases'])
                event('backward_phase_' + str(phase_index) + '_' + phase['name'],
                      lambda retain=retain: live['result'].backward(live['seed'], retain_graph=retain))
                hold_gradients('phase_' + str(phase_index), gradient_names)
            if spec['retry_after_default'] and 'seed' in live:
                event('backward_retry_after_default',
                      lambda: live['result'].backward(live['seed']))
                hold_gradients('after_retry', gradient_names)
            if spec['mutate_result']:
                event('mutate_result_to_observe_version_and_alias', lambda: fill('result', 42.))

        try:
            recipe()
        except BaseException as error:
            row['probe_error'] = {'type': type(error).__name__, 'message': str(error),
                                  'traceback': traceback.format_exc()}
        # The exception wrapper is gone before weak-final observations.
        row['before_final_drops'] = snapshot(live, weak)
        for name in list(live):
            event('final_drop_' + name, lambda name=name: drop(name))
        assert not live
        gc.collect()
        row['final_expired'] = {name: ref.expired() for name, ref in weak.items()}
        row['state_after'] = rng()
        row['status'] = ('PROBE_ERROR' if row['probe_error'] is not None else
                         'SETUP_ERROR' if row['setup_error'] else 'OBSERVED')
        return row

    with torch.random.fork_rng(devices=[]):
        for spec in contract['cases']:
            row = {**spec, 'status': 'STARTED', 'events': [],
                   'target_attempted': False, 'target_accepted': None,
                   'setup_error': False, 'probe_error': None}
            try:
                observe(spec, row)
            except BaseException as error:
                row.update(status='PROBE_ERROR',
                           probe_error={'type': type(error).__name__, 'message': str(error),
                                        'traceback': traceback.format_exc()},
                           partial_cleanup_not_observed=True)
            rows.append(row)
            if row['status'] != 'OBSERVED':
                errors.append({'index': spec['index'], 'name': spec['name'],
                               'status': row['status'], 'probe_error': row.get('probe_error')})
    environment_after = environment()
    outer_rng_restored = bytes(torch.get_rng_state().tolist()) == outer_rng
    after_records, changed_inputs = [], []
    for before in before_records:
        path = Path(before['path'])
        try:
            raw, record = file_record(path)
            after_records.append(record)
            if raw != inputs[str(path)] or record != before:
                changed_inputs.append({'before': before, 'after': record})
        except BaseException as error:
            changed_inputs.append({'before': before,
                                   'read_error': {'type': type(error).__name__, 'message': str(error)}})
    operation_totals = {'attempted': 0, 'succeeded': 0, 'raised': 0}
    backward_totals = {'attempted': 0, 'succeeded': 0, 'raised': 0}
    targets = {'attempted': 0, 'accepted': 0, 'raised': 0, 'not_attempted': 0}
    for row in rows:
        if row.get('target_attempted'):
            targets['attempted'] += 1
            targets['accepted' if row.get('target_accepted') else 'raised'] += 1
        else:
            targets['not_attempted'] += 1
        for item in row.get('events', []):
            operation_totals['attempted'] += 1
            operation_totals['succeeded' if item['accepted'] else 'raised'] += 1
            if item['label'].startswith('backward_'):
                backward_totals['attempted'] += 1
                backward_totals['succeeded' if item['accepted'] else 'raised'] += 1
    complete = (not errors and len(rows) == 32 and not changed_inputs and
                environment_before == environment_after and outer_rng_restored)
    report = {
        **common, 'status': 'OBSERVED' if complete else 'OBSERVATION_INCOMPLETE',
        'torch_executed': True, 'oracle_provenance': provenance,
        'build_configuration': torch.__config__.show(),
        'cpu_capability': torch.backends.cpu.get_cpu_capability(), 'num_threads': torch.get_num_threads(),
        'environment_before': environment_before, 'environment_after': environment_after,
        'environment_restored_within_probe': environment_before == environment_after,
        'rng_restore_scope': 'State immediately after the fixed support initialized its documented environment.',
        'original_outer_rng_restored': outer_rng_restored,
        'source_files_unchanged': not changed_inputs, 'inputs_after': after_records,
        'changed_inputs': changed_inputs, 'cases': len(rows), 'rows': rows,
        'states': states, 'unique_complete_states': len(states),
        'probe_errors': errors, 'probe_error_count': sum(r['status'] == 'PROBE_ERROR' for r in rows),
        'setup_error_count': sum(r['status'] == 'SETUP_ERROR' for r in rows),
        'operation_totals': operation_totals, 'backward_totals': backward_totals,
        'target_totals': targets, 'observation_is_not_native_qualification': True,
    }
    raw = (json.dumps(report, indent=2, allow_nan=False) + '\n').encode()
    output = args.output_dir / 'actual.json'
    with output.open('xb') as handle:
        handle.write(raw)
    print(json.dumps({'status': report['status'], 'cases': len(rows),
                      'actual_bytes': len(raw), 'actual_sha256': sha(raw),
                      'target_totals': targets, 'backward_totals': backward_totals,
                      'probe_error_count': report['probe_error_count'],
                      'setup_error_count': report['setup_error_count']}, allow_nan=False))
    return 0 if complete else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--source-manifest', type=Path, required=True)
    parser.add_argument('--source-manifest-sha256', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    args.repo = args.repo.resolve()
    args.output_dir = args.output_dir.resolve()
    assert Path.cwd().resolve() == args.repo
    assert not args.output_dir.exists(), str(args.output_dir)
    args.output_dir.mkdir(parents=True, exist_ok=False)
    phase = 'input_binding_before_torch'
    try:
        root, inputs, before, contract, lock = bind_inputs(args)
        phase = 'actual_observation'
        return run(args, root, inputs, before, contract, lock)
    except BaseException as error:
        failure = {
            'schema': 'heptatorch.sum-dims-f32-reference32.failure.v1',
            'status': 'NOT_RUN' if phase == 'input_binding_before_torch' else 'PROBE_ERROR',
            'phase': phase, 'native_executed': False, 'compiler_executed': False,
            'torch_executed': False if phase == 'input_binding_before_torch' else None,
            'torch_execution_note': 'If phase is actual_observation, inspect original support output; no completed status is inferred.',
            'error': {'type': type(error).__name__, 'message': str(error),
                      'traceback': traceback.format_exc()},
        }
        with (args.output_dir / 'failure.json').open('x') as handle:
            handle.write(json.dumps(failure, indent=2, allow_nan=False) + '\n')
        raise


if __name__ == '__main__':
    raise SystemExit(main())
