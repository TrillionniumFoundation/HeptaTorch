# Integral sum reference24 — source only

This is a new fixed PyTorch observation program for the immutable 24 recipes in
case-contract.json. No program in this package has been parsed, imported or run.
No Torch/native/compiler/emitter/process was started while preparing it.

## Exact observations

The input words are byte-level inputs, never expected outputs. I64 values enter
through unsigned 64-bit hex and little-endian pack, without a float conversion.
The four dimension-error inputs remain in the denominator. Both overflow inputs
are mandatory and have no host-computed expected sums. Empty construction uses
real torch.empty(0), not torch.frombuffer on an empty buffer.

Every successful result is followed by an actual requires_grad_(True) attempt,
an explicit torch.ones_like integer seed, and an actual backward attempt. The
probe records the real acceptance/error/Version/Storage changes; it does not
infer these outcomes from dtype. It keeps a real held_result alias, then drops
input, backing, result, seed and held_result in explicit events. Weak Tensor and
Storage observations follow complete getter snapshots, with no persistent
getter Tensor or Function cache.

Nine original observation helpers are byte-identical. A new outer snapshot
adds Python weakref liveness after those unchanged helpers have returned.
probe-inverse.json contains a complete 21-edit forward and inverse derivation
from the exact original 32-case probe, including the new independent recipe.
helper-inheritance.json records each unchanged helper's complete source hash.

## Binding and execution scope

The later actual run must bind this complete package, all 38 files of the frozen
original reference package and all 26 files of the frozen integral source
package, plus the installed pip report and source inventory. Twelve complete
original upstream files and six integral primary files are SHA256/Git-blob
verified. The fixed original 11 provenance assertions, one CPU thread, AVX512,
deterministic mode and deterministic fill remain strict.

The executable and arguments are in a separately frozen request candidate. It
has not been submitted. It uses the existing fixed Python 3.12 Torch environment;
it neither forces an instruction set nor swaps a wheel. A machine/provenance
mismatch is a refusal, not an AVX2 substitute.

OBSERVED is only a complete actual-reference record. Native qualification needs
a separately emitted and compiled integral image, full exact 24-case comparison,
the strict native-owner/raw/EOF gates, and required same-image inherited suites.
The qualified 696-function parent is not an integral result. All new
source/image/build identities remain pending until real emission/build. The
complete 2,590-schema project remains HOLD.
