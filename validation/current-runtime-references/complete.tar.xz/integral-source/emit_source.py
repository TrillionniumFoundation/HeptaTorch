"""Future source-emission entry for bounded Bool/I64 sum.dim_IntList.

Delivered SOURCE ONLY. This entry has not been parsed, imported, emitted or run.
A later authorized invocation performs source emission only; no compiler, native
Tensor process or Torch process is constructed by this program.
"""
import argparse
import json
import re
import stat
import sys
import traceback
from pathlib import Path
from authoring_support import CALL, EXTERNAL, functions, sha
from parent_emitter import ParentEmitter
from sum_integral_overlay import apply, record_inverse, SOURCE_PINS, PARENT_SOURCE, PARENT_IMAGE, PARENT_BUILD, PARENT_EMISSION_MANIFEST, STATE, BACKING

HERE = Path(__file__).resolve().parent

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def metadata(path, raw):
    assert not path.is_symlink() and path.is_file()
    return {'bytes': len(raw), 'sha256': sha(raw), 'mode': stat.S_IMODE(path.stat().st_mode)}

def verify_package(path, expected_sha256):
    path = path.resolve()
    raw = path.read_bytes()
    assert sha(raw) == expected_sha256 and path.parent == HERE
    manifest = json.loads(raw)
    assert manifest['schema'] == 'heptatorch.sum-integral.source-handoff.v1'
    assert manifest['status'] == 'SOURCE_ONLY_NOT_EXECUTED'
    assert len(manifest['files']) == manifest['payload_count']
    names = set(manifest['files']) | {path.name}
    found = {str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()}
    assert not any(p.is_symlink() for p in HERE.rglob('*'))
    assert found == names, (sorted(found - names), sorted(names - found))
    inputs = {path: (raw, metadata(path, raw))}
    for name, item in manifest['files'].items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        item_path = HERE / relative
        item_raw = item_path.read_bytes()
        actual = metadata(item_path, item_raw)
        assert actual == item, (item_path, actual, item)
        inputs[item_path.resolve()] = (item_raw, actual)
    return manifest, inputs

def source_units(emitter, combined):
    ordered, done, active = [], set(), set()
    def visit(name):
        if name in EXTERNAL:
            return
        assert name in combined, ('missing function', name)
        assert name not in active, ('recursive function', name)
        if name in done:
            return
        active.add(name)
        for target in sorted({n.decode() for n in CALL.findall(combined[name])}):
            visit(target)
        active.remove(name)
        done.add(name)
        ordered.append(name)
    for name in combined:
        visit(name)
    groups, group, instructions, blocks = [], [], 0, 0
    for name in ordered:
        body = combined[name]
        ni, nb = body.count(b' = '), len(re.findall(rb'^block ', body, re.M))
        if group and (instructions + ni > 3600 or blocks + nb > 1000 or len(group) >= 65):
            groups.append(group)
            group, instructions, blocks = [], 0, 0
        group.append(name)
        instructions += ni
        blocks += nb
    if group:
        groups.append(group)
    units = [('rng03', emitter.rng_raw)]
    for index, names in enumerate(groups):
        imports = sorted({n.decode() for name in names for n in CALL.findall(combined[name])} - set(names))
        assert len(names) + len(imports) <= 256, (index, len(names), len(imports))
        declarations = []
        for name in imports:
            body = emitter.rng[name] if name in EXTERNAL else combined[name]
            declaration = re.sub(rb' entry\(\w+\)$', b' external()', body.split(b'\n')[0]) + b'\n'
            declarations.append(declaration)
        unit_name = f'sum_integral_{index:02d}'
        raw = (f'hia-asm.v1 hepta.hia.program.v8 {unit_name}\nexports({",".join(names)})\n'.encode()
               + b''.join(declarations) + b''.join(combined[name] for name in names))
        units.append((unit_name, raw))
    units.append(('owners', emitter.owner_raw))
    return units


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('previous', 'repository', 'upstream', 'compactor', 'parent-emission-manifest', 'package-manifest', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--package-manifest-sha256', required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    report = {
        'schema': 'heptatorch.sum-integral.source-emission.v1',
        'status': 'EMISSION_STARTED', 'argv': list(sys.argv), 'interpreter': sys.executable,
        'parent_source_sha256': PARENT_SOURCE, 'parent_native_sha256': PARENT_IMAGE,
        'parent_build_sha256': PARENT_BUILD,
        'parent_emission_manifest_sha256': PARENT_EMISSION_MANIFEST,
        'package_manifest_sha256': args.package_manifest_sha256,
        'state_format': STATE, 'backing_format': BACKING, 'descriptor_bytes': 672,
        'public_command_extended': 115, 'new_public_commands': [], 'new_autograd_operations': [],
        'compiler_executed': False, 'native_executed': False, 'torch_executed': False,
        'numeric_expectations_computed_by_host': False,
        'runtime_qualified': False, 'schema_closure': False, 'full_project_status': 'HOLD',
        'units': [],
    }
    write_json(output / 'report.json', report)
    emitter, package_inputs = None, {}
    try:
        manifest, package_inputs = verify_package(args.package_manifest, args.package_manifest_sha256)
        author_names = manifest['author_files']
        assert set(author_names) == {'authoring_support.py', 'parent_emitter.py',
                                    'sum_integral_overlay.py', 'emit_source.py', *SOURCE_PINS}
        own = {name: package_inputs[(HERE / name).resolve()][0] for name in author_names}
        for name, raw in own.items():
            (output / name).write_bytes(raw)
        emitter = ParentEmitter(args.previous.resolve(), args.repository.resolve(),
                                args.upstream.resolve(), args.compactor.resolve(),
                                args.parent_emission_manifest.resolve())
        combined = apply(emitter, dict(emitter.parent), {name: own[name] for name in SOURCE_PINS}, output)
        runtime = b'hia-asm.v1 hepta.hia.program.v8 sum_integral_runtime\n' + b''.join(combined.values())
        inverse = record_inverse(emitter, combined, runtime, output)
        assert len(combined) == 699
        (output / 'runtime.hepta').write_bytes(runtime)
        write_json(output / 'source-map.json', [
            {'name': name, 'sha256': sha(body),
             'parent_sha256': sha(emitter.parent[name]) if name in emitter.parent else None,
             'unchanged_parent': emitter.parent.get(name) == body}
            for name, body in combined.items()
        ])
        for name, raw in source_units(emitter, combined):
            (output / (name + '.hepta')).write_bytes(raw)
            report['units'].append({
                'name': name, 'source_sha256': sha(raw), 'bytes': len(raw),
                'functions': len(functions(raw)), 'blocks': len(re.findall(rb'^block ', raw, re.M)),
                'instructions': raw.count(b' = '), 'compiler_executed': False,
            })
        emitter.unchanged()
        for path, (before, item) in package_inputs.items():
            assert path.read_bytes() == before and metadata(path, before) == item, path
        report.update(
            status='SOURCE_EMITTED_NOT_COMPILED', source_sha256=sha(runtime),
            functions=len(combined), blocks=len(re.findall(rb'^block ', runtime, re.M)),
            instructions=runtime.count(b' = '), units_planned=len(report['units']),
            source_transition={'old_functions': 696, 'current_functions': 699,
                               'unchanged': 691, 'modified': 5, 'added': 3,
                               'whole_forward_exact': inverse['whole_forward_exact'],
                               'whole_inverse_exact': inverse['whole_inverse_exact'],
                               'inverse_sha256': sha((output / 'sum03-to-integral01-body-inverse.json').read_bytes())},
            parent_inputs= {str(path): item for path, item in emitter.input_metadata.items()},
            package_inputs={str(path): item for path, (_, item) in package_inputs.items()},
            all_inputs_unchanged=True, compactor_records=emitter.checks,
        )
        write_json(output / 'report.json', report)
        members = {p.name for p in output.iterdir() if p.is_file()}
        expected = set(author_names) | {unit['name'] + '.hepta' for unit in report['units']} | {
            'runtime.hepta', 'source-map.json', 'sum-integral-fragment.hepta',
            'sum-integral-source-custody.json', 'sum03-to-integral01-body-inverse.json', 'report.json'}
        assert members == expected and all(p.is_file() and not p.is_symlink() for p in output.iterdir())
        inventory = {name: metadata(output / name, (output / name).read_bytes()) for name in sorted(members)}
        write_json(output / 'emission-inventory.json', {
            'schema': 'heptatorch.sum-integral.emission-inventory.v1',
            'status': 'EMISSION_OUTPUT_BYTES_RECORDED_NOT_INDEPENDENTLY_ADMITTED',
            'files': inventory, 'file_count': len(inventory),
            'only_self_exclusion': 'emission-inventory.json',
            'functions': 699, 'units': len(report['units']),
            'source_sha256': sha(runtime), 'compiler_executed': False,
            'native_executed': False, 'torch_executed': False,
        })
        print(json.dumps({key: report[key] for key in
              ('status', 'source_sha256', 'functions', 'blocks', 'instructions', 'units_planned')}))
        return 0
    except BaseException as error:
        report.update(status='SOURCE_EMISSION_FAIL', error=repr(error), traceback=traceback.format_exc(),
                      input_recheck_errors=[])
        for path, (before, item) in package_inputs.items():
            try:
                assert path.read_bytes() == before and metadata(path, before) == item
            except BaseException as failure:
                report['input_recheck_errors'].append({'path': str(path), 'error': repr(failure)})
        if emitter is not None:
            for path, before in emitter.inputs.items():
                try:
                    assert path.read_bytes() == before and metadata(path, before) == emitter.input_metadata[path]
                except BaseException as failure:
                    report['input_recheck_errors'].append({'path': str(path), 'error': repr(failure)})
        write_json(output / 'report.json', report)
        print(report['traceback'], file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
