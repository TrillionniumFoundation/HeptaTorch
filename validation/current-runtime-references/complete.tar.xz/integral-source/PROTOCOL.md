# Integral SumDims candidate protocol

Status: SOURCE ONLY. No AST/import, emitter, compiler, native Tensor or Torch run has been performed for this candidate. The complete project and sum schema remain HOLD/OPEN.

## Existing command extended

The eight little-endian u64 command words remain:

`[115, public_tensor, axis_count, axes_payload_offset, keepdim, dtype, 0, 0]`

The current entry maximum remains117. No command118 or additional AD operation is introduced.

- `axis_count = 18446744073709551615` means None; `axis_count = 0` means []; each requires offset0.
- Otherwise count1..4 and a complete count*8 byte payload are required. Payload words preserve original signed64 axis spelling. The existing `sd_axis_mask` handles negative normalization, duplicates, rank0 effective-rank1 and range errors before command scratch is cleared.
- `keepdim` is0 or1.
- Wire dtype0 is F32;2 is I64; `18446744073709551615` is None.
- The last two words remain zero. Existing packet extent, completepayload and error checks remain.

The new supported rows are Bool(code1) or I64(code2) input with dtypeNone orI64, producing I64. All existing F32+None/F32 calls use the original `sd_sum_tensor` and complete F32 TI kernel. Bool/I64+explicitF32, explicitBool, F32+explicitI64, and other dtypes remain unsupported; PyTorch can support some of them, so their native refusal is a declared limitation, not parity.

## Bounded geometry

Rank0..4, dimensions and total input/output numel at most262144, nonnegative element strides at most1152921504606846975. Zero strides, overlap, holes and nonzero offsets are allowed when the existing typed input capability and storage extent are valid. No negative-stride tensor or generic device/layout domain is claimed.

The result shape is computed from the normalized mask. Reduced dimensions disappear or become1 according to keepdim. Empty dimensions are detected before division/product checks. The existing 384-byte scratch at w[2048:2432] is reused and cleared on every outer command return.

## Value representation and ownership

I64 values are always raw64-bit words. Bool input words are promoted from canonical0/1. The kernel executes actual HIA `int.add.wrap` via u64 addition. It never calls F32/F64 conversion, an old floating reduction, host Python sum or a precomputed expected-value table.

`typed_descriptor(w, result_rank, result_sizes, 0, 1, 2)` creates a genuine I64 Tensor with fresh Storage/Version; full8bytes per logical output are initialized and written with the original `typed_store`. Typed logical reads go through original `tget/taddr`, respecting the input's actual strides and offset.

Integer results do not call `record(...,47,...)`, capture an AD input edge, save the input Tensor, install an AccumulateGrad or change input Version. No new owner fields are used. `shape_command_finish` and `publish_tensor` are the original generic typed publication path and remain byte-identical.

The public response remains the original32-byte record:
`[115, status, public_result_token_or_zero, 0]`.
The framework's existing frame/command rollback contract remains unchanged.

## State identity

Prospective outer format HTSINT01; backing format HTOSIN01; descriptor672B/84Q unchanged. Actual emitted runtime and ELF hashes, unit count, compile report and runtime qualifications are PENDING.

New functions: si_plan, si_sum_integral, si_dispatch_sum.
Existing functions changed: to_command plus four state-tag functions.
All691 remaining parent bodies, including every F32 arithmetic/kernel/AD/allocator/release function, must remain exact when the future emitter runs. Expected699 functions is a source assertion, not an emitted result.

## Evidence and limits

The fixed upstream is PyTorch2.15.0 commit31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457. ReduceOpsUtils promotes integral includingBool toLong; CPU make_reduction casts to output dtype; the integral SumKernel dispatch uses binary_kernel_reduce_vec with zero identity and integral addition.

Modulo64 associativity motivates this independent logical traversal. The signed-overflow cases are mandatory future actual observations. C++ source addition is not a cross-platform overflow proof. Empty-output Version, errors/publication, exactStorage bytes, owner invariants and weak lifetime are also pending actual qualification. Internal Bool-cast temporary memory footprint and allocation-failure equivalence are not claimed.

The24-case contract contains inputs and observation obligations only. It supplies no expected numeric output. Values, exceptions and identity relations must come from a future fixed Torch run before a native comparison is admitted.
