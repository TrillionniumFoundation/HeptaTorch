"""Frozen Sum03 parent and real typed-storage source loader for future emission."""
import importlib.util
import json
import stat
import sys
from pathlib import Path
from authoring_support import Emitter, functions, sha, RNG, OWNERS
from sum_integral_overlay import PARENT_SOURCE, PARENT_IMAGE, PARENT_BUILD, PARENT_EMISSION_MANIFEST

class ParentEmitter(Emitter):
    def __init__(self, previous, repository, upstream, compactor, emission_manifest):
        self.inputs, self.input_metadata = {}, {}
        def read(path, pin=None, size=None, mode=None):
            path = Path(path)
            assert not path.is_symlink() and path.is_file(), path
            path = path.resolve()
            before = path.stat()
            assert stat.S_ISREG(before.st_mode)
            raw = path.read_bytes()
            after = path.stat()
            assert (before.st_size, before.st_mtime_ns, before.st_ctime_ns,
                    stat.S_IMODE(before.st_mode)) == (
                   after.st_size, after.st_mtime_ns, after.st_ctime_ns,
                   stat.S_IMODE(after.st_mode)), path
            if pin is not None:
                assert sha(raw) == pin, (path, sha(raw), pin)
            if size is not None:
                assert len(raw) == size, path
            if mode is not None:
                assert stat.S_IMODE(after.st_mode) == mode, path
            metadata = {'bytes': len(raw), 'sha256': sha(raw), 'mode': stat.S_IMODE(after.st_mode)}
            if path in self.inputs:
                assert self.inputs[path] == raw and self.input_metadata[path] == metadata
            self.inputs[path], self.input_metadata[path] = raw, metadata
            return raw
        self.read_bound = read
        self.parent_raw = read(previous / 'runtime.hepta', PARENT_SOURCE, 2290899, 0o600)
        self.parent = functions(self.parent_raw)
        read(previous / 'tensor-sum-dims-session', PARENT_IMAGE, 3571712, 0o500)
        build = json.loads(read(previous / 'build.json', PARENT_BUILD, 78702, 0o600))
        assert build['schema'] == 'heptatorch.sum-dims-f32.native-build.v4'
        assert build['source_revision'] == '04' and build['status'] == 'PASS_NATIVE_BUILD_ONLY'
        assert build['source_sha256'] == PARENT_SOURCE and build['native_sha256'] == PARENT_IMAGE
        assert build['descriptor_bytes'] == 672 and build['functions'] == 696
        assert build['state_format'] == 'HTSUM003' and build['backing_format'] == 'HTOSUM03'
        assert build['units_planned'] == build['units_compiled'] == len(build['units']) == 14
        assert build['objects_reused'] is False and build['all_inputs_unchanged'] is True
        assert build['result_executable_executed'] is False and build['torch_executed'] is False
        assert len(build['processes']) == 15 and build['link_exit'] == 0
        assert len({unit['name'] for unit in build['units']}) == 14
        for unit in build['units']:
            read(previous / (unit['name'] + '.hepta'), unit['source_sha256'])
            read(previous / (unit['name'] + '.o'), unit['object_sha256'])
        self.rng_raw = read(previous / 'rng03.hepta', RNG)
        self.owner_raw = read(previous / 'owners.hepta', OWNERS)
        self.rng = functions(self.rng_raw)
        assert len(self.parent) == 696 and len(self.rng) == 17
        manifest = json.loads(read(emission_manifest, PARENT_EMISSION_MANIFEST, 9921, 0o600))
        assert manifest['source_sha256'] == PARENT_SOURCE and manifest['functions'] == 696
        assert manifest['unit_count'] == 14 and manifest['file_count'] == len(manifest['files']) == 30
        directory = Path(manifest['emission_directory']).resolve()
        regular = {str(path.relative_to(directory)) for path in directory.rglob('*') if path.is_file()}
        assert not any(path.is_symlink() for path in directory.rglob('*'))
        assert regular == set(manifest['files']), (sorted(regular - set(manifest['files'])),
                                                  sorted(set(manifest['files']) - regular))
        for name, item in manifest['files'].items():
            relative = Path(name)
            assert not relative.is_absolute() and '..' not in relative.parts
            read(directory / relative, item['sha256'], item['bytes'], item['mode'])
        assert manifest['source02_transition'] == build['source02_transition_admission']
        self.parent_emission_manifest = manifest
        emitter_path = repository / 'tools/owned_tensors/authoring.py'
        read(emitter_path, '2845fc2e3f03ccbadd5ea6c59734d0be6db6477bf8434d288259fab5ee570ba6')
        profile = json.loads(read(repository / 'tools/owned_tensors/profile.json',
            '69642a730f9da8567a01cc5afd9d15963a49ff1ab83f7761039bb301d0d2d242'))
        read(compactor, '36730b55b58c29b210d921a426c62eab50d9f579ad5d7a1e4199b38799218f37')
        for name, pin in profile['upstream_authoring_sources'].items():
            read(upstream / name, pin)
        sys.path.insert(0, str(upstream))
        spec = importlib.util.spec_from_file_location('sum_integral_native_emitter', emitter_path)
        self.emitter = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.emitter)
        spec = importlib.util.spec_from_file_location('sum_integral_bounded_compactor', compactor)
        self.compactor = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.compactor)
        self.context, self.signatures, self.checks = [], {}, []
        for name, body in {**self.parent, **self.rng}.items():
            self.add_context(name, body)

    def unchanged(self):
        # Stronger metadata custody supplements the unchanged parent Emitter.
        super().unchanged()
        for path, item in self.input_metadata.items():
            assert not path.is_symlink() and path.is_file()
            assert stat.S_IMODE(path.stat().st_mode) == item['mode'], path
            assert len(self.inputs[path]) == item['bytes'] and sha(self.inputs[path]) == item['sha256']
