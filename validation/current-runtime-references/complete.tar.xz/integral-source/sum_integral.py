# Isolated SOURCE-ONLY integral extension of the frozen 696-function Sum03.
# These are HIA NativeBuilder functions. No host Tensor or expected-value model.
# Scope: canonical Bool or I64 input, None/I64 dtype, CPU rank 0..4.
# The existing F32 SumDims body and its complete TensorIterator kernel are unchanged.

def si_plan(w: mutbuf, source: u64, mask: u64, keepdim: u64, plan: u64) -> u64:
    p=dptr(w,source)
    rank=getw(w,p)
    dtype=getw(w,p+576)
    if rank>4 or keepdim>1 or mask>=(1<<rank):
        return terror(w,7)
    if dtype!=1 and dtype!=2:
        return terror(w,7)
    if getw(w,p+32)!=0 or getw(w,p+8)>262144:
        return terror(w,7)
    memory_fill(w,plan,384,0)
    putw(w,plan,2)
    putw(w,plan+8,rank)
    putw(w,plan+16,mask)
    putw(w,plan+24,keepdim)
    putw(w,plan+40,getw(w,p+8))
    output_rank=0
    output_empty=0
    input_empty=0
    axis=0
    while axis<rank:
        size=getw(w,p+96+8*axis)
        stride=getw(w,p+128+8*axis)
        # Bounded nonnegative element strides, including zero and holes.
        # Eight-byte conversion cannot overflow signed int64 in this scope.
        if size>262144 or stride>1152921504606846975:
            return terror(w,7)
        putw(w,plan+96+8*axis,size)
        if size==0:
            input_empty=1
        if ((mask>>axis)&1)==0 or keepdim!=0:
            result_size=size
            if ((mask>>axis)&1)!=0:
                result_size=1
            putw(w,plan+64+8*output_rank,result_size)
            if result_size==0:
                output_empty=1
            output_rank=output_rank+1
        axis=axis+1
    input_numel=1
    if input_empty!=0:
        input_numel=0
    else:
        axis=0
        while axis<rank:
            size=getw(w,plan+96+8*axis)
            if input_numel>262144//size:
                return terror(w,3)
            input_numel=input_numel*size
            axis=axis+1
    if input_numel!=getw(w,p+8):
        return terror(w,9)
    output_numel=1
    if output_empty!=0:
        output_numel=0
    else:
        axis=0
        while axis<output_rank:
            size=getw(w,plan+64+8*axis)
            if output_numel>262144//size:
                return terror(w,3)
            output_numel=output_numel*size
            axis=axis+1
    putw(w,plan+32,output_rank)
    putw(w,plan+48,output_numel)
    return 1

def si_sum_integral(w: mutbuf, source: u64, dimension_count: u64, dimensions: u64, keepdim: u64, dtype: u64, plan: u64) -> u64:
    if dtype!=2 and dtype!=18446744073709551615:
        return terror(w,7)
    if valid(w,source)==0:
        return 0
    p=dptr(w,source)
    mask=sd_axis_mask(w,getw(w,p),dimension_count,dimensions)
    if getw(w,0)!=0:
        return 0
    # sd_axis_mask consumes all original signed axis words before scratch clears.
    if si_plan(w,source,mask,keepdim,plan)==0:
        return 0
    # typed_descriptor parameters: rank, sizes, requires, own_storage, dtype.
    # New output has a genuine eight-byte Storage and independent Version.
    result=typed_descriptor(w,getw(w,plan+32),plan+64,0,1,2)
    if result==0:
        return 0
    q=dptr(w,result)
    if getw(w,q+576)!=2 or getw(w,q+8)!=getw(w,plan+48):
        return terror(w,9)
    index=0
    while index<getw(w,plan+48):
        if typed_store(w,taddr(w,result,index),8,0)==0:
            return 0
        index=index+1
    # All arithmetic below is actual HIA u64 int.add.wrap. No float conversion,
    # Python sum, precomputed result, sequential F32 reduction or host oracle.
    # Fixed-platform signed-overflow parity still requires a future raw-bit run.
    rank=getw(w,plan+8)
    input_dtype=getw(w,p+576)
    index=0
    while index<getw(w,plan+40):
        remaining=index
        output_index=0
        output_step=1
        axis=rank
        while axis>0:
            axis=axis-1
            size=getw(w,plan+96+8*axis)
            # Nonempty input was shape-validated, so each size is nonzero here.
            coordinate=remaining%size
            remaining=remaining//size
            if ((mask>>axis)&1)==0:
                output_index=output_index+coordinate*output_step
                output_step=output_step*size
        if output_index>=getw(w,plan+48):
            return terror(w,9)
        item=tget(w,source,index)
        if getw(w,0)!=0:
            return 0
        if input_dtype==1:
            if item!=0:
                item=1
        accumulated=tget(w,result,output_index)
        if getw(w,0)!=0:
            return 0
        if typed_store(w,taddr(w,result,output_index),8,accumulated+item)==0:
            return 0
        index=index+1
    # Integer output is not differentiable. Do not record op47, retain a
    # source/Saved edge, create an AccumulateGrad, or mutate source Version.
    memory_fill(w,plan,384,0)
    return result

def si_dispatch_sum(w: mutbuf, token: u64, dimension_count: u64, dimensions: u64, keepdim: u64, dtype: u64, plan: u64) -> u64:
    # Explicit F32 calls take the unchanged parent body, including refusals.
    if dtype==0:
        return sd_sum_tensor(w,token,dimension_count,dimensions,keepdim,dtype,plan)
    source=public_node(w,token)
    if source==0:
        return 0
    input_dtype=getw(w,dptr(w,source)+576)
    if input_dtype==1 or input_dtype==2:
        return si_sum_integral(w,source,dimension_count,dimensions,keepdim,dtype,plan)
    # public_node only validates the public T capability; it is not the lazy
    # AD getter. F32 None keeps the original to_view_public refresh exactly.
    if dtype==18446744073709551615:
        return sd_sum_tensor(w,token,dimension_count,dimensions,keepdim,dtype,plan)
    return terror(w,7)
