def to_command(r: readbuf, out: mutbuf, w: mutbuf, command: u64, response: u64, payload_start: u64) -> u64:
    operation=getr(r,command)
    if operation==116:
        return sd_permute_command(r,out,w,command,response,payload_start)
    if operation==117:
        return sd_accumulator_command(r,out,w,command,response)
    if operation!=115:
        return sd_previous_to_command(r,out,w,command,response,payload_start)
    first=getw(w,8)
    result=0
    count=getr(r,command+16)
    dimensions=getr(r,command+24)
    keepdim=getr(r,command+32)
    dtype=getr(r,command+40)
    if getr(r,command+48)!=0 or getr(r,command+56)!=0 or keepdim>1:
        terror(w,7)
    if dtype!=0 and dtype!=18446744073709551615:
        terror(w,7)
    # entry/frame_valid already checked raw header length against buffer.len.
    packet_size=getr(r,16)
    has_axes=0
    if count!=18446744073709551615 and count!=0:
        has_axes=1
        if count>4:
            terror(w,7)
        if dimensions<payload_start or dimensions>packet_size:
            terror(w,2)
        else:
            if count<=4 and 8*count>packet_size-dimensions:
                terror(w,2)
    else:
        if dimensions!=0:
            terror(w,7)
    if getw(w,0)==0:
        memory_fill(w,2048,384,0)
        if has_axes!=0:
            axis=0
            while axis<count:
                putw(w,2048+8*axis,getr(r,dimensions+8*axis))
                axis=axis+1
        result=sd_sum_tensor(w,getr(r,command+8),count,2048,keepdim,dtype,2048)
    memory_fill(w,2048,384,0)
    return shape_command_finish(w,out,response,operation,first,result)
