# SumDims source03 protocol

Status: source authoring only. This package has not been parsed, emitted, compiled, or run.
The frozen source01/source02 packages and their actual b222/6b emissions remain separate.
The original source02 native32 result remains 21 PASS / 11 FAIL; no result is transferred.

The descriptor is still672 bytes (84 u64 words). The new formats are `HTSUM003`
(outer) and `HTOSUM03` (backing). The exact c436/07994965 parent and all13 parent
source/object files remain inputs. Existing commands and old allocator, capture,
row-release, Saved release, and ownership functions retain their original bodies.
The existing-G arithmetic call in gradient_accumulate is the single additional
modified parent body, explicitly recorded and fully reversible.

## Commands

Every request record has8 little-endian u64 words. Axis payloads contain signed
int64 values represented by their original u64 words. Standard frame validation,
response capacity admission, and whole-frame error rollback remain the parent mechanism.

| Command | Words1–7 | Result |
| --- | --- | --- |
|115, sum.dim_IntList|public F32 token; original axis count; axis payload offset; keepdim0/1; dtype0 or U64_MAX;0;0|new actual reduction Tensor|
|116, permute|public F32 token; axis count; axis payload offset;0;0;0;0|new actual view Tensor|
|117, AccumulateGrad.variable|public Tensor whose current grad_fn owns the selected edge; immediate edge slot0/1;0;0;0;0;0|the existing original leaf Tensor|

For115, count=U64_MAX meansNone and count0 means[]; both require payload offset0.
The reduction mask may coincide while their stored original metadata remains distinct.
An explicit list has1–4 axes, preserves order and signed spelling, and uses the
existing bounded rank0–4 normalization and duplicate rejection.

For116, count must equal the actual input rank0–4. Count0 requires offset0.
Every normalized axis occurs exactly once; negative axes are accepted only within
the actual rank. Malformed reserved words/count/duplicate axes produce error7;
invalid axis or payload range produces error2. A legacy view lacking genuine
ViewInfo is rejected by the unchanged base-root guard (error5). F32 is the initial
bounded dtype. This is a genuine permutation operation with AD48; it does not call
the public transpose or AsStrided APIs to stand in for permute.

For117, the selected immediate next edge must be enabled and point to a real
AccumulateGrad (op0). No grad_fn, an absent/disabled edge, or a non-AccumulateGrad
target produces error7. An ordinary invalid public token follows the parent's
error1 path. The current Tensor grad_fn lookup uses to_view_public and thus the
existing lazy-refresh behavior. A rowless captured accumulator resolves its exact
608/624 target through history_accumulator_target and private_tensor, including
incarnation and strong-root checks. The existing publish_tensor publishes that
same Tensor. No alias, tensor-valued Saved copy, synthetic input root, or substitute
gradient Tensor is introduced.

All three commands return the standard32-byte record
`[operation, error, public_tensor_token_or_zero, 0]`.
The existing shape_command_finish handles publication and request-local cleanup.

## AD47: SumBackward1 metadata

Word176 retains source01's exact layout: source sizes0–2 in19-bit fields,
source rank in bits57–59, and the reduction mask in bits60–63.

Word184 retains size3 in bits0–18, keepdim in bit19, and implicit-all in bit20.
New fields are original count in bits21–23 (5=None,0=[],1–4=explicit count),
and four original signed-axis bytes in bits24–55. Bits56–63 and every unused axis
byte must be0. A stored signed byte is sign-extended to u64 for the observed
_saved_dim value. The original order is retained.

The validator independently reconstructs the normalized mask from those original
axes, rejects duplicates/range/reserved bits, and requires implicit-all exactly
for count0 or5. Existing input/output shape and dtype checks remain. Original
axis bytes are captured in a native local before sd_plan clears the shared2048
scratch region. Numerical reduction and expand-backward loops are unchanged.

## AD48: PermuteBackward0 metadata and ownership

Word176 has rank in bits0–2 and four normalized axis bytes at bit8,16,24,32.
Bits3–7 and40–63 are0. Word184 has the four original signed-axis bytes in bits0–31;
bits32–63 are0. Unused slots are0. Normalizing each original byte must reproduce
the stored permutation exactly. The observed _saved_dims comes from the original
bytes, never from the output shape.

The actual view has permuted sizes and element strides, the same Storage and
Version, and the same physical byte offset. Its immediate AD edge is recorded
through record48; its ultimate-base Tensor is independently retained through
the original640/648 ViewInfo role and600/208 counts.

Historical metadata may be rowless. history_snapshot preserves the physical byte
offset at232 but does not preserve the live-only offset cache at64; the metadata
validator therefore compares232. It checks source/result rank, dtype, numel, all
permuted sizes/strides, and the complete two-word encoding. It does not require a
historical node to own a live Tensor row.

Backward implements the inverse permutation. Its incoming gradient is an actual
alias with the original S/V/offset and inverse-permuted incoming strides, as in the
fixed permute_backwards source. The logical first-write path preserves raw bits.
There are no Tensor Saved operands. Existing graph lifetime and release machinery
remain the owner of every real edge and base root.

## Arithmetic corrections in source03

The existing leaf gradient accumulation now calls the unchanged
scalar_add_preserving_bits(existing, incoming) helper at its single add site.
All adoption, aliases, Storage and Version operations, guards and release paths
remain exactly as before. The global addf and the helper body are unchanged.

The reduction output store also uses scalar_add_preserving_bits(existing, row).
CastStoreAccumulate still performs a real +=, including its first +0 write.
This output-store operand precedence is separate from the carry-first order
inside row_sum and multi_row_sum. No iterator axis, coalescing, ILP, cascade,
vector branch, finite arithmetic or loop order changes.

## Scope

No new runtime qualification follows from these sources. The actual source02
6b emission is the strict 29-member baseline; its complete 09446 inverse is
recomputed back to source01 b222 and copied without changes. The future new
emission must differ in exactly two arithmetic bodies and four format bodies,
with all other690 functions exact. That count is a source assertion, not an
already emitted or compiled result. The original native32 FAIL remains intact.
Root owns emission and compilation. Both the full original32 and original76
regression still require actual same-image execution because the leaf gradient
callee is shared. Project status remainsHOLD.
