def source_units(emitter, combined):
    ordered, done, active = [], set(), set()
    def visit(name):
        if name in EXTERNAL:
            return
        assert name in combined, ('missing function', name)
        assert name not in active, ('recursive function', name)
        if name in done:
            return
        active.add(name)
        for target in sorted({n.decode() for n in CALL.findall(combined[name])}):
            visit(target)
        active.remove(name)
        done.add(name)
        ordered.append(name)
    for name in combined:
        visit(name)
    groups, group, instructions, blocks = [], [], 0, 0
    for name in ordered:
        body = combined[name]
        ni, nb = body.count(b' = '), len(re.findall(rb'^block ', body, re.M))
        if group and (instructions + ni > 3600 or blocks + nb > 1000 or len(group) >= 65):
            groups.append(group)
            group, instructions, blocks = [], 0, 0
        group.append(name)
        instructions += ni
        blocks += nb
    if group:
        groups.append(group)
    units = [('rng03', emitter.rng_raw)]
    for index, names in enumerate(groups):
        imports = sorted({n.decode() for name in names for n in CALL.findall(combined[name])} - set(names))
        assert len(names) + len(imports) <= 256, (index, len(names), len(imports))
        declarations = []
        for name in imports:
            body = emitter.rng[name] if name in EXTERNAL else combined[name]
            declaration = re.sub(rb' entry\(\w+\)$', b' external()', body.split(b'\n')[0]) + b'\n'
            declarations.append(declaration)
        unit_name = f'sum_dims_{index:02d}'
        raw = (f'hia-asm.v1 hepta.hia.program.v8 {unit_name}\nexports({",".join(names)})\n'.encode()
               + b''.join(declarations) + b''.join(combined[name] for name in names))
        units.append((unit_name, raw))
    units.append(('owners', emitter.owner_raw))
    return units

