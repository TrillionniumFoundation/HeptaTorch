"""New integral SumDims overlay, source only until a separate authorized emission."""
import json
from authoring_support import functions, once, sha

PARENT_SOURCE = 'be841bf3468b4ce6ce66daead602d540839dadb1f8ceca2fd3b5940ff2e6d545'
PARENT_IMAGE = 'cff287705bc2c9cfc9eb53f0c3f68b287c30e6e93c2b44cfe8954047fc386234'
PARENT_BUILD = 'b2d9dd9eff9b9f1887a9d3268fe5692024b65804e73bd319539ce9644df3ea6f'
PARENT_EMISSION_MANIFEST = 'c545a70923207f90cb9cce9054c4fa8f5ade9d960a71cc7f45c8d1a763b759fa'
STATE = 'HTSINT01'
BACKING = 'HTOSIN01'
SOURCE_PINS = {
    'sum_integral.py': '37f61ec44fb3f4844ce81b73a33899f1705e6d19c3eea827ef2372c2bf4b95ae',
    'sum_integral_command.py': '768ce2e48ce3053c563a52c2a3632ec1fbce9719faf5b0dfea6ace21f302e589',
}
ADDED = {'si_plan', 'si_sum_integral', 'si_dispatch_sum'}
MODIFIED = {'to_command', 'init_state', 'state_header', 'so_state_init', 'so_state_header'}

def apply(emitter, combined, sources, out):
    original = dict(combined)
    assert len(original) == 696 and set(sources) == set(SOURCE_PINS)
    assert all(sha(sources[name]) == pin for name, pin in SOURCE_PINS.items())
    assert ADDED.isdisjoint(original)
    fragment = emitter.emit(b'\n'.join(sources[name] for name in SOURCE_PINS).decode('utf-8'))
    emitted = functions(fragment)
    assert set(emitted) == ADDED | {'to_command'}
    combined.update(emitted)
    (out / 'sum-integral-fragment.hepta').write_bytes(fragment)
    tag_edits = []
    for name in ('init_state', 'state_header', 'so_state_init', 'so_state_header'):
        outer = name in ('init_state', 'state_header')
        old_tag = b'HTSUM003' if outer else b'HTOSUM03'
        new_tag = STATE.encode('ascii') if outer else BACKING.encode('ascii')
        assert len(old_tag) == len(new_tag) == 8
        old = ('{"value":' + str(int.from_bytes(old_tag, 'little')) + '}').encode()
        new = ('{"value":' + str(int.from_bytes(new_tag, 'little')) + '}').encode()
        combined[name] = once(original[name], old, new)
        assert once(combined[name], new, old) == original[name]
        tag_edits.append({'function': name, 'before': old.decode(), 'after': new.decode(), 'count': 1})
    changed = {name for name in original if original[name] != combined[name]}
    assert changed == MODIFIED and set(combined) - set(original) == ADDED
    assert len(combined) == 699 and len(set(original) - changed) == 691
    assert all(combined[name] == original[name] for name in set(original) - changed)
    # Exact original F32 function bodies and all AD/Storage/Version code are retained.
    for name in ('sd_sum_tensor', 'sd_axis_mask', 'sd_plan', 'sd_execute_plan',
                 'sd_backward', 'incoming_describe', 'gradient_accumulate',
                 'partial_apply_node', 'typed_descriptor', 'tget', 'taddr', 'typed_store',
                 'sd_permute_tensor', 'sd_accumulator_variable', 'entry'):
        assert combined[name] == original[name], name
    (out / 'sum-integral-source-custody.json').write_text(json.dumps({
        'schema': 'heptatorch.sum-integral.source-overlay.v1',
        'status': 'SOURCE_EMITTED_NOT_COMPILED',
        'parent_source_sha256': PARENT_SOURCE, 'parent_image_sha256': PARENT_IMAGE,
        'source_inputs_sha256': SOURCE_PINS,
        'changed_parent_functions': sorted(changed),
        'unchanged_parent_functions': sorted(set(original) - changed),
        'added_functions': sorted(ADDED), 'tag_edits': tag_edits,
        'public_command_extended': 115, 'new_public_commands': [],
        'new_autograd_operations': [], 'integer_output_requires_grad': False,
        'integer_output_records_op47': False,
        'f32_TensorIterator_kernel_unchanged': True,
        'no_float_conversion_for_integer_values': True,
        'wrap_overflow_parity': 'PENDING_FIXED_PLATFORM_ACTUAL',
        'state_format': STATE, 'backing_format': BACKING, 'descriptor_bytes': 672,
        'compiler_executed': False, 'native_executed': False, 'torch_executed': False,
        'runtime_qualified': False, 'schema_closure': False, 'full_project_status': 'HOLD'
    }, indent=2) + '\n')
    return combined

def record_inverse(emitter, combined, runtime, out):
    original = emitter.parent
    original_order = list(original)
    assert list(combined)[:len(original_order)] == original_order
    # The actual whole parent byte stream, including its header/order/trailing LF,
    # is reconstructed. No set-only or function-count-only ancestry assertion.
    parent_raw = emitter.parent_raw
    first = parent_raw.index(b'fn ')
    parent_header = parent_raw[:first]
    assert parent_header + b''.join(original.values()) == parent_raw
    child_header = runtime[:runtime.index(b'fn ')]
    assert runtime == child_header + b''.join(combined.values())
    changes = [
        {'name': name, 'before_sha256': sha(original[name]), 'after_sha256': sha(combined[name]),
         'before_body': original[name].decode(), 'after_body': combined[name].decode()}
        for name in original_order if original[name] != combined[name]
    ]
    restored = dict(combined)
    for item in changes:
        assert restored[item['name']] == item['after_body'].encode()
        restored[item['name']] = item['before_body'].encode()
    for name in ADDED:
        del restored[name]
    recovered = parent_header + b''.join(restored[name] for name in original_order)
    assert recovered == parent_raw and sha(recovered) == PARENT_SOURCE
    forward = dict(original)
    for item in changes:
        assert forward[item['name']] == item['before_body'].encode()
        forward[item['name']] = item['after_body'].encode()
    for name in combined:
        if name in ADDED:
            forward[name] = combined[name]
    assert child_header + b''.join(forward.values()) == runtime
    result = {
        'schema': 'heptatorch.sum-integral.whole-runtime-inverse.v1',
        'parent_source_sha256': PARENT_SOURCE, 'child_source_sha256': sha(runtime),
        'parent_header': parent_header.decode(), 'child_header': child_header.decode(),
        'parent_function_order': original_order, 'child_function_order': list(combined),
        'changed_functions': changes,
        'added_functions': [{'name': name, 'sha256': sha(combined[name]),
                             'body': combined[name].decode()} for name in combined if name in ADDED],
        'unchanged_functions': [{'name': name, 'sha256': sha(original[name])}
                                for name in original_order if name not in MODIFIED],
        'whole_forward_exact': True, 'whole_inverse_exact': True,
        'old_count': 696, 'current_count': 699, 'unchanged_count': 691,
        'modified_count': 5, 'added_count': 3,
    }
    (out / 'sum03-to-integral01-body-inverse.json').write_text(json.dumps(result, indent=2) + '\n')
    return result
