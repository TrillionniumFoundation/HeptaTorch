"""Re-derive two files using only explicit reversible identity/path edits."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = '51820849f7becec549be15babace00f00687601ae7f53bcee0e636ca02f721f9'
IMAGE = 'aa3cc8f0c8738a9505d31c9e8ba5a523b7e08b591b61fc7bfb8592295491618b'
OWNER = 'db8dfd3ce4c845049a521a2612be4b53c295248daa748c31da3b2ccdd22dfc61'
RUN = 'aa0201607f50b5633d25bab41a009c2c53af2b080cf87ca9080fe723934957b1'


def require(ok, label):
    if not ok:
        raise ValueError(label)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def definition(raw, name):
    lines = raw.decode().splitlines(keepends=True)
    nodes = [node for node in ast.parse(raw).body
             if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name == name]
    require(len(nodes) == 1, 'unique complete source definition: ' + name)
    node = nodes[0]
    return ''.join(lines[node.lineno - 1:node.end_lineno]).encode()


def change(before, edits):
    after = before
    for old, new, count in edits:
        require(after.count(old.encode()) == count, 'exact forward occurrence count: ' + old)
        after = after.replace(old.encode(), new.encode(), count)
    restored = after
    for old, new, count in reversed(edits):
        require(restored.count(new.encode()) == count, 'exact inverse occurrence count: ' + new)
        restored = restored.replace(new.encode(), old.encode(), count)
    require(restored == before, 'entire original file restored')
    ast.parse(after)
    return after, dict(before_sha256=sha(before), after_sha256=sha(after),
                       before_bytes=len(before), after_bytes=len(after), edits=edits,
                       whole_file_inverse_exact=True)


def derive(bind):
    owner = bind(HERE / 'frozen-candidate719/candidate/owner_f64.py', OWNER)
    run = bind(HERE / 'frozen719/run.py', RUN)
    outputs, proof = {}, {}
    outputs['owner736.py'], proof['owner'] = change(owner, [
        ('f64-source01-UNBOUND-719', 'f64-source01-UNBOUND-736', 1),
        ('functions == 719', 'functions == 736', 2),
        ('e2eedf870e306572672817cfc98bcf49d9aeacc0657c04dbaf50e5e6f5ceb66d', SOURCE, 1),
    ])
    proof['owner'].update(all_nonidentity_bytes_unchanged=True,
        original_f64_dtype_domain_extension_unchanged=True,
        original_private_scalar3_predicates_unchanged=True,
        original_full_owner_and_frame_boundary_predicates_unchanged=True,
        full_transition_recomputed=False)
    outputs['derived719_run.py'], proof['run'] = change(run, [
        ('exact-frozen719-source-required', 'exact-frozen736-source-required', 1),
        ('exact-real719-ELF-required', 'exact-real736-ELF-required', 1),
        ('heptatorch.f64.tensor-native33.v1', 'heptatorch.f64.tensor-native736.v1', 1),
        ("args.candidate / 'original55-mapping.json'", "FROZEN_CANDIDATE / 'original55-mapping.json'", 1),
        ('inputs, plan, package)', 'inputs, plan, FROZEN_PRODUCER_MANIFEST)', 1),
    ])
    before_main, after_main = definition(run, 'main'), definition(outputs['derived719_run.py'], 'main')
    require(run.replace(before_main, b'', 1) == outputs['derived719_run.py'].replace(after_main, b'', 1),
            'all bytes outside main remain original')
    preserved = {}
    for name in ('Reference', 'Driver', 'numeric_case', 'boundary_case', 'run_child'):
        before = definition(run, name)
        require(before == definition(outputs['derived719_run.py'], name), 'complete original definition: ' + name)
        preserved[name] = dict(bytes=len(before), sha256=sha(before))
    start, stop = b'            tasks = []\n', b'        code = 0 if result'
    require(before_main.split(start, 1)[1].split(stop, 1)[0] ==
            after_main.split(start, 1)[1].split(stop, 1)[0], 'complete48 scheduling and comparison loop')
    proof['run'].update(only_main_edited=True, complete48_task_loop_unchanged=True,
        original_definitions=preserved, main_before_sha256=sha(before_main), main_after_sha256=sha(after_main))
    proof.update(schema='heptatorch.current736-original-f64-48.reader-identity-inverse.v1',
        source_sha256=SOURCE, native_sha256=IMAGE, original_reference_namespace_preserved=True,
        old87_expected_statuses_modified=False, original_strict55_FAIL_preserved=True,
        native_executed=False, Torch_executed=False, compiler_executed=False,
        runtime_PASS_transferred=False)
    outputs['identity-derivation.json'] = (json.dumps(proof, sort_keys=True, indent=2) + '\n').encode()
    return outputs, proof
