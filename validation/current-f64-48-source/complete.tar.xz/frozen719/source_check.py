#!/usr/bin/env python3
"""Pure source/corpus/comparator/wire checks. Never starts an application."""
import argparse
import ast
import json
import os
import struct
import subprocess
import sys
import traceback
from pathlib import Path

from common import (HERE, SOURCE, IMAGE, PARTITION_MANIFEST, Inputs, bind_package,
                    candidate_admission, dump, parse, sha, require)
from corpus import groups, comparator


def forbidden(*args, **kwargs):
    raise AssertionError('source-only check attempted to start a process')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--candidate', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--actual-build-report', type=Path)
    a = p.parse_args()
    out = a.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    inputs, result, code = Inputs(), {}, 1
    result.update(schema='heptatorch.f64.tensor-qualification-source-check.v1', status='FAIL',
        native_executed=False, Torch_executed=False, compiler_executed=False,
        actual_numeric_qualification_granted=False, failures=[])
    # Definitions and parsers may be imported; all process launch paths are
    # explicit errors during this check. The Torch producer is not invoked.
    subprocess.Popen = subprocess.run = subprocess.call = forbidden
    os.fork = os.execve = os.system = forbidden
    try:
        result['source_manifest_sha256'] = bind_package(inputs)
        result['source_admission'] = candidate_admission(a.candidate, inputs)
        for path in sorted(HERE.rglob('*.py')):
            raw = inputs.bind(path)
            ast.parse(raw, str(path))
        result['python_AST_files'] = len(list(HERE.rglob('*.py')))
        mapping = parse(inputs.bind(a.candidate / 'original55-mapping.json'))
        rows = groups(inputs, mapping)
        result.update(original_numeric_groups_mapped=len(rows), original_input_values=sum(r['input_values'] for r in rows),
            all_original_request_digests_and60000batching_match=True,
            original_sqrt_groups_excluded=6, original_standalone_refusals_excluded=16)
        compare, result['original_comparison_inverse'] = comparator(inputs)
        checks = []
        for label, mode, actual, expected, valid in (
            ('F64-positive-zero', 0, 0, 0, True),
            ('F64-zero-sign-must-match', 0, 1 << 63, 0, False),
            ('F64-inf-exact', 3, 0x7ff0000000000000, 0x7ff0000000000000, True),
            ('F64-finite-neighbor-refused', 2, 0x3ff0000000000001, 0x3ff0000000000000, False),
            ('F64-original-quiet-NaN-classification', 1, 0xfff8000000000042, 0x7ff8123456789abc, True),
            ('F64-signaling-NaN-output-refused', 1, 0x7ff0000000000042, 0x7ff8123456789abc, False),
            ('F32-zero-sign-must-match', 6, 1 << 31, 0, False),
            ('F32-original-quiet-NaN-classification', 6, 0xffc00042, 0x7fc00001, True),
            ('F32-signaling-NaN-output-refused', 6, 0x7f800001, 0x7fc00001, False)):
            row = dict(non_nan_attempted=0, exact_non_nan=0, nan_classification=0, mismatches=[])
            compare(mode, [(0x123, 0x456)], 37, [actual], [expected], row)
            require((not row['mismatches']) == valid, 'original-comparison-boundary-control', label=label)
            if not valid:
                require(row['mismatches'][0]['index'] == 37 and row['mismatches'][0]['a'] == '0x123'
                        and row['mismatches'][0]['b'] == '0x456', 'original-input-diagnostic-preserved')
            checks.append(dict(name=label, outcome_matches_original_contract=True, actual_native_observation=False))
        try:
            compare(0, [(0, 0)], 0, [], [0], dict(mismatches=[]))
        except AssertionError:
            checks.append(dict(name='original-length-assertion', rejected=True))
        else:
            raise AssertionError('original comparator accepted unequal lengths')
        result['pure_comparator_controls'] = checks
        from cases import CASES, CASE_SHA256
        from reference import words_raw
        from native import Native, WIRE
        import controls
        import run
        result['boundary_case_sha256'] = CASE_SHA256
        factory_packets = []
        for spec in CASES:
            names = set()
            for action in spec['actions']:
                if 'name' in action:
                    require(action['name'] not in names, 'boundary-new-role-only')
                    names.add(action['name'])
                if action['kind'] != 'create':
                    continue
                raw = words_raw(action['dtype'], action['words'])
                body = Native.factory_packet(action['dtype'], action['shape'], raw, action['requires'])
                require(body[:8] == b'HTORCH03' and struct.unpack_from('<3Q', body, 8) == (1, len(body), 0)
                        and struct.unpack_from('<8Q', body, 32) == (97, action['dtype'], 96, 0, 0, 0, 0, 0),
                        'real-factory-packet-structure')
                cfg = struct.unpack_from('<8Q', body, 96)
                require(cfg[0] == len(action['shape']) and cfg[1] == int(action['requires'])
                        and list(cfg[2:2 + cfg[0]]) == action['shape'] and cfg[6] == 160
                        and cfg[7] == len(raw) and body[160:] == raw,
                        'all-rank-dtype-and-full-width-raw-bytes')
                factory_packets.append(dict(case=spec['name'], role=action['name'], sha256=sha(body), bytes=len(body)))
        require(len(Native.factory_packet(4, [60000], bytes(480000))) == 480160,
                'largest-original-batch-fits-real-one-MiB-frame')
        result['pure_factory_packet_checks'] = factory_packets
        result['all_twelve_boundary_cases_defined'] = len(CASES) == 12
        if a.actual_build_report:
            built = parse(inputs.bind(a.actual_build_report))
            require(built['schema'] == 'heptatorch.complete-runtime-build.v1' and built['status'] == 'PASS_NATIVE_BUILD_ONLY'
                    and built['source_sha256'] == SOURCE and built['native_sha256'] == IMAGE
                    and built['manifest_sha256'] == PARTITION_MANIFEST and built['functions'] == 719
                    and built['units_planned'] == len(built['units']) == 14 and len(built['processes']) == 15
                    and built['runtime_qualified'] is False and built['result_executable_executed'] is False,
                    'retained-actual-cold-report-summary')
            result['cold_report_summary_observed_only'] = dict(source=SOURCE, image=IMAGE,
                complete_build_files_rechecked_here=False, native_qualification_transferred=False)
        result['status'], code = 'PASS_SOURCE_AND_WIRE_ONLY_NOT_RUN', 0
    except BaseException as error:
        result['failures'].append(dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
    finally:
        try:
            result['all_inputs_unchanged'] = inputs.unchanged()
        except BaseException as error:
            result['status'], code = 'FAIL', 1
            result['failures'].append(dict(stage='input-recheck', error=repr(error)))
        result['inputs'] = inputs.rows
        dump(out / 'report.json', result)
    print(json.dumps({k: result[k] for k in ('status', 'native_executed', 'Torch_executed', 'compiler_executed')}))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
