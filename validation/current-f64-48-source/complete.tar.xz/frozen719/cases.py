"""Additional real Tensor contracts. All numbers below are input bit patterns."""
from common import canonical, sha


def create(name, dtype, shape, words, requires=False):
    return dict(kind='create', name=name, dtype=dtype, shape=shape, words=words, requires=requires)


def view(name, source, shape, strides, offset=0):
    return dict(kind='view', name=name, source=source, shape=shape, strides=strides, offset=offset)


def cast(name, source, target, copy=False, format=0, opcode=108):
    return dict(kind='cast', name=name, source=source, target=target, copy=copy,
                format=format, opcode=opcode)


def binary(name, operation, left, right):
    return dict(kind='binary', name=name, operation=operation, left=left, right=right)


F32 = [0x00000000, 0x80000000, 0x3f800000, 0xbf800000, 0x40000000, 0x3e800000,
       0x00800000, 0x00000001, 0x7f7fffff, 0xff7fffff, 0x33800000, 0x4b800001]
F64 = [0x0000000000000000, 0x8000000000000000, 0x3ff0000000000000, 0xbff0000000000000,
       0x7ff0000000000000, 0xfff0000000000000, 0x7ff8123456789abc, 0x7ff0123456789abc]

CASES = [
    dict(name='rank0-raw64-set-fill-version', actions=[
        create('x', 4, [], [0x0123456789abcdef]),
        dict(kind='set', source='x', index=0, bits=0x8000000000000000),
        dict(kind='fill', source='x', bits=0x7ff8123456789abc),
        cast('same', 'x', 4), cast('copy', 'x', 4, True),
        dict(kind='set', source='copy', index=0, bits=0xfedcba9876543210)]),
    dict(name='rank4-broadcast-all-four-operations', actions=[
        create('a', 4, [2, 1, 2, 1], [0x3ff0000000000000, 0xbff0000000000000,
                                    0x4000000000000000, 0x3fe0000000000000]),
        create('b', 4, [1, 3, 1, 4], [0x3ff0000000000000, 0x4000000000000000,
                                    0x4008000000000000, 0xbff0000000000000] * 3),
        *[binary('r' + str(op), op, 'a', 'b') for op in range(1, 5)]]),
    dict(name='empty-broadcast-all-four-operations', actions=[
        create('a', 4, [2, 0, 3], []), create('b', 4, [1, 0, 1], []),
        *[binary('r' + str(op), op, 'a', 'b') for op in range(1, 5)]]),
    dict(name='transpose-cast-preserve-and-strided-binary', actions=[
        create('base', 0, [6], F32[:6]), view('v', 'base', [3, 2], [1, 3]),
        cast('a', 'v', 4), create('b', 4, [], [0x4000000000000000]),
        *[binary('r' + str(op), op, 'a', 'b') for op in range(1, 5)],
        dict(kind='set', source='a', index=3, bits=0x7ff8fedcba987654),
        dict(kind='fill', source='a', bits=0x8000000000000001),
        cast('back', 'a', 0), cast('contiguous', 'a', 0, format=1)]),
    dict(name='gapped-offset-cast-preserve', actions=[
        create('base', 0, [24], F32 * 2), view('v', 'base', [3, 4], [8, 2], 1),
        cast('a', 'v', 4), cast('back', 'a', 0)]),
    dict(name='zero-stride-cast-preserve', actions=[
        create('base', 0, [4], F32[2:6]), view('v', 'base', [3, 4], [0, 1]),
        cast('a', 'v', 4), cast('back', 'a', 0)]),
    dict(name='overlap-cast-preserve', actions=[
        create('base', 0, [5], F32[2:7]), view('v', 'base', [2, 3], [1, 1]),
        cast('a', 'v', 4), cast('back', 'a', 0)]),
    dict(name='singleton-arbitrary-strides-cast-preserve', actions=[
        create('base', 0, [8], F32[:8]), view('v', 'base', [1, 2, 1, 3], [20, 3, 11, 1], 1),
        cast('a', 'v', 4), cast('back', 'a', 0)]),
    dict(name='empty-cast-both-widths-and-copy', actions=[
        create('x', 0, [2, 0, 3], []), cast('a', 'x', 4),
        cast('same', 'a', 4), cast('copy', 'a', 4, opcode=109), cast('back', 'a', 0)]),
    dict(name='F64-dense-transpose-preserve-vs-contiguous', actions=[
        create('base', 0, [6], F32[2:8]), view('v', 'base', [3, 2], [1, 3]),
        cast('a', 'v', 4), cast('same', 'a', 4),
        cast('preserve', 'a', 4, True), cast('contiguous', 'a', 4, format=1),
        cast('copy109', 'a', 4, opcode=109)]),
    dict(name='F64-same-dtype-raw-NaN-payload-copy-alias', actions=[
        create('a', 4, [8], F64), cast('same', 'a', 4), cast('copy', 'a', 4, True),
        cast('copy109', 'a', 4, opcode=109),
        dict(kind='set', source='copy', index=6, bits=0xffffffffffffffff),
        dict(kind='fill', source='copy109', bits=0x8000000000000001),
        dict(kind='set', source='a', index=7, bits=0x7ff8fedcba987654)]),
    dict(name='zero-length-rank4-raw-fill-version', actions=[
        create('a', 4, [0, 2, 3, 4], []),
        dict(kind='fill', source='a', bits=0x7ff8fedcba987654),
        cast('back', 'a', 0), cast('again', 'back', 4)]),
]

CASE_SHA256 = sha(canonical(CASES))

# These are explicit boundaries of this candidate, not a claim that PyTorch
# rejects ordinary F64 autograd, mixed arithmetic or the other public operators.
BOUNDARY_CONTRACT = dict(public_dtype=4, private_wrapped_scalar_dtype=3,
    supported_binary_operations=[1, 2, 3, 4], cast_pairs=[[0, 4], [4, 0], [4, 4]],
    unsupported=['F64 autograd', 'mixed dtype arithmetic', 'F64 sqrt', 'F64 sum',
                 'F64 general views', 'F64 SavedTensor', 'F64 reshape/permute'],
    original55_groups=dict(new_Tensor_numeric_mapping=33, sqrt_not_exposed=6,
                           standalone_packet_refusals_not_transferred=16),
    original_strict_Torch_failed_groups=4, original_strict_Torch_mismatches=4008)
