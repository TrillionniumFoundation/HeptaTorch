"""Exact old input generator and numeric comparison block, with an explicit inverse."""
import ast
import hashlib
import struct
import textwrap
import types

from common import HERE, ORACLE, Inputs, canonical, load, parse, require, sha

LIMIT = 60000
MASK, INF = (1 << 63) - 1, 0x7ff0000000000000


def bind_original(inputs):
    raw = inputs.bind(HERE / 'frozen/f64_oracle.py', ORACLE)
    text = raw.decode()
    tree = ast.parse(text)
    main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    ref = next(n for n in main.body if isinstance(n, ast.FunctionDef) and n.name == 'reference')
    loops = [n for n in ast.walk(main) if isinstance(n, ast.For)
             and isinstance(n.target, ast.Tuple) and isinstance(n.target.elts[0], ast.Name)
             and n.target.elts[0].id == 'position']
    require(len(loops) == 1, 'unique-original-numeric-comparison')
    lines = text.splitlines(keepends=True)
    spans = {}
    for name, node in (('reference_function.py.txt', ref), ('comparison_block.py.txt', loops[0])):
        actual = textwrap.dedent(''.join(lines[node.lineno - 1:node.end_lineno]))
        frozen = inputs.bind(HERE / 'frozen' / name).decode()
        require(frozen == actual, 'complete-original-AST-source-span', name=name)
        parsed = ast.parse(frozen).body[0]
        require(ast.dump(parsed, include_attributes=False) == ast.dump(node, include_attributes=False),
                'original-comparison-AST-exact', name=name)
        spans[name] = frozen
    original = load(HERE / 'frozen/f64_oracle.py', 'original_f64_inputs_only')
    return original, spans


def groups(inputs, mapping):
    original, _ = bind_original(inputs)
    rows = list(original.corpus())
    require(len(rows) == 39, 'original39-numerical-groups-before16-packet-refusals')
    result = []
    for index, (name, mode, pairs) in enumerate(rows):
        mapped = mapping['rows'][index]
        require(mapped['original_index'] == index and mapped['case'] == name
                and mapped['mode'] == mode and mapped['original_input_values'] == len(pairs),
                'original-corpus-index-and-count', case=name)
        digest = hashlib.sha256()
        for offset, batch in batches(pairs):
            digest.update(original_packet(mode, batch))
        require(digest.hexdigest() == mapped['original_request_sha256'],
                'all-original-input-bytes-and-batching', case=name)
        if mode != 4:
            result.append(dict(original_index=index, name=name, mode=mode, pairs=pairs,
                input_values=len(pairs), original_request_sha256=digest.hexdigest()))
    require(len(result) == 33, 'exact33-mapped-groups')
    return result


def batches(pairs):
    for offset in range(0, max(1, len(pairs)), LIMIT):
        yield offset, pairs[offset:offset + LIMIT]


def original_packet(mode, batch):
    return struct.pack('<II', mode, len(batch)) + b''.join(
        struct.pack('<QQ', x, y) if mode < 4 else struct.pack('<Q', x) for x, y in batch)


def input_bytes(mode, batch):
    code = 'I' if mode == 5 else 'Q'
    left = b''.join(struct.pack('<' + code, x) for x, _ in batch)
    right = b''.join(struct.pack('<Q', y) for _, y in batch) if mode < 4 else None
    return left, right


def original_reference(torch, inputs):
    _, spans = bind_original(inputs)
    environment = dict(a=types.SimpleNamespace(reference='pytorch'), torch=torch, struct=struct)
    # Entire original function, including its unentered CPython branch. The
    # local flag is fixed to PyTorch and the CPython evaluator is not provided.
    exec(compile(spans['reference_function.py.txt'], '<original-reference-function>', 'exec'), environment)
    return environment['reference']


def comparator(inputs):
    _, spans = bind_original(inputs)
    block = spans['comparison_block.py.txt']
    prefix = 'def compare(mode, batch, offset, actual, expected, row):\n'
    precheck = '    assert len(expected) == len(actual) == len(batch)\n'
    source = prefix + precheck + textwrap.indent(block, '    ')
    compiled = ast.parse(source)
    loop = next(n for n in compiled.body[0].body if isinstance(n, ast.For))
    require(ast.dump(loop, include_attributes=False) == ast.dump(ast.parse(block).body[0], include_attributes=False),
            'every-original-numeric-predicate-retained')
    environment = dict(MASK=MASK, INF=INF)
    exec(compile(source, '<whole-original-comparison>', 'exec'), environment)
    proof = dict(original_sha256=ORACLE, original_comparison_sha256=sha(block.encode()),
                 original_reference_sha256=sha(spans['reference_function.py.txt'].encode()),
                 original_comparison_AST_unchanged=True, no_numeric_predicate_or_tolerance_edits=True,
                 non_nan='exact bits including signed zero and infinity',
                 nan='classification and quiet bit; payload/sign not claimed',
                 host_expected_used_as_new_reference=False)
    return environment['compare'], proof
