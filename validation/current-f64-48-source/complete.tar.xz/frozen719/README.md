# First ordinary F64 Tensor qualification source

This package prepares the first actual qualification of the separate
**719-function ordinary F64 Tensor candidate**. The source authoring and pure
checks do not execute a native Tensor application, Torch, a compiler or a linker.
The root task has separately observed its real cold build. No application
qualification is transferred from that build or from the 701/712 images.

| Bound input | SHA-256 |
|---|---|
| Complete 719-function runtime | `e2eedf870e306572672817cfc98bcf49d9aeacc0657c04dbaf50e5e6f5ceb66d` |
| First actual 719 ELF | `4ef74a024572ed6e37f33544a0b7dfbcad37d93a5e9da40afa633e0773aa3807` |
| First actual cold build report | `c0c3e240e12ef41c85409801ec5e5dee572ff9430c8b034922cfe24a4e664332` |
| `public_f64` partition manifest | `3af7c65e81673985b03cf810f849c734949a07e520d02385a4f9ff7a14c9629e` |
| Complete candidate source package manifest | `14cc6731198a0524ec8ee70843d0ca2ab44c8d239b7b4fd43b48d2f3593dead5` |
| Complete candidate owner observer | `db8dfd3ce4c845049a521a2612be4b53c295248daa748c31da3b2ccdd22dfc61` |
| Complete original numerical oracle | `bb639f7ef669d34787986ed62e870cc61071adcba1ae4e44e325673e2f75bb03` |

The build report SHA is a mandatory explicit CLI argument because a newly
observed cold build has its own original receipt. The source, image, partition,
compiler, linker, builder and unchanged three-argument ABI are separately pinned.
This package does not contain the Generator integration.

## What the first run must qualify

The numerical group maps all **33 supported original groups and 1,798,174 input
values** through actual public Tensor operations. The 20 binary groups use
command 97 for two dtype-4 Tensor inputs, command 2 for add/subtract/multiply/divide,
and commands 13/96/98 for actual metadata and eight-byte logical output. Three
widen groups and four narrow groups use actual commands 108 and the original
F32/F64 conversion bodies. Six original empty groups exercise the same interfaces.
The old 60,000-value batch size, pair order and every original request digest are
checked before native execution. Each operand has its own real factory frame;
no request-local intermediate Tensor is fabricated by the reader.

The **entire original numerical comparison loop** is extracted from the retained
oracle with only uniform indentation removed. Its AST is compared to its actual
original source span in the same interpreter. Every non-NaN output remains bit
exact, including signed zero and infinity. NaN output retains the old
classification and quiet-bit rule; payload and sign parity are not newly claimed.
The exact original Torch reference function is likewise retained and executed
with its reference selector fixed to `pytorch`. Its dormant CPython branch has no
host evaluator in the reference execution environment. The new real Tensor
operation must independently produce the same actual words as that original
Torch function. No host arithmetic generates expected numerical values.

Twelve additional Tensor recipes observe every intermediate role, including:

- Rank zero and rank four; empty shapes; four-operation broadcasting.
- F32 transpose, offset/gapped, zero-stride, overlapping and singleton layouts
  converted to F64, including preserve versus contiguous format.
- F64 arithmetic on a real dense transposed result, full-width strided raw set
  and fill, and F64-to-F32 conversion back from that layout.
- Exact raw NaN payload storage, high bits, signed zero and subnormal mutations;
  actual Version increments; same-dtype aliases versus copies through 108/109.
- Release of all named roots, alias relationships, complete physical Storage
  contents, no-AD/leaf/view metadata and all 5,056 RNG bytes.

The separate entry group checks explicit candidate refusals. It creates a real
old private dtype-3 scalar through the unchanged 114/107 Saved path and confirms
its dtype, width and rank. Code 3 cannot become an ordinary public dtype. Both
orders of mixed dtype arithmetic, unsupported cast pairs, F64 autograd, sqrt,
sum, reshape, views and Saved operations must refuse with their exact existing
protocol causes and preserve all committed owner bytes. Two negative requests
also resolve a new F64 factory through the actual same-frame FE alias, then
reject and roll back the entire transaction. These refusal controls document
the candidate's bounded API; they do not pretend PyTorch lacks those features.

Two independent children perform real resource failures: F32-to-F64 result
Storage allocation, and F64 add result Storage allocation. Real Bool fillers
leave 16–32 KiB free while the requested result needs 524,288 bytes. The reader
first verifies available Tensor/Storage/Version/Hold slots and an already
allocated descriptor page. A real `RLIMIT_AS` leaves room for the unchanged
transaction, a complete RNG query and small wire buffers. Actual successful
queries under that same limit precede the denied allocation. The original
limit is restored in `finally`; the exact same request must then succeed and
match a separately observed Torch result. The full native owner, input bits,
RNG and `/proc/PID/maps` must survive the failure unchanged.

The native suite has **48 independent children**: 33 numerical groups, 12 Tensor
recipes, one entry group and two allocation controls. Every child must finish
with exit zero, actual EOF on both streams, no stderr, no extra stdout and no
forced cleanup. All groups continue after a failure so their original artifacts
can be retained, but any failure prevents the aggregate `PASS`.

## Evidence and ownership

`native.py` retains the complete frozen wire encoder, decoder and original
fork/exec and own-child memory helpers. The capture subclass records each
completed write and read immediately, including partial failures. Complete
before/after owner bytes are compressed and saved **before** decoding. The
candidate's full 84-word observer checks every actual descriptor and its
Storage/Version/Hold/Saved graph; each ordinary error additionally requires the
same pointer, length and every owner byte. Public metadata and raw value output
are cross-checked against independently read actual owner Storage addresses.
The owner explicitly extends dtype membership to 4; it does not claim an
unchanged old predicate domain or a fully recomputed private transition ledger.

Cold admission is a full-file inverse of the frozen 701 admission, changing only
source/image/count/profile literals. All original 14-module/15-process checks,
relocatable object bytes, original support modules, exact linked object request,
double EOF, compiler/linker/stack identities and actual ELF binding still run.
The new source admission reverses all 15 modifications and 18 additions back to
the exact 823 source and confirms all 686 unchanged bodies. Eight old numerical
bodies and three shared helpers match the original standalone F64 source in full.

Proof summaries store raw source SHA values and explicit predicates. An
`ast.dump` string or its hash is never compared between a host Python report and
a different Torch Python version; AST comparisons only occur between original
and derived source parsed in the same current interpreter.

`frozen/` retains both original hosted F64 reports byte for byte. The original
denominator is still **55**: 33 groups mapped here, **6 sqrt groups not exposed**,
and **16 standalone packet-refusal groups not transferred**. The four original
strict Torch failures and 4,008 recorded differences remain preserved. This new
Tensor reader never imports the old application's PASS or replaces those FAILs.
`full_dtype_gate_closed` and `full_project_status` remain false/HOLD even if this
bounded Tensor suite eventually passes.

## Root-executable commands

`PACKAGE`, `CANDIDATE`, `BUILD`, `REPO`, `TORCH_PYTHON` and each output directory
below denote explicit absolute paths selected by the root task. The candidate
directory is the unchanged 76-payload source package, not a build directory.
The build directory must include all original source, object, toolchain and
stream artifacts produced by the fixed builder. Every output must be new and
outside the bound inputs. Do not use `python -I`: these source modules are
loaded from the explicit script directory. `-E -S -B` is used for native-only
qualification; the fixed Torch environment must retain its site packages.

Pure source and wire admission:

```sh
python -E -S -B "$PACKAGE/source_check.py" \
  --candidate "$CANDIDATE" \
  --actual-build-report "$BUILD/build.json" \
  --output "$SOURCE_CHECK_OUTPUT"
```

Reference preparation, which does not import Torch:

```sh
cd "$REPO"
"$TORCH_PYTHON" -E -B "$PACKAGE/reference.py" \
  --repository "$REPO" --candidate "$CANDIDATE" \
  --output "$REFERENCE_PREPARE_OUTPUT" --prepare-only
```

First actual reference, in the same fixed environment:

```sh
cd "$REPO"
"$TORCH_PYTHON" -E -B "$PACKAGE/reference.py" \
  --repository "$REPO" --candidate "$CANDIDATE" \
  --output "$REFERENCE_ACTUAL_OUTPUT"
```

Bind the SHA of its original `report.json` and preserve its full blobs and row
files. The producer enforces the original 11 wheel-provenance checks for
`2.15.0+cpu`, git `d0f2af8b66b20da4baa50644c0cd3f887a2eae2e`; the upstream
inventory remains the separately documented `31a77…` commit.

Native preparation and first actual run use the same arguments and different
new output directories. Remove `--prepare-only` only for the actual run:

```sh
python -E -S -B "$PACKAGE/run.py" \
  --candidate "$CANDIDATE" --build-directory "$BUILD" \
  --reference "$REFERENCE_ACTUAL_OUTPUT/report.json" \
  --expected-source-sha256 e2eedf870e306572672817cfc98bcf49d9aeacc0657c04dbaf50e5e6f5ceb66d \
  --expected-native-sha256 4ef74a024572ed6e37f33544a0b7dfbcad37d93a5e9da40afa633e0773aa3807 \
  --expected-build-sha256 c0c3e240e12ef41c85409801ec5e5dee572ff9430c8b034922cfe24a4e664332 \
  --expected-reference-sha256 "$EXACT_REFERENCE_SHA256" \
  --output "$NATIVE_PREPARE_OUTPUT" --prepare-only
```

Report schemas are `heptatorch.f64.tensor-reference33.v1` and
`heptatorch.f64.tensor-native33.v1`. `PREPARED_NOT_RUN` and reference `OBSERVED`
are not native PASS. Native PASS requires all 48 children, all raw transport and
owner checks, all mandatory controls, and a successful final recheck of every
bound input. The reader does not run another Torch reference or another cold
build during native qualification.
