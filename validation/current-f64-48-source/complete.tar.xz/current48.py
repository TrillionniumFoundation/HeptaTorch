#!/usr/bin/env python3
"""Run current736 F64 48 with two explicit malformed-factory status changes.

All original numerical, resource, owner, transaction and EOF implementations
remain the exact original source. The original controls module stays frozen.
"""
from contextlib import contextmanager
import hashlib
from pathlib import Path
import sys
import types


HERE = Path(__file__).resolve().parent
BRIDGE = 'af9707abdfe0f2982a19920991cdc30e43670b859ce442eb0950b0e9ebb3fb45'
DERIVATION = 'b44291b89f1b1ec4dd6b1ab30c7db1b27712d4be1033ab5d6230405df4da67c4'
CONTROLS = '16daead20d5bf9934371a8283b18a94dc03a45d3390b346d7ef5d7019d8820d8'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(raw, path, name):
    obj = types.ModuleType(name)
    obj.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), obj.__dict__)
    return obj


def adapter_type(bridge):
    class CurrentAdapter(bridge.Adapter):
        def bind_package(self, inputs):
            digest = super().bind_package(inputs)
            author_path = HERE / 'control_derivation.py'
            author = load(inputs.bind(author_path, DERIVATION), author_path, 'current736_f64_factory_derivation')
            generated, self.control_proof = author.derive(inputs.bind)
            control_path = HERE / 'controls736.py'
            actual = inputs.bind(control_path, CONTROLS)
            bridge.require(actual == generated, 'complete two-status controls derivation')
            self.current_controls = load(actual, control_path, 'current736_f64_explicit_factory_statuses')
            # original_modules owns and restores this import slot. Its original
            # module object and every original source file remain unchanged.
            sys.modules['controls'] = self.current_controls
            return digest

        def candidate_admission(self, directory, inputs):
            original = super().candidate_admission(directory, inputs)
            return dict(schema='heptatorch.current736.f64-48.explicit-controls-source-admission.v1',
                source_sha256=bridge.SOURCE, native_sha256=bridge.IMAGE, functions=736, units=14,
                original_identity_source_admission=original,
                original87_source_bytes_unchanged=True,
                current87_expected_status_changes=self.control_proof,
                two_factory_status_expectations_changed=True,
                other85_expected_statuses_unchanged=True,
                numerical_cases_comparison_and_allocation_loops_unchanged=True,
                original_reference_namespace_preserved=True,
                original_strict55_FAIL_preserved=True,
                historical_or_unmodified_original48_PASS_transferred=False,
                native_executed=False, Torch_executed=False, compiler_executed=False)

    return CurrentAdapter


@contextmanager
def current_reader():
    """Expose the same pure admission and original reader to later readback."""
    bridge_path = HERE / 'bridge.py'
    bridge_raw = bridge_path.read_bytes()
    if bridge_path.is_symlink() or sha(bridge_raw) != BRIDGE:
        raise ValueError('exact identity-only original48 bridge required')
    bridge = load(bridge_raw, bridge_path, 'current736_original48_identity_bridge')
    with bridge.original_modules() as (original_modules, original_run, startup_inputs):
        yield adapter_type(bridge)(original_modules, original_run, startup_inputs)


def main():
    with current_reader() as adapter:
        return adapter.current_main()()


if __name__ == '__main__':
    raise SystemExit(main())
