#!/usr/bin/env python3
"""Qualify the first ordinary F64 Tensor candidate on one real cold-built ELF."""
import argparse
import hashlib
import json
import math
import struct
import sys
import traceback
from pathlib import Path

from cases import CASES, CASE_SHA256, BOUNDARY_CONTRACT
from common import (HERE, SOURCE, IMAGE, MAPPING, CHECKS, Inputs, bind_package, candidate_admission,
                    cold_admission, dump, parse, require, sha)
from corpus import groups, batches, input_bytes, comparator
from native import Native, WIRE, make_owner


class Reference:
    def __init__(self, path, expected, inputs, plan, producer_manifest):
        self.root = path.resolve(strict=True).parent
        self.data = parse(inputs.bind(path, expected))
        d = self.data
        require(d['schema'] == 'heptatorch.f64.tensor-reference33.v1' and d['status'] == 'OBSERVED'
                and d['torch_executed'] is True and d['native_executed'] is False
                and d['inputs_unchanged'] is True and d['failures'] == [], 'complete-real-Torch-reference')
        require(d['producer_manifest_sha256'] == producer_manifest
                and d['candidate_admission']['source_sha256'] == SOURCE
                and d['candidate_admission']['whole_inverse_to_823'] is True,
                'exact-new-producer-and-candidate-bound')
        provenance = d['oracle_provenance']
        require(provenance['status'] == 'PASS' and set(provenance['checks']) == CHECKS
                and all(v is True for v in provenance['checks'].values())
                and d['torch_version'] == '2.15.0+cpu'
                and d['torch_git_version'] == 'd0f2af8b66b20da4baa50644c0cd3f887a2eae2e',
                'unchanged-fixed-wheel-provenance')
        require(d['expected_groups'] == len(d['groups']) == 33
                and d['expected_boundary_cases'] == len(d['boundary_cases']) == len(CASES)
                and d['boundary_case_sha256'] == CASE_SHA256 and d['boundary_plan'] == CASES
                and d['boundary_contract'] == BOUNDARY_CONTRACT,
                'all33-and-exact-new-boundary-recipes')
        self.blobs = {}
        for digest, row in d['blob_manifest'].items():
            require(digest == row['sha256'] and row['path'] == 'blobs/' + digest + '.bin',
                    'safe-exact-reference-blob-path')
            self.blobs[digest] = inputs.bind(self.root / row['path'], digest, row['bytes'], row['mode'])
        require(len(self.blob(d['rng'])) == 5056, 'reference-full5056-RNG')
        for index, (source, observed) in enumerate(zip(plan, d['groups'])):
            require(observed['status'] == 'OBSERVED'
                    and all(observed[k] == source[k] for k in ('name', 'mode', 'original_index',
                                                              'input_values', 'original_request_sha256')),
                    'original-numeric-reference-row-identity')
            expected_batches = list(batches(source['pairs']))
            require(len(observed['batches']) == len(expected_batches), 'all-original-batches-observed')
            digest = hashlib.sha256()
            for (offset, batch), entry in zip(expected_batches, observed['batches']):
                require(entry['offset'] == offset and entry['count'] == len(batch)
                        and entry['original_function_witness_matches'] is True,
                        'original-batch-index-and-real-function-witness')
                left, right = input_bytes(source['mode'], batch)
                require(self.blob(entry['left']['logical']) == left
                        and (right is None and entry['right'] is None or right is not None
                             and self.blob(entry['right']['logical']) == right), 'reference-input-bytes-exact')
                raw = self.blob(entry['original_reference_words'])
                require(len(raw) == 8 * len(batch), 'complete-original-reference-word-width')
                digest.update(raw)
                mode = source['mode']
                logical = self.blob(entry['result']['logical'])
                words = [v[0] for v in struct.iter_unpack('<I' if mode == 6 else '<Q', logical)]
                require(b''.join(struct.pack('<Q', x) for x in words) == raw,
                        'actual-Tensor-reference-bits-equal-original-function-words')
            require(digest.hexdigest() == observed['reference_packed_sha256']
                    and self.blob(observed['rng']) == self.blob(d['rng']), 'reference-all-word-and-RNG-binding')
            require(parse(inputs.bind(self.root / ('numeric-%02d.json' % index))) == observed,
                    'reference-numeric-standalone-row-identical')
        for index, (spec, row) in enumerate(zip(CASES, d['boundary_cases'])):
            require(row['status'] == 'OBSERVED' and row['name'] == spec['name'] and row['spec'] == spec
                    and row['rng_unchanged'] is True and self.blob(row['rng']) == self.blob(d['rng']),
                    'complete-Torch-boundary-row')
            require(parse(inputs.bind(self.root / ('boundary-%02d.json' % index))) == row,
                    'reference-boundary-standalone-row-identical')
        recovery = d['allocation_recovery']
        require(recovery['status'] == 'OBSERVED' and recovery['element_count'] == 65536
                and self.blob(recovery['rng']) == self.blob(d['rng']), 'real-recovery-reference')

    def blob(self, row):
        raw = self.blobs[row['sha256']]
        require(row['path'] == 'blobs/' + row['sha256'] + '.bin'
                and len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'bound-reference-blob-record')
        return raw


class Driver:
    def __init__(self, args, owner, directory, reference, compare):
        self.args, self.owner, self.directory, self.reference = args, owner, directory, reference
        self.compare = compare
        self.checks, self.marks, self.operations = [], [], []
        self.live = {}
        self.n = Native(args.build_directory / 'heptatorch', args.build_directory / 'runtime.hepta',
                        owner, directory, args.expected_native_sha256)
        self.gen = None
        try:
            self.gen = self.n.one(60, 1729)['value']
            self.rng = self.n.one(63, self.gen)['payload']
            self.check('complete-native-RNG-equals-fixed-Torch', self.rng, reference.blob(reference.data['rng']))
        except BaseException:
            self.n.finish()
            raise

    def check(self, label, actual, expected):
        def summarize(value):
            return dict(bytes=len(value), sha256=sha(value)) if isinstance(value, bytes) else value
        row = dict(label=label, actual=summarize(actual), expected=summarize(expected), passed=actual == expected)
        self.checks.append(row)
        require(row['passed'], 'actual-native-comparison', **row)

    def rng_unchanged(self, label):
        self.check(label + '/complete5056-RNG', self.n.one(63, self.gen)['payload'], self.rng)

    def observe(self, token, wanted, mode='raw', label='tensor'):
        got = self.n.tensor(token)
        keys = ('dtype', 'device', 'element_size', 'shape', 'strides', 'numel', 'storage_bytes',
                'storage_offset_elements', 'storage_offset_bytes', 'version', 'requires_grad',
                'is_leaf', 'is_view', 'grad_fn', 'grad_is_none', 'retains_grad')
        for key in keys:
            self.check(label + '/' + key, got[key], wanted[key])
        self.check(label + '/base-present', got['base_tensor_identity'] is not None,
                   wanted['base_tensor_identity'] is not None)
        expected = self.reference.blob(wanted['logical'])
        if mode == 'raw':
            self.check(label + '/all-logical-input-bits', got['logical'], expected)
            self.check(label + '/all-physical-Storage-bits', got['storage'], self.reference.blob(wanted['storage']))
        elif mode is not None:
            self.check(label + '/logical-width', len(got['logical']), len(expected))
            code = '<I' if got['element_size'] == 4 else '<Q'
            actual = [x[0] for x in struct.iter_unpack(code, got['logical'])]
            expected_words = [x[0] for x in struct.iter_unpack(code, expected)]
            counts = dict(non_nan_attempted=0, exact_non_nan=0, nan_classification=0, mismatches=[])
            # Same complete original numeric predicate block. Synthetic pair
            # labels here are only diagnostic indexes; no expected number is
            # computed from these labels.
            self.compare(mode, [(0, 0)] * len(actual), 0, actual, expected_words, counts)
            require(not counts['mismatches'], 'actual-Tensor-numerical-bits', label=label, counts=counts)
        else:
            # Corpus rows run the entire original comparator below with the
            # original input pair and global index. Do not stop first in a
            # second comparison that would lose those original diagnostics.
            self.check(label + '/logical-width-before-original-comparison', len(got['logical']), len(expected))
        self.marks.append(dict(label=label, observed={k: v for k, v in got.items() if k not in ('logical', 'storage')},
            logical_bytes=len(got['logical']), logical_sha256=sha(got['logical']),
            storage_sha256=sha(got['storage']), numeric_mode=mode))
        return got

    def mark(self, expected):
        self.check(expected['label'] + '/live-roles', list(self.live), expected['live_roles'])
        current = {name: self.observe(token, expected['tensors'][name], expected['comparison_modes'][name],
                                     expected['label'] + '/' + name) for name, token in self.live.items()}
        for pair, relation in expected['relations'].items():
            left, right = pair.split('|')
            self.check(expected['label'] + '/' + pair + '/same-Tensor',
                current[left]['tensor_identity'] == current[right]['tensor_identity'], relation['same_Tensor'])
            self.check(expected['label'] + '/' + pair + '/same-Storage',
                current[left]['storage_identity'] == current[right]['storage_identity'], relation['same_Storage'])
        for name, wanted in expected['tensors'].items():
            for other, ref in expected['tensors'].items():
                self.check(expected['label'] + '/' + name + '/base-is-' + other,
                    current[name]['base_tensor_identity'] == current[other]['tensor_identity'],
                    wanted['base_tensor_identity'] == ref['tensor_identity'])
        self.rng_unchanged(expected['label'])

    def drop(self, name):
        token = self.live.pop(name)
        if token not in self.live.values():
            self.n.one(41, token)

    def cleanup(self):
        for name in list(self.live)[::-1]:
            self.drop(name)
        self.rng_unchanged('after-all-Tensor-release')
        self.n.one(66, self.gen)
        self.gen = None
        self.check('native-final-owner-audit', self.n.one(53)['value'], 1)
        snapshot, endpoint, raw = self.n.capture('all-public-roles-released')
        self.check('all-real-public-Tensor-slots-released', sum(r[1] for r in snapshot['tables']['1']), 0)
        self.check('all-real-generators-released', sum(r[1] for r in snapshot['tables']['7']), 0)
        self.check('all-live-Tensor-descriptor-roots-released',
            sum(bool(self.owner.w(node, 240)) for node in snapshot['nodes'].values()), 0)
        return endpoint


def numeric_case(driver, group, reference):
    mode = group['mode']
    row = dict(non_nan_attempted=0, exact_non_nan=0, nan_classification=0, mismatches=[], batches=[])
    result_digest = hashlib.sha256()
    for (offset, batch), expected in zip(batches(group['pairs']), reference['batches']):
        left_raw, right_raw = input_bytes(mode, batch)
        driver.live['left'] = driver.n.create(0 if mode == 5 else 4, [len(batch)], left_raw)
        if right_raw is not None:
            driver.live['right'] = driver.n.create(4, [len(batch)], right_raw)
        driver.observe(driver.live['left'], expected['left'], label='input-left')
        if right_raw is not None:
            driver.observe(driver.live['right'], expected['right'], label='input-right')
        if mode < 4:
            command = (2, mode + 1, driver.live['left'], driver.live['right'])
        else:
            command = (108, driver.live['left'], 4 if mode == 5 else 0, 0, 0)
        driver.live['result'] = driver.n.one(*command)['value']
        got = driver.observe(driver.live['result'], expected['result'], mode=None, label='numeric-result')
        actual = [x[0] for x in struct.iter_unpack('<I' if mode == 6 else '<Q', got['logical'])]
        wanted = [x[0] for x in struct.iter_unpack('<Q', driver.reference.blob(expected['original_reference_words']))]
        driver.compare(mode, batch, offset, actual, wanted, row)
        result_digest.update(b''.join(struct.pack('<Q', value) for value in actual))
        driver.observe(driver.live['left'], expected['left'], label='unchanged-input-left')
        if right_raw is not None:
            driver.observe(driver.live['right'], expected['right'], label='unchanged-input-right')
        driver.rng_unchanged('numeric-batch-' + str(offset))
        row['batches'].append(dict(offset=offset, count=len(batch), command=list(command),
            actual_logical_sha256=sha(got['logical']), actual_packed_words_sha256=sha(
                b''.join(struct.pack('<Q', value) for value in actual))))
        with (driver.directory / 'numeric-progress.jsonl').open('a') as stream:
            stream.write(json.dumps(dict(original_index=group['original_index'], offset=offset,
                batch_count=len(batch), non_nan_attempted=row['non_nan_attempted'],
                exact_non_nan=row['exact_non_nan'], nan_classification=row['nan_classification'],
                original_mismatches=list(row['mismatches'])), allow_nan=False) + '\n')
        for name in list(driver.live)[::-1]:
            driver.drop(name)
    require(not row['mismatches'], 'original-entire-numeric-comparison', mismatches=row['mismatches'])
    row.update(original_index=group['original_index'], original_request_sha256=group['original_request_sha256'],
        actual_tensor_packed_words_sha256=result_digest.hexdigest(), input_values=group['input_values'])
    return row


def boundary_case(driver, spec, reference):
    from reference import words_raw
    at = 0
    for event in spec['actions']:
        kind = event['kind']
        if kind == 'create':
            token = driver.n.create(event['dtype'], event['shape'],
                words_raw(event['dtype'], event['words']), event['requires'])
            driver.live[event['name']] = token
        elif kind == 'view':
            driver.live[event['name']] = driver.n.view(driver.live[event['source']],
                event['shape'], event['strides'], event['offset'])
        elif kind == 'cast':
            source = driver.live[event['source']]
            # Opcode109 has its own fixed word layout: target, memory format;
            # opcode108 uses target, copy flag, memory format.
            command = ((109, source, event['target'], event['format']) if event['opcode'] == 109 else
                       (108, source, event['target'], int(event['copy']), event['format']))
            driver.live[event['name']] = driver.n.one(*command)['value']
        elif kind == 'binary':
            driver.live[event['name']] = driver.n.one(2, event['operation'],
                driver.live[event['left']], driver.live[event['right']])['value']
        elif kind == 'set':
            driver.n.one(12, driver.live[event['source']], event['index'], event['bits'])
        elif kind == 'fill':
            driver.n.one(100, driver.live[event['source']], event['bits'], 0)
        else:
            raise ValueError(kind)
        driver.mark(reference['marks'][at])
        at += 1
    for name in list(driver.live)[::-1]:
        driver.drop(name)
        driver.mark(reference['marks'][at])
        at += 1
    driver.check('every-fixed-reference-mark-consumed', at, len(reference['marks']))
    return dict(reference_marks_completed=at, raw_set_fill_preserve_all_bits=True)


def run_child(args, owner, directory, reference, compare, name, function):
    row = dict(name=name, status='FAIL', error=None, native_started=False)
    driver = None
    try:
        driver = Driver(args, owner, directory, reference, compare)
        row['native_started'] = True
        row['details'] = function(driver)
        row['cleanup_owner'] = driver.cleanup()
        row['status'] = 'PASS'
    except BaseException as error:
        row['error'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
    finally:
        if driver is not None:
            try:
                row['transport'] = driver.n.finish()
            except BaseException as error:
                row['status'] = 'FAIL'
                row['EOF_error'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
            row.update(frames=driver.n.s.frames, checks=driver.checks, observations=driver.marks,
                       operations=driver.operations)
        elif (directory / 'raw/transport.json').exists():
            # A constructor may fail after the actual child was created.
            # Preserve that execution fact and its real EOF result.
            row['transport'] = parse((directory / 'raw/transport.json').read_bytes())
            row['native_started'] = True
            row['frames'] = row['transport']['frames']
        if directory.exists():
            dump(directory / 'report.json', row)
    return row


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('candidate', 'build-directory', 'reference', 'output'):
        p.add_argument('--' + name, required=True, type=Path)
    for name in ('expected-source-sha256', 'expected-native-sha256', 'expected-build-sha256',
                 'expected-reference-sha256'):
        p.add_argument('--' + name, required=True)
    p.add_argument('--prepare-only', action='store_true')
    args = p.parse_args()
    require(not sys.flags.optimize, 'assertions-enabled')
    require(args.expected_source_sha256 == SOURCE, 'exact-frozen736-source-required')
    require(args.expected_native_sha256 == IMAGE, 'exact-real736-ELF-required')
    args.build_directory = args.build_directory.resolve(strict=True)
    args.candidate = args.candidate.resolve(strict=True)
    out = args.output.resolve()
    for path in (HERE, args.candidate, args.build_directory, args.reference.resolve().parent):
        require(not out.is_relative_to(path) and not path.is_relative_to(out), 'output-isolated-from-bound-inputs')
    out.mkdir(parents=True, exist_ok=False)
    inputs, result, code = Inputs(), {}, 1
    result.update(schema='heptatorch.f64.tensor-native736.v1', status='PREPARED_NOT_RUN',
        source_sha256=SOURCE, native_sha256=args.expected_native_sha256,
        actual_build_sha256=args.expected_build_sha256, reference_sha256=args.expected_reference_sha256,
        native_executed=False, Torch_executed=False, compiler_executed=False,
        expected_numeric_groups=33, expected_boundary_cases=len(CASES), expected_entry_groups=1,
        expected_allocation_controls=2, numeric_groups=[], boundary_cases=[], entry_groups=[],
        allocation_controls=[], failures=[], all_inputs_unchanged=False, boundary_contract=BOUNDARY_CONTRACT,
        original_strict55_modified=False, original_strict55_failed_groups=4,
        original_strict55_mismatches=4008, original_sqrt_groups_not_exposed=6,
        original_standalone_refusals_not_transferred=16, full_dtype_gate_closed=False,
        full_project_status='HOLD', full_transition_recomputed=False)
    try:
        package = bind_package(inputs)
        result['reader_manifest_sha256'] = package
        result['source_admission'] = candidate_admission(args.candidate, inputs)
        result['cold_admission'] = cold_admission(args.build_directory, args.expected_native_sha256,
                                               args.expected_build_sha256, inputs)
        mapping = parse(inputs.bind(FROZEN_CANDIDATE / 'original55-mapping.json', MAPPING))
        plan = groups(inputs, mapping)
        compare, result['original_comparison_inverse'] = comparator(inputs)
        reference = Reference(args.reference, args.expected_reference_sha256, inputs, plan, FROZEN_PRODUCER_MANIFEST)
        result['case_plan'] = [{k: v for k, v in g.items() if k != 'pairs'} for g in plan]
        if not args.prepare_only:
            from controls import entry_controls, allocation_control
            owner = make_owner(args.candidate, args.expected_native_sha256, inputs)
            result['native_executed'] = True
            tasks = []
            for index, (group, expected) in enumerate(zip(plan, reference.data['groups'])):
                tasks.append(('numeric_groups', 'numeric-%02d' % index, group['name'],
                              lambda d, g=group, r=expected: numeric_case(d, g, r)))
            for index, (spec, expected) in enumerate(zip(CASES, reference.data['boundary_cases'])):
                tasks.append(('boundary_cases', 'boundary-%02d' % index, spec['name'],
                              lambda d, s=spec, r=expected: boundary_case(d, s, r)))
            tasks.append(('entry_groups', 'entry-00', 'explicit-dtype-raw-and-noAD-boundaries', entry_controls))
            for stage in ('cast', 'binary'):
                tasks.append(('allocation_controls', 'allocation-' + stage, 'F64-' + stage + '-actual-OOM-recovery',
                              lambda d, s=stage: allocation_control(d, s)))
            for group, directory, name, function in tasks:
                row = run_child(args, owner, out / directory, reference, compare, name, function)
                result[group].append(row)
                if row['status'] != 'PASS':
                    result['failures'].append(dict(group=group, name=name, error=row['error'],
                                                   EOF_error=row.get('EOF_error')))
            require(len(result['numeric_groups']) == 33 and len(result['boundary_cases']) == len(CASES)
                    and len(result['entry_groups']) == 1 and len(result['allocation_controls']) == 2,
                    'all-mandatory-new-Tensor-groups-completed')
            children = [row for group in ('numeric_groups', 'boundary_cases', 'entry_groups', 'allocation_controls')
                        for row in result[group]]
            result['native_children'] = len(children)
            result['frames'] = sum(row.get('frames', 0) for row in children)
            result['status'] = 'PASS' if not result['failures'] and all(row['status'] == 'PASS' for row in children) else 'FAIL'
        code = 0 if result['status'] in ('PASS', 'PREPARED_NOT_RUN') else 1
    except BaseException as error:
        result['status'] = 'FAIL'
        result['failures'].append(dict(stage='admission-or-run', type=type(error).__name__,
                                      message=str(error), traceback=traceback.format_exc()))
        code = 1
    finally:
        try:
            result['all_inputs_unchanged'] = inputs.unchanged()
        except BaseException as error:
            result['status'], code = 'FAIL', 1
            result['failures'].append(dict(stage='final-input-recheck', error=repr(error)))
        result['inputs'] = inputs.rows
        dump(out / 'report.json', result)
    print(json.dumps({k: result[k] for k in ('status', 'expected_numeric_groups',
                                            'expected_boundary_cases', 'native_executed')}))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
