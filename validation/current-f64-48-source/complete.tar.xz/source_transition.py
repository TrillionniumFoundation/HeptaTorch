"""Restore the exact original F64 719 source from the current 736 source.

This is a complete source-byte inverse, not a runtime equivalence assertion.
The admitted executable remains the current executable. No application runs.
"""
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
SOURCE = '51820849f7becec549be15babace00f00687601ae7f53bcee0e636ca02f721f9'
ORIGINAL = 'e2eedf870e306572672817cfc98bcf49d9aeacc0657c04dbaf50e5e6f5ceb66d'
DELTA = '036c99850b7fa6f06f69b5e6c1f60381efac80c79c4787c33745adeceb811baf'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(ok, label):
    if not ok:
        raise ValueError(label)


def functions(raw, count):
    matches = list(re.finditer(rb'^fn ([A-Za-z_][A-Za-z0-9_]*)\(.*?^end\n', raw, re.M | re.S))
    rows = {match[1].decode(): match[0] for match in matches}
    header = raw.split(b'\n', 1)[0] + b'\n'
    require(len(rows) == len(matches) == count, 'exact complete function count')
    require(header + b''.join(rows.values()) == raw, 'no bytes outside header and complete functions')
    return header, rows


def checked_body(row, name, prefix=''):
    body = row[prefix + 'body'].encode()
    require(body.startswith(('fn ' + name + '(').encode()) and body.endswith(b'end\n')
            and len(body) == row[prefix + 'bytes'] and sha(body) == row[prefix + 'sha256'],
            'complete pinned function body: ' + name)
    return body


def restore_source(source, bind):
    bind(Path(__file__).resolve())
    require(sha(source) == SOURCE, 'only the exact current736 source is admitted')
    raw = bind(HERE / 'source-transition.json', DELTA)
    delta = json.loads(raw)
    require(delta['schema'] == 'heptatorch.current736-to-original-f64-719.full-source-delta.v1'
            and delta['current']['sha256'] == SOURCE and delta['original']['sha256'] == ORIGINAL
            and delta['current']['functions'] == 736 and delta['original']['functions'] == 719,
            'exact source profile pair')
    header, current = functions(source, 736)
    require(header.decode() == delta['current']['header']
            and len(source) == delta['current']['bytes']
            and list(current) == delta['current']['order'], 'complete current extent and declaration order')
    old_order = delta['original']['order']
    changed, added, removed, unchanged = (delta[key] for key in
        ('changed', 'added', 'removed', 'unchanged'))
    require(len(old_order) == len(set(old_order)) == 719
            and len(changed) == 22 and len(added) == 24 and len(removed) == 7
            and len(unchanged) == 690
            and set(changed) | set(unchanged) | set(removed) == set(old_order)
            and set(changed) | set(unchanged) | set(added) == set(current)
            and not (set(changed) & set(unchanged))
            and not (set(removed) & set(current)) and not (set(added) & set(old_order)),
            'exact690 unchanged,22 changed,7 removed,24 added partition')
    old_bodies = {}
    for name, row in unchanged.items():
        body = current[name]
        require(len(body) == row['bytes'] and sha(body) == row['sha256'],
                'unchanged complete function: ' + name)
        old_bodies[name] = body
    for name, row in changed.items():
        before, after = checked_body(row, name, 'before_'), checked_body(row, name, 'after_')
        require(before != after and current[name] == after, 'exact changed current body: ' + name)
        old_bodies[name] = before
    for name, row in removed.items():
        old_bodies[name] = checked_body(row, name)
    for name, row in added.items():
        require(current[name] == checked_body(row, name), 'exact added current body: ' + name)
    original = delta['original']['header'].encode() + b''.join(old_bodies[name] for name in old_order)
    old_header, old = functions(original, 719)
    require(len(original) == delta['original']['bytes'] and sha(original) == ORIGINAL
            and list(old) == old_order, 'every original source byte and its ordering is restored')
    forward = header + b''.join(
        checked_body(changed[name], name, 'after_') if name in changed else
        checked_body(added[name], name) if name in added else old[name]
        for name in delta['current']['order'])
    require(forward == source, 'complete current source round trip')
    callers = {name: sorted(caller for caller, body in old.items()
                           if ('"function":"' + name + '"').encode() in body)
               for name in removed}
    require(callers == delta['removed_original_callers']
            and all(not value for value in callers.values()),
            'the seven removed declarations have no original source call sites')
    proof = dict(schema='heptatorch.current736-to-original-f64-719.full-source-inverse.v1',
        source_sha256=SOURCE, original_source_sha256=ORIGINAL, source_functions=736,
        original_functions=719, whole_source_inverse_exact=True, whole_round_trip_exact=True,
        unchanged_complete_functions=690, changed_functions=list(changed),
        removed_functions=list(removed), added_functions=list(added),
        removed_original_callers=callers, delta_sha256=DELTA,
        original_header_restored=old_header.decode(),
        current_executable_replaced=False, runtime_equivalence_proved=False,
        historical_runtime_PASS_transferred=False, cases_or_expected_values_changed=False,
        native_executed=False, Torch_executed=False, compiler_executed=False)
    return original, proof
