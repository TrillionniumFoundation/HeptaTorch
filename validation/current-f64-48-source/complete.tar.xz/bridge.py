"""Current736 identity and strict cold admission for original F64 48 cases.

Reference keeps the exact original719 namespace. The original case, comparison,
full-owner, transaction, resource and EOF implementations remain unchanged.
This bridge does not inherit the historical48 PASS or repair strict55 FAILs.
"""
import ast
import contextlib
import hashlib
import json
import os
import re
import stat
import sys
import types
from pathlib import Path

HERE = Path(__file__).resolve().parent
FROZEN = HERE / 'frozen719'
FROZEN_CANDIDATE = HERE / 'frozen-candidate719'
SOURCE = '51820849f7becec549be15babace00f00687601ae7f53bcee0e636ca02f721f9'
IMAGE = 'aa3cc8f0c8738a9505d31c9e8ba5a523b7e08b591b61fc7bfb8592295491618b'
REFERENCE = 'b1dafeed270b4dd226c349dece9d7f6213c2dabd34681685d97ec13c068e9b11'
PRODUCER = '23d09ddb6414eca8610e80ff17519129dc6175c02789f8c693a8e1ef36bd590e'
PRODUCER_SOURCE = 'e2eedf870e306572672817cfc98bcf49d9aeacc0657c04dbaf50e5e6f5ceb66d'
COMMON = '6849c9941cd5a0e436a7ab60757c0a1cc90885d8756cb913c9e1cec746f44627'
ORIGINAL_RUN = 'aa0201607f50b5633d25bab41a009c2c53af2b080cf87ca9080fe723934957b1'
PARTITION = '28865982694c45b8b022ad9ee63255e31b6001f2b0004652e099d2de39ae5885'
QUALIFICATION = '9a45cee45a289dae0a35b0a256f66f6a1ea2d3c8becd30bb2174da1ffb51e9bb'
BUILDER = '9c93f8ff3fcfda8358e51a4c12efb3b0e0962abed9b5a750ca32d5a5568ac14d'
IDENTITY_AUTHOR = '32e34e3e5445f9118cbd79cdfd57027f724e5e1fddc1dae1ccb0e3ba8608a12f'
IDENTITY_PROOF = 'd8f22cccf4cdd9bb39f7338ec2b50f3c5db95877c544a9fd6751411bb886dc99'
SOURCE_HELPER = '343845599a01a12379b86f49045e8650f6068e4da722bb3b2bd8df0e7a64c14a'
OWNER = '4f041444918c9bb4c1cbd1c7ca3072ce4ae7d03ccef38adb4fe50124aa7382a4'
DERIVED_RUN = '0622fc0557ae853289a921b4d0d8256d551ae05e1f7829eb77286ea0169e0032'


def require(value, message):
    if not value:
        raise AssertionError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique(pairs):
    out = {}
    for name, value in pairs:
        require(name not in out, 'duplicate JSON key: ' + name)
        out[name] = value
    return out


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique)


def regular(path, expected):
    path = Path(path)
    require(not path.is_symlink(), 'symlink input: ' + str(path))
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    require(stat.S_ISREG(after.st_mode) and
            (before.st_dev, before.st_ino, before.st_mode, before.st_size,
             before.st_mtime_ns, before.st_ctime_ns) ==
            (after.st_dev, after.st_ino, after.st_mode, after.st_size,
             after.st_mtime_ns, after.st_ctime_ns), 'changed or nonregular input')
    require(sha(raw) == expected, 'input SHA: ' + str(path))
    return raw


def module(raw, name, path):
    result = types.ModuleType(name)
    result.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), result.__dict__)
    return result


def definition(raw, name):
    lines = raw.decode().splitlines(keepends=True)
    nodes = [n for n in ast.parse(raw).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))
             and n.name == name]
    require(len(nodes) == 1, 'unique source definition: ' + name)
    node = nodes[0]
    return ''.join(lines[node.lineno - 1:node.end_lineno]).encode()


def manifest(directory, filename, expected, inputs):
    directory = Path(directory).resolve(strict=True)
    raw = inputs.bind(directory / filename, expected)
    doc = parse(raw)
    names = set(doc['files'])
    physical = set()
    for path in directory.rglob('*'):
        require(not path.is_symlink(), 'no symlink inside source package')
        if path.is_file():
            physical.add(path.relative_to(directory).as_posix())
    require(physical == names | {filename}, 'complete physical source-package members')
    for name, row in doc['files'].items():
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts and path.as_posix() == name,
                'safe normalized source-package path')
        inputs.bind(directory / path, row['sha256'], row['bytes'], row['mode'])
    return sha(raw), doc


@contextlib.contextmanager
def original_modules():
    """Load the complete pinned old package; never run its main or producer."""
    names = ('common', 'cases', 'corpus', 'reference', 'native', 'controls')
    missing = object()
    previous = {name: sys.modules.get(name, missing) for name in names}
    previous_bytecode = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        common = module(regular(FROZEN / 'common.py', COMMON), 'f64_original719_common', FROZEN / 'common.py')
        sys.modules['common'] = common
        startup_inputs = common.Inputs()
        manifest(FROZEN, 'source-manifest.json', PRODUCER, startup_inputs)
        require(common.HERE == FROZEN and common.SOURCE == PRODUCER_SOURCE,
                'old producer namespace stays719')
        old_modules = {'common': common}
        for name in names[1:]:
            path = FROZEN / (name + '.py')
            raw = startup_inputs.bind(path)
            old_modules[name] = module(raw, 'f64_original719_' + name, path)
            sys.modules[name] = old_modules[name]
        old_run = module(startup_inputs.bind(FROZEN / 'run.py', ORIGINAL_RUN),
                         'f64_original719_run', FROZEN / 'run.py')
        require(old_run.Reference.__init__.__globals__['SOURCE'] == PRODUCER_SOURCE,
                'original Reference global source must stay719')
        yield old_modules, old_run, startup_inputs
        startup_inputs.unchanged()
    finally:
        for name in names:
            if previous[name] is missing:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = previous[name]
        sys.dont_write_bytecode = previous_bytecode


class Adapter:
    def __init__(self, old_modules, old_run, startup_inputs):
        self.old, self.run, self.startup_inputs = old_modules, old_run, startup_inputs
        self.repository = self.profile = self.identity = None

    def bind_package(self, inputs):
        digest, _ = manifest(HERE, 'source-manifest.json', None, inputs)
        manifest(FROZEN, 'source-manifest.json', PRODUCER, inputs)
        for path, row in self.startup_inputs.rows.items():
            inputs.bind(path, row['sha256'], row['bytes'], row['mode'])
        author_path = HERE / 'identity.py'
        author = module(inputs.bind(author_path, IDENTITY_AUTHOR), 'f64_736_identity_author', author_path)
        generated, proof = author.derive(inputs.bind)
        for name, expected in generated.items():
            require(inputs.bind(HERE / name) == expected, 'complete identity rederivation: ' + name)
        require(inputs.bind(HERE / 'identity-derivation.json', IDENTITY_PROOF) ==
                generated['identity-derivation.json'], 'exact complete identity inverse')
        require(self.run.Reference.__init__.__globals__['SOURCE'] == PRODUCER_SOURCE,
                'reference continues to describe the original719 producer')
        self.identity = proof
        return digest

    def candidate_admission(self, directory, inputs):
        repository = Path(directory).resolve(strict=True)
        raw = inputs.bind(repository / 'tools/current_runtime/source/manifest.json', PARTITION)
        planned = parse(raw)
        require(planned['runtime']['sha256'] == SOURCE and planned['runtime']['functions'] == 736
                and planned['expected_native_sha256'] == IMAGE and len(planned['units']) == 14,
                'exact736 source,14 units and actual image profile')
        source = inputs.bind(repository / 'tools/current_runtime/source/runtime.hepta', SOURCE)
        helper_path = HERE / 'source_transition.py'
        helper = module(inputs.bind(helper_path, SOURCE_HELPER), 'f64_736_source_inverse', helper_path)
        restored, source_proof = helper.restore_source(source, inputs.bind)
        require(restored == inputs.bind(FROZEN_CANDIDATE / 'candidate/runtime.hepta', PRODUCER_SOURCE),
                'all original719 source bytes reconstructed from actual736')
        old_admission = self.old['common'].candidate_admission(FROZEN_CANDIDATE, inputs)
        qpath = repository / 'tools/current_runtime/qualification.py'
        profile = module(inputs.bind(qpath, QUALIFICATION), 'f64_736_strict_shared_admission', qpath)
        require(profile.SOURCE == SOURCE and profile.IMAGE == IMAGE
                and profile.FUNCTIONS == 736 and profile.UNITS == 14
                and profile.ROOT == repository and profile.PROFILE_BYTES == raw,
                'same actual repository profile for source and cold build')
        inputs.bind(repository / 'tools/current_runtime/build.py', BUILDER)
        self.repository, self.profile = repository, profile
        return dict(schema='heptatorch.current736-original-f6448.source-admission.v1',
            source_sha256=SOURCE, native_sha256=IMAGE, functions=736, units=14,
            complete736_to719_inverse=source_proof, original719_source_admission=old_admission,
            current_source_manifest_sha256=PARTITION, strict_shared_admission_sha256=QUALIFICATION,
            original_reference_producer_source_sha256=PRODUCER_SOURCE,
            original_reference_producer_manifest_sha256=PRODUCER,
            reader_identity_inverse=self.identity, original87_expectations_changed=False,
            original_strict55_failures_preserved=True, numerical_expected_values_changed=False,
            prior_runtime_PASS_transferred=False, native_executed=False, Torch_executed=False,
            original_boundary_contract_is_original719_scope=True,
            original_sum_refusal_is_default_dtype_U64MAX=True,
            current_explicit_Bool_sum_and_any_all_outside_this48_suite=True)

    def cold_admission(self, directory, image_sha, report_sha, inputs):
        require(self.repository is not None and self.profile is not None,
                'source profile admission precedes cold build admission')
        require(image_sha == IMAGE and re.fullmatch('[0-9a-f]{64}', report_sha) is not None,
                'current image and explicit actual cold receipt identity')
        directory = Path(directory).resolve(strict=True)
        physical = {}
        def bound(path, expected=None):
            raw = inputs.bind(path, expected)
            key = str(Path(path).absolute())
            physical[key] = inputs.rows[key]
            return raw
        built = self.profile.admit_build(directory, bound, report_sha)
        require(len(physical) == 69 and built['functions'] == 736 and len(built['units']) == 14
                and len(built['processes']) == 15,
                'all69 physical current inputs and14 compiler plus1 linker processes')
        require(inputs.bind(directory / 'manifest.json', PARTITION) == self.profile.PROFILE_BYTES,
                'source and cold manifests identical')
        return dict(schema='heptatorch.current736-original-f6448.cold-admission.v1',
            status='PASS_BUILD_ADMISSION_ONLY', source_sha256=SOURCE, native_sha256=IMAGE,
            build_sha256=report_sha, functions=736, units=14, physical_inputs=69, files=physical,
            compiler_processes=14, linker_processes=1,
            shared_admission_sha256=QUALIFICATION, builder_sha256=BUILDER,
            manifest_sha256=PARTITION, original_shared_predicates_unchanged=True,
            link_request_magic='HIACGS01', four_argument_linker=True,
            historical730_fixed_build_receipt_used=False, native_executed_by_admission=False,
            Torch_executed_by_admission=False, runtime_qualification_inferred=False)

    def reference(self, path, expected, inputs, plan, producer_manifest):
        require(expected == REFERENCE and producer_manifest == PRODUCER,
                'exact original reference and original producer manifest')
        require(self.old['common'].SOURCE == PRODUCER_SOURCE
                and self.run.Reference.__init__.__globals__['SOURCE'] == PRODUCER_SOURCE,
                'original Reference namespace has not been rebound to736')
        return self.run.Reference(path, expected, inputs, plan, producer_manifest)

    def make_owner(self, candidate, image_sha, inputs):
        require(Path(candidate).resolve(strict=True) == self.repository and image_sha == IMAGE,
                'owner belongs to the admitted current736 image')
        path = HERE / 'owner736.py'
        owner = module(inputs.bind(path, OWNER), 'f64_736_original_full_owner', path)
        owner.bind_profile(SOURCE, IMAGE, 736)
        require(owner.SOURCE == SOURCE and owner.IMAGE == IMAGE, 'exact current736 owner identity')
        return owner

    def current_main(self):
        raw = regular(HERE / 'derived719_run.py', DERIVED_RUN)
        namespace = dict(self.run.__dict__)
        namespace.update(HERE=HERE, SOURCE=SOURCE, IMAGE=IMAGE, FROZEN_CANDIDATE=FROZEN_CANDIDATE,
            FROZEN_PRODUCER_MANIFEST=PRODUCER, bind_package=self.bind_package,
            candidate_admission=self.candidate_admission, cold_admission=self.cold_admission,
            Reference=self.reference, make_owner=self.make_owner)
        exec(compile(definition(raw, 'main'), str(HERE / 'derived719_run.py') + '::main', 'exec'), namespace)
        require(self.run.Reference.__init__.__globals__['SOURCE'] == PRODUCER_SOURCE,
                'new main does not mutate original Reference globals')
        return namespace['main']


def main():
    with original_modules() as (old_modules, old_run, startup_inputs):
        return Adapter(old_modules, old_run, startup_inputs).current_main()()


if __name__ == '__main__':
    raise SystemExit(main())
