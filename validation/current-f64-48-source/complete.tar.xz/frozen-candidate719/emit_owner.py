#!/usr/bin/env python3
"""Prepare a strictly bound F64 read-only observer; no child/native execution."""
from pathlib import Path
import ast
import hashlib
import json

HERE=Path(__file__).resolve().parent
FROZEN=Path('/tmp/heptatorch-current32-parity/frozen/owner_integral.py')
PIN='c39600e7c37dea390f88cf9e74d86dfa924301456e0f32e127d82c98ad6778b0'
SHA=lambda b:hashlib.sha256(b).hexdigest()

ADDITIVE=r'''

# BEGIN EXPLICIT PUBLIC F64 OBSERVATION; numerical expected values live elsewhere.
_f64_original_verify_snapshot = verify_snapshot
_f64_original_verify_frame_boundary = verify_frame_boundary
_f64_original_bind_profile = bind_profile
F64_SOURCE_SHA256 = "SOURCE_PIN"
F64_ZERO_FIELDS = (24,32,40,48,56,72,80,176,184,248,288,360,384,408,
                   584,592,600,608,616,624,632,640,648,656,664)


def bind_profile(source_sha256, native_sha256, functions):
    need(source_sha256 == F64_SOURCE_SHA256 and functions == 719,
         "f64-source-candidate-profile-required")
    # IMAGE must be an actual separately observed cold-build hash supplied by
    # the eventual native reader. No executable has yet been built or pinned.
    return _f64_original_bind_profile(source_sha256, native_sha256, functions)


def f64_role(snapshot, index):
    node = _live_node(snapshot, index, "f64-live-node")
    need(w(node,576) == 4 and not any(w(node,f) for f in F64_ZERO_FIELDS),
         "f64-public-no-AD-no-Saved-no-ViewInfo", node=index)
    need(w(node,240) == 1, "f64-live-real-Tensor-row", node=index)
    storage = _live_row(snapshot,2,w(node,216),"f64-real-Storage")
    version = _live_row(snapshot,3,w(node,224),"f64-real-Version")
    need(w(node,232) == 0 and storage[3] == 8*w(node,8),
         "f64-eight-byte-storage-exact-extent", node=index)
    return {"node":index, "dtype":4, "width":8,
            "storage":w(node,216), "version":w(node,224),
            "actual_version_value":version[2], "storage_bytes":storage[3],
            "requires_grad":False, "autograd_operation":0,
            "ViewInfo_absent":True, "Saved_absent":True}


def verify_snapshot(snapshot):
    checked = _f64_original_verify_snapshot(snapshot)
    actual = [f64_role(snapshot,int(name)) for name,node in snapshot["nodes"].items()
              if w(node,304) and w(node,576)==4]
    return {**checked, "ordinary_f64_nodes":actual,
            # Three old dtype membership predicates and one width table were
            # extended explicitly. Never describe that as an unchanged old
            # predicate domain; every original 84-word field check still runs.
            "all_original_84Q_predicates_retained":False,
            "all_original_84Q_fields_checked":True,
            "old_dtype_domains_and_private_scalar3_preserved":True,
            "explicit_dtype_domain_extension":[4],
            "full_transition_recomputed":False}


def _f64_source_unchanged(before,after,index):
    need(before["nodes"][str(index)]==after["nodes"][str(index)],
         "f64-input-complete84words-unchanged",node=index)


def _f64_fresh_result(before,after,result,sources):
    node=_live_node(after,result,"f64-new-result")
    need(str(result) not in before["nodes"] or not w(before["nodes"][str(result)],304),
         "f64-new-live-node")
    version=_live_row(after,3,w(node,224),"f64-new-Version")
    storage=_live_row(after,2,w(node,216),"f64-new-Storage")
    need(version[2]==0 and w(node,232)==0 and
         storage[3]==(8 if w(node,576)==4 else 4)*w(node,8),
         "f64-result-fresh-zero-Version-and-complete-storage")
    for source in sources:
        old=before["nodes"][str(source)]
        need(result!=source and w(node,320)!=w(old,320)
             and w(node,216)!=w(old,216) and w(node,224)!=w(old,224),
             "f64-result-distinct-T-S-V",source=source)


def f64_command_metadata(before,after,command,record):
    op=command[0]
    need(record["opcode"]==op,"f64-response-opcode")
    if op==97 and command[1]==4:
        result=public_node(after,record["value"])
        role=f64_role(after,result)
        _f64_fresh_result(before,after,result,[])
        return {"operation":97,"role":role,"explicit_dtype4":True}
    if op==2:
        left=public_node(before,command[2]); right=public_node(before,command[3])
        if w(before["nodes"][str(left)],576)!=4:
            return None
        need(command[1] in (1,2,3,4) and w(before["nodes"][str(right)],576)==4,
             "f64-explicit-binary-pair-no-mixed-promotion")
        result=public_node(after,record["value"])
        role=f64_role(after,result)
        _f64_fresh_result(before,after,result,[left,right])
        _f64_source_unchanged(before,after,left);_f64_source_unchanged(before,after,right)
        return {"operation":2,"binary_operation":command[1],"role":role,
                "input_all84words_unchanged":True}
    if op in (108,109):
        source=public_node(before,command[1]); old=before["nodes"][str(source)]
        source_dtype,target_dtype=w(old,576),command[2]
        if source_dtype!=4 and target_dtype!=4:
            return None
        need(source_dtype in (0,4) and target_dtype in (0,4) and w(old,32)==0,
             "f64-cast-explicit-F32-F64-noAD-pair")
        result=public_node(after,record["value"])
        node=_live_node(after,result,"f64-cast-result")
        need(w(node,576)==target_dtype and not any(w(node,f) for f in F64_ZERO_FIELDS),
             "f64-cast-target-dtype-noAD-Saved-or-view")
        _f64_source_unchanged(before,after,source)
        if result==source:
            need(op==108 and command[3]==0 and target_dtype==source_dtype,
                 "f64-cast-alias-only-explicit-same-dtype-no-copy")
        else:
            _f64_fresh_result(before,after,result,[source])
        return {"operation":op,"source_dtype":source_dtype,"result_dtype":target_dtype,
                "actual_same_Tensor":result==source,"input_all84words_unchanged":True,
                "numerical_conversion_reference_compared_here":False}
    return None


def verify_frame_boundary(before,after,commands,frame_status,records,body,*,
                          before_raw=None,after_raw=None):
    original=_f64_original_verify_frame_boundary(before,after,commands,frame_status,records,body,
                       before_raw=before_raw,after_raw=after_raw)
    details=None
    if not frame_status and any(c[0] in (2,97,108,109) for c in commands):
        # No invented intermediate owners for batched public operations.
        need(len(commands)==1,"f64-new-operation-one-command-per-observation")
        details=f64_command_metadata(before,after,commands[0],records[0])
    return {**original,"f64_command_details":details,
            "numeric_expected_values_computed_here":False,
            "full_transition_recomputed":False}
# END EXPLICIT PUBLIC F64 OBSERVATION
'''


def main():
    old=FROZEN.read_bytes();assert SHA(old)==PIN
    source=json.loads((HERE/'candidate/transition.json').read_bytes())['source_sha256']
    edits=[
        ('HTSINT01','HTSINT02',2),('HTOSIN01','HTOSIN02',2),
        ('functions == 699','functions == 719',1),
        ('sum-integral-source01-UNBOUND-699','f64-source01-UNBOUND-719',1),
        ('sum-integral-source01-%d-preserved47-48','f64-source01-%d-full-owner',1),
        ('heptatorch.sum-integral-owner-source01.v1','heptatorch.f64-candidate-owner.v1',1),
        ('dtype in (0, 1, 2, 3)','dtype in (0, 1, 2, 3, 4)',1),
        ('width = (4, 1, 8, 8)[dtype]','width = (4, 1, 8, 8, 8)[dtype]',1),
        ('row[3] in (0, 1, 2, 3)','row[3] in (0, 1, 2, 3, 4)',1),
        ('row[4] in (0, 1, 2, 3)','row[4] in (0, 1, 2, 3, 4)',1),
        ('# The only admitted binary64 Tensor is the original wrapped scalar.',
         '# Private dtype3 remains the original wrapped binary64 scalar.',1),
    ]
    changed=old
    for before,after,count in edits:
        assert changed.count(before.encode())==count,(before,count)
        changed=changed.replace(before.encode(),after.encode())
    additive=ADDITIVE.replace('SOURCE_PIN',source).encode()
    result=changed+additive
    inverse=result.removesuffix(additive)
    for before,after,count in reversed(edits):
        assert inverse.count(after.encode())==count,(after,count)
        inverse=inverse.replace(after.encode(),before.encode())
    assert inverse==old
    ast.parse(result)
    (HERE/'candidate/frozen-owner-integral.py').write_bytes(old)
    (HERE/'candidate/owner_f64.py').write_bytes(result)
    receipt={'schema':'heptatorch.public-f64-owner-derivation.v1',
        'status':'SOURCE_ONLY_OBSERVER_NOT_EXECUTED',
        'frozen_owner_sha256':PIN,'candidate_owner_sha256':SHA(result),
        'source_sha256':source,'native_sha256':None,'native_binding_required_at_execution':True,
        'whole_file_inverse_exact':True,'edits':edits,'additive_sha256':SHA(additive),
        'all_original_84Q_fields_checked':True,'old_dtype_domains_preserved':True,
        'three_dtype_membership_domains_explicitly_extended':[4],
        'width_table_explicitly_extended':{'4':8},
        'old_scalar3_predicates_unchanged':True,
        'original_ordinary_full_owner_error_rollback_unchanged':True,
        'full_transition_recomputed':False,'native_executed':False,'Torch_executed':False}
    (HERE/'candidate/owner-derivation.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':main()
