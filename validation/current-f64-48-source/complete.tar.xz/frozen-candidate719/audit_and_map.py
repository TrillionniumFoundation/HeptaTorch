#!/usr/bin/env python3
"""Inspect pinned source and recorded evidence; never execute native or Torch."""
from pathlib import Path
import ast
import collections
import hashlib
import json
import re

ROOT = Path('/workspace/scratch/fd98c6279214/HeptaTorch')
HERE = Path(__file__).resolve().parent
SHA = lambda b: hashlib.sha256(b).hexdigest()
FN = re.compile(rb'^fn (\w+)\([^\n]*\n.*?^end\n', re.M | re.S)


def main():
    candidate = HERE / 'candidate'
    pins = {}

    def read(relative, expected=None):
        path = ROOT / relative
        raw = path.read_bytes()
        actual = SHA(raw)
        assert expected is None or expected == actual, relative
        pins[relative] = {'sha256': actual, 'bytes': len(raw)}
        return raw

    initial = json.loads(read('validation/hosted-native-f64-initial-failure.json',
        'c0c9fbf13d763ab6cf3145451530695c05c3f29ab653c2b5fdf9cfcfa430727a'))
    later = json.loads(read('validation/hosted-native-f64.json',
        'ffcb6b7f0ee213cef32259d3a46153a1ec2212ada9d43d4ec69c331c1f0a13c4'))
    read('tests/f64_oracle.py',
         'bb639f7ef669d34787986ed62e870cc61071adcba1ae4e44e325673e2f75bb03')
    read('tools/dtype-f64/profile.json',
         '8865de92df8a2e6f55ef1b3d7a28d56e05dd228b21a1c53b3f485151f4027dd3')
    original = {x['reference']: x for x in initial['reports']}
    cp, pt = original['cpython'], original['pytorch']
    assert cp['cases'] == pt['cases'] == 55
    assert cp['failed_cases'] == 0 and pt['failed_cases'] == 4
    assert cp['status'] == 'PASS' and pt['status'] == 'FAIL'
    assert [x['case'] for x in cp['rows']] == [x['case'] for x in pt['rows']]
    assert len(pt['rows']) == len({x['case'] for x in pt['rows']}) == 55
    assert sum(x.get('non_nan_attempted', 0) - x.get('exact_non_nan', 0)
               for x in pt['rows']) == 4008
    qualification = later['independent_rne_reference_accuracy_report']
    assert qualification['status'] == 'PARTIAL'
    assert qualification['qualification_status'] == 'PASS'
    assert qualification['original_strict_failed_cases'] == 4
    assert qualification['sqrt_bitwise_mismatch_count'] == 4008
    assert not qualification['strict_pytorch_bitwise_gate_closed']
    assert not qualification['full_dtype_gate_closed']

    rows = []
    for index, (a, b) in enumerate(zip(cp['rows'], pt['rows'])):
        mode = b.get('mode')
        category = ('standalone_packet_refusal' if mode is None else
                    'sqrt_not_exposed' if mode == 4 else
                    'numerical_tensor_candidate_scope')
        mapped = (None if mode is None or mode == 4 else
                  {'opcode': 2, 'binary_operation': mode + 1,
                   'source_dtype': 4, 'target_dtype': 4} if mode < 4 else
                  {'opcode': 108, 'copy': True, 'memory_format': 0,
                   'source_dtype': 0 if mode == 5 else 4,
                   'target_dtype': 4 if mode == 5 else 0})
        rows.append({
            'original_index': index, 'case': b['case'], 'mode': mode,
            'original_input_values': b.get('input_values'),
            'original_cpython_status': a['status'],
            'original_pytorch_status': b['status'],
            'original_pytorch_non_nan_mismatches':
                b.get('non_nan_attempted', 0) - b.get('exact_non_nan', 0),
            'original_request_sha256': b['request_sha256'],
            'original_response_sha256': b['response_sha256'],
            'original_reference_packed_sha256': b.get('reference_packed_sha256'),
            'category': category, 'proposed_tensor_operation': mapped,
            'new_tensor_test_status': 'NOT_RUN',
            'original_result_transferred_to_new_image': False,
        })
    counts = dict(collections.Counter(x['category'] for x in rows))
    assert counts == {'numerical_tensor_candidate_scope': 33,
                      'sqrt_not_exposed': 6, 'standalone_packet_refusal': 16}
    mapping = {
        'schema': 'heptatorch.public-f64-original55-source-mapping.v1',
        'status': 'SOURCE_AND_RECORDED_EVIDENCE_REVIEW_ONLY',
        'original_denominator': 55, 'category_counts': counts,
        'original_strict_pytorch_status': 'FAIL',
        'original_strict_pytorch_failed_groups': 4,
        'original_strict_pytorch_non_nan_mismatches': 4008,
        'source_and_evidence_inputs': dict(pins), 'rows': rows,
        'comparator_contract': {
            'non_nan': 'exact bits including signed zero and infinity',
            'nan': 'NaN classification plus quiet bit; original payload/sign not claimed',
            'original_tolerance_changed': False,
        },
        'standalone_refusal_abi': {
            'header': 'u32 operation,u32 count', 'maximum_count': 60000,
            'success': 'eight zero bytes followed by one u64 per result',
            'refusal': 'one u64 status, 1 malformed or 2 invalid widen input',
            'tensor_frame_equivalence_claimed': False,
        },
        'requires_fresh_tensor_reference_and_native_comparison': True,
        'native_executed': False, 'torch_executed': False,
    }

    def functions(raw):
        pairs = [(m[1].decode(), m[0]) for m in FN.finditer(raw)]
        assert len(pairs) == len(dict(pairs))
        return dict(pairs)

    base_raw = read('tools/current_runtime/source/runtime.hepta',
                   '82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313')
    base = functions(base_raw)
    fresh_raw = (candidate / 'runtime.hepta').read_bytes()
    fresh = functions(fresh_raw)
    transition = json.loads((candidate / 'transition.json').read_bytes())
    assert SHA(fresh_raw) == transition['source_sha256']
    assert set(fresh) - set(base) == set(transition['added'])
    assert {k for k in base if fresh[k] != base[k]} == set(transition['changed'])
    inverse = fresh_raw
    for name, record in transition['added'].items():
        assert SHA(fresh[name]) == record['sha256']
        assert (candidate / 'added' / (name + '.hepta')).read_bytes() == fresh[name]
        inverse = inverse.replace(fresh[name], b'', 1)
    for name, record in transition['changed'].items():
        assert SHA(base[name]) == record['before_sha256']
        assert SHA(fresh[name]) == record['after_sha256']
        assert (candidate / 'before' / (name + '.hepta')).read_bytes() == base[name]
        assert (candidate / 'after' / (name + '.hepta')).read_bytes() == fresh[name]
        inverse = inverse.replace(fresh[name], base[name], 1)
    assert inverse == base_raw

    owner_raw = (candidate / 'owner_f64.py').read_bytes()
    owner_proof = json.loads((candidate / 'owner-derivation.json').read_bytes())
    assert SHA(owner_raw) == owner_proof['candidate_owner_sha256']
    boundary = owner_raw.index(b'\n\n# BEGIN EXPLICIT PUBLIC F64 OBSERVATION')
    owner_inverse = owner_raw[:boundary]
    assert SHA(owner_raw[boundary:]) == owner_proof['additive_sha256']
    for before, after, count in reversed(owner_proof['edits']):
        assert owner_inverse.count(after.encode()) == count
        owner_inverse = owner_inverse.replace(after.encode(), before.encode())
    assert owner_inverse == (candidate / 'frozen-owner-integral.py').read_bytes()
    assert SHA(owner_inverse) == 'c39600e7c37dea390f88cf9e74d86dfa924301456e0f32e127d82c98ad6778b0'
    ast.parse(owner_raw)

    rng_raw = read('tools/current_runtime/source/units/rng03.hepta')
    rng = functions(rng_raw)
    dtype_rows = []
    group_counts = {'f16': 16, 'bf16': 22, 'float8-e5m2': 16,
                    'float8-e4m3fn': 16, 'float8-e4m3fnuz': 16}
    for kind, groups in group_counts.items():
        path, = (ROOT / 'tools' / ('dtype-' + kind)).glob('*.hepta')
        raw = read(str(path.relative_to(ROOT)))
        bodies = functions(raw)
        report = 'validation/hosted-native-' + kind + '.json'
        read(report)
        dtype_rows.append({
            'type': kind, 'original_group_denominator': groups,
            'source': str(path.relative_to(ROOT)), 'source_sha256': SHA(raw),
            'recorded_evidence': report,
            'numeric_bodies': {k: {'sha256': SHA(v),
                                  'identical_existing_rng_body': rng.get(k) == v}
                               for k, v in bodies.items()
                               if k.startswith(('round_', 'widen_'))},
            'storage_width': 2 if kind in ('f16', 'bf16') else 1,
            'current_701_public_dtype_code': None,
            'new_public_dtype_code_assigned_here': None,
            'source_component_qualification_is_tensor_qualification': False,
        })
    audit = {
        'schema': 'heptatorch.public-f64-source-independent-custody.v1',
        'status': 'SOURCE_CHECKED_NOT_COMPILED_NOT_RUN',
        'baseline_sha256': SHA(base_raw), 'source_sha256': SHA(fresh_raw),
        'functions': len(fresh), 'unchanged_original_functions': len(base)-len(transition['changed']),
        'modified_original_functions': len(transition['changed']),
        'added_functions': len(transition['added']),
        'whole_source_inverse_exact': True,
        'owner_sha256': SHA(owner_raw), 'whole_owner_file_inverse_exact': True,
        'original_owner_sha256': SHA(owner_inverse),
        'owner_scope': 'single-command frames with actual public T handles; dtype4 creation, binary and cast',
        'owner_qualification_limitations': [
            'No actual image is bound; native build required before observer execution.',
            'Owner checks noAD, real T/S/V and all original84Q fields; it does not compute numeric expected values.',
            'Source descriptor equality does not replace complete Storage/RNG5056/raw frame comparisons.',
            'Do not pass synthetic frame-local FE handles as if they were already resolved public T handles.',
            'This observer retains old Integral115 predicates and is not the current Bool/F32 sum observer.',
            'General private allocation transition ledger is not recomputed.',
        ],
        'original55_mapping_sha256': SHA((json.dumps(mapping, indent=2, sort_keys=True)+'\n').encode()),
        'other_dtype_components': dtype_rows, 'source_and_evidence_inputs': pins,
        'native_executable_sha256': None,
        'compiler_executed': False, 'native_executed': False, 'torch_executed': False,
    }
    (HERE / 'original55-mapping.json').write_text(json.dumps(mapping, indent=2, sort_keys=True)+'\n')
    (HERE / 'dtype-source-audit.json').write_text(json.dumps(audit, indent=2, sort_keys=True)+'\n')
    print(json.dumps({'status': audit['status'], 'functions': len(fresh),
                      'mapping': counts, 'source_sha256': SHA(fresh_raw),
                      'owner_sha256': SHA(owner_raw),
                      'original55_mapping_sha256': audit['original55_mapping_sha256'],
                      'audit_sha256': SHA((HERE/'dtype-source-audit.json').read_bytes())}, indent=2))


if __name__ == '__main__':
    main()
