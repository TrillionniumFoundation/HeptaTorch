# Ordinary F64 Tensor source candidate

This directory is a source-only candidate derived from the current 701-function
Tensor runtime. No compiler, linker, HIA image or Torch reference was executed
for this candidate. The repository and every existing qualification report are
unchanged. A successful text/SSA/partition check is not native qualification.

## Exact source identities

| Item | SHA-256 |
|---|---|
| Original 701-function runtime | `82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313` |
| Candidate 719-function runtime | `e2eedf870e306572672817cfc98bcf49d9aeacc0657c04dbaf50e5e6f5ceb66d` |
| Original standalone F64 source | `44a6ff00413829d3cf8f7fbd91fb96a6baf090c3c754882d4361f49ed85a2e56` |
| Original complete owner observer | `c39600e7c37dea390f88cf9e74d86dfa924301456e0f32e127d82c98ad6778b0` |
| Candidate complete owner observer | `db8dfd3ce4c845049a521a2612be4b53c295248daa748c31da3b2ccdd22dfc61` |
| Original 55-group mapping | `79cbe8921e57eb32a2da20588a7e7a13acbcef05de31319dc4b66add0bab942a` |
| Independent source/evidence audit | `82bb4e376a483dc0f67a40b74b6716ca8e82ada0a2a96d9a49fb02e450177744` |

`candidate/transition.json` records all 15 changed original functions and 18 new
functions. Their complete old and new text is retained in `before/`, `after/`
and `added/`. Removing the new bodies and restoring the 15 original bodies
recovers the entire original source byte for byte. The other 686 original
functions are unchanged.

The descriptor remains 672 bytes and its dtype field remains at byte 576. The
candidate does not modify owners, RNG support, `step`, frame layout, memory
ownership ABI, the compiler or linker. Pure partition planning produces 14
modules, as before. The separate Generator candidate must be composed and
qualified explicitly if it is selected; this source does not contain that
integration or borrow its results.

## Public dtype and operation scope

Ordinary F64 uses **public dtype 4**. Private dtype 3 remains the existing
wrapped binary64 scalar: rank zero, one element, eight-byte Storage, disabled
autograd role and its original restricted entry points. Public factories still
reject code 3. No other new public dtype code is assigned.

| Operation | Concrete entry and implementation | Candidate boundary |
|---|---|---|
| Explicit F64 construction | command 97, `typed_from_wire`, width-aware existing `typed_descriptor` | dtype 4; rank 0–4, including empty shapes; requires-grad rejected |
| Raw value observation | command 98 and existing `typed_read`/`tget` | eight little-endian bytes per logical value; no conversion through F32 |
| Dtype and shape observation | commands 96 and 13 | actual dtype, shape, strides and storage metadata |
| Raw element mutation | command 12, `tset` | all 64 bits retained; existing bounds and Version path |
| Raw fill | command 100, `typed_fill` | all 64 bits retained; original mutation and Version guards |
| Add/subtract/multiply/divide | command 2, operation 1/2/3/4, `f64_binary` | both operands dtype 4; actual broadcast shape, width-aware strides, fresh Storage and Version; no AD |
| F32 to F64 | commands 108/109, `f64_cast_admit`, `f64_copy_tensor` | each source value passes through the unchanged `widen32` body; F32 source requires-grad rejected |
| F64 to F32 | same commands | each source value passes through the unchanged `narrow64` body; no AD |
| F64 to F64 | same commands | actual raw bits; command 108 may alias only on its existing same-dtype/no-copy path |

The numeric bodies `pack64`, `add64`, `sub64`, `multiply_high`, `mul64`, `div64`,
`widen32` and `narrow64` are byte-identical to the old standalone source.
`getr`, `shrjam` and `packf` already match exactly. The standalone raw `putw`
is **not** imported: the Tensor runtime has its own address translation and
the new kernels use existing `typed_store` on actual Tensor addresses.

`f64_copy_tensor` retains the existing preserve-format/contiguous allocation
algorithm, including `dist_dense_layout` for preserve format. An F32 source may
therefore be strided or overlapping; the result is separately allocated and
dense with the original converter's layout policy. Binary operations similarly
use the existing width-aware `integer_pointwise_layout`, followed by logical
index reads and actual result-address writes. These paths still require a fresh
Torch comparison of output bits **and strides**; source reuse alone is not that
comparison.

This candidate does not expose F64 sqrt, sum, general views, permutations,
reshape operations, saved tensors, mixed dtype promotion or autograd.
Unsupported F64 paths are refused rather than entering old F32 arithmetic.
Existing public Bool/I64/F32 paths route to their original bodies. In particular,
the old scalar dtype-3 guards are retained before the new dtype-4 checks.

## Guard and transaction changes

The 15 original modifications are limited to these sites:

- `dtype_width`, `typed_from_wire`, `scalar_previous_dtype_audit` and
  `dtype_audit` add the exact dtype-4 domain, width and no-AD invariants.
- `tset` and `typed_fill` permit full-width F64 values without removing their
  original bounds, no-grad or Version checks.
- `binary` and `to_copy_tensor` dispatch to new explicit F64 helpers; exact
  renamed original bodies remain the fallback for previous types.
- `sd_previous_to_command` permits target 4 only on commands 108/109. Factory
  110 and the original private-scalar guards remain restricted.
- `to_command` refuses a live F64 source on other shape/sum/AD paths.
- `command_argument` permits a F64 Tensor on the selected low-operation
  binary, raw-set and metadata arguments; other low-operation Tensor uses
  remain refused.
- `typed_command` refuses F64 on commands 99/101/102; raw fill 100 remains
  admitted. `rng_strided_view`, `save_public` and `data_alias` explicitly
  exclude new F64 views and saved roles.

Ordinary malformed-frame validation, state trial allocation, error rollback,
publication and cleanup are inherited. There is no new host-side allocator or
fabricated allocation/epoch result. That does not prove new runtime rollback:
the eventual reader must retain and compare complete owner bytes, mappings,
input Storage and the 5,056 RNG-state bytes around actual allocation failures.

## Full owner reader

`candidate/owner_f64.py` retains the complete c396 observer. Its inverse is
checked in `owner-derivation.json` and independently by `audit_and_map.py`.
Three dtype-membership predicates (node, Weak and Hold) explicitly add 4, and
the width table adds eight bytes. All previous dtype domains and all 84-word
field checks remain. The observer explicitly reports that its dtype predicate
domain was extended; it does not claim every old predicate is byte-identical.

The additive layer checks F64 no-AD/no-Saved/no-ViewInfo roles and fresh real
Tensor, Storage and Version identities for construction, arithmetic and copy.
New results must have Version zero; source descriptors must retain all 84 words.
The original complete owner rollback predicate still runs on errors.

This is a reader for single-command frames containing actual public Tensor
handles. Frame-local FE aliases must first be resolved by a future runner; they
must not be passed to the observer as already published handles. It is not a
replacement for the established Bool/F32 sum observer: the frozen Integral115
predicates are intentionally still present. It does not calculate numerical
expected values or recompute a general private-allocation transition ledger.
An actual source/image binding is mandatory before it can decode a snapshot;
no native image exists for this candidate yet.

## Original 55 groups and retained failures

`original55-mapping.json` retains every original group in order, both recorded
reference statuses, raw request/response hashes and the mapping category.
The full denominator remains **55**:

| Original groups | Count | Relation to this candidate |
|---|---:|---|
| Add, subtract, multiply and divide corpora | 20 | Numeric bodies reused; candidate Tensor comparisons still NOT_RUN |
| Widen corpora | 3 | F32→F64 candidate comparisons still NOT_RUN |
| Narrow corpora | 4 | F64→F32 candidate comparisons still NOT_RUN |
| Empty non-sqrt operations | 6 | Tensor empty-result comparisons still NOT_RUN |
| Sqrt corpora and empty sqrt | 6 | Original source/evidence retained; no F64 Tensor sqrt entry added |
| Standalone malformed-packet refusals | 16 | Original standalone protocol retained; cannot be counted as Tensor-frame tests |

The original strict Torch result remains **FAIL in four sqrt groups, with
4,008 non-NaN bit mismatches**. The later independent-RNE report is `PARTIAL`
with a separately named component qualification; its strict Torch bitwise gate
and full dtype gate remain false. Those reports and expectations are untouched.
Excluding sqrt from this small integration does not repair or hide that gate.

The original comparator requires exact non-NaN bits, including signed zero
and infinities. For NaNs it requires NaN classification and the quiet bit;
it does not claim exact NaN payload or sign parity. A future Tensor comparison
must state this same boundary instead of silently adding or weakening it.

The 16 standalone refusals consist of eight truncated header lengths, unknown
and maximum operation, count over the 60,000 limit and maximum count, missing
binary operand, trailing bytes, high input bits for widen and a late invalid
widen word. Their ABI is a u32 operation/count header, not a Tensor frame.
They cannot establish the new Tensor admission and owner-rollback rules.

## Required next real checks

The source is ready for independent review and a separately authorized cold
build, not for publication as qualified. The narrow runtime gate needs:

1. All 33 mapped numeric/empty corpora on actual Tensor commands, preserving
   input words and exact existing comparison semantics with fresh fixed Torch
   output. Include the original signed zeros, subnormals, infinities, signaling
   and quiet NaNs, rounding midpoints, exponent boundaries and random inputs.
2. Tensor-specific rank-zero, empty, four-axis, broadcast, singleton and
   preserve-format layouts, including transposed and overlapping F32 inputs
   before cast. Verify logical raw values, shape, strides, dtype and complete
   Storage extent. Test same-dtype alias versus explicit copy separately.
3. Raw-set/fill high-bit preservation and Version increments; repeated drop,
   handle-generation and same-slot reuse; source Tensor/Storage/RNG unchanged
   on nonmutating success paths.
4. Real refusals for public dtype 3/unknown types, requires-grad construction,
   F32 requiring-grad cast to F64, mixed F64/F32/Bool/I64 binary operands in both
   orders, Bool/I64↔F64 casts, unsupported operations, invalid flags/axes/shape
   and truncated or trailing frames. Preserve full owner bytes on each error.
5. Real allocation failures at descriptor, Storage and publication stages,
   followed by successful execution of the identical command after restoring
   resources. Require complete raw transport, exit/EOF and no mapping leaks.
6. Existing current-runtime suites and all private-scalar32 comparisons on the
   new image. No result from source 823 or a standalone dtype image transfers.

## Other existing dtype components

`dtype-source-audit.json` pins every source, numeric body and recorded evidence
file below. All currently lack an ordinary Tensor dtype in the 701 core.

| Component | Original denominator | Reusable code and integration work |
|---|---:|---|
| F16 | 16 | `round_f16` already equals the RNG module's private body; import its existing export only after an explicit support transition. Add exact `widen_f16`, a public dtype, two-byte Storage and strict conversion/operation guards. |
| BF16 | 22 | `round_bf16` likewise already matches the private RNG body. Widen is the original 16-bit left shift. Public dtype and two-byte owner/Storage admission remain missing. |
| Float8 E5M2 | 16 | Exact `round_float8_e5m2` and `widen_float8_e5m2` bodies exist; add a separate public dtype and one-byte conversion paths. |
| Float8 E4M3FN | 16 | Distinct round/widen bodies and frozen-reference behavior; do not infer semantics from E5M2 or another Torch version. |
| Float8 E4M3FNUZ | 16 | Distinct round/widen bodies; its unsigned-zero/NaN behavior requires its own unchanged reference corpus. |

No new dtype codes, arithmetic promotion, AD support or Tensor qualification are
claimed for these components. Their original standalone denominators and first
failure records must remain independently visible during any later integration.
