#!/usr/bin/env python3
"""Pure text/SSA/call checks; this file cannot invoke native processes."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/fd98c6279214/HeptaTorch')
FUNCTION = re.compile(rb'^fn (\w+)\(([^\n]*)\) -> \(([^)]*)\) effects\([^\n]*\) entry\((\w+)\)\n.*?^end\n', re.M|re.S)
PARAM = re.compile(r'([A-Za-z_][A-Za-z_0-9]*):([A-Za-z0-9_]+)')
INSTRUCTION = re.compile(r'  ([A-Za-z_][A-Za-z_0-9]*):([a-z0-9]+) = ([A-Za-z0-9_.]+)\(([^)]*)\)(?: (\{.*\}))?$')
TARGET = re.compile(r'(\w+)\(([^)]*)\)')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def params(text):
    found = PARAM.findall(text)
    assert ','.join(v+':'+t for v,t in found)==text
    return found


def main():
    root = HERE/'candidate'
    transition = json.loads((root/'transition.json').read_bytes())
    raw = (root/'runtime.hepta').read_bytes()
    base = (root/'baseline-runtime.hepta').read_bytes()
    assert sha(raw)==transition['source_sha256']
    assert sha(base)==transition['baseline_sha256']
    bodies={m[1].decode():m[0] for m in FUNCTION.finditer(raw)}
    support = (ROOT/'tools/current_runtime/source/units/rng03.hepta').read_bytes()
    defs={**bodies, **{m[1].decode():m[0] for m in FUNCTION.finditer(support)}}
    signatures={}
    for name,body in defs.items():
        m=FUNCTION.fullmatch(body);assert m,name
        signatures[name]=([t for v,t in params(m[2].decode())],m[3].decode())
    selected = sorted(set(transition['changed'])|set(transition['added']))
    checked_blocks=checked_instructions=0
    for name in selected:
        body=bodies[name].decode(); lines=body.splitlines()
        h=FUNCTION.fullmatch(bodies[name]); header_params=params(h[2].decode())
        entry=h[4].decode(); blocks={}; instructions={}; current=None; all_names=set()
        for line in lines[1:]:
            if line=='end':break
            if line.startswith('block '):
                m=re.fullmatch(r'block (\w+)\(([^)]*)\)',line);assert m,(name,line)
                current=m[1];assert current not in blocks,name
                blocks[current]=params(m[2]);instructions[current]=[]
                for v,t in blocks[current]:assert v not in all_names,(name,v);all_names.add(v)
            else:instructions[current].append(line)
        assert blocks[entry]==header_params,(name,entry)
        graph={n:[] for n in blocks}
        for block,rows in instructions.items():
            scope=dict(blocks[block]);closed=False
            for line in rows:
                assert not closed,(name,block,line)
                m=INSTRUCTION.fullmatch(line)
                if m:
                    v,typ,op,argtext,attrtext=m.groups()
                    assert v not in all_names,(name,v);all_names.add(v)
                    args=[] if not argtext else argtext.split(',')
                    assert all(a in scope for a in args),(name,block,line,args,scope)
                    ts=[scope[a] for a in args]; attrs={} if attrtext is None else json.loads(attrtext)
                    if op=='call':
                        assert attrs['function'] in signatures,(name,line)
                        expected,returned=signatures[attrs['function']]
                        assert (ts,typ)==(expected,returned),(name,line,ts,typ,expected,returned)
                    elif op=='const':assert not args and typ in ['u64','u32','usize','i64','bool']
                    elif op.startswith('compare.'):
                        assert len(ts)==2 and ts[0]==ts[1] and typ=='bool',(name,line,ts)
                    elif op in ['bool.or','bool.and']:assert ts==['bool','bool'] and typ=='bool'
                    elif op=='select':assert ts==['bool',typ,typ]
                    elif op.startswith(('int.add.','int.sub.','int.mul.','int.div.','int.rem.')):
                        assert len(ts)==2 and ts==[typ,typ]
                    elif op.startswith(('bit.','int.shl.','int.shr.')):
                        assert len(ts)==2 and ts[0]==typ
                    elif op=='int.cast':assert len(ts)==1
                    elif op=='buffer.len':assert len(ts)==1 and ts[0] in ['readbuf','mutbuf','buffer'] and typ=='usize'
                    elif op in ['buffer.load','buffer.store']:
                        pass # unchanged original body, compiler admission remains required
                    else:
                        assert op in ['memory.load','memory.store','bit.not','bool.not'],(name,line)
                    scope[v]=typ;checked_instructions+=1
                    continue
                if line.startswith('  ret('):
                    x=line.removeprefix('  ret(').removesuffix(')')
                    assert scope.get(x)==signatures[name][1],(name,line)
                elif line.startswith('  jump ') or line.startswith('  branch '):
                    command=line.strip()
                    if command.startswith('branch '):
                        _,condition,tails=command.split(' ',2)
                        assert scope.get(condition)=='bool',(name,line)
                    else:tails=command.removeprefix('jump ')
                    targets=TARGET.findall(tails)
                    assert len(targets)==(2 if command.startswith('branch ') else 1),(name,line)
                    assert ' '.join(f'{a}({b})' for a,b in targets)==tails,(name,line)
                    for target,argtext in targets:
                        assert target in blocks,(name,line)
                        args=[] if not argtext else argtext.split(',')
                        assert [scope.get(a) for a in args]==[t for _,t in blocks[target]],(name,line,target,args)
                        graph[block].append(target)
                else:raise AssertionError((name,block,line))
                closed=True
            assert closed,(name,block)
        reachable=set();stack=[entry]
        while stack:
            b=stack.pop()
            if b not in reachable:reachable.add(b);stack.extend(graph[b])
        assert reachable==set(blocks),(name,sorted(set(blocks)-reachable))
        checked_blocks+=len(blocks)

    restore=raw
    for name in reversed(list(transition['added'])):
        # Each added definition is independently pinned; order is immaterial.
        b=(root/'added'/f'{name}.hepta').read_bytes()
        assert sha(b)==transition['added'][name]['sha256'] and restore.count(b)==1
        restore=restore.replace(b,b'',1)
    for name in transition['changed']:
        a=(root/'after'/f'{name}.hepta').read_bytes()
        b=(root/'before'/f'{name}.hepta').read_bytes()
        assert sha(a)==transition['changed'][name]['after_sha256']
        assert sha(b)==transition['changed'][name]['before_sha256']
        assert restore.count(a)==1;restore=restore.replace(a,b,1)
    assert restore==base
    # Repository parser and partition planner operate on source bytes only.
    p=ROOT/'tools/current_runtime/partition.py'
    spec=importlib.util.spec_from_file_location('f64_source_partition_only',p)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    owner=(ROOT/'tools/current_runtime/source/units/owners.hepta').read_bytes()
    units=module.partition(raw,support,owner,'f64_candidate')
    parsed=module.build.parse_source(raw)
    assert parsed['functions']==719
    sizes=[]
    for name,unit in units:
        u=module.build.parse_source(unit,unit=True)
        assert u['functions']<=256 and u['blocks']<=4096 and u['instructions']<=16384
        sizes.append({k:u[k] for k in ['functions','blocks','instructions']}|{'name':name,'sha256':sha(unit)})
    report={'schema':'heptatorch.public-f64-pure-source-check.v1',
        'status':'SOURCE_STRUCTURALLY_CHECKED_NOT_COMPILED_NOT_RUN',
        'source_sha256':sha(raw),'baseline_sha256':sha(base),
        'full_source_inverse':True,'selected_functions_type_and_local_SSA_checked':len(selected),
        'selected_blocks':checked_blocks,'selected_instructions':checked_instructions,
        'source_functions':parsed['functions'],'source_blocks':parsed['blocks'],
        'source_instructions':parsed['instructions'],'planned_units':len(units),'units':sizes,
        'native_compiler_executed':False,'native_linker_executed':False,
        'HIA_executed':False,'Torch_executed':False,
        'private3_original_factory_and_rank0_contract_retained':True,
        'semantic_qualification': 'NOT_RUN',
        'compiler_qualification': 'NOT_RUN',
        'inputs':{str(p):sha(p.read_bytes()),str(p.with_name('build.py')):sha(p.with_name('build.py').read_bytes())}}
    dest=HERE/'source-check.json';dest.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
