# Current736 F64 48, explicit factory-status adaptation

The entry is current48.py. It exposes current_reader() for pure admission and
later independent evidence readback. It delegates the complete original48
numerical/resource runner without changing any numeric loop or comparison.

The original719 controls.py remains frozen. controls736.py is its complete
copy with one reversible expression change: the old16-byte public factory
packets for dtype5/6 expect cause100; all other85 refusal expectations remain
unchanged. Half elements now occupy2 bytes and shape[2] requires4 payload bytes,
so these original16-byte packets are malformed. They remain rejected.

Both old expected7 failures were observed on the admitted current736 image
before this source was prepared. The untouched48 run retains FAIL at dtype5
after2 entry refusals; a separate focused child retains FAIL at dtype6 with
the original setup, reject function, Driver.check and expected7 unchanged.
Neither historical failure report is modified or relabelled as PASS.

bridge.py, derived719_run.py, owner736.py, the complete736-to719 source inverse
and all98 original frozen source files are ordinary byte-identical copies of
the identity-only package. current48.py binds and rederives the two-status
controls before the original main imports them. All original Reference
globals remain719. The original strict55 FAIL and project HOLD remain.

This package is source-only until independently reviewed and actually run.
No current48 corrected runtime PASS is supplied by this manifest. No Torch,
native image or compiler is executed during this source freeze.
