"""Derive only the two malformed Half factory status expectations for736.

The original16-byte factory packets now reach the unchanged length check with
two-byte Half elements. Their cause100 rejects malformed payload size. This
does not turn unsupported operations into successful Torch compatibility.
"""
import ast
import hashlib
from pathlib import Path


HERE = Path(__file__).resolve().parent
ORIGINAL_CONTROLS = 'a0a03c98983e6ae6ca17d5fa96f0a696ecfcb940263b325135a5a71c0ce3d638'
OLD = "               driver.n.factory_packet(dtype, [2], struct.pack('<2Q', 1, 2)), 7)"
NEW = "               driver.n.factory_packet(dtype, [2], struct.pack('<2Q', 1, 2)), 100 if dtype in (5, 6) else 7)"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def definition(raw, name):
    lines = raw.decode().splitlines(keepends=True)
    found = [node for node in ast.parse(raw).body if isinstance(node, ast.FunctionDef) and node.name == name]
    require(len(found) == 1, 'unique complete original function: ' + name)
    node = found[0]
    return ''.join(lines[node.lineno - 1:node.end_lineno]).encode()


def derive(bind):
    before = bind(HERE / 'frozen719/controls.py', ORIGINAL_CONTROLS)
    require(before.count(OLD.encode()) == 1, 'one exact original factory refusal expression')
    after = before.replace(OLD.encode(), NEW.encode(), 1)
    require(after.count(NEW.encode()) == 1 and after.replace(NEW.encode(), OLD.encode(), 1) == before,
            'complete original controls.py byte inverse')
    old_tree, new_tree = ast.parse(before), ast.parse(after)
    old_entry = next(node for node in old_tree.body if isinstance(node, ast.FunctionDef) and node.name == 'entry_controls')
    new_entry = next(node for node in new_tree.body if isinstance(node, ast.FunctionDef) and node.name == 'entry_controls')
    old_loop = next(node for node in old_entry.body if isinstance(node, ast.For)
                    and isinstance(node.target, ast.Name) and node.target.id == 'dtype')
    new_loop = next(node for node in new_entry.body if isinstance(node, ast.For)
                    and isinstance(node.target, ast.Name) and node.target.id == 'dtype')
    old_call, new_call = old_loop.body[0].value, new_loop.body[0].value
    require(isinstance(old_call, ast.Call) and isinstance(new_call, ast.Call)
            and old_call.func.id == new_call.func.id == 'reject'
            and len(old_call.args) == len(new_call.args) == 4,
            'the original reject call is the only adapted expression')
    require(ast.dump(old_call.args[-1]) == ast.dump(ast.parse('7', mode='eval').body)
            and ast.dump(new_call.args[-1]) == ast.dump(ast.parse('100 if dtype in (5, 6) else 7', mode='eval').body),
            'only dtype5/6 malformed factory statuses may change')
    new_call.args[-1] = old_call.args[-1]
    require(ast.dump(new_tree) == ast.dump(old_tree), 'complete original AST after inverse of one status expression')
    unchanged = {}
    for name in ('reject', 'resources', 'allocation_control'):
        body = definition(before, name)
        require(body == definition(after, name), 'entire original function unchanged: ' + name)
        unchanged[name] = dict(bytes=len(body), sha256=sha(body))
    proof = dict(schema='heptatorch.current736.f64-48.two-factory-statuses.v1',
        before_bytes=len(before), before_sha256=sha(before),
        after_bytes=len(after), after_sha256=sha(after),
        edits=[dict(before=OLD, after=NEW, occurrences=1)],
        whole_file_inverse_exact=True, whole_AST_inverse_exact=True,
        expected_status_changes=[dict(label='public-factory-dtype-' + str(dtype), dtype=dtype,
            original_expected_status=7, current_expected_status=100,
            shape=[2], raw_payload_bytes=16, current_element_bytes=2,
            required_payload_bytes=4, cause='malformed factory payload extent') for dtype in (5, 6)],
        original_factory_packets_and_labels_unchanged=True,
        original87_refusals_retained=True, other85_expected_statuses_unchanged=True,
        full_original_reject_owner_rollback_and_allocation_functions=unchanged,
        original_Control_source_file_modified=False, native_executed=False,
        Torch_executed=False, compiler_executed=False,
        any_successful_Torch_compatibility_claim_added=False)
    return after, proof
