#!/usr/bin/env python3
"""Observe ten fixed CPU Torch cat recipes; never infer a wire capacity contract."""
import argparse
import gc
import hashlib
import json
from pathlib import Path
import runpy
import struct
import sys
import traceback
import warnings

SUPPORT_SHA = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK_SHA = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
PYTHON_SHA = 'e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f'
FIXTURE_PINS = {
    'cat-saved-list-arena-boundary.input.hex': '1290502a522f2be052d488e4c77cbc5886c1fdb680da677d8367be72803c8474',
    'cat-saved-list-arena-boundary.output.hex': '306be2d490d850c0bc9c959c65240a331438a51f0b7a932833bb1885b45600c7',
    'cat-saved-list-arena-overflow.input.hex': '484b0c3c517e6a99f669d92302278bef6c02d2299b4c18639c816521dd2f4621',
    'cat-saved-list-arena-overflow.output.hex': '74319a54ecc7d77e9170925d1f3961d017ec940656d42886d7b16c3c7653630a',
}
CASES = (
    dict(name='repeat62207-rank1empty-dim999-emptyseed-backward', shapes=[[0]],
         runs=[[0, 62207]], dim=999, backward=True, fixture='cat-saved-list-arena-boundary'),
    dict(name='two-rank1empty-dim999', shapes=[[0], [0]], runs=[[0, 1], [1, 1]], dim=999, backward=True),
    dict(name='repeat62208-rank1empty-dim999-forward-only', shapes=[[0]],
         runs=[[0, 62208]], dim=999, backward=False, fixture='cat-saved-list-arena-overflow'),
    dict(name='two-rank1empty-dim0', shapes=[[0], [0]], runs=[[0, 1], [1, 1]], dim=0, backward=True),
    dict(name='two-rank2empty-axis1-extent0', shapes=[[2, 0], [2, 0]], runs=[[0, 1], [1, 1]], dim=1, backward=True),
    dict(name='two-rank2empty-axis0-nonzero-extent', shapes=[[2, 0], [2, 0]], runs=[[0, 1], [1, 1]], dim=0, backward=True),
    dict(name='rank1empty-rank2empty-axis1', shapes=[[0], [2, 0]], runs=[[0, 1], [1, 1]], dim=1, backward=True),
    dict(name='rank1empty-rank2empty-axis0', shapes=[[0], [2, 0]], runs=[[0, 1], [1, 1]], dim=0, backward=True),
    dict(name='rank2empty-rank1empty-axis0', shapes=[[2, 0], [0]], runs=[[0, 1], [1, 1]], dim=0, backward=True),
    dict(name='rank1empty-rank2values-axis1', shapes=[[0], [2, 1]], values={'1': [[1.0], [2.0]]},
         runs=[[0, 1], [1, 1]], dim=1, backward=True),
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--fixtures', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repository, fixtures, output = [p.resolve() for p in (args.repository, args.fixtures, args.output)]
    assert Path.cwd().resolve() == repository and not sys.flags.optimize
    assert sys.byteorder == 'little' and sys.version_info[:2] == (3, 12)
    output.mkdir(parents=True, exist_ok=False)
    paths = [Path(__file__).resolve(), Path(sys.executable).resolve(), repository / 'tests/pytorch_oracle.py',
             repository / 'compatibility/pytorch-oracle-lock.json', repository / 'compatibility/upstream-lock.json',
             repository / 'build/pytorch-install.json']
    paths += [fixtures / name for name in FIXTURE_PINS]
    originals = {str(p): p.read_bytes() for p in paths}
    identities = {p: dict(bytes=len(raw), sha256=sha(raw)) for p, raw in originals.items()}
    assert identities[str(repository / 'tests/pytorch_oracle.py')]['sha256'] == SUPPORT_SHA
    assert identities[str(repository / 'compatibility/pytorch-oracle-lock.json')]['sha256'] == LOCK_SHA
    assert identities[str(Path(sys.executable).resolve())]['sha256'] == PYTHON_SHA
    for name, pin in FIXTURE_PINS.items():
        assert identities[str(fixtures / name)]['sha256'] == pin
    report = dict(schema='heptatorch.cat-empty-reference10.v1', status='RUNNING', expected_cases=10,
                  source_sha256=identities[str(Path(__file__).resolve())]['sha256'], inputs=identities,
                  case_manifest_sha256=sha(json.dumps(CASES, sort_keys=True, separators=(',', ':')).encode()),
                  recipes=CASES, rows=[], native_executed=False, torch_executed=False,
                  original_expected_bytes_compared=False, wire_capacity_contract_inferred=False,
                  output_grad_retention_hooks_added=False, versions_recorded_without_offset=True)
    code = 0
    try:
        boundaries = {}
        for fixture, count, command_count in [('cat-saved-list-arena-boundary', 62207, 5),
                                              ('cat-saved-list-arena-overflow', 62208, 2)]:
            raw = bytes.fromhex(originals[str(fixtures / (fixture + '.input.hex'))].decode())
            assert raw[:8] == b'HTORCH01'
            commands, length, flags = struct.unpack_from('<3Q', raw, 8)
            assert commands == command_count and length == len(raw) and flags == 0
            create, cat = [struct.unpack_from('<8Q', raw, 32 + 64 * i) for i in range(2)]
            assert create[:7] == (1, 1, 1, 0, 0, 0, 0) and cat[0] == 34 and cat[1] == 999
            assert struct.unpack_from('<Q', raw, cat[2])[0] == count
            assert len(raw) == cat[2] + 8 + 8 * count
            assert all(struct.unpack_from('<Q', raw, cat[2] + 8 + 8 * i)[0] == 1 for i in range(count))
            boundaries[fixture] = dict(repeated_source_count=count, dim=cat[1], input_shape=[0], requires_grad=True)
        report['original_boundary_input_mapping'] = boundaries
        old_argv = sys.argv
        try:
            sys.argv = [str(repository / 'tests/pytorch_oracle.py'), str(output / 'NO_NATIVE_EXECUTION'),
                        str(output / 'oracle-provenance.json'), str(repository / 'compatibility/pytorch-oracle-lock.json')]
            context = runpy.run_path(str(repository / 'tests/pytorch_oracle.py'), run_name='cat_empty_reference_only')
        finally:
            sys.argv = old_argv
        torch, provenance = context['torch'], context['PROVENANCE']
        assert provenance['status'] == 'PASS' and len(provenance['checks']) == 11 and all(provenance['checks'].values())
        report.update(torch_executed=True, oracle_provenance=provenance,
                      cpu_capability=torch.backends.cpu.get_cpu_capability(), num_threads=torch.get_num_threads())
        initial_rng = bytes(torch.get_rng_state().tolist())

        def tensor_data(t):
            return dict(shape=list(t.shape), strides=list(t.stride()), storage_offset=t.storage_offset(),
                        numel=t.numel(), dtype=str(t.dtype), device=str(t.device), layout=str(t.layout),
                        element_size=t.element_size(), storage_nbytes=t.untyped_storage().nbytes(),
                        is_contiguous=t.is_contiguous(), requires_grad=t.requires_grad, is_leaf=t.is_leaf,
                        retains_grad=t.retains_grad, grad_fn=None if t.grad_fn is None else type(t.grad_fn).__name__,
                        version=t._version, logical_data_hex=bytes(t.detach().contiguous().reshape(-1).view(torch.uint8).tolist()).hex())

        def snapshot(t):
            result = tensor_data(t)
            with warnings.catch_warnings(record=True) as observed:
                warnings.simplefilter('always')
                gradient = t.grad
            result.update(grad_is_none=gradient is None,
                          gradient=None if gradient is None else tensor_data(gradient),
                          grad_read_warnings=[dict(category=x.category.__name__, message=str(x.message),
                                                   filename=x.filename, lineno=x.lineno) for x in observed])
            return result

        def raised(error):
            return dict(status='RAISED', type=type(error).__name__, message=str(error), traceback=traceback.format_exc())

        def observe_case(recipe):
            before_rng = bytes(torch.get_rng_state().tolist())
            inputs = []
            for index, shape in enumerate(recipe['shapes']):
                values = recipe.get('values', {}).get(str(index))
                if values is None:
                    assert 0 in shape
                    tensor = torch.empty(tuple(shape), dtype=torch.float32, device='cpu', requires_grad=True)
                else:
                    tensor = torch.tensor(values, dtype=torch.float32, device='cpu', requires_grad=True)
                assert list(tensor.shape) == shape and tensor.is_leaf
                inputs.append(tensor)
            indices = [index for index, count in recipe['runs'] for _ in range(count)]
            assert 1 <= len(indices) <= 62208
            arguments = [inputs[index] for index in indices]
            row = dict(name=recipe['name'], recipe=recipe, arguments=dict(
                encoding='run-length input indices', runs=recipe['runs'], count=len(arguments),
                unique_tensor_objects=len({id(t) for t in arguments}),
                aliases_match_recipe=all(t is inputs[i] for t, i in zip(arguments, indices))),
                inputs_before_forward=[snapshot(t) for t in inputs])
            result = seed = None
            try:
                result = torch.cat(arguments, dim=recipe['dim'])
            except Exception as error:
                row['forward'] = raised(error)
                row['backward'] = dict(status='NOT_RUN_FORWARD_RAISED', requested=recipe['backward'])
            else:
                row['forward'] = dict(status='RETURNED', output=snapshot(result))
            row['inputs_after_forward'] = [snapshot(t) for t in inputs]
            if result is not None and recipe['backward']:
                if result.numel() == 0:
                    seed = torch.empty(tuple(result.shape), dtype=result.dtype, device='cpu', requires_grad=False)
                    seed_method = 'torch.empty(output.shape), zero elements'
                else:
                    seed = torch.ones_like(result, memory_format=torch.contiguous_format, requires_grad=False)
                    seed_method = 'torch.ones_like(output), contiguous'
                before_seed = snapshot(seed)
                try:
                    result.backward(seed)
                except Exception as error:
                    row['backward'] = raised(error)
                else:
                    row['backward'] = dict(status='RETURNED')
                row['backward'].update(requested=True, seed_construction=seed_method, seed_before=before_seed,
                                       seed_after=snapshot(seed), output_after=snapshot(result))
            elif result is not None:
                row['backward'] = dict(status='NOT_REQUESTED_FORWARD_ONLY', requested=False)
            row['inputs_after_backward_or_skip'] = [snapshot(t) for t in inputs]
            del result, seed, arguments, indices
            gc.collect()
            row['inputs_after_releasing_output_and_seed'] = [snapshot(t) for t in inputs]
            after_rng = bytes(torch.get_rng_state().tolist())
            assert after_rng == before_rng == initial_rng
            row.update(rng_unchanged=True, rng_sha256=sha(after_rng), observation_complete=True)
            return row

        for recipe in CASES:
            report['rows'].append(observe_case(recipe))
        assert len(report['rows']) == 10 and all(row['observation_complete'] for row in report['rows'])
        assert all(Path(path).read_bytes() == raw for path, raw in originals.items())
        assert bytes(torch.get_rng_state().tolist()) == initial_rng
        report.update(status='OBSERVED', cases=10, inputs_unchanged=True, rng_unchanged=True,
                      rng_sha256=sha(initial_rng), torch_exceptions_are_observations_not_native_pass=True)
    except BaseException as error:
        report.update(status='FAIL', error=dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
        code = 1
    (output / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + '\n')
    print(json.dumps({key: report.get(key) for key in ('status', 'cases', 'expected_cases', 'error')}))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
