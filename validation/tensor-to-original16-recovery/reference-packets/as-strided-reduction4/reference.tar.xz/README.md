# AsStrided reduction bit observations: four additive recipes

This reference is independent of the earlier four direct-copy observations. It keeps its own source, actual output, transport records, and preparation history. No native expected value is used to construct the reference.

The probe is `cea71a50c31d181c8e6615ed18e12cf4b138ea13974257336f7fe7b85bf3850d`; the actual reference is 133,284 bytes, SHA256 `6cb9f88cbcc5d079f6b7c97e5dfa92bfa468478f927b1f57dc13a81dc565f6fc`. Durable job `1a1e5f5d95c-392-3a27` completed with exit 0. All six remote files are preserved with their original bytes and modes and independently checked fixed-version reads.

Both views have shape `(2,3)` over the same contiguous `(2,3)` base. One has stride `(0,1)`, exercising the zero-stride sum. The other has stride `(1,1)`, exercising the nonzero overlapping output and `index_add_`. Each uses negative-zero or six distinct signed quiet-NaN payload words. The original observer, seed construction, getter order, and operation sequence are unchanged from the direct-copy probe. Six textual changes reverse exactly to that source.

All four recipes were observed, all 32 attempted operations succeeded, and no operation or probe error occurred. The exact fixed wheel/source/Python/platform and all eleven provenance fields were verified. The complete 5,056-byte CPU RNG state is unchanged.

## Actual results

In both reduction geometries, six negative-zero inputs produce six positive-zero words in the base gradient. The retained view gradient keeps the original six negative-zero words. This distinguishes these operations from the direct-copy branch.

For the input words `[7fc12345, ffc23456, 7fc00001, ffc00002, 7fc34567, ffc45678]`, the zero-stride base gradient is `[7fc12345, ffc23456, 7fc00001, 00000000, 00000000, 00000000]`. The nonzero overlapping view produces `[7fc12345, ffc00002, 7fc34567, ffc45678, 00000000, 00000000]`. These are observations from the actual wheel, not inferred IEEE expectations. The retained view gradient keeps the input logical order and all input words.

Both base gradients are contiguous `(3,1)`, Version 1. Both retained view gradients are contiguous `(3,1)`, Version 0. The actual `_to_copy(Preserve)` output stride is `(3,1)` for the zero-stride view and `(1,2)` for the equal, nonzero input strides. All real Tensor/Storage relations and complete physical/logical bytes remain in the raw reference.

## Offline verification and preserved correction

Use the final verifier in a new output path:

```sh
python -B verify_observation_v2.py --root /absolute/path/to/reference-overlap4 --output /absolute/path/to/new-admission.json
```

The final offline result has 744 passing checks and no failure. It executes neither PyTorch nor native code. The reference remains `OBSERVED`, with no native qualification claim.

The first verifier incorrectly added a contiguous-output assumption for both layouts. Its original source `c988fc41...` and original `admission-first.json` failure are preserved. Only that one layout expression is corrected in v2 to the actual `(1,2)` equal-stride result. The raw reference, probe, numerical words, Version, identity, provenance, and transport predicates are unchanged. Whole-file inverse proofs and the original direct-copy source/reader are included.

The child NumPy initialization warning is preserved; the probe does not use NumPy. No new weak-reference, reclamation, signaling-NaN, wider-vector, larger-reduction, or cross-backend behavior is claimed. The accompanying pinned sum-source review distinguishes the two-element scalar fold from larger four-lane reductions. The original direct-copy reference remains separately frozen.
