#!/usr/bin/env python3
"""Offline byte/provenance and observation audit; executes neither Torch nor native."""
import argparse
import base64
import hashlib
import itertools
import json
from pathlib import Path
import struct
import traceback

PROBE = 'cea71a50c31d181c8e6615ed18e12cf4b138ea13974257336f7fe7b85bf3850d'
ACTUAL = '6cb9f88cbcc5d079f6b7c97e5dfa92bfa468478f927b1f57dc13a81dc565f6fc'
SUPPORT = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
JOB = '1a1e5f5d95c-392-3a27'
REMOTE = '/home/qian-qi/heptatorch-continuation-20261116/runs/to-as-strided-reduction-bits4-01'
REPO = '/home/qian-qi/heptatorch-continuation-20261116/repo-pr28-repair'
PYTHON = '/home/qian-qi/heptatorch-continuation-20261116/runs/pr28-observer-repair/torch-venv/bin/python'
CHECKS = {'python_matches', 'platform_matches', 'version_backend_matches',
          'git_matches_oracle_build_pin', 'distribution_version_matches',
          'direct_url_matches', 'direct_url_archive_sha256_matches',
          'pip_report_url_matches', 'pip_report_archive_sha256_matches',
          'pip_report_version_matches', 'pip_report_requested'}
EVENTS = ['create_base', 'create_true_view', 'base_requires_true', 'base_add_one',
          'real_to_copy', 'retain_view_gradient', 'create_raw_seed', 'backward']
SNAPS = ['before_requires', 'derived_requires_before_version',
         'after_version_and_ordered_getters', 'before_backward', 'after_backward']


def digest(data):
    return hashlib.sha256(data).hexdigest()


class Audit:
    def __init__(self, root):
        self.root = root
        self.checks = []
        self.bound = {}
        self.tensor_observations = 0
        self.raw_word_observations = 0

    def need(self, name, value):
        self.checks.append({'check': name, 'passed': bool(value)})
        if not value:
            raise AssertionError(name)

    def raw(self, rel, expected=None):
        p = self.root / rel
        b = p.read_bytes()
        self.bound[rel] = {'bytes': len(b), 'sha256': digest(b), 'mode': p.stat().st_mode & 0o777}
        if expected:
            self.need('source-bytes:' + rel, digest(b) == expected)
        return b

    def obj(self, rel, expected=None):
        return json.loads(self.raw(rel, expected))

    def tensor(self, t, label):
        basekeys = {'tensor_identity', 'storage_identity', 'dtype', 'width', 'shape', 'stride',
                    'offset', 'storage_bytes', 'version', 'requires_grad', 'is_leaf',
                    'storage_hex', 'storage_sha256', 'logical_hex', 'logical_sha256',
                    'binary_words', 'grad_fn', 'base_tensor_identity', 'retains_grad'}
        self.need(label + ':schema', set(t) in (basekeys, basekeys | {'grad'}))
        self.need(label + ':f32', t['dtype'] == 'torch.float32' and t['width'] == 4)
        for key in ('tensor_identity', 'storage_identity'):
            self.need(label + ':' + key, isinstance(t[key], str) and t[key].isdigit() and int(t[key]) > 0)
        self.need(label + ':layout', len(t['shape']) == len(t['stride']) and all(type(x) is int and x >= 0 for x in t['shape'] + t['stride']) and type(t['offset']) is int and t['offset'] >= 0)
        raw = bytes.fromhex(t['storage_hex'])
        self.need(label + ':storage-bytes-sha', len(raw) == t['storage_bytes'] and digest(raw) == t['storage_sha256'])
        points = [t['offset'] + sum(c * s for c, s in zip(cs, t['stride'])) for cs in itertools.product(*(range(d) for d in t['shape']))]
        self.need(label + ':bounds', all(0 <= i * 4 and i * 4 + 4 <= len(raw) for i in points))
        logical = b''.join(raw[i * 4:i * 4 + 4] for i in points)
        self.need(label + ':logical-bytes-sha-words', logical.hex() == t['logical_hex'] and digest(logical) == t['logical_sha256'] and list(struct.unpack('<' + 'I' * len(points), logical)) == t['binary_words'])
        self.need(label + ':flags-version', type(t['version']) is int and t['version'] >= 0 and all(type(t[k]) is bool for k in ('requires_grad', 'is_leaf', 'retains_grad')))
        self.tensor_observations += 1
        self.raw_word_observations += len(points)
        if t.get('grad') is not None:
            self.tensor(t['grad'], label + '.grad')

    def run(self):
        source = self.raw('pytorch_as_strided_reduction_bits_probe.py', PROBE)
        self.need('remote-source-byte-identical', self.raw('remote/pytorch_as_strided_reduction_bits_probe.py', PROBE) == source)
        self.raw('support/pytorch_oracle.py', SUPPORT)
        lock = self.obj('support/pytorch-oracle-lock.json', LOCK)
        self.raw('peer/as-strided-reduction-probe-source-only.json', 'de8de265b9dd2696d85909352811c55231db609ff54eb20613ca2167820716de')
        source_bytes = self.raw('upstream/FunctionsManual.cpp', 'a8603d6309822a3f93fa4fcb5ada05e2f0f7e29a1b96db64fe6f59ce0c730558')
        custody = self.obj('upstream/source-custody.json')
        entry = next(x for x in custody['files'] if x['path'] == 'torch/csrc/autograd/FunctionsManual.cpp')
        self.need('primary-source-Git-blob', entry['git_blob'] == hashlib.sha1(b'blob ' + str(len(source_bytes)).encode() + b'\0' + source_bytes).hexdigest() and custody['source_ref'] == lock['inventory_commit'])
        transport = self.obj('transport-read-inputs.json')
        for e in transport['entries']:
            self.need('original-transport:' + e['name'], self.raw('transport/' + e['name']) == e['content_text'].encode())
        names = ['actual.json', 'completion.json', 'invocation.json', 'pytorch_as_strided_reduction_bits_probe.py', 'stdout.txt', 'stderr.txt']
        for name in names:
            meta = self.obj('transport/info-' + name + '.json')
            raw = self.raw('remote/' + name)
            self.need('immutable-remote-file:' + name, meta['path'] == REMOTE + '/' + name and len(raw) == meta['size'] and digest(raw) == meta['sha256'] and meta['mode'] == 0o600 and self.bound['remote/' + name]['mode'] == 0o600)
            parts = ['bytes-actual.json-0.json', 'bytes-actual.json-65536.json', 'bytes-actual.json-131072.json'] if name == 'actual.json' else ['bytes-' + name + '-0.json']
            combined = bytearray()
            for part in parts:
                c = self.obj('transport/' + part)
                data = base64.b64decode(c['data_base64'], validate=True)
                self.need('fixed-version-chunk:' + part, c['path'] == meta['path'] and c['version'] == meta['version'] and c['size'] == len(raw) and c['offset'] == len(combined) and c['next_offset'] == len(combined) + len(data) and digest(data) == c['chunk_sha256'] and c['eof'] is (c['next_offset'] == len(raw)))
                combined.extend(data)
            self.need('complete-chunks:' + name, combined == raw)
        status = self.obj('transport/process-final-status.json')
        self.need('durable-job-completed-exit0', status['job_id'] == JOB and status['state'] == 'succeeded' and status['exit_code'] == 0 and status['automatic_retry'] is False and status['timed_out'] is False and status['cancelled'] is False)
        self.need('durable-job-complete-logs', all(status[k] is True for k in ('output_complete', 'output_durable', 'terminal_publication_confirmed')) and status['log_synced'] == {'stdout': True, 'stderr': True} and status['log_truncated'] == {'stdout': False, 'stderr': False})
        outer = self.obj('transport/process-final-read.json')
        self.need('outer-log-job', outer['job_id'] == JOB)
        for key in ('stdout', 'stderr'):
            x = outer[key]
            z = bytes.fromhex(x['bytes_hex'])
            self.need('outer-log:' + key, x['offset'] == 0 and x['next_offset'] == x['size'] == len(z) == status['log_bytes'][key]['seen'] == status['log_bytes'][key]['stored'] and x['eof'] is True and z.decode() == x['text'])
        complete = self.obj('remote/completion.json')
        self.need('child-completion', all(complete[k] is True for k in ('process_started', 'process_completed', 'source_unchanged')) and complete['returncode'] == 0 and json.loads(outer['stdout']['text']) == complete)
        self.need('child-file-inventory', set(complete['files']) == set(names) - {'completion.json'})
        for name, row in complete['files'].items():
            self.need('child-file:' + name, self.bound['remote/' + name] == row)
        inv = self.obj('remote/invocation.json')
        args = [PYTHON, '-B', REMOTE + '/pytorch_as_strided_reduction_bits_probe.py', '--reference', REPO + '/tests/pytorch_oracle.py', '--lock', REPO + '/compatibility/pytorch-oracle-lock.json', '--repo', REPO, '--output', REMOTE + '/actual.json']
        self.need('exact-child-invocation', inv['argv'] == args and inv['cwd'] == REPO and inv['executable'] == PYTHON and inv['resolved_executable'] == '/usr/bin/python3.12' and inv['executable_sha256'] == 'e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f' and inv['source_sha256'] == PROBE and inv['native_executed'] is False and inv['time_ns_before'] < complete['time_ns_after'])
        a = self.obj('remote/actual.json', ACTUAL)
        prepared = self.obj('prepared.json')
        self.need('original-prepared-history', prepared['status'] == 'PREPARED_NOT_RUN' and prepared['torch_executed'] is False and prepared['cases'] == 0 and prepared['rows'] == [] and prepared['case_plan'] == a['case_plan'])
        self.need('actual-status-scope', a['schema'] == 'heptatorch.as-strided-reduction-bits-reference4.v1' and a['status'] == 'OBSERVED' and a['torch_executed'] is True and a['native_executed'] is False and a['native_qualified'] is False and a['pytorch_api_qualified'] == 0 and a['pytorch_api_denominator'] == 2590 and a['full_pytorch_rewrite_complete'] is False)
        self.need('source-unchanged', a['probe_sha256'] == PROBE and a['primary_source_ref'] == lock['inventory_commit'] and a['source_files_unchanged'] is True and a['inputs_sha256'] == {REMOTE + '/pytorch_as_strided_reduction_bits_probe.py': PROBE, REPO + '/tests/pytorch_oracle.py': SUPPORT, REPO + '/compatibility/pytorch-oracle-lock.json': LOCK})
        p = a['oracle_provenance'];e = lock['oracle'];o = p['observed']
        self.need('all11-independent-fields', p['status'] == 'PASS' and set(p['checks']) == CHECKS and all(x is True for x in p['checks'].values()) and p['expected'] == e and p['metadata_error'] is None and p['lock_sha256'] == LOCK and p['lock_path'] == REPO + '/compatibility/pytorch-oracle-lock.json' and p['release_source_equivalence'] == lock['release_source_equivalence'])
        self.need('observed-exact-fields', set(o) == {'python', 'platform', 'version', 'git_commit', 'backend_versions', 'distribution_version', 'direct_url', 'install_report'})
        self.need('observed-python-platform', set(o['python']) == {'implementation', 'version', 'full_version'} and o['python']['implementation'] == e['python']['implementation'] and o['python']['version'] == e['python']['version'] and o['python']['full_version'].startswith('3.12.') and o['platform'] == e['platform'])
        self.need('observed-version-backend', o['version'] == o['distribution_version'] == e['version'] and o['git_commit'] == e['git_commit'] and o['backend_versions'] == e['backend_versions'])
        dl = {'url': e['wheel']['url'], 'archive_info': {'hash': 'sha256=' + e['wheel']['sha256'], 'hashes': {'sha256': e['wheel']['sha256']}}}
        self.need('observed-full-direct-url', o['direct_url'] == dl)
        ip = o['install_report']
        self.need('observed-full-install-report', set(ip) == {'path', 'pip_version', 'download_info', 'metadata_name', 'metadata_version', 'requested'} and ip['path'] == e['install_report'] and ip['download_info'] == dl and ip['metadata_name'] == e['distribution'] and ip['metadata_version'] == e['version'] and ip['requested'] is True and ip['pip_version'] == '25.1.1')
        self.need('environment-restored', a['environment_restored'] is True and a['environment_before'] == a['environment_after'] and a['environment_before']['grad_enabled'] is True and a['environment_before']['deterministic_algorithms'] is True and a['environment_before']['deterministic_fill'] is True)
        self.need('exact-four-observed', a['cases'] == len(a['rows']) == len(a['case_plan']) == 4 and a['probe_error_count'] == 0 and a['probe_errors'] == [] and a['operation_totals'] == {'attempted': 32, 'succeeded': 32, 'raised': 0})
        for key, value in a['states'].items():
            raw = bytes.fromhex(value['hex'])
            self.need('MT5056:' + key, len(raw) == value['bytes'] == 5056 and digest(raw) == key)
        self.need('no-RNG-consumption', set(a['states']) == {a['environment_before']['rng']})
        results = []
        for i, (r, spec) in enumerate(zip(a['rows'], a['case_plan'])):
            prefix = 'case' + str(i)
            self.need(prefix + ':plan', {k: r[k] for k in spec} == spec and r['index'] == i and r['status'] == 'OBSERVED')
            self.need(prefix + ':event-snapshot-order', [e['label'] for e in r['events']] == EVENTS and [s['label'] for s in r['snapshots']] == SNAPS)
            self.need(prefix + ':all-operations-success', all(e['accepted'] is True and e['error'] is None for e in r['events']))
            states = [r['state_before'], r['state_after']] + [e[k] for e in r['events'] for k in ('state_before', 'state_after')] + [s['rng'] for s in r['snapshots']]
            self.need(prefix + ':fullMT-unchanged', set(states) == set(a['states']))
            for j, s in enumerate(r['snapshots']):
                self.need(prefix + ':snapshot-members:' + str(j), set(s['tensors']) == ({'base', 'view'} if j < 3 else {'base', 'view', 'copy', 'seed'}))
                for name, t in s['tensors'].items():
                    self.tensor(t, prefix + '/' + s['label'] + '/' + name)
            ts = [s['tensors'] for s in r['snapshots']]
            for name in ('base', 'view'):
                self.need(prefix + ':' + name + '-stableT/S', len({t[name]['tensor_identity'] for t in ts}) == 1 and len({t[name]['storage_identity'] for t in ts}) == 1)
                self.need(prefix + ':' + name + '-version', [t[name]['version'] for t in ts] == [0, 0, 1, 1, 1])
                self.need(prefix + ':' + name + '-requires', [t[name]['requires_grad'] for t in ts] == [False, True, True, True, True])
            self.need(prefix + ':true-view-and-derived-history', all(t['view']['base_tensor_identity'] == t['base']['tensor_identity'] and t['view']['storage_identity'] == t['base']['storage_identity'] and t['view']['tensor_identity'] != t['base']['tensor_identity'] for t in ts) and [t['view']['is_leaf'] for t in ts] == [True, True, False, False, False] and ts[0]['view']['grad_fn'] is None and ts[1]['view']['grad_fn'] is None)
            for t in ts[2:]:
                self.need(prefix + ':real-captured-edge', t['view']['grad_fn'] == {'kind': 'AsStridedBackward0', 'next_edges': [{'kind': 'AccumulateGrad', 'output_nr': 0, 'variable_tensor_identity': t['base']['tensor_identity']}]})
            t = ts[-1];seed=t['seed'];bg=t['base']['grad'];vg=t['view']['grad'];copy=t['copy']
            self.need(prefix + ':explicit-seed', seed['logical_hex'] == r['seed_hex'] and seed['binary_words'] == r['seed_words'] and seed['base_tensor_identity'] is not None and seed['version'] == 0)
            self.need(prefix + ':first-grad-version-layout', bg['version'] == 1 and bg['shape'] == [2, 3] and bg['stride'] == [3, 1] and vg['version'] == 0 and vg['shape'] == r['shape'] and vg['stride'] == [3, 1])
            self.need(prefix + ':fresh-independent-grad-identities', len({x['tensor_identity'] for x in (t['base'],t['view'],copy,seed,bg,vg)}) == 6 and len({x['storage_identity'] for x in (t['base'],copy,seed,bg,vg)}) == 5)
            self.need(prefix + ':retain-and-copy-edge', t['view']['retains_grad'] is True and copy['grad'] is None and copy['version'] == 0 and copy['grad_fn'] == {'kind': 'ToCopyBackward0', 'next_edges': [{'kind': 'AsStridedBackward0', 'output_nr': 0}]})
            points=[r['offset']+sum(c*s for c,s in zip(cs,r['stride'])) for cs in itertools.product(*(range(d) for d in r['shape']))]
            observed_base_words = ([0,0,0,0,0,0], [0x7fc12345,0xffc23456,0x7fc00001,0,0,0], [0,0,0,0,0,0], [0x7fc12345,0xffc00002,0x7fc34567,0xffc45678,0,0])[i]
            self.need(prefix + ':observed-reduction-words', vg['binary_words'] == seed['binary_words'] and bg['binary_words'] == observed_base_words and copy['stride'] == [3, 1])
            results.append({'index':i,'name':r['name'],'status':'OBSERVED','operations':8,'snapshots':5,'seed_words_hex':[f'{x:08x}' for x in seed['binary_words']],'base_gradient_words_hex':[f'{x:08x}' for x in bg['binary_words']],'view_gradient_words_hex':[f'{x:08x}' for x in vg['binary_words']],'base_gradient_version':bg['version'],'view_gradient_version':vg['version'],'base_gradient_stride':bg['stride'],'view_gradient_stride':vg['stride'],'copy_gradient':None,'RNG5056_unchanged':True})
        return results


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    assert not args.output.exists()
    a=Audit(args.root)
    report={'schema':'heptatorch.as-strided-reduction-bits4-offline-admission.v1','native_executions_this_audit':0,'torch_executions_this_audit':0,'reference_status':'OBSERVED','native_qualified':False,'pytorch_api_qualified':0,'source_sha256':digest(Path(__file__).read_bytes())}
    try:
        report.update(status='PASS',observations=a.run())
    except BaseException as error:
        report.update(status='FAIL',error=repr(error),traceback=traceback.format_exc())
    report.update(checks=a.checks,checks_passed=sum(x['passed'] for x in a.checks),checks_failed=sum(not x['passed'] for x in a.checks),bound_inputs=a.bound,tensor_observations=a.tensor_observations,raw_word_observations=a.raw_word_observations)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:report[k] for k in ('status','checks_passed','checks_failed','reference_status','native_qualified')}))
    return report['status']!='PASS'


if __name__=='__main__':
    raise SystemExit(main())
