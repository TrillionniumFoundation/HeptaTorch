import hashlib,json,os,pathlib,subprocess,sys,time,traceback
p=json.loads(sys.stdin.read()); root=pathlib.Path(p['root']);root.mkdir(mode=0o700,parents=False,exist_ok=False)
def sha(x):return hashlib.sha256(x).hexdigest()
source=root/'pytorch_as_strided_copy_bits_probe.py'; raw=p['source'].encode(); assert sha(raw)==p['source_sha256'];source.write_bytes(raw);source.chmod(0o600)
py=pathlib.Path(p['python']);repo=pathlib.Path(p['repo']); assert py.is_file() and os.access(py,os.X_OK)
for rel,pin in p['pins'].items():assert sha((repo/rel).read_bytes())==pin
request={'executable':str(py),'resolved_executable':str(py.resolve()),'executable_sha256':sha(py.resolve().read_bytes()),'cwd':str(repo),'argv':[str(py),'-B',str(source),'--reference',str(repo/'tests/pytorch_oracle.py'),'--lock',str(repo/'compatibility/pytorch-oracle-lock.json'),'--repo',str(repo),'--output',str(root/'actual.json')],'source_sha256':sha(raw),'native_executed':False,'time_ns_before':time.time_ns()}
(root/'invocation.json').write_text(json.dumps(request,indent=2)+'\n')
try:
 result=subprocess.run(request['argv'],cwd=repo,capture_output=True,timeout=150)
 (root/'stdout.txt').write_bytes(result.stdout);(root/'stderr.txt').write_bytes(result.stderr)
 outcome={'process_started':True,'process_completed':True,'returncode':result.returncode,'time_ns_after':time.time_ns(),'source_unchanged':source.read_bytes()==raw,'files':{}}
 for f in sorted(root.iterdir()):
  if f.is_file():data=f.read_bytes();outcome['files'][f.name]={'bytes':len(data),'sha256':sha(data),'mode':f.stat().st_mode&0o777}
 (root/'completion.json').write_text(json.dumps(outcome,indent=2)+'\n'); print(json.dumps(outcome));sys.exit(result.returncode)
except BaseException as error:
 if isinstance(error,SystemExit):raise
 (root/'execution-error.json').write_text(json.dumps({'error':repr(error),'traceback':traceback.format_exc()},indent=2)+'\n');raise
