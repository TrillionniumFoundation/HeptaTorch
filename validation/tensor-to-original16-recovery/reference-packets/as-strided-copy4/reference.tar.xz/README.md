# AsStrided direct-copy bit observations: four additive recipes

This package contains one actual run of the fixed CPU PyTorch wheel. The raw reference remains `OBSERVED`; it does not qualify a native implementation or increase the public API compatibility count.

The probe source is `e61ec8727551d513e7e1f7b442faac61098ea415d2b430fafcbe31350b083225`. Its raw `remote/actual.json` is 133,222 bytes, SHA256 `5c377c9b0f9d7ebee572c9bdd58bdb68d2dde6e312e040853527dab3e6827acc`. The durable ROG job `1a1e5eef5c9-392-3a20` completed with exit 0. All six remote files were read at their fixed versions and verified against independent full-file SHA256, size, and mode. The original invocation, child output, completion, process output, status, and bounded binary-read responses are included.

## Observed behavior

Four recipes cover two true, non-overlapping views over a contiguous base: shape `(2,3)`, stride `(3,1)`, and shape `(3,2)`, stride `(1,3)`. Each layout uses either six binary32 negative-zero words or six distinct quiet-NaN words carrying both signs. The seed is actually constructed from raw bytes, cloned, and reshaped; the report records its real resulting bytes and base identity.

The base starts with `requires_grad=False`. After creating the view, the probe enables the base's flag, performs one no-grad scalar addition, and reads the declared metadata getters. This refreshes real `AsStridedBackward0` history. The probe then creates a real `_to_copy`, retains the view gradient, and calls first-order backward with the explicit seed.

All 32 attempted operations succeeded. There were four observed recipes, no probe errors, and no operation exceptions. All 11 provenance checks passed. The verifier also compares the complete observed version, distribution version, direct wheel URL and archive hashes, installation record, Python/platform, backend, and the fixed release/source-equivalence record; it does not accept flags alone.

In both geometries, the base gradient preserves the negative-zero words and every quiet-NaN sign and payload. For the transposed view, the base's logical gradient order is seed indices `[0,2,4,1,3,5]`. The retained view gradient preserves seed logical order. The base gradient has shape `(2,3)`, contiguous stride `(3,1)`, and Version 1. The retained view gradient is contiguous in its own shape and has Version 0. Both gradients have independent Tensor/Storage identities, and the copy's gradient remains undefined. The full 5,056-byte CPU RNG state is unchanged throughout.

The original child stderr records a NumPy initialization warning from the wheel (`No module named 'numpy'`). This probe does not use NumPy; the warning is preserved and no operation or probe error was hidden. The earlier regular-file preflight rejection of the venv Python symlink is also preserved. The actual execution used that existing venv and separately recorded its resolved executable hash.

## Source relationship and limits

The full fixed `FunctionsManual.cpp` and its original source-custody record are included. The verifier recomputes the Git blob. The upstream non-overlapping-output branch uses a `copy_` into the strided storage view; the overlapping branch uses `index_add_`, with zero-stride reduction handled separately. This four-case reference exercises the direct-copy branch. It does not qualify overlap reductions, signaling NaNs, another backend, other view geometries, higher-order derivatives, or Tensor reclamation. A separate additive overlap reference was recorded after these four cases; these four original cases remain unchanged.

The native To05 implementation was not executed by this package. Its producer's subsequent original-candidate comparison is separate evidence. The native producer and old fixtures are not modified here.

## Offline verification

Run the following command from any working directory, selecting a new output path:

```sh
python -B verify_observation.py --root /absolute/path/to/reference4 --output /absolute/path/to/new-admission.json
```

The verifier imports neither Torch nor the native producer and runs no subprocess. The first actual offline audit produced 747 passing checks, zero failed checks, and preserves `reference_status=OBSERVED`, `native_qualified=false`. The historical `prepared.json` remains `PREPARED_NOT_RUN`; it was not overwritten by the actual result.
