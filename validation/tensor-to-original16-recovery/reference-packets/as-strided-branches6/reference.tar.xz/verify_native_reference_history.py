#!/usr/bin/env python3
"""Pure byte verification of the preserved native first-failure history."""
import argparse
import hashlib
import io
import json
import lzma
from pathlib import Path, PurePosixPath
import tarfile


def sha(b):
    return hashlib.sha256(b).hexdigest()


def single_xz(b):
    d = lzma.LZMADecompressor(format=lzma.FORMAT_XZ)
    p = d.decompress(b)
    assert d.eof and not d.unused_data
    return p


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--manifest-sha256', required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    assert not a.output.exists()
    mraw = (a.root / 'manifest.json').read_bytes()
    assert sha(mraw) == a.manifest_sha256
    m = json.loads(mraw)
    qraw = (a.root / 'qualification.json').read_bytes()
    assert sha(qraw) == m['qualification_sha256']
    q = json.loads(qraw)
    z = (a.root / m['archive']).read_bytes()
    assert len(z) == m['archive_bytes'] and sha(z) == m['archive_sha256']
    plain = single_xz(z)
    wanted = m['members']
    assert len(wanted) == m['member_count'] and wanted
    seen = set()
    total = 0
    reports = {}
    owner_chunks = 0
    with tarfile.open(fileobj=io.BytesIO(plain), mode='r:') as t:
        for member in t:
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert member.name == path.as_posix() and member.name not in seen and member.name in wanted
            seen.add(member.name)
            record = wanted[member.name]
            raw = t.extractfile(member).read()
            assert len(raw) == member.size == record['bytes'] and sha(raw) == record['sha256']
            assert member.mode == record['mode']
            total += len(raw)
            if member.name.endswith('.owner.xz'):
                owner = single_xz(raw)
                assert sha(owner) == path.name.removesuffix('.owner.xz')
                owner_chunks += 1
            if path.name == 'report.json':
                reports[member.name] = {'sha256': sha(raw), 'report': json.loads(raw)}
    assert seen == set(wanted) and total == m['original_bytes']
    observations = []
    if 'reports' in q:
        for record in q['reports']:
            got = reports[record['path']]
            assert got['sha256'] == record['sha256']
            r = got['report']
            assert all(r[k] == v for k, v in record.items() if k not in ('path', 'sha256'))
            assert r['reference_sha256'] == q['reference_sha256']
            observations.append(record)
    else:
        matched = [(name, x) for name, x in reports.items() if x['sha256'] == q['report_sha256']]
        assert len(matched) == 1
        name, got = matched[0]
        r = got['report']
        for key in ['reference_sha256', 'probe_sha256', 'source_sha256', 'native_sha256', 'cases', 'passed', 'failed', 'frames', 'checks', 'exact_words', 'rng_bytes']:
            assert r[key] == q[key]
        assert q['status'] == 'FAIL_PRESERVED' and r['status'] == 'FAIL'
        observations.append({'path': name, 'sha256': got['sha256'], 'status': r['status'],
                             'cases': r['cases'], 'passed': r['passed'], 'failed': r['failed']})
    out = {'schema': 'heptatorch.native-reference-history-byte-review.v1',
           'status': 'PASS', 'review_source_sha256': sha(Path(__file__).read_bytes()),
           'manifest_sha256': sha(mraw), 'qualification_sha256': sha(qraw),
           'archive_sha256': sha(z), 'archive_bytes': len(z),
           'tar_sha256': sha(plain), 'tar_bytes': len(plain),
           'member_count': len(seen), 'expanded_member_bytes': total,
           'owner_snapshots_single_xz_and_plain_hash_verified': owner_chunks,
           'all_member_bytes_sizes_modes_verified': True,
           'single_xz_stream_verified_through_EOF': True,
           'original_statuses_preserved': observations,
           'native_executions_this_review': 0, 'torch_executions_this_review': 0,
           'note': 'Verifies preserved executed evidence bytes; does not rerun or reclassify any native result.'}
    a.output.write_text(json.dumps(out, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: out[k] for k in ['status', 'member_count', 'expanded_member_bytes', 'owner_snapshots_single_xz_and_plain_hash_verified']}))


if __name__ == '__main__':
    main()
