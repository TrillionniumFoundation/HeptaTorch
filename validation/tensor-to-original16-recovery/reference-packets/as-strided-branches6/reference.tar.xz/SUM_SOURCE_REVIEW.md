# CPU sum order behind AsStrided backward

This review binds the source at `31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457` to four separate, immutable actual reference runs. It does not execute Torch or a native candidate. The references remain `OBSERVED`; each native replay keeps its own source, image, and result.

## Why a single first-NaN rule is insufficient

`as_strided_backward` processes output axes in descending order. A size greater than one with zero stride is reduced by a distinct `sum` call before the remaining geometry is considered. The remaining geometry chooses either `copy_` into the new zero storage or `index_add_` for possible overlap. This is a whole-geometry decision. A location having one contributor is not sufficient to switch an overlapping output to the copy path. See the pinned [FunctionsManual.cpp](https://github.com/pytorch/pytorch/blob/31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457/torch/csrc/autograd/FunctionsManual.cpp), especially the output-axis processing and later copy/index-add selection.

The measured direct-copy cases retain negative zero and the signed quiet-NaN payload in the base gradient. The measured reduction cases turn an all-negative-zero contribution into positive zero. These differences follow separate operations and must not be repaired by changing a global addition helper.

## Reduction tree and accumulator type

The pinned [SumKernel.cpp](https://github.com/pytorch/pytorch/blob/31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457/aten/src/ATen/native/cpu/SumKernel.cpp) initializes the output with positive zero. `CastStoreAccumulate` adds a computed subtotal into that output. `multi_row_sum` uses four levels of partial accumulators; `row_sum` distributes inputs across four independent lanes, processes the scalar remainder into lane zero, and then folds lanes one through three into lane zero. These are floating-point operations, so replacing their tree with a mathematically equivalent sequential sum can change both finite rounding and NaN payload selection.

For float32 this particular CPU kernel explicitly selects `acc_type<scalar_t, true>`. The pinned [AccumulateType.h](https://github.com/pytorch/pytorch/blob/31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457/aten/src/ATen/AccumulateType.h) maps that float specialization to float. The general CPU float-to-double specialization is not the one used at this call site.

The fixed support file calls `torch.set_num_threads(1)`. Actual reports record CPU capability `AVX512`, and the branch-six probe additionally requires it before observation. The raw reports do not separately record `get_num_threads()`: single-thread configuration is bound to the unchanged support source, while AVX512 is an actual recorded field. The pinned [TensorIteratorReduce.cpp](https://github.com/pytorch/pytorch/blob/31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457/aten/src/ATen/native/TensorIteratorReduce.cpp) selects the serial path for a one-thread execution. The AVX512 float vector definition has 16 elements.

## Minimum branch matrix and actual distinctions

The branch names below are inferred from pinned source, the observed incoming contiguous layout, and the fixed AVX512 profile. They are not instruction-pointer traces. Every seed word is an explicit input word. The expected native result comes only from the preserved actual report.

| View shape and stride | Source-selected computation | Actual distinction |
|---|---|---|
| `[8,3]`, `[0,1]` | Scalar outer tail: one four-lane `row_sum` per column | Row four's NaN payload survives row one's payload because row four is in lane zero. Finite cancellation gives `[1,2,-2]` in the used base region. |
| `[8,4]`, `[0,1]` | Scalar outer main group: four separate column accumulators | Row one's NaN payload survives. Finite cancellation gives `[0,1,-1,0]`. This differs from reusing the three-column tail tree. |
| `[3,81]`, `[1,0]` | Vector inner: 64-element main group, one 16-element vector tail, one scalar tail | The final scalar accumulator receives the scalar tail before the 16 vector lanes. With payloads at reduced indices 4, 64, and 80, the actual result selects index 4. The finite recipes yield `[1,2,-2]`. |
| `[8,81]`, `[0,1]` | Vector outer: 64 columns through the main group, 16 columns through vector `row_sum`, one scalar column through scalar `row_sum` | The first 64 columns select row-one payloads; columns 64 through 80 select row-four payloads. Finite cancellation likewise changes at column 64. |

All used base gradients in these new references have Version 1. Their unused second row contains positive zero. The retained view gradient has Version 0, a new independent storage, its own contiguous layout, and exactly the original seed words. All complete 5056-byte RNG states remain unchanged. Full tensor and storage identities, strides, offsets, bytes, captured edges, warnings, and events remain in the original reports rather than being replaced by this table.

## Source facts and measured NaN propagation are separate

The C++ source determines the reduction tree. It does not, by itself, establish which operand's NaN payload the compiled wheel will propagate for every addition instruction. The measured vector-inner final fold chooses the later contributing NaN in its actual fold order, while the measured scalar-outer and four-lane paths have different observed selections. Therefore the native implementation must preserve the source-selected stages and use the measured operand behavior for those stages. A blanket first-payload or last-payload rule across the entire AsStrided output is contradicted by the references.

This packet qualifies only the recorded float32 CPU inputs and fixed configuration. It does not infer all signaling-NaN behavior, other CPU capabilities, multithread reductions, higher-level carry thresholds, arbitrary strided incoming gradients, or all rank-four zero-axis combinations from these recipes.

## Preserved progression

The earlier copy-four and reduction-four packets are unchanged. The new lanes-two reference exposed the original candidate 07's two failures; candidate 08 passed those same two inputs. The separate branch-six reference then exposed six failures on that unchanged candidate 08. The first branch-six failure archive contains the full candidate source, image, units, requests, responses, owner snapshots, and original report. The reference and native result are distinct evidence; neither is relabeled by a successor's outcome.
