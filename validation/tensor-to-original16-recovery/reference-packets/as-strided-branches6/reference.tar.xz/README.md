# reference-branches6: complete actual-reference packet

The fixed Torch wheel observed **6 recipes and 48 successful operations**, with no probe or operation errors. The original report remains `OBSERVED`; no native qualification is attached to that reference status.

- Actual: `remote/actual.json`, SHA256 `cf8e8dc4c6104fc3ea42d50972bc0728b3b591f1eaaf1f1c446dc67f9a8f5730`.
- Probe: `pytorch_as_strided_sum_branches_probe.py`, SHA256 `c976b3150e4d22648e5def8f3bcfb2e5a8ab7fb331f934ec8ab455b0c9a9996b`.
- Offline byte/provenance/metadata audit: `1135 passed, 0 failed`; reader SHA256 `b2504271435518a71a72d842ce68fbf1a8f640a8958ccb72fe2c1900ab778ec6`.
- Preserved native history: **candidate 08: 0/6**. Its separate original archive contains 267 members and keeps every reported failure. It was byte-verified here without rerunning native or Torch.

## Contents and scope

The packet contains the complete raw actual JSON, exact local/remote probe bytes, original launch request, authoritative durable terminal status and complete process logs, six full remote files with their full-file SHA256/modes/fixed-version metadata and every binary-read chunk, fixed support and lock bytes, original `PREPARED_NOT_RUN` metadata, source and reader inverses, primary upstream source files, independent source-only reviews, and original native history. The explanatory table in `SUM_SOURCE_REVIEW.md` supplements the raw reports. It does not replace any raw values, identities, versions, layouts, complete RNG states, or failures.

CPU capability is actually recorded as `AVX512`. The fixed support source executes `torch.set_num_threads(1)`; the original report does not separately snapshot `get_num_threads()`. Build configuration and all 11 complete provenance fields, including installed distribution version, full direct URL/archive hash and pip report, remain intact.

The native history is the producer's original separately executed evidence. This packet does not claim an independent rerun of those native cases. Later candidates cannot retroactively change the included first-failure status. No production source or previous reference was modified.

## Restore and verify

From this packet's outer directory, use the included byte verifier with a new extraction/output path:

```sh
python -B verify_reference_bundle.py --packet PACKET --extract NEW_DIRECTORY --output NEW_BYTE_REPORT.json
python -B NEW_DIRECTORY/verify_observation.py --root NEW_DIRECTORY --output NEW_REFERENCE_AUDIT.json
python -B NEW_DIRECTORY/verify_native_reference_history.py --root NEW_DIRECTORY/native-history --manifest-sha256 c692aa45a4ea839f0b729c51bd3fbc16e850209832561680f5dcb3f9d7e063e8 --output NEW_NATIVE_HISTORY_BYTE_REVIEW.json
```

All three commands are offline byte/structure checks. They execute neither Torch nor the native image. The outer verifier checks the exact file set, complete archive and uncompressed tar hashes, each member's bytes/size/mode, and a single XZ stream through EOF. The native-history verifier also validates every compressed owner snapshot through EOF and its uncompressed content-address hash.

The unchanged earlier direct-copy4 and reduction4 packets are separate inputs, not rewritten by this packet. The original baseline reader is included only to make the additive inverse reproducible.

The original start-RPC response was not retained in the recovered local transport set. The exact launch request, known job ID, authoritative successful terminal status, complete durable logs, child invocation/completion records, and all immutable file reads are preserved. The known job was not restarted to reconstruct a launch response.
