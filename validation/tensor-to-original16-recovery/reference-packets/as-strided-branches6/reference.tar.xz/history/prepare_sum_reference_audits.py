#!/usr/bin/env python3
"""Create additive offline audits; never execute the reference or native program."""
import ast
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'reference-overlap4/verify_observation_v2.py'
BASE_SHA = '568ac19268641e59252189a538ce68bc5255255c8751559988537d0fd8c4b773'


def sha(b):
    return hashlib.sha256(b).hexdigest()


def copy_new(source, target):
    assert not target.exists(), target
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    assert source.read_bytes() == target.read_bytes()
    assert source.stat().st_mode & 0o777 == target.stat().st_mode & 0o777


def make(dirname, probe_name, probe_sha, actual_sha, job, remote_name, count, transport_dict):
    root = ROOT / dirname
    baseline = BASE.read_text()
    assert sha(baseline.encode()) == BASE_SHA
    actual = json.loads((root / 'remote/actual.json').read_bytes())
    assert sha((root / 'remote/actual.json').read_bytes()) == actual_sha
    assert actual['cases'] == count and actual['probe_sha256'] == probe_sha
    text = baseline
    changes = []

    def change(old, new):
        nonlocal text
        n = text.count(old)
        assert n > 0 and old != new, old
        changes.append({'old': old, 'new': new, 'count': n})
        text = text.replace(old, new)

    change('cea71a50c31d181c8e6615ed18e12cf4b138ea13974257336f7fe7b85bf3850d', probe_sha)
    change('6cb9f88cbcc5d079f6b7c97e5dfa92bfa468478f927b1f57dc13a81dc565f6fc', actual_sha)
    change('1a1e5f5d95c-392-3a27', job)
    change('to-as-strided-reduction-bits4-01', remote_name)
    change('pytorch_as_strided_reduction_bits_probe.py', probe_name)
    change('heptatorch.as-strided-reduction-bits-reference4.v1', actual['schema'])
    change('heptatorch.as-strided-reduction-bits4-offline-admission.v1', actual['schema'].replace('-reference', '-offline-admission'))
    change("        self.raw('peer/as-strided-reduction-probe-source-only.json', 'de8de265b9dd2696d85909352811c55231db609ff54eb20613ca2167820716de')\n", """        inverse = self.obj('source-inverse.json')
        previous = self.raw('history/previous_probe.py', inverse['original_probe_sha256'])
        restored = source.decode()
        for delta in reversed(inverse['changes']):
            self.need('source-inverse-count:' + str(delta['count']), restored.count(delta['new']) == delta['count'])
            restored = restored.replace(delta['new'], delta['old'])
        self.need('source-full-exact-inverse', restored.encode() == previous and inverse['new_probe_sha256'] == PROBE and inverse['exact_whole_file_inverse'] is True)
        config_source = self.raw('support/pytorch_oracle.py', SUPPORT)
        self.need('single-thread-fixed-source-configuration', b'torch.set_num_threads(1)' in config_source)
        # The raw reference records AVX512 but no direct get_num_threads() value.
        # This is a source-bound configuration claim, not a new runtime observation.
        for filename in ('source-custody.json', 'source-custody-02.json'):
            custody_sum = self.obj('sum-upstream/' + filename)
            self.need('sum-source-fixed-ref:' + filename, custody_sum['ref'] == lock['inventory_commit'] and len(custody_sum['files']) == 3)
            for record in custody_sum['files']:
                body = self.raw('sum-upstream/' + record['path'], record['sha256'])
                self.need('sum-source-full-blob:' + record['path'], len(body) == record['bytes'] and hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\\0' + body).hexdigest() == record['git_blob'])
""")
    old = "        for e in transport['entries']:\n            self.need('original-transport:' + e['name'], self.raw('transport/' + e['name']) == e['content_text'].encode())\n"
    new = ("        self.need('transport-index-schema', set(transport) == {'schema', 'entries'} and isinstance(transport['entries'], list))\n        entries = transport['entries']\n" if transport_dict else "        self.need('transport-index-schema', isinstance(transport, list))\n        entries = transport\n")
    new += """        self.need('transport-exact-inventory', entries and len({e['name'] for e in entries}) == len(entries) and {e['name'] for e in entries} == {p.name for p in (self.root / 'transport').iterdir() if p.is_file()})
        for e in entries:
            self.need('original-transport:' + e['name'], self.raw('transport/' + e['name']) == e['content_text'].encode())
"""
    change(old, new)
    change("            parts = ['bytes-actual.json-0.json', 'bytes-actual.json-65536.json', 'bytes-actual.json-131072.json'] if name == 'actual.json' else ['bytes-' + name + '-0.json']", "            parts = ['bytes-' + name + '-' + str(offset) + '.json' for offset in range(0, len(raw), 65536)]")
    old = "        self.need('exact-four-observed', a['cases'] == len(a['rows']) == len(a['case_plan']) == 4 and a['probe_error_count'] == 0 and a['probe_errors'] == [] and a['operation_totals'] == {'attempted': 32, 'succeeded': 32, 'raised': 0})"
    new = f"        self.need('exact-{count}-observed', a['cases'] == len(a['rows']) == len(a['case_plan']) == {count} and a['probe_error_count'] == 0 and a['probe_errors'] == [] and a['operation_totals'] == {{'attempted': {count * 8}, 'succeeded': {count * 8}, 'raised': 0}})\n        self.need('actual-cpu-capability', a['cpu_capability'] == 'AVX512')"
    change(old, new)
    change("bg['shape'] == [2, 3] and bg['stride'] == [3, 1] and vg['version'] == 0 and vg['shape'] == r['shape'] and vg['stride'] == [3, 1]", "bg['shape'] == r['base_shape'] and bg['stride'] == [r['base_shape'][1], 1] and vg['version'] == 0 and vg['shape'] == r['shape'] and vg['stride'] == [r['shape'][1], 1]")
    observed = [row['snapshots'][-1]['tensors']['base']['grad']['binary_words'] for row in actual['rows']]
    literal = '[' + ', '.join('[' + ', '.join(f'0x{x:08x}' for x in words) + ']' for words in observed) + ']'
    old = "            observed_base_words = ([0,0,0,0,0,0], [0x7fc12345,0xffc23456,0x7fc00001,0,0,0], [0,0,0,0,0,0], [0x7fc12345,0xffc00002,0x7fc34567,0xffc45678,0,0])[i]"
    change(old, "            # Literal transcription from the pinned actual reference; never a producer-derived expectation.\n            observed_base_words = " + literal + '[i]')
    change("copy['stride'] == ([3, 1] if i < 2 else [1, 2])", "copy['stride'] == [r['shape'][1], 1]")
    change("'source_sha256':digest(Path(__file__).read_bytes())}", "'source_sha256':digest(Path(__file__).read_bytes()),'thread_configuration':'fixed support source calls torch.set_num_threads(1); raw report does not independently record get_num_threads','branch_labels':'inferred from pinned source and input layout, not instruction tracing'}")
    ast.parse(text)
    restored = text
    for delta in reversed(changes):
        assert restored.count(delta['new']) == delta['count'], delta['new'][:100]
        restored = restored.replace(delta['new'], delta['old'])
    assert restored == baseline
    newfile = root / 'verify_observation.py'
    assert not newfile.exists()
    newfile.write_text(text)
    for name in ['pytorch_oracle.py', 'pytorch-oracle-lock.json']:
        copy_new(ROOT / 'reference4/support' / name, root / 'support' / name)
    for name in ['FunctionsManual.cpp', 'source-custody.json']:
        copy_new(ROOT / 'reference4/upstream' / name, root / 'upstream' / name)
    for path in sorted((ROOT / 'sum-upstream').rglob('*')):
        if path.is_file():
            copy_new(path, root / 'sum-upstream' / path.relative_to(ROOT / 'sum-upstream'))
    inverse = json.loads((root / 'source-inverse.json').read_bytes())
    if dirname == 'reference-lanes2':
        previous = ROOT / 'reference-overlap4/pytorch_as_strided_reduction_bits_probe.py'
    else:
        previous = ROOT / 'reference-lanes2/pytorch_as_strided_sum_lanes_probe.py'
    assert sha(previous.read_bytes()) == inverse['original_probe_sha256']
    copy_new(previous, root / 'history/previous_probe.py')
    copy_new(BASE, root / 'history/previous_offline_audit.py')
    (root / 'reader-inverse.json').write_text(json.dumps({
        'schema': 'heptatorch.additive-actual-observation-audit-inverse.v1',
        'status': 'SOURCE_PREPARED_NOT_RUN', 'before_sha256': BASE_SHA,
        'after_sha256': sha(text.encode()), 'changes': changes,
        'exact_whole_file_inverse': True,
        'observed_word_literals_source': {'path': 'remote/actual.json', 'sha256': actual_sha, 'selector': 'rows[].snapshots[-1].tensors.base.grad.binary_words'},
        'all_original_provenance_comparisons_preserved': True,
        'all_original_tensor_byte_identity_version_checks_preserved': True,
        'native_executed': False, 'torch_executed': False,
    }, indent=2) + '\n')
    print(json.dumps({'root': str(root), 'reader_sha256': sha(text.encode()), 'changes': len(changes)}))


if __name__ == '__main__':
    make('reference-lanes2', 'pytorch_as_strided_sum_lanes_probe.py',
         '0c1ce7e828fc457189d74340951a94f60245139370f4ab6654e54bd8804d6cb8',
         'e4ca312aef1dba177830e5e90f91dc01676fa015ca659a67b5a447628bb0689c',
         '1a1e5fc2bec-392-3a3a', 'to-as-strided-sum-lanes2-01', 2, True)
    make('reference-branches6', 'pytorch_as_strided_sum_branches_probe.py',
         'c976b3150e4d22648e5def8f3bcfb2e5a8ab7fb331f934ec8ab455b0c9a9996b',
         'cf8e8dc4c6104fc3ea42d50972bc0728b3b591f1eaaf1f1c446dc67f9a8f5730',
         '1a1e60092db-392-3a48', 'to-as-strided-sum-branches6-01', 6, False)
