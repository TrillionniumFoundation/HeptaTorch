# reference-lanes2: complete actual-reference packet

The fixed Torch wheel observed **2 recipes and 16 successful operations**, with no probe or operation errors. The original report remains `OBSERVED`; no native qualification is attached to that reference status.

- Actual: `remote/actual.json`, SHA256 `e4ca312aef1dba177830e5e90f91dc01676fa015ca659a67b5a447628bb0689c`.
- Probe: `pytorch_as_strided_sum_lanes_probe.py`, SHA256 `0c1ce7e828fc457189d74340951a94f60245139370f4ab6654e54bd8804d6cb8`.
- Offline byte/provenance/metadata audit: `432 passed, 0 failed`; reader SHA256 `525a81e60cd8a3a32842a1e707b2d9152f22b93bff50c8c8b4196daeca36ab9e`.
- Preserved native history: **candidate 07: 0/2; candidate 08: 2/2**. Its separate original archive contains 115 members and keeps every reported failure. It was byte-verified here without rerunning native or Torch.

## Contents and scope

The packet contains the complete raw actual JSON, exact local/remote probe bytes, original launch request, authoritative durable terminal status and complete process logs, six full remote files with their full-file SHA256/modes/fixed-version metadata and every binary-read chunk, fixed support and lock bytes, original `PREPARED_NOT_RUN` metadata, source and reader inverses, primary upstream source files, independent source-only reviews, and original native history. The explanatory table in `SUM_SOURCE_REVIEW.md` supplements the raw reports. It does not replace any raw values, identities, versions, layouts, complete RNG states, or failures.

CPU capability is actually recorded as `AVX512`. The fixed support source executes `torch.set_num_threads(1)`; the original report does not separately snapshot `get_num_threads()`. Build configuration and all 11 complete provenance fields, including installed distribution version, full direct URL/archive hash and pip report, remain intact.

The native history is the producer's original separately executed evidence. This packet does not claim an independent rerun of those native cases. Later candidates cannot retroactively change the included first-failure status. No production source or previous reference was modified.

## Restore and verify

From this packet's outer directory, use the included byte verifier with a new extraction/output path:

```sh
python -B verify_reference_bundle.py --packet PACKET --extract NEW_DIRECTORY --output NEW_BYTE_REPORT.json
python -B NEW_DIRECTORY/verify_observation.py --root NEW_DIRECTORY --output NEW_REFERENCE_AUDIT.json
python -B NEW_DIRECTORY/verify_native_reference_history.py --root NEW_DIRECTORY/native-history --manifest-sha256 065a64ed9367e5d54d65a2b16d54de7d7fe12bb1e9ad34485d813b34ff5a778b --output NEW_NATIVE_HISTORY_BYTE_REVIEW.json
```

All three commands are offline byte/structure checks. They execute neither Torch nor the native image. The outer verifier checks the exact file set, complete archive and uncompressed tar hashes, each member's bytes/size/mode, and a single XZ stream through EOF. The native-history verifier also validates every compressed owner snapshot through EOF and its uncompressed content-address hash.

The unchanged earlier direct-copy4 and reduction4 packets are separate inputs, not rewritten by this packet. The original baseline reader is included only to make the additive inverse reproducible.

The native lanes-two history references earlier candidate source archives by exact SHA in its original qualification. Those historical dependencies remain at the producer checkpoint location recorded in `handoff.json`; this packet does not claim they are newly cold-built. The full lanes-two requests/responses and owner snapshots are included.
