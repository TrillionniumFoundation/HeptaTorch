def entry(s: readbuf, o: mutbuf, w: mutbuf, scratch: mutbuf) -> u32:
    if length(o) < 32:
        return 0
    reply_error(o, 0)
    error = frame_valid(s)
    if error != 0:
        reply_error(o, error)
        return 32
    putw(w, 0, 0)
    putw(w, 48, 0)
    putw(w, 56, 0)
    count = getr(s, 8)
    if count != 0:
        putw(w, 96, 8192)
    end = 32 + count * 64
    i = 0
    at = 32
    halted = 0
    while i < count and halted == 0:
        if at > length(o) - 32:
            putw(o, 24, 3)
            return at
        putw(w, 104, i)
        code = getr(s, 32 + i * 64)
        if code >= 91 and code <= 94:
            next = gradient_object_command(s, o, w, 32 + i * 64, at)
        elif code >= 71 and code <= 79 or code == 90 or code == 95:
            next = owned_optimizer_command(s, o, w, 32 + i * 64, at, end)
        elif code >= 80 and code <= 89:
            if code == 86 or code == 87:
                next = dist_partial_command(s,o,w,scratch,32+i*64,at)
            else:
                next = dist_command(s,o,w,scratch,32+i*64,at)
        elif code >= 60 and code <= 69:
            next = rng_command(s, o, w, scratch, 32 + i * 64, at, end)
        else:
            next = command(s, o, w, 32 + i * 64, at, end)
        if getw(w, 0) == 0 and getw(w, 3968) != 0:
            graph_collect_since(w, getw(w, 8))
        error = getw(w, 0)
        if error != 0:
            putw(o, 24, error)
            return next
        putw(w, getw(w, 96) + i * 8, getw(o, at + 16))
        if (code == 58 or code == 86 or code == 87) and getw(o, at + 16) != 0:
            halted = 1
        at = next
        i = i + 1
        putw(o, 16, i)
    if count != 0:
        fill_range(w, 8192, count * 8, 0)
        putw(w, 96, 0)
        putw(w, 104, 0)
    putw(w, 80, 0)
    if getw(w, 0) != 0:
        reply_error(o, getw(w, 0))
        return 32
    return at

def partial_apply_node(w:mutbuf, t:u64) -> u64:
    if getw(w,dptr(w,t)+40) == 41:
        dist_backward_bernoulli(w,t)
        if getw(w,0) != 0:
            return 0
        return 1
    return partial_apply_node_gradient(w,t)


def incoming_describe(w: mutbuf, t: u64, parent: u64, edge: u64) -> u64:
    memory_fill(w, 3808, 88, 0)
    p = dptr(w, t)
    op = getw(w, p + 40)
    putw(w, 3840, parent)
    putw(w, 3848, 2)
    incoming_contiguous_layout(w, parent, 3856)
    if op == 1 or (op == 2 and edge == 0) or op == 17 or ((op == 39 or op == 40) and edge == 0):
        if incoming_same_shape(w, t, parent) != 0:
            return incoming_describe_alias(w, t, getw(w, p + 472), getw(w, p + 488))
        return 1
    if op == 10:
        if incoming_describe_alias(w, t, 2, parent) == 0:
            return 0
        a = getw(w, p + 176)
        b = getw(w, p + 184)
        putw(w, 3856 + a * 8, getw(w, p + 496 + b * 8))
        putw(w, 3856 + b * 8, getw(w, p + 496 + a * 8))
        return 1
    if op == 16:
        if incoming_describe_alias(w, t, 2, parent) == 0:
            return 0
        if incoming_reshape_layout(w, t, parent, 3856) != 0:
            return 1
        putw(w, 3808, 0)
        putw(w, 3816, 0)
        putw(w, 3824, 0)
        putw(w, 3832, 0)
        return incoming_contiguous_layout(w, parent, 3856)
    if op == 7:
        if incoming_describe_alias(w, t, 2, parent) == 0:
            return 0
        j = 0
        while j < getw(w, dptr(w, parent)):
            putw(w, 3856 + j * 8, 0)
            j = j + 1
        return 1
    if op == 37 or op == 38:
        return incoming_describe_cat(w, t, parent, edge)
    if op == 41:
        return incoming_zero_layout(w,t,3856)
    if op == 26 or op == 27:
        putw(w, 3888, 1)
        return 1
    if op == 2 or op == 3 or op == 4 or (op == 5) or (op == 6) or (op >= 11 and op <= 15) or (op == 20) or (op == 21) or (op == 22) or (op == 25) or (op == 39) or (op == 40):
        return 1
    putw(w, 3848, 1)
    return 1

def binary(w: mutbuf, op: u64, a: u64, b: u64) -> u64:
    if valid(w, a) == 0 or valid(w, b) == 0:
        return 0
    if op < 1 or op > 4:
        return terror(w, 4)
    rank = bshape(w, a, b)
    req = getw(w, dptr(w, a) + 32) | getw(w, dptr(w, b) + 32)
    t = tnew(w, rank, 128, req)
    if t == 0:
        return 0
    if pointwise_layout(w,t,a,b) == 0:
        return 0
    n = getw(w, dptr(w, t) + 8)
    data = getw(w, dptr(w, t) + 16)
    i = 0
    while i < n:
        ai = bindex(w, t, a, i)
        bi = bindex(w, t, b, i)
        x = tget(w, a, ai)
        y = tget(w, b, bi)
        put4(w, taddr(w,t,i), scalar_binary(op, x, y))
        i = i + 1
    return record(w, t, op, a, b)


def ensure_backward_work(w: mutbuf, limit: u64, epoch: u64) -> u64:
    if incoming_mark_preserve_targets(w,limit,epoch) == 0:
        return 0
    i = 1
    while i <= limit:
        p = dptr(w, i)
        if getw(w, p + 304) != 0 and getw(w, p + 168) == epoch:
            if getw(w, p + 448) != 0 or getw(w, p + 480) != 0 or getw(w, p + 528) != 0:
                return terror(w, 9)
            if getw(w, p + 40) == 0 and getw(w, p + 32) != 0 and (getw(w, p + 384) == 0):
                if gradient_new(w, i) == 0:
                    return 0
            if getw(w, p + 256) == 0:
                address = alloc(w, getw(w, p + 8) * 4)
                if address == 0:
                    return 0
                putw(w, p + 160, address)
                putw(w, p + 256, getw(w, 80))
            if storage_capacity(w, 3, 0) == 0:
                return 0
            vid = so_slot_new(w, 3)
            if vid == 0:
                return terror(w, 9)
            vp = so_slot_lookup(w, 3, vid)
            so_uput(w, vp + 24, 1)
            putw(w, p + 480, vid)
            hp = so_slot_lookup(w, 6, getw(w, p + 256))
            if hp == 0:
                return terror(w, 9)
            putw(w, p + 536, so_uget(w, hp + 16))
            if getw(w,p+544) == 1:
                if incoming_reserve_preserve_storage(w,i) == 0:
                    return 0
        i = i + 1
    return 1

def incoming_drop_cache(w: mutbuf, t: u64) -> u64:
    p = dptr(w, t)
    if hold_release(w, getw(w, p + 256)) == 0:
        return 0
    vid = getw(w, p + 480)
    if vid != 0 and so_version_release(w, vid) != 0:
        return terror(w, 9)
    if hold_release(w,getw(w,p+552)) == 0:
        return 0
    other = getw(w,p+568)
    if other != 0 and so_version_release(w,other) != 0:
        return terror(w,9)
    putw(w,p+544,0)
    putw(w,p+552,0)
    putw(w,p+560,0)
    putw(w,p+568,0)
    putw(w, p + 160, 0)
    putw(w, p + 256, 0)
    putw(w, p + 480, 0)
    putw(w, p + 536, 0)
    return 1

def incoming_can_accumulate(w: mutbuf, t: u64) -> u64:
    p = dptr(w, t)
    if getw(w, p + 472) != 2:
        return 0
    origin = getw(w, p + 488)
    if origin == 0 or getw(w, dptr(w, origin) + 528) != 1 or incoming_dense(w, t, p + 496) == 0:
        return 0
    sp = so_storage_live(w, getw(w, p + 448))
    if sp == 0:
        return terror(w, 9)
    expected = 1
    if getw(w, p + 256) != 0 and getw(w, p + 536) == getw(w, p + 448):
        expected = expected + 1
    if getw(w,p+552) != 0 and getw(w,p+560) == getw(w,p+448):
        expected = expected+1
    return choose(so_uget(w, sp + 40) == expected, 1, 0)

def incoming_construct(w: mutbuf, parent: u64) -> u64:
    p = dptr(w, parent)
    sid = getw(w, 3816)
    vid = getw(w, 3824)
    offset = getw(w, 3832)
    mode = getw(w, 3848)
    origin = getw(w, 3840)
    physical = 0
    if getw(w, 3808) == 0:
        sid = getw(w, p + 536)
        vid = getw(w, p + 480)
        offset = 0
        origin = parent
        if incoming_contiguous(w,parent,3856) == 0:
            sid = getw(w,p+560)
            vid = getw(w,p+568)
            if getw(w,p+552) == 0 or sid == 0 or vid == 0 or sid == getw(w,p+536):
                return terror(w,9)
            physical = 1
    if incoming_bind(w, parent, sid, vid, offset, mode, origin) == 0:
        return 0
    j = 0
    while j < 4:
        putw(w, p + 496 + j * 8, getw(w, 3856 + j * 8))
        j = j + 1
    if physical != 0:
        j = 0
        while j < getw(w,p+8):
            put4(w,incoming_address(w,parent,j),get4(w,getw(w,p+160)+j*4))
            j = j+1
    if getw(w, 3808) == 0 and getw(w, 3888) != 0:
        return incoming_version_bump(w, vid)
    return 1

def incoming_zero_axis_order(w:mutbuf, p:u64) -> u64:
    rank = getw(w,p)
    perm = 0
    i = 0
    while i < rank:
        perm = perm | ((rank-i-1) << (i*8))
        i = i+1
    i = 1
    while i < rank:
        anchor = i
        j = i
        done = 0
        while j > 0 and done == 0:
            j = j-1
            left = (perm >> (j*8)) & 255
            right = (perm >> (anchor*8)) & 255
            ls = getw(w,p+496+left*8)
            rs = getw(w,p+496+right*8)
            if ls != 0 and rs != 0:
                if ls > rs or (ls == rs and getw(w,p+96+left*8) > getw(w,p+96+right*8)):
                    difference = left ^ right
                    perm = perm ^ (difference << (j*8)) ^ (difference << (anchor*8))
                    anchor = j
                else:
                    if ls < rs:
                        done = 1
        i = i+1
    return perm

def incoming_zero_layout(w:mutbuf, t:u64, dest:u64) -> u64:
    p = dptr(w,t)
    if incoming_dense(w,t,p+496) != 0:
        j = 0
        while j < 4:
            putw(w,dest+j*8,getw(w,p+496+j*8))
            j = j+1
        return 1
    order = incoming_zero_axis_order(w,p)
    stride = 1
    j = 0
    while j < getw(w,p):
        axis = (order >> (j*8)) & 255
        putw(w,dest+axis*8,stride)
        size = getw(w,p+96+axis*8)
        if size > 1:
            stride = stride*size
        j = j+1
    return 1


def incoming_mark_preserve_targets(w:mutbuf, limit:u64, epoch:u64) -> u64:
    i = 1
    while i <= limit:
        p = dptr(w,i)
        if getw(w,p+304) != 0 and getw(w,p+168) == epoch:
            if getw(w,p+544) != 0 or getw(w,p+552) != 0 or getw(w,p+560) != 0 or getw(w,p+568) != 0:
                return terror(w,9)
        i = i+1
    i = 1
    while i <= limit:
        p = dptr(w,i)
        if getw(w,p+304) != 0 and getw(w,p+168) == epoch and getw(w,p+40) == 41:
            parent = gradient_parent_at(w,i,0)
            if parent != 0:
                q = dptr(w,parent)
                if getw(w,q+304) == 0 or getw(w,q+168) != epoch:
                    return terror(w,9)
                putw(w,q+544,1)
        i = i+1
    return 1

def incoming_reserve_preserve_storage(w:mutbuf, t:u64) -> u64:
    p = dptr(w,t)
    if getw(w,p+544) != 1:
        return terror(w,9)
    address = alloc(w,getw(w,p+8)*4)
    if address == 0:
        return 0
    hold = getw(w,80)
    hp = so_slot_lookup(w,6,hold)
    if hp == 0:
        return terror(w,9)
    sid = so_uget(w,hp+16)
    if storage_capacity(w,3,0) == 0:
        return 0
    vid = so_slot_new(w,3)
    if vid == 0:
        return terror(w,9)
    vp = so_slot_lookup(w,3,vid)
    so_uput(w,vp+24,1)
    putw(w,p+544,address)
    putw(w,p+552,hold)
    putw(w,p+560,sid)
    putw(w,p+568,vid)
    return 1


def pointwise_compare_axes(w:mutbuf, out:u64, a:u64, b:u64, left:u64, right:u64) -> u64:
    operand = 0
    while operand < 2:
        source = a
        if operand == 1:
            source = b
        ls = dist_probability_stride(w,out,source,left)
        rs = dist_probability_stride(w,out,source,right)
        if ls != 0 and rs != 0:
            if ls < rs:
                return 1
            if ls > rs:
                return 2
            if getw(w,out+96+left*8) > getw(w,out+96+right*8):
                return 2
        operand = operand+1
    return 0

def pointwise_axis_order(w:mutbuf, out:u64, a:u64, b:u64) -> u64:
    rank = getw(w,out)
    perm = 0
    i = 0
    while i < rank:
        perm = perm | ((rank-i-1) << (i*8))
        i = i+1
    i = 1
    while i < rank:
        anchor = i
        j = i
        done = 0
        while j > 0 and done == 0:
            j = j-1
            left = (perm >> (j*8)) & 255
            right = (perm >> (anchor*8)) & 255
            comparison = pointwise_compare_axes(w,out,a,b,left,right)
            if comparison == 2:
                difference = left ^ right
                perm = perm ^ (difference << (j*8)) ^ (difference << (anchor*8))
                anchor = j
            if comparison == 1:
                done = 1
        i = i+1
    return perm

def pointwise_channels_last(w:mutbuf, t:u64) -> u64:
    p = dptr(w,t)
    if getw(w,p) != 4:
        return 0
    expected = 1
    i = 0
    while i < 4:
        axis = (131841 >> (i*8)) & 255
        size = getw(w,p+96+axis*8)
        if size > 1 and getw(w,p+128+axis*8) != expected:
            return 0
        expected = expected*size
        i = i+1
    return 1

def pointwise_write_order(w:mutbuf, p:u64, order:u64, raw_zero:u64) -> u64:
    stride = 1
    i = 0
    while i < getw(w,p):
        axis = (order >> (i*8)) & 255
        putw(w,p+128+axis*8,stride)
        size = getw(w,p+96+axis*8)
        if size != 0 or raw_zero != 0:
            stride = stride*size
        i = i+1
    return 1

def pointwise_layout(w:mutbuf, t:u64, a:u64, b:u64) -> u64:
    p = dptr(w,t)
    pa = dptr(w,a)
    pb = dptr(w,b)
    rank = getw(w,p)
    if incoming_same_shape(w,a,b) != 0:
        if is_contiguous(w,a) != 0 and is_contiguous(w,b) != 0:
            return 1
        if pointwise_channels_last(w,a) != 0 and pointwise_channels_last(w,b) != 0:
            return pointwise_write_order(w,p,131841,0)
        if is_dense(w,a) != 0 and is_dense(w,b) != 0:
            same = 1
            i = 0
            while i < rank:
                if getw(w,pa+128+i*8) != getw(w,pb+128+i*8):
                    same = 0
                i = i+1
            if same != 0:
                i = 0
                while i < rank:
                    putw(w,p+128+i*8,getw(w,pb+128+i*8))
                    i = i+1
                return 1
    order = pointwise_axis_order(w,p,pa,pb)
    inverted = 1
    i = 0
    while i < rank:
        if ((order >> (i*8)) & 255) != rank-i-1:
            inverted = 0
        i = i+1
    if inverted != 0:
        return 1
    return pointwise_write_order(w,p,order,1)


def scalar_add_preserving_bits(a:u64, b:u64) -> u64:
    a = a & 4294967295
    b = b & 4294967295
    aa = a & 2147483647
    bb = b & 2147483647
    if bb > 2139095040:
        return b | 4194304
    if aa > 2139095040:
        return a | 4194304
    if aa == 2139095040 and bb == 2139095040 and ((a ^ b) & 2147483648) != 0:
        return 4290772992
    return addf(a,b)
