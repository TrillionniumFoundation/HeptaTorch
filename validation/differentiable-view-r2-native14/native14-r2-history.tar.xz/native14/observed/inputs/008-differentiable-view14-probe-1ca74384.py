#!/usr/bin/env python3
"""Observe direct differentiable as_strided and chained view graph ownership.

Fourteen fixed CPU recipes. Every outcome comes from the pinned Torch run;
there is no expected gradient or predicted error table in this file. The
existing Tensor.to references and all native producers remain unchanged.
"""
import argparse
import gc
import hashlib
import itertools
import json
from pathlib import Path
import runpy
import struct
import sys
import traceback
import warnings

SUPPORT_SHA = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK_SHA = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
SOURCE_REF = '31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457'
SOURCE_PINS = {
    'tools/autograd/derivatives.yaml': '4a4d1ae1ddea605f57594de991da2c92e89ae11d6aa6edf348107589b548082c',
    'torch/csrc/autograd/FunctionsManual.cpp': 'a8603d6309822a3f93fa4fcb5ada05e2f0f7e29a1b96db64fe6f59ce0c730558',
    'torch/csrc/autograd/variable.cpp': 'ca2f1e573307069dee2fdff70ba81f161f48817cd278ad5464b9809cf23ab2c6',
    'torch/csrc/autograd/variable.h': '94dbc890e0fac8dcde6dc3556bcafbdfffa5f8bce09d83e0169fed3ddbfbe5cd',
    'tools/autograd/gen_variable_type.py': '66bb855965a3829800523189eb137b15b3470d75fbffbb48b286cf7e37e78982',
    'tools/autograd/gen_inplace_or_view_type.py': '76686bbebaa7ea3d5b7c6406bca51b81181b11878395fbb9442e671e108fd7e2',
}
CHECKS = {
    'python_matches', 'platform_matches', 'version_backend_matches',
    'git_matches_oracle_build_pin', 'distribution_version_matches',
    'direct_url_matches', 'direct_url_archive_sha256_matches',
    'pip_report_url_matches', 'pip_report_archive_sha256_matches',
    'pip_report_version_matches', 'pip_report_requested',
}
SEED_VALUES = (1., -2., 3., -4., .5, -.25, 2., -1., .25, -.5, 4., -3.)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def plan():
    direct = (
        ('leaf_transpose', 'matrix', [3, 2], [1, 3], 0),
        ('leaf_offset_holes', 'flat12', [2, 2], [4, 2], 1),
        ('leaf_zero_stride', 'flat4', [3, 2], [0, 1], 1),
        ('leaf_nonzero_overlap', 'flat4', [2, 3], [1, 1], 0),
        ('empty_output_nonempty_leaf', 'flat6', [2, 0, 3], [17, 101, 2], 7),
        ('empty_offset_nonview_leaf', 'empty_offset', [0, 3], [29, 2], 11),
        ('dense_transpose_nonview_leaf', 'transpose_clone', [2, 3], [3, 1], 0),
    )
    result = []
    for name, base, size, stride, offset in direct:
        result.append({'index': len(result), 'name': name, 'family': 'direct_geometry',
                       'base_recipe': base, 'base_requires_grad': True,
                       'view_size': size, 'view_stride': stride, 'view_storage_offset': offset,
                       'backward_schedule': ['retain_graph=True', 'retain_graph=False']})
    for name, family in (
        ('nonleaf_direct_then_upstream_retry', 'nonleaf_direct'),
        ('chain_retained_intermediate', 'chain_retained'),
        ('chain_from_own_requires_leaf_view', 'chain_own_leaf'),
        ('chain_from_derived_requires_without_own_flag', 'chain_derived_none'),
        ('captured_chain_then_base_version_refresh', 'chain_refresh'),
        ('saved_version_error_before_view_backward', 'saved_version'),
        ('drop_public_base_and_intermediate_before_backward', 'weak_lifetime'),
    ):
        result.append({'index': len(result), 'name': name, 'family': family,
                       'base_recipe': 'matrix',
                       'base_requires_grad': family not in ('chain_own_leaf', 'chain_derived_none'),
                       'view1_size': [2, 3], 'view1_stride': [3, 1], 'view1_storage_offset': 0,
                       'view2_size': [3, 2], 'view2_stride': [1, 3], 'view2_storage_offset': 0})
    assert len(result) == 14 and len({row['name'] for row in result}) == 14
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ('reference', 'lock', 'repo', 'output'):
        ap.add_argument('--' + name, type=Path, required=True)
    ap.add_argument('--prepare-only', action='store_true')
    args = ap.parse_args()
    assert Path.cwd().resolve() == args.repo.resolve()
    assert not args.output.exists()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    inputs = {p.resolve(): p.read_bytes() for p in (Path(__file__), args.reference, args.lock)}
    assert sha(inputs[args.reference.resolve()]) == SUPPORT_SHA
    assert sha(inputs[args.lock.resolve()]) == LOCK_SHA
    common = {
        'schema': 'heptatorch.differentiable-as-strided-reference14.v1',
        'probe_sha256': sha(inputs[Path(__file__).resolve()]),
        'primary_source_ref': SOURCE_REF, 'primary_source_pins': SOURCE_PINS,
        'case_plan': plan(), 'native_executed': False, 'native_qualified': False,
        'full_pytorch_rewrite_complete': False, 'pytorch_api_denominator': 2590,
        'closed_schema_count': 0,
        'policy': 'OBSERVATION ONLY. Every output, gradient, error, identity, Version and lifetime is recorded from actual pinned Torch.',
        'scope': 'CPU float32, explicit nonnegative as_strided geometry, ordinary grad mode and first-order backward. No arbitrary Python wrapper reference-count equivalence or complete schema qualification is asserted.',
        'getter_order': 'For each live name: raw Tensor/Storage/layout/Version/requires/_base, then grad_fn, is_leaf, retains_grad, grad; Saved attributes and pairwise current gradient-edge relations follow in insertion order. These getters can refresh lazy ViewInfo history.',
        'ownership_scope': 'Only live holds named Tensor roots. Weak references hold StorageWeakRef only. All snapshots and captured events contain primitives/copies; function-local grad_fn, Saved and AccumulateGrad.variable wrappers are released before final weak checks.',
        'seed_values': list(SEED_VALUES),
    }
    if args.prepare_only:
        report = {**common, 'status': 'PREPARED_NOT_RUN', 'torch_executed': False,
                  'cases': 0, 'rows': [], 'inputs_sha256': {str(p): sha(b) for p, b in inputs.items()}}
        args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
        print(json.dumps({'status': report['status'], 'planned_cases': len(plan()), 'probe_sha256': common['probe_sha256']}))
        return 0

    old_argv = sys.argv
    try:
        sys.argv = [str(args.reference), str(args.repo / 'reference-only-no-native-execution'),
                    str(args.output.with_suffix('.provenance.json')), str(args.lock)]
        context = runpy.run_path(str(args.reference), run_name='differentiable_as_strided_provenance_only')
    finally:
        sys.argv = old_argv
    torch, provenance = context['torch'], context['PROVENANCE']
    assert provenance['status'] == 'PASS' and set(provenance['checks']) == CHECKS
    assert all(value is True for value in provenance['checks'].values())
    assert torch.are_deterministic_algorithms_enabled()
    assert torch.utils.deterministic.fill_uninitialized_memory is True
    assert torch.get_num_threads() == 1
    assert torch.backends.cpu.get_cpu_capability() == 'AVX512'
    from torch.multiprocessing.reductions import StorageWeakRef
    states, rows, errors = {}, [], []

    def environment():
        return {'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
                'deterministic_fill': torch.utils.deterministic.fill_uninitialized_memory,
                'grad_enabled': torch.is_grad_enabled(), 'num_threads': torch.get_num_threads(),
                'cpu_capability': torch.backends.cpu.get_cpu_capability()}

    environment_before = environment()
    outer_rng = bytes(torch.get_rng_state().tolist())

    def rng():
        raw = bytes(torch.get_rng_state().tolist())
        assert len(raw) == 5056
        key = sha(raw)
        states.setdefault(key, {'bytes': len(raw), 'hex': raw.hex()})
        return key

    def capture(operation):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            try:
                value = operation()
                event = {'accepted': True, 'outcome': 'SUCCEEDED', 'error': None}
            except Exception as error:
                value = None
                event = {'accepted': False, 'outcome': 'RAISED',
                         'error': {'type': type(error).__name__, 'message': str(error)}}
        event['warnings'] = [{'type': type(w.message).__name__, 'message': str(w.message)} for w in caught]
        return value, event

    def raw_tensor(x):
        if x is None:
            return None
        storage = x.untyped_storage()
        raw = bytes(storage)
        width = x.element_size()
        shape, strides, offset = list(x.shape), list(x.stride()), x.storage_offset()
        logical = bytearray()
        for linear in range(x.numel()):
            quotient, at = linear, offset
            for size, stride in zip(reversed(shape), reversed(strides)):
                at += (quotient % size) * stride
                quotient //= size
            word = raw[at * width:at * width + width]
            assert len(word) == width
            logical.extend(word)
        base = x._base
        result = {'tensor_identity': str(x._cdata), 'storage_identity': str(storage._cdata),
                  'dtype': str(x.dtype), 'element_size': width, 'shape': shape, 'strides': strides,
                  'numel': x.numel(), 'storage_bytes': len(raw),
                  'storage_offset_elements': offset, 'storage_offset_bytes': offset * width,
                  'storage_raw_hex': raw.hex(), 'logical_bytes_hex': bytes(logical).hex(),
                  'binary_words': [int.from_bytes(logical[i:i + width], 'little') for i in range(0, len(logical), width)],
                  'version': x._version, 'requires_grad': x.requires_grad, 'is_view': x._is_view(),
                  'base_tensor_identity': None if base is None else str(base._cdata)}
        del base, storage
        return result

    def primitive(value):
        if isinstance(value, torch.Tensor):
            return {'tensor': raw_tensor(value)}
        if value is None or isinstance(value, (bool, int, str)):
            return value
        if isinstance(value, float):
            return {'double_bits': struct.unpack('<Q', struct.pack('<d', value))[0]}
        if isinstance(value, (tuple, list)):
            return [primitive(item) for item in value]
        return {'type': type(value).__name__, 'diagnostic_repr': repr(value)}

    def node_info(fn, depth=4):
        if fn is None:
            return None
        result = {'kind': type(fn).__name__}
        if type(fn).__name__ == 'AccumulateGrad':
            variable = fn.variable
            result['variable'] = raw_tensor(variable)
            del variable
        if depth:
            result['next_edges'] = [{'output_nr': int(nr), 'node': node_info(child, depth - 1)}
                                    for child, nr in fn.next_functions]
        return result

    def saved_attributes(fn):
        if fn is None:
            return {}
        attributes = {}
        for name in sorted(n for n in dir(fn) if n.startswith('_saved_')):
            value, event = capture(lambda name=name: getattr(fn, name))
            if event['accepted']:
                event['value'] = primitive(value)
            del value
            attributes[name] = event
        return attributes

    def tensor_observation(x, weak):
        before = raw_tensor(x)
        fn, getter = capture(lambda: x.grad_fn)
        if getter['accepted']:
            getter['node'] = node_info(fn)
        del fn
        leaf, leaf_event = capture(lambda: x.is_leaf)
        if leaf_event['accepted']:
            leaf_event['value'] = bool(leaf)
        del leaf
        retained, retained_event = capture(lambda: x.retains_grad)
        if retained_event['accepted']:
            retained_event['value'] = bool(retained)
        del retained
        grad, grad_event = capture(lambda: x.grad)
        if grad_event['accepted']:
            grad_event['tensor'] = raw_tensor(grad)
            if grad is not None:
                key = 'observed_grad_storage_' + str(grad.untyped_storage()._cdata)
                if key not in weak:
                    weak[key] = StorageWeakRef(grad.untyped_storage())
        del grad
        return {'before_grad_fn_getter': before, 'grad_fn_getter': getter,
                'requires_grad_after_grad_fn_getter': x.requires_grad,
                'is_leaf_after_grad_fn_getter': leaf_event, 'retains_grad': retained_event,
                'gradient': grad_event}

    def snapshot(live, weak):
        names = list(live)
        tensors = {name: tensor_observation(live[name], weak) for name in names}
        relations = {}
        for left_name, right_name in itertools.combinations(names, 2):
            left, right = live[left_name], live[right_name]
            relations[left_name + '|' + right_name] = {
                'same_Python_object': left is right, 'same_Tensor': left._cdata == right._cdata,
                'same_Storage': left.untyped_storage()._cdata == right.untyped_storage()._cdata,
                'same_current_Version_value': left._version == right._version}
        if len(names) > 1:
            del left, right
        current, getters, saved, edges = {}, {}, {}, {}
        for name in names:
            fn, event = capture(lambda name=name: live[name].grad_fn)
            getters[name] = event
            if event['accepted']:
                current[name] = fn
            del fn
        for name, fn in current.items():
            saved[name] = saved_attributes(fn)
            edge_rows = []
            if fn is not None:
                for child, nr in fn.next_functions:
                    edge_rows.append({'output_nr': int(nr), 'node': node_info(child),
                                      'matches_live_current_grad_fn': [other for other, candidate in current.items()
                                                                     if child is not None and child is candidate]})
                    del child
            edges[name] = edge_rows
        # No Function or Tensor wrapper is returned or added to a persistent cache.
        if current:
            del fn
        current.clear()
        return {'tensor_getter_order': names, 'tensors': tensors, 'relations': relations,
                'saved_getters_after_tensor_getters': saved, 'edge_getters': getters,
                'edges_after_all_tensor_getters': edges,
                'expired': {name: ref.expired() for name, ref in weak.items()}, 'state': rng()}

    def make_base(kind):
        if kind == 'matrix':
            return torch.tensor([[1., 2., 3.], [4., 5., 6.]], dtype=torch.float32)
        if kind.startswith('flat'):
            return torch.tensor([float(i + 1) for i in range(int(kind[4:]))], dtype=torch.float32)
        if kind == 'empty_offset':
            return torch.empty(0, dtype=torch.float32).as_strided((2, 0, 3), (17, 101, 2), 7).detach()
        if kind == 'transpose_clone':
            return torch.tensor([[1., 2., 3.], [4., 5., 6.]], dtype=torch.float32).t().clone(memory_format=torch.preserve_format)
        raise AssertionError(kind)

    def make_seed(shape):
        if any(size == 0 for size in shape):
            return torch.empty(tuple(shape), dtype=torch.float32)
        counter = [0]
        def nested(dims):
            if not dims:
                value = SEED_VALUES[counter[0] % len(SEED_VALUES)]
                counter[0] += 1
                return value
            return [nested(dims[1:]) for _ in range(dims[0])]
        return torch.tensor(nested(list(shape)), dtype=torch.float32)

    def observe(spec):
        torch.manual_seed(1729)
        live, weak, events = {}, {}, []
        row = {**spec, 'state_before_setup': rng(), 'events': events}

        def event(label, operation, publish=None):
            before = snapshot(live, weak)
            value, result = capture(operation)
            result.update(label=label, before=before)
            if result['accepted']:
                result['returned'] = primitive(value)
                if isinstance(value, torch.Tensor):
                    result['returned_is_existing'] = {name: value is item for name, item in live.items()}
                if publish is not None:
                    assert isinstance(value, torch.Tensor), (label, type(value).__name__)
                    live[publish] = value
                    weak[publish + '_storage'] = StorageWeakRef(value.untyped_storage())
            del value
            result['after'] = snapshot(live, weak)
            events.append(result)
            return result['accepted']

        def drop(name):
            del live[name]
            gc.collect()

        def clear_grad(name):
            live[name].grad = None

        def mutate_base():
            with torch.no_grad():
                live['base'].add_(1.)

        def new_view(source, target, size, stride, offset):
            return event('as_strided_' + target,
                         lambda: torch.as_strided(live[source], tuple(size), tuple(stride), offset), publish=target)

        def retain(name):
            return event('retain_grad_' + name, lambda: live[name].retain_grad())

        def backward(name, retain_graph, suffix):
            return event('backward_' + suffix,
                         lambda: live[name].backward(live['seed'], retain_graph=retain_graph))

        def finish():
            row['before_final_drops'] = snapshot(live, weak)
            for name in list(live):
                event('final_drop_' + name, lambda name=name: drop(name))
            assert not live
            gc.collect()
            row.update(status='OBSERVED', final_expired={name: ref.expired() for name, ref in weak.items()},
                       state_after=rng())
            return row

        if not event('construct_base', lambda: make_base(spec['base_recipe']), publish='base'):
            row['remaining_not_attempted'] = 'base constructor raised'
            return finish()
        if spec['base_requires_grad']:
            if not event('base_requires_grad_true', lambda: live['base'].requires_grad_(True)):
                row['remaining_not_attempted'] = 'requires_grad request raised'
                return finish()
        family = spec['family']
        if family == 'direct_geometry':
            if not new_view('base', 'view', spec['view_size'], spec['view_stride'], spec['view_storage_offset']):
                return finish()
            retain('view')
            event('construct_seed', lambda: make_seed(live['view'].shape), publish='seed')
            backward('view', True, 'first_retained')
            if live['view'].grad is not None:
                event('hold_first_view_gradient', lambda: live['view'].grad, publish='held_view_grad')
            backward('view', False, 'second_default')
            return finish()

        if family == 'nonleaf_direct':
            if not event('construct_factor', lambda: torch.tensor(2., dtype=torch.float32), publish='factor'):
                return finish()
            if not event('mul_base_factor', lambda: torch.mul(live['base'], live['factor']), publish='middle'):
                return finish()
            retain('middle')
            if not new_view('middle', 'view', [3, 2], [1, 3], 0):
                return finish()
            retain('view')
            event('construct_seed', lambda: make_seed(live['view'].shape), publish='seed')
            backward('view', False, 'first_default')
            for name in ('middle', 'view'):
                if live[name].grad is not None:
                    event('hold_first_' + name + '_gradient', lambda name=name: live[name].grad,
                          publish='held_' + name + '_grad')
            backward('view', False, 'retry_after_upstream_default')
            return finish()

        if family == 'saved_version':
            if not new_view('base', 'view', [3, 2], [1, 3], 0):
                return finish()
            retain('view')
            if not event('mul_view_by_same_view', lambda: torch.mul(live['view'], live['view']), publish='root'):
                return finish()
            event('construct_seed', lambda: make_seed(live['root'].shape), publish='seed')
            event('base_add_scalar_one_no_grad', mutate_base)
            backward('root', False, 'after_saved_version_change')
            return finish()

        if not new_view('base', 'view1', spec['view1_size'], spec['view1_stride'], spec['view1_storage_offset']):
            return finish()
        if family == 'chain_own_leaf':
            event('view1_own_requires_grad_true', lambda: live['view1'].requires_grad_(True))
        elif family == 'chain_derived_none':
            event('base_requires_grad_true_at_version_zero', lambda: live['base'].requires_grad_(True))
        if not new_view('view1', 'view2', spec['view2_size'], spec['view2_stride'], spec['view2_storage_offset']):
            return finish()
        retain('view1')
        retain('view2')
        event('construct_seed', lambda: make_seed(live['view2'].shape), publish='seed')
        if family in ('chain_retained', 'chain_own_leaf', 'chain_derived_none'):
            backward('view2', True, 'first_retained')
            for name in ('view1', 'view2'):
                if live[name].grad is not None:
                    event('hold_first_' + name + '_gradient', lambda name=name: live[name].grad,
                          publish='held_' + name + '_grad')
            backward('view2', False, 'second_default')
            return finish()

        if not event('to_copy_before_mutation_or_drop',
                     lambda: torch.ops.aten._to_copy(live['view2'], dtype=torch.float32,
                                                     memory_format=torch.preserve_format), publish='old_copy'):
            return finish()
        if family == 'chain_refresh':
            backward('old_copy', True, 'old_copy_first_retained')
            for name in ('view1', 'view2'):
                if live[name].grad is not None:
                    event('hold_first_' + name + '_gradient', lambda name=name: live[name].grad,
                          publish='held_' + name + '_grad')
            for name in ('base', 'view1', 'view2'):
                event('clear_before_refresh_' + name, lambda name=name: clear_grad(name))
            event('base_add_scalar_one_no_grad', mutate_base)
            if not event('to_copy_after_getters_refreshed_history',
                         lambda: torch.ops.aten._to_copy(live['view2'], dtype=torch.float32,
                                                         memory_format=torch.preserve_format), publish='new_copy'):
                return finish()
            backward('old_copy', False, 'old_captured_chain_after_refresh')
            for name in ('base', 'view1', 'view2'):
                event('clear_before_new_copy_' + name, lambda name=name: clear_grad(name))
            backward('new_copy', False, 'new_current_chain_after_refresh')
            return finish()
        if family == 'weak_lifetime':
            event('drop_public_base_before_backward', lambda: drop('base'))
            event('drop_public_intermediate_before_backward', lambda: drop('view1'))
            backward('old_copy', False, 'with_only_final_view_and_copy_public')
            if live['view2'].grad is not None:
                event('hold_final_view_gradient', lambda: live['view2'].grad, publish='held_view_grad')
            event('drop_copy_after_default_backward', lambda: drop('old_copy'))
            event('drop_last_public_view', lambda: drop('view2'))
            return finish()
        raise AssertionError(family)

    with torch.random.fork_rng(devices=[]):
        for spec in plan():
            try:
                rows.append(observe(spec))
            except BaseException as error:
                failure = {**spec, 'status': 'PROBE_ERROR', 'error': repr(error),
                           'traceback': traceback.format_exc()}
                errors.append(failure)
                rows.append(failure)
    environment_after = environment()
    assert environment_before == environment_after
    assert bytes(torch.get_rng_state().tolist()) == outer_rng
    assert all(path.read_bytes() == raw for path, raw in inputs.items())
    totals = {'attempted': 0, 'succeeded': 0, 'raised': 0}
    for row in rows:
        for event in row.get('events', []):
            totals['attempted'] += 1
            totals['succeeded' if event['accepted'] else 'raised'] += 1
    report = {**common, 'status': 'OBSERVED' if not errors else 'PROBE_ERROR', 'torch_executed': True,
              'oracle_provenance': provenance, 'build_configuration': torch.__config__.show(),
              'cpu_capability': torch.backends.cpu.get_cpu_capability(), 'num_threads': torch.get_num_threads(),
              'environment_before': environment_before, 'environment_after': environment_after,
              'environment_restored': True, 'original_outer_rng_restored': True,
              'source_files_unchanged': True, 'inputs_sha256': {str(p): sha(b) for p, b in inputs.items()},
              'cases': len(rows), 'rows': rows, 'states': states, 'unique_complete_states': len(states),
              'probe_errors': errors, 'probe_error_count': len(errors), 'operation_totals': totals}
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({key: report[key] for key in ('status', 'cases', 'probe_sha256', 'operation_totals', 'probe_error_count')}))
    return int(bool(errors))


if __name__ == '__main__':
    raise SystemExit(main())
