"""Actual new dispatcher controls. No reference-value or response synthesis."""
from pathlib import Path
import gzip
import select
import struct
import subprocess
import time

from admission import need,sha
from observe import Audit,save,require_children

PRODUCTION_PLAN=[
    'cg-owner-rejects-tensor', 'cg-owner-rejects-unknown-request',
    'tensor-owner-rejects-cg-create', 'tensor-owner-rejects-cg-system-seed',
    'empty-unknown-request-then-cg', 'empty-cg-stats-then-tensor',
]


def tensor_packet(commands):
    records=b''.join(struct.pack('<8Q',*c,*([0]*(8-len(c)))) for c in commands)
    return b'HTORCH03'+struct.pack('<3Q',len(commands),32+len(records),0)+records


def tensor_reply(raw,status=0):
    need(len(raw)>=32 and raw[:8]==b'HTORSP03','real Tensor response family')
    version,count,error=struct.unpack_from('<3Q',raw,8)
    need(version==3 and error==status,'real Tensor response error/version')
    if status:
        need(count==0 and len(raw)==32,'real terminal Tensor refusal');return []
    rows=[];at=32
    for _ in range(count):
        need(at+32<=len(raw),'real Tensor record header')
        op,error,value,size=struct.unpack_from('<4Q',raw,at);at+=32
        need(error==0 and at+size<=len(raw),'real Tensor record span')
        rows.append((op,value,raw[at:at+size]));at+=size
    need(at==len(raw),'real Tensor reply trailing bytes');return rows


def cg_reply(raw,status=0):
    need(len(raw)>=64 and raw[:8]==b'HTCGRS01','real CG response family')
    code,size,live,allocation,last,epoch,reserved=struct.unpack_from('<7Q',raw,8)
    need(code==status and reserved==0 and size==len(raw)-64,'real CG status/payload')
    if status:need(size==0,'real terminal CG refusal')
    return raw[64:]


class Neutral:
    def __init__(self,image,audit):
        self.audit=audit
        def start():
            self.process=subprocess.Popen([str(image)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                                          stderr=subprocess.PIPE,env={'PATH':''})
        audit.adopt(self,image,start)
    def exact(self,count):
        data=bytearray();deadline=time.monotonic()+30
        while len(data)<count:
            remain=deadline-time.monotonic()
            need(remain>0 and select.select([self.process.stdout],[],[],max(0,remain))[0],
                 'new control real response deadline')
            block=self.audit.read(self.process.stdout.fileno(),count-len(data))
            need(block,'new control premature native EOF');data.extend(block)
        return bytes(data)
    def raw(self,body):
        def exchange():
            self.process.stdin.write(b'HTOWNR01'+struct.pack('<Q',len(body))+body)
            self.process.stdin.flush()
            header=self.exact(16)
            need(header[:8]==b'HTOWNS01','new control real outer reply')
            count=struct.unpack_from('<Q',header,8)[0]
            need(0<=count<=1<<20,'new control native response bound')
            return self.exact(count)
        return self.audit.frame(self,body,exchange)
    def close(self):
        def finish():
            self.process.stdin.close();self.process.stdin=None
            out,err=self.process.communicate(timeout=30)
            need(self.process.returncode==0 and not out and not err,'new control final exit/EOF')
        return self.audit.closing(self,False,finish)


def run(output,image,image_sha,packet,tensor_owner,entry_tool_audit):
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    audit=Audit(output/'native',image,{str(image):image_sha},tensor_owner=tensor_owner,plan=PRODUCTION_PLAN)
    rows=[];cg_pool=tensor_pool=None
    def owner_bytes(session):
        row=session.audit_child['frames'][-1]['owner_after']['raw']
        value=gzip.decompress((audit.output/row['path']).read_bytes())
        need(len(value)==row['bytes'] and sha(value)==row['sha256'],'actual control owner snapshot identity')
        return value
    make=tensor_packet([(38,1,0,1,0,0,0,0x3f800000)])
    def create_tensor(s):
        result=tensor_reply(s.raw(make));need(len(result)==1 and result[0][0]==38,'actual Tensor construction')
        handle=result[0][1];need(handle>>32>0,'actual typed Tensor identity')
        return handle
    def tensor_value(s,handle):
        result=tensor_reply(s.raw(tensor_packet([(39,handle,0,1)])))
        need(result==[(39,1,struct.pack('<I',0x3f800000))],'real Tensor survives protocol refusal')
    try:
        for name in PRODUCTION_PLAN:
            s=Neutral(image,audit)
            if name.startswith('cg-owner'):
                created=cg_reply(s.raw(packet('create',count=1,a=5489)))
                need(len(created)==8,'real Generator construction handle')
                handle=struct.unpack('<Q',created)[0]
                cg_pool=owner_bytes(s)
                bad=make if name=='cg-owner-rejects-tensor' else b'UNKNOWN!'
                cg_reply(s.raw(bad),1)
                need(cg_reply(s.raw(packet('current_seed',handle)))==struct.pack('<Q',5489),
                     'real Generator survives protocol refusal')
            elif name.startswith('tensor-owner'):
                handle=create_tensor(s);tensor_pool=owner_bytes(s)
                bad=packet('create',count=1,a=9) if name.endswith('cg-create') else packet('seed',1)
                tensor_reply(s.raw(bad),100)
                tensor_value(s,handle)
            elif name=='empty-unknown-request-then-cg':
                tensor_reply(s.raw(b'UNKNOWN!'),100)
                need(owner_bytes(s)==b'','unknown request must retain empty native owner')
                result=cg_reply(s.raw(packet('create',count=1,a=17)))
                handle=struct.unpack('<Q',result)[0]
                need(cg_reply(s.raw(packet('current_seed',handle)))==struct.pack('<Q',17),'empty owner family selection')
            else:
                need(name=='empty-cg-stats-then-tensor','fixed new control plan')
                need(cg_reply(s.raw(packet('stats')))==b'' and owner_bytes(s)==b'',
                     'empty CG readonly request must not allocate a family owner')
                handle=create_tensor(s);tensor_value(s,handle)
            s.close();rows.append({'case':name,'status':'PASS','real_production_native':True})
        children=audit.reports();require_children(children,image_sha)
        need([c['case'] for c in children]==PRODUCTION_PLAN,'all six ordered new production controls')
        need(cg_pool is not None and tensor_pool is not None,'actual observed source pools required')
        (output/'actual-generator-pool.bin').write_bytes(cg_pool)
        (output/'actual-tensor-pool.bin').write_bytes(tensor_pool)
        need(len(cg_pool)==64+5088 and len(tensor_pool)+88<=1<<20,'actual probe pool budget')
        stats=packet('stats');tempty=tensor_packet([])
        scenarios=[]
        for size in (1,7,8,63):
            scenarios.append((f'short-{size}-cg',bytes(size),stats,64,b'',b'HTCGRS01',10,64))
            scenarios.append((f'short-{size}-tensor',bytes(size),tempty,32,b'',b'HTORSP03',7,32))
        unknown=b'UNKNOWN!'+bytes(56)
        scenarios += [('unknown64-cg',unknown,stats,64,b'',b'HTCGRS01',10,64),
                      ('unknown64-tensor',unknown,tempty,32,b'',b'HTORSP03',7,32),
                      ('known-short-cg',b'HTCGST01',stats,64,b'',b'HTCGRS01',10,64),
                      ('known-short-cg-wrong-request',b'HTCGST01',tempty,64,b'',b'HTCGRS01',1,64)]
        for label,offset in [('core',64),('backing',139264)]:
            bad=bytearray(tensor_pool);bad[offset]^=1;bad=bytes(bad)
            scenarios.append((f'tensor-bad-{label}-cg',bad,stats,64,b'',b'HTCGRS01',10,64))
            scenarios.append((f'tensor-bad-{label}-tensor',bad,tempty,32,b'',b'HTORSP03',7,32))
        scenarios += [('known-cg-wrong-tensor',cg_pool,tempty,64,b'',b'HTCGRS01',1,64),
                      ('known-tensor-wrong-cg',tensor_pool,stats,64,b'',b'HTORSP03',100,32),
                      ('known-tensor-wrong-cg-seed',tensor_pool,packet('seed',1),64,b'12345678',b'HTORSP03',100,32)]
        for capacity in (0,1,31,32,63):
            scenarios.append((f'unknown-cg-output-{capacity}',unknown,stats,capacity,b'',None,None,0))
        for capacity in (0,1,31):
            scenarios.append((f'unknown-tensor-output-{capacity}',unknown,tempty,capacity,b'',None,None,0))
        scenarios += [('known-tensor-output31',tensor_pool,packet('seed',1),31,b'12345678',None,None,0),
                      ('known-cg-output63',cg_pool,tempty,63,b'',None,None,0),
                      ('empty-cg-stats',b'',stats,64,b'',b'HTCGRS01',0,64),
                      ('empty-unknown-tensor-error',b'',b'UNKNOWN!',32,b'',b'HTORSP03',100,32)]
        need(len(scenarios)==31 and len({r[0] for r in scenarios})==31,'complete31 new ABI boundary controls')
        probe=entry_tool_audit.entry_output/'step-probe'
        need(entry_tool_audit.probe_image is not None and sha(probe.read_bytes())==entry_tool_audit.probe_image,
             'actual probe must be the original entry59 probe linked with all15 new objects')
        first_process=len(entry_tool_audit.rows)
        for name,state,body,capacity,entropy,magic,status,expected_length in scenarios:
            request=struct.pack('<4Q',len(state),len(body),capacity,len(entropy))+state+body+entropy
            process=entry_tool_audit.run([str(probe)],input=request,capture_output=True,env={'PATH':''},timeout=30)
            need(process.returncode==0 and not process.stderr,'real new ABI control process must finish')
            response=process.stdout
            need(len(response)>=24,'real new ABI probe output header')
            length,state_bytes,actual_capacity=struct.unpack_from('<3Q',response)
            need(actual_capacity==capacity and state_bytes==len(state) and len(response)==24+capacity+state_bytes,
                 'actual ABI output/owner dimensions')
            actual=response[24:24+capacity];after=response[24+capacity:]
            need(after==state and length==expected_length,'actual invalid/wrong-family owner retained byte-for-byte')
            if magic is None:
                need(actual==bytes(capacity),'short output must remain untouched')
            elif magic==b'HTCGRS01':
                need(cg_reply(actual[:length],status)==b'','real new ABI CG refusal or empty stats')
                need(actual[length:]==bytes(capacity-length),'new ABI CG trailing output untouched')
            else:
                need(tensor_reply(actual[:length],status)==[],'real new ABI Tensor refusal')
                need(actual[length:]==bytes(capacity-length),'new ABI Tensor trailing output untouched')
            rows.append({'case':name,'status':'PASS','qualification_owned_step_probe':True,
                         'caller_created_owner_only_in_qualification':True,
                         'request_sha256':sha(request),'response_sha256':sha(response),
                         'original_owner_sha256':sha(state),'returned_owner_sha256':sha(after),
                         'actual_returned_length':length,'actual_capacity':capacity,
                         'actual_status':status,'entire_actual_owner_retained':True})
        entry_tool_audit.require_complete()
        need(len(rows)==37 and all(r['status']=='PASS' for r in rows),'all37 new dispatcher controls required')
        report={'schema':'heptatorch.generator712-dispatch-controls.v1','status':'PASS','cases':rows,
                'case_count':37,'production_cases':6,'qualification_abi_cases':31,
                'native_children':children,'probe_processes':list(entry_tool_audit.rows[first_process:]),
                'actual_probe_sha256':entry_tool_audit.probe_image,'actual_image_sha256':image_sha,
                'production_accepts_foreign_owners_or_entropy_pointers':False,
                'os_entropy_consumption_before_application_validation_prohibited':False,
                'raw_entropy_cleared_between_every_observed_frame':True}
        save(output/'report.json',report);return report
    finally:
        audit.cleanup();children=audit.reports()
        save(output/'native-observations.json',children)
