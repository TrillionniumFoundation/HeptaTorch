#!/usr/bin/env python3
"""Pure, explicit correction of five new dispatcher expectations; no execution."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import re
import shutil
import stat

PREVIOUS_MANIFEST = '8bf7ed228319dc424f8188bdf476415ef3c046de60e63820e4ca6d5e949d855b'
PREVIOUS_CONTROLS = '3cbe9798c5c37a7c2dbc41598ae4199a550467600300a6dc87f351c61e266b1a'
BASELINE = '82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313'
CURRENT = 'fac3d413c6c0f6874d224cbea312108ee2c8baa027102d41890d85094a5faa38'
EDITS = [
    ("tensor_reply(s.raw(bad),1)", "tensor_reply(s.raw(bad),100)",
     ['tensor-owner-rejects-cg-create', 'tensor-owner-rejects-cg-system-seed']),
    ("tensor_reply(s.raw(b'UNKNOWN!'),1)", "tensor_reply(s.raw(b'UNKNOWN!'),100)",
     ['empty-unknown-request-then-cg']),
    ("('known-tensor-wrong-cg',tensor_pool,stats,64,b'',b'HTORSP03',1,32)",
     "('known-tensor-wrong-cg',tensor_pool,stats,64,b'',b'HTORSP03',100,32)",
     ['known-tensor-wrong-cg']),
    ("('known-tensor-wrong-cg-seed',tensor_pool,packet('seed',1),64,b'12345678',b'HTORSP03',1,32)",
     "('known-tensor-wrong-cg-seed',tensor_pool,packet('seed',1),64,b'12345678',b'HTORSP03',100,32)",
     ['known-tensor-wrong-cg-seed']),
    ("('empty-unknown-tensor-error',b'',b'UNKNOWN!',32,b'',b'HTORSP03',1,32)",
     "('empty-unknown-tensor-error',b'',b'UNKNOWN!',32,b'',b'HTORSP03',100,32)",
     ['empty-unknown-tensor-error']),
]


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def record(path):
    need(path.is_file() and not path.is_symlink(), 'regular file required: '+str(path))
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw), 'mode': stat.S_IMODE(path.stat().st_mode)}


def function(raw, name):
    found = re.findall(rb'^fn '+name.encode()+rb'\([^\n]*\n.*?^end\n', raw, re.M | re.S)
    need(len(found) == 1, 'one complete HIA definition required: '+name)
    return found[0]


def ast_deltas(old, new, at='root'):
    need(type(old) is type(new), 'AST node types changed: '+at)
    result = []
    if isinstance(old, ast.AST):
        for name in old._fields:
            result += ast_deltas(getattr(old, name), getattr(new, name), at+'.'+name)
    elif isinstance(old, list):
        need(len(old) == len(new), 'AST lengths changed: '+at)
        for i, (left, right) in enumerate(zip(old, new)):
            result += ast_deltas(left, right, at+f'[{i}]')
    elif old != new:
        result.append({'path': at, 'before': old, 'after': new})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--previous-package', type=Path, required=True)
    parser.add_argument('--baseline-source', type=Path, required=True)
    parser.add_argument('--current-source', type=Path, required=True)
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    previous = args.previous_package.resolve(strict=True)
    output = args.output.resolve()
    need(not output.exists(), 'fresh output required')
    previous_manifest = (previous/'package-manifest.json').read_bytes()
    need(sha(previous_manifest) == PREVIOUS_MANIFEST, 'fixed source02 manifest required')
    manifest = json.loads(previous_manifest)
    files = manifest['files']
    actual_paths = {str(p.relative_to(previous)) for p in previous.rglob('*') if p.is_file()}
    need(actual_paths == set(files) | {'package-manifest.json'}, 'entire source02 package required')
    snapshots = {name: (previous/name).read_bytes() for name in files}
    for name, row in files.items():
        need(record(previous/name) == row, 'source02 payload changed: '+name)
    baseline = args.baseline_source.read_bytes()
    current = args.current_source.read_bytes()
    need(sha(baseline) == BASELINE and sha(current) == CURRENT, 'fixed complete HIA sources required')
    functions = {}
    for name in ('frame_valid', 'reply_error'):
        before, after = function(baseline, name), function(current, name)
        need(before == after, 'original Tensor envelope function changed: '+name)
        functions[name] = {'bytes': len(after), 'sha256': sha(after),
                           'entire_definition_byte_identical_701_to_712': True,
                           'hia_source': after.decode()}
    need(functions['frame_valid']['hia_source'].count('{"value":100}') == 3,
         'three original malformed-envelope error sites required')
    evidence = {}
    for rel in ('docs/protocol.md', 'tools/tensor_objects/PROTOCOL.md',
                'tools/gradient_objects/authoring/public/baseline-authoring/objects.py',
                'tools/gradient_objects/test_state_handoff.py',
                'tools/backward_release/test_state_handoff.py'):
        path = args.repository/rel
        evidence[rel] = record(path)
    doc = (args.repository/'docs/protocol.md').read_text()
    need('command responses and final status 100.' in doc, 'original documented envelope status100')
    old_authoring = (args.repository/'tools/gradient_objects/authoring/public/baseline-authoring/objects.py').read_text()
    source_tree = ast.parse(old_authoring)
    for name in ('frame_valid', 'reply_error'):
        nodes = [n for n in source_tree.body if isinstance(n, ast.FunctionDef) and n.name == name]
        need(len(nodes) == 1, 'original HTORCH03 authoring definition')
        functions[name]['historical_authoring'] = ast.get_source_segment(old_authoring, nodes[0])
    need(functions['frame_valid']['historical_authoring'].count('return 100') == 3
         and str(int.from_bytes(b'HTORCH03', 'little')) in functions['frame_valid']['historical_authoring'],
         'historical version3 envelope status100, not a new target-derived expectation')
    for rel, assertion in (
        ('tools/gradient_objects/test_state_handoff.py', 'assert status == 100 and records == [] and s.owner() == empty'),
        ('tools/backward_release/test_state_handoff.py', 'assert status==100 and session.owner()==empty_before')):
        need(assertion in (args.repository/rel).read_text(), 'independent old malformed-envelope assertion')
        evidence[rel]['original_assertion'] = assertion

    old = snapshots['controls.py']
    need(sha(old) == PREVIOUS_CONTROLS, 'fixed source02 controls required')
    new = old
    for before, after, cases in EDITS:
        need(new.count(before.encode()) == 1 and after.encode() not in new, 'unique correction site')
        new = new.replace(before.encode(), after.encode())
    inverse = new
    for before, after, cases in reversed(EDITS):
        need(inverse.count(after.encode()) == 1, 'unique correction inverse site')
        inverse = inverse.replace(after.encode(), before.encode())
    need(inverse == old and len(new) == len(old)+10, 'complete source02 controls inverse required')
    deltas = ast_deltas(ast.parse(old), ast.parse(new))
    need(len(deltas) == 5 and all(d['before'] == 1 and d['after'] == 100
                                and d['path'].endswith('.value') for d in deltas),
         'only five integer constant AST leaves may change')

    shutil.copytree(previous, output)
    (output/'controls.py').write_bytes(new)
    explanation = '''
## Source03 correction after the preserved first actual failure

The first source02 run remains FAIL. Its fixed report is 12,790,903 bytes,
SHA `e71e66591a4e0535b8ac6d68da994f7af113ac8b69a788317444bc7c1e52b6df`,
from job `1a1ee2451e6-ffbe-d`. Original24, native11 and entry59 each passed;
the new dispatcher group stopped in its third production trajectory. None of
those results is transferred to a new complete131 PASS.

The new controls had confused CG malformed-input status1 with the existing
Tensor malformed-envelope status100. Source03 changes exactly five integer
constants, covering six new cases: Tensor-owner CG-create/CG-seed production
requests, the empty unknown production request, and the matching three ABI
cases. The fixed original version3 authoring and old state-handoff assertions
independently specify100. The complete `frame_valid` and `reply_error` HIA
definitions are byte-identical in the fixed701 and712 sources. The root read
the first failure's real HTORSP03 response: version3, count0, status100; its
physical owner pointer, length and entire contents were unchanged.

`controls-correction.json` records the independent contract, all five source
edits and a complete reverse transformation to source02. The original94
comparators, requests and reference sources, every owner/EOF predicate, the
Tensor invalid-owner7 and CG1/10 rules, and short-output0 rules are unchanged.
Source03 is SOURCE_ONLY_NOT_EXECUTED until a new actual full131 run succeeds.
The native source, executable, cold build and entropy tool are unchanged.
'''
    (output/'README.md').write_bytes(snapshots['README.md']+explanation.encode())
    author = output/'authoring/correct_tensor_envelope.py'
    author.write_bytes(Path(__file__).read_bytes())
    proof = {
        'schema': 'heptatorch.generator712-new-controls-contract-correction.v1',
        'status': 'SOURCE_ONLY_NOT_EXECUTED',
        'source02_manifest_sha256': PREVIOUS_MANIFEST,
        'source02_controls_sha256': PREVIOUS_CONTROLS,
        'source03_controls_sha256': sha(new),
        'whole_controls_file_inverse_exact': True,
        'ast_deltas': deltas,
        'edits': [{'before': old, 'after': new, 'new_control_cases': cases} for old,new,cases in EDITS],
        'new_control_cases_corrected': 6,
        'original94_modified': False,
        'original94_sources_and_all_other_executable_payloads_byte_identical': True,
        'unaltered_source02_payloads': {name: row for name,row in files.items() if name not in ('controls.py','README.md')},
        'fixed_baseline701_source_sha256': BASELINE,
        'fixed_current712_source_sha256': CURRENT,
        'complete_unchanged_envelope_functions': functions,
        'independent_historical_protocol_inputs': evidence,
        'first_actual_failure_retained': {
            'source': 'root-observed complete actual files; this author does not read or mutate remote results',
            'job': '1a1ee2451e6-ffbe-d',
            'output': '/home/qian-qi/heptatorch-continuation-20261116/runs/root-current701-remote-continuation-01/generator712-generator131-actual-01',
            'report_bytes': 12790903,
            'report_sha256': 'e71e66591a4e0535b8ac6d68da994f7af113ac8b69a788317444bc7c1e52b6df',
            'status': 'FAIL',
            'failed_control': 'tensor-owner-rejects-cg-create',
            'request_bytes': 80,
            'request_sha256': '5bc35b52d6a5f1fe93110e27e773e597c2472fd841990beeb1ef7679b8b0b423',
            'response_bytes': 48,
            'response_sha256': 'd29be3780269cb29912acce7faaf0a945357fc50381ad5702ae99690386946d0',
            'actual_version': 3, 'actual_count': 0, 'actual_status': 100,
            'transport_sha256': '6d07c8977ed35a10d7363670894f0ec1ec1aca6ee03429d82a4b1997fd546d3b',
            'owner_before_after_raw_sha256': 'bd5415b2cd1ef7f4dd1117ae1bcbfa28b243b7b726824200e3c7494077fde661',
        },
        'runtime_source_or_executable_changed': False,
        'native_compiler_linker_Torch_or_worker_executed': False,
        'runtime_PASS_granted': False,
    }
    (output/'controls-correction.json').write_text(json.dumps(proof, indent=2, sort_keys=True)+'\n')
    for name in files:
        need((previous/name).read_bytes() == snapshots[name] and record(previous/name) == files[name],
             'immutable source02 changed: '+name)
        if name not in ('controls.py','README.md'):
            need((output/name).read_bytes() == snapshots[name] and record(output/name) == files[name],
                 'unrelated source03 payload changed: '+name)
    need((previous/'package-manifest.json').read_bytes() == previous_manifest, 'source02 manifest changed')
    rows = {str(path.relative_to(output)): record(path) for path in sorted(output.rglob('*'))
            if path.is_file() and path != output/'package-manifest.json'}
    manifest['files'] = rows
    (output/'package-manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True)+'\n')
    print(json.dumps({'status': 'SOURCE_ONLY_NOT_EXECUTED', 'output': str(output),
                      'controls': record(output/'controls.py'),
                      'correction': record(output/'controls-correction.json'),
                      'manifest': record(output/'package-manifest.json'),
                      'payload_count': len(rows), 'source02_unchanged': True}))


if __name__ == '__main__':
    main()
