#!/usr/bin/env python3
"""Pure source adaptation of the frozen Generator24 / native11 / entry59 gates."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import re
import stat

PINS = {
    'tests/pytorch_cpu_generator_oracle.py': '3b9e1c9058776c67c00c4b07610a2a0d377dda16ca4a956d7e66c442bdfd4157',
    'tools/cpu_generators/qualify.py': '90ba7ba9b6b936592c3b4ca32df6a4e22d2cd38dd21edaa9644c8c6d5e517bc1',
    'tools/cpu_generators/test_entry.py': '54d4d5a8971253263ecfe9c75e1eba6e415fa755ce7c79908388b514f57a8977',
    'tools/cpu_generators/probe.hia': '9bd1d52f11172f2e8db05fef28d2ac5f878b35260295f371bcd308b8ef093bfa',
    'tools/cpu_generators/client.py': '08ce910cbb5199fec9c7f062a896dd46a88ffbb1b67f06fdc5f1453bf5df2b07',
    'tools/cpu_generators/reference.py': 'a942a26c3f0a3286ec32e361aeff201574cadc0c52a855726ba52fe65f17b8b8',
    'tools/cpu_generators/reference.cpp': '9d210d6c8acbca9814ed71358c154ceb9fbf31b1bee261b6cc745a384d5ea874',
    'tests/check_cpu_generator_reports.py': '0059e26e7ec7776a6267d1f8428dab6daf25490539ad5393c0bda0bf9bc6bc3a',
}


def need(ok, text):
    if not ok:
        raise ValueError(text)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repository', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    repo, out = a.repository.resolve(strict=True), a.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    before, source = {}, {}
    for name, pin in PINS.items():
        path = repo/name; raw = path.read_bytes()
        need(sha(raw) == pin, 'frozen source mismatch: '+name)
        before[name] = {'sha256': sha(raw), 'bytes': len(raw), 'mode': stat.S_IMODE(path.stat().st_mode)}
        source[Path(name).name] = raw
        dest = out/'frozen'/Path(name).name; dest.parent.mkdir(exist_ok=True)
        dest.write_bytes(raw)
    edits = {
        'qualify.py': [
            (b"image=build/'generator-session'", b"image=build/'heptatorch'"),
            (b"identity['executable_sha256']", b"identity['native_sha256']"),
        ],
        'test_entry.py': [
            (b"linker=build/'generator-session-linker';image=build/'generator-session'",
             b"linker=build/'toolchain/stack-linker-session';image=build/'heptatorch'"),
            (b"identity['generator_linker_sha256']", b"identity['linker_sha256']"),
            (b"identity['executable_sha256']", b"identity['native_sha256']"),
            (b"objects=[(build/(n+'.o')).read_bytes() for n in ('rng','model','owners')]",
             b"objects=[(build/(row['name']+'.o')).read_bytes() for row in json.loads((build/'manifest.json').read_bytes())['units']]"),
        ],
    }
    reports = {}
    for name in ('qualify.py','test_entry.py'):
        raw = source[name]; changes = edits[name]
        for old, new in changes:
            need(raw.count(old) == 1 and new not in raw, 'unique adapter site: '+name)
            raw = raw.replace(old, new)
        inverse = raw
        for old, new in reversed(changes):
            need(inverse.count(new) == 1, 'unique inverse adapter site: '+name)
            inverse = inverse.replace(new, old)
        need(inverse == source[name], 'whole original source inverse: '+name)
        ast.parse(raw)
        (out/name).write_bytes(raw)
        reports[name] = {'original_sha256': sha(source[name]), 'derived_sha256': sha(raw),
                         'whole_file_inverse_exact': True,
                         'changes': [{'before': old.decode(), 'after': new.decode()} for old,new in changes],
                         'comparisons_expectations_or_case_bodies_changed': False}
    # Keep the original probe's raw writer rather than bind a newly tagged
    # Tensor helper accidentally. All offsets and every original assertion stay.
    old_probe = source['probe.hia']
    need(b'cg_putw' not in old_probe, 'probe binding name collision')
    probe = re.sub(rb'\bputw\b', b'cg_putw', old_probe)
    need(probe != old_probe and re.sub(rb'\bcg_putw\b', b'putw', probe) == old_probe,
         'whole original probe inverse')
    (out/'probe.hia').write_bytes(probe)
    reports['probe.hia'] = {'original_sha256': sha(old_probe), 'derived_sha256': sha(probe),
                            'whole_file_inverse_exact': True, 'only_change': 'putw -> cg_putw raw-writer binding',
                            'changed_identifiers': len(re.findall(rb'\bputw\b', old_probe))}
    for name in ('client.py', 'reference.py', 'reference.cpp', 'pytorch_cpu_generator_oracle.py'):
        (out/name).write_bytes(source[name])
        reports[name] = {'original_sha256': sha(source[name]), 'derived_sha256': sha(source[name]),
                         'entire_file_byte_identical': True}
    for name, row in before.items():
        path=repo/name
        need(path.read_bytes()==source[Path(name).name] and stat.S_IMODE(path.stat().st_mode)==row['mode'],
             'input changed: '+name)
    (out/'adaptation.json').write_text(json.dumps({
        'schema': 'heptatorch.generator712-original-gates-source-adaptation.v1',
        'status': 'SOURCE_ONLY_NATIVE_TORCH_NOT_RUN', 'files': reports, 'inputs': before,
        'all_inputs_unchanged': True,
        'original24_main_and_comparison_entire_source_unchanged': True,
        'original11_and59_expected_values_refusals_assertions_unchanged': True,
        'original_historical_reports_or_PASS_transferred': False,
        'root_must_bind_the_actual_712_cold_build_before_execution': True,
    }, indent=2, sort_keys=True)+'\n')
    print(json.dumps({'status':'SOURCE_ONLY_NATIVE_TORCH_NOT_RUN', 'output':str(out),
                      'adaptation_sha256':sha((out/'adaptation.json').read_bytes())}))


if __name__ == '__main__':
    main()
