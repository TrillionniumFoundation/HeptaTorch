"""Read-only native byte/owner observations around unchanged original calls."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import struct
import time
import traceback

from admission import need, sha, record


def save(path,value):
    Path(path).write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')


def gzip_bytes(path,raw):
    with gzip.open(path,'xb',compresslevel=1) as stream:
        stream.write(raw)


def decode_generator(raw,pointer):
    if not raw:
        need(pointer==0,'empty actual owner pointer')
        return {'family':'empty','live':0,'allocation':0,'last':0,'epoch':0,'records':{}}
    need(pointer>0 and len(raw)>=64 and raw[:8]==b'HTCGST01','actual Generator owner magic')
    last,live,epoch,version,width,r0,r1=struct.unpack_from('<7Q',raw,8)
    need(live<=1024 and len(raw)==64+5088*live and version==1 and width==5088
         and r0==r1==0,'actual Generator owner header/size equation')
    records={}
    for i in range(live):
        offset=64+5088*i
        handle,a,b,c=struct.unpack_from('<4Q',raw,offset)
        need(0<handle<=last and a==b==c==0 and str(handle) not in records,
             'actual live Generator record/unique handle')
        state=raw[offset+32:offset+5088]
        need(len(state)==5056,'actual complete canonical Generator state length')
        records[str(handle)]={'offset':offset,'state_bytes':5056,'state_sha256':sha(state),
                              'initial_seed':struct.unpack_from('<Q',state)[0]}
    return {'family':'generator','live':live,'allocation':len(raw),'last':last,'epoch':epoch,
            'version':version,'width':width,'records':records}


class OwnerReader:
    def __init__(self,process,tensor_owner=None):
        self.process,self.control,self.tensor_owner=process,None,tensor_owner

    def settled(self):
        deadline=time.monotonic()+10
        while True:
            need(self.process.poll() is None,'native exited before actual owner observation')
            fields=Path(f'/proc/{self.process.pid}/syscall').read_text().split()
            if fields and fields[0] not in ('running','-1'):
                values=[int(v,0) for v in fields]
                if values[0]==0 and values[1]==0 and values[3]==16:
                    control=values[2]
                    if self.control is None:self.control=control
                    need(control==self.control,'native frame-control mapping moved')
                    return control
            need(time.monotonic()<deadline,'native did not settle at next16-byte frame read')
            time.sleep(.001)

    def snapshot(self,directory,label,output):
        row={'passed':False,'error':None}
        try:
            control=self.settled()
            with open(f'/proc/{self.process.pid}/mem','rb',buffering=0) as stream:
                def read(at,count):
                    need(at>=0 and count>=0,'negative observed memory range')
                    result=os.pread(stream.fileno(),count,at)
                    need(len(result)==count,'short actual owner memory read')
                    return result
                area=read(control,264)
                pointer,length=struct.unpack_from('<2Q',area,32)
                row.update(control=control,pointer=pointer,length=length)
                # Save actual control bytes before applying new ABI predicates.
                control_path=directory/(label+'.control.bin')
                control_path.write_bytes(area)
                row['control_raw']={'path':str(control_path.relative_to(output)),
                                    'bytes':len(area),'sha256':sha(area)}
                need(struct.unpack_from('<Q',area,192)[0]==1,'startup must retain the live owner slot')
                need(area[128:160]==bytes(32) and area[160:192]==bytes(32),
                     'state/entropy argument and result slots must be clear between frames')
                need(area[256:264]==bytes(8),'private native entropy bytes must be clear between frames')
                need(bool(pointer)==bool(length) and length<=128<<20,'actual owner pointer/length/budget')
                raw=b''.join(read(pointer+at,min(65536,length-at)) for at in range(0,length,65536))
            self.settled()
            raw_path=directory/(label+'.owner.bin.gz')
            gzip_bytes(raw_path,raw)
            row['raw']={'path':str(raw_path.relative_to(output)),'bytes':len(raw),'sha256':sha(raw)}
            if not raw or raw[:8]==b'HTCGST01':
                decoded=decode_generator(raw,pointer)
                verification={'native_compact_owner_header_and_unique_records':True,
                              'every_live_state_5056_bytes_captured':True}
            else:
                need(self.tensor_owner is not None,'unexpected non-Generator owner in an original CG case')
                decoded=self.tensor_owner.decode_owner(raw,pointer)
                verification=self.tensor_owner.verify_snapshot(decoded)
                need(verification['all_original_84Q_predicates_retained'] is True,
                     'complete original Tensor structural verification must execute')
                decoded=dict(decoded,family='tensor')
            decoded_raw=json.dumps(decoded,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
            decoded_path=directory/(label+'.owner.json.gz');gzip_bytes(decoded_path,decoded_raw)
            row.update(passed=True,family=decoded['family'],verification=verification,
                       decoded={'path':str(decoded_path.relative_to(output)),
                                'bytes':len(decoded_raw),'sha256':sha(decoded_raw)})
            return row,raw,decoded
        except BaseException:
            row['error']=traceback.format_exc()
            raise
        finally:
            save(directory/(label+'.owner-observation.json'),row)


class StdinTap:
    def __init__(self,real,child):self.real,self.child=real,child
    def write(self,raw):
        frame=self.child['active_frame'];need(frame is not None,'write outside a real frame')
        count=self.real.write(raw)
        need(type(count) is int and 0<=count<=len(raw),'unverifiable native write')
        frame['request'].extend(raw[:count]);return count
    def __getattr__(self,name):return getattr(self.real,name)


class ProcessTap:
    def __init__(self,real,child):
        self.real,self.child=real,child;self.input_tap=StdinTap(real.stdin,child)
    @property
    def stdin(self):return None if self.real.stdin is None else self.input_tap
    @stdin.setter
    def stdin(self,value):
        need(value is None,'original close can only clear stdin');self.real.stdin=None
    def communicate(self,*args,**kwargs):
        row={'stdout_EOF':False,'stderr_EOF':False,'exit_code':None,'error':None}
        number=len(self.child['communications']);self.child['communications'].append(row)
        stem=self.child['directory']/f'close-{number:02d}'
        try:
            out,err=self.real.communicate(*args,**kwargs)
            stem.with_suffix('.stdout').write_bytes(out);stem.with_suffix('.stderr').write_bytes(err)
            row.update(stdout_EOF=True,stderr_EOF=True,exit_code=self.real.returncode,
                       stdout_bytes=len(out),stdout_sha256=sha(out),stderr_bytes=len(err),stderr_sha256=sha(err))
            return out,err
        except BaseException as error:
            row['error']=traceback.format_exc()
            partial_out=getattr(error,'stdout',None) or b'';partial_err=getattr(error,'stderr',None) or b''
            stem.with_suffix('.partial.stdout').write_bytes(partial_out)
            stem.with_suffix('.partial.stderr').write_bytes(partial_err)
            raise
    def __getattr__(self,name):return getattr(self.real,name)


class OSTap:
    def __init__(self,original,audit):self.original,self.audit=original,audit
    def read(self,fd,count):return self.audit.read(fd,count)
    def __getattr__(self,name):return getattr(self.original,name)


class Audit:
    def __init__(self,output,image,images,tensor_owner=None,plan=None):
        self.output=Path(output);self.output.mkdir(parents=True,exist_ok=False)
        self.image=Path(image).resolve();self.images={str(Path(p).resolve()):s for p,s in images.items()}
        self.tensor_owner,self.plan=tensor_owner,plan
        self.children,self.instances,self.by_fd=[],[],{}

    def adopt(self,instance,executable,constructor,case=None):
        path=Path(executable).resolve();need(str(path) in self.images,'unadmitted native child executable')
        expected=self.images[str(path)];need(record(path)['sha256']==expected,'native changed before Popen')
        index=len(self.children)
        if self.plan is not None:
            need(index<len(self.plan),'unexpected extra original native child');case=self.plan[index]
        case=case or f'child-{index:03d}'
        directory=self.output/f'{index:03d}-{case}';directory.mkdir()
        child={'case':case,'directory':directory,'started':False,'frames':[],
               'communications':[],'close_calls':[],'active_frame':None,'initialization_error':None,
               'request_hash':hashlib.sha256(),'response_hash':hashlib.sha256(),
               'expected_image_sha256':expected,'binary_path':str(path)}
        instance.audit_child=child;self.children.append(child);self.instances.append(instance)
        try:
            constructor()
            child.update(started=True,pid=instance.process.pid)
            instance.process=ProcessTap(instance.process,child)
            raw=(Path('/proc')/str(instance.process.pid)/'exe').read_bytes()
            need(sha(raw)==expected,'actual /proc child executable differs')
            child.update(proc_exe_sha256=sha(raw),proc_exe_bytes=len(raw))
            self.by_fd[instance.process.stdout.fileno()]=child
            instance.owner_reader=OwnerReader(instance.process,self.tensor_owner)
        except BaseException:
            child['initialization_error']=traceback.format_exc();raise

    def read(self,fd,count):
        child=self.by_fd.get(fd)
        need(child is not None and child['active_frame'] is not None,'read outside actual native frame')
        raw=os.read(fd,count);child['active_frame']['response'].extend(raw)
        if not raw:child['active_frame']['early_stdout_EOF']=True
        return raw

    def frame(self,instance,body,invoke):
        child=instance.audit_child;need(child['active_frame'] is None,'nested native frame')
        body=bytes(body);attempted=b'HTOWNR01'+struct.pack('<Q',len(body))+body
        number=len(child['frames']);directory=child['directory']/f'frame-{number:05d}';directory.mkdir()
        (directory/'attempted-request.bin').write_bytes(attempted)
        frame={'request':bytearray(),'response':bytearray(),'error':None,'early_stdout_EOF':False,
               'original_call_returned':False,'owner_before':None,'owner_after':None}
        child['active_frame']=frame
        try:
            before,old_raw,old=instance.owner_reader.snapshot(directory,'before',self.output)
            frame['owner_before']=before
            result=invoke()
            after,new_raw,new=instance.owner_reader.snapshot(directory,'after',self.output)
            frame['owner_after']=after
            response=bytes(frame['response'])
            need(bytes(frame['request'])==attempted,'actual native write differs from original request')
            need(len(response)>=16 and response[:8]==b'HTOWNS01'
                 and struct.unpack_from('<Q',response,8)[0]==len(response)-16
                 and not frame['early_stdout_EOF'],'actual complete reply envelope required')
            payload=response[16:]
            if payload[:8]==b'HTCGRS01':
                need(len(payload)>=64 and new['family'] in {'empty','generator'},'real CG reply family')
                code,size,live,allocation,last,epoch,reserved=struct.unpack_from('<7Q',payload,8)
                need(reserved==0 and size==len(payload)-64
                     and (live,allocation,last,epoch)==(new['live'],new['allocation'],new['last'],new['epoch']),
                     'reply owner fields must equal actual full native memory')
                if code:
                    need(not size and (before['pointer'],before['length'],old_raw)==
                         (after['pointer'],after['length'],new_raw),'refusal must retain the entire actual CG owner')
                if not code and len(body)>=64 and body[:8]==b'HTCGEN01':
                    op,handle,count,a=struct.unpack_from('<4Q',body,8)
                    if op in (4,5):
                        row=new['records'][str(handle)];at=row['offset']+32
                        expected=new_raw[at:at+(8 if op==4 else 5056)]
                        need(payload[64:]==expected,'native state/seed response differs from actual owner memory')
                    if op==18:
                        need(payload[64:]==new_raw[a:a+count],'native dump differs from actual full owner memory')
                frame['generator_reply_bound_to_full_physical_owner']=True
                frame['actual_status']=code
            else:
                need(self.tensor_owner is not None and len(payload)>=32 and payload[:8]==b'HTORSP03',
                     'unrecognized real response family')
                version,count,status=struct.unpack_from('<3Q',payload,8)
                need(version==3,'Tensor response version')
                if status:
                    need(count==0 and len(payload)==32 and (before['pointer'],old_raw)==(after['pointer'],new_raw),
                         'Tensor protocol refusal must retain actual entire owner')
                frame['actual_status']=status
            frame['original_call_returned']=True
            return result
        except BaseException:
            frame['error']=traceback.format_exc()
            if frame['owner_before'] is not None and frame['owner_after'] is None \
                    and not (directory/'after.owner-observation.json').exists():
                try:frame['owner_after']=instance.owner_reader.snapshot(directory,'after-failure',self.output)[0]
                except BaseException:frame['failure_owner_error']=traceback.format_exc()
            raise
        finally:
            child['active_frame']=None
            request,response=bytes(frame.pop('request')),bytes(frame.pop('response'))
            (directory/'request.bin').write_bytes(request);(directory/'response.bin').write_bytes(response)
            child['request_hash'].update(request);child['response_hash'].update(response)
            frame.update(index=number,directory=str(directory.relative_to(self.output)),
                         request_bytes=len(request),request_sha256=sha(request),
                         response_bytes=len(response),response_sha256=sha(response))
            child['frames'].append(frame);save(directory/'transport.json',frame)

    def closing(self,instance,failed,invoke):
        row={'failed_argument':failed,'returned':False,'error':None}
        instance.audit_child['close_calls'].append(row)
        try:
            value=invoke();row['returned']=True;return value
        except BaseException:row['error']=traceback.format_exc();raise

    def native_class(self,base):
        audit=self
        class Captured(base):
            def __init__(self,executable):
                audit.adopt(self,executable,lambda:base.__init__(self,executable))
            def call(self,op,handle=0,count=0,a=0,b=0,payload=b'',status=0):
                mask=(1<<64)-1
                body=b'HTCGEN01'+struct.pack('<7Q',op,handle,count,a&mask,b&mask,len(payload),0)+payload
                return audit.frame(self,body,lambda:base.call(self,op,handle,count,a,b,payload,status))
            def close(self,failed=False):
                return audit.closing(self,failed,lambda:base.close(self,failed))
        return Captured

    def session_class(self,base):
        audit=self
        class Captured(base):
            def __init__(self,executable,preexec_fn=None):
                audit.adopt(self,executable,lambda:base.__init__(self,executable,preexec_fn=preexec_fn))
            def raw(self,body):return audit.frame(self,body,lambda:base.raw(self,body))
            def close(self):return audit.closing(self,False,lambda:base.close(self))
        return Captured

    def cleanup(self):
        for instance in self.instances:
            process=getattr(instance,'process',None);child=instance.audit_child
            complete=bool(child['communications']) and all(child['communications'][-1][key] is True
                                                           for key in ('stdout_EOF','stderr_EOF'))
            if process is not None and not complete:
                child['outer_cleanup_required']=True
                try:
                    if process.poll() is None:process.kill()
                    process.communicate(timeout=30)
                except BaseException:child['outer_cleanup_error']=traceback.format_exc()

    def reports(self):
        rows=[]
        for child in self.children:
            row={k:v for k,v in child.items() if k not in {'directory','active_frame','request_hash','response_hash'}}
            row.update(directory=str(child['directory'].relative_to(self.output)),
                       request_stream_sha256=child['request_hash'].hexdigest(),
                       response_stream_sha256=child['response_hash'].hexdigest(),
                       frames_completed=sum(f['original_call_returned'] for f in child['frames']))
            save(child['directory']/'transport.json',row);rows.append(row)
        return rows


def require_children(children,expected_image=None):
    need(children,'at least one actual native child is required')
    for child in children:
        need(child['started'] is True and child['initialization_error'] is None
             and child['proc_exe_sha256']==child['expected_image_sha256'],'actual native child identity')
        if expected_image:need(child['proc_exe_sha256']==expected_image,'same complete image required')
        need(len(child['frames'])==child['frames_completed']>0 and all(f['error'] is None for f in child['frames']),
             'every actual frame must finish and pass original checks')
        need(all(f[key] is not None and f[key]['passed'] is True for f in child['frames']
                 for key in ('owner_before','owner_after')),'full actual owners required for every frame')
        need(child['close_calls']==[{'failed_argument':False,'returned':True,'error':None}]
             and len(child['communications'])==1 and not child.get('outer_cleanup_required'),
             'one original normal close without emergency cleanup')
        end=child['communications'][0]
        need(end['stdout_EOF'] is True and end['stderr_EOF'] is True and end['exit_code']==0
             and end['stdout_bytes']==end['stderr_bytes']==0 and end['error'] is None,
             'actual successful exit, both EOF and empty trailing streams required')
