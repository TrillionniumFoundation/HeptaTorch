"""Fixed712 source/cold-build admission. Pure reads, no native tool invocation."""
from pathlib import Path
import hashlib
import json
import re
import stat
import struct
import types

SOURCE = 'fac3d413c6c0f6874d224cbea312108ee2c8baa027102d41890d85094a5faa38'
IMAGE = '5b7aac203d2c913d43781f0da45d40e9bac2037c2bc074ec30f8dd663710a805'
SOURCE_PACKAGE = '8ac67a00bddbd3d709b4191e154a671aa302ddc4ae1a7347e4aa39443a571f82'
MANIFEST = '708e4b642f630604cedb1d2cf566fefcfb3d9afd74a835f5a265d7e51f1ff4e5'
BUILDER = '9c93f8ff3fcfda8358e51a4c12efb3b0e0962abed9b5a750ca32d5a5568ac14d'
INSPECTOR = '71b72260014417db72ffcebd80c86543e257c80d76cdd6c878b41feaa117cf92'
COMPILER = 'b1c851a0896fa6071f800e1146c3c27d0c6cf85059e9a6281b46d42908a3f59f'
LINKER = '761a941fd7a2d53eb9b45869fcfc20e970640e9dd11d60f7c61a89812b61d74e'
OLD_LINKER = 'aae650e8822ef0b1e74d15108ad1d0f17ec791205ed5a158ec60b709f48f0e16'
RUNTIME_LINKER = '0c5176e3aa968631ae592b887c5dc3cf1e8e3f48f73593f076e9d7965ffacfd7'
TOOL_LINKER = 'fa3065b5dc42bfe09fd29cf773c5adc5a9296c125a6a161daecf2fa885ea160b'
TOOL_SOURCE = '7bba866ece4f33fb6b1973e33475d868376f2b804d5ce81116cf206cfff31c34'
TOOL_PREFIX = '75b74f8441acd38b84d5a4784ab3a37f48652e06caa1ca938595aa1324424a00'
SUPPORT = 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK = 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
ORACLE = '3b9e1c9058776c67c00c4b07610a2a0d377dda16ca4a956d7e66c442bdfd4157'
ORIGINAL_PACKAGE = 'd5d529a697056625a19c06abf4ddc25326dad8854ae87b0406ec86f5a66fd085'
CHECKS = {'python_matches', 'platform_matches', 'version_backend_matches',
          'git_matches_oracle_build_pin', 'distribution_version_matches',
          'direct_url_matches', 'direct_url_archive_sha256_matches',
          'pip_report_url_matches', 'pip_report_archive_sha256_matches',
          'pip_report_version_matches', 'pip_report_requested'}
NAMES = ['rng03'] + [f'cat_f32_{i:02d}' for i in range(12)] + ['cg_model', 'owners']


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def record(path):
    path = Path(path)
    need(not path.is_symlink(), 'symlink input forbidden: '+str(path))
    before = path.stat(); raw = path.read_bytes(); after = path.stat()
    need(stat.S_ISREG(before.st_mode) and
         (before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns,before.st_mode) ==
         (after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns,after.st_mode),
         'input changed during read: '+str(path))
    return {'bytes': len(raw), 'sha256': sha(raw), 'mode': stat.S_IMODE(after.st_mode)}


class Inputs:
    def __init__(self):
        self.rows = {}

    def bind(self, path, expected=None):
        path = Path(path).absolute()
        row = record(path)
        need(expected is None or row['sha256'] == expected, 'input SHA mismatch: '+str(path))
        need(str(path) not in self.rows or self.rows[str(path)] == row, 'bound input changed: '+str(path))
        self.rows[str(path)] = row
        raw = path.read_bytes()
        need(sha(raw) == row['sha256'] and len(raw) == row['bytes'], 'input changed after binding')
        return raw

    def unchanged(self):
        return {name: record(name) == row for name,row in self.rows.items()}


def file_package(root, manifest, inputs, schema=None):
    root = Path(root).resolve(strict=True)
    raw = inputs.bind(root/'package-manifest.json', manifest)
    value = json.loads(raw)
    if schema:
        need(value['schema'] == schema, 'source package schema')
    rows = value['files']
    if isinstance(rows, dict):
        rows = [dict(path=name,**row) for name,row in rows.items()]
    seen=set()
    for row in rows:
        rel=Path(row['path'])
        need(not rel.is_absolute() and '..' not in rel.parts and str(rel)==row['path'] and str(rel) not in seen,
             'invalid package member')
        seen.add(str(rel)); path=root/rel
        inputs.bind(path,row['sha256'])
        need(record(path)=={k:row[k] for k in ('bytes','sha256','mode')}, 'package bytes/mode mismatch: '+str(rel))
    return value


def loaded_module(path, raw, name):
    module=types.ModuleType(name);module.__file__=str(path)
    exec(compile(raw,str(path),'exec'),module.__dict__)
    return module


def admit(args, inputs):
    need(args.expected_native_sha256==IMAGE,'fixed actual712 native executable required')
    candidate=args.candidate.resolve(strict=True)
    source_package=file_package(candidate,SOURCE_PACKAGE,inputs,
                                'heptatorch.generator-native712.source-package.v1')
    builder_path=candidate/'tools/current_runtime/build.py'
    builder=loaded_module(builder_path,inputs.bind(builder_path,BUILDER),'fixed712_source_builder_definitions')
    manifest_raw=inputs.bind(candidate/'source/manifest.json',MANIFEST)
    manifest=json.loads(manifest_raw,object_pairs_hook=builder.unique_object)
    runtime,units,summary=builder.check_sources(manifest,candidate/'source',inputs.bind)
    need(summary['functions']==summary['complete_core_bodies_matched']==712
         and summary['units_planned']==15 and summary['source_sha256']==SOURCE,
         'complete fixed712 source required')
    need([entry['name'] for entry,_,_ in units]==NAMES, 'all15 original ordered units required')
    # Complete old701 inverse, independent of an old application image or a
    # path to a historical complete source. Only exact canonical bytes are used.
    model=next(parsed for entry,raw,parsed in units if entry['name']=='cg_model')
    suffix=b''.join(model['definitions'].values())
    need(len(model['definitions'])==11 and runtime.endswith(suffix), 'eleven exact appended CG bodies')
    current_header,tail=runtime.split(b'\n',1)
    need(current_header==b'hia-asm.v1 hepta.hia.program.v8 tensor_generator_complete01', 'combined source header')
    old_header=b'hia-asm.v1 hepta.hia.program.v8 sum_integral_f32_runtime\n'
    inverse=old_header+tail.removesuffix(suffix)
    need(sha(inverse)=='82360ce87dae6f9a004ef50be4f991b6f83905a83f4b17ca8d6634827b7bd313',
         'entire previous701 source inverse failed')

    build=args.build_directory.resolve(strict=True)
    raw=inputs.bind(build/'build.json',args.expected_build_sha256)
    receipt=json.loads(raw)
    need(receipt['schema']=='heptatorch.complete-runtime-build.v1'
         and receipt['status']=='PASS_NATIVE_BUILD_ONLY'
         and receipt['source_sha256']==SOURCE and receipt['native_sha256']==args.expected_native_sha256
         and receipt['functions']==receipt['complete_core_bodies_matched']==712
         and receipt['units_planned']==15 and receipt['manifest_sha256']==MANIFEST,
         'actual complete712 cold build required')
    need(receipt['compiler_sha256']==COMPILER and receipt['linker_sha256']==LINKER
         and receipt['limits']==builder.LIMITS and receipt['all_inputs_unchanged'] is True
         and receipt['objects_reused'] is False and receipt['link_exit']==0
         and all(receipt[key] is False for key in ('historical_runtime_executed','result_executable_executed',
                                                  'torch_executed','runtime_qualified','full_pytorch_rewrite_complete')),
         'fixed true cold build and no runtime-PASS transfer required')
    need(receipt['module_dependencies']==summary['module_dependencies'], 'cold source dependency graph')
    need(inputs.bind(build/'runtime.hepta',SOURCE)==runtime
         and inputs.bind(build/'manifest.json',MANIFEST)==manifest_raw, 'cold source copies differ')
    image=inputs.bind(build/'heptatorch',args.expected_native_sha256)
    need(len(image)==receipt['native_bytes'] and image[:6]==b'\x7fELF\x02\x01'
         and struct.unpack_from('<HH',image,16)==(2,62), 'actual Linux x86-64 ELF required')
    inputs.bind(build/'toolchain/stack-module-compiler',COMPILER)
    inputs.bind(build/'toolchain/stack-linker-session',LINKER)
    processes=receipt['processes']
    need([r['name'] for r in processes]==NAMES+['link'] and len(receipt['units'])==15,
         'fifteen actual compiles plus one actual link required')
    objects=[];views=[]
    inspector_path=candidate/'tools/stack_budget/inspect_stack.py'
    inspector=loaded_module(inspector_path,inputs.bind(inspector_path,INSPECTOR),'fixed712_stack_inspector')
    for i,(entry,source,parsed) in enumerate(units):
        name=entry['name'];row=receipt['units'][i];process=processes[i]
        need(inputs.bind(build/(name+'.hepta'),entry['sha256'])==source, 'actual unit source differs')
        obj=inputs.bind(build/(name+'.o'),row['object_sha256'])
        need(row['name']==name and row['source_sha256']==sha(source)
             and row['object_bytes']==len(obj) and row['functions']==parsed['functions']
             and row['blocks']==parsed['blocks'] and row['instructions']==parsed['instructions']
             and row['compiler_exit']==row['compiler_stderr_bytes']==0, 'actual compiled unit record')
        need(process['input_sha256']==sha(source) and process['input_bytes']==len(source)
             and process['stdout_sha256']==sha(obj) and process['stdout_bytes']==len(obj), 'actual compiler stream')
        views.append(inspector.inspect(source,obj));objects.append(obj)
    budget=inspector.longest(views)
    need({k:v for k,v in budget.items() if k!='per_function_path_bytes'}==receipt['stack']
         and budget['maximum_path_bytes']<=builder.LIMITS['stack_path_bytes'], 'actual stack inspection differs')
    request=b'HIACGS01'+struct.pack('<3Q',15,4,0)+b'step'+b''.join(struct.pack('<Q',len(obj))+obj for obj in objects)
    need(inputs.bind(build/'link.request.bin')==request, 'actual HIACGS01 request differs')
    link=processes[-1]
    need(link['input_sha256']==sha(request) and link['input_bytes']==len(request)
         and link['stdout_sha256']==sha(image) and link['stdout_bytes']==len(image), 'actual linker stream')
    for row in processes:
        need(row['started'] is True and row['exit_code']==0 and row['stdout_EOF'] is True
             and row['stderr_EOF'] is True and not row.get('timed_out',False)
             and row['stderr_bytes']==0 and row['stderr_sha256']==sha(b''), 'complete real tool exit/EOF required')
        need(inputs.bind(build/(row['name']+'.stderr'))==b'', 'native tool stderr changed')
    for path,row in receipt['inputs'].items():
        value=inputs.bind(Path(path),row['sha256'])
        need(len(value)==row['bytes'], 'original cold-build input identity changed')

    tool=args.tool_build.resolve(strict=True)
    tool_raw=inputs.bind(tool/'build.json',args.expected_tool_build_sha256)
    tools=json.loads(tool_raw)
    need(tools['schema']=='heptatorch.generator-entropy-linker.tool-only-build.v1'
         and tools['status']=='PASS_NATIVE_ENTROPY_LINKER_BUILD_ONLY'
         and tools['all_inputs_unchanged'] is True and tools['entropy_linker_sha256']==LINKER
         and tools['entropy_linker_source_sha256']==TOOL_SOURCE and tools['startup_prefix_sha256']==TOOL_PREFIX
         and tools['compiler_executed'] is True and tools['tool_linker_executed'] is True
         and tools['generator_session_linker_executed'] is False
         and tools['old_generator_application_built'] is False
         and tools['old_generator_application_executed'] is False and tools['torch_executed'] is False,
         'actual tool-only entropy bootstrap required')
    need(len(tools['processes'])==2 and tools['other41_linker_function_asts_unchanged'] is True,
         'actual two-tool bootstrap and41 original authoring functions required')
    for row in tools['processes']:
        need(row['started'] is True and row['exit_code']==0 and row['stdout_EOF'] is True
             and row['stderr_EOF'] is True and row['timed_out'] is False and row['stderr_bytes']==0,
             'entropy tool process did not finish completely')
        directory=Path(row['directory'])
        for leaf,key in (('input.bin','input'),('stdout.bin','stdout'),('stderr.bin','stderr')):
            value=inputs.bind(directory/leaf,row[key+'_sha256'])
            need(len(value)==row[key+'_bytes'], 'entropy tool raw stream differs')
    for name,row in tools['products'].items():
        inputs.bind(tool/name,row['sha256']);need(record(tool/name)==row, 'entropy product bytes/mode')
    for name,row in tools['inputs'].items():
        inputs.bind(Path(name),row['sha256']);need(record(Path(name))==row, 'entropy source bytes/mode')
    need(inputs.bind(tool/'generator-session-linker',LINKER)==inputs.bind(build/'toolchain/stack-linker-session',LINKER),
         'current build must use the freshly reproduced fixed entropy tool')
    stack=args.stack_build.resolve(strict=True)
    for name,pin in [('stack-module-compiler',COMPILER),('stack-linker-runtime',RUNTIME_LINKER),
                     ('stack-linker-session',OLD_LINKER)]:
        inputs.bind(stack/'native'/name,pin)
    repo=args.repository.resolve(strict=True)
    original_root=args.original_package_root.resolve(strict=True)
    package=inputs.bind(original_root/'validation/cpu-generator-package.sha256',ORIGINAL_PACKAGE)
    originals={}
    for line in package.decode().splitlines():
        pin,relative=line.split('  ',1)
        need(relative not in originals and not Path(relative).is_absolute() and '..' not in Path(relative).parts,
             'original26 custody path')
        inputs.bind(original_root/relative,pin);originals[relative]=pin
    need(len(originals)==26,'complete original26 source package required')
    for rel,pin in [('tests/pytorch_cpu_generator_oracle.py',ORACLE),('tests/pytorch_oracle.py',SUPPORT),
                    ('compatibility/pytorch-oracle-lock.json',LOCK)]:
        inputs.bind(repo/rel,pin)
    return {'status':'ADMITTED_NOT_RUN','source_sha256':SOURCE,'native_sha256':sha(image),
            'cold_build_sha256':sha(raw),'entropy_tool_build_sha256':sha(tool_raw),
            'core_functions':712,'units':15,'actual_cold_processes':16,
            'all701_complete_source_inverse_exact':True,'original26_package':originals,
            'stack':receipt['stack'],'candidate_package_payload_files':source_package['payload_files']}
