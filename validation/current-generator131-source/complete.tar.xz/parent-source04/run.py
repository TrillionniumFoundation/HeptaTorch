#!/usr/bin/env python3
"""Run original Generator24, native11, entry59 and37 new dispatcher controls.

The original numerical/exception/reference programs are unchanged except the
explicit whole-file-inverted build paths and object census in the two native
qualifiers. This wrapper observes real streams and actual committed owner
memory. Only root executes; --prepare-only imports no Torch and starts nothing.
"""
from pathlib import Path
import argparse
import contextlib
import hashlib
import json
import os
import re
import sys
import time
import traceback
import types

from admission import (Inputs,need,sha,record,admit,loaded_module,SOURCE,IMAGE,ORACLE,
                       CHECKS,COMPILER,LINKER)
from observe import Audit,OSTap,save,require_children
from processes import ToolAudit,ReferenceAudit

HERE=Path(__file__).resolve().parent
OWNER='c39600e7c37dea390f88cf9e74d86dfa924301456e0f32e127d82c98ad6778b0'
SEEDS=[0,1,17,5489,(1<<31)-1,(1<<32)-1,1<<32,(1<<32)+17,(1<<63)-1,1<<63,(1<<64)-2,(1<<64)-1]
PLAN=['mixed-seed-'+str(seed) for seed in SEEDS]+[
    'default-construction','six-interleaved-generators','clone-across-twist',
    'state-export-restore','float-normal-cache-clones','double-normal-cache-clones',
    'reseed-clears-both-caches','native-system-seed-roundtrip',
    'release-compaction-preserves-survivors','zero-count-does-not-advance',
    'sixty-four-independent-generators','long-cloned-trajectory']
ORIGINALS={
    'pytorch_cpu_generator_oracle.py':ORACLE,
    'qualify.py':'90ba7ba9b6b936592c3b4ca32df6a4e22d2cd38dd21edaa9644c8c6d5e517bc1',
    'test_entry.py':'54d4d5a8971253263ecfe9c75e1eba6e415fa755ce7c79908388b514f57a8977',
    'probe.hia':'9bd1d52f11172f2e8db05fef28d2ac5f878b35260295f371bcd308b8ef093bfa',
    'client.py':'08ce910cbb5199fec9c7f062a896dd46a88ffbb1b67f06fdc5f1453bf5df2b07',
    'reference.py':'a942a26c3f0a3286ec32e361aeff201574cadc0c52a855726ba52fe65f17b8b8',
    'reference.cpp':'9d210d6c8acbca9814ed71358c154ceb9fbf31b1bee261b6cc745a384d5ea874',
    'check_cpu_generator_reports.py':'0059e26e7ec7776a6267d1f8428dab6daf25490539ad5393c0bda0bf9bc6bc3a',
}


def package(inputs):
    manifest=json.loads(inputs.bind(HERE/'package-manifest.json'))
    need(manifest['schema']=='heptatorch.generator712-original-qualification-source.v1','qualification package schema')
    paths=list(HERE.rglob('*'))
    need(all(not p.is_symlink() and (p.is_file() or p.is_dir()) for p in paths),'regular source package only')
    actual={str(p.relative_to(HERE)):record(p) for p in paths if p.is_file() and p!=HERE/'package-manifest.json'}
    need(actual==manifest['files'],'exact complete qualification source bytes/modes required')
    for name,row in actual.items():inputs.bind(HERE/name,row['sha256'])
    adaptation=json.loads(inputs.bind(HERE/'adaptation.json'))
    for name,pin in ORIGINALS.items():
        original=inputs.bind(HERE/'frozen'/name,pin)
        if name=='check_cpu_generator_reports.py':continue
        raw=inputs.bind(HERE/name,adaptation['files'][name]['derived_sha256'])
        if name in {'qualify.py','test_entry.py'}:
            restored=raw
            for row in reversed(adaptation['files'][name]['changes']):
                old,new=row['before'].encode(),row['after'].encode()
                need(restored.count(new)==1,'exact qualifier inverse edit count')
                restored=restored.replace(new,old)
        elif name=='probe.hia':restored=re.sub(rb'\bcg_putw\b',b'putw',raw)
        else:restored=raw
        need(restored==original,'entire original qualifier inverse: '+name)
    return adaptation


def tensor_owner(inputs,out):
    original=inputs.bind(HERE/'frozen/owner_integral.py',OWNER)
    changes=[('HTSINT01','HTSINT02',2),('HTOSIN01','HTOSIN02',2),
             ('functions == 699','functions == 712',1),
             ('sum-integral-source01-UNBOUND-699','generator712-dispatch-UNBOUND',1),
             ('sum-integral-source01-%d-preserved47-48','generator%d-dispatch-full-tensor-owner',1),
             ('heptatorch.sum-integral-owner-source01.v1','heptatorch.generator712-dispatch-tensor-owner.v1',1)]
    raw=original
    for old,new,count in changes:
        need(raw.count(old.encode())==count and new.encode() not in raw,'Tensor observer profile edit count')
        raw=raw.replace(old.encode(),new.encode())
    inverse=raw
    for old,new,count in reversed(changes):
        need(inverse.count(new.encode())==count,'Tensor observer profile inverse count')
        inverse=inverse.replace(new.encode(),old.encode())
    need(inverse==original,'whole complete original Tensor observer inverse')
    path=out/'executed-tensor-owner.py';path.write_bytes(raw);inputs.bind(path,sha(raw))
    module=loaded_module(path,raw,'generator712_dispatch_complete_tensor_owner')
    module.bind_profile(SOURCE,IMAGE,712)
    proof={'original_sha256':OWNER,'executed_sha256':sha(raw),'whole_file_inverse_exact':True,
           'only_profile_identity_tag_and_function_count_changed':True,'all_original_84Q_predicates_retained':True}
    save(out/'tensor-owner-inverse.json',proof)
    return module,proof


@contextlib.contextmanager
def entry_output(directory,argv):
    old_argv,old_cwd=sys.argv,Path.cwd();sys.argv=argv
    try:
        with (directory/'original-entry.stdout').open('x') as stdout,(directory/'original-entry.stderr').open('x') as stderr:
            with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):yield
    finally:sys.argv=old_argv;os.chdir(old_cwd)


def oracle24(args,inputs,out):
    out.mkdir(parents=True,exist_ok=False)
    inputs.bind(args.repository/'build/pytorch-install.json')
    original=inputs.bind(HERE/'pytorch_cpu_generator_oracle.py',ORACLE)
    # Preserve the exact original __file__ source custody, including its main.
    path=args.repository/'tests/pytorch_cpu_generator_oracle.py'
    scope={'__name__':'generator712_original24_definitions','__file__':str(path)}
    exec(compile(original,str(path),'exec'),scope)
    need(scope['PLAN']==PLAN,'all24 original ordered cases required')
    audit=Audit(out/'native',args.build_directory/'heptatorch',
                {str(args.build_directory/'heptatorch'):IMAGE},plan=PLAN)
    scope['Native']=audit.native_class(scope['Native']);scope['os']=OSTap(scope['os'],audit)
    result={'status':'FAIL','cases':0,'native_executed':False,'Torch_execution_attempted':True,
            'Torch_executed':None,'original_oracle_whole_source_unchanged':True,'error':None}
    try:
        argv=[str(path),'--native',str(args.build_directory/'heptatorch'),'--expected-native-sha256',IMAGE,
              '--repo',str(args.repository),'--output',str(out/'original-report.json')]
        with entry_output(out,argv):code=scope['main']()
        original_report=json.loads((out/'original-report.json').read_bytes())
        result['original_entry_exit']=code
        need(code==0 and original_report['schema']=='heptatorch.live-pytorch-owned-cpu-generator.v1'
             and original_report['status']=='PASS' and original_report['cases']==original_report['expected_cases']==24
             and original_report['failed_cases']==0 and original_report['native_executable_sha256']==IMAGE,
             'all original24 actual comparisons must pass')
        provenance=original_report['oracle_provenance']
        need(provenance['status']=='PASS' and set(provenance['checks'])==CHECKS
             and all(v is True for v in provenance['checks'].values()),'all11 actual Torch provenance requirements')
        result['Torch_executed']=True
        need(set(original_report['source_files_unchanged_during_run'])=={'native','oracle','reference_support','lock'}
             and all(v is True for v in original_report['source_files_unchanged_during_run'].values()),
             'original24 complete source custody')
        children=audit.reports();require_children(children,IMAGE)
        need([r['case'] for r in original_report['rows']]==[c['case'] for c in children]==PLAN,
             'all24 original real native trajectories in order')
        for row,child in zip(original_report['rows'],children):
            need(row['status']=='PASS' and row['frames']==child['frames_completed']
                 and row['request_stream_sha256']==child['request_stream_sha256']
                 and row['response_stream_sha256']==child['response_stream_sha256'],
                 'original24 frame count and actual byte-stream custody')
        for key in ('frames','exact_values','serialized_state_bytes_compared'):
            need(original_report[key]==sum(row[key] for row in original_report['rows'])>0,
                 'complete original24 aggregate: '+key)
        seeds=original_report['rows'][19]['nondeterministic_seed_observations']
        need(original_report['rows'][19]['case']=='native-system-seed-roundtrip' and len(seeds)==4,
             'four actual independent native/Torch system seed observations')
        result.update(status='PASS',cases=24,frames=original_report['frames'],
                      exact_values=original_report['exact_values'],
                      serialized_state_bytes_compared=original_report['serialized_state_bytes_compared'],
                      oracle_provenance=provenance,original_report=record(out/'original-report.json'))
    except BaseException:result['error']=traceback.format_exc()
    finally:
        audit.cleanup();children=audit.reports()
        result['native_executed']=any(c['started'] for c in children);result['native_children']=children
        save(out/'report.json',result)
    return result


def client_module(inputs,audit):
    path=HERE/'client.py';client=loaded_module(path,inputs.bind(path,ORIGINALS['client.py']),'client')
    client.Session=audit.session_class(client.Session);client.os=OSTap(client.os,audit)
    sys.modules['client']=client
    return client


def native11(args,inputs,out):
    out.mkdir(parents=True,exist_ok=False)
    audit=Audit(out/'native',args.build_directory/'heptatorch',{str(args.build_directory/'heptatorch'):IMAGE})
    client=client_module(inputs,audit)
    reference=loaded_module(HERE/'reference.py',inputs.bind(HERE/'reference.py',ORIGINALS['reference.py']),'reference')
    reference_audit=ReferenceAudit(out/'independent-reference-processes')
    reference.subprocess=reference_audit;sys.modules['reference']=reference
    program=loaded_module(HERE/'qualify.py',inputs.bind(HERE/'qualify.py'),'generator712_original_native11')
    program.subprocess=reference_audit
    result={'status':'FAIL','cases':0,'native_executed':False,'Torch_executed':False,'error':None}
    try:
        target=out/'original';argv=[str(HERE/'qualify.py'),'--build',str(args.build_directory),'--output',str(target)]
        with entry_output(out,argv):code=program.main()
        report=json.loads((target/'report.json').read_bytes())
        need(code is None and report['schema']=='heptatorch.cpu-generator-native-qualification.v1'
             and report['status']=='PASS' and len(report['cases'])==11
             and len({row['name'] for row in report['cases']})==11
             and all(row['status']=='PASS' for row in report['cases'])
             and report['image_sha256']==IMAGE and report['build_receipt_sha256']==args.expected_build_sha256,
             'complete original11 actual native qualification')
        for field,expected in [('frames',1715),('exact_output_values',121611),('full_rng_state_checks',471),
                               ('full_pool_failure_rollbacks',72)]:
            need(report[field]==expected,'original mandatory qualification count: '+field)
        for name,pin in report['test_sources_sha256'].items():
            need(record(HERE/name)['sha256']==pin,'actual original11 test source differs')
        children=audit.reports();require_children(children,IMAGE)
        need(len(children)==5 and sum(c['frames_completed'] for c in children)==1715,
             'all five original persistent native processes and1715 real frames required')
        reference_audit.require_complete()
        result.update(status='PASS',cases=11,frames=1715,exact_output_values=121611,
                      full_rng_state_checks=471,full_pool_failure_rollbacks=72,
                      original_report=record(target/'report.json'))
    except BaseException:result['error']=traceback.format_exc()
    finally:
        audit.cleanup();children=audit.reports();result['native_children']=children
        result['native_executed']=any(c['started'] for c in children)
        result['independent_reference_processes']=reference_audit.rows;save(out/'report.json',result)
    return result


def entry59(args,inputs,out):
    out.mkdir(parents=True,exist_ok=False)
    image=args.build_directory/'heptatorch'
    audit=Audit(out/'native',image,{str(image):IMAGE})
    client_module(inputs,audit)
    target=out/'original'
    tools=ToolAudit(out/'tool-and-probe-processes',args.build_directory,args.stack_build,target,
                    inputs.bind(HERE/'probe.hia'),audit.images)
    program=loaded_module(HERE/'test_entry.py',inputs.bind(HERE/'test_entry.py'),'generator712_original_entry59')
    program.subprocess=tools
    result={'status':'FAIL','cases':0,'native_executed':False,'Torch_executed':False,'error':None}
    try:
        argv=[str(HERE/'test_entry.py'),'--build',str(args.build_directory),
              '--stack-build',str(args.stack_build),'--output',str(target)]
        with entry_output(out,argv):code=program.main()
        report=json.loads((target/'report.json').read_bytes())
        need(code is None and report['schema']=='heptatorch.cpu-generator-native-entry-qualification.v1'
             and report['status']=='PASS' and len(report['cases'])==report['case_count']==59
             and len({row['case'] for row in report['cases']})==59
             and all(row['status']=='PASS' for row in report['cases'])
             and report['production_image_sha256']==IMAGE and report['linker_sha256']==LINKER
             and report['compiler_sha256']==COMPILER,'all59 original ABI cases must truly pass')
        need(report['probe_source_sha256']==sha((HERE/'probe.hia').read_bytes())
             and report['probe_image_sha256']==tools.probe_image
             and report['test_source_sha256']==sha((HERE/'test_entry.py').read_bytes())
             and report['caller_created_owners_in_qualification_only'] is True
             and report['production_accepts_native_pointers_from_packets'] is False,'actual probe/source boundary')
        children=audit.reports();require_children(children)
        need(len(children)==2 and children[0]['proc_exe_sha256']==IMAGE
             and children[1]['proc_exe_sha256']==tools.reordered_image,'original production and actual reordered image')
        tools.require_complete()
        result.update(status='PASS',cases=59,original_report=record(target/'report.json'),
                      actual_current15_probe_sha256=tools.probe_image,
                      actual_current15_reordered_image_sha256=tools.reordered_image)
    except BaseException:result['error']=traceback.format_exc()
    finally:
        audit.cleanup();children=audit.reports();result['native_children']=children
        result['native_executed']=any(c['started'] for c in children)
        result['tool_and_probe_processes']=list(tools.rows);save(out/'report.json',result)
    return result,tools


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('repository','candidate','build-directory','tool-build','stack-build','output'):
        p.add_argument('--'+name,type=Path,required=True)
    for name in ('native','build','tool-build'):
        p.add_argument('--expected-'+name+'-sha256',required=True)
    p.add_argument('--original-package-root',type=Path)
    p.add_argument('--prepare-only',action='store_true')
    p.add_argument('--group',choices=('all','oracle24','native11','entry59'),default='all')
    args=p.parse_args(argv)
    if args.original_package_root is None:args.original_package_root=args.repository
    need(not sys.flags.optimize,'all original comparison assertions must remain enabled')
    for key in ('repository','candidate','build_directory','tool_build','stack_build','original_package_root'):
        setattr(args,key,getattr(args,key).resolve(strict=True))
    args.output=args.output.resolve()
    for root in (HERE,args.repository,args.candidate,args.build_directory,args.tool_build,args.stack_build,args.original_package_root):
        need(not args.output.is_relative_to(root) and not root.is_relative_to(args.output),
             'new result directory must not modify or contain an input tree')
    args.output.mkdir(parents=True,exist_ok=False)
    inputs=Inputs();started=time.monotonic();old_modules={n:sys.modules.get(n) for n in ('client','reference')}
    report={'schema':'heptatorch.generator712-current-native-qualification.v1','status':'FAIL',
            'source_sha256':SOURCE,'native_sha256':IMAGE,'build_sha256':args.expected_build_sha256,
            'tool_build_sha256':args.expected_tool_build_sha256,'selected_group':args.group,
            'native_executed':False,'Torch_executed':False,'groups':{},'error':None,
            'source_or_expected_numerical_values_modified':False,
            'original24_source_entirely_unchanged':True,'original11_and59_complete_source_inverses_required':True,
            'historical_runtime_PASS_transferred':False,'production_rng_or_owner_in_python':False,
            'full_private_tensor_allocation_transition_ledger_claimed':False,
            'generator_tensor_handle_interoperability_claimed':False,'full_pytorch_rewrite_complete':False}
    code=1
    try:
        report['source_adaptations']=package(inputs)
        report['cold_build_admission']=admit(args,inputs)
        owner,proof=tensor_owner(inputs,args.output)
        report['tensor_observer_source_inverse']=proof
        owner.pin_profile(args.build_directory/'heptatorch',args.build_directory/'runtime.hepta')
        if args.prepare_only:
            report['status']='PREPARED_NOT_RUN';code=0
        else:
            selected=('oracle24','native11','entry59') if args.group=='all' else (args.group,)
            tools=None
            for group in selected:
                if group=='oracle24':value=oracle24(args,inputs,args.output/group)
                elif group=='native11':value=native11(args,inputs,args.output/group)
                else:value,tools=entry59(args,inputs,args.output/group)
                report['groups'][group]=value
                save(args.output/'report.json',report)
            if args.group=='all':
                if report['groups']['entry59']['status']=='PASS':
                    try:
                        from controls import run
                        # Original frozen packet is the only CG encoder used by
                        # new controls; its results still come from real native.
                        client=loaded_module(HERE/'client.py',inputs.bind(HERE/'client.py',ORIGINALS['client.py']),
                                             'generator712_control_original_client')
                        value=run(args.output/'dispatch',args.build_directory/'heptatorch',IMAGE,client.packet,owner,tools)
                    except BaseException:value={'status':'FAIL','error':traceback.format_exc()}
                else:value={'status':'NOT_RUN','reason':'The actual current-object original59 probe gate did not pass.'}
                report['groups']['dispatch']=value
                need(set(report['groups'])=={'oracle24','native11','entry59','dispatch'}
                     and all(v['status']=='PASS' for v in report['groups'].values()),'all original94 plus37 new controls required')
                report.update(status='PASS_CURRENT712_GENERATOR131',cases=131,original_cases=94,new_dispatch_cases=37)
            else:
                need(report['groups'][args.group]['status']=='PASS','selected original group did not pass')
                report.update(status='PASS_SELECTED_GROUP_ONLY',cases=report['groups'][args.group]['cases'])
            code=0
    except BaseException:report.update(status='FAIL',error=traceback.format_exc());code=1
    finally:
        for name,module in old_modules.items():
            if module is None:sys.modules.pop(name,None)
            else:sys.modules[name]=module
        report['native_executed']=any(v.get('native_executed',False) for v in report['groups'].values())
        if 'oracle24' in report['groups']:report['Torch_executed']=report['groups']['oracle24']['Torch_executed']
        try:
            after=inputs.unchanged()
        except BaseException:
            after={name:False for name in inputs.rows};report['input_recheck_error']=traceback.format_exc()
        report.update(inputs=inputs.rows,input_checks_after_execution=after,
                      all_inputs_unchanged=bool(after) and all(after.values()),elapsed_seconds=time.monotonic()-started)
        if not report['all_inputs_unchanged']:report['status']='FAIL';code=1
        save(args.output/'report.json',report)
        print(json.dumps({k:report[k] for k in ('status','native_executed','Torch_executed','all_inputs_unchanged')}))
    return code


if __name__=='__main__':
    raise SystemExit(main())
