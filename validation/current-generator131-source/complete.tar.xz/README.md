# Current712 Generator qualification: original94 plus37 new controls

This package is source-only until root runs it against the actual current cold
build. No native/Torch PASS is embedded or inherited. The fixed production
source is `fac3d413c6c0f6874d224cbea312108ee2c8baa027102d41890d85094a5faa38`;
the actual newly compiled ELF is
`5b7aac203d2c913d43781f0da45d40e9bac2037c2bc074ec30f8dd663710a805`.

## Preserved originals

| Group | Original source | Preserved work |
|---|---|---|
| PyTorch24 | `3b9e1c9058776c67c00c4b07610a2a0d377dda16ca4a956d7e66c442bdfd4157` | The entire original file, main, 24 plans, exact bit/state comparisons, Torch calls, 12 seeds and four independent system-seed observations are byte-identical. |
| Native11 | `90ba7ba9b6b936592c3b4ca32df6a4e22d2cd38dd21edaa9644c8c6d5e517bc1` | Only the image filename and actual cold-build identity key change. All numerical, resource, seccomp, RLIMIT_AS, unmap, rollback and recovery assertions are unchanged. |
| Entry59 | `54d4d5a8971253263ecfe9c75e1eba6e415fa755ce7c79908388b514f57a8977` | Only image/linker paths, actual build identity keys and the three-object list change. The new list reads all15 actual cold-build objects from the fixed manifest. All59 case bodies, expected statuses and ABI admission checks remain unchanged. |
| ABI probe | `9bd1d52f11172f2e8db05fef28d2ac5f878b35260295f371bcd308b8ef093bfa` | Only the raw writer binding changes from `putw` to the proven `cg_putw` alias. This avoids binding the Tensor core's tagged-address writer. |

`adaptation.json` lists every changed fragment. Each derived whole file is
reversed and compared against the fixed original bytes before execution.
`client.py`, `reference.py` and `reference.cpp` are byte-identical. The original
26-file package manifest is also verified; its old reports never grant current
runtime PASS. The C++/CPython code remains an independent qualification
reference, never production code or target RNG output.

## What is executed and observed

The unmodified original24 main invokes the fixed real Torch environment and
requires all11 original provenance checks. Its Native subclass calls the exact
original constructor, call and close methods. Two read/write taps record only
bytes the original process actually writes or reads. No request, reply, target
word, handle, epoch or error is translated or synthesized.

The original11 program runs five real persistent HIA children. It retains
1715 frames, 121611 exact output values, 471 complete state checks and72
whole-pool failure rollbacks. The original seccomp filter makes actual native
getrandom fail with EAGAIN; the real kernel AS quota still causes and recovers
from actual allocation failure. Original C++ reference compilation and actual
reference subprocess stdout/stderr are retained separately.

For every persistent target frame, the observer waits for the actual process's
next 16-byte stdin read and reads the startup control and entire committed owner
from `/proc`. It saves raw control/owner bytes before interpreting them. It
checks native compact owner size `64 + 5088 * live_count`, the unique actual
handles, all5056-byte state regions, and agreement between real reply header
fields and physical native memory. `get_state`, `current_seed` and `dump`
responses are also bound to those observed bytes. Refusals must retain the
same actual pointer, length and complete owner bytes.

The observer additionally checks that all state/entropy argument slots, result
slots and eight private entropy bytes have been cleared between frames. A
failure retains the original raw bytes and fails the gate; it cannot be
repaired by an observer or reported as success. This is a complete physical CG
owner observation, not a claim of a full private Tensor allocation-transition
ledger.

Entry59 truly compiles the original derived probe and links it with all15 new
objects. The unchanged old three-argument linker must reject the new entry;
the entropy linker must reject the original nine bad signatures and accept the
positive signature. The original reordered-service test links all15 actual
objects in reverse order and executes that genuinely produced image. It does
not use a historical Generator executable or an isolated model substitute.
Each HIA tool/probe child is observed through `/proc/exe` before input is sent;
all actual stdin/stdout/stderr, exit codes, both EOF observations and refusal
outputs are retained.

## New dispatcher controls

Six real production trajectories check both wrong-family directions, an
unknown request on an existing CG owner, a real system-seed request rejected
by an existing Tensor owner, and family selection while the owner is genuinely
empty. The Tensor used in these tests is constructed by actual operation38;
its returned native identity is used to read its actual value after refusal.
No logical ID is substituted for a native ID.

Thirty-one further internal ABI probe cases cover nonempty short/unknown owners,
both damaged Tensor magic words, known-but-short CG owners, wrong protocols,
short output capacities and the empty-owner cases. Their starting nonempty
valid CG/Tensor pools come from the production processes' actual raw memory.
The probe returns the real entire owner; every refused case must preserve it
byte-for-byte. Arbitrary test-owned buffers and test-supplied entropy exist only
inside this qualification probe. Production frames cannot submit native owner
pointers or the fourth trusted entropy argument.

These 37 tests preserve the declared new dispatch boundary: an unknown
nonempty owner can select only a refusal format, never application execution.
An empty unknown request uses the Tensor error format. The unknown-Tensor
refusal path does not claim the old pre-validation scratch allocation priority
under simultaneous OOM. A complete CG seed frame may cause the startup to read
OS entropy before application validation; tests require the application owner
and RNG state to remain unchanged, not that the OS entropy call never occurred.

## Root commands

The exact actual reports currently selected are:

| Receipt | SHA-256 |
|---|---|
| Complete712 cold build | `37d6038d6315a2f83b3fb1582f94e9e1b63dfa45c7168896b8123946fbea0c52` |
| Tool-only entropy linker build | `8d98ad295934b384940b7559666a3570faad695d777f04e97c38ae713871a69f` |

Use the fixed CPython3.12/Torch environment already used for the original
35/270/live32 gates. Actual execution must allow site packages; do not use `-S`
for the Torch run. The repository needs its original pinned
`build/pytorch-install.json`. Native11 additionally needs the original host
`g++` reference compiler. Entry59 needs the fixed module compiler,
`stack-linker-runtime` and old `stack-linker-session` under `STACK/native`.

```sh
"$PINNED_PYTHON" -B "$PACKAGE/run.py" \
  --repository "$REPO" --candidate "$CANDIDATE" \
  --build-directory "$R/generator-native712-cold-build-01" \
  --tool-build "$R/generator-entropy-tool-build-01" \
  --stack-build /home/qian-qi/heptatorch-continuation-20261116/runs/dview-r1-fixed-toolchain-cold-02/hepta-stack-budget \
  --expected-native-sha256 5b7aac203d2c913d43781f0da45d40e9bac2037c2bc074ec30f8dd663710a805 \
  --expected-build-sha256 37d6038d6315a2f83b3fb1582f94e9e1b63dfa45c7168896b8123946fbea0c52 \
  --expected-tool-build-sha256 8d98ad295934b384940b7559666a3570faad695d777f04e97c38ae713871a69f \
  --output "$FRESH_OUTPUT" --prepare-only
```

Preparation checks the source package, entire701 source inverse, all15 source
units and actual objects, all16 cold process streams, the actual HIACGS01 link
request, fresh pure stack inspection and the real two-process entropy tool
receipt. Preparation executes no compiler, linker, target or Torch and reports
`PREPARED_NOT_RUN` only.

Remove `--prepare-only` and choose another fresh output for actual execution.
The default runs all four groups, preserving failures and continuing the other
independent original groups. The new dispatcher controls require the actual
Entry59 probe to have passed first. Every old group and all37 new controls must
pass, with all inputs unchanged, for `PASS_CURRENT712_GENERATOR131`.

`--group oracle24`, `--group native11` or `--group entry59` can execute one
original group independently. Its success is explicitly
`PASS_SELECTED_GROUP_ONLY`; it cannot close the complete Generator gate.
Original standard output and warning output are retained in separate files.
Target trailing stdout/stderr must remain empty and both real EOF observations
are mandatory. The top-level `report.json` points to each original report and
the complete process/frame/owner data below it.

The original 513 Tensor cases still require their own complete new-image run.
Passing this package cannot imply passing those cases, cross-family handle
interoperability, all PyTorch Generator functionality, or the full PyTorch API.

## Source03 correction after the preserved first actual failure

The first source02 run remains FAIL. Its fixed report is 12,790,903 bytes,
SHA `e71e66591a4e0535b8ac6d68da994f7af113ac8b69a788317444bc7c1e52b6df`,
from job `1a1ee2451e6-ffbe-d`. Original24, native11 and entry59 each passed;
the new dispatcher group stopped in its third production trajectory. None of
those results is transferred to a new complete131 PASS.

The new controls had confused CG malformed-input status1 with the existing
Tensor malformed-envelope status100. Source03 changes exactly five integer
constants, covering six new cases: Tensor-owner CG-create/CG-seed production
requests, the empty unknown production request, and the matching three ABI
cases. The fixed original version3 authoring and old state-handoff assertions
independently specify100. The complete `frame_valid` and `reply_error` HIA
definitions are byte-identical in the fixed701 and712 sources. The root read
the first failure's real HTORSP03 response: version3, count0, status100; its
physical owner pointer, length and entire contents were unchanged.

`controls-correction.json` records the independent contract, all five source
edits and a complete reverse transformation to source02. The original94
comparators, requests and reference sources, every owner/EOF predicate, the
Tensor invalid-owner7 and CG1/10 rules, and short-output0 rules are unchanged.
Source03 is SOURCE_ONLY_NOT_EXECUTED until a new actual full131 run succeeds.
The native source, executable, cold build and entropy tool are unchanged.
