"""Retain real qualification tool/probe and independent reference subprocesses."""
from pathlib import Path
import json
import struct
import subprocess
import time
import traceback

from admission import need, sha, record, COMPILER, LINKER, OLD_LINKER, RUNTIME_LINKER
from observe import save


def link_request(magic,objects,entry):
    return magic+struct.pack('<3Q',len(objects),len(entry),0)+entry+b''.join(struct.pack('<Q',len(x))+x for x in objects)


class ToolAudit:
    def __init__(self,directory,build,stack,entry_output,probe_source,images):
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=False)
        self.build,self.entry_output=Path(build),Path(entry_output)
        self.probe_source,self.images=bytes(probe_source),images
        self.tools={str((Path(stack)/'native'/name).resolve()):pin for name,pin in (
            ('stack-module-compiler',COMPILER),('stack-linker-runtime',RUNTIME_LINKER),
            ('stack-linker-session',OLD_LINKER))}
        self.tools[str((self.build/'toolchain/stack-linker-session').resolve())]=LINKER
        manifest=json.loads((self.build/'manifest.json').read_bytes())
        self.objects=[(self.build/(r['name']+'.o')).read_bytes() for r in manifest['units']]
        need(len(self.objects)==14,'full14 actual objects required by original entry qualification')
        self.rows=[];self.probe_object=None;self.probe_image=None;self.reordered_image=None

    def run(self,argv,**kwargs):
        need(type(argv) is list and len(argv)==1 and set(kwargs)=={'input','capture_output','env','timeout'}
             and kwargs['capture_output'] is True and kwargs['env']=={'PATH':''} and kwargs['timeout']==30,
             'original qualification subprocess call contract changed')
        path=Path(argv[0]).resolve(strict=True);name=str(path);source=kwargs['input']
        need(type(source) is bytes,'immutable real qualification input required')
        expected=self.tools.get(name)
        kind='fixed-native-tool'
        if expected is None:
            need(path==self.entry_output/'step-probe' and self.probe_image is not None,
                 'unadmitted executable requested by original qualification')
            expected=self.probe_image;kind='qualification-owned-step-probe'
        need(record(path)['sha256']==expected,'actual qualification executable identity changed')
        # A newly linked probe or reordered production image is admitted only
        # from a real link request containing every current object, not a toy.
        is_probe=(expected==RUNTIME_LINKER and self.probe_object is not None and
                  source==link_request(b'HIASTKR1',self.objects+[self.probe_object],b'probe'))
        is_reordered=(expected==LINKER and source==link_request(b'HIACGS01',self.objects[::-1],b'step'))
        number=len(self.rows);directory=self.directory/f'process-{number:04d}';directory.mkdir()
        (directory/'input.bin').write_bytes(source)
        row={'index':number,'kind':kind,'argv':argv,'binary_sha256':expected,
             'input_bytes':len(source),'input_sha256':sha(source),'started':False,
             'stdout_EOF':False,'stderr_EOF':False,'timed_out':False,'error':None,
             'directory':str(directory),'current14_object_probe_link':is_probe,
             'current14_object_reordered_link':is_reordered}
        self.rows.append(row);save(directory/'process.json',row)
        process=None;out=err=b'';started=time.monotonic()
        try:
            # Equivalent to the exact original run(..., input=..., capture_output=True).
            # Reading /proc/exe before sending input observes the real exec while
            # each HIA stdin service waits for its original request.
            process=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE,env=kwargs['env'])
            row.update(started=True,pid=process.pid)
            actual=(Path('/proc')/str(process.pid)/'exe').read_bytes()
            need(sha(actual)==expected,'actual /proc qualification ELF differs')
            row['proc_exe_sha256']=sha(actual)
            try:
                out,err=process.communicate(input=source,timeout=kwargs['timeout'])
            except subprocess.TimeoutExpired as error:
                row['timed_out']=True
                process.kill();out,err=process.communicate()
                row.update(stdout_EOF=True,stderr_EOF=True,exit_code=process.returncode)
                raise subprocess.TimeoutExpired(argv,kwargs['timeout'],output=out,stderr=err) from error
            row.update(stdout_EOF=True,stderr_EOF=True,exit_code=process.returncode)
            need(record(path)['sha256']==expected,'qualification executable changed during invocation')
            if process.returncode==0 and not err:
                if expected==COMPILER and source==self.probe_source:
                    need(self.probe_object is None and out[:4]==b'\x7fELF','single real probe object')
                    self.probe_object=out
                if is_probe:
                    need(self.probe_image is None and out[:4]==b'\x7fELF','single real current probe image')
                    self.probe_image=sha(out)
                if is_reordered:
                    need(self.reordered_image is None and out[:4]==b'\x7fELF','single real reordered current image')
                    self.reordered_image=sha(out)
                    self.images[str((self.entry_output/'reordered-service').resolve())]=sha(out)
            return subprocess.CompletedProcess(argv,process.returncode,out,err)
        except BaseException:
            row['error']=traceback.format_exc()
            if process is not None and not row['stdout_EOF']:
                try:
                    if process.poll() is None:process.kill()
                    out,err=process.communicate(timeout=30)
                    row.update(stdout_EOF=True,stderr_EOF=True,exit_code=process.returncode,outer_cleanup_required=True)
                except BaseException:row['cleanup_error']=traceback.format_exc()
            raise
        finally:
            (directory/'stdout.bin').write_bytes(out);(directory/'stderr.bin').write_bytes(err)
            row.update(stdout_bytes=len(out),stdout_sha256=sha(out),stderr_bytes=len(err),stderr_sha256=sha(err),
                       elapsed_seconds=time.monotonic()-started)
            save(directory/'process.json',row)

    def require_complete(self):
        need(self.probe_object is not None and self.probe_image is not None and self.reordered_image is not None,
             'original current-object probe and reordered image must truly be linked')
        need(all(r['started'] is True and r['proc_exe_sha256']==r['binary_sha256']
                 and r['stdout_EOF'] is True and r['stderr_EOF'] is True and not r['timed_out']
                 and r['error'] is None and not r.get('outer_cleanup_required')
                 and r['exit_code'] in (0,2) and r['stderr_bytes']==0
                 and (r['exit_code']==0 or r['stdout_bytes']==0) for r in self.rows),
             'actual tool/probe success or original empty refusal, exit and both EOF required')


class ReferenceAudit:
    """Observe original host reference calls; do not replace its model or values."""
    def __init__(self,directory):
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=False);self.rows=[]
    def run(self,argv,**kwargs):
        need(type(argv) is list and argv and kwargs.get('capture_output') is True,
             'original independent reference subprocess required')
        number=len(self.rows);directory=self.directory/f'process-{number:04d}';directory.mkdir()
        path=Path(argv[0]).resolve(strict=True);before=record(path)
        row={'index':number,'argv':argv,'executable':before,'stdout_EOF':False,'stderr_EOF':False,
             'error':None,'production_runtime':False,'directory':str(directory)}
        self.rows.append(row);out=err=b''
        try:
            result=subprocess.run(argv,**kwargs)
            out,err=result.stdout,result.stderr
            row.update(stdout_EOF=True,stderr_EOF=True,exit_code=result.returncode)
            need(record(path)==before,'independent reference executable changed')
            return result
        except subprocess.TimeoutExpired as error:
            # The original subprocess.run owns kill/wait on this path. Retain
            # only its genuinely captured partial streams and keep EOF false.
            out=error.stdout or error.output or b'';err=error.stderr or b''
            row.update(timed_out=True,error=traceback.format_exc())
            raise
        except subprocess.CalledProcessError as error:
            out,err=error.stdout or b'',error.stderr or b''
            row.update(stdout_EOF=True,stderr_EOF=True,exit_code=error.returncode,error=traceback.format_exc())
            raise
        except BaseException:row['error']=traceback.format_exc();raise
        finally:
            (directory/'stdout.bin').write_bytes(out);(directory/'stderr.bin').write_bytes(err)
            row.update(stdout_bytes=len(out),stdout_sha256=sha(out),stderr_bytes=len(err),stderr_sha256=sha(err))
            save(directory/'process.json',row)
    def require_complete(self):
        need(self.rows and all(r['stdout_EOF'] is True and r['stderr_EOF'] is True
                              and r['exit_code']==0 and r['stderr_bytes']==0 and r['error'] is None
                              for r in self.rows),'original independent reference processes must truly pass')
