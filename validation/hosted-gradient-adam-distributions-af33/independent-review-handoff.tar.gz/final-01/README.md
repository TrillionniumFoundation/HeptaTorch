# af33 independent offline hosted admission

The final review passed **59,251 checks with zero failures**. It reads original
GitHub artifacts and their official metadata. It does not run HeptaTorch,
compile HIA, import Torch, modify native memory, or rewrite an original report.

| Execution | Original evidence checked |
| --- | --- |
| Native PR run 43862154942, job 133281424261 | All 76 actual steps succeeded; 58 original reports, 30 envelope obligations, and 294 journal-artifact members |
| Quick run 43862154875, job 133281423877 | Exact 355-function profile; all 13 steps, 185 artifact members, live32, frozen35, native3 and copied-snapshot4+18 |
| Quick run 43862154875, job 133281423531 | Exact 428-function profile; the same complete, separately executed gates |

Source is `af33d1065a3b097990e9536df5b22b1a3fb315cf`, tree
`88ed6bd6a41ca0e58e653b3d76718090b3bbba64`. Official merge checkout,
its base/head parents, job and run attempts, artifact identities, collector
checkout identities and every inventoried member are bound to that source.

Each of the four actual frozen35 executions retains 6,344 frames and
2,590,274 numerical comparisons, zero parameter absolute-Version mismatches,
and the original 283 explicit-state lifecycle differences. Every original EOF,
process exit, empty-pipe and post-close Version gate actually completed. Each
of the four live32 executions preserves its original workload and all eleven
reference-provenance checks. The raw pip reports are cross-bound to the oracle
observations. Repetition across executions is not counted as additional APIs.

The main artifact also binds the true cold 355 qualification and all sixteen
steps, its 124 immutable package members, the true fresh 428 seventeen-step
producer, three independent native gates, four peer runners, strict extreme8
comparison, and all 427 recorded inputs. All fifty older report obligations
remain present. The fixed Optimizer24 ledger remains **23 qualified within
the exposed scope and one partial (case14)**. The original eighteen
unrepresented distribution observations remain open.

The two original failed quick artifacts, all forty-seven repair-archive
members, and the original30ea native failure ZIP are checked as original
bytes. The original 3 PASS / 32 FAIL result is not retroactively reclassified.
The offline reviewer additionally calls only the frozen observer's pure JSON
validator on four positive and eighteen negative snapshots per quick profile.
These 44 pure checks create no native or Torch execution.

## Exact deliverables

- Final reviewer SHA256:
  `123aa0b96823a5f78d14a1998ab5cb992ac7172b65304b11905bc0d457967f59`.
- Original final report: 5,829,457 bytes, SHA256
  `694bf7fc8f05d41715aa7ab12c8d196b2ebfab159ad9a1f227c9260b2641176b`.
- `report.json.gz` is a byte-preserving compression of that report: 66,808
  bytes, SHA256
  `5016eb21a4a42a9eb97b0415f2bbbc6f1815cd08c222efcce471f6b9a6fdff87`.
- `reader-schema-correction.json` preserves the earlier reader's schema
  mistake and its failed receipt. The actual 355 units add precisely
  `source_bytes` and `object_bytes`; all original profile fields are unchanged.
  The corrected reader checks the extra byte counts against exact restored
  archive members, and rejects any other extra fields.

## Replay

Use the included `inputs-cloud.json` as a path map for the original artifacts.
Only that separate map should be adapted when moving the evidence. Original
report paths remain the CI paths; the reader resolves their exact
build-relative artifact keys and verifies SHA256 and byte length.

```sh
python3 -I -S -B review_hosted_af33.py \
  --inputs final-01/inputs-cloud.json \
  --output /absolute/new-review-output
```

`--quick-only` reviews only the two quick artifacts and deliberately returns
`PASS_QUICK_COMPONENTS_MAIN_PENDING` with `admission_allowed=false`. The
earlier quick-only report and the earlier Mac reader failure remain intact.

**The whole project remains HOLD.** All seventeen full-system gates remain
open or in progress, the inventory denominator remains 2,590, and complete
upstream schema parity remains zero. This scoped hosted admission does not
close the full PyTorch rewrite.
