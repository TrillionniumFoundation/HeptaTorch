#!/usr/bin/env python3
"""Offline, source-bound admission of PR28 af33 hosted bytes.

This reader never starts the application or imports Torch. Original JSON bytes,
including CI absolute paths, are not rewritten. Historical failures remain failures.
"""
from pathlib import Path, PurePosixPath
from collections import Counter
import argparse, ast, gzip, hashlib, io, json, re, tarfile, traceback, types, zipfile

HEAD = "af33d1065a3b097990e9536df5b22b1a3fb315cf"
TREE = "88ed6bd6a41ca0e58e653b3d76718090b3bbba64"
BASE = "dcb903ccbb679497f4c7fa3c413dc0f6d19340ef"
REPOSITORY = "TrillionniumFoundation/HeptaTorch"
LOCK = "ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944"
OBSERVER = "e900466bff13bcaa5cd89a814dc411b4fc33320d84855ca6bd085179cd599c6a"
LAUNCHER = "65c0d68725f0585b79f88ceb5fa106526a44805eca0b58535f32b5b29916cd12"
PEER = "c4873900abd44f2c74c2632d662d932ee0912501b7a127771c2bfecccc0f2db6"
PROFILES = {
 "355": {"name":"gradient-objects-355",
         "source":"1b18da2cf9791e1b20982f9706434c1359ea194dd983dc6c66eb005f152e77b5",
         "image":"be18ab877f38a4027a527783db80a1418a137c7d6da91e5bc39e2af8c044cb6b"},
 "428": {"name":"gradient-adam-distributions-428",
         "source":"1fed8ea7ba5bf755a9df9ca1e61d34cfd4712cc2fd66e0728493091c81c24dae",
         "image":"6773485896d961b6c2e62784ebb66320290df47128bd1331aecc0c8b7f6611fe"}}
PROVENANCE = {"python_matches","platform_matches","version_backend_matches",
 "git_matches_oracle_build_pin","distribution_version_matches","direct_url_matches",
 "direct_url_archive_sha256_matches","pip_report_url_matches",
 "pip_report_archive_sha256_matches","pip_report_version_matches","pip_report_requested"}
HEX = re.compile(r"[0-9a-f]{64}\Z")
OPEN_DIST = [4,9,14,19,24,29,34,39,109,110,167,168,169,170,171,172,173,174]
ATOMIC_DIFF = [101,103,105,179]
OLD50_SHA = "7bdb005879b75e38105e68b44e08981680bf29742881ea9cb2936d58a5e9f34b"
SOURCE_MANIFEST_SHA = "519bc512331c34bb6f738de477ffbcd3058428546eec8c248fd949ce69774c78"

def sha(raw): return hashlib.sha256(raw).hexdigest()
def canonical(x): return json.dumps(x,sort_keys=True,separators=(",",":"),allow_nan=False).encode()
def unique(pairs):
    out={}
    for k,v in pairs:
        if k in out: raise ValueError("duplicate JSON member: "+k)
        out[k]=v
    return out
def decode(raw): return json.loads(raw,object_pairs_hook=unique)
def plain_sha(x): return isinstance(x,str) and HEX.fullmatch(x) is not None
def basename(path):
    p=PurePosixPath(path)
    assert p.is_absolute() and ".." not in p.parts, ("invalid original CI path",path)
    return p.name
def member_name(name):
    p=PurePosixPath(name)
    assert name and not p.is_absolute() and ".." not in p.parts and "\\" not in name
    assert str(p)==name
    return name

def original_build_relative(path):
    p=PurePosixPath(path)
    assert p.is_absolute() and ".." not in p.parts
    # The raw report keeps its original CI path. Resolve only its exact
    # build-relative artifact key, never rewrite the original JSON.
    parts=p.parts
    i=max(n for n,x in enumerate(parts) if x=="build")
    return str(PurePosixPath(*parts[i+1:]))

class Audit:
    def __init__(self, root, output):
        self.root,self.output=root,output
        self.checks=[];self.files={};self.summary={};self.restored_members={}
    def check(self, name, condition, **detail):
        row={"check":name,"passed":bool(condition)}
        if detail: row["detail"]=detail
        self.checks.append(row)
        if not condition: raise AssertionError(row)
    def read(self,path):
        p=Path(path)
        if not p.is_absolute(): p=self.root/p
        assert p.is_file() and not p.is_symlink(),str(p)
        raw=p.read_bytes()
        d={"bytes":len(raw),"sha256":sha(raw)}
        self.check(str(p)+": stable original input",str(p) not in self.files or self.files[str(p)]==d)
        self.files[str(p)]=d
        return raw
    def json(self,path): return decode(self.read(path))
    def archive(self,spec):
        raw=self.read(spec["zip"])
        self.check("ZIP exact downloaded identity",sha(raw)==spec["sha256"] and len(raw)==spec["bytes"])
        metadata=self.json(spec["metadata"])
        if "artifacts" in metadata:
            selected=[m for m in metadata["artifacts"] if m["id"]==spec["artifact_id"]]
            self.check("one exact official artifact-list record",len(selected)==1)
            metadata=selected[0]
        self.check("official artifact identity",metadata["id"]==spec["artifact_id"]
                   and metadata["name"]==spec["artifact_name"] and metadata["expired"] is False)
        self.check("official artifact size",metadata["size_in_bytes"]==len(raw))
        if metadata.get("digest") is not None:
            self.check("official artifact SHA256",metadata["digest"]=="sha256:"+sha(raw))
        z=zipfile.ZipFile(io.BytesIO(raw))
        members={}
        for entry in z.infolist():
            if entry.is_dir(): continue
            name=member_name(entry.filename)
            self.check("unique ordinary ZIP member "+name,name not in members
                       and not ((entry.external_attr>>16)&0o170000)==0o120000)
            members[name]=z.read(entry)
        self.check("artifact contains bytes",bool(members))
        return members,metadata
    def provenance(self,p,label):
        self.check(label+": actual11 provenance",p["status"]=="PASS" and p["metadata_error"] is None
                   and set(p["checks"])==PROVENANCE and all(v is True for v in p["checks"].values()))
        self.check(label+": locked reference wheel",p["lock_sha256"]==LOCK
                   and p["observed"]["version"]=="2.15.0+cpu"
                   and p["observed"]["git_commit"]=="d0f2af8b66b20da4baa50644c0cd3f887a2eae2e")
        observed=p['observed'];expected=p['expected']
        self.check(label+': observed interpreter/backend/URL bytes',
                   observed['python']['implementation']=='cpython' and observed['python']['version']==[3,12]
                   and observed['platform']=={'sys_platform':'linux','machine':'x86_64'}
                   and observed['backend_versions']=={'cuda':None,'hip':None,'rocm':None,'xpu':None}
                   and observed['distribution_version']=='2.15.0+cpu'
                   and observed['direct_url']['url']==expected['wheel']['url']
                   and observed['direct_url']['archive_info']['hashes']['sha256']==expected['wheel']['sha256']
                   =='0955c7e3446326293f48af18fad67872fa31dee5a36a87690eb9e5be8b465be3')
        e=p["release_source_equivalence"]
        self.check(label+": no upstream commit conflation",
                   e["inventory_commit"]=="31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457"
                   and e["torch_git_matches_upstream_pin"] is False
                   and e["changed_paths"]==["pyproject.toml"])
    def pip_binding(self,raw,provenances,label):
        install=decode(raw)
        torch=[r for r in install['install'] if r['metadata']['name']=='torch']
        self.check(label+': exactly one requested pinned wheel install',len(torch)==1 and torch[0]['requested'] is True)
        row=torch[0]
        for p in provenances:
            observed=p['observed']['install_report']
            self.check(label+': original pip bytes bind actual oracle',
                       observed['pip_version']==install['pip_version']
                       and observed['download_info']==row['download_info']
                       and observed['metadata_name']==row['metadata']['name']
                       and observed['metadata_version']==row['metadata']['version']=='2.15.0+cpu'
                       and observed['requested']==row['requested'])
    def job(self,spec,workflow):
        run=self.json(spec["run"])
        jobs=self.json(spec["jobs"])
        selected=[j for j in jobs["jobs"] if j["id"]==spec["job_id"]]
        self.check("exact official job selected",len(selected)==1)
        job=selected[0]
        self.check("official workflow terminal success",run["status"]=="completed"
                   and run["conclusion"]=="success" and run["head_sha"]==HEAD
                   and run["repository"]["full_name"]==REPOSITORY)
        self.check("job terminal success",job["run_id"]==run["id"]
                   and job['run_attempt']==run['run_attempt']
                   and job['head_sha']==run['head_sha']
                   and job["status"]=="completed" and job["conclusion"]=="success"
                   and all(s["status"]=="completed" and s["conclusion"]=="success" for s in job["steps"]))
        names=re.findall(r"^      - name: (.+)$",workflow.decode(),re.M)
        actual=[s["name"] for s in job["steps"]]
        positions=[]
        for name in names:
            matches=[i for i,x in enumerate(actual) if x==name]
            self.check("declared workflow step executed: "+name,len(matches)==1)
            positions.append(matches[0])
        self.check("workflow step order retained",positions==sorted(positions))
        checkouts=len(re.findall(rb"^\s+uses: actions/checkout@",workflow,re.M))
        self.check("all declared and lifecycle steps present",len(actual)==len(names)+checkouts+2,
                   declared=len(names),actual=len(actual),checkout_post_steps=checkouts)
        checkout=self.json(spec["checkout_commit"])
        checkout_tree=(checkout.get("commit") or checkout)["tree"]["sha"]
        self.check("checkout exact target tree",checkout_tree==TREE)
        if run["event"]=="pull_request":
            parents=[p["sha"] for p in checkout["parents"]]
            self.check("PR merge parents bind exact base and head",parents==[BASE,HEAD])
        elif run["event"] in ("push","workflow_dispatch"):
            self.check("direct checkout exact source head",checkout["sha"]==HEAD)
        else: self.check("admitted workflow event",False,event=run["event"])
        return {"run":run,"job":job,"checkout":checkout}
    def identity(self,manifest,ctx,private=False):
        github=manifest["identity"]["github"] if private else manifest["github"]
        checkout=manifest["checkout_before"] if private else {
            "head":manifest["checkout_commit"],"tree":manifest["checkout_tree"],
            "clean":not manifest["tracked_worktree_dirty"]}
        self.check("collector exact official checkout",checkout["head"]==ctx["checkout"]["sha"]
                   and checkout["tree"]==TREE and checkout["clean"] is True)
        self.check("collector exact official run/repository",
                   github["GITHUB_RUN_ID"]==str(ctx["run"]["id"])
                   and github['GITHUB_RUN_ATTEMPT']==str(ctx['run']['run_attempt'])
                   and github["GITHUB_REPOSITORY"]==REPOSITORY
                   and github["GITHUB_SHA"]==ctx["checkout"]["sha"])
        if private:
            self.check("private collector source head",manifest["identity"]["source_head"]==HEAD
                       and manifest["checkout_after"]==manifest["checkout_before"])
        else: self.check("main collector source head",github["HEPTATORCH_SOURCE_HEAD_SHA"]==HEAD)
    def live32(self,raw,p,label,baseline_plan):
        d=decode(raw)
        self.check(label+": exact image/source",d["native_source_sha256"]==p["source"]
                   and d["native_executable_sha256"]==p["image"])
        self.check(label+": 32 actual passes",d["status"]=="PASS" and d["failed_cases"]==0
                   and d["cases"]==d["expected_cases"]==len(d["rows"])==32
                   and all(r["status"]=="PASS" for r in d["rows"]))
        self.check(label+": fixed actual workload counts",
                   [d[k] for k in ("frames","exact_binary32_words","serialized_state_bytes",
                                   "absolute_version_comparisons","gradient_presence_comparisons")]
                   ==[2132,17455,1137600,238,166])
        self.check(label+": fixed case plan",d["case_plan"]==baseline_plan)
        self.provenance(d["oracle_provenance"],label)
        self.check(label+": source custody",d["source_files_unchanged_during_run"]["native"] is True
                   and d["source_files_unchanged_during_run"]
                   and all(v is True for v in d["source_files_unchanged_during_run"].values())
                   and d["source_custody"]["native"]==p["image"]
                   and d["source_custody"]["source"]==p["source"]
                   and d["source_custody"]["oracle"]=="554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160")
        self.check(label+": actual independent Torch, scoped result",
                   d["pytorch_executed"] is True and d["one_native_process_per_trajectory"] is True
                   and d["whole_pytorch_rewrite_complete"] is False
                   and d["full_autograd_gate_closed"] is d["full_rng_gate_closed"] is False)
        return d
    def frozen35(self,wrapper_raw,inner_raw,p,inner_name,label,baseline_plan):
        d,w=decode(inner_raw),decode(wrapper_raw)
        self.check(label+": additive wrapper actual success",
                   w["schema"]=="heptatorch.frozen35-private-node-accounted-run.v1"
                   and w["status"]=="PASS" and w["original_entry_return_code"]==0 and w["exception"] is None)
        b=w["original_oracle_report"]
        self.check(label+": original raw report bound",
                   basename(b["path"])==inner_name
                   and PurePosixPath(b["path"]).parent.name=="build"
                   and b["bytes"]==len(inner_raw) and b["sha256"]==sha(inner_raw))
        self.check(label+": fixed exact profile",
                   w["profile"]["name"]==p["name"] and w["profile"]["source_sha256"]==p["source"]
                   and w["profile"]["native_sha256"]==d["native_executable_sha256"]==p["image"])
        pins={"native_image":p["image"],"native_source":p["source"],"observer":OBSERVER,"launcher":LAUNCHER}
        for key,value in pins.items():
            self.check(label+": executed source "+key,w["source_custody"][key]["sha256"]==value)
        for name,pin in self.original_pins.items():
            self.check(label+': complete unchanged original oracle source '+name,
                       w['source_custody'][name]['sha256']==pin)
        self.check(label+": all35 cases actually pass",d["status"]==b["status"]=="PASS"
                   and d["failed_cases"]==b["failed_cases"]==0
                   and d["cases"]==d["expected_cases"]==b["cases"]==len(d["rows"])==35
                   and all(r["status"]=="PASS" for r in d["rows"]))
        self.check(label+": unchanged28 plus actual lifetime7",
                   d["groups"]["unchanged_numeric_28"]["cases"]==d["groups"]["unchanged_numeric_28"]["passed"]==28
                   and d["groups"]["additional_object_lifetime_7"]["cases"]==d["groups"]["additional_object_lifetime_7"]["passed"]==7)
        self.check(label+": unchanged count/tolerance plan",d["case_plan"]==baseline_plan
                   and [(r["case"],r["rtol"],r["atol"]) for r in d["rows"]]
                   ==[(r["case"],r["rtol"],r["atol"]) for r in baseline_plan])
        self.check(label+": exact complete workload",
                   d["frames"]==b["frames"]==sum(r["frames"] for r in d["rows"])==6344
                   and d["compared_values"]==b["compared_values"]==sum(r["compared_values"] for r in d["rows"])==2590274)
        self.check(label+": no discarded parameter Version differences",
                   d["direct_parameter_absolute_version_mismatches"]==sum(len(r.get("parameter_version_mismatches",[])) for r in d["rows"])==0)
        self.check(label+": legacy283 state observations preserved",
                   d["explicit_state_absolute_version_differences"]==sum(len(r.get("explicit_state_version_differences",[])) for r in d["rows"])==283)
        self.provenance(d["oracle_provenance"],label)
        for doc in (d,w):
            self.check(label+": source custody unchanged",bool(doc["source_files_unchanged_during_run"])
                       and all(v is True for v in doc["source_files_unchanged_during_run"].values()))
        self.check(label+": native custody unchanged",d["native_unchanged_during_run"] is True)
        for field,pin in {"v3_entry":"149b41c455444edeb8d25d0ad98045e29683e780f37f7e210e7985242d359597",
                          "v3_bridge":"c2888687f8876ad3505f0e13c9aecddc45695eff22bfdd9fa16d760f9aa3dac5",
                          "oracle_lock":LOCK}.items():
            self.check(label+": unchanged original source "+field,d["source_custody"][field]["sha256"]==pin)
        self.check(label+": every original EOF/Version gate executed",
                   w["all_original_EOF_and_post_close_Version_gates_executed"] is True
                   and w["numeric_oracle_rows_reclassified_by_wrapper"] is False
                   and len(w["observer_cases"])==35)
        for row,case in zip(d["rows"],w["observer_cases"]):
            o=row["private_node_observer"]
            self.check(label+": actual original postconditions "+row["case"],
                       case==dict(case=row["case"],**o) and o["status"]=="PASS"
                       and o['profile']==p['name']
                       and o["eof_exit_assertions_executed"] is True
                       and o["post_close_parameter_version_assertions_executed"] is True
                       and o["frames_checked"]==row["frames"])
            for observation in row.get("optimizer_version_observations",[]):
                for param in observation["parameters"]:
                    self.check(label+": exact observed parameter Version",
                               param["equal"] is True and param["native_version"]==param["pytorch_version"])
        overlay=w["observer_overlay"]
        self.check(label+": explicit narrow observer override",
                   overlay["runtime_replacements"]==["bridge.install"]
                   and overlay["original_bridge_close_assertion_replaced"]=="stats[11] == self.next_id-1"
                   and overlay["inverse_runtime_restoration_checked_after_execution"] is True
                   and overlay["no_native_memory_writes"] is True)
        self.check(label+": no full-rewrite claim",d["full_rewrite_complete"] is w["full_rewrite_complete"] is False
                   and d["pytorch_api_denominator"]==w["pytorch_api_denominator"]==2590)
        return d,w
    def custody(self,members,metadata,ctx,expected_reports,label):
        paths=[p for p in members if p.endswith("/custody.json")]
        self.check(label+": unique raw-custody manifest",len(paths)==1)
        manifest_path=paths[0];m=decode(members[manifest_path])
        self.check(label+": complete successful byte export",
                   m["schema"]=="heptatorch.private-node-journal-custody.v1"
                   and m["status"]=="COMPLETE" and m["job_status_received"]=="success"
                   and not m["missing"] and not m["errors"])
        self.identity(m,ctx,private=True)
        self.check(label+": artifact officially linked to run",
                   metadata["workflow_run"]["id"]==ctx["run"]["id"]
                   and m["identity"]["artifact"]["name"]==metadata["name"])
        listed={r["path"]:r for r in m["files"]}
        self.check(label+": exact raw file set",len(listed)==len(m["files"])==m["file_count"]
                   and set(listed)|{manifest_path}==set(members)
                   and m["total_file_bytes"]==sum(r["size"] for r in listed.values()))
        for name,row in listed.items():
            self.check(label+": original bytes "+name,
                       len(members[name])==row["size"] and sha(members[name])==row["sha256"])
        self.check(label+": original reports were not parsed/reformatted",
                   m["report_contents_parsed_or_rewritten"] is False
                   and m["native_executed"] is False and m["torch_executed"] is False)
        mirrors={}
        for r in m["report_copies"]:
            self.check(label+": verified mirror "+r["original"],r["status"]=="COPIED_BYTES_VERIFIED")
            self.check(label+": mirror identity",r["mirror"] in members
                       and sha(members[r["mirror"]])==r["sha256"] and len(members[r["mirror"]])==r["size"])
            mirrors[PurePosixPath(r["original"]).name]=members[r["mirror"]]
        self.check(label+": exactly five requested report mirrors",
                   len(mirrors)==m["requested_report_count"]==5 and set(mirrors)==set(expected_reports))
        for name,raw in expected_reports.items():
            if raw is not None:self.check(label+": original CI bytes equal mirror "+name,mirrors[name]==raw)
        return m,mirrors
    def journals(self,members,rows,label):
        events_paths=[n for n in members if n.endswith("/events.json")]
        seen_cases={}
        for row in rows:
            o=row["private_node_observer"]
            folder=original_build_relative(o["snapshot_directory"])
            candidates=[n for n in events_paths if str(PurePosixPath(n).parent)==folder]
            self.check(label+": one actual journal per case "+row["case"],len(candidates)==1)
            ep=candidates[0];sp=str(PurePosixPath(ep).with_name("snapshots.jsonl.gz"))
            events=decode(members[ep])
            self.check(label+": journal frame coverage "+row["case"],
                       len(events)==row["frames"]==o["frames_checked"]
                       and all(e["error"] is None and e["result"]["status"]=="PASS" for e in events))
            required={e[k] for e in events for k in ("before","after")}
            present=set()
            with gzip.GzipFile(fileobj=io.BytesIO(members[sp]),mode="rb") as f:
                for line in f:
                    x=decode(line);h=sha(canonical(x["snapshot"]))
                    self.check(label+": snapshot original canonical hash",h==x["sha256"] and h not in present)
                    self.check(label+': snapshot exact profile',x['snapshot']['profile']==o['profile'])
                    present.add(h)
            self.check(label+": all journal snapshots referenced exactly",required==present)
            self.check(label+": executed allocation accounting totals",
                       sum(e["result"]["created_program_nodes"] for e in events)==o["program_created_nodes"]
                       and sum(e["result"]["created_private_G"] for e in events)==o["private_G_created_nodes"])
            seen_cases[row["case"]]=len(events)
        return seen_cases
    def finish(self):
        for p,meta in self.files.items():
            raw=Path(p).read_bytes()
            self.check("after-custody "+p,len(raw)==meta["bytes"] and sha(raw)==meta["sha256"])

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--inputs",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    p.add_argument("--quick-only",action="store_true",help="Review both quick artifacts only; never admit the unreviewed main run.")
    a=p.parse_args()
    a.inputs=a.inputs.resolve();a.output=a.output.resolve()
    a.output.mkdir(parents=True,exist_ok=False)
    executed=Path(__file__).read_bytes()
    (a.output/"executed-reviewer.py").write_bytes(executed)
    audit=Audit(a.inputs.parent,a.output)
    result={"schema":"heptatorch.pr28.af33-independent-hosted-admission.v1",
            "status":"NOT_RUN","head":HEAD,"tree":TREE,"reviewer_sha256":sha(executed),
            "native_executed_by_reviewer":False,"Torch_executed_by_reviewer":False,
            "original_report_bytes_rewritten":False,"whole_project_decision":"HOLD",
            "full_schema_parity":0,"pytorch_api_denominator":2590,
            "whole_pytorch_rewrite_complete":False}
    code=1
    try:
        i=audit.json(a.inputs)
        audit.check("input specification",i["schema"]=="heptatorch.pr28.af33-admission-inputs.v1")
        bundle=Path(i["source_bundle"])
        if not bundle.is_absolute():bundle=a.inputs.parent/bundle
        manifest_raw=audit.read(bundle/"published-source-manifest.json")
        audit.check("fixed published source manifest",sha(manifest_raw)==SOURCE_MANIFEST_SHA)
        manifest=decode(manifest_raw)
        audit.check("published source target",manifest["head"]==HEAD and manifest["tree"]==TREE)
        sources={}
        for row in manifest["files"]:
            raw=audit.read(bundle/"published"/row["path"])
            audit.check("published blob "+row["path"],len(raw)==row["bytes"]
                        and sha(raw)==row["sha256"]
                        and hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==row["git_blob"])
            sources[row["path"]]=raw
        workflow=sources[".github/workflows/native.yml"]
        quick=sources[".github/workflows/observer-accounting.yml"]
        observer_ast=ast.parse(sources['tests/private_node_accounting/owner_accounting.py'])
        audit.original_pins=next(ast.literal_eval(n.value) for n in observer_ast.body
            if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SOURCE_PINS' for t in n.targets))
        acceptance=decode(sources["compatibility/full-acceptance.json"])
        capabilities=decode(sources["compatibility/capabilities.json"])
        audit.check("all17 whole-system gates remain open",
                    acceptance["status"]=="HOLD" and len(acceptance["gates"])==17
                    and all(g["status"] in ("OPEN","IN_PROGRESS") for g in acceptance["gates"])
                    and acceptance["native_schema_count"]==2590 and acceptance["whole_pytorch_rewrite_complete"] is False)
        audit.check("no complete upstream schema claim",
                    capabilities["full_upstream_schema_parity_count"]==0
                    and capabilities["native_schema_inventory_count"]==2590
                    and capabilities["whole_pytorch_rewrite_complete"] is False)
        old_raw=audit.read(bundle/"old50-obligations.json")
        audit.check("old50 obligations are fixed before this run",sha(old_raw)==OLD50_SHA)
        old=decode(old_raw)["reports"]
        baseline35=old["pytorch-adam-distributions-frozen35.json"]["case_plan"]
        baseline32=old["pytorch-adam-distributions-backward.json"]["case_plan"]
        if a.quick_only:
            quick_summaries=review_quick(audit,i["quick"],quick,baseline32,baseline35,sources)
            audit.finish()
            result.update(status="PASS_QUICK_COMPONENTS_MAIN_PENDING",admission_allowed=False,
                          quick_profiles=quick_summaries,main_native_reviewed=False,
                          all_original_files_unchanged=True)
            return save_result(audit,result,0)
        ctx=audit.job(i["native"],workflow)
        main_bytes,meta=audit.archive(i["native"]["reports"])
        m=decode(main_bytes["ci-report-manifest.json"])
        audit.check("main original export complete",m["status"]=="COMPLETE" and m["job_status_before_export"]=="success"
                    and m["original_report_bytes_reserialized"] is False)
        audit.identity(m,ctx)
        audit.check("official main artifact run",meta["workflow_run"]["id"]==ctx["run"]["id"])
        audit.check("main source workflow and collector",
                    m["workflow_sha256"]==sha(workflow)
                    and m["collector_sha256"]==sha(sources["tools/collect_ci_reports.py"]))
        required=sorted({x.decode() for x in re.findall(rb"tools/emit_ci_report\.py build/([A-Za-z0-9_.-]+\.json)",workflow)})
        audit.check("all30 envelope obligations retained",len(required)==30
                    and m["required_envelope_reports"]==required and not m["missing_envelope_reports"])
        listed={r["path"]:r for r in m["reports"]}
        audit.check("58 exact original reports",len(listed)==len(m["reports"])==58
                    and set(main_bytes)==set(listed)|{"ci-report-manifest.json"})
        reports={}
        for name,row in listed.items():
            raw=main_bytes[name]
            audit.check("main original member "+name,len(raw)==row["bytes"] and sha(raw)==row["sha256"])
            reports[name]=decode(raw)
        audit.check("all old50 reports still present",set(old)<=set(reports))
        for name,expected in old.items():
            d=reports[name]
            audit.check("old50 schema/status "+name,d.get("schema")==expected["schema"] and d.get("status")==expected["status"])
            for field,value in expected["fields"].items():
                audit.check("old50 preserved field "+name+"/"+field,d[field]==value)
            if "case_plan" in expected:audit.check("old50 fixed plan "+name,d["case_plan"]==expected["case_plan"])
            if "row_count" in expected:
                audit.check("old50 row coverage "+name,len(d["rows"])==expected["row_count"]
                            and [r.get("status") if isinstance(r,dict) else None for r in d["rows"]]==expected["row_statuses"])
            if "oracle_provenance" in d:audit.provenance(d["oracle_provenance"],name)
        baseline35=old["pytorch-adam-distributions-frozen35.json"]["case_plan"]
        baseline32=old["pytorch-adam-distributions-backward.json"]["case_plan"]
        new_rows={}
        for profile,prefix in (("355","pytorch-gradient-objects"),("428","pytorch-gradient-adam-distributions")):
            model=PROFILES[profile]
            live=audit.live32(main_bytes[prefix+"-backward.json"],model,"main "+profile+" live32",baseline32)
            inner_name=prefix+"-frozen35-original.json"
            d,w=audit.frozen35(main_bytes[prefix+"-frozen35.json"],main_bytes[inner_name],model,inner_name,"main "+profile+" frozen35",baseline35)
            audit.pip_binding(main_bytes['pytorch-install.json'],[live['oracle_provenance'],d['oracle_provenance']],'main '+profile)
            new_rows[profile]=d["rows"]
        native_components(audit,reports,sources)
        journal_bytes,jmeta=audit.archive(i["native"]["journals"])
        expected={name:main_bytes[name] for name in (
            "pytorch-gradient-objects-frozen35.json","pytorch-gradient-objects-frozen35-original.json",
            "pytorch-gradient-adam-distributions-frozen35.json","pytorch-gradient-adam-distributions-frozen35-original.json",
            "pytorch-install.json")}
        audit.custody(journal_bytes,jmeta,ctx,expected,"main journals")
        for profile,rows in new_rows.items():audit.journals(journal_bytes,rows,"main "+profile)
        quick_summaries=review_quick(audit,i["quick"],quick,baseline32,baseline35,sources)
        for unit in reports['hosted-gradient-objects-native.json']['build']['units']:
            for suffix,kind in (('.hepta','source'),('.o','object')):
                restored=audit.restored_members['355'][unit['name']+suffix]
                audit.check('355 additional unit byte count matches exact published restoration '+unit['name']+suffix,
                            unit[kind+'_bytes']==restored['bytes']
                            and unit[kind+'_sha256']==restored['sha256'])
        history_review(audit,i["history"])
        audit.finish()
        result.update(status="PASS_SCOPED_HOSTED_ADMISSION",admission_allowed=True,
                      native_run=ctx["run"]["id"],native_job=ctx["job"]["id"],
                      old_reports_preserved=50,main_original_reports=58,required_envelopes=30,
                      main_new_profiles={"355":{"live32":32,"frozen35":35},"428":{"live32":32,"frozen35":35}},
                      quick_profiles=quick_summaries,all_original_files_unchanged=True)
        code=0
    except Exception as e:
        result.update(status="FAIL_ADMISSION_REVIEW",admission_allowed=False,error=repr(e),traceback=traceback.format_exc())
    return save_result(audit,result,code)

def save_result(audit,result,code):
    result.update(checks=audit.checks,checks_passed=sum(x["passed"] for x in audit.checks),
                  checks_failed=sum(not x["passed"] for x in audit.checks),input_files=audit.files,
                  additional_source_bound_observations=audit.summary)
    raw=(json.dumps(result,indent=2,allow_nan=False)+"\n").encode()
    (audit.output/"report.json").write_bytes(raw)
    print(json.dumps({"status":result["status"],"report":str(audit.output/"report.json"),"sha256":sha(raw),
                      "checks_passed":result["checks_passed"],"checks_failed":result["checks_failed"]}))
    return code

def review_quick(audit, entries, quick, baseline32, baseline35, sources):
    quick_summaries=[]
    observer_source=sources['tests/private_node_accounting/owner_accounting.py']
    audit.check('pure verifier exact frozen source',sha(observer_source)==OBSERVER)
    pure=types.ModuleType('offline_frozen_private_node_observer')
    pure.__file__='source-bound-owner_accounting.py'
    exec(compile(observer_source,pure.__file__,'exec'),pure.__dict__)
    # Only these JSON-to-JSON validation functions are called below; no
    # capture/install/process/profile-loading function is invoked.
    control_ast=ast.parse(sources['tests/private_node_accounting/check_owner_snapshots.py'])
    control_calls=sorted((n for n in ast.walk(control_ast) if isinstance(n,ast.Call)
                          and isinstance(n.func,ast.Name) and n.func.id=='run'),key=lambda n:n.lineno)
    rules=[(ast.literal_eval(n.args[0]),ast.literal_eval(n.args[1]),ast.literal_eval(n.args[3])) for n in control_calls]
    audit.check('exact18 independently frozen negative rules',len(rules)==18 and len({r[0] for r in rules})==18)
    audit.check("exactly two independent quick profiles",{x["profile"] for x in entries}=={"355","428"} and len(entries)==2)
    for entry in entries:
        profile=entry["profile"];model=PROFILES[profile]
        qctx=audit.job(entry,quick)
        qb,qmeta=audit.archive(entry["artifact"])
        _,mirror=audit.custody(qb,qmeta,qctx,{n:None for n in (
            "observer-restored.json","observer-live32.json","observer-frozen35.json",
            "observer-frozen35-original.json","pytorch-install.json")},"quick "+profile)
        restored=decode(mirror["observer-restored.json"])
        audit.check("quick exact published bytes, no invented rebuild",
                    restored["status"]=="EXACT_PUBLISHED_BYTES_RESTORED_NOT_NEW_BUILD"
                    and restored["native_rebuilt"] is False and restored["profile"]==profile
                    and restored["source_sha256"]==model["source"] and restored["native_sha256"]==model["image"])
        archive_sha={'355':'07d32eb46016ee8d222475de68117d84eeded0e014d488f7ce1936fbcafb0898',
                     '428':'458fab50d7eb4c9685fd400053dd6746225ccae348e75c758d1e0cbd6d8fb6fe'}
        membermap={m['path']:m for m in restored['members']}
        audit.check('quick exact published archive and complete member set '+profile,
                    restored['archive_sha256']==archive_sha[profile]
                    and len(membermap)==len(restored['members'])=={'355':30,'428':33}[profile])
        audit.restored_members[profile]=membermap
        live=audit.live32(mirror["observer-live32.json"],model,"quick "+profile+" live32",baseline32)
        d,w=audit.frozen35(mirror["observer-frozen35.json"],mirror["observer-frozen35-original.json"],
                         model,"observer-frozen35-original.json","quick "+profile+" frozen35",baseline35)
        audit.pip_binding(mirror['pytorch-install.json'],[live['oracle_provenance'],d['oracle_provenance']],'quick '+profile)
        audit.journals(qb,d["rows"],"quick "+profile+" frozen35")
        controls=one_suffix(qb,"/native-controls/report.json")
        negative=one_suffix(qb,"/negative-controls/report.json")
        control=decode(controls);neg=decode(negative)
        audit.check("quick actual three native controls "+profile,
                    control["status"]=="PASS" and control["cases"]==len(control['rows'])==3
                    and control["frames"]==sum(r['frames'] for r in control['rows'])==13
                    and [r['case'] for r in control['rows']]==[
                        'private-gradient-reset-keeps-real-high-slot-and-rollback',
                        'same-frame-nongrad-create-reset-keeps-incarnation-counter',
                        'original-Linear-and-MSE-count3-plus-three-private-gradients']
                    and control["profile"]["name"]==model["name"]
                    and control["profile"]["native_sha256"]==model["image"]
                    and control["profile"]["source_sha256"]==model["source"]
                    and control['native_image_unchanged'] is True
                    and control['source_custody']['observer']==OBSERVER
                    and control['source_custody']['test']=='55d57b8fea82556f6b5e03a5f2112ddaf689b8dfec8e93f53609b0637a337509'
                    and all(r["status"]=="PASS" for r in control["rows"]))
        audit.journals(qb,control["rows"],"quick "+profile+" native3")
        audit.check("quick exact four positive plus18 negative "+profile,
                    neg["status"]=="PASS_OBSERVER_CONTROLS_ONLY" and neg["failures"]==0
                    and neg["positive_cases"]==len(neg["positive_rows"])==4
                    and neg["negative_cases"]==len(neg["negative_rows"])==18
                    and neg["observer_sha256"]==OBSERVER and neg["controls_sha256"]==PEER
                    and neg["expected_profile"]==model["name"]
                    and neg["original_journals_unchanged"] is True and neg["observer_source_unchanged"] is True)
        audit.check('quick copied controls do not impersonate native execution '+profile,
                    all(neg[k] is False for k in ('native_executed','Torch_executed','native_memory_read','native_memory_written')))
        audit.check('quick original source bytes in artifact '+profile,
                    sha(one_suffix(qb,'/negative-controls/executed-controls.py'))==PEER
                    and sha(one_suffix(qb,'/negative-controls/observer-under-test.py'))==OBSERVER)
        audit.check('quick four positive categories '+profile,
                    {r['case'] for r in neg['positive_rows']}=={'materialization','compound-construction',
                    'reset-with-private-gradient','failed-frame-rollback'}
                    and all(r['status']=='PASS' for r in neg['positive_rows']))
        chosen={}
        for r in neg['positive_rows']:
            entry=event_input(qb,r['journal'],r['event'])
            audit.check('quick positive binds actual native journal '+profile+'/'+r['case'],
                        sha(canonical(entry))==r['input_sha256'] and entry['recorded_result']==r['result']
                        and entry['before']['profile']==entry['after']['profile']==model['name'])
            pure_result=pure.verify_transition(entry['before'],entry['after'],entry['tickets'],entry['commands'],entry['status'])
            audit.check('pure validation of original positive JSON '+profile+'/'+r['case'],pure_result==entry['recorded_result'])
            chosen[r['case']]=entry
        audit.check('quick18 exact source-defined order and rules '+profile,
                    [(r['case'],r['expected_rule']) for r in neg['negative_rows']]==[(n,r) for n,_,r in rules])
        for r,(name,base,rule) in zip(neg["negative_rows"],rules):
            audit.check("exact negative rule "+profile+"/"+r["case"],
                        r["status"]=="PASS_EXPECTED_REJECTION" and r["actual_rule"]==r["expected_rule"])
            path_suffix="/negative-inputs/"+r["case"]+".json.gz"
            packed=one_suffix(qb,path_suffix)
            audit.check("negative copy raw hash "+r["case"],sha(packed)==r["compressed_sha256"]
                        and sha(gzip.decompress(packed))==r["input_sha256"])
            changed=decode(gzip.decompress(packed));original=chosen[base]
            audit.check('one-sided isolated copied snapshot '+profile+'/'+name,
                        changed['before']==original['before'] and canonical(changed)!=canonical(original)
                        and r['source_event']=={'journal':original['path'],'event':original['ordinal']}
                        and all(changed[k]==original[k] for k in ('path','ordinal','commands','status','recorded_result')))
            try:
                pure.verify_transition(changed['before'],changed['after'],changed['tickets'],changed['commands'],changed['status'])
            except AssertionError as error:
                detail=error.args[0] if error.args else None
                audit.check('pure exact rejection on archived JSON '+profile+'/'+name,
                            isinstance(detail,dict) and detail.get('observer_rule')==rule)
            else:
                audit.check('pure exact rejection on archived JSON '+profile+'/'+name,False)
        for path,meta in neg['input_files'].items():
            key=original_build_relative(path)
            audit.check('quick negative-control original input custody '+key,
                        key in qb and len(qb[key])==meta['bytes'] and sha(qb[key])==meta['sha256'])
        quick_summaries.append({"profile":profile,"run":qctx["run"]["id"],"job":qctx["job"]["id"],
                                "native_controls":3,"positive_controls":4,"negative_controls":18,"live32":32,"frozen35":35,
                                'additional_pure_JSON_checks':22,'additional_native_or_Torch_executions':0})
    return quick_summaries

def event_input(members,path,ordinal):
    key=original_build_relative(path)
    events=decode(members[key]);event=events[ordinal]
    required={event['before'],event['after']};snapshots={}
    packed=members[str(PurePosixPath(key).with_name('snapshots.jsonl.gz'))]
    with gzip.GzipFile(fileobj=io.BytesIO(packed),mode='rb') as f:
        for line in f:
            item=decode(line)
            if item['sha256'] in required:
                assert sha(canonical(item['snapshot']))==item['sha256']
                snapshots[item['sha256']]=item['snapshot']
    assert set(snapshots)==required
    return {'path':path,'ordinal':ordinal,'before':snapshots[event['before']],
            'after':snapshots[event['after']],'tickets':event['tickets'],'commands':event['commands'],
            'status':event['expected_status'],'recorded_result':event['result']}

def one_suffix(members,suffix):
    matches=[raw for name,raw in members.items() if name.endswith(suffix)]
    assert len(matches)==1,(suffix,len(matches))
    return matches[0]

def native_components(audit,reports,sources):
    a=reports["hosted-gradient-objects-native.json"]
    audit.check("355 actual16-component cold qualification",
                a["status"]=="QUALIFIED_COMPONENT_WITH_OPEN_SCOPE"
                and a["source_sha256"]==PROFILES["355"]["source"] and a["native_sha256"]==PROFILES["355"]["image"]
                and a["formal_report_count"]==len(a["reports"])==16 and a["all_input_custody_unchanged"] is True)
    package=decode(sources['tools/gradient_objects/package-manifest.json'])
    audit.check("355 original124 package inputs",len(package['files'])==124
                and a['package_manifest_sha256']==sha(sources['tools/gradient_objects/package-manifest.json'])
                and all(plain_sha(x) for x in a["inputs_sha256"].values()))
    for relative,digest in package['files'].items():
        matches=[v for p,v in a['inputs_sha256'].items() if p.endswith('/'+relative)]
        audit.check('355 original package member executed custody '+relative,matches==[digest])
    audit.check("355 executed16 original child scripts",
                a["cold_qualification"]["step_count"]==len(a["cold_qualification"]["steps"])==16
                and all(s["exit_code"]==0 and plain_sha(s["report_sha256"]) for s in a["cold_qualification"]["steps"]))
    base355=decode(sources['tools/gradient_objects/profile.json'])
    built=a['build']
    for k in ('functions','blocks','instructions','descriptor_bytes','source_sha256','native_sha256'):
        audit.check('355 exact native build field '+k,built[k]==base355[k])
    audit.check('355 all eight unit records retained',len(built['units'])==len(base355['units'])==8)
    for actual,pinned in zip(built['units'],base355['units']):
        audit.check('355 complete pinned unit identity '+pinned['name'],
                    set(actual)==set(pinned)|{'source_bytes','object_bytes'}
                    and {k:actual[k] for k in pinned}==pinned
                    and isinstance(actual['source_bytes'],int) and 0<actual['source_bytes']<=1048576
                    and isinstance(actual['object_bytes'],int) and 0<actual['object_bytes']<=8388608)
    audit.check('355 cold overlay/full-authoring true native reproduction',
                a['cold_qualification']['cold_overlay_and_full_authoring_image_identical'] is True
                and a['cold_qualification']['all_package_sources_unchanged'] is True)
    stepnames=['cold-HIA-overlay-build','author-public-foundation','reproduce-full-authoring-lineage',
        'original-public-ten','incoming-25-observations','alias-edge-12-observations',
        'native-ownership-lifetimes','typed-result-references','signed-zero-13','partial-16',
        'presence-8','gradient-clear-10','build-handoff-optimizer','execute-handoff-optimizer',
        'build-handoff-public-foundation','execute-handoff-public-foundation']
    audit.check('355 exact16 original command order',[s['name'] for s in a['cold_qualification']['steps']]==stepnames)
    for step in a['cold_qualification']['steps']:
        name=step['name'];child=a['reports'][name]
        audit.check('355 child receipt identity '+name,
                    a['original_report_sha256'][name]['sha256']==step['report_sha256']
                    and a['cold_qualification']['suite_reports'][name]['sha256']==step['report_sha256']
                    and child['status']==step['report_status'])
        if 'oracle_provenance' in child:audit.provenance(child['oracle_provenance'],'355 '+name)
    audit.check("355 retained original finite qualification boundaries",
                a["original_10_counts"]=={"qualified":9,"partial":1,"failed":0}
                and a["incoming_25_counts"]=={"qualified":22,"unrepresented":3,"failed":0}
                and a["alias_edge_12_counts"]=={"qualified":12,"failed":0}
                and a["whole_project_decision"]=="HOLD" and a["full_pytorch_rewrite_complete"] is False)
    d=reports["hosted-gradient-adam-distributions-native.json"]
    audit.check("428 default fresh producer actually executed",
                d["status"]=="QUALIFIED_COMPONENT_WITH_OPEN_SCOPE" and d["source_sha256"]==PROFILES["428"]["source"]
                and d["native_sha256"]==PROFILES["428"]["image"] and d["producer_executed_this_invocation"] is True
                and d["producer_steps_verified"]==17 and d["native_gates_executed"]==3
                and d["independent_runners_executed"]==4 and d["strict_extreme_stride_cases"]==8
                and d["strict_extreme_stride_fields"]==344 and d["input_file_count"]==len(d["checked_inputs"])==427
                and d["input_custody_after"] is True)
    audit.check("428 published aggregator source",
                d["integration_script_sha256"]==sha(sources["tests/qualify_gradient_adam_distributions.py"]))
    producer=d["producer"]
    audit.check("428 producer is not reused review mode",producer["mode"]=="executed_here")
    original=producer["original_report"]
    tree=ast.parse(sources["tests/qualify_gradient_adam_distributions.py"])
    steps=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign)
               and any(isinstance(t,ast.Name) and t.id=="STEPS" for t in n.targets))
    audit.check("all17 actual producer commands",original["step_count"]==len(original["steps"])==17
                and [x["name"] for x in original["steps"]]==[x[0] for x in steps])
    audit.check("aggregator default eight orchestration invocations",len(d["execution_steps"])==8
                and [x['name'] for x in d['execution_steps']]==['producer-17','native-review-3',
                     'zero-merge-mathematical','actual-zero-merge','actual-scalar-add-nan','native-cross',
                     'extreme-stride-observe','extreme-stride-compare']
                and all(x["exit_code"]==0 for x in d["execution_steps"]))
    audit.check('428 all427 custody entries structurally valid',
                all(plain_sha(v['sha256']) and isinstance(v['bytes'],int) and v['bytes']>=0
                    for v in d['checked_inputs'].values()))
    for step,(name,script,_) in zip(original["steps"],steps):
        audit.check("producer actual step "+name,step["exit_code"]==0
                    and Path(step["command"][4]).name==script and step["command"][1:4]==["-I","-S","-B"])
        child=producer["children"][name]
        audit.check("producer child bound "+name,child["sha256"]==step["report_sha256"]
                    and child["report"]["status"]==step["report_status"])
        audit.check('producer executed script and output custody '+name,
                    step['command'][4] in d['checked_inputs']
                    and d['checked_inputs'][child['path']]['sha256']==child['sha256']
                    and d['checked_inputs'][child['path']]['bytes']==child['bytes'])
        if 'oracle_provenance' in child['report']:audit.provenance(child['report']['oracle_provenance'],'428 '+name)
    current=producer['children']['cold-native-build']['report']
    base428=decode(sources['tools/gradient_adam_distributions/profile.json'])
    for k in ('functions','blocks','instructions','descriptor_bytes','source_sha256','native_sha256','units'):
        audit.check('428 exact nine-unit cold build field '+k,current[k]==base428[k])
    for name,counts in (("distribution-atomic-183",{"PASS":161,"OPEN_TRANSACTION_DIFFERENCE":4,"OPEN_UNREPRESENTED":18}),
                        ("distribution-explicit-183",{"PASS":165,"OPEN_UNREPRESENTED":18})):
        r=producer["children"][name]["report"]
        audit.check("fixed distribution183 "+name,r["reference_cases"]==len(r["rows"])==183
                    and dict(Counter(x["status"] for x in r["rows"]))==r["counts"]==counts)
    union=d["optimizer_reference_union"]
    audit.check("optimizer original24 is23 plus partial14 only",
                union["original_reference_cases"]==24 and union["qualified_exposed_scope"]==23
                and union["partial_cases"]==1 and union["partial_one_based_indices"]==[14]
                and union["qualified_one_based_indices"]==[x for x in range(1,25) if x!=14]
                and union["original_18_plus_1_partial_plus_5_open_report_unchanged"] is True)
    ledger=d["distribution_reference_ledger"]
    audit.check("all18 remaining distribution gaps preserved",
                ledger["original_cases"]==183 and ledger["unrepresented_zero_based_indices"]==OPEN_DIST
                and ledger["late_error_zero_based_indices"]==ATOMIC_DIFF)
    native=d["native_review"]
    audit.check("three independent native gates",len(native["children"])==3)
    audit.check('three native gates actually executed',native['original_report']['suite_count']==3
                and native['original_report']['input_custody_after'] is True
                and all(x['exit']==0 and x['status']=='PASS' for x in native['original_report']['suites']))
    recomp=native['children']['recompile']['report']
    audit.check('428 complete function-to-unit cold admission',
                recomp['complete_core_body_count']==len(recomp['core_body_bindings'])==428
                and len(recomp['units'])==9 and recomp['source_to_units_exact_once'] is True
                and recomp['all_object_and_image_bytes_identical'] is True)
    audit.check("four peer runners remain four",len(d["peer_review"])==4)
    strict=d["extreme_stride"]["comparison"]["report"]
    audit.check("strict8 extreme layout fields",
                [strict[k] for k in ("cases","passing_cases","failing_cases","field_comparisons","different_fields")]==[8,8,0,344,0])
    audit.check('strict8 uses this execution observation',
                strict['native_observations_sha256']==d['extreme_stride']['observation']['sha256'])
    audit.check("original4 layout failures retained",d["retained_history"]["candidate04_extreme_stride_failure"]["report"]["status"]=="FAIL"
                and d["retained_history"]["candidate04_extreme_stride_failure"]["report"]["failing_cases"]==4)
    audit.check("new composition not full closure",d["readiness"]=="HOLD"
                and d["all_rng_complete"] is d["full_optimizer_complete"] is d["full_rewrite_complete"] is False)
    old=reports["hosted-adam-distributions-native.json"]
    audit.check("old378 ledger remains22 plus1 plus1",dict(Counter(r["status"] for r in old["optimizer_original_24_ledger"]))
                =={"QUALIFIED_EXPOSED_SCOPE":22,"PARTIAL_WITH_RETAINED_NONLEAF_OPEN":1,"OPEN_NOT_EXECUTED":1})

def history_review(audit,spec):
    # Exact Git blobs from the published af33 commit, not caller-supplied goldens.
    blobs={
        'README.md':'d9b967791a473c5c43cc5995598d8138e8e41387',
        'copy-correction-review.json':'7fcac270f09ddd7a91fd464e93991aeb02e0df59',
        'first-artifact-admission.json':'2d7a519baa3871fa234084e8ee290686b46f324e',
        'first-jobs.json':'75a69bfd16e5537e2f5569bfcf4c6837d82aed16',
        'first-merge-checkout.json':'0097342de8d13895eb613a1ed20385fa7e0fcfba',
        'observer-355-first.zip':'8aa6f8c5e555da39d332dfae1fc4f57fe5eccc7e',
        'observer-428-first.zip':'f0d34b4307a754e3e798990401553d977226a96d',
        'repaired-355.json':'0ba5b8931997ca2f10669e24dcdd2b1a9bf3359c',
        'repaired-428.json':'7d5ac2ce057d519ba3e44ec0ed4a691905d810e5',
        'repaired-admission.json':'65051e91ec41b6da21cc8adfd33a935c56447081',
        'repaired-controls-exact.tar.xz':'10f12e35c606c736a62afabe62495fbe4c7cdd11'}
    root=Path(spec['directory'])
    if not root.is_absolute():root=audit.root/root
    original={}
    for name,blob in blobs.items():
        raw=audit.read(root/name)
        audit.check('history exact published Git blob '+name,
                    hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob)
        original[name]=raw
    admission=decode(original['first-artifact-admission.json'])
    audit.check('first real failure is not reclassified',
                admission['status']=='ORIGINAL_FAILED_CI_ARTIFACT_BYTES_VERIFIED'
                and admission['source_head']=='1d45ea911399b2d4815edc6bb7bf970e2b6e2e68'
                and admission['run']==43860338027 and admission['report_bytes_reserialized'] is False)
    jobs=decode(original['first-jobs.json'])['jobs']
    audit.check('both first quick jobs remain actual failures',len(jobs)==2
                and {j['id'] for j in jobs}=={133275184676,133275185212}
                and all(j['run_id']==43860338027 and j['status']=='completed'
                        and j['conclusion']=='failure' for j in jobs))
    for j in jobs:
        steps={s['name']:s['conclusion'] for s in j['steps']}
        audit.check('first failed copy did not execute Torch or postconditions '+str(j['id']),
                    steps['Execute three native ownership and allocation controls']=='success'
                    and steps['Reject eighteen independent corruptions of copied real snapshots']=='failure'
                    and steps['Install the independent pinned PyTorch CPU oracle']=='skipped'
                    and steps['Execute the unchanged live joint oracle with 32 cases']=='skipped'
                    and steps['Execute all 35 unchanged cases with exact private-node accounting']=='skipped')
    old_checker=None
    for row in admission['rows']:
        profile=row['profile'];raw=original['observer-'+profile+'-first.zip']
        audit.check('first failed artifact exact bytes '+profile,len(raw)==row['zip_bytes'] and sha(raw)==row['zip_sha256'])
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names=[m.filename for m in z.infolist() if not m.is_dir()]
            audit.check('first failed artifact unique35 entries '+profile,len(names)==len(set(names))==35)
            files={member_name(name):z.read(name) for name in names}
        custody=decode(one_suffix(files,'/custody.json'))
        audit.check('first PARTIAL/missing results preserved '+profile,
                    custody['status']=='PARTIAL' and custody['file_count']==34
                    and custody['missing']==row['missing'] and not custody['errors'])
        for f in custody['files']:
            audit.check('first original member '+profile+'/'+f['path'],
                        len(files[f['path']])==f['size'] and sha(files[f['path']])==f['sha256'])
        failed=decode(one_suffix(files,'/negative-controls/report.json'))
        native=decode(one_suffix(files,'/native-controls/report.json'))
        audit.check('first actual native3 succeeded, copied control17 failed '+profile,
                    native['status']=='PASS' and native['cases']==3 and native['frames']==13
                    and failed['status']=='FAIL_OBSERVER_CONTROLS'
                    and len(failed['positive_rows'])==4 and len(failed['negative_rows'])==16
                    and failed['error']==row['negative_error'])
        old_checker=one_suffix(files,'/negative-controls/executed-controls.py')
        audit.check('first exact48e checker retained '+profile,
                    sha(old_checker)=='48e3b0592585ba721265536fc11cfb460d870e88cb20dbfd9ecb41d6f299215f')
    archive=original['repaired-controls-exact.tar.xz']
    files={}
    with tarfile.open(fileobj=io.BytesIO(archive),mode='r:*') as tar:
        for member in tar:
            if member.isdir():continue
            audit.check('history regular archive member '+member.name,member.isfile())
            name=member_name(member.name)
            audit.check('history no duplicate member '+name,name not in files)
            files[name]=tar.extractfile(member).read()
    audit.check('complete47-member repaired evidence',len(files)==47)
    repaired=decode(original['repaired-admission.json'])
    audit.check('Mac repair is copied-snapshot execution only',
                repaired['status']=='BOTH_FIRST_HOSTED_JOURNAL_NEGATIVE_REPLAYS_PASS'
                and repaired['new_native_or_Torch_execution'] is False
                and repaired['old_failed_reports_reclassified'] is False)
    for row in repaired['rows']:
        profile='355' if row['profile']==PROFILES['355']['name'] else '428'
        raw=original['repaired-'+profile+'.json']
        audit.check('Mac repair complete original raw report '+profile,
                    sha(raw)==row['report_sha256'] and len(raw)==row['report_bytes']
                    and any(value==raw for value in files.values()))
        d=decode(raw)
        audit.check('Mac exact4 plus18 repair remains separately scoped '+profile,
                    d['status']=='PASS_OBSERVER_CONTROLS_ONLY' and d['positive_cases']==4
                    and d['negative_cases']==18 and d['controls_sha256']==PEER
                    and d['observer_sha256']==OBSERVER and d['native_executed'] is d['Torch_executed'] is False)
        for r in d['negative_rows']:
            packed=[v for n,v in files.items() if profile in PurePosixPath(n).parts and n.endswith('/'+r['case']+'.json.gz')]
            audit.check('Mac exact copied negative bytes '+profile+'/'+r['case'],
                        len(packed)==1 and sha(packed[0])==r['compressed_sha256']
                        and sha(gzip.decompress(packed[0]))==r['input_sha256'])
    corrected=[v for v in files.values() if sha(v)==PEER]
    audit.check('corrected source physically preserved',bool(corrected))
    new_piece=b"""            # Content-addressed journals may share the same dict for equal
            # before/after snapshots. JSON round-trip makes the two sides
            # independent; deepcopy would preserve that alias.
            changed=json.loads(canonical(original))
            assert changed['before'] is not changed['after']
            mutate(changed)
            assert canonical(changed['before'])==canonical(original['before']), 'mutation changed before snapshot'
"""
    old_piece=b"""            changed=copy.deepcopy(original)
            mutate(changed)
"""
    audit.check('exact one-site inverse restores first failed source',
                corrected[0].count(new_piece)==1 and corrected[0].replace(new_piece,old_piece)==old_checker)
    review=decode(original['copy-correction-review.json'])
    audit.check('published correction does not change native/numeric gates',
                review['observer_changed'] is review['native_changed'] is review['numeric_or_version_assertions_changed'] is False)
    audit.summary['historical_first_control_failure_retained']=True
    if spec.get('native_first_failure_zip'):
        raw=audit.read(spec['native_first_failure_zip'])
        audit.check('30ea original failing native ZIP bytes retained',len(raw)==3914565
                    and sha(raw)=='ac4f9a5af8cbb8ec58db4ee5a015b8789b159835dd370ea213fe8dd582e0ed8c'
                    and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
                    =='9df79eef1065ab33c7c71c2b580295551add45bc')
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names=[m.filename for m in z.infolist() if not m.is_dir()]
            audit.check('30ea unique exact54 reports plus manifest',len(names)==len(set(names))==55)
            files={member_name(name):z.read(name) for name in names}
        manifest=decode(files['ci-report-manifest.json'])
        audit.check('30ea original partial export is still failure',
                    manifest['status']=='PARTIAL' and manifest['job_status_before_export']=='failure'
                    and manifest['github']['HEPTATORCH_SOURCE_HEAD_SHA']=='30ea38d3572a18ede2dda80decc2fcb4a83feb84'
                    and manifest['github']['GITHUB_RUN_ID']=='43850393178')
        for row in manifest['reports']:
            audit.check('30ea original report byte identity '+row['path'],
                        len(files[row['path']])==row['bytes'] and sha(files[row['path']])==row['sha256'])
        raw_failed=files['pytorch-gradient-objects-frozen35.json']
        audit.check('30ea unchanged original failed35 report',len(raw_failed)==3022230
                    and sha(raw_failed)=='46c861a63c1dae54b257ea78b140f442868e0848f347d6cc10fec38013d08dbe')
        failed=decode(raw_failed)
        audit.check('30ea original3PASS32FAIL is not relabeled',failed['status']=='FAIL'
                    and failed['cases']==35 and failed['failed_cases']==32
                    and Counter(r['status'] for r in failed['rows'])=={'PASS':3,'FAIL':32}
                    and failed['frames']==6344 and failed['compared_values']==2590274
                    and failed['direct_parameter_absolute_version_mismatches']==0
                    and failed['explicit_state_absolute_version_differences']==283)
        audit.summary['original30ea_failure_re_read_as_original_bytes']=True
        audit.summary['original30ea_skipped_postconditions_not_retroactively_passed']=True
    else:
        audit.summary['original30ea_failure_re_read_as_original_bytes']=False
        audit.summary['original30ea_prior_read_only_diagnostic_sha256']='6ed189f77dbc16fede0838d854fcc5fb9da71c62e2c92072ab108aab727c6b85'

if __name__=="__main__": raise SystemExit(main())
