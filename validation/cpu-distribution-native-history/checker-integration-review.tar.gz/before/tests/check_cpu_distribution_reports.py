"""Bind complete native distribution reports to frozen source and owner profiles."""
from pathlib import Path
import argparse
import hashlib
import json
import tarfile

PROFILES = {
    'atomic': ('cpu_distributions', 'cpu-distributions-package.sha256',
               '0a22dd70b079851d6ae109fb9f28fe77a4e002f211fcbc0fc79a0c0c35afc867', 37,
               'a72a98232c7b7f10efa67ce29b21e417c58201383bef9aacc266fe247ff356ce',
               '515790a191b3db1ecbfcb3f2afab644ef980b51ad85c5d6daf1b8c5a9a5a6e28'),
    'partial': ('cpu_distributions_partial', 'cpu-distributions-partial-package.sha256',
                '49992445c887ba87eeda65acf38c8b22ce2b01bca59bb893f3b4a7acd3644737', 28,
                '55ed0c6e16317add03974c01ffd85e38684fc535a3e5cb6423ed043f4217f05b',
                'bb4c25e35a170f08276d464db6b630cf03765ff816e6a9ca9aa1651360a1ccf4'),
}
REFERENCE = 'c624f5c4762b1c71e7053aba9af55aaa3d8bbaae5aa100b0a6df5f44f58da467'


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            value.update(block)
    return value.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('atomic-build', 'build', 'atomic-review', 'review', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    a = parser.parse_args()
    for key, value in vars(a).items():
        setattr(a, key, value.resolve())
    repo = Path(__file__).resolve().parents[1]
    files = {Path(__file__)}
    custody, builds, reproductions, summaries, reports, report_hashes, archives = {}, {}, {}, {}, {}, {}, {}
    for label, (directory, manifest_name, manifest_pin, count, source_pin, image_pin) in PROFILES.items():
        package = repo / 'tools' / directory
        manifest = repo / 'validation' / manifest_name
        assert digest(manifest) == manifest_pin
        rows = manifest.read_text().splitlines()
        assert len(rows) == count
        files.add(manifest)
        for row in rows:
            expected, relative = row.split('  ', 1)
            path = (repo / relative).resolve()
            assert path.is_relative_to(repo) and digest(path) == expected, relative
            files.add(path)
        profile = json.loads((package / 'profile.json').read_bytes())
        directory = a.atomic_build if label == 'atomic' else a.build
        for name, expected in (('runtime.hepta', source_pin), ('tensor-distributions-session', image_pin)):
            path = directory / name
            assert digest(path) == expected
            files.add(path)
        build = json.loads((directory / 'build.json').read_bytes())
        reproduction = json.loads((directory / 'reproduction.json').read_bytes())
        files.update((directory / 'build.json', directory / 'reproduction.json'))
        assert build['status'] == reproduction['status'] == 'PASS'
        assert build['runtime_source_sha256'] == reproduction['runtime_source_sha256'] == source_pin
        assert build['executable_sha256'] == reproduction['executable_sha256'] == image_pin
        assert reproduction['all_source_object_image_bytes_identical'] is True and reproduction['native_units'] == 7
        assert build['host_production_numerical_runtime'] is False and build['aggregate_core_host_check'] is False
        assert build['rng_module_byte_identical'] and build['owner_module_byte_identical'] and build['input_custody_after']
        assert build['compiler_sha256'] == 'b1c851a0896fa6071f800e1146c3c27d0c6cf85059e9a6281b46d42908a3f59f'
        assert build['linker_sha256'] == 'aae650e8822ef0b1e74d15108ad1d0f17ec791205ed5a158ec60b709f48f0e16'
        assert len(build['units']) == len(profile['units']) == 7
        for unit, original in zip(build['units'], profile['units'], strict=True):
            for key in ('name', 'source_sha256', 'object_sha256'):
                assert unit[key] == original[key]
            for extension, key in (('.hepta', 'source_sha256'), ('.o', 'object_sha256')):
                path = directory / (unit['name'] + extension)
                assert digest(path) == unit[key]
                files.add(path)
        if label == 'partial':
            assert build['all_predecessor_dist_functions_byte_identical'] and build['old_atomic_commands_80_85_unchanged']
            assert reproduction['old_atomic_function_bodies_identical']
        builds[label], reproductions[label] = build, reproduction
        history = json.loads((package / 'evidence/native-observations.json').read_bytes())
        archive = package / 'evidence' / history['archive']
        assert digest(archive) == history['archive_sha256'] and archive.stat().st_size == history['archive_bytes']
        members = history.get('members', history.get('files'))
        expected = {row['path']: row for row in members}
        assert len(expected) == len(members)
        seen = set()
        with tarfile.open(archive, 'r:gz') as tf:
            for member in tf:
                assert member.isfile() and member.name in expected and member.name not in seen
                row = expected[member.name]
                stream = tf.extractfile(member)
                value, size = hashlib.sha256(), 0
                for block in iter(lambda: stream.read(1 << 20), b''):
                    value.update(block); size += len(block)
                assert value.hexdigest() == row['sha256'] and size == row['bytes'] and member.mode == row['mode']
                seen.add(member.name)
        assert seen == set(expected)
        archives[label] = {'archive_sha256': history['archive_sha256'], 'archive_bytes': archive.stat().st_size,
                           'verified_members': len(seen), 'original_bytes': history['original_bytes']}
        review = a.atomic_review if label == 'atomic' else a.review
        summary_path = review / 'report.json'
        summary = json.loads(summary_path.read_bytes())
        files.add(summary_path)
        assert summary['status'] == 'PARTIAL' and summary['native_scoped_qualification_passed'] is True
        assert summary['runtime_source_sha256'] == source_pin and summary['executable_sha256'] == image_pin
        assert summary['all_rng_complete'] is False and summary['all_tensor_dtypes_complete'] is False
        assert summary['full_pytorch_rewrite_complete'] is False
        expected_names = (['actual-reference', 'native-controls', 'probability-math', 'owned-entry', 'typed-handoffs']
                          if label == 'atomic' else ['atomic-reference', 'explicit-reference', 'four-late-errors',
                                                   'native-controls', 'owned-entry', 'typed-handoffs'])
        assert [row['name'] for row in summary['suites']] == expected_names
        for row in summary['suites']:
            path = review / row['name'] / 'report.json'
            assert row['exit_code'] == 0 and digest(path) == row['report_sha256']
            report = json.loads(path.read_bytes())
            assert report['status'] == row['status']
            key = label + '/' + row['name']
            reports[key], report_hashes[key] = report, digest(path)
            files.add(path)
        summaries[label] = summary
    before = {str(path): digest(path) for path in sorted(files)}
    reference_path = repo / 'tools/cpu_distributions/evidence/torch-bernoulli-dropout.json'
    assert digest(reference_path) == REFERENCE
    reference = json.loads(reference_path.read_bytes())
    assert reference['status'] == 'OBSERVED' and reference['cases'] == 183
    assert len(reference['oracle_provenance']['checks']) == 11 and all(v is True for v in reference['oracle_provenance']['checks'].values())
    atomic = reports['atomic/actual-reference']
    old = reports['partial/atomic-reference']
    explicit = reports['partial/explicit-reference']
    for row in (atomic, old, explicit):
        assert row['reference_sha256'] == REFERENCE and row['reference_cases'] == 183 and row['input_custody_after'] is True
        assert len(row['actual_reference_provenance_checks']) == 11 and all(v is True for v in row['actual_reference_provenance_checks'].values())
        assert row['status'] == 'PARTIAL' and row['all_rng_complete'] is False and row['full_pytorch_rewrite_complete'] is False
    assert atomic['counts'] == old['counts'] == {'PASS': 161, 'OPEN_TRANSACTION_DIFFERENCE': 4, 'OPEN_UNREPRESENTED': 18}
    assert explicit['counts'] == {'PASS': 165, 'OPEN_UNREPRESENTED': 18}
    assert [(x['index'], x['name'], x['status']) for x in atomic['rows']] == [(x['index'], x['name'], x['status']) for x in old['rows']]
    changed = []
    for previous, current in zip(old['rows'], explicit['rows'], strict=True):
        assert (previous['index'], previous['name']) == (current['index'], current['name'])
        if previous['status'] != current['status']:
            assert previous['status'] == 'OPEN_TRANSACTION_DIFFERENCE' and current['status'] == 'PASS'
            changed.append(current['index'])
    assert changed == [101, 103, 105, 179]
    for row in (atomic, old):
        assert (row['frames_before_EOF'], row['exact_float32_words'], row['complete_state_comparisons'], row['rollback_bytes_compared']) == (1894, 49069, 182, 10861632)
    assert (explicit['frames_before_EOF'], explicit['exact_float32_words'], explicit['complete_state_comparisons'], explicit['rollback_bytes_compared']) == (1908, 49085, 182, 9051360)
    expected_counts = {
        'atomic/native-controls': {'case_count': 4, 'frames_before_EOF': 98, 'exact_value_comparisons': 1000023, 'rollback_bytes': 44193488},
        'atomic/probability-math': {'cases': 106488, 'native_u64_results': 425952, 'production_objects_byte_identical': True},
        'atomic/owned-entry': {'cases': 86, 'probe_processes': 84, 'live_frames': 6},
        'atomic/typed-handoffs': {'cases': 2, 'frames': 9, 'all_source_custody_unchanged': True},
        'partial/four-late-errors': {'case_count': 4, 'frames_before_EOF': 91, 'exact_words': 32, 'complete_state_comparisons': 16, 'rollback_bytes': 2413696},
        'partial/native-controls': {'case_count': 14, 'frames_before_EOF': 159, 'exact_float32_words': 108153, 'complete_state_comparisons': 19, 'rollback_bytes_compared': 6034240},
        'partial/owned-entry': {'raw_processes': 34, 'live_frames': 20, 'complete_owner_bytes_compared': 10559920},
        'partial/typed-handoffs': {'cases': 2, 'frames': 9, 'all_source_custody_unchanged': True},
    }
    for name, expected in expected_counts.items():
        assert reports[name]['status'] == 'PASS'
        assert all(reports[name][key] == value for key, value in expected.items()), name
    after = {str(path): digest(path) for path in sorted(files)}
    assert before == after
    result = {
        'schema': 'heptatorch.integrated-cpu-distributions-qualification.v1', 'status': 'PARTIAL',
        'native_scoped_qualification_passed': True,
        'atomic_source_sha256': PROFILES['atomic'][4], 'atomic_executable_sha256': PROFILES['atomic'][5],
        'source_sha256': PROFILES['partial'][4], 'executable_sha256': PROFILES['partial'][5],
        'reference_sha256': REFERENCE, 'oracle_provenance': reference['oracle_provenance'],
        'source_custody_before': before, 'source_custody_after': after,
        'cold_reproduction': reproductions, 'verified_failure_and_execution_archives': archives,
        'summaries': summaries, 'reports': reports, 'original_report_sha256': report_hashes,
        'original_actual_torch_observations': 183, 'explicit_strict_mapped_passes': 165,
        'open_unrepresented': 18, 'old_atomic_transaction_differences_retained': 4,
        'closed_explicit_error_indices_zero_based': changed,
        'host_numeric_production_runtime': False, 'full_aggregate_host_admission_claimed': False,
        'real_module_and_linked_call_graph_admission': True,
        'all_rng_complete': False, 'all_tensor_dtypes_complete': False,
        'full_pytorch_rewrite_complete': False, 'pytorch_api_denominator': 2590,
        'count_policy': 'Repeated profiles, finite native controls and case subsets are not added into upstream schema coverage.',
        'open_scope': ['8 float64 probability Tensor observations', '2 integer output dtype observations',
                       '8 distinct native_dropout bool-mask observations', 'normal-grad-mode tracked nonleaf inplace',
                       'kind-8 Optimizer and public-gradient-object composition', 'all other unsupported schemas'],
    }
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'status': 'PARTIAL', 'native_scoped_qualification_passed': True,
                      'reports': len(reports), 'actual_cases': 183, 'strict_mapped': 165,
                      'unrepresented': 18, 'report_sha256': digest(a.output)}))


if __name__ == '__main__':
    main()
