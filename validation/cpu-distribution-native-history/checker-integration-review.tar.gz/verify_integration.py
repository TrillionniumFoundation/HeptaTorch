#!/usr/bin/env python3
"""Small report-admission and integration checks; no native suite is rerun."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import re
import subprocess
import sys
import yaml

HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'HeptaTorch-cpu-distributions'
SHA=lambda b:hashlib.sha256(b).hexdigest()


def main():
    checker=REPO/'tests/check_cpu_distribution_reports.py'
    inputs={checker:checker.read_bytes()}
    old=json.loads((REPO/'build/distributions-root-integrated.json').read_text())
    reference=json.loads((REPO/'tools/cpu_distributions/evidence/torch-bernoulli-dropout.json').read_text())
    spec=importlib.util.spec_from_file_location('reviewed_distribution_checker',checker)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    profiles={};peers={};members={}
    for label,folder in [('atomic','cpu_distributions'),('partial','cpu_distributions_partial')]:
        package=REPO/'tools'/folder
        profiles[label]=json.loads((package/'profile.json').read_text())
        peers[label]=json.loads((package/'handoff-peer-pins.json').read_text())
        history=json.loads((package/'evidence/native-observations.json').read_text())
        members[label]={r['path']:r for r in history.get('members',history.get('files'))}
    for key,r in old['reports'].items():
        label=key.split('/')[0]
        module.check_report_identity(key,r,profiles[label],peers[label],members[label])
    for key in ['atomic/actual-reference','partial/atomic-reference','partial/explicit-reference']:
        module.check_reference_rows(old['reports'][key],reference,explicit=key.endswith('explicit-reference'))
    attacks=[]
    mutations=[
      ('production-image','atomic/probability-math',lambda r:r.update(production_executable_sha256='0'*64)),
      ('current-image','atomic/typed-handoffs',lambda r:r.update(current_executable_sha256='0'*64)),
      ('peer-source','partial/typed-handoffs',lambda r:r['peers'][0].update(peer_source_sha256='0'*64)),
      ('renamed-source','partial/typed-handoffs',lambda r:r['source_bindings'][0].update(renamed_sha256='0'*64)),
      ('qualification-image','partial/owned-entry',lambda r:r.update(probe_sha256='0'*64)),
      ('wrong-schema','atomic/native-controls',lambda r:r.update(schema='unrelated-report.v1')),
    ]
    for name,key,mutate in mutations:
        r=copy.deepcopy(old['reports'][key]);mutate(r);label=key.split('/')[0]
        try:module.check_report_identity(key,r,profiles[label],peers[label],members[label])
        except AssertionError:attacks.append({'name':name,'rejected':True,'native_executed':False})
        else:raise AssertionError(name)
    for name in ['wrong-reference-family','duplicate-index','open-row-swapped-with-pass']:
        r=copy.deepcopy(old['reports']['partial/explicit-reference'])
        if name=='wrong-reference-family':r['rows'][0]['family']='unrelated-family'
        elif name=='duplicate-index':r['rows'][182]['index']=181
        else:r['rows'][0]['status'],r['rows'][4]['status']=r['rows'][4]['status'],r['rows'][0]['status']
        try:module.check_reference_rows(r,reference,explicit=True)
        except AssertionError:attacks.append({'name':name,'rejected':True,'native_executed':False})
        else:raise AssertionError(name)
    for name in ['wrong-subreport-source','truncated-reference-rows']:
        d=HERE/name
        command=[sys.executable,'-I','-S','-B',str(checker),
          '--atomic-build',str(REPO/'build/cpu-distributions'),'--build',str(REPO/'build/cpu-distributions-partial'),
          '--atomic-review',str(d/'atomic'),'--review',str(d/'partial'),'--output',str(d/'new-checker-result.json')]
        result=subprocess.run(command,capture_output=True,timeout=30)
        (d/'new.stdout').write_bytes(result.stdout);(d/'new.stderr').write_bytes(result.stderr)
        assert result.returncode!=0 and not (d/'new-checker-result.json').exists(),name
        attacks.append({'name':name,'original_checker_exit':0,'new_checker_exit':result.returncode,'rejected':True,'native_executed':False})
    old_raw=(HERE/'before/.github/workflows/native.yml').read_bytes()
    new_raw=(REPO/'.github/workflows/native.yml').read_bytes()
    previous=yaml.safe_load(old_raw);current=yaml.safe_load(new_raw)
    old_steps=previous['jobs']['native']['steps'];new_steps=current['jobs']['native']['steps']
    names={s['name'] for s in old_steps};added=[s for s in new_steps if s['name'] not in names]
    assert len(added)==3 and [s for s in new_steps if s['name'] in names]==old_steps
    starts=list(re.finditer(rb'^      - name: (.+)\n',new_raw,re.M));restored=new_raw[:starts[0].start()]
    for index,start in enumerate(starts):
        end=starts[index+1].start() if index+1<len(starts) else len(new_raw)
        if start.group(1).decode() in names:restored+=new_raw[start.start():end]
    assert restored==old_raw,'Old workflow bytes changed'
    for step in added:
        result=subprocess.run(['bash','-n'],input=step['run'].encode(),capture_output=True)
        assert result.returncode==0,result.stderr
    command=['make','-n','-o','build/tensor-rng-nullable/reproduction.json','-o','build/tensor-rng-composition/reproduction.json',
             '-o','build/gradient-materialization/build.json','cpu-distributions','cpu-distributions-partial','test-cpu-distributions']
    result=subprocess.run(command,cwd=REPO,capture_output=True);(HERE/'make-dry-run.stdout').write_bytes(result.stdout);(HERE/'make-dry-run.stderr').write_bytes(result.stderr)
    assert result.returncode==0,result.stderr
    for fragment in [b'tools/cpu_distributions/rebuild.py',b'tools/cpu_distributions_partial/rebuild.py',
                     b'tools/cpu_distributions/qualify.py',b'tools/cpu_distributions_partial/qualify.py',b'tests/check_cpu_distribution_reports.py']:
        assert result.stdout.count(fragment)==1,fragment
    shell=subprocess.run(['sh','-n'],input=result.stdout,capture_output=True);assert shell.returncode==0,shell.stderr
    for relative in ['validation/cpu-distributions-package.sha256','validation/cpu-distributions-partial-package.sha256']:
        for line in (REPO/relative).read_text().splitlines():
            digest,name=line.split('  ',1);assert SHA((REPO/name).read_bytes())==digest
    expected_oracles={
      'tests/pytorch_tensor_rng_backward_oracle.py':'554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160',
      'tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py':'149b41c455444edeb8d25d0ad98045e29683e780f37f7e210e7985242d359597'}
    for name,digest in expected_oracles.items():assert SHA((REPO/name).read_bytes())==digest
    for path,raw in inputs.items():assert path.read_bytes()==raw
    report={'schema':'heptatorch.distribution-integration-review.v1','status':'PASS',
      'checker_sha256':SHA(inputs[checker]),'old_checker_sha256':SHA((HERE/'before/tests/check_cpu_distribution_reports.py').read_bytes()),
      'old_report_sha256':SHA((REPO/'build/distributions-root-integrated.json').read_bytes()),
      'genuine_11_report_identities_passed':True,'genuine_183_rows_passed':True,'negative_controls':attacks,
      'old_workflow_steps':len(old_steps),'new_workflow_steps':len(new_steps),'added_steps':[s['name'] for s in added],
      'all_old_workflow_bytes_unchanged_after_removing_new_steps':True,'new_step_shell_syntax_passed':True,
      'make_dry_run_passed':True,'make_dry_run_shell_syntax_passed':True,
      'all_65_frozen_package_files_unchanged':True,'both_existing_oracle_sources_unchanged':True,
      'native_suites_rerun_by_this_review':False,'actual_PyTorch_rerun_by_this_review':False}
    (HERE/'review.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
