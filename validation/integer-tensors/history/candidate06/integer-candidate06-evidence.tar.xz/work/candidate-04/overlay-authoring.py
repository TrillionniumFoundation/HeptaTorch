def dtype_width(code: u64) -> u64:
    if code == 0:
        return 4
    if code == 1:
        return 1
    if code == 2:
        return 8
    return 0

def typed_descriptor(w: mutbuf, rank: u64, shape: u64, requires: u64, own: u64, dtype: u64) -> u64:
    if getw(w, 0) != 0:
        return 0
    width = dtype_width(dtype)
    if width == 0:
        return terror(w, 7)
    if dtype != 0 and requires == 1:
        return terror(w, 5)
    if rank > 4 or requires > 1:
        return terror(w, 2)
    location = object_address(w, shape)
    if location > length(w) or 32 > length(w) - location:
        return terror(w, 2)
    slot = getw(w, 8)
    if slot >= 65536:
        return terror(w, 3)
    if getw(w, 120) == 18446744073709551615:
        return terror(w, 8)
    n = 1
    axis = 0
    while axis < rank:
        d = getw(w, shape + axis * 8)
        if d > 262144:
            return terror(w, 3)
        if d == 0:
            n = 0
        axis = axis + 1
    if n != 0:
        axis = 0
        while axis < rank:
            n = n * getw(w, shape + axis * 8)
            if n > 16777216:
                return terror(w, 3)
            axis = axis + 1
    if descriptor_page(w, slot) == 0:
        return 0
    if storage_capacity(w, 1, 0) == 0:
        return 0
    if own != 0 and storage_capacity(w, 3, 0) == 0:
        return 0
    p = dptr(w, slot)
    memory_fill(w, p, 640, 0)
    putw(w, p, rank)
    putw(w, p + 576, dtype)
    putw(w, p + 8, n)
    putw(w, p + 32, requires)
    putw(w, p + 64, choose(own != 0, slot, 0))
    putw(w, p + 200, 2)
    putw(w, p + 304, 1)
    putw(w, 120, getw(w, 120) + 1)
    putw(w, p + 320, getw(w, 120))
    axis = rank
    stride = 1
    while axis > 0:
        axis = axis - 1
        d = getw(w, shape + axis * 8)
        putw(w, p + 96 + axis * 8, d)
        putw(w, p + 128 + axis * 8, stride)
        if d != 0:
            stride = stride * d
    tid = so_slot_new(w, 1)
    tp = so_slot_lookup(w, 1, tid)
    putw(w, p + 192, tid)
    putw(w, p + 240, 1)
    so_uput(w, tp + 48, slot)
    if own != 0:
        data = alloc(w, n * width)
        if getw(w, 0) != 0:
            return 0
        hid = getw(w, 80)
        hp = so_slot_lookup(w, 6, hid)
        sid = so_uget(w, hp + 16)
        vid = so_slot_new(w, 3)
        vp = so_slot_lookup(w, 3, vid)
        so_uput(w, vp + 24, 1)
        so_uput(w, tp + 16, sid)
        so_uput(w, tp + 24, vid)
        so_uput(w, tp + 40, n * width)
        putw(w, p + 16, data)
        putw(w, p + 216, sid)
        putw(w, p + 224, vid)
        so_slot_drop(w, 6, hid)
    if requires != 0:
        work = alloc(w, n * 4)
        if getw(w, 0) != 0:
            return 0
        putw(w, p + 160, work)
        putw(w, p + 256, getw(w, 80))
    putw(w, 8, slot + 1)
    return slot

def typed_from_wire(s: readbuf, w: mutbuf, dtype: u64, config: u64, end: u64) -> u64:
    width = dtype_width(dtype)
    if width == 0:
        return terror(w, 7)
    if config < end or config > length(s) or 64 > length(s) - config or (config & 7 != 0):
        return terror(w, 100)
    rank = getr(s, config)
    requires = getr(s, config + 8)
    if rank > 4 or requires > 1:
        return terror(w, 2)
    if dtype != 0 and requires != 0:
        return terror(w, 5)
    axis = 0
    n = 1
    while axis < 4:
        dim = getr(s, config + 16 + axis * 8)
        if axis >= rank:
            if dim != 0:
                return terror(w, 2)
        else:
            if dim > 262144:
                return terror(w, 3)
            if dim == 0:
                n = 0
        putw(w, 2048 + axis * 8, dim)
        axis = axis + 1
    if n != 0:
        axis = 0
        while axis < rank:
            n = n * getw(w, 2048 + axis * 8)
            if n > 16777216:
                return terror(w, 3)
            axis = axis + 1
    data = getr(s, config + 48)
    size = getr(s, config + 56)
    if size != n * width or data < end or data > length(s) or (size > length(s) - data):
        return terror(w, 100)
    if dtype == 1:
        i = 0
        while i < size:
            if byte(s, data + i) > 1:
                return terror(w, 7)
            i = i + 1
    t = typed_descriptor(w, rank, 2048, requires, 1, dtype)
    if t == 0:
        return 0
    address = object_address(w, getw(w, dptr(w, t) + 16))
    typed_copy_from_wire(w, s, address, data, size)
    return t

def tset(w: mutbuf, t: u64, index: u64, bits: u64) -> u64:
    if valid(w, t) == 0:
        return 0
    p = dptr(w, t)
    code = getw(w, p + 576)
    width = dtype_width(code)
    if width == 0:
        return terror(w, 9)
    if index >= getw(w, p + 8) or (code != 2 and bits > 4294967295):
        return terror(w, 7)
    if code == 1 and bits > 1:
        return terror(w, 7)
    if version_can_bump(w, t, 1) == 0:
        return 0
    typed_store(w, taddr(w, t, index), width, bits)
    return bump_version(w, t)

def typed_fill(w: mutbuf, t: u64, bits: u64, no_grad: u64) -> u64:
    if valid(w, t) == 0:
        return 0
    p = dptr(w, t)
    code = getw(w, p + 576)
    width = dtype_width(code)
    if width == 0 or no_grad > 1 or (code != 2 and bits > 4294967295):
        return terror(w, 7)
    if code == 1 and bits > 1:
        return terror(w, 7)
    if no_grad == 0 and getw(w, p + 32) != 0:
        return terror(w, 5)
    if version_can_bump(w, t, 1) == 0:
        return 0
    i = 0
    while i < getw(w, p + 8):
        typed_store(w, taddr(w, t, i), width, bits)
        i = i + 1
    return bump_version(w, t)

def dtype_audit(w: mutbuf) -> u64:
    status = 0
    i = 1
    while i < getw(w, 8):
        p = dptr(w, i)
        if getw(w, p + 616) != 0:
            status = 9
        i = i + 1
    if status == 0:
        status = history_audit(w)
    i = 1
    while i < getw(w, 8) and status == 0:
        p = dptr(w, i)
        if getw(w, p + 304) != 0:
            code = getw(w, p + 576)
            if code > 2:
                status = 9
            if code != 0 and (getw(w, p + 32) != 0 or getw(w, p + 384) != 0):
                status = 9
            mask = getw(w, p + 584)
            if mask != 0:
                q = private_tensor(w, mask, getw(w, p + 592))
                if q == 0 or getw(w, p + 40) != 42 or getw(w, p + 288) == 0:
                    status = 9
                else:
                    saved = so_saved_live(w, getw(w, p + 288))
                    if saved == 0:
                        status = 9
                    elif so_uget(w, saved + 16) != getw(w, q + 216) or so_uget(w, saved + 24) != getw(w, q + 224):
                        status = 9
                    putw(w, q + 616, getw(w, q + 616) + 1)
            elif getw(w, p + 592) != 0:
                status = 9
        elif getw(w, p + 584) != 0 or getw(w, p + 592) != 0 or getw(w, p + 600) != 0:
            status = 9
        i = i + 1
    i = 1
    while i < getw(w, 8):
        p = dptr(w, i)
        if getw(w, p + 600) != getw(w, p + 616):
            status = 9
        putw(w, p + 616, 0)
        i = i + 1
    return status

def so_audit_records(w: mutbuf) -> u64:
    kind = 1
    while kind <= 8:
        i = 1
        while i <= so_uget(w, 16):
            p = so_slot_at(w, kind, i)
            generation = so_uget(w, p)
            live = so_uget(w, p + 8)
            if generation > 4294967295 or live > 1:
                return 9
            if live == 0:
                j = 16
                while j < 64:
                    if so_uget(w, p + j) != 0:
                        return 9
                    j = j + 8
            else:
                if generation == 0:
                    return 9
                id = so_handle(kind, i, generation)
                if kind == 1 or kind == 5:
                    if kind == 1 and so_tensor_live(w, id) == 0 or (kind == 5 and so_saved_live(w, id) == 0):
                        return 9
                    if so_audit_count(w, 2, so_uget(w, p + 16), 0) != 0 or so_audit_count(w, 3, so_uget(w, p + 24), 16) != 0:
                        return 9
                    if kind == 1 and (so_uget(w, p + 56) > 1 or so_uget(w, p + 48) == 0 or so_uget(w, p + 48) >= getw(w, 8)):
                        return 9
                    if kind == 5 and so_uget(w, p + 56) != 0 and (private_hold(w, so_uget(w, p + 56), 128) == 0):
                        return 9
                if kind == 4 or kind == 6:
                    field = 0
                    if kind == 4:
                        field = 8
                    if so_audit_count(w, 2, so_uget(w, p + 16), field) != 0:
                        return 9
                    j = 32
                    if kind == 4 and so_uget(w, p + 24) > 2:
                        return 9
                    if kind == 6:
                        if so_uget(w, p + 24) > 1:
                            return 9
                        if so_uget(w, p + 32) > 2 or (so_uget(w, p + 24) == 1 and so_uget(w, p + 32) != 0):
                            return 9
                        j = 40
                    while j < 64:
                        if so_uget(w, p + j) != 0:
                            return 9
                        j = j + 8
                if kind == 7:
                    hid = so_uget(w, p + 16)
                    address = private_hold(w, hid, 5056)
                    if address == 0 or rng_state_canonical(w, address) == 0:
                        return 9
                    j = 24
                    while j < 64:
                        if so_uget(w, p + j) != 0:
                            return 9
                        j = j + 8
                    j = 1
                    while j < i:
                        other = so_slot_at(w, 7, j)
                        if so_uget(w, other + 8) == 1 and so_uget(w, other + 16) == hid:
                            return 9
                        j = j + 1
                if kind == 3:
                    j = 32
                    while j < 64:
                        if so_uget(w, p + j) != 0:
                            return 9
                        j = j + 8
            i = i + 1
        kind = kind + 1
    return 0

def entry(s: readbuf, o: mutbuf, w: mutbuf, scratch: mutbuf) -> u32:
    if length(o) < 32:
        return 0
    reply_error(o, 0)
    error = frame_valid(s)
    if error != 0:
        reply_error(o, error)
        return 32
    putw(w, 0, 0)
    putw(w, 48, 0)
    putw(w, 56, 0)
    count = getr(s, 8)
    if count != 0:
        putw(w, 96, 8192)
    end = 32 + count * 64
    i = 0
    at = 32
    halted = 0
    while i < count and halted == 0:
        if at > length(o) - 32:
            putw(o, 24, 3)
            return at
        putw(w, 104, i)
        code = getr(s, 32 + i * 64)
        if code == 106:
            next = integer_scalar_command(s,o,w,32+i*64,at)
        elif code == 105:
            next = integer_dropout_command(s,o,w,scratch,32+i*64,at)
        elif code == 103 or code == 104:
            next = integer_command(s,o,w,32+i*64,at)
        elif code >= 96 and code <= 102:
            next = typed_command(s, o, w, scratch, 32 + i * 64, at, end)
        elif code >= 91 and code <= 94:
            next = gradient_object_command(s, o, w, 32 + i * 64, at)
        elif code >= 71 and code <= 79 or code == 90 or code == 95:
            next = owned_optimizer_command(s, o, w, 32 + i * 64, at, end)
        elif code >= 80 and code <= 89:
            if code == 86 or code == 87:
                next = dist_partial_command(s, o, w, scratch, 32 + i * 64, at)
            else:
                next = dist_command(s, o, w, scratch, 32 + i * 64, at)
        elif code >= 60 and code <= 69:
            next = rng_command(s, o, w, scratch, 32 + i * 64, at, end)
        else:
            next = command(s, o, w, 32 + i * 64, at, end)
        if getw(w, 0) == 0 and getw(w, 3968) != 0:
            graph_collect_since(w, getw(w, 8))
        error = getw(w, 0)
        if error != 0:
            putw(o, 24, error)
            return next
        putw(w, getw(w, 96) + i * 8, getw(o, at + 16))
        if (code == 58 or code == 86 or code == 87) and getw(o, at + 16) != 0:
            halted = 1
        if code == 105 and getw(o,at+32) != 0:
            halted = 1
        at = next
        i = i + 1
        putw(o, 16, i)
    if count != 0:
        fill_range(w, 8192, count * 8, 0)
        putw(w, 96, 0)
        putw(w, 104, 0)
    putw(w, 80, 0)
    if getw(w, 0) != 0:
        reply_error(o, getw(w, 0))
        return 32
    return at

def integer_i64_to_f32(bits:u64) -> u64:
    sign = (bits >> 63) << 31
    magnitude = bits
    if sign != 0:
        magnitude = 0-bits
    if magnitude == 0:
        return 0
    exponent = 0
    scan = magnitude
    while scan > 1:
        scan = scan >> 1
        exponent = exponent+1
    if exponent <= 23:
        mantissa = magnitude << (23-exponent)
    else:
        shift = exponent-23
        mantissa = magnitude >> shift
        remainder = magnitude & ((1 << shift)-1)
        half = 1 << (shift-1)
        if remainder > half or (remainder == half and (mantissa & 1) != 0):
            mantissa = mantissa+1
        if mantissa == 16777216:
            mantissa = mantissa >> 1
            exponent = exponent+1
    return sign | ((exponent+127) << 23) | (mantissa & 8388607)

def integer_as_f32(bits:u64, dtype:u64) -> u64:
    if dtype == 0:
        return bits
    if dtype == 1:
        return choose(bits != 0,1065353216,0)
    return integer_i64_to_f32(bits)

def integer_result_dtype(w:mutbuf, op:u64, a:u64, b:u64) -> u64:
    ca = tensor_dtype(w,a)
    cb = tensor_dtype(w,b)
    if ca > 2 or cb > 2 or (ca != 2 and cb != 2):
        return terror(w,7)
    if op < 1 or op > 7:
        return terror(w,7)
    if op == 2 and (ca == 1 or cb == 1):
        return terror(w,7)
    if op >= 4 and op <= 6 and (ca == 0 or cb == 0):
        return terror(w,7)
    if getw(w,dptr(w,a)+32) != 0 or getw(w,dptr(w,b)+32) != 0:
        return terror(w,5)
    if ca == 0 or cb == 0 or op == 7:
        return 0
    return 2

def integer_scalar_binary(op:u64, a:u64, b:u64, dtype:u64) -> u64:
    if dtype == 0:
        if op == 1:
            return addf(a,b)
        if op == 2:
            return subf(a,b)
        if op == 3:
            return mulf(a,b)
        return divf(a,b)
    if op == 1:
        return a+b
    if op == 2:
        return a-b
    if op == 3:
        return a*b
    if op == 4:
        return a & b
    if op == 5:
        return a | b
    return a ^ b

def integer_pointwise_compare_axes(w:mutbuf, p:u64, pa:u64, pb:u64, left:u64, right:u64) -> u64:
    which = 0
    while which < 2:
        q = choose(which == 1,pb,pa)
        width = dtype_width(getw(w,q+576))
        sa = dist_probability_stride(w,p,q,left)*width
        sb = dist_probability_stride(w,p,q,right)*width
        if sa != 0 and sb != 0:
            aa = sa ^ 9223372036854775808
            bb = sb ^ 9223372036854775808
            if aa < bb:
                return 1
            if aa > bb:
                return 2
            if getw(w,p+96+left*8) > getw(w,p+96+right*8):
                return 2
        which = which+1
    return 0

def integer_target_shape(w:mutbuf, target:u64, rank:u64) -> u64:
    p = dptr(w,target)
    if rank != getw(w,p):
        return terror(w,2)
    axis = 0
    while axis < rank:
        if getw(w,128+axis*8) != getw(w,p+96+axis*8):
            return terror(w,2)
        axis = axis+1
    return 1

def integer_view_end(w:mutbuf, t:u64) -> u64:
    p = dptr(w,t)
    extent = 0
    axis = 0
    while axis < getw(w,p):
        extent = extent+(getw(w,p+96+axis*8)-1)*getw(w,p+128+axis*8)
        axis = axis+1
    return getw(w,p+232)+(extent+1)*dtype_width(getw(w,p+576))

def integer_inplace_overlap(w:mutbuf, a:u64, b:u64) -> u64:
    pa = dptr(w,a)
    pb = dptr(w,b)
    if getw(w,pa+8) == 0 or getw(w,pb+8) == 0:
        return 1
    if dist_no_internal_overlap(w,a) == 0:
        return 0
    if getw(w,pa+216) != getw(w,pb+216):
        return 1
    if getw(w,pa+232) >= integer_view_end(w,b) or getw(w,pb+232) >= integer_view_end(w,a):
        return 1
    if getw(w,pa+232) != getw(w,pb+232) or getw(w,pa+576) != getw(w,pb+576):
        return terror(w,2)
    if incoming_same_shape(w,a,b) == 0:
        return terror(w,2)
    axis = 0
    while axis < getw(w,pa):
        if getw(w,pa+128+axis*8) != getw(w,pb+128+axis*8):
            return terror(w,2)
        axis = axis+1
    return 1

def integer_binary_element(w:mutbuf, op:u64, target:u64, a:u64, b:u64, index:u64) -> u64:
    ca = tensor_dtype(w,a)
    cb = tensor_dtype(w,b)
    dtype = tensor_dtype(w,target)
    av = tget(w,a,bindex(w,target,a,index))
    bv = tget(w,b,bindex(w,target,b,index))
    if dtype == 0:
        av = integer_as_f32(av,ca)
        bv = integer_as_f32(bv,cb)
    else:
        if ca == 1:
            av = choose(av != 0,1,0)
        if cb == 1:
            bv = choose(bv != 0,1,0)
    value = integer_scalar_binary(op,av,bv,dtype)
    return typed_store(w,taddr(w,target,index),dtype_width(dtype),value)

def integer_binary(w:mutbuf, op:u64, a:u64, b:u64, inplace:u64) -> u64:
    if valid(w,a) == 0 or valid(w,b) == 0:
        return 0
    dtype = integer_result_dtype(w,op,a,b)
    if getw(w,0) != 0:
        return 0
    rank = bshape(w,a,b)
    if getw(w,0) != 0:
        return 0
    target = a
    if inplace != 0:
        if tensor_dtype(w,a) != 2 or dtype != 2:
            return terror(w,7)
        if integer_target_shape(w,a,rank) == 0 or integer_inplace_overlap(w,a,b) == 0:
            return 0
        if version_can_bump(w,a,1) == 0:
            return 0
    else:
        target = typed_descriptor(w,rank,128,0,1,dtype)
        if target == 0:
            return 0
        if integer_pointwise_layout(w,target,a,b) == 0:
            return 0
    n = getw(w,dptr(w,target)+8)
    i = 0
    while i < n:
        integer_binary_element(w,op,target,a,b,i)
        i = i+1
    if inplace != 0:
        if bump_version(w,target) == 0:
            return 0
    return target

def integer_command(s:readbuf, o:mutbuf, w:mutbuf, cp:u64, at:u64) -> u64:
    code = getr(s,cp)
    result = 0
    first = getw(w,8)
    if (code != 103 and code != 104) or getr(s,cp+32) != 0 or getr(s,cp+40) != 0 or getr(s,cp+48) != 0 or getr(s,cp+56) != 0:
        terror(w,7)
    if getw(w,0) == 0:
        a = public_node(w,resolve_handle(w,getr(s,cp+16)))
        b = public_node(w,resolve_handle(w,getr(s,cp+24)))
        if a != 0 and b != 0:
            result = integer_binary(w,getr(s,cp+8),a,b,choose(code == 104,1,0))
            if getw(w,0) == 0:
                result = publish_tensor(w,result)
    if getw(w,0) == 0:
        finish_command(w,first)
    status = getw(w,0)
    if status != 0:
        result = 0
    putw(o,at,code)
    putw(o,at+8,status)
    putw(o,at+16,result)
    putw(o,at+24,0)
    return at+32


def integer_dropout_nonempty(w:mutbuf, scratch:mutbuf, input:u64, generator:u64, probability:u64, training:u64, o:mutbuf, at:u64) -> u64:
    p = dptr(w,input)
    n = getw(w,p+8)
    if n > 1000000:
        return terror(w,3)
    data = rng_object(w,generator)
    if data == 0:
        return 0
    complement = 0
    if training != 0:
        if dist_prob64_valid(probability) == 0:
            return terror(w,7)
        complement = dist_complement64(probability)
    mask = typed_descriptor(w,getw(w,p),p+96,0,1,1)
    if mask == 0 or dist_dense_layout(w,mask,input,1) == 0:
        return 0
    output = typed_descriptor(w,getw(w,p),p+96,0,1,2)
    if output == 0:
        return 0
    if training == 0:
        if dist_dense_layout(w,output,input,1) == 0:
            return 0
    else:
        if integer_pointwise_layout(w,output,input,mask) == 0:
            return 0
    if native_dropout_fill_mask(w,scratch,mask,data,complement,training) == 0:
        return 0
    i = 0
    while i < n:
        if training == 0:
            typed_store(w,taddr(w,output,i),8,tget(w,input,i))
        else:
            integer_binary_element(w,3,output,input,mask,i)
        i = i+1
    if training != 0:
        return 12
    putw(o,at+16,publish_tensor(w,output))
    putw(o,at+40,publish_tensor(w,mask))
    return 0

def integer_native_dropout(w:mutbuf, scratch:mutbuf, input:u64, generator:u64, probability:u64, training:u64, o:mutbuf, at:u64) -> u64:
    if valid(w,input) == 0:
        return 0
    if tensor_dtype(w,input) != 2 or training > 2:
        return terror(w,7)
    if rng_object(w,generator) == 0:
        return 0
    p = dptr(w,input)
    if getw(w,p+8) != 0:
        return integer_dropout_nonempty(w,scratch,input,generator,probability,training,o,at)
    mask = typed_descriptor(w,getw(w,p),p+96,0,1,2)
    if mask == 0 or dist_dense_layout(w,mask,input,1) == 0:
        return 0
    putw(o,at+16,publish_tensor(w,input))
    putw(o,at+40,publish_tensor(w,mask))
    return 0

def integer_dropout_command(s:readbuf, o:mutbuf, w:mutbuf, scratch:mutbuf, cp:u64, at:u64) -> u64:
    first = getw(w,8)
    error = 0
    payload = 0
    putw(o,at,105)
    putw(o,at+8,0)
    putw(o,at+16,0)
    putw(o,at+24,0)
    if getr(s,cp+40) != 0 or getr(s,cp+48) != 0 or getr(s,cp+56) != 0:
        terror(w,7)
    if at+32 > length(o) or 16 > length(o)-at-32:
        terror(w,3)
    if getw(w,0) == 0:
        putw(o,at+32,0)
        putw(o,at+40,0)
        input = public_node(w,resolve_handle(w,getr(s,cp+8)))
        if input != 0:
            error = integer_native_dropout(w,scratch,input,resolve_handle(w,getr(s,cp+16)),getr(s,cp+24),getr(s,cp+32),o,at)
        if getw(w,0) == 0:
            if finish_command(w,first) != 0:
                putw(o,at+32,error)
                payload = 16
    status = getw(w,0)
    if status != 0:
        putw(o,at+16,0)
        payload = 0
    putw(o,at+8,status)
    putw(o,at+24,payload)
    return at+32+payload


def integer_scalar_add(w:mutbuf, target:u64, scalar:u64) -> u64:
    if valid(w,target) == 0:
        return 0
    if tensor_dtype(w,target) != 2:
        return terror(w,7)
    if dist_no_internal_overlap(w,target) == 0:
        return 0
    if version_can_bump(w,target,1) == 0:
        return 0
    n = getw(w,dptr(w,target)+8)
    index = 0
    while index < n:
        value = tget(w,target,index)+scalar
        typed_store(w,taddr(w,target,index),8,value)
        index = index+1
    if bump_version(w,target) == 0:
        return 0
    return target

def integer_scalar_command(s:readbuf, o:mutbuf, w:mutbuf, cp:u64, at:u64) -> u64:
    first = getw(w,8)
    result = 0
    if getr(s,cp) != 106 or getr(s,cp+24) != 0 or getr(s,cp+32) != 0 or getr(s,cp+40) != 0 or getr(s,cp+48) != 0 or getr(s,cp+56) != 0:
        terror(w,7)
    if getw(w,0) == 0:
        target = public_node(w,resolve_handle(w,getr(s,cp+8)))
        if target != 0:
            result = integer_scalar_add(w,target,getr(s,cp+16))
            if getw(w,0) == 0:
                result = publish_tensor(w,result)
    if getw(w,0) == 0:
        finish_command(w,first)
    status = getw(w,0)
    if status != 0:
        result = 0
    putw(o,at,106)
    putw(o,at+8,status)
    putw(o,at+16,result)
    putw(o,at+24,0)
    return at+32
