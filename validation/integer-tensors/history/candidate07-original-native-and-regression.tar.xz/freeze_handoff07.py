"""Freeze immutable producer source and original native evidence; never rerun it."""
import hashlib
import json
import lzma
from pathlib import Path
import shutil
import stat
import tarfile

B = Path(__file__).resolve().parent
PERSISTENT = Path('/workspace/scratch/d26699e25fea/integer-tensor-checkpoints')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def archive_verify(path, members):
    seen = set()
    with tarfile.open(path, 'r:xz') as tar:
        for item in tar:
            assert item.isfile() and item.name in members and item.name not in seen
            pin = members[item.name]
            raw = tar.extractfile(item).read()
            assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256'] and item.mode == pin['mode'], item.name
            seen.add(item.name)
    assert seen == set(members)
    with lzma.open(path, 'rb') as reader:
        while reader.read(1048576):
            pass


def archive_files(path, files):
    assert not path.exists()
    members = {}
    with lzma.open(path, 'wb', preset=3) as xz:
        with tarfile.open(fileobj=xz, mode='w|') as tar:
            for name, source in sorted(files.items()):
                raw = source.read_bytes()
                info = tar.gettarinfo(str(source), arcname=name)
                assert info.isfile()
                members[name] = {'bytes': len(raw), 'sha256': sha(raw),
                                 'mode': stat.S_IMODE(source.stat().st_mode)}
                with source.open('rb') as reader:
                    tar.addfile(info, reader)
    archive_verify(path, members)
    assert all(sha(source.read_bytes()) == members[name]['sha256']
               and stat.S_IMODE(source.stat().st_mode) == members[name]['mode']
               for name, source in files.items())
    result = {'schema': 'heptatorch.integer07-original-evidence-archive.v1',
              'archive': path.name, 'archive_bytes': path.stat().st_size,
              'archive_sha256': sha(path.read_bytes()), 'members': members,
              'member_count': len(members), 'original_bytes': sum(p['bytes'] for p in members.values()),
              'every_member_size_sha256_mode_verified': True,
              'xz_stream_read_to_complete_EOF': True, 'original_files_deleted': False}
    path.with_suffix('.manifest.json').write_text(json.dumps(result, indent=2) + '\n')
    return {k: v for k, v in result.items() if k != 'members'}


def collect(names):
    files = {}
    for name in names:
        source = B / name
        if source.is_file():
            files[source.relative_to(B).as_posix()] = source
        else:
            assert source.is_dir(), name
            for f in source.rglob('*'):
                if f.is_file():
                    files[f.relative_to(B).as_posix()] = f
    return files


def main():
    out = B / 'handoff-07'
    assert not out.exists()
    package = B / 'package'
    package_manifest = package / 'tools/integer_tensors/package-manifest.json'
    manifest_raw = package_manifest.read_bytes()
    assert sha(manifest_raw) == 'ece14e766825fe0843dfe624fdab8a3b4ec407d27f7a0b5e155e2ee15ee77b71'
    for name, pin in json.loads(manifest_raw)['files'].items():
        f = package / name
        assert len(f.read_bytes()) == pin['bytes'] and sha(f.read_bytes()) == pin['sha256']
        assert stat.S_IMODE(f.stat().st_mode) == pin['mode']
    cold = B / 'portable-cold-07-first'
    cold_raw = (cold / 'report.json').read_bytes()
    assert sha(cold_raw) == 'e0043b88982b2b9427195f082d55c4fc7a1076d0b25ddc2f3d9d6234cf40608c'
    cold_report = json.loads(cold_raw)
    assert cold_report['status'] == 'PASS' and cold_report['step_count'] == 10
    assert cold_report['native_cold_rebuild_executed'] and cold_report['all_package_members_unchanged']
    assert all(row['status'] == 'PASS' and row['exit_code'] == 0 for row in cold_report['steps'])
    shutil.copytree(package, out)
    validation = out / 'validation/integer-tensors'
    history, evidence = validation / 'history', validation / 'evidence'
    history.mkdir(); evidence.mkdir()
    old = []
    for name, archive_name, expected in (
        ('candidate03', 'candidate03-evidence.tar.xz', '7e6039da158e4a3134c343d78b60e325ebcaebf72a9f5ca745497bcd1cda866b'),
        ('candidate06', 'integer-candidate06-evidence.tar.xz', '99ed21f08c57b1827c3e14cf2fec5fe596b58e8577defd36f70276b1acfa347e')):
        source = PERSISTENT / name
        receipt = json.loads((source / 'manifest.json').read_bytes())
        rows = receipt['members']
        members = {row['path']: row for row in rows} if isinstance(rows, list) else rows
        archive = source / archive_name
        assert sha(archive.read_bytes()) == expected
        archive_verify(archive, members)
        shutil.copytree(source, history / name)
        for f in source.rglob('*'):
            if f.is_file():
                copied = history / name / f.relative_to(source)
                assert copied.read_bytes() == f.read_bytes() and stat.S_IMODE(copied.stat().st_mode) == stat.S_IMODE(f.stat().st_mode)
        old.append({'checkpoint': name, 'archive_sha256': expected,
                    'manifest_sha256': sha((source / 'manifest.json').read_bytes()),
                    'member_count': len(members), 'all_original_member_bytes_modes_verified': True})
    initial_names = ['candidate-07', 'storage12-first-07', 'arithmetic30-first-07',
                     'dropout12-first-07', 'alias8-first-07', 'rne-first-07',
                     'promotion20-first-07', 'view-base6-first-07',
                     'legacy523-first-06', 'legacy523-first-07', 'inherited-adapters06']
    initial_names += [f.name for f in B.iterdir() if f.is_file() and f.suffix in ('.py', '.md', '.json', '.stdout', '.stderr')]
    initial = archive_files(history / 'candidate07-original-native-and-regression.tar.xz', collect(initial_names))
    cold_names = ['portable-cold-07-first', 'portable-cold-07-first-command.json',
                  'portable-cold-07-first.stdout', 'portable-cold-07-first.stderr']
    rebuilt = archive_files(evidence / 'portable-cold07-original.tar.xz', collect(cold_names))
    (evidence / 'portable-cold07-report.json').write_bytes(cold_raw)
    (evidence / 'portable-cold07-build.json').write_bytes((cold / 'native/build.json').read_bytes())
    (evidence / 'portable-cold07-profile-rebuild.json').write_bytes((cold / 'native/profile-rebuild.json').read_bytes())
    retained = cold / 'legacy523-behavior12/retained12/report.json'
    if not retained.exists():
        candidates = list((cold / 'legacy523-behavior12').glob('*/report.json'))
        candidates = [p for p in candidates if json.loads(p.read_bytes()).get('status') == 'QUALIFIED_EXPOSED_SCOPE']
        assert len(candidates) == 1
        retained = candidates[0]
    retained_report = json.loads(retained.read_bytes())
    assert retained_report['variants_executed'] == retained_report['variants_qualified'] == 12
    assert retained_report['unexpected_failures'] == 0
    qualification = {'schema': 'heptatorch.integer-tensor-producer-handoff.v1',
                     'status': 'PRODUCER_COLD10_QUALIFIED_INDEPENDENT_INTEGRATION_SEPARATE',
                     'source_sha256': cold_report['source_sha256'], 'native_sha256': cold_report['native_sha256'],
                     'producer_source_package_manifest_sha256': sha(manifest_raw),
                     'cold_report_sha256': sha(cold_raw), 'cold_top_level_gates': 10,
                     'cold_native_units': 11, 'original54_indices_exactly_once': list(range(54)),
                     'legacy_outer_gates': 12, 'legacy_inherited_subgates': 16,
                     'retained12_status': retained_report['status'],
                     'retained12_report_sha256': sha(retained.read_bytes()),
                     'counts_are_overlapping_named_gates_not_unique_API_totals': True,
                     'cold_evidence': rebuilt, 'initial07_evidence': initial, 'historical_checkpoints': old,
                     'independent_integration_reports_required': cold_report['independent_integration_reports_required'],
                     'original_failures_reclassified': False, 'native_OR_Torch_reexecuted_by_packager': False,
                     'global_admission': 'HOLD', 'full_pytorch_rewrite_complete': False,
                     'pytorch_api_denominator': 2590}
    (validation / 'qualification.json').write_text(json.dumps(qualification, indent=2) + '\n')
    (validation / 'README.md').write_text('''# Int64 producer evidence, candidate 07

The source-only manifest in `tools/integer_tensors` remains exactly the manifest
used by the real cold execution. Its historical preparation status is not
rewritten. `qualification.json` and `evidence/portable-cold07-report.json`
record the later actual cold result on that exact package.

All ten named top-level gates passed, including a new eleven-module native
build, the seven producer reference gates, the independent unchanged actual40
runner and twelve legacy behavior gates. The legacy coordinator includes the
original sixteen gates and their unchanged explicit partial/open outcomes.
These are overlapping evidence groups, not a new API denominator.

The cold archive preserves the actual source, executable, every compiled unit,
commands, stdout/stderr, original reports and completed raw archives. No native
execution is replaced by a Python model. Extract an outer archive, then follow
its preserved nested `RESTORE.json` and member manifests to restore raw gate
streams; restoration indexes retain the original execution paths as context.

History is deliberately additive. Candidate03 and candidate06 checkpoint
archives and manifests remain original bytes, including their original pending
scope labels. They contain the initial host observer failures, candidate04
as_strided/view and promotion-layout failures, later fixes and source-specific
results. Candidate06's independently discovered three in-place failures and
candidate07's independent actual40 success remain in the separate root-owned
`validation/int64-inplace-review` namespace. The new initial07 archive also
keeps both separately executed legacy06 and legacy07 suites; neither is
renamed as the other's execution.

Resource and owned-entry gates, legal prior-profile owner transfer, live32,
strict35 and copied-snapshot negative controls have separate owners, source
pins and manifests. They are required by integration and are not inferred from
the producer status. Mixed-dtype AD, public Tensor.to, a Python exception-text
frontend and full PyTorch completion remain unclaimed. The overall project
remains HOLD with denominator 2590.
''')
    all_files = {}
    for f in sorted(out.rglob('*')):
        if not f.is_file():
            continue
        raw = f.read_bytes(); mode = stat.S_IMODE(f.stat().st_mode)
        assert mode in (0o644, 0o755), (f, mode)
        all_files[f.relative_to(out).as_posix()] = {'bytes': len(raw), 'sha256': sha(raw), 'mode': mode}
    final_manifest = {'schema': 'heptatorch.integer-tensor-complete-handoff.v1',
                      'status': qualification['status'], 'files': all_files,
                      'full_pytorch_rewrite_complete': False, 'pytorch_api_denominator': 2590}
    final_path = validation / 'package-manifest.json'
    final_path.write_text(json.dumps(final_manifest, indent=2) + '\n')
    summary = {'path': str(out), 'member_count': len(all_files) + 1,
               'payload_bytes': sum(p['bytes'] for p in all_files.values()),
               'manifest_sha256': sha(final_path.read_bytes()),
               'qualification_sha256': sha((validation / 'qualification.json').read_bytes()),
               'source_manifest_sha256': sha(manifest_raw),
               'source_sha256': qualification['source_sha256'], 'native_sha256': qualification['native_sha256'],
               'raw_archive_bytes': sum(x['archive_bytes'] for x in (initial, rebuilt))}
    (B / 'handoff-07-receipt.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
