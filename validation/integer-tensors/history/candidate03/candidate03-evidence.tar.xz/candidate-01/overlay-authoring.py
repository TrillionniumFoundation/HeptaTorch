def dtype_width(code: u64) -> u64:
    if code == 0:
        return 4
    if code == 1:
        return 1
    if code == 2:
        return 8
    return 0

def typed_descriptor(w: mutbuf, rank: u64, shape: u64, requires: u64, own: u64, dtype: u64) -> u64:
    if getw(w, 0) != 0:
        return 0
    width = dtype_width(dtype)
    if width == 0:
        return terror(w, 7)
    if dtype != 0 and requires == 1:
        return terror(w, 5)
    if rank > 4 or requires > 1:
        return terror(w, 2)
    location = object_address(w, shape)
    if location > length(w) or 32 > length(w) - location:
        return terror(w, 2)
    slot = getw(w, 8)
    if slot >= 65536:
        return terror(w, 3)
    if getw(w, 120) == 18446744073709551615:
        return terror(w, 8)
    n = 1
    axis = 0
    while axis < rank:
        d = getw(w, shape + axis * 8)
        if d > 262144:
            return terror(w, 3)
        if d == 0:
            n = 0
        axis = axis + 1
    if n != 0:
        axis = 0
        while axis < rank:
            n = n * getw(w, shape + axis * 8)
            if n > 16777216:
                return terror(w, 3)
            axis = axis + 1
    if descriptor_page(w, slot) == 0:
        return 0
    if storage_capacity(w, 1, 0) == 0:
        return 0
    if own != 0 and storage_capacity(w, 3, 0) == 0:
        return 0
    p = dptr(w, slot)
    memory_fill(w, p, 640, 0)
    putw(w, p, rank)
    putw(w, p + 576, dtype)
    putw(w, p + 8, n)
    putw(w, p + 32, requires)
    putw(w, p + 64, choose(own != 0, slot, 0))
    putw(w, p + 200, 2)
    putw(w, p + 304, 1)
    putw(w, 120, getw(w, 120) + 1)
    putw(w, p + 320, getw(w, 120))
    axis = rank
    stride = 1
    while axis > 0:
        axis = axis - 1
        d = getw(w, shape + axis * 8)
        putw(w, p + 96 + axis * 8, d)
        putw(w, p + 128 + axis * 8, stride)
        if d != 0:
            stride = stride * d
    tid = so_slot_new(w, 1)
    tp = so_slot_lookup(w, 1, tid)
    putw(w, p + 192, tid)
    putw(w, p + 240, 1)
    so_uput(w, tp + 48, slot)
    if own != 0:
        data = alloc(w, n * width)
        if getw(w, 0) != 0:
            return 0
        hid = getw(w, 80)
        hp = so_slot_lookup(w, 6, hid)
        sid = so_uget(w, hp + 16)
        vid = so_slot_new(w, 3)
        vp = so_slot_lookup(w, 3, vid)
        so_uput(w, vp + 24, 1)
        so_uput(w, tp + 16, sid)
        so_uput(w, tp + 24, vid)
        so_uput(w, tp + 40, n * width)
        putw(w, p + 16, data)
        putw(w, p + 216, sid)
        putw(w, p + 224, vid)
        so_slot_drop(w, 6, hid)
    if requires != 0:
        work = alloc(w, n * 4)
        if getw(w, 0) != 0:
            return 0
        putw(w, p + 160, work)
        putw(w, p + 256, getw(w, 80))
    putw(w, 8, slot + 1)
    return slot

def typed_from_wire(s: readbuf, w: mutbuf, dtype: u64, config: u64, end: u64) -> u64:
    width = dtype_width(dtype)
    if width == 0:
        return terror(w, 7)
    if config < end or config > length(s) or 64 > length(s) - config or (config & 7 != 0):
        return terror(w, 100)
    rank = getr(s, config)
    requires = getr(s, config + 8)
    if rank > 4 or requires > 1:
        return terror(w, 2)
    if dtype != 0 and requires != 0:
        return terror(w, 5)
    axis = 0
    n = 1
    while axis < 4:
        dim = getr(s, config + 16 + axis * 8)
        if axis >= rank:
            if dim != 0:
                return terror(w, 2)
        else:
            if dim > 262144:
                return terror(w, 3)
            if dim == 0:
                n = 0
        putw(w, 2048 + axis * 8, dim)
        axis = axis + 1
    if n != 0:
        axis = 0
        while axis < rank:
            n = n * getw(w, 2048 + axis * 8)
            if n > 16777216:
                return terror(w, 3)
            axis = axis + 1
    data = getr(s, config + 48)
    size = getr(s, config + 56)
    if size != n * width or data < end or data > length(s) or (size > length(s) - data):
        return terror(w, 100)
    if dtype == 1:
        i = 0
        while i < size:
            if byte(s, data + i) > 1:
                return terror(w, 7)
            i = i + 1
    t = typed_descriptor(w, rank, 2048, requires, 1, dtype)
    if t == 0:
        return 0
    address = object_address(w, getw(w, dptr(w, t) + 16))
    typed_copy_from_wire(w, s, address, data, size)
    return t

def tset(w: mutbuf, t: u64, index: u64, bits: u64) -> u64:
    if valid(w, t) == 0:
        return 0
    p = dptr(w, t)
    code = getw(w, p + 576)
    width = dtype_width(code)
    if width == 0:
        return terror(w, 9)
    if index >= getw(w, p + 8) or (code != 2 and bits > 4294967295):
        return terror(w, 7)
    if code == 1 and bits > 1:
        return terror(w, 7)
    if version_can_bump(w, t, 1) == 0:
        return 0
    typed_store(w, taddr(w, t, index), width, bits)
    return bump_version(w, t)

def typed_fill(w: mutbuf, t: u64, bits: u64, no_grad: u64) -> u64:
    if valid(w, t) == 0:
        return 0
    p = dptr(w, t)
    code = getw(w, p + 576)
    width = dtype_width(code)
    if width == 0 or no_grad > 1 or (code != 2 and bits > 4294967295):
        return terror(w, 7)
    if code == 1 and bits > 1:
        return terror(w, 7)
    if no_grad == 0 and getw(w, p + 32) != 0:
        return terror(w, 5)
    if version_can_bump(w, t, 1) == 0:
        return 0
    i = 0
    while i < getw(w, p + 8):
        typed_store(w, taddr(w, t, i), width, bits)
        i = i + 1
    return bump_version(w, t)

def dtype_audit(w: mutbuf) -> u64:
    status = 0
    i = 1
    while i < getw(w, 8):
        p = dptr(w, i)
        if getw(w, p + 616) != 0:
            status = 9
        i = i + 1
    if status == 0:
        status = history_audit(w)
    i = 1
    while i < getw(w, 8) and status == 0:
        p = dptr(w, i)
        if getw(w, p + 304) != 0:
            code = getw(w, p + 576)
            if code > 2:
                status = 9
            if code != 0 and (getw(w, p + 32) != 0 or getw(w, p + 384) != 0):
                status = 9
            mask = getw(w, p + 584)
            if mask != 0:
                q = private_tensor(w, mask, getw(w, p + 592))
                if q == 0 or getw(w, p + 40) != 42 or getw(w, p + 288) == 0:
                    status = 9
                else:
                    saved = so_saved_live(w, getw(w, p + 288))
                    if saved == 0:
                        status = 9
                    elif so_uget(w, saved + 16) != getw(w, q + 216) or so_uget(w, saved + 24) != getw(w, q + 224):
                        status = 9
                    putw(w, q + 616, getw(w, q + 616) + 1)
            elif getw(w, p + 592) != 0:
                status = 9
        elif getw(w, p + 584) != 0 or getw(w, p + 592) != 0 or getw(w, p + 600) != 0:
            status = 9
        i = i + 1
    i = 1
    while i < getw(w, 8):
        p = dptr(w, i)
        if getw(w, p + 600) != getw(w, p + 616):
            status = 9
        putw(w, p + 616, 0)
        i = i + 1
    return status

def so_audit_records(w: mutbuf) -> u64:
    kind = 1
    while kind <= 8:
        i = 1
        while i <= so_uget(w, 16):
            p = so_slot_at(w, kind, i)
            generation = so_uget(w, p)
            live = so_uget(w, p + 8)
            if generation > 4294967295 or live > 1:
                return 9
            if live == 0:
                j = 16
                while j < 64:
                    if so_uget(w, p + j) != 0:
                        return 9
                    j = j + 8
            else:
                if generation == 0:
                    return 9
                id = so_handle(kind, i, generation)
                if kind == 1 or kind == 5:
                    if kind == 1 and so_tensor_live(w, id) == 0 or (kind == 5 and so_saved_live(w, id) == 0):
                        return 9
                    if so_audit_count(w, 2, so_uget(w, p + 16), 0) != 0 or so_audit_count(w, 3, so_uget(w, p + 24), 16) != 0:
                        return 9
                    if kind == 1 and (so_uget(w, p + 56) > 1 or so_uget(w, p + 48) == 0 or so_uget(w, p + 48) >= getw(w, 8)):
                        return 9
                    if kind == 5 and so_uget(w, p + 56) != 0 and (private_hold(w, so_uget(w, p + 56), 128) == 0):
                        return 9
                if kind == 4 or kind == 6:
                    field = 0
                    if kind == 4:
                        field = 8
                    if so_audit_count(w, 2, so_uget(w, p + 16), field) != 0:
                        return 9
                    j = 32
                    if kind == 4 and so_uget(w, p + 24) > 2:
                        return 9
                    if kind == 6:
                        if so_uget(w, p + 24) > 1:
                            return 9
                        if so_uget(w, p + 32) > 2 or (so_uget(w, p + 24) == 1 and so_uget(w, p + 32) != 0):
                            return 9
                        j = 40
                    while j < 64:
                        if so_uget(w, p + j) != 0:
                            return 9
                        j = j + 8
                if kind == 7:
                    hid = so_uget(w, p + 16)
                    address = private_hold(w, hid, 5056)
                    if address == 0 or rng_state_canonical(w, address) == 0:
                        return 9
                    j = 24
                    while j < 64:
                        if so_uget(w, p + j) != 0:
                            return 9
                        j = j + 8
                    j = 1
                    while j < i:
                        other = so_slot_at(w, 7, j)
                        if so_uget(w, other + 8) == 1 and so_uget(w, other + 16) == hid:
                            return 9
                        j = j + 1
                if kind == 3:
                    j = 32
                    while j < 64:
                        if so_uget(w, p + j) != 0:
                            return 9
                        j = j + 8
            i = i + 1
        kind = kind + 1
    return 0
