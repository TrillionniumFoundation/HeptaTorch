"""Keep the fixed36 observer assertions; add the separately observed fourteen recipes."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PARENT = Path('/dev/shm/heptatorch-d26699e25fea/mixed-integer-autograd-extension/replay_actual36.py')
raw = PARENT.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '1609db9c48727cc30ffdc60d70db4d6e1c8b319803dc44d63e6183a2534f8489'
original = raw.decode()
source = original
replacements = [
    ('98f24165401f9aadfd86147113454104ae1c8e969dcc105a16b6cb83d605bdfb',
     'c80ee752f7d7fffe3e808eb4720de0a0447e146e1b20eadc4b219dbbff96c3b5'),
    ('cf3017df475fcb64b4eca771476b8433588e8d2f379b3cc3cb05a9addbd3d165',
     'eca3e273d0afbb3265fca7c73451950d011f41fa1670a7d695911776657296ae'),
    ("reference['cases']==36", "reference['cases']==14"),
    ('range(36)', 'range(14)'), ('0<=i<36', '0<=i<14'),
    ('actual36_native_observer', 'saved_public14_native_observer'),
    ('heptatorch.mixed-integer-autograd-actual36-replay.v1', 'heptatorch.saved-public-lifetime14-replay.v1'),
]
for before, after in replacements:
    assert source.count(before) == 1
    source = source.replace(before, after)
assert source.count('original_integer_Storage_expired') == 2
source = source.replace('original_integer_Storage_expired', 'original_Storage_expired')
begin = source.index('        try:\n            generator=one(60,1729)')
end = source.index("            row['status']='PASS' if not row['differences'] else 'FAIL'", begin)
old_recipe = source[begin:end]
new_recipe = '''        try:
            generator=one(60,1729)['value']
            floating=[1.5,-2.,4.,.5,8.,-4.]
            integers=[2,3,5,7,16777217,-16777219]
            live['x']=create(0,[2,3],floating,1)
            original_name='x' if case['family']=='self' else 'i'
            if case['family']!='self':
                if case['layout']=='integer_holes':
                    base=create(2,[24],list(range(2,26)))
                    live['i']=n.view(base,[2,3],[9,2],1);drop(base)
                else:
                    live['i']=create(2,[2,3],integers)
            weak=one(42,live[original_name])['value']
            snapshot(case['input_before'],'input_before')
            if case['family']=='self':
                live['y']=one(2,3 if case['operation']=='mul' else 4,live['x'],live['x'])['value']
            else:
                left,right=(live['x'],live['i']) if case['float_side']=='left' else (live['i'],live['x'])
                live['y']=one(103,3 if case['operation']=='mul' else 7,left,right)['value']
            live['seed']=create(0,[2,3],[-0.,1.,-1.,.5,2.,-2.])
            eq('forward.accepted',True,case['forward']['accepted'])
            snapshot(case['after_forward'],'after_forward')
            for event in case['events']:
                label=event['event']
                if label=='drop_original_public':
                    drop(live.pop(event['target']))
                elif label=='hold_saved_public':
                    slot={'_saved_self':0,'_saved_other':1}[event['attribute']]
                    expected_status=status_of(event['result'])
                    command=(107,live['y'],slot)
                    if expected_status:
                        rejected(command,expected_status,label+'.'+event['name'])
                    else:
                        token=one(*command)['value']
                        eq(label+'.'+event['name']+'.Tensor_present',token!=0,'tensor' in event['result'])
                        if token:
                            live[event['name']]=token
                elif label=='backward_default':
                    record=one(58,live['y'],live['seed'],0)
                    error,completed,leaves,failing=struct.unpack('<4Q',record['payload'])
                    eq(label+'.runtime_status',error,status_of(event['result']))
                    eq(label+'.record_error',record['value'],error)
                    row.setdefault('backwards',[]).append(dict(event=label,runtime_status=error,
                        completed_nodes=completed,completed_leaves=leaves,failing_opcode=failing))
                elif label in ('drop_graph','drop_graph_after_backward'):
                    drop(live.pop('y'))
                elif label=='drop_all_held_saved':
                    # A native public capability has one token. Both Python aliases are
                    # deliberately removed together in the fixed reference recipe.
                    tokens={live.pop(name) for name in event['names']}
                    for token in tokens:
                        if token not in live.values():
                            drop(token)
                else:
                    raise AssertionError(('unmapped actual event',label))
                snapshot(event['after'],label)
            for token in set(live.values()):drop(token)
            live.clear();one(44,weak);weak=None;one(66,generator);generator=None
            eq('final.audit',one(53)['value'],1)
            stats=struct.unpack('<12Q',one(54)['payload']);eq('final.live_counts',stats[5:11],(0,1,0,0,0,1))
'''
source = source[:begin]+new_recipe+source[end:]
assert source.count("    build=json.loads(inputs[a.build_report.resolve()]);assert build['status']=='PASS'") == 1
insert_point = "    build=json.loads(inputs[a.build_report.resolve()]);assert build['status']=='PASS'"
strict = """
    assert len(build['units'])==11 and build['descriptor_bytes']==640
    assert sha(inputs[a.observer.resolve()])=='ffff67e9c3881d8e5f9ce85f200080641bb9e96d790ca722cc8dd6655fa65abb'
    assert sha(inputs[a.protocol.with_name('owner_client.py').resolve()])=='dee3e4cb25ee1e5e06513e2f33478fbe274d9510ce2aaab9525815c72312946b'"""
source = source.replace(insert_point, insert_point+strict)
source = source.replace('Strict replay of fixed, actually observed mixed F32/I64 autograd recipes.',
                        'Strict replay of fourteen fixed, actually observed public Saved lifetime recipes.')
source = source.replace("'saved_accessor':'107 returns the original Tensor; transient observer public tokens are released immediately'",
                        "'saved_accessor':'107 returns original Tensor; held Saved capabilities survive graph release; temporary observer tokens are released immediately'")
ast.parse(source)
compile(source, 'replay_saved_public14.py', 'exec')
target = ROOT / 'replay_saved_public14.py'
target.write_text(source)

old_ast, new_ast = ast.parse(original), ast.parse(source)
def nested(tree, name):
    return next(node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name==name)
unchanged = ('pack32','pack64','eq','one','create','drop','owner_file','rejected','status_of',
             'node_name','observe_tensor','compare_tensor')
for name in unchanged:
    assert ast.dump(nested(old_ast,name),include_attributes=False)==ast.dump(nested(new_ast,name),include_attributes=False)
old_snapshot=ast.dump(nested(old_ast,'snapshot'),include_attributes=False)
new_snapshot=ast.dump(nested(new_ast,'snapshot'),include_attributes=False)
assert new_snapshot.replace('original_Storage_expired','original_integer_Storage_expired')==old_snapshot
receipt={'schema':'heptatorch.saved-public14.native-replay-authoring.v1',
         'parent_reader_sha256':hashlib.sha256(raw).hexdigest(),
         'reader_sha256':hashlib.sha256(source.encode()).hexdigest(),
         'reader_bytes':len(source.encode()),'unchanged_assertion_helpers':list(unchanged),
         'snapshot_only_reference_weak_field_rename':True,
         'full_owner_rollback_and_full_rng_assertions_retained':True,
         'extra_exact_owner_client_observer_and_unit_count_pins':True,
         'new_recipe_source_sha256':hashlib.sha256(new_recipe.encode()).hexdigest(),
         'reference_sha256':'c80ee752f7d7fffe3e808eb4720de0a0447e146e1b20eadc4b219dbbff96c3b5',
         'native_executed':False,'Torch_executed':False}
(ROOT/'replay-source-review.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt))
