#!/usr/bin/env python3
"""Run this one fixed reference probe; preserve complete original bytes."""
import ast
import gzip
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import sys
import tarfile
import traceback

ROOT = Path('/home/qian-qi/heptatorch-continuation-20261116/runs/saved-public-lifetime14-reference-01')
REPO = Path('/home/qian-qi/heptatorch-continuation-20261116/repo-pr28-repair')
SOURCE = ROOT / 'pytorch_saved_public_lifetime_probe.py'
PIN = 'eca3e273d0afbb3265fca7c73451950d011f41fa1670a7d695911776657296ae'
SHA = lambda b: hashlib.sha256(b).hexdigest()


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + chr(10))


def main():
    assert not (ROOT / 'run.json').exists()
    raw = SOURCE.read_bytes()
    assert SHA(raw) == PIN
    ast.parse(raw)
    compile(raw, str(SOURCE), 'exec')
    input_pins = {
        'tests/pytorch_oracle.py': 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae',
        'compatibility/pytorch-oracle-lock.json': 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944',
        'build/pytorch-install.json': '35ad4841c2f2f94be7ded7f1bcc97f9592f806658ff660bfac5bdc3b0cf986ef',
    }
    for name, pin in input_pins.items():
        assert SHA((REPO / name).read_bytes()) == pin
    common = [sys.executable, '-B', str(SOURCE), '--reference', str(REPO / 'tests/pytorch_oracle.py'),
              '--lock', str(REPO / 'compatibility/pytorch-oracle-lock.json'), '--repo', str(REPO)]
    run = {'schema': 'heptatorch.saved-public-lifetime-fixed-remote-execution.v1',
           'status': 'RUNNING', 'source_sha256': PIN, 'source_bytes': len(raw),
           'python': sys.version, 'executable': sys.executable,
           'commands': [], 'native_executed': False, 'input_pins': input_pins}
    write('run.json', run)
    result_code = 1
    try:
        for label, extra in (('prepare', ['--prepare-only']), ('actual', [])):
            output = ROOT / ('torch-saved-public-lifetime.json' if label == 'actual' else 'prepare.json')
            assert not output.exists()
            argv = common + ['--output', str(output)] + extra
            write(label + '-argv.json', argv)
            row = {'name': label, 'argv': argv, 'process_started': False, 'process_completed': False}
            run['commands'].append(row)
            write('run.json', run)
            with (ROOT / (label + '.stdout')).open('wb') as so, (ROOT / (label + '.stderr')).open('wb') as se:
                process = subprocess.Popen(argv, cwd=REPO, stdout=so, stderr=se)
                row['process_started'] = True
                write('run.json', run)
                try:
                    process.wait(timeout=180)
                except BaseException:
                    process.kill()
                    process.wait()
                    raise
            row.update(process_completed=True, exit_code=process.returncode)
            write('run.json', run)
            assert process.returncode == 0, (label, process.returncode)
            assert SOURCE.read_bytes() == raw
        original = (ROOT / 'torch-saved-public-lifetime.json').read_bytes()
        report = json.loads(original)
        assert report['status'] == 'OBSERVED' and report['cases'] == 14
        assert report['probe_error_count'] == 0 and report['probe_sha256'] == PIN
        assert report['native_executed'] is False and report['torch_executed'] is True
        assert report['source_files_unchanged'] is True
        assert report['oracle_provenance']['status'] == 'PASS'
        checks = report['oracle_provenance']['checks']
        assert len(checks) == 11 and all(v is True for v in checks.values())
        for name, pin in input_pins.items():
            assert SHA((REPO / name).read_bytes()) == pin
        run.update(status='OBSERVED', cases=14, probe_errors=0, reference_sha256=SHA(original),
                   reference_bytes=len(original), provenance_checks=checks, inputs_unchanged=True)
        result_code = 0
    except BaseException as error:
        run.update(status='EXECUTION_OR_PROBE_FAILURE', error=repr(error), traceback=traceback.format_exc())
    finally:
        write('run.json', run)
        files = {}
        for path in sorted(ROOT.rglob('*')):
            if path.is_file() and path.name not in ('original-reference.tar.gz', 'transport.json'):
                assert not path.is_symlink()
                data = path.read_bytes()
                files[path.relative_to(ROOT).as_posix()] = {
                    'bytes': len(data), 'sha256': SHA(data), 'mode': stat.S_IMODE(path.stat().st_mode)}
        archive = ROOT / 'original-reference.tar.gz'
        with archive.open('wb') as outer, gzip.GzipFile(fileobj=outer, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w|') as tar:
            for name, pin in files.items():
                path = ROOT / name
                assert SHA(path.read_bytes()) == pin['sha256']
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = pin['bytes'], pin['mode'], 0
                with path.open('rb') as source:
                    tar.addfile(member, source)
        raw_archive = archive.read_bytes()
        transport = {'status': run['status'], 'source_sha256': PIN,
                     'archive': str(archive), 'archive_sha256': SHA(raw_archive), 'archive_bytes': len(raw_archive),
                     'files': files, 'file_count': len(files),
                     'reference_sha256': run.get('reference_sha256'), 'reference_bytes': run.get('reference_bytes'),
                     'native_executed': False}
        write('transport.json', transport)
        print(json.dumps({k: v for k, v in transport.items() if k != 'files'}))
    return result_code


if __name__ == '__main__':
    raise SystemExit(main())
