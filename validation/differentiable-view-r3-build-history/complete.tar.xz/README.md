# R3 native compilation evidence

One actual native compilation produced all 13 source units, all 13 object files and the linked R3 ELF. The fixed R2 parent and fixed toolchain are explicitly reused, not counted as new cold builds. Original argv, stdout, stderr, durable job responses, before/after input checks, emitted HIA, fragments, maps, linker request and every generated file are included.

The compiler wrapper identifies the result as BUILT_NOT_RUNTIME_QUALIFIED. It executes no target business commands and no Torch. The separately executed original4 and original14 replay results belong to the replay owner and are not relabeled as compiler results.

Every original compiler input is mapped either to this archive or to a precise member in the immutable R1/R2 archive, with original SHA/size/mode and archive SHA/size/mode retained. The two dependency archive bytes and their manifest/previous-verification originals are pinned. This sealer does not rebuild tools or parents, and it does not relabel earlier runtime failures.

The composed source has 627 functions, 8245 blocks, 29636 instructions and 13 units. Its 605 unchanged parent bodies, nine changed parent bodies and 13 added bodies are verified against the actual R2 parent. Global divf/addf, gradient clone/adopt contract, original constructor and retained-hook fix are unchanged. The independent coverage helper is exact.

Count-zero holes delegate to the former divide path. These four new observations do not certify all internal hole or signaling-NaN bit patterns. Scope remains explicitly finite.
