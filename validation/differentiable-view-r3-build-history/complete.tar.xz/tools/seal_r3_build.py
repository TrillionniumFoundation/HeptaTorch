from pathlib import Path
import hashlib,json,stat,tarfile,io,lzma,os,datetime
R=Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
BUILD=R/'differentiable-view-r3-native-build-01'
SRC=R/'differentiable-view-recovered-source-03'
OUT=R/'differentiable-view-r3-build-handoff-01'
OUT.mkdir(mode=0o700,exist_ok=False)
os.umask(0o077)
def sha(b):return hashlib.sha256(b).hexdigest()
def info(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink(),str(p)
 b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(s.st_mode)}
def save(p,x):
 with p.open('x') as f:json.dump(x,f,sort_keys=True,indent=2);f.write('\n')
def check(p,pin):
 x=info(p);assert x['sha256']==pin,(p,x);return x
top=BUILD/'report.json'
check(top,'5af28797a7f6871c97c9751b17875c1c5aaa6b6730bcb7513cccc94c234a5b4b')
report=json.loads(top.read_bytes())
assert report['status']=='BUILT_NOT_RUNTIME_QUALIFIED' and report['all_inputs_unchanged'] is True
assert report['torch_executions']==0 and report['target_runtime_business_executions']==0
assert len(report['child']['units'])==13 and report['child']['functions']==627
assert report['commands'][0]['completed'] is True and report['commands'][0]['returncode']==0
before=json.loads((BUILD/'inputs-before.json').read_bytes())
for p,v in before.items():assert info(Path(p))==v,p
sources={}
def add(name,p):
 assert name not in sources
 p=Path(p);sources[name]=p
 return info(p)
for p in sorted(BUILD.rglob('*')):
 if p.is_file():add('executed/r3-native-build/'+p.relative_to(BUILD).as_posix(),p)
for p in sorted(SRC.iterdir()):
 if p.is_file():add('author-source/'+p.name,p)
add('execution/dview-r3-native-execute-01.py',R/'dview-r3-native-execute-01.py')
add('execution/original-tool-responses.json',R/'dview-r3-build-tool-responses-original.json')
check(R/'dview-r3-build-tool-responses-original.json','bdef1597355e2bbeee532b6985a16e2ef230061ead2ccdebdab1e15cf22e7358')
add('tools/seal_r3_build.py',Path(__file__))
deps=[
 ('R1',R/'differentiable-view-r1-build-handoff-01','091db48eb6792b7f6def09c8080e067e22b32dc56243747b37a578669923d42c',
 '73d92a8e15b3f5fae7a6e5149227ca05e42d0d19c57c2e61b41a360d2f9c42ed','69f09a66ac57269204c34793f3559ef31db7ba107eb70642ad50a8c203e0111f'),
 ('R2',R/'differentiable-view-r2-build-handoff-01','93dbdd40238fc266363cdb76f583d74b6a403ac20cb01cb8dbed3d635cd6833e',
 'a77b7efeb516656170997d025a444091fade2fa8cfbc5dda5c607e3cc92a6eed','e2192a584f6fe3c9488600b4d71824e6a94446664cd1f5d22f7171e54419fe65')]
dependencies={};external={}
for label,d,mpin,apin,vpin in deps:
 mi=check(d/'manifest.json',mpin);ai=check(d/'complete.tar.xz',apin);vi=check(d/'verification.json',vpin)
 mj=json.loads((d/'manifest.json').read_bytes())
 assert mj['file_count']==len(mj['files']) and len(mj['files'])>0
 assert mj['archive']['sha256']==apin and mj['archive']['bytes']==ai['bytes']
 dependencies[label]={'directory':str(d),'archive':ai,'manifest':mi,'original_verification':vi,
 'member_count':mj['file_count'],'original_member_verification_reused':True,
 'reran_dependency_native_or_build':False,'members':mj['files']}
 for n,q in mj['files'].items():external.setdefault((q['sha256'],q['bytes']),[]).append((label,n,q))
 add('dependencies/'+label+'/manifest-original.json',d/'manifest.json')
 add('dependencies/'+label+'/verification-original.json',d/'verification.json')
 add('dependencies/'+label+'/outer-custody-original.json',d/'outer-custody.json')
local={}
for n,p in sources.items():
 q=info(p);local.setdefault((q['sha256'],q['bytes']),[]).append((n,q))
bindings={};captured=0
for path,q in before.items():
 key=(q['sha256'],q['bytes'])
 row={'required_original_input':{'path':path,**q}}
 if key in local:
  n,a=sorted(local[key],key=lambda z:(z[1]['mode']!=q['mode'],z[0]))[0]
  row.update(kind='this_archive',member=n,archive_member=a)
 elif key in external:
  label,n,a=sorted(external[key],key=lambda z:(z[2]['mode']!=q['mode'],z[0]!='R2',z[1]))[0]
  row.update(kind='frozen_dependency_archive',dependency=label,member=n,archive_member=a)
 else:
  captured+=1
  n='captured-inputs/'+f'{captured:04d}-'+Path(path).name
  a=add(n,Path(path));local.setdefault(key,[]).append((n,a))
  row.update(kind='this_archive',member=n,archive_member=a)
 row['restore_original_mode_explicitly']=row['archive_member']['mode']!=q['mode']
 bindings[path]=row
assert set(bindings)==set(before) and bindings
save(OUT/'input-bindings.json',{'schema':'heptatorch.r3-build-complete-input-bindings.v1','bindings':bindings,
 'count':len(bindings),'all_original_input_bytes_modes_unchanged':True,
 'mode_rule':'Original compile input mode and archive member mode are independently pinned. Explicit chmod is required when restoring a differing captured-input mode.',
 'dependencies':{k:{kk:vv for kk,vv in v.items() if kk!='members'} for k,v in dependencies.items()}})
add('input-bindings.json',OUT/'input-bindings.json')
readme="""# R3 native compilation evidence

One actual native compilation produced all 13 source units, all 13 object files and the linked R3 ELF. The fixed R2 parent and fixed toolchain are explicitly reused, not counted as new cold builds. Original argv, stdout, stderr, durable job responses, before/after input checks, emitted HIA, fragments, maps, linker request and every generated file are included.

The compiler wrapper identifies the result as BUILT_NOT_RUNTIME_QUALIFIED. It executes no target business commands and no Torch. The separately executed original4 and original14 replay results belong to the replay owner and are not relabeled as compiler results.

Every original compiler input is mapped either to this archive or to a precise member in the immutable R1/R2 archive, with original SHA/size/mode and archive SHA/size/mode retained. The two dependency archive bytes and their manifest/previous-verification originals are pinned. This sealer does not rebuild tools or parents, and it does not relabel earlier runtime failures.

The composed source has 627 functions, 8245 blocks, 29636 instructions and 13 units. Its 605 unchanged parent bodies, nine changed parent bodies and 13 added bodies are verified against the actual R2 parent. Global divf/addf, gradient clone/adopt contract, original constructor and retained-hook fix are unchanged. The independent coverage helper is exact.

Count-zero holes delegate to the former divide path. These four new observations do not certify all internal hole or signaling-NaN bit patterns. Scope remains explicitly finite.
"""
(OUT/'README.md').write_text(readme);(OUT/'README.md').chmod(0o600);add('README.md',OUT/'README.md')
files={n:info(p) for n,p in sorted(sources.items())}
assert len(files)>90
for n,q in report['output_inventory'].items():
 assert files['executed/r3-native-build/'+n]==q,(n,q)
assert {n[25:] for n in []}==set()
archive=OUT/'complete.tar.xz'
tarbuf=io.BytesIO()
with tarfile.open(fileobj=tarbuf,mode='w',format=tarfile.PAX_FORMAT) as tf:
 for n,p in sorted(sources.items()):
  q=files[n];b=p.read_bytes();assert sha(b)==q['sha256']
  ti=tarfile.TarInfo(n);ti.size=len(b);ti.mode=q['mode'];ti.mtime=0;ti.uid=ti.gid=0
  tf.addfile(ti,io.BytesIO(b))
raw=tarbuf.getvalue();z=lzma.compress(raw,format=lzma.FORMAT_XZ,preset=6)
with archive.open('xb') as f:f.write(z)
archive.chmod(0o600)
manifest={'schema':'heptatorch.differentiable-view-r3-build-handoff.v1','archive':{'path':'complete.tar.xz',**info(archive),'tar_bytes':len(raw),'tar_sha256':sha(raw)},
 'files':files,'file_count':len(files),'expanded_bytes':sum(v['bytes'] for v in files.values()),
 'input_bindings':bindings,'input_binding_count':len(bindings),'captured_missing_dependency_inputs':captured,
 'all_input_bindings_complete':True,'dependencies':{k:{kk:vv for kk,vv in v.items() if kk!='members'} for k,v in dependencies.items()},
 'native_business_executions_by_sealer':0,'Torch_executions_by_sealer':0,
 'original_compile_job':'1a1e6a374ef-392-3bcb','original_build_report_sha256':'5af28797a7f6871c97c9751b17875c1c5aaa6b6730bcb7513cccc94c234a5b4b'}
save(OUT/'manifest.json',manifest)
d=lzma.LZMADecompressor(format=lzma.FORMAT_XZ);tar=d.decompress(z)
assert d.eof and not d.unused_data and sha(tar)==sha(raw) and len(tar)==len(raw)
seen={}
with tarfile.open(fileobj=io.BytesIO(tar),mode='r:') as tf:
 for ti in tf:
  assert ti.isfile() and ti.name in files and ti.name not in seen
  q=files[ti.name];b=tf.extractfile(ti).read()
  assert len(b)==q['bytes'] and sha(b)==q['sha256'] and ti.mode==q['mode']
  seen[ti.name]=q
assert set(seen)==set(files)
for path,row in bindings.items():
 q={k:row['required_original_input'][k] for k in ('bytes','sha256','mode')}
 assert info(Path(path))==q
 a=files[row['member']] if row['kind']=='this_archive' else dependencies[row['dependency']]['members'][row['member']]
 assert a==row['archive_member'] and a['sha256']==q['sha256'] and a['bytes']==q['bytes']
verification={'schema':'heptatorch.build-handoff-byte-verification.v1','status':'PASS',
 'archive_sha256':sha(z),'archive_bytes':len(z),'tar_sha256':sha(raw),'tar_bytes':len(raw),
 'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'file_count':len(files),'expanded_bytes':manifest['expanded_bytes'],
 'all_member_bytes_sizes_modes_verified':True,'single_xz_stream_verified_through_eof':True,
 'all_input_bindings_complete':True,'input_binding_count':len(bindings),'captured_inputs':captured,
 'external_input_bindings':sum(v['kind']=='frozen_dependency_archive' for v in bindings.values()),
 'explicit_input_mode_restorations':sum(v['restore_original_mode_explicitly'] for v in bindings.values()),
 'native_executions':0,'torch_executions':0,'original_compile_status':'BUILT_NOT_RUNTIME_QUALIFIED'}
save(OUT/'verification.json',verification)
outer={'schema':'heptatorch.build-handoff-outer-custody.v1','files':{n:info(OUT/n) for n in ('complete.tar.xz','manifest.json','verification.json')},
 'original_compile_job':'1a1e6a374ef-392-3bcb','native_executions':0,'torch_executions':0,'originals_mode':0o600}
save(OUT/'outer-custody.json',outer)
print(json.dumps({'directory':str(OUT),'verification':verification,'original_files':{n:info(OUT/n) for n in ('complete.tar.xz','manifest.json','verification.json','outer-custody.json')}},sort_keys=True))
