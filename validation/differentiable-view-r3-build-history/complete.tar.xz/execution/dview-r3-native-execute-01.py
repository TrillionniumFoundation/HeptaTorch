#!/usr/bin/env python3
"""Unique R3 compilation; every planned 13 units is compiled with the fixed tools."""
from pathlib import Path
import datetime,hashlib,json,os,re,stat,subprocess,sys,traceback
BASE=Path('/home/qian-qi/heptatorch-continuation-20261116')
RUNS=BASE/'runs'
REPO=RUNS/'to-view-recovery-integration-01/repo'
SRC=RUNS/'differentiable-view-recovered-source-03'
PREVIOUS=RUNS/'differentiable-view-r2-native-build-01/candidate-r2'
TOOLRUN=RUNS/'dview-r1-fixed-toolchain-cold-02'
TOOLS=TOOLRUN/'hepta-stack-budget/native'
OUT=RUNS/'differentiable-view-r3-native-build-01'
CHILD=OUT/'candidate-r3'
SOURCE='3c2c0a125bcac6d47075bf58fc3f78c0e7b9a0b1370757981b99dcd3793b21c6'
os.umask(0o077)
OUT.mkdir(mode=0o700,exist_ok=False)
LOG=OUT/'execution';LOG.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n')
def info(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink(),str(p)
 b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(s.st_mode)}
before={}
def pin(p,digest=None):
 p=Path(p)
 r=info(p)
 if digest is not None:assert r['sha256']==digest,(str(p),r,digest)
 if str(p) in before:assert before[str(p)]==r
 before[str(p)]=r
 return r
report={'schema':'heptatorch.differentiable-view-r3-native-invocation.v1','status':'RUNNING',
 'started_at':utc(),'commands':[],'torch_executions':0,'target_runtime_business_executions':0,
 'runtime_qualified':False,'whole_project_status':'HOLD','closed_api_schemas':0,
 'pytorch_api_denominator':2590,'full_pytorch_rewrite_complete':False,
 'parent_native_rebuilt_this_invocation':False,'parent_reused_from_actual_child_job':'1a1e671a388-392-3b3d',
 'toolchain_rebuilt_this_invocation':False,'toolchain_reused_from_actual_cold_job':'1a1e65f617b-392-3af4'}
def run(label,argv):
 r={'label':label,'argv':[str(x) for x in argv],'cwd':str(REPO),
 'started':False,'completed':False,'started_at':utc(),'timeout_seconds':1800}
 report['commands'].append(r);save(LOG/(label+'.argv.json'),r)
 with (LOG/(label+'.stdout')).open('xb') as so,(LOG/(label+'.stderr')).open('xb') as se:
  p=subprocess.Popen(r['argv'],cwd=REPO,stdout=so,stderr=se)
  r['started']=True;r['pid']=p.pid;save(LOG/(label+'.started.json'),r)
  try:r['returncode']=p.wait(timeout=1800);r['timed_out']=False
  except subprocess.TimeoutExpired:
   p.kill();r['returncode']=p.wait();r['timed_out']=True
  r['completed']=True;r['completed_at']=utc()
 r['stdout']=info(LOG/(label+'.stdout'));r['stderr']=info(LOG/(label+'.stderr'))
 save(LOG/(label+'.completed.json'),r)
 print(json.dumps({'label':label,'returncode':r['returncode'],'stderr_bytes':r['stderr']['bytes']}),flush=True)
 assert r['returncode']==0 and not r['timed_out'] and r['stderr']['bytes']==0,r
try:
 compiler=TOOLS/'stack-module-compiler';linker=TOOLS/'stack-linker-session'
 pin(compiler,'b1c851a0896fa6071f800e1146c3c27d0c6cf85059e9a6281b46d42908a3f59f')
 pin(linker,'aae650e8822ef0b1e74d15108ad1d0f17ec791205ed5a158ec60b709f48f0e16')
 pin(TOOLRUN/'report.json','444c47e36a0c44f21a03bacefd4e2021d913fcb5815ecf6458c009790f8f7a4c')
 pin(PREVIOUS.parent/'report.json','20c6d8a6fa1dc4e63c97a6ecddc6a76fe494ae3b0fe12c07d5757a7a1ff15422')
 pin(PREVIOUS/'build.json','e97c4c2c65e0a0f17880f0d41a73281daf0b8badfb39865e3efbe310ccf2972e')
 pin(PREVIOUS/'runtime.hepta','197bd52db4815f575ea3e9055d3f5556900314bd2f4fbb262e80cea76ea16ef2')
 pin(PREVIOUS/'tensor-differentiable-view-session','13cee2163e8f62081db35e831885714789ac5117fb80c030a1ccaf7194e0821c')
 pin(SRC/'source-manifest.json','048bdfbda2bd71486faaa98a89b70d5f41dfa48e8fd8ae2ad7a344420dded77b')
 manifest=json.loads((SRC/'source-manifest.json').read_bytes())
 assert manifest['schema']=='heptatorch.direct-view-r3-author-manifest.v1'
 assert manifest['status']=='SOURCE_PREPARED_NOT_COMPILED' and len(manifest['files'])==21
 assert len({r['path'] for r in manifest['files']})==21
 for row in manifest['files']:
  p=SRC/row['path'];assert p.parent==SRC
  got=info(p);assert got=={k:row[k] for k in ('bytes','sha256','mode')},row
  before[str(p)]=got
 prepared=json.loads((SRC/'prepare-build.json').read_bytes())
 assert prepared['status']=='PREPARED_NOT_COMPILED' and prepared['orchestration_revision']=='RECOVERED_SOURCE_R3'
 assert (prepared['functions'],prepared['blocks'],prepared['instructions'],prepared['descriptor_bytes'],prepared['units_planned'])==(627,8245,29636,672,13)
 assert prepared['source_sha256']==SOURCE and len(prepared['units'])==13
 assert all(x['native_compile_started'] is False for x in prepared['units'])
 for path,digest in prepared['inputs_sha256'].items():pin(Path(path),digest)
 previous=json.loads((PREVIOUS/'build.json').read_bytes())
 assert previous['status']=='PASS' and previous['functions']==614 and len(previous['units'])==12
 for u in previous['units']:
  assert u['compiler_exit']==0
  pin(PREVIOUS/(u['name']+'.hepta'),u['source_sha256'])
  pin(PREVIOUS/(u['name']+'.o'),u['object_sha256'])
 pin(Path(__file__))
 pin(Path(sys.executable).resolve())
 original_argv=json.loads((SRC/'prepare-command.json').read_bytes())
 assert original_argv[:3]==['/usr/bin/python3','-B',str(SRC/'build.py')]
 assert original_argv[-1]=='--prepare-only' and original_argv.count('--prepare-only')==1
 expected_paths={'--previous':PREVIOUS,'--repository':REPO,'--upstream':BASE/'toolchain',
 '--compactor':REPO/'tools/owned_optimizers/compact_functions.py','--compiler':compiler,'--linker':linker}
 for flag,path in expected_paths.items():
  assert original_argv.count(flag)==1 and original_argv[original_argv.index(flag)+1]==str(path)
 assert original_argv.count('--output')==1
 actual_argv=original_argv[:-1]
 old_output=actual_argv[actual_argv.index('--output')+1]
 actual_argv[actual_argv.index('--output')+1]=str(CHILD)
 inverse=actual_argv[:];inverse[inverse.index('--output')+1]=old_output;inverse.append('--prepare-only')
 assert inverse==original_argv
 save(OUT/'command-adaptation.json',{'original_prepare_argv':original_argv,'actual_compile_argv':actual_argv,
 'changes':['remove --prepare-only','replace --output value with unique candidate-r3 path'],
 'exact_inverse':True,'all_other_argv_unchanged':True})
 save(OUT/'inputs-before.json',before)
 review={'schema':'heptatorch.direct-view-r3-independent-source-review.v1','status':'SOURCE_ONLY_NO_BLOCKER_IDENTIFIED',
 'source_manifest_sha256':'048bdfbda2bd71486faaa98a89b70d5f41dfa48e8fd8ae2ad7a344420dded77b',
 'complete_sources_read':{'build.py':'e71dddc0462b8330341c359ec0108536854d752f54ddcad7b0d7ed8cd1b77683',
 'incoming_geometry.py':'bdd5c9d06093db032c3cb25ed541449f531145288ce56f6b97d3ca634064137e',
 'incoming_geometry_overlay.py':'e6de117049f65a2ead43141902325d3cffa9519d0d3370ee22f7644586479428',
 'parent_emitter.py':'4d4921023329ee7da52242ca23a148d91546f470a99472dd5a16bf062d8f7091',
 'dview_coverage_divide.hepta':'4de09bb940b9e63f625c5629583b7dce7c1487c2bf3b84a88a1faae9c360fb34'},
 'frozen_causal_review_report_sha256':'8dc2566f0ab090a5e725375166484893b969e1aff5278e2f2c47cca937085d0a',
 'findings':['Actual physical incoming span/offset/strides replace the op44 contiguous description.',
 'The existing gradient layout contract, clone, steal and Version behavior remain exact parent bodies.',
 'A real first-edge physical storage is built by scatter, copy/index_add and optional normalization with separate Version bumps.',
 'The local positive-coverage NaN helper preserves sign/payload and quiets; all other inputs delegate to original division.',
 'Later edges use the original incoming_merge_edge path and do not repeat first-edge construction or tail trimming.',
 'Original constructor/captured-edge/retained-hook bodies remain unchanged.',
 'Full new runtime qualification and original4/original14 replay are still pending.'],
 'unqualified_boundary':'Count-zero internal holes delegate to old divf; no exact PyTorch 0/0 bit-pattern compatibility is claimed by these four observations.',
 'native_or_Torch_execution_by_source_review':False}
 save(OUT/'independent-source-review.json',review)
 run('01-child-r3-native13',actual_argv)
 child=json.loads((CHILD/'build.json').read_bytes())
 assert child['status']=='PASS' and child['orchestration_revision']=='RECOVERED_SOURCE_R3'
 assert (child['functions'],child['blocks'],child['instructions'],child['descriptor_bytes'])==(627,8245,29636,672)
 assert len(child['units'])==13 and child['state_format']=='HTVAD003' and child['backing_format']=='HTOVAD03'
 assert child['runtime_qualified'] is False and child['torch_executed'] is False
 assert child['link_exit']==0 and child['source_sha256']==SOURCE
 assert child['changed_parent_functions']==prepared['changed_parent_functions']
 assert child['added_functions']==prepared['added_functions'] and len(child['added_functions'])==13
 assert len(child['changed_parent_functions'])==9
 assert child['inputs_sha256']==prepared['inputs_sha256']
 assert child['authoring_inputs_sha256']==prepared['authoring_inputs_sha256']
 assert [u['name'] for u in child['units']]==[u['name'] for u in prepared['units']]
 for u,plan in zip(child['units'],prepared['units']):
  assert u['compiler_exit']==0 and u['source_sha256']==plan['source_sha256']
  assert info(CHILD/(u['name']+'.hepta'))['sha256']==u['source_sha256']
  obj=(CHILD/(u['name']+'.o')).read_bytes()
  assert obj.startswith(b'\x7fELF') and sha(obj)==u['object_sha256']
  assert (CHILD/(u['name']+'.stderr')).read_bytes()==b''
 assert (CHILD/'link.stderr').read_bytes()==b''
 assert info(CHILD/'runtime.hepta')['sha256']==SOURCE
 assert info(CHILD/'tensor-differentiable-view-session')['sha256']==child['native_sha256']
 F=re.compile(rb'^(fn ([A-Za-z_][A-Za-z_0-9]*)\([^\n]*\n.*?^end\n)',re.M|re.S)
 old={n.decode():b for b,n in F.findall((PREVIOUS/'runtime.hepta').read_bytes())}
 new={n.decode():b for b,n in F.findall((CHILD/'runtime.hepta').read_bytes())}
 assert len(old)==614 and len(new)==627 and set(old)<=set(new)
 changes=[n for n in old if old[n]!=new[n]]
 assert changes==child['changed_parent_functions']
 assert sorted(set(new)-set(old))==child['added_functions']
 for name in ('gradient_accumulate','incoming_obeys_contract','incoming_adopt_gradient','incoming_drop_cache',
 'to_zero_factory_incoming','divf','addf','to_strided_view','to_view_refresh'):
  assert old[name]==new[name],name
 assert sha(new['dview_coverage_divide'])=='4de09bb940b9e63f625c5629583b7dce7c1487c2bf3b84a88a1faae9c360fb34'
 aliases={'incoming_describe':'dview_previous_incoming_describe','incoming_construct':'dview_previous_incoming_construct',
 'incoming_mark_preserve_targets':'dview_previous_mark_preserve_targets'}
 for original,alias in aliases.items():
  assert new[alias].replace(('fn '+alias+'(').encode(),('fn '+original+'(').encode(),1)==old[original]
 for name in ('init_state','state_header','so_state_init','so_state_header'):
  outer=name in ('init_state','state_header')
  a=b'HTVAD002' if outer else b'HTOVAD02';b=b'HTVAD003' if outer else b'HTOVAD03'
  a=('{"value":'+str(int.from_bytes(a,'little'))+'}').encode()
  b=('{"value":'+str(int.from_bytes(b,'little'))+'}').encode()
  assert new[name].count(b)==1 and old[name].count(a)==1 and new[name].replace(b,a)==old[name]
 old_expr=b'  v20:u64 = int.mul.wrap(v18,v19)\n'
 new_expr=b'  v20:u64 = call(v11,v13) {"function":"dview_preserve_capacity"}\n'
 assert new['incoming_reserve_preserve_storage'].replace(new_expr,old_expr,1)==old['incoming_reserve_preserve_storage']
 for p,row in before.items():assert info(Path(p))==row,p
 report.update(status='BUILT_NOT_RUNTIME_QUALIFIED',completed_at=utc(),all_inputs_unchanged=True,
 child={'path':str(CHILD),'build_report':info(CHILD/'build.json'),'source_sha256':child['source_sha256'],
 'native_sha256':child['native_sha256'],'native_bytes':child['native_bytes'],'functions':627,'blocks':8245,
 'instructions':29636,'units':child['units'],'changed_parent_functions':changes,'added_functions':child['added_functions'],
 'unchanged_complete_parent_bodies':len(old)-len(changes)},
 parent={'path':str(PREVIOUS),'source_sha256':previous['source_sha256'],'native_sha256':previous['native_sha256'],
 'build_report':info(PREVIOUS/'build.json'),'reused_from_prior_actual_build':True})
 report['output_inventory']={str(p.relative_to(OUT)):info(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='report.json'}
 save(OUT/'report.json',report)
 print(json.dumps({'status':report['status'],'report':str(OUT/'report.json'),'report_sha256':sha((OUT/'report.json').read_bytes()),
 'source_sha256':child['source_sha256'],'native_sha256':child['native_sha256'],'build_sha256':info(CHILD/'build.json')['sha256'],
 'functions':627,'blocks':8245,'instructions':29636,'units':13}),flush=True)
except BaseException as error:
 report.update(status='FAIL',completed_at=utc(),error=repr(error),traceback=traceback.format_exc())
 try:report['input_recheck']={p:info(Path(p))==r for p,r in before.items()}
 except BaseException as secondary:report['input_recheck_error']=repr(secondary)
 try:report['partial_files']={str(p.relative_to(OUT)):info(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='report.json'}
 except BaseException as secondary:report['partial_inventory_error']=repr(secondary)
 if not (OUT/'report.json').exists():save(OUT/'report.json',report)
 print(json.dumps({'status':'FAIL','report':str(OUT/'report.json'),'error':repr(error)}),flush=True)
 raise
