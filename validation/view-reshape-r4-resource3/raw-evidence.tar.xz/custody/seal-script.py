#!/usr/bin/env python3
"""Seal the completed resource07b invocation; no compiler, Torch or native runs."""
import hashlib,json,lzma,os,stat,tarfile
from pathlib import Path,PurePosixPath
R=Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
OBS=R/'hia-wrapped-scalar-resource-actual07b-first-01'
SRC=R/'hia-wrapped-scalar-resource-source-07b'
NATIVE=R/'differentiable-view-r4-scalar07b-native-build-01/candidate-r4-scalar07b'
REF=R/'wrapped-f64-reference32-01'
OUT=R/'hia-wrapped-scalar-resource07b-handoff-01'
REPORT='8ba0ec16c85490a81e2e84a6f0a42c57917a5fe4768d444220ecdd18e30bde10'
def sha(b):return hashlib.sha256(b).hexdigest()
def info(p):
    assert p.is_file() and not p.is_symlink(),str(p)
    h=hashlib.sha256();size=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b);size+=len(b)
    return {'bytes':size,'sha256':h.hexdigest(),'mode':stat.S_IMODE(p.stat().st_mode)}
def dump(p,d):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:f.write(json.dumps(d,indent=2,sort_keys=True)+'\n')
def api(x):
    if x.get('status')=='fulfilled':x=x['value']
    assert not x.get('isError')
    return json.loads(''.join(c['text'] for c in x['content'] if c['type']=='text'))
OUT.mkdir(exist_ok=False)
assert info(OBS/'report.json')['sha256']==REPORT
report=json.loads((OBS/'report.json').read_bytes())
assert report['status']=='PASS' and report['case_count']==report['passed']==3
assert report['all_inputs_unchanged'] and [x['EOF_exit_code'] for x in report['cases']]==[0,0,0]
assert [x['name'] for x in report['cases']]==[
 'entry_guards_and_relative_tokens','saved_scalar_and_temporary_lifetime','result_allocation_oom_recovery']
capture=R/'hia-wrapped-scalar-resource07b-transport-capture-01.json'
assert info(capture)['sha256']=='cebb6cda9e27083160593973b5c9e3268732ee20cd7319158dfadfb3de9927d5'
cap=json.loads(capture.read_bytes());terminal=api(cap['native_terminal_status']);stream=api(cap['native_process_read'])
assert terminal['job_id']=='1a1e77a8531-392-3d9f' and terminal['state']=='succeeded' and terminal['exit_code']==0
assert terminal['output_complete'] and terminal['output_durable'] and not terminal['automatic_retry']
for key in ('stdout','stderr'):
    x=stream[key];assert x['offset']==0 and x['eof'] and x['next_offset']==x['size']
    b=bytes.fromhex(x['bytes_hex']);assert len(b)==x['size'] and b.decode()==x['text']
    p=OUT/('transport/'+key+'.bin');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
dump(OUT/'transport/terminal-status.json',terminal)
dump(OUT/'transport/stream-receipt.json',stream)
prepare_stream=api(cap['prepare_process_read'])
for key in ('stdout','stderr'):
    x=prepare_stream[key];assert x['offset']==0 and x['eof'] and x['next_offset']==x['size']
    b=bytes.fromhex(x['bytes_hex']);assert len(b)==x['size']
    (OUT/('transport/prepare-'+key+'.bin')).write_bytes(b)
files={}
def add(name,p):
    rel=PurePosixPath(name);assert not rel.is_absolute() and '..' not in rel.parts and str(rel)==name
    assert name not in files,name
    files[name]=p
for name,pin in report['inputs'].items():
    p=Path(name);assert info(p)==pin,(name,info(p),pin)
    for parent,label in ((SRC,'source'),(NATIVE,'native'),(REF,'reference')):
        if p.is_relative_to(parent):add(label+'/'+str(p.relative_to(parent)),p);break
    else:raise AssertionError('unclassified source '+name)
for p in sorted(OBS.rglob('*')):
    assert not p.is_symlink()
    if p.is_file():add('observed/'+str(p.relative_to(OBS)),p)
extras={
 'custody/api-transport-capture.json':capture,
 'custody/actual-request.json':R/'hia-wrapped-scalar07b-resource3-actual-request-20261117-v1.json',
 'custody/intent.json':R/'hia-wrapped-scalar-resource07b-proposed-intent-01.json',
 'custody/root-authorization.json':R/'root-wrapped-scalar07b-resource-review-v1.json',
 'custody/prepare-report.json':R/'hia-wrapped-scalar-resource-prepare-07b-01/report.json',
 'custody/source07b-independent-review.json':R/'hia-wrapped-scalar07b-source-review-01/report.json',
 'custody/source07b-review-manifest.json':R/'hia-wrapped-scalar07b-source-review-01/manifest.json',
 'custody/source05-missed-contract-addendum.json':R/'hia-wrapped-scalar-source05-token-node-addendum-01.json',
 'custody/seal-script.py':Path(__file__)
}
for n,p in extras.items():add(n,p)
for p in sorted((OUT/'transport').rglob('*')):
    if p.is_file():add('transport/'+str(p.relative_to(OUT/'transport')),p)
before={n:info(p) for n,p in sorted(files.items())}
origins={n:str(p) for n,p in sorted(files.items())}
archive=OUT/'raw-evidence.tar.xz'
with tarfile.open(archive,'w:xz',format=tarfile.PAX_FORMAT,preset=6) as tar:
    for n,p in sorted(files.items()):tar.add(p,arcname=n,recursive=False)
assert before=={n:info(p) for n,p in sorted(files.items())}
# Independent streaming XZ EOF and full TAR hash, not just decompression success.
d=lzma.LZMADecompressor(format=lzma.FORMAT_XZ);th=hashlib.sha256();ts=0
with archive.open('rb') as f:
    while True:
        b=f.read(1<<20)
        if not b:break
        assert not d.eof,'trailing compressed bytes'
        u=d.decompress(b);th.update(u);ts+=len(u)
        assert not d.unused_data,'concatenated/trailing XZ stream'
assert d.eof
seen={}
with tarfile.open(archive,'r:xz') as tar:
    for m in tar:
        assert m.isfile() and m.name in before and m.name not in seen,m.name
        n=PurePosixPath(m.name);assert not n.is_absolute() and '..' not in n.parts
        expected=before[m.name];h=hashlib.sha256();size=0
        with tar.extractfile(m) as f:
            for b in iter(lambda:f.read(1<<20),b''):h.update(b);size+=len(b)
        got={'bytes':size,'sha256':h.hexdigest(),'mode':m.mode&511}
        assert got==expected,(m.name,got,expected)
        seen[m.name]=got
assert seen==before
manifest={'schema':'heptatorch.wrapped-scalar-resource07b-evidence.v1',
 'archive':info(archive),'members':before,'original_paths':origins,'member_count':len(before),
 'member_bytes':sum(x['bytes'] for x in before.values()),'single_xz_stream_eof':True,
 'uncompressed_tar_bytes':ts,'uncompressed_tar_sha256':th.hexdigest(),
 'all_members_verified':True,'all_original_inputs_unchanged':True,
 'self_reference_exclusions':['evidence-manifest.json','summary.json','delivery-manifest.json','raw-evidence.tar.xz'],
 'source_manifest_sha256':'ef0e0b1f830fea8a71d537d71b6408bbe656fc7e0473d6ad3e01da55e62e49cc',
 'native_report_sha256':REPORT,
 'scope':'Only source06 three finite native controls. No Torch/compiler/emitter; original26 failures remain.'}
dump(OUT/'evidence-manifest.json',manifest)
summary={'schema':'heptatorch.wrapped-scalar-resource07b-handoff.v1','status':'FINITE_NATIVE_CONTROLS_PASS',
 'native_job':'1a1e77a8531-392-3d9f','source':report['source_sha256'],'native':report['native_sha256'],
 'native_report':info(OBS/'report.json'),'archive':info(archive),
 'manifest':info(OUT/'evidence-manifest.json'),'cases':[],
 'frames':report['frames_before_EOF'],'checks':report['checks'],
 'rollback_bytes':report['full_owner_rollback_bytes'],'rng_bytes':report['full_rng_bytes'],
 'committed_84Q_snapshots':report['committed_84Q_snapshots'],
 'all_inputs_unchanged':True,'inputs':len(report['inputs']),
 'copied_controls':3,'EOF_codes':[0,0,0],'native_executed_here':False,
 'native_executed_in_original_job':True,'Torch_executed_here':False,
 'compiler_executed_here':False,'emitter_executed_here':False,
 'member_count':len(before),'member_bytes':manifest['member_bytes'],'whole_pytorch_gate':'HOLD',
 'business_suite_scope':'Other source07b numerical results remain separate; none were replayed during resource qualification',
 'weak_scope':'Finite native ownership only; original actual32 does not contain a Weak-lifetime oracle.',
 'source13_history':'This packet uses an existing genuinely compiled source07b image; it is not a new cold build.',
 'orchestration_scope':'Exact reviewed request submitted once; original start, status, full streams and preflight preserved.'}
for c in report['cases']:
    summary['cases'].append({k:c.get(k) for k in ('name','status','frames_before_EOF','checks','EOF_exit_code','rollback_bytes')})
dump(OUT/'summary.json',summary)
readme="""# Wrapped Scalar source07b finite resources

The original job 1a1e77a8531-392-3d9f ran exactly three finite controls on source07b and passed all three: 243 native frames, 771 checks, 250 committed 84Q snapshots, 54,698,688 rollback bytes, 1,203,328 RNG bytes and three normal EOF exits. Three copied corruptions were rejected. No new Torch/compiler/emitter was run.

The envelope preserves source59 payload, all13 unit source/object products and the actual existing ELF, original32 reference/probe, every child report/snapshot/wire/stream, request, root authorization, prepare report and the source05 review-gap addendum. Original absolute child paths were not rewritten. evidence-manifest.json maps every archive member back to the original path with exact size/SHA256/mode.

The archive was reopened and every member's bytes/mode and complete membership were checked; a separate streaming decoder confirmed a single XZ EOF and full uncompressed TAR hash. Original source/output inputs were hashed before and after sealing.

Original source05/source06 business failures remain historical facts. This source07b packet contains only the three explicitly authorized controls. It does not qualify the newly introduced backward private-preserve-cache OOM path, general float64 operators, owned short-output entry, or extend actual32 with a PyTorch Weak oracle. No original file is deleted. Source-only and transport-only reports are separate from the actual job.
"""
(OUT/'README.md').write_text(readme)
# Preserve whole original archive. Opaque transport chunks are separate copies only if required.
if archive.stat().st_size>8*1024*1024:
    chunks=[];pos=0
    with archive.open('rb') as f:
        for i,b in enumerate(iter(lambda:f.read(8*1024*1024),b'')):
            p=OUT/('raw-evidence.part-%03d'%i);p.write_bytes(b);chunks.append({'name':p.name,'offset':pos,**info(p)});pos+=len(b)
    dump(OUT/'concat-index.json',{'whole':info(archive),'parts':chunks,'mode_of_whole':info(archive)['mode']})
delivery={'schema':'heptatorch.wrapped-scalar-resource07b-delivery.v1',
 'files':{str(p.relative_to(OUT)):info(p) for p in sorted(OUT.rglob('*')) if p.is_file()},
 'modes':'Original archive members retain original modes. This envelope has not been installed into Git.',
 'native_executed':False,'Torch_executed':False}
dump(OUT/'delivery-manifest.json',delivery)
print(json.dumps({'status':'SEALED_AND_VERIFIED','directory':str(OUT),'archive':info(archive),
 'manifest':info(OUT/'evidence-manifest.json'),'delivery':info(OUT/'delivery-manifest.json'),
 'summary':info(OUT/'summary.json'),'members':len(before),'member_bytes':manifest['member_bytes']},sort_keys=True))
