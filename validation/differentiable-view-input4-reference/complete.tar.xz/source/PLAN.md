# Four new direct-view input boundaries

## Why these are new

The unchanged independent72 report2512acd has 24 output geometries and three
seed modes. Its source6cbf7caa constructs a contiguous arange256 leaf in every
row, followed by one view and one ToCopy. It does not test an overlapping
immediate input, a nonempty input with holes, or two distinct sibling views.
The unchanged reference14 report2270d5ba covers direct output overlap, a linear
retained chain and a same-view double Mul edge; it does not isolate these three
input/graph boundaries. R2's 14/14 result0b987fcb remains independently frozen.

## Recipes

1. A detached nonview leaf input has shape[2,3], strides[0,1] over three real
   Storage elements. Its differentiable output selects each physical element
   exactly once using shape[3], stride[1]. This separates input multiplicity
   division from output reduction/index_add. Two backwards use explicitly
   recorded finite words and then signed zero/qNaN input words; gradients are
   explicitly cleared between phases while first gradients are held.

2. A detached nonview leaf input has shape[2,3], strides[1,1] over four real
   elements. Outputshape[4]/stride[1] again has unique physical elements.
   Multiplicity is nonuniform. Two seed phases independently observe finite and
   signed-zero/payload behavior; no resulting gradient is precomputed.

3. A detached nonview leaf inputshape[2,2]/stride[3,1]/offset0 has holes in a
   six-element Storage. Outputshape[2,2]/stride[3,1]/offset1 uses valid Storage
   locations, including positions outside the input logical footprint.
   One explicit finite-seed backward records what actual Torch accepts and
   which gradients it returns.

4. A real [3,2]/[1,3] retained intermediate view of a [2,3] leaf has two distinct
   [2,2]/[3,1] sibling views at offsets0 and1. Their Tensor objects differ while
   some physical locations overlap. Multiplication joins both siblings.
   All three views retain gradients. Two finite-seed phases record merge,
   immediate edge, retained replacement and final ownership behavior.

The native mapping for input setup is the existing detached strided alias69
followed by90 own-requires, then the new real differentiable constructor111.
Sibling graph construction uses111 for every real view and binary2/op3 for
actual multiplication. Seed construction observes a final plain F32 clone;
temporary int32/dtype-view wrappers are not exposed as a new native API.

## Observation and ownership

All outcomes come from the actual pinned Torch. The probe records complete
physical Storage bytes and logical raw words, shape/stride/offset, T/S identity,
Version, requires/is_leaf/is_view/_base, recursive current edges, Saved getters,
retained gradients, alias relations, warnings and exact error text. Complete
5056-byte RNG states are interned without dropping bytes. Every named object is
dropped in order and StorageWeakRef states are observed after local wrappers
and temporary grad_fn objects are gone. Only the explicit live map keeps
Tensor roots; returned snapshots contain primitives.

Original14 observer helpers are copied exactly and their source/AST hashes
are checked. No native or Torch executes during preparation. Autograd is the
unique fixed ROG actual executor using the declared stable key; scope is the
unique future native replay executor. Root reviews the full probe first.

## Fixed primary evidence

FunctionsManual.cpp, official31a, SHA a8603d6309822a3f93fa4fcb5ada05e2f0f7e29a1b96db64fe6f59ce0c730558,
lines3470-3599, explicitly distinguishes output reductions/scatter from input
multiplicity division and returns input geometry. Lines3539-3544 explicitly
record the unresolved upstream check for output positions not visible in the
input logical geometry. This note does not predict whether a recipe raises.
variable.cpp, same fixed31a, SHA ca2f1e573307069dee2fdff70ba81f161f48817cd278ad5464b9809cf23ab2c6,
provides Tensor/grad_fn/weak retained-hook ownership. Both complete official
files are bound and copied into this new package.

The profile remains AVX512, one thread, deterministic algorithms and fill
uninitialized memory enabled. All11 wheel/install provenance checks are
mandatory. This is a finite new observation plan, not whole-schema acceptance.
