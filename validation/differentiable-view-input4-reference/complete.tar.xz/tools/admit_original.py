#!/usr/bin/env python3
"""Pure byte/schema review of the one fixed input-boundaries4 actual report."""
from pathlib import Path
import hashlib
import itertools
import json
import math
import stat
import sys
import traceback

BASE = Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
SRC = BASE / 'differentiable-view-input-boundaries-04-20261116'
CUSTODY = BASE / 'differentiable-view-input4-actual-custody-01'
OUT = BASE / 'differentiable-view-input4-independent-admission-01'
ACTUAL_SHA = 'f4abe6a750ecc791b3a7bc7aa507b4c77eb0a2fcccf45b0c6a828db0e01490d3'
EXECUTION_SHA = '78ea18d6ab862d5d289e45b7b12e590b30ac5c6c816056477b23879b5e6aa6bb'
COUNTS = {'checks': 0, 'tensor_records': 0, 'logical_words': 0,
          'storage_bytes': 0, 'snapshots': 0, 'rng_references': 0,
          'events': 0, 'backward_events': 0}
TENSOR_KEYS = {'tensor_identity','storage_identity','dtype','element_size','shape','strides',
               'numel','storage_bytes','storage_offset_elements','storage_offset_bytes',
               'storage_raw_hex','logical_bytes_hex','binary_words','version','requires_grad',
               'is_view','base_tensor_identity'}
SNAPSHOT_KEYS = {'tensor_getter_order','tensors','relations','saved_getters_after_tensor_getters',
                 'edge_getters','edges_after_all_tensor_getters','expired','state'}

def check(ok, where):
    COUNTS['checks'] += 1
    if not ok:
        raise AssertionError(where)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def info(p):
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'mode': stat.S_IMODE(p.stat().st_mode),
            'sha256': sha(raw)}

def identity(value):
    return type(value) is str and value.isdecimal() and int(value) > 0

def tensor(t, path):
    check(set(t) == TENSOR_KEYS, path + ': exact Tensor record fields')
    check(identity(t['tensor_identity']) and identity(t['storage_identity']), path + ': identities')
    check(t['base_tensor_identity'] is None or identity(t['base_tensor_identity']), path + ': base identity')
    check(t['dtype'] == 'torch.float32' and t['element_size'] == 4, path + ': true F32 width')
    shape, stride = t['shape'], t['strides']
    check(type(shape) is list and type(stride) is list and len(shape) == len(stride), path + ': rank')
    check(all(type(x) is int and x >= 0 for x in shape + stride), path + ': geometry words')
    check(type(t['numel']) is int and t['numel'] == math.prod(shape), path + ': numel')
    check(type(t['storage_offset_elements']) is int and t['storage_offset_elements'] >= 0, path + ': offset')
    check(t['storage_offset_bytes'] == 4 * t['storage_offset_elements'], path + ': byte offset')
    physical = bytes.fromhex(t['storage_raw_hex'])
    logical = bytes.fromhex(t['logical_bytes_hex'])
    check(physical.hex() == t['storage_raw_hex'] and logical.hex() == t['logical_bytes_hex'], path + ': canonical full hex')
    check(len(physical) == t['storage_bytes'] and len(logical) == 4 * t['numel'], path + ': full lengths')
    expected = bytearray()
    for index in range(t['numel']):
        rem, address = index, t['storage_offset_elements']
        for size, step in zip(reversed(shape), reversed(stride)):
            address += (rem % size) * step
            rem //= size
        check(0 <= address * 4 and address * 4 + 4 <= len(physical), path + ': logical address bounds')
        expected.extend(physical[address * 4: address * 4 + 4])
    check(bytes(expected) == logical, path + ': independently gather complete logical bytes')
    words = [int.from_bytes(logical[i:i+4], 'little') for i in range(0, len(logical), 4)]
    check(t['binary_words'] == words, path + ': exact raw F32 words')
    check(type(t['version']) is int and t['version'] >= 0, path + ': Version')
    check(type(t['requires_grad']) is bool and type(t['is_view']) is bool, path + ': boolean AD metadata')
    COUNTS['tensor_records'] += 1
    COUNTS['logical_words'] += len(words)
    COUNTS['storage_bytes'] += len(physical)

def snapshot(s, path, states):
    check(set(s) == SNAPSHOT_KEYS, path + ': exact snapshot fields')
    names = s['tensor_getter_order']
    check(type(names) is list and len(names) == len(set(names)), path + ': unique getter names')
    check(list(s['tensors']) == names, path + ': actual tensor getter order')
    for field in ('saved_getters_after_tensor_getters', 'edge_getters', 'edges_after_all_tensor_getters'):
        check(set(s[field]) == set(names), path + ': full ' + field + ' names')
    expected_keys = {a + '|' + b for a, b in itertools.combinations(names, 2)}
    check(set(s['relations']) == expected_keys, path + ': complete pairwise relations')
    for a, b in itertools.combinations(names, 2):
        left = s['tensors'][a]['before_grad_fn_getter']
        right = s['tensors'][b]['before_grad_fn_getter']
        r = s['relations'][a + '|' + b]
        check(set(r) == {'same_Python_object','same_Tensor','same_Storage','same_current_Version_value'}, path + ': relation keys')
        check(all(type(v) is bool for v in r.values()), path + ': relation booleans')
        check(r['same_Tensor'] == (left['tensor_identity'] == right['tensor_identity']), path + ': same actual Tensor')
        check(r['same_Storage'] == (left['storage_identity'] == right['storage_identity']), path + ': same actual Storage')
        check(r['same_current_Version_value'] == (left['version'] == right['version']), path + ': current Version equality')
        check(not r['same_Python_object'] or r['same_Tensor'], path + ': wrapper identity implies Tensor')
    check(all(type(v) is bool for v in s['expired'].values()), path + ': weak states booleans')
    check(s['state'] in states, path + ': full RNG state binding')
    for name in names:
        for edge in s['edges_after_all_tensor_getters'][name]:
            matches = edge['matches_live_current_grad_fn']
            check(type(matches) is list and len(matches) == len(set(matches)) and set(matches) <= set(names), path + ': edge identity names')
            check(type(edge['output_nr']) is int and edge['output_nr'] >= 0, path + ': edge output number')
    COUNTS['snapshots'] += 1

def walk(v, path, states):
    if type(v) is dict:
        if 'tensor_identity' in v:
            tensor(v, path)
        if 'tensor_getter_order' in v:
            snapshot(v, path, states)
        for k, w in v.items():
            if k in ('state', 'state_before_setup', 'state_after'):
                check(type(w) is str and w in states, path + '/' + k + ': complete state reference')
                COUNTS['rng_references'] += 1
            walk(w, path + '/' + k, states)
    elif type(v) is list:
        for i, w in enumerate(v):
            walk(w, path + '/' + str(i), states)

def simple_tensor(t):
    if t is None:
        return None
    return {k: t[k] for k in ('tensor_identity', 'storage_identity','shape','strides',
                              'storage_offset_elements','storage_bytes','version',
                              'binary_words','requires_grad','is_view','base_tensor_identity')}

OUT.mkdir(mode=0o700, exist_ok=False)
result = {'schema': 'heptatorch.input-boundaries4-independent-actual-byte-admission.v1',
          'status': 'FAIL', 'native_executions': 0, 'torch_executions': 0,
          'closed_schema_count': 0, 'pytorch_api_denominator': 2590,
          'source': info(Path(__file__).resolve()), 'primary_error': None}
try:
    actual_path = SRC / 'actual.json'
    raw = actual_path.read_bytes()
    check(sha(raw) == ACTUAL_SHA and len(raw) == 5680715, 'exact original actual bytes')
    execution_raw = (CUSTODY / 'execution.json').read_bytes()
    check(sha(execution_raw) == EXECUTION_SHA, 'exact original execution receipt')
    report, execution = json.loads(raw), json.loads(execution_raw)
    check(execution['status'] == 'OBSERVED' and execution['exit_code'] == 0, 'one actual successful process')
    check(execution['child_started'] is True and execution['child_completed'] is True, 'actual started and completed')
    check(execution['inputs_before'] == execution['inputs_after'] and len(execution['inputs_before']) == 25, 'all 25 before-after input bindings')
    for name, record in execution['inputs_before'].items():
        check(info(Path(record['path'])) == record, 'input still exact: ' + name)
    check(execution['upstream_originals_freshly_read_by_outer_wrapper'] is True, 'actual upstream outer reads')
    prepared = json.loads((SRC / 'prepare.json').read_bytes())
    check(report['case_plan'] == prepared['case_plan'], 'fixed before-actual plan')
    check(report['status'] == 'OBSERVED' and report['cases'] == len(report['rows']) == 4, 'all four actual cases')
    check(report['probe_errors'] == [] and report['probe_error_count'] == 0, 'no probe errors')
    check(report['native_executed'] is False and report['native_qualified'] is False, 'observation only')
    check(report['source_files_unchanged'] is True and report['torch_executed'] is True, 'source unchanged/actual Torch')
    check(report['oracle_provenance']['status'] == 'PASS', 'original full provenance')
    check(execution['observation_admission']['provenance']['independent_complete_observed_provenance_compared'] is True, 'independent complete observed provenance')
    check(len(report['oracle_provenance']['checks']) == 11 and all(v is True for v in report['oracle_provenance']['checks'].values()), 'all 11 provenance checks')
    states = report['states']
    check(len(states) == report['unique_complete_states'] and bool(states), 'nonempty complete state set')
    for digest, row in states.items():
        state = bytes.fromhex(row['hex'])
        check(len(state) == row['bytes'] == 5056 and sha(state) == digest, 'complete original MT bytes/' + digest)
    summaries = []
    all_events = []
    for plan, row in zip(report['case_plan'], report['rows']):
        check(row['status'] == 'OBSERVED' and {k: row[k] for k in plan} == plan, 'unmodified recipe/' + plan['name'])
        phases = []
        backward = [e for e in row['events'] if e['label'].startswith('backward_phase_')]
        check(len(backward) == len(plan['seed_phases']), 'complete backward schedule')
        for phase_index, phase in enumerate(plan['seed_phases']):
            seeds = [e for e in row['events'] if e['label'] == 'construct_seed_phase_' + str(phase_index)]
            check(len(seeds) == 1 and seeds[0]['accepted'] is True, 'exact input seed actually constructed')
            seed = seeds[0]['after']['tensors']['seed']['before_grad_fn_getter']
            check(seed['binary_words'] == phase['words'] and not seed['is_view'] and seed['base_tensor_identity'] is None, 'exact original seed bits / ordinary clone')
            e = backward[phase_index]
            check(e['label'] == 'backward_phase_' + str(phase_index) + '_' + phase['name'], 'exact phase order')
            after = e['after']['tensors']
            phases.append({'phase': phase['name'], 'accepted': e['accepted'], 'error': e['error'],
                           'actual_seed': simple_tensor(seed),
                           'actual_after': {name: {
                               'tensor': simple_tensor(item['before_grad_fn_getter']),
                               'is_leaf': item['is_leaf_after_grad_fn_getter'],
                               'retains_grad': item['retains_grad'],
                               'gradient': simple_tensor(item['gradient'].get('tensor')),
                               'gradient_observation_accepted': item['gradient']['accepted']}
                               for name, item in after.items() if not name.startswith('held_') and name != 'seed'}})
        check(set(row['final_expired']) == set(row['events'][-1]['after']['expired']), 'final weak inventory complete')
        check(row['final_expired'] == row['events'][-1]['after']['expired'], 'final weak states actual last snapshot')
        summaries.append({'index': row['index'], 'name': row['name'], 'events': len(row['events']),
                          'backward_phases': phases, 'final_expired': row['final_expired'],
                          'all_final_storage_weak_expired_observed': all(row['final_expired'].values())})
        all_events.extend(row['events'])
        COUNTS['backward_events'] += len(backward)
        walk(row, '/rows/' + str(row['index']), states)
    COUNTS['events'] = len(all_events)
    totals = {'attempted': len(all_events), 'succeeded': sum(e['accepted'] for e in all_events),
              'raised': sum(not e['accepted'] for e in all_events)}
    check(totals == report['operation_totals'] == {'attempted':103,'succeeded':103,'raised':0}, 'actual event counts, no assumed native result')
    check(COUNTS['backward_events'] == 7, 'all seven actually attempted')
    for name in ('stdout', 'stderr'):
        record = execution['raw_' + name]
        check(info(Path(record['path'])) == record, 'exact original child ' + name)
    stderr = (CUSTODY / 'stderr.txt').read_bytes()
    result.update(status='OBSERVATION_BYTE_INTEGRITY_VERIFIED', original_report=info(actual_path),
                  original_execution=info(CUSTODY / 'execution.json'),
                  counts=COUNTS, cases=summaries, operation_totals=totals,
                  num_unique_complete_rng_states=len(states),
                  actual_child_stderr={'bytes': len(stderr), 'sha256': sha(stderr),
                                      'text': stderr.decode('utf-8'),
                                      'classification': 'Torch import warning: optional NumPy unavailable; original stdout, stderr and all eleven provenance checks preserved.'},
                  limits=['Values are observed, not predicted or substituted.',
                          'No native comparison performed by this reader.',
                          'Graph identity comparisons without raw Function addresses remain source-bound executed observations.',
                          'Only the four fixed recipes and original pinned environment are observed.'])
except BaseException:
    result['primary_error'] = traceback.format_exc()
    result['counts'] = COUNTS
(OUT / 'report.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
print(json.dumps({'status': result['status'], 'counts': COUNTS,
                  'report': info(OUT / 'report.json')}, allow_nan=False))
if result['primary_error']:
    print(result['primary_error'], file=sys.stderr)
raise SystemExit(0 if result['status'] == 'OBSERVATION_BYTE_INTEGRITY_VERIFIED' else 1)
