#!/usr/bin/env python3
"""One actual reference run; immutable sources and raw execution custody."""
from pathlib import Path
import ast
import hashlib
import importlib.metadata
import json
import os
import platform
import stat
import subprocess
import sys
import time
import traceback

BASE = Path('/home/qian-qi/heptatorch-continuation-20261116')
SOURCE = BASE / 'runs/differentiable-view-input-boundaries-04-20261116'
WORK = BASE / 'runs/differentiable-view-input4-actual-custody-01'
MANIFEST_SHA = '7056b24c58d5e0589cef7d40709e38e63017b794cf9a58f6af8687a80023f240'
INTENT_SHA = '56a78d7da9d06e1e89ff7bb58fdb1e22ccec964caa897f2996150ec0b22e78b6'
PROBE_SHA = 'cf569335f48624c1edf2f97a649200f2e792ebcef5b6f1df6bac73293ce02efc'
INSTALL_SHA = '35ad4841c2f2f94be7ded7f1bcc97f9592f806658ff660bfac5bdc3b0cf986ef'
PYTHON_SHA = 'e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f'
KEY = 'heptatorch-d266-direct-view-input-boundaries4-actual-20261116-v1'
CHECKS = {'python_matches', 'platform_matches', 'version_backend_matches',
          'git_matches_oracle_build_pin', 'distribution_version_matches',
          'direct_url_matches', 'direct_url_archive_sha256_matches',
          'pip_report_url_matches', 'pip_report_archive_sha256_matches',
          'pip_report_version_matches', 'pip_report_requested'}
SOURCE_REVIEW = {
    'schema': 'heptatorch.input4-independent-source-review.v1',
    'status': 'SOURCE_ONLY_REVIEWED',
    'source_sha256': PROBE_SHA, 'source_manifest_sha256': MANIFEST_SHA,
    'intent_sha256': INTENT_SHA, 'torch_executions': 0, 'native_executions': 0,
    'findings': [
        'Complete 23382-byte fixed probe, manifest and intent independently read.',
        'Overlapping inputs are actual detached strided Tensors requiring grad; output addresses are explicit and unique.',
        'The holes recipe uses valid underlying Storage outside the input logical footprint; no result is predicted.',
        'Sibling views have a retained middle and actual mul node; two phases clear current grad and retain explicitly named old gradients.',
        'Seed words are literal construction inputs; ordinary clone/raw-bit checks are performed by the fixed probe.',
        'Snapshot grad_fn, AccumulateGrad.variable and Saved wrappers are function-local and released. Only live/held roots persist.',
        'All seven backward operations record actual success or exception; OBSERVED is not native qualification.',
        'Probe inputs contain self/support/lock only; this wrapper separately reads and binds both upstream sources and all manifest members.'
    ],
    'limitations': ['No new native execution, no complete PyTorch schema qualification.']
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def info(path):
    path = Path(path)
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode) and not path.is_symlink(), str(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'mode': stat.S_IMODE(st.st_mode),
            'sha256': sha(raw)}

def put(name, value):
    raw = (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()
    with (WORK / name).open('xb') as out:
        out.write(raw)

def capture_inputs(paths):
    return {name: info(path) for name, path in paths.items()}

def check_provenance(report, lock, install):
    p = report['oracle_provenance']
    expected = lock['oracle']
    assert p['status'] == 'PASS' and p['metadata_error'] is None
    assert p['expected'] == expected
    assert p['release_source_equivalence'] == lock['release_source_equivalence']
    assert p['lock_path'] == str(SOURCE / 'inputs/pytorch-oracle-lock.json')
    assert p['lock_sha256'] == 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
    assert set(p['checks']) == CHECKS and all(v is True for v in p['checks'].values())
    o = p['observed']
    assert set(o) == {'python', 'platform', 'version', 'git_commit', 'backend_versions',
                     'distribution_version', 'direct_url', 'install_report'}
    assert o['python'] == {'implementation': sys.implementation.name,
                          'version': list(sys.version_info[:2]), 'full_version': sys.version}
    assert o['python']['implementation'] == expected['python']['implementation']
    assert o['python']['version'] == expected['python']['version']
    assert o['platform'] == expected['platform'] == {'sys_platform': sys.platform, 'machine': platform.machine()}
    assert o['version'] == o['distribution_version'] == expected['version']
    assert o['git_commit'] == expected['git_commit']
    assert o['backend_versions'] == expected['backend_versions']
    wheel = expected['wheel']
    archive = {'hash': 'sha256=' + wheel['sha256'], 'hashes': {'sha256': wheel['sha256']}}
    assert o['direct_url'] == {'url': wheel['url'], 'archive_info': archive}
    records = [r for r in install['install'] if r.get('metadata', {}).get('name', '').lower() == 'torch']
    assert len(records) == 1
    item = records[0]
    assert item['requested'] is True and item['metadata']['version'] == expected['version']
    assert item['download_info'] == {'url': wheel['url'], 'archive_info': archive}
    assert o['install_report'] == {
        'path': expected['install_report'], 'pip_version': install.get('pip_version'),
        'download_info': item['download_info'], 'metadata_name': item['metadata']['name'],
        'metadata_version': item['metadata']['version'], 'requested': True}
    return {'status': 'PASS', 'original_all_eleven_checks': p['checks'],
            'independent_complete_observed_provenance_compared': True}

def verify_observation(report, before, prepared, lock, install):
    assert report['schema'] == 'heptatorch.differentiable-view-input-boundaries4.v1'
    assert report['status'] == 'OBSERVED' and report['torch_executed'] is True
    assert report['native_executed'] is False and report['native_qualified'] is False
    assert report['full_pytorch_rewrite_complete'] is False
    assert report['pytorch_api_denominator'] == 2590 and report['closed_schema_count'] == 0
    assert report['probe_sha256'] == PROBE_SHA
    assert report['primary_source_ref'] == '31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457'
    assert report['primary_source_pins'] == {
        'torch/csrc/autograd/FunctionsManual.cpp': before['manifest:upstream/FunctionsManual.cpp']['sha256'],
        'torch/csrc/autograd/variable.cpp': before['manifest:upstream/variable.cpp']['sha256']}
    assert report['cases'] == len(report['rows']) == 4
    assert report['probe_error_count'] == 0 and report['probe_errors'] == []
    assert report['source_files_unchanged'] is True
    assert report['inputs_sha256'] == {
        str(SOURCE / 'pytorch_differentiable_view_input_boundaries_probe.py'): PROBE_SHA,
        str(SOURCE / 'inputs/pytorch_oracle.py'): 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae',
        str(SOURCE / 'inputs/pytorch-oracle-lock.json'): 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'}
    assert report['case_plan'] == prepared['case_plan']
    totals = {'attempted': 0, 'succeeded': 0, 'raised': 0}
    summary = []
    backward_count = 0
    for specification, row in zip(report['case_plan'], report['rows']):
        assert row['status'] == 'OBSERVED'
        assert {k: row[k] for k in specification} == specification
        event_labels = [e['label'] for e in row['events']]
        assert len(event_labels) == len(set(event_labels))
        backward_events = []
        for e in row['events']:
            assert type(e['accepted']) is bool
            assert e['outcome'] == ('SUCCEEDED' if e['accepted'] else 'RAISED')
            assert (e['error'] is None) == e['accepted']
            totals['attempted'] += 1
            totals['succeeded' if e['accepted'] else 'raised'] += 1
            if e['label'].startswith('backward_phase_'):
                backward_events.append({'label': e['label'], 'accepted': e['accepted'], 'error': e['error']})
        assert len(backward_events) == len(specification['seed_phases'])
        backward_count += len(backward_events)
        summary.append({'index': row['index'], 'name': row['name'], 'status': row['status'],
                        'events': len(row['events']), 'backward_events': backward_events,
                        'final_expired': row['final_expired']})
    assert backward_count == 7 and report['operation_totals'] == totals
    env = {'deterministic_algorithms': True, 'deterministic_fill': True,
           'grad_enabled': True, 'num_threads': 1, 'cpu_capability': 'AVX512'}
    assert report['environment_before'] == report['environment_after'] == env
    assert report['environment_restored'] is True and report['original_outer_rng_restored'] is True
    assert report['cpu_capability'] == 'AVX512' and report['num_threads'] == 1
    assert type(report['build_configuration']) is str and report['build_configuration']
    assert report['unique_complete_states'] == len(report['states']) and report['states']
    for digest, state in report['states'].items():
        raw = bytes.fromhex(state['hex'])
        assert state['bytes'] == len(raw) == 5056 and sha(raw) == digest
    return {'status': 'OBSERVED_ONLY', 'cases': summary, 'backward_events': backward_count,
            'operation_totals': totals, 'provenance': check_provenance(report, lock, install),
            'all_original_complete_rng_bytes_verified': True,
            'native_qualified': False}

os.umask(0o077)
WORK.mkdir(mode=0o700, exist_ok=False)
put('source-review.json', SOURCE_REVIEW)
started = time.time_ns()
tick = time.monotonic()
result = {'schema': 'heptatorch.input-boundaries4-original-execution.v1',
          'status': 'FAIL', 'host': 'rog', 'idempotency_key': KEY,
          'native_executed': False, 'child_started': False, 'child_completed': False,
          'started_unix_ns': str(started), 'source_only_review': info(WORK / 'source-review.json'),
          'wrapper_source': info(Path(__file__).resolve()), 'primary_error': None}
paths = {}
before = {}
after = {}
rc = None
child = None
try:
    manifest_path, intent_path = SOURCE / 'source-manifest.json', SOURCE / 'actual-execution-intent.json'
    assert info(manifest_path)['sha256'] == MANIFEST_SHA
    assert info(intent_path)['sha256'] == INTENT_SHA
    manifest, intent = json.loads(manifest_path.read_bytes()), json.loads(intent_path.read_bytes())
    assert manifest['schema'] == 'heptatorch.direct-view.input4-prepared-source-manifest.v1'
    assert manifest['status'] == 'PREPARED_NOT_RUN' and len(manifest['files']) == 15
    seen = set()
    for item in manifest['files']:
        rel = Path(item['path'])
        assert not rel.is_absolute() and '..' not in rel.parts and str(rel) not in seen
        seen.add(str(rel))
        actual = info(SOURCE / rel)
        assert {k: actual[k] for k in ('bytes', 'mode', 'sha256')} == {k: item[k] for k in ('bytes', 'mode', 'sha256')}, str(rel)
        paths['manifest:' + str(rel)] = SOURCE / rel
    paths['source-manifest'] = manifest_path
    assert intent['idempotency_key'] == KEY and intent['actual_started_here'] is False
    assert intent['unique_executor'] == '/root/autograd_extension'
    assert intent['source_sha256'] == PROBE_SHA
    assert intent['host'] == 'rog' and intent['native_executed'] is False and intent['torch_executed'] is False
    repo = Path(intent['cwd'])
    assert Path.cwd().resolve() == repo.resolve()
    assert intent['executable'] == str(BASE / 'runs/pr28-observer-repair/torch-venv/bin/python')
    assert sys.executable == intent['executable']
    assert sys.implementation.name == 'cpython' and sys.version_info[:3] == (3, 12, 3)
    paths['actual-python-resolved'] = Path(sys.executable).resolve()
    assert info(paths['actual-python-resolved'])['sha256'] == PYTHON_SHA
    paths['venv-pyvenv.cfg'] = Path(sys.executable).parent.parent / 'pyvenv.cfg'
    lock = json.loads((SOURCE / 'inputs/pytorch-oracle-lock.json').read_bytes())
    assert lock['inventory_commit'] == '31a77fc9c0a7c6fff15a1ff58c743f53b1a9d457'
    paths['repository-upstream-lock'] = repo / 'compatibility/upstream-lock.json'
    inventory = json.loads(paths['repository-upstream-lock'].read_bytes())
    assert inventory['commit'] == lock['inventory_commit']
    pip_path = Path(lock['oracle']['install_report'])
    if not pip_path.is_absolute():
        pip_path = repo / pip_path
    paths['actual-repository-install-report'] = pip_path
    assert info(pip_path)['sha256'] == INSTALL_SHA
    assert pip_path.read_bytes() == (SOURCE / 'inputs/pytorch-install.json').read_bytes()
    install = json.loads(pip_path.read_bytes())
    distribution = importlib.metadata.distribution(lock['oracle']['distribution'])
    assert distribution.version == lock['oracle']['version']
    metadata_root = Path(distribution._path)
    for name in ('direct_url.json', 'METADATA', 'WHEEL', 'INSTALLER', 'RECORD'):
        paths['installed-torch-metadata:' + name] = metadata_root / name
    argv = [intent['executable'], *intent['args']]
    expected_argv = [
        intent['executable'], '-B', str(SOURCE / 'pytorch_differentiable_view_input_boundaries_probe.py'),
        '--reference', str(SOURCE / 'inputs/pytorch_oracle.py'),
        '--lock', str(SOURCE / 'inputs/pytorch-oracle-lock.json'),
        '--repo', str(repo), '--output', str(SOURCE / 'actual.json')]
    assert argv == expected_argv
    actual_path = SOURCE / 'actual.json'
    assert not actual_path.exists()
    before = capture_inputs(paths)
    put('inputs-before.json', before)
    put('command.json', {'argv': argv, 'cwd': str(repo), 'executable': intent['executable'],
                         'timeout_seconds': 800, 'native_executed': False,
                         'outer_wrapper_binds_additional_sources_without_modifying_original_intent': True})
    prepared = json.loads((SOURCE / 'prepare.json').read_bytes())
    result.update(argv=argv, cwd=str(repo), python_executable=sys.executable,
                  python_resolved=str(Path(sys.executable).resolve()), python_version=sys.version,
                  python_sha256=PYTHON_SHA, actual_output=str(actual_path),
                  all_fifteen_prepared_members_read_and_verified=True,
                  upstream_originals_freshly_read_by_outer_wrapper=True,
                  probe_itself_only_reads_self_support_lock=True)
    put('execution-started.json', result)
    with (WORK / 'stdout.txt').open('xb') as so, (WORK / 'stderr.txt').open('xb') as se:
        child = subprocess.Popen(argv, cwd=repo, stdin=subprocess.DEVNULL, stdout=so, stderr=se)
        result.update(child_started=True, child_pid=child.pid)
        put('child-started.json', {'pid': child.pid, 'argv': argv, 'cwd': str(repo),
                                 'started_unix_ns': str(time.time_ns()), 'native_executed': False})
        try:
            rc = child.wait(timeout=800)
        except subprocess.TimeoutExpired:
            child.kill()
            rc = child.wait()
            raise
    result['child_completed'] = True
    after = capture_inputs(paths)
    put('inputs-after.json', after)
    assert before == after
    assert rc == 0, ('actual reference exited', rc)
    original = actual_path.read_bytes()
    report = json.loads(original)
    result['original_report'] = info(actual_path)
    result['observation_admission'] = verify_observation(report, before, prepared, lock, install)
    result['status'] = 'OBSERVED'
except BaseException:
    result['primary_error'] = traceback.format_exc()
finally:
    if not after and paths:
        try:
            after = capture_inputs(paths)
            if not (WORK / 'inputs-after.json').exists():
                put('inputs-after.json', after)
        except BaseException:
            result['after_input_error'] = traceback.format_exc()
    result.update(exit_code=rc, inputs_before=before, inputs_after=after,
                  all_inputs_unchanged=bool(before) and before == after,
                  completed_unix_ns=str(time.time_ns()), wall_seconds=time.monotonic() - tick)
    for stream in ('stdout', 'stderr'):
        stream_path = WORK / (stream + '.txt')
        if stream_path.exists():
            result['raw_' + stream] = info(stream_path)
    actual_path = SOURCE / 'actual.json'
    if actual_path.exists() and 'original_report' not in result:
        result['original_report'] = info(actual_path)
    put('execution.json', result)
    print(json.dumps({k: result[k] for k in ('status', 'exit_code', 'child_started',
                     'child_completed', 'all_inputs_unchanged', 'wall_seconds')}, allow_nan=False))
    if 'original_report' in result:
        print(json.dumps(result['original_report']))
    if result['primary_error']:
        print(result['primary_error'], file=sys.stderr)
raise SystemExit(0 if result['status'] == 'OBSERVED' else (rc if rc not in (None, 0) else 1))
