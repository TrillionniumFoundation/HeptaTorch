from pathlib import Path
import hashlib,json,lzma,tarfile,stat
base=Path(__file__).resolve().parent
infos=json.loads((base/'remote-files.json').read_text())
chunks=[]
for info in infos:
 out=base/info['name'];assert not out.exists()
 digest=hashlib.sha256()
 with out.open('xb')as target:
  for offset in range(0,info['size'],65536):
   p=base/(info['name']+'.'+str(offset).zfill(9)+'.chunk');raw=p.read_bytes();meta=json.loads(p.with_suffix('.json').read_text())
   assert len(raw)==min(65536,info['size']-offset)
   assert meta['version']==info['version']and meta['offset']==offset and meta['next_offset']==offset+len(raw)
   assert meta['size']==info['size']and meta['path']==info['path']and hashlib.sha256(raw).hexdigest()==meta['chunk_sha256']
   target.write(raw);digest.update(raw);chunks.append(meta)
 assert out.stat().st_size==info['size']and digest.hexdigest()==info['sha256']
 out.chmod(info['mode'])
manifest=json.loads((base/'evidence-manifest.json').read_text());archive=base/'raw-evidence.tar.xz'
assert manifest['archive']['sha256']==infos[0]['sha256']and manifest['member_count']==450
seen=set();summaries={};total=0
with tarfile.open(archive,'r:xz')as tar:
 for member in tar:
  path=Path(member.name)
  assert member.isfile()and not path.is_absolute()and '..'not in path.parts
  assert member.name in manifest['files']and member.name not in seen
  metadata=manifest['files'][member.name];digest=hashlib.sha256();n=0
  with tar.extractfile(member)as source:
   for block in iter(lambda:source.read(1048576),b''):digest.update(block);n+=len(block)
  assert n==member.size==metadata['bytes']and member.mode==metadata['mode']and digest.hexdigest()==metadata['sha256']
  seen.add(member.name);total+=n
  if member.name.endswith(('/original-oracle.json','/outer.json','/execution.json','/report.json','/oracle.json'))or member.name.endswith(('exact-report-binding.stdout','copied18.stdout')):
   q=base/'selected-originals'/member.name;q.parent.mkdir(parents=True,exist_ok=True);data=tar.extractfile(member).read();q.write_bytes(data);q.chmod(member.mode)
   if member.name.endswith('.json'):
    try:
     doc=json.loads(data);summaries[member.name]={k:doc[k]for k in ('status','cases','case_count','failed_cases','frames','compared_values','positive_cases','negative_cases')if k in doc}
    except json.JSONDecodeError:
     assert member.name=='unmodified-frozen35-01/execution.json'and data.endswith(b'\\n')
     summaries[member.name]={'status':'PRESERVED_ORIGINAL_METADATA_TRAILING_LITERAL_BACKSLASH_N','raw_unchanged':True}
assert seen==set(manifest['files'])and total==manifest['expanded_bytes']==94644488
with lzma.open(archive,'rb')as f:
 for _ in iter(lambda:f.read(1048576),b''):pass
report={'schema':'heptatorch.dtype523-frozen35-local-transfer-custody.v1','status':'PASS_COMPLETE_LOCAL_BYTES','native_executed':False,'Torch_executed':False,'remote_metadata':infos,'chunks':chunks,'member_count':len(seen),'expanded_bytes':total,'all_chunk_versions_offsets_lengths_SHA_verified':True,'whole_archive_SHA_verified':True,'XZ_EOF_verified':True,'every_member_size_SHA_mode_verified':True,'original_reports_not_rewritten':True,'summaries':summaries,'whole_pytorch_gate':'HOLD','full_pytorch_parity':False}
(base/'local-transfer-custody.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'archive_sha256':infos[0]['sha256'],'manifest_sha256':infos[1]['sha256'],'members':len(seen),'expanded_bytes':total,'receipt_sha256':hashlib.sha256((base/'local-transfer-custody.json').read_bytes()).hexdigest(),'summary':summaries}))
