from pathlib import Path
import ast,hashlib,json
ROOT=Path('/dev/shm/heptatorch-d26699e25fea/HeptaTorch-native-dropout-integration-11')
D=Path(__file__).resolve().parent/'tests/dtype_frozen35_accounting'
src=(ROOT/'tests/private_node_accounting/run_frozen35_accounted.py').read_text()
assert hashlib.sha256(src.encode()).hexdigest()=='65c0d68725f0585b79f88ceb5fa106526a44805eca0b58535f32b5b29916cd12'
edits=[
 ('import owner_accounting as observer','import owner_accounting523 as observer'),
 ('    custody = {name:', '    paths.update(observer.dependency_paths())\n    custody = {name:'),
 ('    (output / "invocation.json").write_text(json.dumps(invocation, indent=2) + "\\n")',
  '    (output / "invocation.json").write_text(json.dumps(invocation, indent=2) + "\\n")\n    (output / "legacy-inverse-proof.json").write_text(json.dumps(observer.inverse_proof(), indent=2) + "\\n")'),
 ('Exact actual incarnation increments and reachable private G roots; exact actual stats and reset high-water, no inequality fallback.',
  'Exact actual incarnation increments and source-derived constructor costs; full80-word owner under640 structural rules with explicit source-proved Storage tombstone correction plus inverse-proved original35 restrictions. New99/101 roles explicitly absent; exact stats/reset high-water, no inequality fallback.'),
 ('Read-only accounting repair for the additional v3 observer; all35 original case implementations and actual Torch references remain unchanged.',
  'Read-only fixed35 accounting for separately pinned523/640 owner, complete actual80-word snapshots and exact source-derived allocations. All35 original case implementations and actual Torch references unchanged. General99/101 ownership roles separately qualified; they are explicitly absent in this fixed35 command domain.')]
new=src
for before,after in edits:
 assert new.count(before)==1,before
 new=new.replace(before,after)
restored=new
for before,after in reversed(edits):
 assert restored.count(after)==1,after
 restored=restored.replace(after,before)
assert restored==src
ast.parse(new)
p=D/'run_frozen35_accounted.py';p.write_text(new)
proof={'status':'SOURCE_ADAPTATION_ONLY_NOT_EXECUTED','original_path':'tests/private_node_accounting/run_frozen35_accounted.py','original_sha256':hashlib.sha256(src.encode()).hexdigest(),'derived_path':'tests/dtype_frozen35_accounting/run_frozen35_accounted.py','derived_sha256':hashlib.sha256(new.encode()).hexdigest(),'exact_inverse_original_bytes':True,'edits':[{'before':a,'after':b,'count':1}for a,b in edits]}
(D/'launcher-adaptation.json').write_text(json.dumps(proof,indent=2)+'\n')
print(proof['derived_sha256'])
