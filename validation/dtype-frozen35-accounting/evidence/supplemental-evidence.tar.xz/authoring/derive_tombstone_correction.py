from pathlib import Path
import hashlib,json,shutil,ast
B=Path(__file__).resolve().parent;D=B/'tests/dtype_frozen35_accounting';H=B/'history/attempt-01';H.mkdir(parents=True,exist_ok=True)
for name in ('observer-input-01.tar.xz','observer-input-01-manifest.json'):
 p=Path('/dev/shm/heptatorch-d26699e25fea/dtype-frozen35-extension')/name
 q=H/name
 if not q.exists():shutil.copyfile(p,q)
for name in ('check_owner_snapshots.py','check_frozen35_accounted.py','negative-controls-adaptation.json','report-checker-adaptation.json'):
 q=H/name
 if not q.exists():shutil.copyfile(D/name,q)
old=(D.parent/'dtype_owner_accounting/owner640.py').read_text();h=lambda x:hashlib.sha256(x).hexdigest();assert h(old.encode())=='6ea9e8b33164089034a2a71a03f4850e1ec18ed1a09155d7841f700ef311c833'
a='            need(row[2] == row[3] == row[4] == 0, "expired-Storage-extent", token=sid)'
b='''            # so_storage_release clears offset/rounded/strong but retains
            # requested bytes in a same-generation Weak tombstone.
            need(row[2] == row[4] == 0, "expired-Storage-extent", token=sid)
            need(row[3] <= pool, "expired-Storage-requested-bound", token=sid)'''
assert old.count(a)==1
new=old.replace(a,b);assert new.replace(b,a)==old;ast.parse(new)
(D/'owner640_storage_tombstone.py').write_text(new)
proof={'schema':'heptatorch.owner640-storage-tombstone-correction.v1','original_source_sha256':h(old.encode()),'corrected_source_sha256':h(new.encode()),'source_only_exact_inverse_original_bytes':True,'edits':[{'before':a,'after':b,'count':1}],'native_source_sha256':'6ffe509afce28ff15705b4c7b269eaef8f8f89f9d8b2486d4d9fa45b6be66ef3','native_changed':False,'historical_original4native24copied_results_not_relabelled':True,'actual_full35_first_failure':{'original_report_sha256':'d37500707fec0c9e225c2df1cade0ad360435ee0959a1f36a86e8b0d4ae01a55','cases':35,'failed_cases':4,'all4_rule':'expired-Storage-extent'}}
(D/'storage-tombstone-correction.json').write_text(json.dumps(proof,indent=2)+'\n')
p=D/'owner_accounting523.py';raw=p.read_text()
raw=raw.replace('STRUCTURAL = HERE.parent / "dtype_owner_accounting" / "owner640.py"','ORIGINAL_STRUCTURAL = HERE.parent / "dtype_owner_accounting" / "owner640.py"\nSTRUCTURAL = HERE / "owner640_storage_tombstone.py"')
raw=raw.replace('STRUCTURAL_SHA = "6ea9e8b33164089034a2a71a03f4850e1ec18ed1a09155d7841f700ef311c833"',f'ORIGINAL_STRUCTURAL_SHA = "6ea9e8b33164089034a2a71a03f4850e1ec18ed1a09155d7841f700ef311c833"\nSTRUCTURAL_SHA = "{h(new.encode())}"')
raw=raw.replace('assert _sha(_legacy_raw) == LEGACY_SHA','assert _sha(ORIGINAL_STRUCTURAL.read_bytes()) == ORIGINAL_STRUCTURAL_SHA\nassert _sha(_legacy_raw) == LEGACY_SHA')
raw=raw.replace('        need(actual == expected, "source-constructor-ticket-count", expected=expected, actual=actual)','''        need(actual == expected, "source-constructor-ticket-count", expected=expected, actual=actual)
        # Successful destruction keeps requested bytes until the final Weak is
        # released. A same-generation tombstone never revives its payload.
        if before["length"] and after["length"]:
            for prior, current in zip(before["tables"]["2"], after["tables"]["2"]):
                if prior[1] == current[1] == 1 and prior[0] == current[0]:
                    if current[5] == 0:
                        need(current[3] == prior[3], "expired-Storage-requested-preserved")
                    if prior[5] == 0:
                        need(current[5] == 0, "expired-Storage-payload-revived")''')
raw=raw.replace('"accounting_profile": PROFILE_FILE}','"original_structural_owner640": ORIGINAL_STRUCTURAL,\n            "storage_tombstone_correction": HERE / "storage-tombstone-correction.json",\n            "accounting_profile": PROFILE_FILE}')
raw=raw.replace('need(LEGACY.read_bytes() == _legacy_raw and STRUCTURAL.read_bytes() == _structural_raw,','need(LEGACY.read_bytes() == _legacy_raw and STRUCTURAL.read_bytes() == _structural_raw\n         and _sha(ORIGINAL_STRUCTURAL.read_bytes()) == ORIGINAL_STRUCTURAL_SHA,')
raw=raw.replace('The only changed predicate is descriptor width 72 -> 80.','The only changed legacy predicate is descriptor width 72 -> 80.')
raw=raw.replace('unchanged general\n640-byte structural verifier.','general 640-byte structural verifier with one explicitly source-proved\nStorage tombstone correction (the original6ea file stays frozen).')
raw=raw.replace('The complete 640 structural check is additional, never waived.','The complete 640 structural check is additional, never waived; its one\n    # tombstone correction is independently source-bound and reversible.')
ast.parse(raw);p.write_text(raw)
q=D/'profile.json';j=json.loads(q.read_text());j['original_structural_observer_sha256']=j['structural_observer_sha256'];j['structural_observer_sha256']=h(new.encode());j['structural_claim']='Actual complete80-word nodes; original6ea structure with one explicit source-derived Storage tombstone correction. No576 projection.';q.write_text(json.dumps(j,indent=2)+'\n')
print(json.dumps({'owner_sha256':h(p.read_bytes()),'structural_sha256':h(new.encode()),'correction_sha256':h((D/'storage-tombstone-correction.json').read_bytes())}))
