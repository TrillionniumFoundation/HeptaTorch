from pathlib import Path
import ast,hashlib,json
ROOT=Path('/dev/shm/heptatorch-d26699e25fea/HeptaTorch-native-dropout-integration-11')
D=Path(__file__).resolve().parent/'tests/dtype_frozen35_accounting'
h=lambda b:hashlib.sha256(b).hexdigest()
old=(ROOT/'tests/private_node_accounting/check_owner_snapshots.py').read_text()
pin=h((D/'owner_accounting523.py').read_bytes())
edits=[("EXPECTED = '281f1ea437046a9cd884de2c8da34f38649a3b6482ade23123ac4aa992faed64'",f"EXPECTED = '{pin}'"),("choices=['gradient-objects-355','gradient-adam-distributions-428','retained-gradients-446']","choices=['dtype-native-dropout-523']"),("e['after']['nodes'][str(n)]=[0]*72","e['after']['nodes'][str(n)]=[0]*80")]
new=old
for a,b in edits:
 assert new.count(a)==1,a
 new=new.replace(a,b)
inverse=new
for a,b in reversed(edits):
 assert inverse.count(b)==1
 inverse=inverse.replace(b,a)
assert inverse==old
ast.parse(new)
(D/'check_owner_snapshots.py').write_text(new)
proof={'original_sha256':h(old.encode()),'derived_sha256':h(new.encode()),'exact_inverse_original_bytes':True,'changed_only_observer_pin_profile_choice_and_real_descriptor_width':True,'all18_original_named_rules_and_expected_rejections_unchanged':True,'edits':[{'before':a,'after':b,'count':1}for a,b in edits]}
(D/'negative-controls-adaptation.json').write_text(json.dumps(proof,indent=2)+'\n')
# The report validator retains all original35 counts, fields, tolerance checks,
# all11 provenance names, EOF and postclose Version requirements.
old=(ROOT/'tests/private_node_accounting/check_frozen35_accounted.py').read_text()
start=old.index('PROFILES={');end=old.index('\nCHECKS=',start)
profiles='PROFILES={\n "830f0b4ef8d6ad8c6a105be56d383628b45c84e3e43905fee6812c7c52d35a51":\n  ("dtype-native-dropout-523","6ffe509afce28ff15705b4c7b269eaef8f8f89f9d8b2486d4d9fa45b6be66ef3"),\n}'
launcher=h((D/'run_frozen35_accounted.py').read_bytes());profile=h((D/'profile.json').read_bytes());structural=h((D/'owner640_storage_tombstone.py').read_bytes());correction=h((D/'storage-tombstone-correction.json').read_bytes())
extra=''' assert wrapper["source_custody"]["legacy_owner_rules"]["sha256"]=="281f1ea437046a9cd884de2c8da34f38649a3b6482ade23123ac4aa992faed64"
 assert wrapper["source_custody"]["structural_owner640"]["sha256"]=="STRUCTURAL_PIN"
 assert wrapper["source_custody"]["original_structural_owner640"]["sha256"]=="6ea9e8b33164089034a2a71a03f4850e1ec18ed1a09155d7841f700ef311c833"
 assert wrapper["source_custody"]["storage_tombstone_correction"]["sha256"]=="CORRECTION_PIN"
 assert wrapper["source_custody"]["accounting_profile"]["sha256"]=="PROFILE_PIN"
 assert wrapper["profile"]["descriptor_bytes"]==640
 assert wrapper["profile"]["source_constructor_costs"] is True
 inverse=wrapper["profile"]["inverse_proof"]
 assert inverse["legacy_source_sha256"]==wrapper["source_custody"]["legacy_owner_rules"]["sha256"]
 assert inverse["structural_source_sha256"]==wrapper["source_custody"]["structural_owner640"]["sha256"]
 assert inverse["full_640_snapshot_no_projection"] is True
 assert set(inverse["functions"])=={"sha","canonical","need","word","identity","semantic_snapshot","verify_snapshot","verify_transition","Journal","install"}
 assert all(x["inverse_entire_function_AST_equals_original"] is True for x in inverse["functions"].values())
 assert sum(x["width_predicates_changed"] for x in inverse["functions"].values())==1
 assert inverse["functions"]["verify_snapshot"]["width_predicates_changed"]==1
 assert all(x["original_ast_sha256"]==x["executed_ast_sha256"] for name,x in inverse["functions"].items() if name not in ("verify_snapshot","verify_transition"))
'''.replace('PROFILE_PIN',profile).replace('STRUCTURAL_PIN',structural).replace('CORRECTION_PIN',correction)
edits=[(old[start:end],profiles),('=="281f1ea437046a9cd884de2c8da34f38649a3b6482ade23123ac4aa992faed64"',f'=="{pin}"'),('=="65c0d68725f0585b79f88ceb5fa106526a44805eca0b58535f32b5b29916cd12"',f'=="{launcher}"'),(' assert inner["frames"]==bound["frames"]',extra+' assert inner["frames"]==bound["frames"]')]
new=old
for a,b in edits:
 assert new.count(a)==1,a
 new=new.replace(a,b)
inverse=new
for a,b in reversed(edits):
 assert inverse.count(b)==1,b
 inverse=inverse.replace(b,a)
assert inverse==old
ast.parse(new)
(D/'check_frozen35_accounted.py').write_text(new)
proof={'original_sha256':h(old.encode()),'derived_sha256':h(new.encode()),'exact_inverse_original_bytes':True,'original35_counts_numeric_and_EOF_Version_gates_unchanged':True,'additional640_dependency_and_inverse_checks':True,'edits':[{'before':a,'after':b,'count':1}for a,b in edits]}
(D/'report-checker-adaptation.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({p.name:h(p.read_bytes())for p in D.iterdir()if p.is_file()}))
