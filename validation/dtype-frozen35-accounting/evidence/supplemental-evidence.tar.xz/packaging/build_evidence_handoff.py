from pathlib import Path
import hashlib
import io
import json
import os
import stat
import tarfile

RAM = Path('/dev/shm/heptatorch-d26699e25fea')
WORK = Path('/workspace/scratch/d26699e25fea')
SOURCE = WORK / 'dtype-frozen35-accounting-extension'
DOWNLOAD = RAM / 'dtype-frozen35-extension/download-01'
ROOT = RAM / 'dtype-frozen35-evidence-handoff-01'
OUT = ROOT / 'validation/dtype-frozen35-accounting/evidence'
OUT.mkdir(parents=True, exist_ok=False)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def metadata(path):
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode), path
    raw = path.read_bytes()
    assert len(raw) == st.st_size
    return {'bytes': len(raw), 'sha256': sha(raw), 'mode': stat.S_IMODE(st.st_mode)}


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')
    path.chmod(0o644)


def copy_exact(source, destination, expected=None):
    before = metadata(source)
    if expected:
        assert before['sha256'] == expected, (source, before)
    raw = source.read_bytes()
    assert sha(raw) == before['sha256']
    destination.write_bytes(raw)
    destination.chmod(0o644)
    assert metadata(source) == before
    assert destination.read_bytes() == raw
    return before


remote_archive = DOWNLOAD / 'raw-evidence.tar.xz'
remote_meta = metadata(remote_archive)
assert remote_meta == {
    'bytes': 15587512,
    'sha256': '1c3ef93dd3e7910b10dd12287959b6e841e5b2e2e71ffb09793fcc1597b4d993',
    'mode': 0o600,
}
copy_exact(DOWNLOAD / 'evidence-manifest.json', OUT / 'remote-evidence-manifest.json',
           '4344fc085e7c3e405bc2edf0c9ae73315f1fe6c6be438b3e9cc2638913f5497b')
copy_exact(DOWNLOAD / 'local-transfer-custody.json', OUT / 'local-transfer-custody.json',
           '2f1e5dfce6224465600b374fa46c82c91ae5df1ea9d00303d2d4634995436403')
parts = []
with remote_archive.open('rb') as source:
    offset = 0
    while True:
        raw = source.read(8 * 1024 * 1024)
        if not raw:
            break
        name = 'raw-evidence.tar.xz.part' + str(len(parts)).zfill(2)
        (OUT / name).write_bytes(raw)
        (OUT / name).chmod(0o644)
        parts.append({'file': name, 'offset': offset, 'bytes': len(raw), 'sha256': sha(raw)})
        offset += len(raw)
assert offset == remote_meta['bytes'] and len(parts) == 2
assert metadata(remote_archive) == remote_meta

selected = {}


def add_file(source, name):
    assert name not in selected, name
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    selected[name] = source


def add_tree(source, prefix):
    for p in sorted(source.rglob('*')):
        assert not p.is_symlink(), p
        if p.is_file():
            add_file(p, prefix + '/' + p.relative_to(source).as_posix())


add_tree(RAM / 'dtype-frozen35-extension/tombstone-control-01', 'tombstone-control-01')
add_tree(RAM / 'dtype-frozen35-extension/structural-replay-01', 'structural-replay-01')
add_tree(SOURCE / 'history', 'source-history')
for p in sorted(SOURCE.glob('*.json')):
    if p.name != 'live32-ROG-original.json':
        add_file(p, 'local-custody/' + p.name)
for p in sorted(SOURCE.glob('derive_*.py')):
    add_file(p, 'authoring/' + p.name)
for p in sorted((WORK / 'dtype-owner-accounting-extension').glob('dtype523-*.json')):
    add_file(p, 'remote-job-custody/' + p.name)
for name in ['verify_assembly.py', 'remote-files.json']:
    add_file(DOWNLOAD / name, 'download-custody/' + name)
for p in sorted(DOWNLOAD.glob('*.json')):
    if '.chunk' not in p.name and ('.tar.xz.' in p.name or '.json.' in p.name):
        add_file(p, 'download-custody/chunk-metadata/' + p.name)
add_file(RAM / 'owner640-peer-source-review-01/report.json', 'peer-source-review/original-6ea.json')
add_file(RAM / 'owner640-peer-tombstone-review-01/report.json', 'peer-source-review/tombstone-f503.json')
frozen = WORK / 'dtype-owner-accounting-extension/handoff-01'
add_file(frozen / 'tests/dtype_owner_accounting/owner640.py', 'frozen-prior/owner640.py')
add_file(frozen / 'validation/dtype-owner-accounting/raw-evidence.tar.xz', 'frozen-prior/raw-evidence.tar.xz')
for p in sorted((frozen / 'validation/dtype-owner-accounting').glob('*.json')):
    add_file(p, 'frozen-prior/' + p.name)
for name in ['protocol.py', 'owner_client.py']:
    add_file(RAM / 'HeptaTorch-native-dropout-integration-11/tests/retained_resource_review' / name,
             'frozen-prior/' + name)
add_tree(SOURCE / 'source-handoff-01', 'frozen-source-package')
add_file(Path(__file__), 'packaging/build_evidence_handoff.py')
before = {name: dict(metadata(p), source_path=str(p)) for name, p in sorted(selected.items())}
archive = OUT / 'supplemental-evidence.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as tf:
    for name, p in sorted(selected.items()):
        raw = p.read_bytes()
        meta = before[name]
        assert len(raw) == meta['bytes'] and sha(raw) == meta['sha256']
        t = tarfile.TarInfo(name)
        t.size = len(raw)
        t.mode = meta['mode']
        t.uid = t.gid = 0
        t.uname = t.gname = ''
        t.mtime = 0
        tf.addfile(t, io.BytesIO(raw))
archive.chmod(0o644)
assert all(metadata(p) == {k: before[n][k] for k in ('bytes', 'sha256', 'mode')}
           for n, p in selected.items())
seen = set()
with tarfile.open(archive, 'r:xz') as tf:
    for member in tf:
        assert member.isfile() and member.name not in seen and member.name in before
        meta = before[member.name]
        raw = tf.extractfile(member).read()
        assert len(raw) == member.size == meta['bytes']
        assert member.mode == meta['mode'] and sha(raw) == meta['sha256']
        seen.add(member.name)
assert seen == set(before)
supplement = {
    'schema': 'heptatorch.dtype523-frozen35-supplemental-custody.v1',
    'status': 'VERIFIED', 'native_executed_during_packaging': False,
    'Torch_executed_during_packaging': False,
    'archive': metadata(archive), 'member_count': len(before),
    'expanded_bytes': sum(x['bytes'] for x in before.values()),
    'files': before, 'all_original_files_before_after_unchanged': True,
    'all_members_verified': True,
    'notes': ['Original local controls, source-only peer reviews, historical source bytes and transport failures remain distinct.',
              'The historical native 4/24 archive is included unchanged as input to a pure observer replay; it is not new native execution.',
              'Original absolute paths and argv in child reports have not been rewritten.'],
}
write_json(OUT / 'supplemental-evidence-manifest.json', supplement)
index = {
    'schema': 'heptatorch.dtype523-frozen35-recoverable-evidence.v1',
    'source_package_manifest_sha256': '934aa2916e6cd00d634839b9b3676b73b62dfe70815a8a44b043dfb65b91d3b3',
    'native_source_sha256': '6ffe509afce28ff15705b4c7b269eaef8f8f89f9d8b2486d4d9fa45b6be66ef3',
    'native_executable_sha256': '830f0b4ef8d6ad8c6a105be56d383628b45c84e3e43905fee6812c7c52d35a51',
    'archives': [
        {'name': 'remote-raw', 'restored_filename': 'raw-evidence.tar.xz',
         'archive': remote_meta, 'parts': parts,
         'manifest': dict(metadata(OUT / 'remote-evidence-manifest.json'), file='remote-evidence-manifest.json'),
         'member_count': 450, 'expanded_bytes': 94644488},
        {'name': 'local-supplement', 'restored_filename': 'supplemental-evidence.tar.xz',
         'archive': metadata(archive),
         'parts': [dict(metadata(archive), file=archive.name, offset=0)],
         'manifest': dict(metadata(OUT / 'supplemental-evidence-manifest.json'), file='supplemental-evidence-manifest.json'),
         'member_count': len(before), 'expanded_bytes': supplement['expanded_bytes']},
    ],
    'whole_pytorch_gate': 'HOLD', 'pytorch_api_denominator': 2590,
    'whole_pytorch_rewrite_complete': False,
    'notes': ['Splitting changes storage representation only. Joining the listed bytes must reproduce the original complete XZ byte stream.',
              'The remote archive contains the exact runtime, executable and build receipt used for actual tests, not a new compilation or all 11 compiler unit objects.',
              'The source package and old 355/428/446 observers remain unchanged.'],
}
write_json(OUT / 'evidence-index.json', index)
print(json.dumps({'root': str(ROOT), 'index': metadata(OUT / 'evidence-index.json'),
                  'parts': parts, 'supplement_members': len(before),
                  'supplement_archive': metadata(archive)}, indent=2))
