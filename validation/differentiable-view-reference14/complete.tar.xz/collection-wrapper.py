from pathlib import Path
import hashlib
import io
import json
import lzma
import stat
import tarfile

work = Path('/home/qian-qi/heptatorch-continuation-20261116/runs/differentiable-view14-1ca74384-01')
raw_actual = (work / 'actual.json').read_bytes()
assert len(raw_actual) == 6573864
assert hashlib.sha256(raw_actual).hexdigest() == '2270d5ba925bcf91c56db94fac663695e69079c74edbf80aff8fa086e7c81665'
execution = json.loads((work / 'execution.json').read_bytes())
assert execution['status'] == 'OBSERVED' and execution['exit_code'] == 0
assert execution['cases'] == 14 and execution['probe_error_count'] == 0
assert execution['inputs_before'] == execution['inputs_after']
for item in execution['inputs_before'].values():
    p = Path(item['path'])
    assert p.is_file()
    assert len(p.read_bytes()) == item['bytes']
    assert hashlib.sha256(p.read_bytes()).hexdigest() == item['sha256']
    assert stat.S_IMODE(p.stat().st_mode) == item['mode']
assert not (work / 'result.tar.xz').exists()
assert not (work / 'result-manifest.json').exists()
files = {}
for p in sorted(work.rglob('*')):
    if p.is_file():
        assert not p.is_symlink()
        b = p.read_bytes()
        files[p.relative_to(work).as_posix()] = {'bytes': len(b),
            'sha256': hashlib.sha256(b).hexdigest(), 'mode': stat.S_IMODE(p.stat().st_mode)}
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as tf:
    for name, item in files.items():
        member = tarfile.TarInfo(name)
        member.size = item['bytes']
        member.mode = item['mode']
        member.mtime = 0
        tf.addfile(member, io.BytesIO((work / name).read_bytes()))
raw_tar = buffer.getvalue()
compressed = lzma.compress(raw_tar, preset=6)
decoder = lzma.LZMADecompressor()
restored = decoder.decompress(compressed)
assert decoder.eof and not decoder.unused_data and restored == raw_tar
seen = set()
with tarfile.open(fileobj=io.BytesIO(restored), mode='r:') as tf:
    for member in tf.getmembers():
        assert member.isfile() and member.name not in seen
        seen.add(member.name)
        item = files[member.name]
        data = tf.extractfile(member).read()
        assert len(data) == member.size == item['bytes']
        assert hashlib.sha256(data).hexdigest() == item['sha256']
        assert member.mode & 0o777 == item['mode']
assert seen == set(files)
(work / 'result.tar.xz').write_bytes(compressed)
manifest = {'schema': 'heptatorch.differentiable-view14-original-raw-archive.v1',
    'status': 'ARCHIVED_EXACT', 'actual_job_id': '1a1e63f71cd-392-3aa4',
    'file_count': len(files), 'expanded_bytes': sum(v['bytes'] for v in files.values()),
    'files': files, 'archive_bytes': len(compressed),
    'archive_sha256': hashlib.sha256(compressed).hexdigest(),
    'tar_bytes': len(raw_tar), 'tar_sha256': hashlib.sha256(raw_tar).hexdigest(),
    'all_members_bytes_modes_verified': True, 'single_xz_eof': True,
    'native_executed': False, 'torch_executed': False,
    'source_files_freshly_loaded_by_collection': list(execution['inputs_before'])}
(work / 'result-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
for name in ('actual.json', 'execution.json', 'result.tar.xz', 'result-manifest.json'):
    p = work / name
    b = p.read_bytes()
    print(json.dumps({'name': name, 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(),
        'mode': stat.S_IMODE(p.stat().st_mode)}))
print(json.dumps({'file_count': len(files), 'expanded_bytes': manifest['expanded_bytes'],
    'single_xz_eof': True, 'native_executed': False, 'torch_executed': False}))
