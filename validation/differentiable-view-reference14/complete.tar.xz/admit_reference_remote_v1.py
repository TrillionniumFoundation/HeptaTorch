#!/usr/bin/env python3
"""Independent read-only admission of the completed reference14; never imports Torch."""
import argparse, ast, hashlib, io, itertools, json, lzma, math, re, stat, tarfile, traceback
from collections import Counter
from pathlib import Path, PurePosixPath

PROBE='1ca74384675f4f5bbe1b477be827e1d405bf3ca04bc3eeaa22e4628dfe0cc1ac'
SUPPORT='ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'
LOCK='ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'
ACTUAL='2270d5ba925bcf91c56db94fac663695e69079c74edbf80aff8fa086e7c81665'
REPO='/home/qian-qi/heptatorch-continuation-20261116/repo-pr28-repair'
WORK='/home/qian-qi/heptatorch-continuation-20261116/runs/differentiable-view14-1ca74384-01'
REMOTE_PROBE='/home/qian-qi/heptatorch-continuation-20261116/runs/differentiable-view14-probe-1ca74384.py'
PYTHON='/home/qian-qi/heptatorch-continuation-20261116/runs/pr28-observer-repair/torch-venv/bin/python'
FLAGS={'python_matches','platform_matches','version_backend_matches','git_matches_oracle_build_pin','distribution_version_matches','direct_url_matches','direct_url_archive_sha256_matches','pip_report_url_matches','pip_report_archive_sha256_matches','pip_report_version_matches','pip_report_requested'}
def sha(b): return hashlib.sha256(b).hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    assert not a.output.exists()
    groups=Counter(); counts=Counter(); summaries=[]; primary=None
    def check(group,condition,location=''):
        if not condition: raise AssertionError((group,location))
        groups[group]+=1
    def tensor(t,location):
        counts['tensor_records']+=1
        keys={'tensor_identity','storage_identity','dtype','element_size','shape','strides','numel','storage_bytes','storage_offset_elements','storage_offset_bytes','storage_raw_hex','logical_bytes_hex','binary_words','version','requires_grad','is_view','base_tensor_identity'}
        check('Tensor complete schema',set(t)==keys,location)
        check('opaque actual Tensor Storage identities',all(isinstance(t[k],str) and re.fullmatch(r'[1-9][0-9]*',t[k]) for k in ('tensor_identity','storage_identity')),location)
        check('F32 and flags',t['dtype']=='torch.float32' and t['element_size']==4 and type(t['requires_grad']) is bool and type(t['is_view']) is bool,location)
        check('optional true base identity',t['base_tensor_identity'] is None or isinstance(t['base_tensor_identity'],str) and re.fullmatch(r'[1-9][0-9]*',t['base_tensor_identity']),location)
        shape, strides=t['shape'],t['strides']
        check('geometry types',isinstance(shape,list) and isinstance(strides,list) and len(shape)==len(strides) and all(type(x) is int and x>=0 for x in shape+strides),location)
        n=math.prod(shape);off=t['storage_offset_elements']
        check('numel Version offset',type(t['numel']) is int and t['numel']==n and type(t['version']) is int and t['version']>=0 and type(off) is int and off>=0 and t['storage_offset_bytes']==4*off,location)
        physical=bytes.fromhex(t['storage_raw_hex']);logical=bytes.fromhex(t['logical_bytes_hex'])
        check('full actual raw byte sizes',len(physical)==t['storage_bytes'] and len(logical)==4*n,location)
        derived=bytearray()
        for linear in range(n):
            q,at=linear,off
            for size,stride in zip(reversed(shape),reversed(strides)):
                at+=(q%size)*stride;q//=size
            word=physical[4*at:4*at+4]
            check('nonempty actual Storage extent',len(word)==4,location)
            derived.extend(word)
        words=[int.from_bytes(logical[i:i+4],'little') for i in range(0,len(logical),4)]
        check('logical bytes derived from complete Storage',bytes(derived)==logical,location)
        check('complete exact binary32 words',t['binary_words']==words and all(type(x) is int and 0<=x<2**32 for x in t['binary_words']),location)
        counts['binary32_words']+=len(words);counts['physical_bytes']+=len(physical)
    def walk(v,location):
        if isinstance(v,dict):
            if 'tensor_identity' in v: tensor(v,location);return
            for k,x in v.items():walk(x,location+'/'+k)
        elif isinstance(v,list):
            for i,x in enumerate(v):walk(x,location+'/'+str(i))
    def snapshot(s,states,location):
        counts['snapshots']+=1
        names=s['tensor_getter_order']
        check('complete ordered snapshot',names==list(s['tensors']) and len(names)==len(set(names)),location)
        check('complete graph getter slots',all(set(s[k])==set(names) for k in ('saved_getters_after_tensor_getters','edge_getters','edges_after_all_tensor_getters')),location)
        check('snapshot RNG and Weak types',s['state'] in states and all(type(x) is bool for x in s['expired'].values()),location)
        check('pairwise complete set',set(s['relations'])=={x+'|'+y for x,y in itertools.combinations(names,2)},location)
        for pair,rel in s['relations'].items():
            x,y=pair.split('|');left=s['tensors'][x]['before_grad_fn_getter'];right=s['tensors'][y]['before_grad_fn_getter']
            check('pairwise actual identities',rel['same_Tensor'] is (left['tensor_identity']==right['tensor_identity']) and rel['same_Storage'] is (left['storage_identity']==right['storage_identity']) and rel['same_current_Version_value'] is (left['version']==right['version']) and type(rel['same_Python_object']) is bool and (not rel['same_Python_object'] or rel['same_Tensor']),location+'/'+pair)
        walk(s,location)
    try:
        manifest_raw=(a.root/'result-manifest.json').read_bytes()
        check('manifest original pin',sha(manifest_raw)=='39078c1335b20e79d280046ad19ebc03c71cd4a91b18ffa3a29b705e15dc2969')
        m=json.loads(manifest_raw); archive=(a.root/'result.tar.xz').read_bytes()
        check('complete original archive',len(archive)==m['archive_bytes']==78388 and sha(archive)==m['archive_sha256']=='e8060b0561533ef66356c060dcdd2cf58318c553a833c04c2594b18aee581360')
        d=lzma.LZMADecompressor();rawtar=d.decompress(archive)
        check('single XZ EOF and complete tar',d.eof and not d.unused_data and len(rawtar)==m['tar_bytes'] and sha(rawtar)==m['tar_sha256'])
        raw={};modes={}
        with tarfile.open(fileobj=io.BytesIO(rawtar),mode='r:') as tf:
            for member in tf.getmembers():
                name=member.name;path=PurePosixPath(name)
                check('safe unique regular member',member.isfile() and not path.is_absolute() and '..' not in path.parts and name not in raw,name)
                item=m['files'][name];b=tf.extractfile(member).read();local=a.root/name
                check('all original bytes sizes modes',len(b)==member.size==item['bytes'] and sha(b)==item['sha256'] and member.mode&0o777==item['mode'] and local.read_bytes()==b and stat.S_IMODE(local.stat().st_mode)==item['mode'],name)
                raw[name]=b;modes[name]=item['mode']
        check('complete raw inventory',set(raw)==set(m['files']) and len(raw)==m['file_count']==12 and sum(map(len,raw.values()))==m['expanded_bytes']==6778504)
        check('original full actual identity',len(raw['actual.json'])==6573864 and sha(raw['actual.json'])==ACTUAL)
        r=json.loads(raw['actual.json']);e=json.loads(raw['execution.json'])
        probe_name='inputs/differentiable-view14-probe-1ca74384.py'
        for name,pin in [(probe_name,PROBE),('inputs/pytorch_oracle.py',SUPPORT),('inputs/pytorch-oracle-lock.json',LOCK),('inputs/pytorch-install.json','35ad4841c2f2f94be7ded7f1bcc97f9592f806658ff660bfac5bdc3b0cf986ef')]:
            check('original exact probe support lock install',sha(raw[name])==pin,name)
        mod=ast.parse(raw[probe_name]);functions=[n for n in mod.body if isinstance(n,ast.FunctionDef) and n.name=='plan']
        check('one literal plan function',len(functions)==1)
        namespace={}
        exec(compile(ast.Module(body=functions,type_ignores=[]),'<pinned-plan-only>','exec'),namespace)
        plan=namespace['plan']()
        check('exact pinned input plan',r['case_plan']==plan and len(plan)==14 and len({s['name'] for s in plan})==14)
        declared={}
        for node in mod.body:
            if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ('SOURCE_REF','SOURCE_PINS'):
                declared[node.targets[0].id]=ast.literal_eval(node.value)
        check('prior upstream declarations unchanged',r['primary_source_ref']==declared['SOURCE_REF'] and r['primary_source_pins']==declared['SOURCE_PINS'])
        lock=json.loads(raw['inputs/pytorch-oracle-lock.json']);prov=r['oracle_provenance'];expected=lock['oracle'];obs=prov['observed']
        check('whole locked provenance',prov['status']=='PASS' and prov['expected']==expected and prov['release_source_equivalence']==lock['release_source_equivalence'] and prov['lock_sha256']==LOCK and prov['lock_path']==REPO+'/compatibility/pytorch-oracle-lock.json' and prov['metadata_error'] is None)
        check('all eleven exact source flags',set(prov['checks'])==FLAGS and all(x is True for x in prov['checks'].values()))
        check('complete observed source fields',set(obs)=={'python','platform','version','git_commit','backend_versions','distribution_version','direct_url','install_report'})
        check('actual Python platform backend and package',obs['python']==dict(expected['python'],full_version='3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0]') and obs['platform']==expected['platform'] and obs['backend_versions']==expected['backend_versions'] and obs['version']==obs['distribution_version']==expected['version'] and obs['git_commit']==expected['git_commit'])
        w=expected['wheel'];direct={'url':w['url'],'archive_info':{'hash':'sha256='+w['sha256'],'hashes':{'sha256':w['sha256']}}}
        check('full direct URL and both hashes',obs['direct_url']==direct)
        pip=json.loads(raw['inputs/pytorch-install.json']);matches=[x for x in pip['install'] if x['metadata']['name'].lower()=='torch']
        check('one actual requested locked wheel',len(matches)==1 and matches[0]['requested'] is True and matches[0]['download_info']==direct and matches[0]['metadata']['version']==expected['version'])
        check('whole install provenance',obs['install_report']=={'path':expected['install_report'],'pip_version':pip['pip_version'],'download_info':direct,'metadata_name':'torch','metadata_version':expected['version'],'requested':True})
        check('observation scope unchanged',r['status']=='OBSERVED' and r['cases']==len(r['rows'])==14 and r['probe_errors']==[] and r['probe_error_count']==0 and r['torch_executed'] is True and r['native_executed'] is False and r['native_qualified'] is False and r['full_pytorch_rewrite_complete'] is False and r['closed_schema_count']==0)
        env={'deterministic_algorithms':True,'deterministic_fill':True,'grad_enabled':True,'num_threads':1,'cpu_capability':'AVX512'}
        check('execution environment restored',r['environment_before']==r['environment_after']==env and r['environment_restored'] is True and r['original_outer_rng_restored'] is True and r['num_threads']==1 and r['cpu_capability']=='AVX512')
        check('full RNG inventory',len(r['states'])==r['unique_complete_states']>0)
        for key,v in r['states'].items():
            b=bytes.fromhex(v['hex']);check('whole Generator bytes',len(b)==v['bytes']==5056 and sha(b)==key,key)
        totals=Counter(attempted=0,succeeded=0,raised=0)
        for i,(spec,row) in enumerate(zip(plan,r['rows'])):
            check('all exact planned recipes',row['index']==i and row['status']=='OBSERVED' and all(row[k]==v for k,v in spec.items()),row['name'])
            check('row RNG references',row['state_before_setup'] in r['states'] and row['state_after'] in r['states'],row['name'])
            backwards=[]
            for j,event in enumerate(row['events']):
                loc=str(i)+'/'+str(j)+'/'+event['label']
                check('actual operation outcome',type(event['accepted']) is bool and event['outcome']==('SUCCEEDED' if event['accepted'] else 'RAISED') and (event['error'] is None if event['accepted'] else set(event['error'])=={'type','message'} and all(isinstance(x,str) for x in event['error'].values())),loc)
                totals['attempted']+=1;totals['succeeded' if event['accepted'] else 'raised']+=1
                snapshot(event['before'],r['states'],loc+'/before');snapshot(event['after'],r['states'],loc+'/after')
                if 'returned' in event:walk(event['returned'],loc+'/returned')
                if event['label'].startswith('backward'):
                    gradients={}
                    for name,t in event['after']['tensors'].items():
                        if name not in ('base','middle','view','view1','view2'):continue
                        g=t['gradient'].get('tensor')
                        gradients[name]=None if g is None else {k:g[k] for k in ('tensor_identity','storage_identity','shape','strides','version','binary_words')}
                    backwards.append({'label':event['label'],'accepted':event['accepted'],'error':event['error'],'gradients_after':gradients})
            snapshot(row['before_final_drops'],r['states'],str(i)+'/before_final_drops')
            check('Weak outcomes typed',row['final_expired'] and all(type(x) is bool for x in row['final_expired'].values()),row['name'])
            summaries.append({'index':i,'name':row['name'],'operations':len(row['events']),'backward':backwards,'final_expired':row['final_expired']})
        check('all observed operation totals',dict(totals)==r['operation_totals']=={'attempted':209,'succeeded':207,'raised':2})
        check('actual wrapper completed',e['status']=='OBSERVED' and e['exit_code']==0 and e['primary_error'] is None and e['subprocess_started'] is True and e['native_executed'] is False and e['torch_executed'] is True and e['all_inputs_unchanged'] is True and e['inputs_before']==e['inputs_after'])
        bindings={'probe':(probe_name,REMOTE_PROBE),'support':('inputs/pytorch_oracle.py',REPO+'/tests/pytorch_oracle.py'),'lock':('inputs/pytorch-oracle-lock.json',REPO+'/compatibility/pytorch-oracle-lock.json'),'install':('inputs/pytorch-install.json',REPO+'/build/pytorch-install.json')}
        expected_inputs={key:{'path':path,'bytes':len(raw[name]),'sha256':sha(raw[name]),'mode':modes[name]} for key,(name,path) in bindings.items()}
        check('four actual input identities before and after',e['inputs_before']==expected_inputs and json.loads(raw['inputs-before.json'])==expected_inputs)
        check('three probe source-file hashes',r['source_files_unchanged'] is True and r['inputs_sha256']=={bindings[k][1]:expected_inputs[k]['sha256'] for k in ('probe','support','lock')})
        argv=[PYTHON,'-B',REMOTE_PROBE,'--reference',bindings['support'][1],'--lock',bindings['lock'][1],'--repo',REPO,'--output',WORK+'/actual.json']
        check('exact CLI and interpreter',e['argv']==json.loads(raw['command.json'])==argv and e['cwd']==REPO and e['python_sha256']=='e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f')
        check('original report byte binding',e['original_report']=={'path':WORK+'/actual.json','bytes':6573864,'sha256':ACTUAL,'mode':modes['actual.json']})
        for stream in ('stdout','stderr'):
            check('whole original child logs',e['raw_'+stream]=={'path':WORK+'/'+stream+'.txt','bytes':len(raw[stream+'.txt']),'sha256':sha(raw[stream+'.txt']),'mode':modes[stream+'.txt']},stream)
        check('child process genuinely started',json.loads(raw['child-started.json'])['child_started'] is True and json.loads(raw['child-started.json'])['pid']==e['child_pid'])
        check('chronology within original host',int(e['started_unix_ns'])<=int(e['completed_unix_ns']) and 0<e['wall_seconds']<800)
    except BaseException:
        primary=traceback.format_exc()
    result={'schema':'heptatorch.differentiable-view14-independent-remote-readonly-admission.v1','status':'PASS' if primary is None else 'FAIL','original_report_sha256':ACTUAL,'probe_sha256':PROBE,'original_actual_job_id':'1a1e63f71cd-392-3aa4','reader_sha256':sha(Path(__file__).read_bytes()),'checks_passed':sum(groups.values()),'check_groups':dict(groups),'observations_verified':dict(counts),'cases':summaries,'primary_error':primary,'new_native_executions':0,'new_torch_executions':0,'plan_only_evaluated_from_pinned_AST':True,'source_pin_boundary':'Six upstream source pins are prior declarations, not six upstream files freshly read by the actual run.','local_predecessor':'Cloud functions cell g2:13 was terminated after environment unavailable, local source-write/offline-audit completion UNKNOWN; no native or Torch requested there.','native_qualification':False,'closed_schema_count':0,'full_pytorch_rewrite_complete':False}
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'checks_passed':result['checks_passed'],'observations_verified':dict(counts),'bytes':a.output.stat().st_size,'sha256':sha(a.output.read_bytes()),'primary_error':primary}))
    return 0 if primary is None else 1
if __name__=='__main__':raise SystemExit(main())
