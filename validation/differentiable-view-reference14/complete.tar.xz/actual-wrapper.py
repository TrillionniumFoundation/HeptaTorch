from pathlib import Path
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import time
import traceback

repo = Path('/home/qian-qi/heptatorch-continuation-20261116/repo-pr28-repair')
work = Path('/home/qian-qi/heptatorch-continuation-20261116/runs/differentiable-view14-1ca74384-01')
transported = Path('/home/qian-qi/heptatorch-continuation-20261116/runs/differentiable-view14-probe-1ca74384.py')
pins = {
    'probe': (transported, '1ca74384675f4f5bbe1b477be827e1d405bf3ca04bc3eeaa22e4628dfe0cc1ac'),
    'support': (repo / 'tests/pytorch_oracle.py', 'ef8fe89aa7dbff4ee03f9d5762d2736a3648d9e48e97ad5df7bec615676f04ae'),
    'lock': (repo / 'compatibility/pytorch-oracle-lock.json', 'ca2e54ce65083bbe0ab3d47b6878971271765ab35a9dd70725fa345fceed3944'),
    'install': (repo / 'build/pytorch-install.json', '35ad4841c2f2f94be7ded7f1bcc97f9592f806658ff660bfac5bdc3b0cf986ef'),
}


def info(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'mode': stat.S_IMODE(path.stat().st_mode)}


assert Path.cwd().resolve() == repo
before = {name: info(path) for name, (path, expected) in pins.items()}
for name, (path, expected) in pins.items():
    assert before[name]['sha256'] == expected, name
assert hashlib.sha256(Path(sys.executable).resolve().read_bytes()).hexdigest() == 'e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f'
os.umask(0o077)
work.mkdir(mode=0o700, exist_ok=False)
(work / 'inputs').mkdir(mode=0o700)
for name, (path, expected) in pins.items():
    shutil.copy2(path, work / 'inputs' / path.name)
(work / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
argv = [sys.executable, '-B', str(transported), '--reference', str(pins['support'][0]),
        '--lock', str(pins['lock'][0]), '--repo', str(repo), '--output', str(work / 'actual.json')]
(work / 'command.json').write_text(json.dumps(argv, indent=2) + '\n')
started = time.time_ns()
tick = time.monotonic()
rc = None
primary = None
child_started = False
child_pid = None
(work / 'execution-started.json').write_text(json.dumps({'schema': 'heptatorch.reference14-execution-intent.v1',
    'argv': argv, 'started_unix_ns': str(started), 'child_started': False,
    'native_executed': False}, indent=2) + '\n')
try:
    with (work / 'stdout.txt').open('xb') as so, (work / 'stderr.txt').open('xb') as se:
        child = subprocess.Popen(argv, cwd=repo, stdin=subprocess.DEVNULL, stdout=so, stderr=se)
        child_started = True
        child_pid = child.pid
        (work / 'child-started.json').write_text(json.dumps({'pid': child_pid, 'argv': argv,
            'child_started': True, 'started_unix_ns': str(time.time_ns())}, indent=2) + '\n')
        try:
            rc = child.wait(timeout=800)
        except subprocess.TimeoutExpired:
            child.kill()
            rc = child.wait()
            raise
except BaseException:
    primary = traceback.format_exc()
after = {name: info(path) for name, (path, expected) in pins.items()}
result = {'schema': 'heptatorch.differentiable-view14-original-execution.v1', 'status': 'FAIL',
    'host': 'rog', 'argv': argv, 'cwd': str(repo), 'python_executable': sys.executable,
    'python_resolved': str(Path(sys.executable).resolve()), 'python_version': sys.version,
    'python_sha256': hashlib.sha256(Path(sys.executable).resolve().read_bytes()).hexdigest(),
    'started_unix_ns': str(started), 'completed_unix_ns': str(time.time_ns()),
    'wall_seconds': time.monotonic() - tick, 'exit_code': rc, 'primary_error': primary,
    'subprocess_started': child_started, 'child_pid': child_pid,
    'native_executed': False, 'inputs_before': before, 'inputs_after': after,
    'all_inputs_unchanged': before == after, 'whole_pytorch_rewrite_complete': False,
    'upstream_source_files_freshly_loaded_by_this_run': False}
for stream in ('stdout', 'stderr'):
    path = work / (stream + '.txt')
    if path.exists():
        result['raw_' + stream] = info(path)
observed = False
path = work / 'actual.json'
if path.exists():
    report = json.loads(path.read_bytes())
    result['original_report'] = info(path)
    result['probe_status'] = report.get('status')
    result['cases'] = report.get('cases')
    result['probe_error_count'] = report.get('probe_error_count')
    result['operation_totals'] = report.get('operation_totals')
    result['torch_executed'] = report.get('torch_executed') is True
    result['provenance_checks'] = report.get('oracle_provenance', {}).get('checks', {})
    result['source_files_unchanged'] = report.get('source_files_unchanged')
    observed = (rc == 0 and primary is None and child_started and before == after
        and report.get('status') == 'OBSERVED' and report.get('cases') == 14
        and len(report.get('rows', [])) == 14 and report.get('probe_error_count') == 0
        and report.get('probe_errors') == [] and report.get('torch_executed') is True
        and report.get('source_files_unchanged') is True
        and len(result['provenance_checks']) == 11
        and all(value is True for value in result['provenance_checks'].values()))
result['status'] = 'OBSERVED' if observed else 'FAIL'
(work / 'execution.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('status', 'exit_code', 'cases', 'probe_error_count',
    'operation_totals', 'all_inputs_unchanged', 'wall_seconds') if k in result}))
if 'original_report' in result:
    print(json.dumps(result['original_report']))
raise SystemExit(0 if observed else (rc if rc not in (None, 0) else 1))
