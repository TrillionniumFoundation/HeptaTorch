# Direct differentiable as_strided: fixed actual reference14

The unchanged probe 1ca74384675f4f5bbe1b477be827e1d405bf3ca04bc3eeaa22e4628dfe0cc1ac executed once on the pinned CPU Torch environment. Durable job 1a1e63f71cd-392-3aa4 succeeded with exit 0. Original actual.json is 6,573,864 bytes, SHA256 2270d5ba925bcf91c56db94fac663695e69079c74edbf80aff8fa086e7c81665.

There are 14 OBSERVED recipes, zero probe errors, and 209 actual operations: 207 succeeded and two raised RuntimeError. The exceptions are the nonleaf retry after default Saved release, and the Saved Version 1 versus expected 0 case. These are preserved observed outcomes, not probe errors.

A separate read-only admission ran as job 1a1e64621c1-392-3ab0. It executed no Torch or native binary. Its 41,095 checks bind complete original archive members, source/input bytes, all eleven full provenance fields, the 14 fixed input plans, 432 snapshots, 2,539 Tensor records, 14,126 binary32 words and 57,144 physical bytes. It reconstructs every recorded logical Tensor value from its complete Storage bytes. Original Tensor/Storage identity strings and Version values remain unchanged.

The immutable original collection archive contains twelve files and 6,778,504 expanded bytes. The package additionally preserves exact tool response text, complete durable stdout/stderr and EOF facts, fixedVersion/chunk/full-file recovery records, requests, wrappers, admission source and original admission report. No JSON large-integer tool fingerprint was parsed and rewritten as the original evidence.

The six upstream source pins in the probe are prior source-audit declarations. This actual execution newly hashes the probe, support and lock; the install report is separately pinned. It did not freshly read six upstream source files.

Cloud failed during a new local source-write/offline-admission request. That request remains INTERRUPTED/UNKNOWN in local-interruption.json; no native or Torch was requested there. The final remote read-only admission is a separate actual execution, not a relabeling of the unknown local request. The original pre-run Cloud source-review receipt bytes could not be included after the outage; its exact path/hash and reviewed scope are retained in source-review-locator-and-notes.json. The reviewed probe bytes are included in full.

This is a reference packet, not native implementation qualification. Complete API/schema closure remains unclaimed. The full getter order and intentional retained roots are part of the reference, including lazy history refresh. Weak observations concern Storage lifetime, not Python wrapper refcount equivalence.

Replay the read-only admission after extracting the payload, with a new output path:
python -B admit_reference_remote_v1.py --root original --output /absolute/new/reference-admission.json

The complete.tar.xz manifest covers every payload file. Manifest, archive and outer verification are excluded from their own inventory. The original source path in the archived command remains a ROG path and is not rewritten for portability.
