# Scalar07b four-suite pure raw admission

This is a new, read-only admission program for the frozen 26 + 32 + 14 + 4
native sessions. It does not invoke an ELF, compiler, Torch, numerical model,
process-memory reader, or a replacement oracle. The original 76 runtime results
and original05/06 failures remain unchanged.

## Execution boundary

A Python audit hook rejects subprocess, exec/fork/spawn, network connects and
/proc opens. Native and Session constructors are never called. The original
observer.Native.create/one only serialize requests into RecordedSession.
Every generated request must match the original framed request bytes at the
same frame; the response is the already-captured original bytes. A mismatch
fails admission rather than skipping ahead.

The frozen family Case.execute body is invoked unchanged. It constructs only
the original inputs, commands and root-publication schedule. Original check,
Tensor/Storage bijections, tensor, compare_node, weak checks and input helper
methods are inherited. An explicit I/O adapter reads captured observations;
it does not calculate gradients, casts, output layouts or expected words.

## Reference and getter order

Reference26 remains fecf1956. The exact 225472f6 lifetime-label adapter and
b37c58e5 event reader are bound. Its proof is recomputed byte-for-byte,
including two proven Scalar64 retirements, 208 annotations, 24 untouched rows,
six copied controls, and the complete inverse to the original JSON.

Reference32 remains f3ecc9dd. Its own original 7386703b ScalarCase.execute and
reference admission are used. The snapshot consumer preserves this ordering
for each Tensor: raw, grad_fn metadata, Saved getters, is_leaf, retains_grad,
gradient and then public logical bytes. Saved.other remains a real original
8-byte float64 Tensor. Reference32 does not observe Weak expiry; no such
reference claim is added by this program.

Original14 uses deb9f6fa and originalinput4 uses 5b8809eb. Their event mappings,
references and normalized error rules stay fixed. The 52c3b324 numeric and
identity predicates are not weakened or replaced by summary PASS counts.

## What is independently recomputed

* Every framed request/response, exact generated packet, response opcode/status,
  all four backward payload words as raw diagnostics, original transport rows
  and recorded EOF exit0.
* Every exported Tensor/gradient, dtype, layout, offset, physical/logical bytes,
  exact integer words, Version, Saved result/error, AD edge, live identity,
  retained-warning condition and full5056 RNG comparison.
* Each unique exported complete owner, with all original84Q ownership predicates
  from e54509ce. The three constant-only edits from 0dc6af8d are reversed byte
  for byte before use. The general isolated-ViewInfo-transition checker is not
  invoked and is not claimed passed.
* Raw owner corroboration of stable Tensor/gradient/Saved/Accum geometry,
  physical storage, identities and final edge records. Dynamic pre-getter
  requires/leaf/history fields are compared to the exported original
  observations, not falsely reconstructed from a later owner.
* Full public/Weak/Hold/generator capability sets at exported owner boundaries
  are derived from the actual recorded responses and checked against the owner.

## What is not fabricated

The original native readers made intermediate /proc reads without exporting
each of them. This program cannot recreate those bytes. Original issue()
performed full before/after rollback assertions; when a preceding frame also
has an exported owner, this admission compares the actual pointer, length and
entire before/after byte strings again. Other refusal frames retain their exact
raw status and exported after-owner, and their original source-bound executed
rollback counts are reported separately. They are not relabeled newly
recomputed before/after byte equality.

Native backward completed-node/leaf/failure-op counters are bound to their
original four-Q payload, not promoted to Torch observations. No generic Python
wrapper refcount equivalence, arbitrary CPU dispatch, new Weak observation or
full PyTorch schema closure is inferred.

## Preparation

The --prepare-only command verifies the complete 3200-member archive and all
original SHA/size/mode bindings, the original reference admissions, exact
epoch proof/inverse, actual658/13 build inputs and frozen module pins. It does
not run a case admission. The complete source and this prepared result are
submitted to root for review before the single full pure admission.

Only output files under a new directory are created. All existing evidence,
production sources, root integration files and native cases remain read-only.
