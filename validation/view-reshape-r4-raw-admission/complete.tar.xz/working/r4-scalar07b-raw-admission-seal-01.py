#!/usr/bin/env python3
"""Freeze completed pure admission and its first host failure; no numerical execution."""
from pathlib import Path
from collections import Counter
import hashlib, json, stat, tarfile, runpy
R=Path("/home/qian-qi/heptatorch-continuation-20261116/runs")
O=R/"r4-scalar07b-raw-admission-handoff-01"
O.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
pinned={
"r4-scalar07b-raw-admission-source-01/admit_scalar07b_raw.py":"1e58841782579ca14a14e7106087444e93e16fcb9709fe763525c8018deeb653",
"r4-scalar07b-raw-admission-source-01/configuration.json":"c244571fbd7ca1503dc0e6643da05dc321c7fb4e52de5d55498503eea01b9864",
"r4-scalar07b-raw-admission-source-01/DESIGN.md":"487cb259850e7827d831cb3fbf94d451fe1f8312b9f29de276b14a33eacb9623",
"r4-scalar07b-raw-admission-source-02/admit_scalar07b_raw.py":"20b23badd9393a8f8ed8bdc23dc7bfbcc991ebabe007257297fd5e9b40ee3529",
"r4-scalar07b-raw-admission-source-02/helper-inverse-and-smoke.json":"e2a356e4bef976eac1cdc1261820cc97ad640bcaaf25db70e0df70401fc88659",
"r4-scalar07b-raw-admission-source-02/source01-to-source02.diff":"52a564f85423d17e4bb60eaf7f78f3c2e2cae619edb499e1f761dd4872f21044",
"r4-scalar07b-raw-admission-01/report.json":"c176ba43986598be6821fe5b878a8a3c7008fb190560e5ceb364247f9df49968",
"r4-scalar07b-raw-admission-02/report.json":"33a2537b83244c2c489dc54e395fd656d08ff08d00447c9e9aa9d6b638691a22",
"r4-scalar07b-raw-admission-01-tool-custody.json":"f8b2df2ce86849c550fbdea6c1526a553032fdb5fcf58ef7c71052872de2d30f",
"r4-scalar07b-raw-admission-02-tool-custody.json":"6d9c443a0b9069a660edf6b1d26902a5f2b80741a615934db449a6d99224da1d",
"root-scalar07b-pure-raw-admission-authorization-v1.json":"c49e8548df03e79307e6bde9b6088e02352a35d6f58b81d380f96314e4698eda",
"root-scalar07b-pure-raw-admission-authorization-v2.json":"5985c9c4fa9b94f8fa9a31048d08d54d1c28f92f174479add0a6468da3157350",
"autograd-scalar07b-raw-admission-source-review-01.json":"100cd3d43d801a92e9dc3c30f176b5907e77c89efe3dee95f1feb0f433be76a3",
"autograd-scalar07b-source02-two-line-review.json":"7b7e3e7c1e11e805999b14523aa8e2d0d1d259c8100d74a03865f7ee625c34e3",
"r4-scalar07b-raw-admission-verify-01.py":"193a7d01cec07c2e0fc0ed44f1738687b5644df7c4136baa2c775e0a6339e9ad"}
for rel,h in pinned.items():
    assert sha((R/rel).read_bytes())==h,rel
def readj(rel):
    return json.loads((R/rel).read_bytes())
def emit(name,value):
    p=O/name
    raw=value if isinstance(value,bytes) else (json.dumps(value,indent=2,allow_nan=False)+"\n").encode()
    with p.open("xb") as f:f.write(raw)
    p.chmod(0o644)
    return p
def tool(value):
    return json.loads(next(x["text"] for x in value["content"] if x["type"]=="text"))
good=readj("r4-scalar07b-raw-admission-02/report.json")
bad=readj("r4-scalar07b-raw-admission-01/report.json")
assert good["status"]=="PASS_PURE_RECORDED_EVIDENCE" and good["error"] is None
assert good["all_inputs_unchanged"] and good["audit_guard"]=={"process_attempts":0,"proc_memory_attempts":0}
assert bad["status"]=="FAIL_PURE_ADMISSION" and bad["cases"]==[]
assert bad["error"]["type"]=="TypeError" and "multiple values" in bad["error"]["message"]
assert bad["all_inputs_unchanged"] and bad["audit_guard"]=={"process_attempts":0,"proc_memory_attempts":0}
assert Counter(c["suite"] for c in good["cases"])=={"26":26,"32":32,"14":14,"4":4}
metrics=("pure_comparisons","exact_words_recomputed","full_rng_bytes_recomputed",
"all_raw_frames_generated_and_matched","exported_snapshots_compared",
"physical_Tensor_reads_from_full_owner","full_owner_blobs_invariant_checked",
"full_owner_records","directly_exported_adjacent_rollback_pairs",
"directly_exported_adjacent_rollback_bytes","original_refusal_bytes_source_bound",
"refusals_without_exported_immediate_before_owner")
for key in metrics:
    assert good[key]==sum(c[key] for c in good["cases"]),key
for case in good["cases"]:
    assert case["status"]=="PASS_PURE_RECORDED_EVIDENCE" and case["recorded_native_exit_code"]==0
    p=R/"r4-scalar07b-raw-admission-02"/("suite-"+case["suite"])/("case-%02d"%case["index"])/"report.json"
    assert json.loads(p.read_bytes())==case,str(p)
assert (good["exact_words_recomputed"],good["full_rng_bytes_recomputed"],good["all_raw_frames_generated_and_matched"],
good["original_refusal_bytes_source_bound"])==(66165,11295104,82503,2143906608)
assert good["original_full_assertions"]==481580
successful=readj("r4-scalar07b-raw-admission-02-tool-custody.json")
failed=readj("r4-scalar07b-raw-admission-01-tool-custody.json")
s=tool(successful["status"])
f=tool(failed["terminal"])
assert s["state"]=="succeeded" and s["exit_code"]==0 and s["output_complete"] and s["output_durable"]
assert f["state"]=="failed" and f["exit_code"]==1 and f["output_complete"] and f["output_durable"]
stdout=b"";offset=0
for chunk in successful["log_chunks"]:
    log=tool(chunk)
    a,b=log["stdout"],log["stderr"]
    assert a["offset"]==offset and b["offset"]==0 and b["next_offset"]==0 and b["text"]==""
    raw=bytes.fromhex(a["bytes_hex"])
    assert raw==a["text"].encode()
    assert offset+len(raw)==a["next_offset"]
    stdout+=raw;offset=a["next_offset"]
assert a["eof"] and b["eof"] and len(stdout)==s["log_bytes"]["stdout"]["stored"]==6998
assert s["log_bytes"]["stderr"]["stored"]==0
terminal_lines=[json.loads(line) for line in stdout.splitlines()]
assert len(terminal_lines)==77 and all(x["status"]=="PASS_PURE_RECORDED_EVIDENCE" for x in terminal_lines)
firstlog=tool(failed["logs"])
assert firstlog["stdout"]["eof"] and firstlog["stderr"]["eof"] and firstlog["stderr"]["text"]==""
assert len(bytes.fromhex(firstlog["stdout"]["bytes_hex"]))==f["log_bytes"]["stdout"]["stored"]==1972
config=readj("r4-scalar07b-raw-admission-source-01/configuration.json")
native=R/config["package_directory"]
assert sha((native/"package-manifest.json").read_bytes())==config["package_manifest_sha256"]
assert sha((native/"file-manifest.json").read_bytes())==config["member_manifest_sha256"]
assert (native/"complete.tar.xz").stat().st_size==config["archive_bytes"]
assert sha((native/"complete.tar.xz").read_bytes())==config["archive_sha256"]
selected={}
def add(p):
    p=Path(p)
    assert p.is_file() and not p.is_symlink(),str(p)
    rel=p.relative_to(R).as_posix()
    selected["working/"+rel]=p
for directory in ("r4-scalar07b-raw-admission-source-01","r4-scalar07b-raw-admission-source-02",
"r4-scalar07b-raw-admission-prepare-01","r4-scalar07b-raw-admission-01","r4-scalar07b-raw-admission-02"):
    for p in sorted((R/directory).rglob("*")):
        assert not p.is_symlink(),str(p)
        if p.is_file():add(p)
for rel in pinned:add(R/rel)
for rel in ("r4-scalar07b-raw-admission-source02-create.request.json",
"r4-scalar07b-raw-admission-seal-01.request.json"):
    add(R/rel)
add(Path(__file__))
for entry in config["modules"].values():
    p=R/entry["path"]
    assert sha(p.read_bytes())==entry["sha256"]
    add(p)
p=R/config["owner_inverse"]["path"]
assert sha(p.read_bytes())==config["owner_inverse"]["sha256"];add(p)
for spec in config["suites"]:
    for name in ("reference","probe"):
        p=R/spec[name]["path"]
        assert sha(p.read_bytes())==spec[name]["sha256"];add(p)
    p=R/spec["directory"]/"report.json"
    assert sha(p.read_bytes())==spec["report_sha256"];add(p)
    add(R/spec["intent_path"])
for p in native.iterdir():
    if p.is_file() and p.name!="complete.tar.xz":add(p)
rows=[]
for arc,p in sorted(selected.items()):
    raw=p.read_bytes()
    rows.append({"path":arc,"source_path":str(p),"bytes":len(raw),"sha256":sha(raw),
                 "mode":stat.S_IMODE(p.stat().st_mode)})
member_manifest={"schema":"heptatorch.scalar07b.pure-raw-admission-members.v1",
"members":rows,"member_count":len(rows),"payload_bytes":sum(r["bytes"] for r in rows),
"manifest_itself_is_additional_archive_member":True,
"original_native_raw_dependency_is_external":True}
emit("file-manifest.json",member_manifest)
cases_by_suite={}
for family in ("26","32","14","4"):
    cases=[c for c in good["cases"] if c["suite"]==family]
    cases_by_suite[family]={"cases":len(cases),**{key:sum(c[key] for c in cases) for key in metrics}}
summary={"schema":"heptatorch.scalar07b.pure-raw-admission-summary.v1",
"status":"PASS_PURE_RECORDED_EVIDENCE","cases":76,
"qualification_report_sha256":pinned["r4-scalar07b-raw-admission-02/report.json"],
"first_FAILURE_report_sha256":pinned["r4-scalar07b-raw-admission-01/report.json"],
"source_sha256":good["source_sha256"],"native_sha256":good["native_sha256"],"build_sha256":good["build_sha256"],
"functions":658,"native_units":13,"descriptor_bytes":672,
"admission_reader_sha256":pinned["r4-scalar07b-raw-admission-source-02/admit_scalar07b_raw.py"],
"owner_sha256":good["owner_observer_sha256"],
"totals":{key:good[key] for key in metrics},"suites":cases_by_suite,
"original_native_assertions":481580,
"original_native_rollback_bytes":2143906608,
"rollback_scope":"Direct adjacent before/after exported pairs are a subset of the original rollback claims. Other original refusal checks are source-bound executed assertions; missing before-images are not reconstructed.",
"pure_counter_scope":"pure_comparisons counts the unchanged Case.check calls replayed in this admission; wire/archive/owner invariant checks are additional explicitly required predicates and are not silently added to that number.",
"whole_inputs":len(readj("r4-scalar07b-raw-admission-02/inputs.json")),
"all_inputs_unchanged":True,"recorded_case_EOF_count":76,
"new_native_executions":0,"new_Torch_executions":0,"new_compiler_executions":0,
"new_fixed_oracle_computations":0,
"unexported_intermediate_memory_recreated":False,"general_ViewInfo_transition_checker_invoked":False,
"first_attempt":{"job":"1a1e7971d87-392-3df6","exit_code":1,"both_EOF":True,
"status":"FAIL_PURE_ADMISSION","error":"TypeError in pure helper argument naming before first completed case"},
"second_attempt":{"job":"1a1e79d1c7a-392-3e16","exit_code":0,"both_EOF":True,"status":"PASS_PURE_RECORDED_EVIDENCE"},
"source_correction":"Only need's positional argument name and its diagnostic value changed; whole-file forward/inverse exact. All comparison callsites/config/original helpers/references unchanged.",
"full_pytorch_status":"HOLD","closed_schema_count":0,"pytorch_api_denominator":2590,
"derivative_inventory":688,"system_acceptance_gates":17,
"archive_contains_complete_76_pure_case_reports":True,
"archive_contains_complete_frozen_reference_bytes":True,
"native_raw_archive_unchanged_and_separately_frozen":True}
emit("summary.json",summary)
emit("qualification-report.json",(R/"r4-scalar07b-raw-admission-02/report.json").read_bytes())
emit("first-failure-report.json",(R/"r4-scalar07b-raw-admission-01/report.json").read_bytes())
dependency={"schema":"heptatorch.scalar07b.pure-admission-external-native-evidence.v1",
"original_directory":str(native),
"package_manifest_sha256":config["package_manifest_sha256"],
"member_manifest_sha256":config["member_manifest_sha256"],
"archive_sha256":config["archive_sha256"],"archive_bytes":config["archive_bytes"],
"members":3200,"payload_bytes":169145041,
"not_copied_inside_this_archive":True,
"reason":"The immutable native packet is already separately delivered. This packet retains its complete manifests/custody and all original pure-admission inputs and reports; native wire/owner/build bytes remain in that exact external packet.",
"optional_full_byte_reverification":"Pass --native-package PATH to verify_evidence.py; this checks all3200 original members without invoking any test."}
emit("external-native-package.json",dependency)
verify_bytes=(R/"r4-scalar07b-raw-admission-verify-01.py").read_bytes()
emit("verify_evidence.py",verify_bytes)
readme="""# Final07b four-suite pure raw admission

The frozen native 26+32+14+4 sessions passed, then this independent read-only
admission consumed all76 sessions from their original raw packets. It does not
execute an ELF, compiler, Torch operation, expected-value model or /proc read.

qualification-report.json is the complete original989987-byte report. The
archive includes all76 complete pure case reports, both admission source
versions, complete fixed helpers/references, config, exact source inverse,
helper-only smoke, root/peer source reviews, requests and durable terminal
receipts. first-failure-report.json retains the original helper-argument
TypeError with no completed semantic case. The successor changed only need's
formal parameter name and diagnostic reference; all callsites and predicates
remain byte-identical.

RecordedSession generated every original request in order and required exact
byte equality before returning the captured response. Physical Tensor/gradient
words, Saved8B float64 values, Versions, metadata, identity epochs and full RNG
states were compared using original predicates. Every exported full owner was
decoded using the fixed84Q observer. Original76 recorded process EOFs were
verified; they are not new process executions.

Rollback is explicitly bounded. Only exported adjacent frame f-1/f owners
support new byte-for-byte before/after comparisons. Other original full-owner
rollback checks remain source-bound executed assertions, with their actual
after-owner and error response preserved. No intermediate memory or general
ViewInfo transition proof is invented. The original481580 assertion count is
separate from the pure comparison total in summary.json.

The original12561956-byte native raw archive is an external immutable
dependency listed in external-native-package.json. Its manifests and custody
are inside this packet. It is not duplicated here or altered. With that packet
available, the optional verifier argument rechecks all3200 original native
members as bytes only.

Verification (no admission/native/Torch/compiler is run):

    python3 -I -S -B verify_evidence.py --package PACKAGE_DIR \\
      --expected-manifest-sha256 EXPECTED_PACKAGE_MANIFEST_SHA256

Optional complete original native packet verification:

    python3 -I -S -B verify_evidence.py --package PACKAGE_DIR \\
      --expected-manifest-sha256 EXPECTED_PACKAGE_MANIFEST_SHA256 \\
      --native-package ORIGINAL_NATIVE_PACKET_DIR

The expected manifest SHA is supplied from the external handoff receipt. The
verifier checks every outer file, every archived size/SHA/mode, exactly one XZ
stream, all TAR members and zero end padding. It never extracts paths or
executes archived code. file-manifest.json maps archive-relative names to
original source paths and POSIX modes. All new outer copies are0644; original
modes remain in the archive. verification.json and outer.json are post-manifest
verification/transport receipts, not members of the signed-by-hash payload set.

This is bounded observed compatibility. Full PyTorch remains HOLD:
0/2590 schemas,688 derivative inventory entries and17 system gates.
"""
emit("README.md",readme.encode())
with tarfile.open(O/"complete.tar.xz","w:xz",preset=6) as tf:
    for row in rows:
        p=selected[row["path"]]
        ti=tarfile.TarInfo(row["path"]);ti.size=row["bytes"];ti.mode=row["mode"];ti.mtime=0
        with p.open("rb") as f:tf.addfile(ti,f)
    p=O/"file-manifest.json";ti=tarfile.TarInfo("file-manifest.json")
    ti.size=p.stat().st_size;ti.mode=0o644;ti.mtime=0
    with p.open("rb") as f:tf.addfile(ti,f)
(O/"complete.tar.xz").chmod(0o644)
for row in rows:
    p=selected[row["path"]]
    assert p.stat().st_size==row["bytes"] and stat.S_IMODE(p.stat().st_mode)==row["mode"]
    assert sha(p.read_bytes())==row["sha256"],str(p)
payload=[]
for p in sorted(O.iterdir()):
    if p.is_file():
        payload.append({"path":p.name,"bytes":p.stat().st_size,"sha256":sha(p.read_bytes()),
                        "mode":stat.S_IMODE(p.stat().st_mode)})
assert len(payload)==8 and all(x["mode"]==0o644 for x in payload)
package={"schema":"heptatorch.scalar07b.pure-raw-admission-handoff.v1",
"payload":payload,"payload_count":len(payload),"payload_bytes":sum(x["bytes"] for x in payload),
"status":"PASS_PURE_RECORDED_EVIDENCE","no_new_native_Torch_compiler_oracle":True,
"original_files_unchanged":True,"full_PyTorch_status":"HOLD","closed_schemas":0}
emit("package-manifest.json",package)
mpin=sha((O/"package-manifest.json").read_bytes())
verifier=runpy.run_path(str(O/"verify_evidence.py"))
verified=verifier["verify"](O,mpin,native)
emit("verification.json",verified)
outer={"schema":"heptatorch.scalar07b.pure-raw-admission-outer-receipt.v1",
"output":str(O),"files":[],"original_native_dependency":dependency,
"pure_76_PASS":True,"first_pure_host_FAIL_preserved":True,"no_new_native_Torch_compiler_oracle":True}
for p in sorted(O.iterdir()):
    if p.is_file():
        outer["files"].append({"path":p.name,"bytes":p.stat().st_size,"sha256":sha(p.read_bytes()),"mode":stat.S_IMODE(p.stat().st_mode)})
emit("outer.json",outer)
print(json.dumps({"status":"SEALED_AND_INDEPENDENT_BYTE_VERIFIER_PASS",
"output":str(O),"package_manifest_sha256":mpin,
"outer_sha256":sha((O/"outer.json").read_bytes()),"verification_sha256":sha((O/"verification.json").read_bytes()),
"archive_sha256":sha((O/"complete.tar.xz").read_bytes()),"archive_bytes":(O/"complete.tar.xz").stat().st_size,
"archive_members":len(rows)+1,"payload_bytes":member_manifest["payload_bytes"],
"totals":summary["totals"],"suites":cases_by_suite,"whole_inputs":summary["whole_inputs"]},indent=2))
