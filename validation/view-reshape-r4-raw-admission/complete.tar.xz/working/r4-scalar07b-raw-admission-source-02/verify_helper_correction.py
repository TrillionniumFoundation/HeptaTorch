#!/usr/bin/env python3
"""Pure exact-inverse and helper-only smoke; does not import either admission module."""
import ast, difflib, hashlib, json
from pathlib import Path
ROOT=Path("/home/qian-qi/heptatorch-continuation-20261116/runs")
HERE=ROOT/"r4-scalar07b-raw-admission-source-02"
SPECS=[
(ROOT/"r4-scalar07b-raw-admission-source-01/admit_scalar07b_raw.py","1e58841782579ca14a14e7106087444e93e16fcb9709fe763525c8018deeb653"),
(HERE/"admit_scalar07b_raw.py","20b23badd9393a8f8ed8bdc23dc7bfbcc991ebabe007257297fd5e9b40ee3529"),
(ROOT/"r4-scalar07b-raw-admission-source-01/configuration.json","c244571fbd7ca1503dc0e6643da05dc321c7fb4e52de5d55498503eea01b9864"),
(ROOT/"r4-scalar07b-raw-admission-01/report.json","c176ba43986598be6821fe5b878a8a3c7008fb190560e5ceb364247f9df49968")]
before=[]
raws=[]
for p,h in SPECS:
    b=p.read_bytes()
    assert hashlib.sha256(b).hexdigest()==h
    raws.append(b)
    before.append({"path":str(p),"bytes":len(b),"sha256":h,"mode":p.stat().st_mode & 0o777})
old,new=raws[0].decode(),raws[1].decode()
a='def need(condition, label, **facts):\n    if not condition:\n        raise AssertionError({"raw_admission_rule": label, **facts})'
b='def need(condition, assertion_label, **facts):\n    if not condition:\n        raise AssertionError({"raw_admission_rule": assertion_label, **facts})'
assert old.count(a)==1 and new.count(b)==1
assert old.replace(a,b)==new and new.replace(b,a)==old
ta,tb=ast.parse(old),ast.parse(new)
na={n.name:n for n in ta.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
nb={n.name:n for n in tb.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert na.keys()==nb.keys()
same=[]
for name in na:
    if name=="need":
        continue
    assert ast.dump(na[name],include_attributes=False)==ast.dump(nb[name],include_attributes=False),name
    same.append(name)
def helper(node):
    ns={}
    exec(compile(ast.Module(body=[node],type_ignores=[]),"<isolated-need-helper>","exec"),ns)
    return ns["need"]
old_need,new_need=helper(na["need"]),helper(nb["need"])
try:
    old_need(True,"snapshot-owner-present",label="real-snapshot-label")
except TypeError as e:
    original_error=str(e)
else:
    raise AssertionError("Original collision was not reproduced")
assert new_need(True,"snapshot-owner-present",label="real-snapshot-label") is None
try:
    new_need(False,"snapshot-owner-present",label="real-snapshot-label",frame=1)
except AssertionError as e:
    assert e.args==({"raw_admission_rule":"snapshot-owner-present","label":"real-snapshot-label","frame":1},)
else:
    raise AssertionError("The rejection predicate was weakened")
assert new_need(True,"plain",frame=1) is None
for fn in (old_need,new_need):
    try:
        fn(False,"plain",frame=1)
    except AssertionError as e:
        assert e.args==({"raw_admission_rule":"plain","frame":1},)
    else:
        raise AssertionError("Plain rejection must remain identical")
assert json.loads(raws[3])["status"]=="FAIL_PURE_ADMISSION"
assert json.loads(raws[3])["all_inputs_unchanged"] is True
for row in before:
    p=Path(row["path"])
    assert hashlib.sha256(p.read_bytes()).hexdigest()==row["sha256"]
    assert p.stat().st_mode & 0o777 == row["mode"]
result={"schema":"heptatorch.scalar07b.raw-admission-helper-only-correction.v2",
"status":"PASS_PURE_HELPER_SMOKE_NOT_CASE_ADMISSION","inputs":before,
"forward_whole_bytes_exact":True,"inverse_whole_bytes_exact":True,
"only_changed_top_definition":"need","unchanged_top_definitions":same,
"change":"Only positional assertion label formal name and its diagnostic use are renamed; all call sites, conditions, observations and comparisons remain byte-identical.",
"old_helper_collision_reproduced":original_error,
"new_label_metadata_true_and_false_paths_checked":True,
"plain_true_and_false_paths_unchanged":True,
"new_case_admissions":0,"new_native_executions":0,"new_Torch_executions":0,"new_compiler_executions":0,
"whole_reference_configuration_unchanged":True,
"forward":{"before":a,"after":b},"inverse":{"before":b,"after":a},
"first_full_pure_FAIL_preserved":before[3],
"all_inputs_unchanged":True}
for name,value in [("helper-inverse-and-smoke.json",json.dumps(result,indent=2)+"\n"),
("source01-to-source02.diff","".join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile="source01/admit_scalar07b_raw.py",tofile="source02/admit_scalar07b_raw.py")))]:
    with (HERE/name).open("xb") as f:f.write(value.encode())
print(json.dumps({"status":result["status"],"unchanged_top_definitions":len(same),"new_case_admissions":0,"native":0,"Torch":0,"compiler":0}))
