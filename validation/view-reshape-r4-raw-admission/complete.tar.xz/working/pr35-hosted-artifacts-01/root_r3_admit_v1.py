"""Read-only admission of hosted R3 artifacts; no native or Torch execution."""
from pathlib import Path, PurePosixPath
import argparse,copy,gzip,hashlib,importlib.util,json,lzma,re,stat,struct,sys,traceback,types,zipfile
SHA=lambda b:hashlib.sha256(b).hexdigest()
BASE=Path('/home/qian-qi/heptatorch-continuation-20261116/runs')
REPO=BASE/'view-reshape-r4-integration-01/repo'
ROOT=BASE/'pr35-hosted-artifacts-01'
EXTRACT=ROOT/'native-artifact-extraction-01'
HEAD='11b6d19044b49b517429bf66d4784d007ac006b5'
TREE='9033563fc6abb8063a4477cc99683dda400c5403'
MERGE='2afc42866a678d8ec5f4d0df0cc551e7082dca08'
SOURCE='3c2c0a125bcac6d47075bf58fc3f78c0e7b9a0b1370757981b99dcd3793b21c6'
IMAGE='7841b19051960b6fa13cb98841dbb8e4d6ead97f03e2ad65af415e1a35b03221'
BOUND={}
def read(p,pin=None):
 p=Path(p);assert p.is_file() and not p.is_symlink(),str(p)
 b=p.read_bytes();h=SHA(b)
 if pin is not None:assert h==pin,(str(p),h,pin)
 row={'bytes':len(b),'sha256':h,'mode':stat.S_IMODE(p.stat().st_mode)}
 if str(p) in BOUND:assert BOUND[str(p)]==row
 BOUND[str(p)]=row
 return b
def data(p,pin=None):return json.loads(read(p,pin))
def write(p,obj):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write((json.dumps(obj,indent=2,allow_nan=False)+'\n').encode())
def load(p,name,pin):
 read(p,pin);spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def single_xz(p,expected):
 raw=read(p);assert SHA(raw)==expected.get('compressed_sha256',expected.get('archive_sha256'))
 d=lzma.LZMADecompressor(format=lzma.FORMAT_XZ);b=d.decompress(raw)
 assert d.eof and not d.unused_data and len(b)==expected['bytes'] and SHA(b)==expected['sha256'],str(p)
 if 'compressed_bytes' in expected:assert len(raw)==expected['compressed_bytes']
 return b
def safe_path(base,path):
 q=PurePosixPath(path);assert not q.is_absolute() and '..' not in q.parts and path
 p=base/path;assert p.is_relative_to(base)
 return p
def json_normal(x):return json.loads(json.dumps(x))
def same(a,b,label):
 assert json_normal(a)==json_normal(b),(label,a,b)
def bind_copies(d,report):
 custody=data(d/'input-custody.json');assert set(custody)==set(report['inputs_sha256'])
 result={}
 for original,record in custody.items():
  p=safe_path(d,record['copy']);raw=read(p,record['sha256']);assert len(raw)==record['bytes']
  assert report['inputs_sha256'][original]==record['sha256']
  rel=original.split('/HeptaTorch/HeptaTorch/',1)[1]
  if not rel.startswith('build/'):assert read(REPO/rel)==raw,(original,'repo source mismatch')
  result[rel]=p
 return result
def unpack_frames(raw,magic):
 frames=[];at=0
 while at<len(raw):
  assert at+16<=len(raw)
  tag,size=struct.unpack_from('<8sQ',raw,at);at+=16
  assert tag==magic and 32<=size<=1<<20 and at+size<=len(raw)
  frames.append(raw[at:at+size]);at+=size
 assert at==len(raw)
 return frames
def wire_evidence(d,protocol,image=IMAGE):
 req=unpack_frames(read(d/'requests.frames.bin'),b'HTOWNR01')
 rsp=unpack_frames(read(d/'responses.frames.bin'),b'HTOWNS01')
 t=data(d/'transport.json');assert len(req)==len(rsp)==t['frames']==len(t['rows'])
 assert t['exit_code']==0 and t['responses_before_stdin_eof'] is True and t['executable_sha256']==image
 decoded=[]
 for i,(q,s,r) in enumerate(zip(req,rsp,t['rows']),1):
  assert r=={'frame':i,'pid':t['pid'],'response_bytes':len(s),'stdin_open':True}
  magic,n,size,reserved=struct.unpack_from('<8s3Q',q);assert magic==b'HTORCH03' and size==len(q) and reserved==0
  assert 32+64*n<=len(q)
  commands=[struct.unpack_from('<8Q',q,32+64*j) for j in range(n)]
  status,records=protocol.parse(s)
  if status:assert records==[]
  else:
   assert len(records)<=len(commands)
   assert [v['opcode'] for v in records]==[v[0] for v in commands[:len(records)]]
   if len(records)<len(commands):assert records and records[-1]['opcode']==58 and records[-1]['value']!=0
  decoded.append((status,records,commands))
 return {'request':req,'response':rsp,'decoded':decoded,'transport':t}
ARTIFACTS={
14289781746:(6510370,'8de9c47f346eb8cd00fa91029d7715a868e76b1f5874b94625fa2faa51e6039a'),
14289992100:(6510636,'c4bc90840a4fa0c3fe05456dd0dcf0bc3f9c8bba250fced030cbe7922116b30e'),
14289318347:(11249805,'35183142ec8b5b1bd3c9012a3f986fdaa9384f98a7ca3ed5f5c692e7913f8bdc'),
14288619807:(11249793,'c8f59b01822a6b0f9529ae562738fea8ae91de9dba29cb99138d8b6165dfc435'),
14290366118:(14004782,'3a98dfda25653b674148ae2fa382700853e7f79429e8b0b57e74ae0ab46caf65'),
14289576979:(14004828,'10bec52928f0cea4068a3d9ae9bcb790f255be0b22d287a4b010929515a57439')}
def admit_zip(id):
 size,pin=ARTIFACTS[id];p=ROOT/('artifact-%d.zip'%id);raw=read(p,pin);assert len(raw)==size
 names=set();expanded=0
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  for i in z.infolist():
   assert not stat.S_ISLNK(i.external_attr>>16)
   if i.is_dir():continue
   assert i.filename not in names;names.add(i.filename)
   b=z.read(i);q=safe_path(EXTRACT/str(id),i.filename)
   assert read(q)==b and len(b)==i.file_size
   mode=stat.S_IMODE(i.external_attr>>16)
   if mode:assert stat.S_IMODE(q.stat().st_mode)==mode
   expanded+=len(b)
 assert {str(p.relative_to(EXTRACT/str(id))) for p in (EXTRACT/str(id)).rglob('*') if p.is_file()}==names
 return {'artifact_id':id,'archive_sha256':pin,'archive_bytes':size,'members':len(names),'expanded_bytes':expanded,'all_original_bytes_and_zip_crc_verified':True}
def admit_root(id,run,pr):
 d=EXTRACT/str(id);m=data(d/'ci-report-manifest.json')
 workflow=read(REPO/'.github/workflows/native.yml','b26279e67b7183d0ec6fa3f47c347f4bd8f28d8f24c8e453bf921d8a3d3c3a21')
 read(REPO/'tools/collect_ci_reports.py','22b7e0113197b74f20177fbacd160618ad75737b7d524e63027edc4c5aeee75a')
 required=[Path(p.decode()).name for p in sorted(set(re.findall(rb'tools/emit_ci_report\.py (build/[A-Za-z0-9_.-]+\.json)(?:\s|$)',workflow)))]
 assert len(required)==60 and m['required_envelope_reports']==required and m['missing_envelope_reports']==[]
 assert m['status']=='COMPLETE' and m['job_status_before_export']=='success'
 assert m['checkout_commit']==(MERGE if pr else HEAD) and m['checkout_tree']==TREE
 assert m['tracked_worktree_dirty'] is False and m['original_report_bytes_reserialized'] is False
 assert m['workflow_sha256']==SHA(workflow) and m['collector_sha256']=='22b7e0113197b74f20177fbacd160618ad75737b7d524e63027edc4c5aeee75a'
 g=m['github'];assert g['GITHUB_RUN_ID']==str(run) and g['GITHUB_RUN_ATTEMPT']=='1' and g['GITHUB_JOB']=='native'
 assert g['GITHUB_REPOSITORY']=='TrillionniumFoundation/HeptaTorch' and g['HEPTATORCH_SOURCE_HEAD_SHA']==HEAD
 assert g['GITHUB_SHA']==m['checkout_commit'] and g['GITHUB_EVENT_NAME']==('pull_request' if pr else 'push')
 rows=m['reports'];assert len(rows)==101 and len({r['path'] for r in rows})==101
 statuses={}
 for r in rows:
  b=read(safe_path(d,r['path']),r['sha256']);assert len(b)==r['bytes'];v=json.loads(b)
  statuses[r['path']]=v.get('status',v.get('verdict','NO_TOP_LEVEL_STATUS'))
 assert set(required)<={r['path'] for r in rows}
 assert {p.name for p in d.glob('*.json')}=={r['path'] for r in rows}|{'ci-report-manifest.json'}
 return {'run_id':run,'artifact_id':id,'manifest_sha256':SHA(read(d/'ci-report-manifest.json')),'reports':101,'required':60,'source_head':HEAD,'checkout_commit':m['checkout_commit'],'checkout_tree':TREE,'original_statuses':statuses}


def restore_value(v,wire):
 if isinstance(v,dict) and set(v)=={'wire_payload'}:
  d=v['wire_payload'];b=bytes.fromhex(d['hex']);assert len(b)==d['bytes'];return wire.Payload(b,d['alignment'])
 if isinstance(v,dict) and set(v)=={'bytes','hex'}:
  b=bytes.fromhex(v['hex']);assert len(b)==v['bytes'];return b
 if isinstance(v,list):return [restore_value(x,wire) for x in v]
 if isinstance(v,dict):return {k:restore_value(x,wire) for k,x in v.items()}
 return v
def captured_case(d,ref,row,aggregate,support,wire,observer,owner_observer):
 report=data(d/'report.json');index=row['index']
 for k,v in aggregate.items():same(report[k],v,'case aggregate '+k)
 assert report['status']=='PASS' and report['error'] is None and report['mismatches']==[] and report['exit_code']==0
 assert len(report['operations'])==len(row['events'])==report['reference_event_count']
 evidence=wire_evidence(d/'raw',wire);assert evidence['transport']['frames']==report['frames']
 owners={}
 for digest,b in report['owner_blobs'].items():
  assert b['sha256']==digest
  raw=single_xz(safe_path(d,b['path']),b)
  owner_observer.verify_snapshot(owner_observer.decode_owner(raw))
  owners[digest]=raw
 for o in report['owner_records']:
  assert o['sha256'] in owners and o['length']==len(owners[o['sha256']])
  assert 0<o['frame']<=report['frames'] and o['pointer']>0
 assert set(owners)=={o['sha256'] for o in report['owner_records']}
 c=object.__new__(support.Case)
 c.tmap={};c.treverse={};c.smap={};c.sreverse={};c.failures=[];c.checks=0;c.words=0;c.current_path='pure-captured-observation'
 snapshots=iter(report['snapshots']);snapshot_count=0;raw_tensor_checks=0;command_bindings=0
 def check(label,a,e):c.check(label,a,e)
 def node(e,a,label):c.compare_node(e,a,label)
 def tensor(e,a,label):c.tensor(e,a,label)
 def physical_from_owner(a,m,label):
  nonlocal raw_tensor_checks
  if a is None:return
  current=m.tensor(a['native_node'])
  assert current['native_incarnation']==a['native_incarnation'],label
  for k in ('dtype','element_size','shape','strides','numel','storage_bytes','storage_offset_elements','version','logical_bytes_hex','storage_bytes_hex','native_storage_id','native_version_id','native_base_incarnation'):
   same(current[k],a[k],label+'/'+k)
  raw_tensor_checks+=1
 def snapshot(e,label):
  nonlocal snapshot_count
  a=next(snapshots);assert a['label']==label;snapshot_count+=1;c.current_path=label
  check('getter_order',a['tensor_getter_order'],e['tensor_getter_order'])
  assert list(a['tensors'])==e['tensor_getter_order']
  for name in e['tensor_getter_order']:
   et=e['tensors'][name];at=a['tensors'][name]
   tensor(et['before_grad_fn_getter'],at['before_grad_fn_getter'],name+'/before')
   check(name+'/grad_getter',et['grad_fn_getter']['accepted'],True)
   check(name+'/grad_getter_warnings',et['grad_fn_getter']['warnings'],[])
   node(et['grad_fn_getter']['node'],at['grad_fn'],name+'/grad_fn')
   check(name+'/requires',at['requires_after_getter'],et['requires_grad_after_grad_fn_getter'])
   check(name+'/leaf',at['is_leaf_after_getter'],et['is_leaf_after_grad_fn_getter']['value'])
   check(name+'/retains',at['retains_grad'],et['retains_grad']['value'])
   tensor(et['gradient']['tensor'],at['gradient'],name+'/gradient')
   check(name+'/gradient_getter_accepted',et['gradient']['accepted'],True)
   warnings=et['gradient']['warnings']
   check(name+'/warning_predicate',bool(at['grad_fn']) and not at['retains_grad'],bool(warnings))
   if warnings:check(name+'/warning_count',len(warnings),1);check(name+'/warning_type',warnings[0]['type'],'UserWarning')
  check('relations',a['relations'],e['relations'])
  for name in e['tensor_getter_order']:
   check(name+'/edge_getter',e['edge_getters'][name]['accepted'],True)
   check(name+'/edge_warnings',e['edge_getters'][name]['warnings'],[])
   expected_saved=e['saved_getters_after_tensor_getters'][name];observed_saved=a['saved'][name]
   check(name+'/saved_names',list(observed_saved),list(expected_saved))
   for key,ev in expected_saved.items():
    av=observed_saved[key];wanted=support.expected_status(ev)
    check(name+'/'+key+'/warnings',ev['warnings'],[])
    check(name+'/'+key+'/accepted',av['accepted'],ev['accepted'])
    if wanted:check(name+'/'+key+'/status',av['normalized_wire_status'],wanted)
    elif isinstance(ev['value'],dict) and 'tensor' in ev['value']:
     assert isinstance(av['value'],dict) and 'tensor' in av['value']
     tensor(ev['value']['tensor'],av['value']['tensor'],name+'/'+key)
    else:check(name+'/'+key+'/value',av['value'],ev['value'])
   ae=a['edges'][name];ee=e['edges_after_all_tensor_getters'][name]
   check(name+'/edge_count',len(ae),len(ee))
   for i,(av,ev) in enumerate(zip(ae,ee)):
    check(name+'/edge_output',av['output_nr'],ev['output_nr'])
    check(name+'/edge_identity',av['matches_live_current_grad_fn'],ev['matches_live_current_grad_fn'])
    node(ev['node'],av['node'],name+'/edge/'+str(i))
  check('expired',a['expired'],e['expired']);check('full_rng_digest',a['rng_sha256'],e['state'])
  assert a['owner_sha256'] in owners
  matching=[o for o in report['owner_records'] if o['label']==label]
  assert len(matching)==1 and matching[0]['frame']==a['frame'] and matching[0]['sha256']==a['owner_sha256']
  f=a['frame'];assert evidence['decoded'][f-1][1]==[{'opcode':53,'value':1,'payload':b''}]
  assert evidence['decoded'][f-2][1][0]['opcode']==63
  state=evidence['decoded'][f-2][1][0]['payload'];assert len(state)==5056 and SHA(state)==e['state'] and state==bytes.fromhex(ref['states'][e['state']]['hex'])
  m=observer.Memory(owners[a['owner_sha256']])
  for name,at in a['tensors'].items():
   physical_from_owner(at['before_grad_fn_getter'],m,label+'/'+name+'/raw')
   physical_from_owner(at['gradient'],m,label+'/'+name+'/raw-gradient')
  return a
 final_done=False
 for i,(ev,op) in enumerate(zip(row['events'],report['operations'])):
  if ev['label'].startswith('final_drop_') and not final_done:
   snapshot(row['before_final_drops'],'before_final_drops');final_done=True
  before=snapshot(ev['before'],'event%02d/%s/before'%(i,ev['label']))
  assert op['label']==ev['label'] and op['reference_event']==i
  wanted=support.expected_status(ev)
  check('operation_status',op['normalized_actual_status'],wanted);check('reference_status',op['normalized_reference_status'],wanted)
  if 'returned_tensor' in op:tensor(ev['returned']['tensor'],op['returned_tensor'],'returned_Tensor')
  after=snapshot(ev['after'],'event%02d/%s/after'%(i,ev['label']))
  position=before['frame']
  matched=[]
  for command in op['commands']:
   body=wire.packet([restore_value(command,wire)])
   found=next((j for j in range(position,after['frame']) if evidence['request'][j]==body),None)
   assert found is not None,('operation command missing from original wire',index,ev['label'],command)
   matched.append(found);position=found+1;command_bindings+=1
  if op['record'] is not None:
   wanted_record=restore_value(op['record'],wire)
   wanted_record={k:v for k,v in wanted_record.items() if k!='partial_fields_recorded_not_Torch_oracle_counters'}
   assert any(wanted_record in evidence['decoded'][j][1] for j in matched),(index,ev['label'],'record not in bound wire')
 if not final_done:snapshot(row['before_final_drops'],'before_final_drops')
 try:next(snapshots);raise AssertionError('unconsumed captured snapshot')
 except StopIteration:pass
 assert c.failures==[],c.failures[:8]
 assert snapshot_count==len(row['events'])*2+1
 final=[o for o in report['owner_records'] if o['label']=='final_before_observer_release'];assert len(final)==1
 f=final[0]['frame'];assert evidence['decoded'][f-1][1]==[{'opcode':53,'value':1,'payload':b''}]
 end_state=evidence['decoded'][f-2][1][0]['payload'];assert end_state==bytes.fromhex(ref['states'][row['state_after']]['hex'])
 expected_rollback=sum(o['length'] for o in report['owner_records'] if o['label'].endswith('/frame_refusal'))
 assert expected_rollback==report['rollback_bytes']
 return {'index':index,'name':row['name'],'captured_observation_checks_recomputed':c.checks,'captured_exact_words_compared':c.words,'raw_tensor_physical_checks':raw_tensor_checks,'snapshots':snapshot_count,'owner_blobs_redecoded_and_invariants_replayed':len(owners),'owner_records':len(report['owner_records']),'operation_commands_bound_to_raw_frames':command_bindings,'raw_frames':report['frames'],'original_assertions':report['assertions'],'complete_wire_and_recorded_EOF_verified':True,'original_report_sha256':SHA(read(d/'report.json'))}
def admit_cases(id,suite,n,root_id,support,wire,observer,owner_observer):
 d=EXTRACT/str(id)/suite;report=data(d/'report.json')
 assert report['status']=='PASS' and report['cases']==report['passed_cases']==n and report['failed_cases']==0
 assert report['source_sha256']==SOURCE and report['native_sha256']==IMAGE
 assert report['functions']==627 and report['native_units']==13 and report['descriptor_bytes']==672
 assert report['all_inputs_unchanged'] and report['all_sessions_eof_exit_zero']
 assert report['full_pytorch_rewrite_complete'] is False and report['closed_schema_count']==0
 assert report['torch_executed_here'] is False and report['native_executed'] is True
 copies=bind_copies(d,report)
 refpath=next(p for p in copies.values() if SHA(read(p))==report['reference_sha256'])
 probepath=next(p for p in copies.values() if SHA(read(p))==report['probe_sha256'])
 if n==14:ref=support.admit_reference(read(refpath),read(probepath))
 else:
  reader=load(REPO/'tests/differentiable_view_input4_review/replay_input_boundaries4.py','input4_admission_reader','5b8809eb9e405bf89a3586741d64210483fe3fbc5bc323e2cc16cb712ce4de66')
  ref=reader.admit_reference(read(refpath),read(probepath),report['reference_sha256'],support)
 buildpath=copies['build/differentiable-view-recovered/build.json'];build=data(buildpath)
 assert build['source_sha256']==SOURCE and build['native_sha256']==IMAGE and build['status']=='PASS'
 assert build['functions']==627 and len(build['units'])==13 and build['link_exit']==0
 for u in build['units']:
  assert u['compiler_exit']==0
  for suffix,key in (('.hepta','source_sha256'),('.o','object_sha256')):
   read(copies['build/differentiable-view-recovered/'+u['name']+suffix],u[key])
 assert len(support.FUNCTIONS.findall(read(copies['build/differentiable-view-recovered/runtime.hepta'])))==627
 assert read(EXTRACT/str(root_id)/(suite+'.json'))==read(d/'report.json')
 rows=[]
 for row,agg in zip(ref['rows'],report['rows']):
  rows.append(captured_case(d/('case-%02d'%row['index']),ref,row,agg,support,wire,observer,owner_observer))
 assert len(rows)==n
 for k in ('assertions','exact_words','full_rng_bytes','rollback_bytes','frames'):
  assert sum(r[k] for r in report['rows'])==report[k]
 return {'artifact_id':id,'suite':suite,'source_sha256':SOURCE,'native_sha256':IMAGE,'report_sha256':SHA(read(d/'report.json')),'cases':rows,'input_files':len(copies),'original_full_assertions':report['assertions'],'scope':'Recomputed every exported reference comparison plus raw wire, full saved owner invariants and physical Tensor bytes. Original intermediate observer reads not exported are not invented; no new native/Torch run.'}


def find_input(original,record,artifact_id):
 rel=original.split('/HeptaTorch/HeptaTorch/',1)[1]
 candidates=[REPO/rel] if not rel.startswith('build/') else [EXTRACT/str(artifact_id)/rel[6:]]
 candidates += [Path(p) for p,v in BOUND.items() if v['sha256']==record['sha256'] and v['bytes']==record['bytes']]
 for p in candidates:
  if p.is_file() and SHA(p.read_bytes())==record['sha256']:
   b=read(p,record['sha256']);assert len(b)==record['bytes'];return p
 raise AssertionError(('missing bound input bytes',original,record))
def admit_resources(id,root_id,out,wire,observer):
 d=EXTRACT/str(id)/'differentiable-view-preserve-resources';report=data(d/'report.json')
 assert read(EXTRACT/str(root_id)/'differentiable-view-preserve-resources.json')==read(d/'report.json')
 assert report['status']=='PASS' and report['case_count']==report['passed']==3
 assert report['source_sha256']==SOURCE and report['native_sha256']==IMAGE and report['all_inputs_unchanged'] is True
 assert report['whole_pytorch_gate']=='HOLD' and report['closed_schemas']==0 and report['Torch_executed_here'] is False
 bound={p:find_input(p,v,id) for p,v in report['inputs'].items()}
 source_path=next(v for p,v in bound.items() if p.endswith('/runtime.hepta'))
 refpath=next(v for p,v in bound.items() if report['inputs'][p]['sha256']==report['reference_sha256'])
 ref=data(refpath);source=read(source_path,SOURCE)
 functions={m.group(1).decode():m.group(0) for m in re.finditer(rb'^fn ([A-Za-z_][A-Za-z0-9_]*)\(.*?^end\n',source,re.M|re.S)}
 here=REPO/'tests/differentiable_view_preserve_resource_review'
 sys.modules['owner_view05']=observer
 state=load(here/'owner_state.py','owner_state','e6459b9545b416a95a42b894094754d617c9b6abf5c20c4e4693fc2351674fb1')
 support=load(here/'support.py','support','7d616b06aea3e8acea83213f30c2bb68bcc3150a1ae7a1e0702579be3607e178')
 transport=load(here/'case_transport.py','case_transport','7f17be13ccbf3565e7837ffe4841e2cff876f116ae93e1e13cb560a815fb6b0b')
 driver=load(here/'test_preserve_resources.py','r3_resource_original_recipes','edb879dff167e41fb72b37f6d14d2ad7cfd7f48eef87fade1c96146cee7308bc')
 original_mark=transport.Case.mark
 original_resource=driver.resource
 recipe_names=['tail_release_reuse','preserve_capacity_oom_recovery','tail_then_saved_error_prefix']
 assert [r['name'] for r in report['cases']]==recipe_names
 out.mkdir(parents=True,exist_ok=False);results=[]
 for original in report['cases']:
  name=original['name'];actual=d/name
  assert data(actual/'report.json')==original and original['status']=='PASS'
  evidence=wire_evidence(actual/'transport',wire)
  assert evidence['transport']['frames']==original['frames_before_EOF'] and original['EOF_exit_code']==0
  captured=[]
  for entry in original['snapshots']:
   raw=single_xz(safe_path(actual,entry['owner']['path']),entry['owner'])
   compressed=read(safe_path(actual,entry['snapshot_file']))
   saved=gzip.decompress(compressed);assert SHA(saved)==entry['snapshot_sha256']
   snap=json.loads(saved);assert observer.canonical(snap)==saved
   decoded=observer.decode_owner(raw,snap['pointer']);assert observer.canonical(decoded)==saved
   verified=observer.verify_snapshot(decoded);same(verified,entry['result'],'owner predicates')
   state.State(raw).partition()
   captured.append({'entry':entry,'raw':raw,'snapshot':snap})
  for event in original['events']:
   before=single_xz(safe_path(actual,event['before']['path']),event['before'])
   after=single_xz(safe_path(actual,event['after']['path']),event['after'])
   assert before==after and event['status']==event['expected']
  for control in original['negative_controls']:
   raw=gzip.decompress(read(safe_path(actual,control['file'])));assert SHA(raw)==control['input_sha256']
   try:observer.verify_snapshot(json.loads(raw))
   except AssertionError as e:assert e.args[0]['observer_rule']==control['rule']
   else:raise AssertionError(('negative accepted',control))
  class RecordedSession(wire.Session):
   def __init__(self,executable,**kwargs):
    self.frames=0;self.exit_code=None;self.pid=evidence['transport']['pid'];self.cursor=0;self.current=None
   def exchange(self,body):
    assert self.frames<len(evidence['request'])
    assert body==evidence['request'][self.frames],('recipe request differs',name,self.frames+1)
    assert self.cursor<len(captured)
    self.current=captured[self.cursor]
    result=evidence['response'][self.frames];self.frames+=1;return result
   def owner(self,read_bytes=True):
    assert self.current is not None
    return {'pointer':self.current['snapshot']['pointer'],'length':len(self.current['raw']),'bytes':self.current['raw'],'live':1}
   def finish(self,expected=0,release_probe=True):
    assert self.frames==len(evidence['request']) and self.cursor==len(captured)
    assert expected==evidence['transport']['exit_code']==0
    self.exit_code=0
  def mark(c,label):
   assert c.s.cursor<len(captured)
   item=captured[c.s.cursor];assert item['entry']['label']==label,(name,c.s.cursor,label,item['entry']['label'])
   assert c.s.owner()['bytes']==item['raw']
   snap=original_mark(c,label)
   assert observer.canonical(snap)==observer.canonical(item['snapshot'])
   generated=c.row['snapshots'][-1]
   for k in ('label','result','snapshot_file','snapshot_sha256'):same(generated[k],item['entry'][k],'replayed snapshot '+k)
   for k in ('path','bytes','sha256'):same(generated['owner'][k],item['entry']['owner'][k],'replayed raw owner '+k)
   c.s.cursor+=1
   return snap
  transport.Case.mark=mark
  wire_copy=types.SimpleNamespace(**{k:getattr(wire,k) for k in dir(wire) if not k.startswith('__')})
  wire_copy.Session=RecordedSession
  file_replays=[]
  class RecordedProcFile:
   def __init__(self,paths):self.paths=paths;self.n=0
   def read_bytes(self):
    assert self.n<len(self.paths);p=self.paths[self.n];self.n+=1;b=read(p);file_replays.append(str(p));return b
  def recorded_path(path):
   s=str(path);prefix='/proc/%d/'%evidence['transport']['pid']
   if s.startswith(prefix):
    suffix=s[len(prefix):]
    mapping={'status':['before-limit.status'],'limits':['limited.limits'],'maps':['preserve_growth_OOM.maps-before','preserve_growth_OOM.maps-after']}
    assert suffix in mapping
    return RecordedProcFile([actual/p for p in mapping[suffix]])
   assert not s.startswith('/proc/')
   return Path(path)
  driver.Path=recorded_path;transport.Path=recorded_path
  limit_calls=[]
  class RecordedResource:
   RLIMIT_AS=original_resource.RLIMIT_AS
   RLIM_INFINITY=original_resource.RLIM_INFINITY
   def __init__(self):
    self.current=tuple(original.get('oom_setup',{}).get('original_rlimit',[]))
   def prlimit(self,pid,kind,limits=None):
    assert name=='preserve_capacity_oom_recovery' and pid==evidence['transport']['pid'] and kind==self.RLIMIT_AS
    previous=self.current
    if limits is not None:
     assert tuple(limits) in (tuple(original['oom_setup']['original_rlimit']),(original['oom_setup']['soft_limit'],original['oom_setup']['original_rlimit'][1]))
     self.current=tuple(limits)
    limit_calls.append({'requested':limits,'previous':previous,'result':self.current})
    return previous
  driver.resource=RecordedResource()
  replay_report={'cases':[]}
  c=driver.Case.__new__(driver.Case);c.__init__(name,wire_copy,Path('RECORDED_NOT_EXECUTED'),out,replay_report,original['RLIMIT_AS_bytes'])
  getattr(driver,name)(c,ref,functions);c.row['status']='PASS';c.finish()
  for k,v in original.items():
   if k not in ('snapshots','events','negative_controls'):same(c.row[k],v,'replayed resource '+name+'/'+k)
  assert len(c.row['events'])==len(original['events']) and len(c.row['negative_controls'])==len(original['negative_controls'])
  for a,e in zip(c.row['events'],original['events']):
   for k in ('name','status','expected'):same(a[k],e[k],name+'/refusal/'+k)
   for side in ('before','after'):
    for k in ('path','bytes','sha256'):same(a[side][k],e[side][k],name+'/refusal/'+side+'/'+k)
  if name=='preserve_capacity_oom_recovery':
   assert len(limit_calls)==4 and driver.resource.current==tuple(original['oom_setup']['original_rlimit'])
   assert [Path(p).name for p in file_replays]==['before-limit.status','limited.limits','preserve_growth_OOM.maps-before','preserve_growth_OOM.maps-after']
   assert read(actual/'preserve_growth_OOM.maps-before')==read(actual/'preserve_growth_OOM.maps-after')
  else:assert limit_calls==file_replays==[]
  write(out/(name+'-replay.json'),{'schema':'heptatorch.recorded-resource-pure-replay.v1','status':'PASS','original_report_sha256':SHA(read(actual/'report.json')),'recipe_source_sha256':'edb879dff167e41fb72b37f6d14d2ad7cfd7f48eef87fade1c96146cee7308bc','recomputed_row':c.row,'recorded_proc_files':file_replays,'recorded_limit_calls':limit_calls,'new_native_executions':0,'new_Torch_executions':0,'actual_process_limits_changed':False})
  results.append({'name':name,'original_checks_recomputed':c.row['checks'],'all_requests_matched':c.s.frames,'owner_snapshots_redecoded_and_predicates_recomputed':c.s.cursor,'full_rng_bytes_compared':c.row['full_rng_compared_bytes'],'rollback_bytes_compared':c.row['rollback_bytes'],'original_EOF_status':0})
 transport.Case.mark=original_mark;driver.resource=original_resource;driver.Path=Path;transport.Path=Path
 assert sum(r['original_checks_recomputed'] for r in results)==report['checks']==243
 assert sum(r['all_requests_matched'] for r in results)==report['frames_before_EOF']==113
 return {'artifact_id':id,'source_sha256':SOURCE,'native_sha256':IMAGE,'input_files':len(bound),'original_report_sha256':SHA(read(d/'report.json')),'recipes_replayed':results,'scope':'All original finite recipe and ownership predicates rerun against original wire/owner evidence; recorded proc snapshots and limit calls are replayed data, not a new OOM experiment.'}


def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
 result={'schema':'heptatorch.root-pr35-hosted-r3-artifact-admission.v1','status':'RUNNING','source_head':HEAD,'source_tree':TREE,'new_native_executions':0,'new_Torch_executions':0,'new_compiler_executions':0,'full_pytorch_rewrite_complete':False,'closed_schema_count':0,'whole_pytorch_gate':'HOLD','artifacts':[],'root_manifests':[],'finite_cases':[],'resource_replays':[]}
 phase='start'
 try:
  read(Path(__file__))
  for id in ARTIFACTS:
   phase='archive-'+str(id);item=admit_zip(id);result['artifacts'].append(item);print(json.dumps({'phase':phase,'members':item['members'],'status':'PASS_BYTES'}),flush=True)
  for id,run,pr in [(14289781746,43990265485,True),(14289992100,43990224111,False)]:
   phase='root-manifest-'+str(id);item=admit_root(id,run,pr);result['root_manifests'].append(item);print(json.dumps({'phase':phase,'reports':101,'status':'PASS'}),flush=True)
  p=REPO/'tests/differentiable_view_native_review'
  read(p/'owner_client.py','dee3e4cb25ee1e5e06513e2f33478fbe274d9510ce2aaab9525815c72312946b')
  wire=load(p/'protocol.py','r3_recorded_wire','7a30d7bca140e3a4cc9d63a3e6930b92d2ffd60ad4503895419d8a63e67c8bd9')
  support=load(p/'replay_direct_view14.py','r3_original_comparators','52c3b3242a73fb412102c83c5ba47cf8d95a4eb3c01e56f41bfe593066506d05')
  observer=load(REPO/'tests/differentiable_view_input4_review/native_observer_direct03.py','r3_native_readonly_decode','68d0f4657c6cc7062d98cbf033565b16c7b51f3381c6490247e42512c5baf4a2')
  owner_observer=load(REPO/'tests/differentiable_view_preserve_resource_review/owner_view05.py','r3_complete_owner_predicates','4bf58b2fbccdf1e9f670c0cef854e110c72d1a1c03453e55121e10f2048a6d1f')
  for id,suite,n,root_id in [(14289318347,'differentiable-view-native14',14,14289781746),(14290366118,'differentiable-view-native-input4',4,14289781746),(14288619807,'differentiable-view-native14',14,14289992100),(14289576979,'differentiable-view-native-input4',4,14289992100)]:
   phase=str(id)+'/'+suite;item=admit_cases(id,suite,n,root_id,support,wire,observer,owner_observer);result['finite_cases'].append(item);write(out/(str(id)+'-'+suite+'.json'),item);print(json.dumps({'phase':phase,'cases':n,'status':'PASS_CAPTURED_OBSERVATIONS'}),flush=True)
  for id,root_id in [(14290366118,14289781746),(14289576979,14289992100)]:
   phase=str(id)+'/resource-original-recipes';item=admit_resources(id,root_id,out/('resource-replay-'+str(id)),wire,owner_observer);result['resource_replays'].append(item);print(json.dumps({'phase':phase,'status':'PASS_RECORDED_RECIPE_REPLAY'}),flush=True)
  phase='all-original-inputs-rehash'
  for p,v in BOUND.items():
   b=Path(p).read_bytes();assert len(b)==v['bytes'] and SHA(b)==v['sha256'] and stat.S_IMODE(Path(p).stat().st_mode)==v['mode'],p
  result['status']='PASS_FINITE_ARTIFACT_ADMISSION'
  result['all_bound_original_bytes_and_modes_unchanged']=True
  result['bound_files']=BOUND
 except BaseException as e:
  result['status']='FAIL_ADMISSION';result['error']={'phase':phase,'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()};result['bound_files']=BOUND
  write(out/'report.json',result);raise
 write(out/'report.json',result)
 b=(out/'report.json').read_bytes()
 print(json.dumps({'status':result['status'],'report':str(out/'report.json'),'bytes':len(b),'sha256':SHA(b),'artifacts':len(result['artifacts']),'reports':202,'finite_cases':36,'resource_recipes':6,'bound_files':len(BOUND),'new_native_executions':0,'new_Torch_executions':0,'whole_pytorch_gate':'HOLD'}),flush=True)
if __name__=='__main__':main()
