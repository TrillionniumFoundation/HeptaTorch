import ast
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

root = Path(__file__).resolve().parent
old = root / 'source-01'
new = root / 'source-02'
assert not new.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
original = (old / 'test_preserve_resources.py').read_bytes()
assert sha(original) == '84d5b39fe8491eae25551da05e8ec87d8ea66d33dd8f0f9e07fcd223f63503ca'
shutil.copytree(old, new)
edits = [
    ('        count=((free-64*1024)//4)&~3\n',
     '        count=min(262144,((free-64*1024)//4)&~3)\n'),
    ("    p.add_argument('--prepare-only',action='store_true')\n",
     "    p.add_argument('--prepare-only',action='store_true')\n    p.add_argument('--case',choices=('all','tail_release_reuse','preserve_capacity_oom_recovery','tail_then_saved_error_prefix'),default='all')\n"),
    ("        'old_six_recipes_executed':False,'isolated_transition_gate_executed':False,\n",
     "        'old_six_recipes_executed':False,'isolated_transition_gate_executed':False,'requested_case':a.case,\n"),
    ('            for f in (tail_release_reuse,preserve_capacity_oom_recovery,tail_then_saved_error_prefix):\n',
     "            for f in (tail_release_reuse,preserve_capacity_oom_recovery,tail_then_saved_error_prefix):\n                if a.case!='all' and a.case!=f.__name__:continue\n"),
    ("            report['status']='PASS' if len(report['cases'])==3 and all(r['status']=='PASS' for r in report['cases']) else 'FAIL'\n",
     "            report['status']='PASS' if len(report['cases'])==(3 if a.case=='all' else 1) and all(r['status']=='PASS' for r in report['cases']) else 'FAIL'\n"),
]
text=original.decode()
for before,after in edits:
    assert text.count(before)==1
    text=text.replace(before,after)
result=text.encode()
inverse=text
for before,after in reversed(edits):
    assert inverse.count(after)==1
    inverse=inverse.replace(after,before)
assert inverse.encode()==original
ast.parse(result)
old_defs={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(original).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
new_defs={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(result).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
changed=[k for k in old_defs if old_defs[k]!=new_defs[k]]
assert changed==['preserve_capacity_oom_recovery','main']
(new/'test_preserve_resources.py').write_bytes(result)
provenance=new/'source01-provenance';provenance.mkdir()
for name in ('test_preserve_resources.py','source-manifest.json'):
    shutil.copyfile(old/name,provenance/name)
proof={'schema':'heptatorch.r3-preserve-filler-setup-correction.v1','status':'SOURCE_PREPARED_NOT_RUN',
    'original_driver_sha256':sha(original),'successor_driver_sha256':sha(result),
    'whole_file_inverse_sha256':sha(inverse.encode()),'whole_file_inverse_exact':True,
    'changed_top_level_definitions':changed,'edits':[{'before':a,'after':b} for a,b in edits],
    'primary_failure':{'job_id':'1a1e6c9158b-392-3c3b','source_manifest_sha256':'16a82163c844813b5804263e2f24ed07b427e4ef73044ec48a59b3dd7cca2f5f',
        'status':'SETUP_FAILED_BEFORE_TEMPORARY_PRLIMIT_AND_BACKWARD','filler_dimension':332548,'actual_status':3,
        'first_owner_sha256':'ccc4885ff9db62293eeae03de7a1f26a7820a347cd3bc784f481e6a08da42ffd'},
    'source_cause':{'chain':['full_tensor','tnew','descriptor','typed_descriptor'],
        'native_source_sha256':'3c2c0a125bcac6d47075bf58fc3f78c0e7b9a0b1370757981b99dcd3793b21c6',
        'typed_descriptor_sha256':'eed87bc2f1ff9db405584a249d0548a47703d73a8df4df3f0a6c3cb386925ff2',
        'per_dimension_limit':262144,'failure_branch':'v215 > v216(262144) -> b20 -> terror(3)',
        'diagnostic_job_id':'1a1e6cd2518-392-3c43'},
    'numeric_version_rollback_expectations_changed':False,'production_changed':False,
    'successor_execution_scope':'Only preserve_capacity_oom_recovery; both existing PASS controls remain at the original execution identity.'}
(new/'filler-setup-correction.json').write_text(json.dumps(proof,indent=2)+'\n')
(new/'README.md').write_text((old/'README.md').read_text()+'''\n## Source revision 02\n\nThe first execution passed the tail reuse and Saved-error prefix controls. Its OOM recipe failed before temporary prlimit or backward: a filler shape of 332548 exceeded the frozen typed_descriptor per-dimension bound of 262144. This revision caps each filler at that exact existing bound and adds case selection. It changes no native source or numeric, Version, whole-owner, RNG, mapping, or cleanup assertion. The first failure stays separate. Execute the successor with --case preserve_capacity_oom_recovery to avoid repeating the two successful controls.\n''')
for p in new.rglob('*'):
    if p.is_file():p.chmod(0o644)
files={p.relative_to(new).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'mode':p.stat().st_mode&511}
       for p in sorted(new.rglob('*')) if p.is_file() and p != new/'source-manifest.json'}
manifest={'schema':'heptatorch.r3-preserve-resource-source.v2','status':'PREPARED_NOT_RUN','files':files,
    'source01_manifest_sha256':sha((old/'source-manifest.json').read_bytes()),'whole_file_inverse_exact':True}
(new/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(new/'source-manifest.json').chmod(0o644)
archive=root/'source-02.tar.xz'
with tarfile.open(archive,'w:xz') as t:
    for p in sorted(new.rglob('*')):
        if p.is_file():t.add(p,arcname=p.relative_to(new).as_posix(),recursive=False)
with tarfile.open(archive,'r:xz') as t:
    for m in t.getmembers():
        p=new/m.name;assert m.isfile() and t.extractfile(m).read()==p.read_bytes() and m.mode==p.stat().st_mode&511
print(json.dumps({'source':str(new),'manifest_sha256':sha((new/'source-manifest.json').read_bytes()),
    'driver_sha256':sha(result),'proof_sha256':sha((new/'filler-setup-correction.json').read_bytes()),
    'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),
    'payloads':len(files),'whole_inverse':True}))
