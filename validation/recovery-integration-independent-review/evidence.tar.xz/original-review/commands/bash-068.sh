echo '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160  tests/pytorch_tensor_rng_backward_oracle.py' | sha256sum -c -
status=0
python3 tests/pytorch_tensor_rng_backward_oracle.py \
  --native build/retained-gradients/tensor-retained-session \
  --source build/retained-gradients/runtime.hepta \
  --expected-native-sha256 7568c0a4ec40d82d3a0b46d1e8a27499dd96e8fe3fd15433523131a196da89b5 \
  --expected-source-sha256 666230f05cc6942470006d1f184135321d8cbc26a6c6ba0bf7e3cf9857fe515b \
  --repo . --output build/pytorch-retained-gradients-backward.json > build/pytorch-retained-gradients-backward.stdout || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-retained-gradients-backward.json
exit "$status"

