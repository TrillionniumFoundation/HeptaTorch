status=0
make differentiable-view-recovered \
  HEPTA_SOURCE_ROOT="$GITHUB_WORKSPACE/.toolchain/hepta" \
  HEPTA_STACK_BUILD="$RUNNER_TEMP/hepta-stack-budget" || status=$?
if [ -f build/differentiable-view-recovered/build.json ]; then
  cp build/differentiable-view-recovered/build.json build/differentiable-view-recovered-build.json
  python3 -I -S -B tools/emit_ci_report.py build/differentiable-view-recovered-build.json
fi
exit "$status"

