python3 -I -S -B tools/modules/build_module_compiler.py \
  --source-root "$GITHUB_WORKSPACE/.toolchain/hepta" \
  --capacity-adaptation "$RUNNER_TEMP/hepta-profile-sources/adaptation.json" \
  --output "$RUNNER_TEMP/hepta-modules-sources"
python3 -I -S -B tools/modules/build_module_linker.py \
  --source-root "$GITHUB_WORKSPACE/.toolchain/hepta" \
  --capacity-adaptation "$RUNNER_TEMP/hepta-profile-sources/adaptation.json" \
  --output "$RUNNER_TEMP/hepta-modules-sources"
cp "$RUNNER_TEMP/hepta-profile-sources/compiler-packer.hepta" \
  "$RUNNER_TEMP/hepta-modules-sources/compiler-packer.hepta"
bash tools/modules/rebuild.sh \
  "$RUNNER_TEMP/hepta-expanded/hia-native-compiler" \
  "$RUNNER_TEMP/hepta-modules-sources" \
  "$RUNNER_TEMP/hepta-modules-native"
python3 -I -S -B - <<'MODULE_REPRODUCTION'
from pathlib import Path
import hashlib
import json
import os
temporary = Path(os.environ['RUNNER_TEMP'])
sources = temporary / 'hepta-modules-sources'
native = temporary / 'hepta-modules-native'
recorded = json.loads(Path('validation/native-modules.json').read_text())
digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((sources / 'compiler-adaptation.json').read_text()) == recorded['compiler_authoring']
assert json.loads((sources / 'linker-authoring.json').read_text()) == recorded['linker_authoring']
assert digest(native / 'module-compiler') == recorded['compiler_executable_sha256']
assert digest(native / 'module-linker') == recorded['linker_executable_sha256']
generations = []
for generation in range(3):
    generations.append({'generation': generation,
                        'flat_sha256': digest(native / ('M' + str(generation) + '.image')),
                        'executable_sha256': digest(native / ('compiler-' + str(generation)))})
assert generations == recorded['native_reproduction']['generations']
print(json.dumps({'schema': 'heptatorch.hosted-module-reproduction.v1', 'status': 'PASS',
                  'profile': recorded['profile'], 'native_generations': generations,
                  'compiler_authoring_closure_files': len(recorded['compiler_authoring']['upstream_source_files_verified_before_and_after']),
                  'linker_authoring_closure_files': len(recorded['linker_authoring']['upstream_source_files_verified_before_and_after'])}))
MODULE_REPRODUCTION

