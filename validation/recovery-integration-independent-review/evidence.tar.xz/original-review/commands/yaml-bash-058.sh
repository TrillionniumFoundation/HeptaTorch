python3 -I -S -B - <<'DUAL_ORACLE'
from pathlib import Path
import hashlib
import json
import os
digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
reports = []
names = None
expected_checks = {'python_matches', 'platform_matches', 'version_backend_matches',
                   'git_matches_oracle_build_pin', 'distribution_version_matches',
                   'direct_url_matches', 'direct_url_archive_sha256_matches',
                   'pip_report_url_matches', 'pip_report_archive_sha256_matches',
                   'pip_report_version_matches', 'pip_report_requested'}
for mode, executable, report_file in (
    ('native-linked', 'build/heptatorch', 'build/pytorch-native-linked.json'),
    ('monolithic', 'build/heptatorch-monolithic', 'build/pytorch-monolithic.json')):
    report = json.loads(Path(report_file).read_text())
    assert report['status'] == 'PASS' and report['failed_cases'] == 0
    assert report['expected_cases'] == report['cases'] == len(report['rows']) == 270
    assert report['native_unchanged_during_run']
    assert report['native_executable_sha256'] == digest(executable)
    provenance = report['oracle_provenance']
    assert provenance['status'] == 'PASS' and provenance['metadata_error'] is None
    assert set(provenance['checks']) == expected_checks
    assert all(value is True for value in provenance['checks'].values())
    assert provenance['lock_sha256'] == digest('compatibility/pytorch-oracle-lock.json')
    case_names = {row['case'] for row in report['rows']}
    assert len(case_names) == 270 and all(row['status'] == 'PASS' for row in report['rows'])
    if names is not None:
        assert case_names == names
    names = case_names
    reports.append({'build': mode, 'status': 'PASS', 'cases': report['cases'],
                    'compared_values': report['compared_values'],
                    'native_executable_sha256': report['native_executable_sha256'],
                    'oracle_provenance_checks': len(expected_checks),
                    'oracle_lock_sha256': provenance['lock_sha256'],
                    'report_path': report_file, 'report_sha256': digest(report_file)})
summary = {'schema': 'heptatorch.hosted-tensor-composition-summary.v1', 'status': 'PASS',
           'source_sha256': digest('src/heptatorch.hepta'),
           'oracle_script_sha256': digest('tests/pytorch_oracle.py'), 'builds': reports,
           'historical_159_case_receipts_modified': False}
Path('build/hosted-tensor-composition.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
with Path(os.environ['GITHUB_STEP_SUMMARY']).open('a') as output:
    output.write('### Current HIA runtime and pinned PyTorch\n\n')
    output.write('| Build | Native fixtures | PyTorch cases | Provenance checks | Executable SHA-256 |\n')
    output.write('| --- | ---: | ---: | ---: | --- |\n')
    for report in reports:
        output.write('| ' + report['build'] + ' | 461 | 270 | 11 | `' + report['native_executable_sha256'] + '` |\n')
    output.write('\nHistorical 159-case receipts remain unchanged. Current reports are recorded separately for each build.\n')
DUAL_ORACLE
