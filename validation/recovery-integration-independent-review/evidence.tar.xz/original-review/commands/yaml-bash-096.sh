python3 -I -S -B tests/private_node_accounting/collect_private_node_journals.py \
  --build build --journal-root build/frozen35-private-node --wire-root build/frozen35-private-node-wire \
  --reports build/pytorch-gradient-objects-frozen35.json build/pytorch-gradient-objects-frozen35-original.json \
    build/pytorch-gradient-adam-distributions-frozen35.json build/pytorch-gradient-adam-distributions-frozen35-original.json \
    build/pytorch-retained-gradients-frozen35.json build/pytorch-retained-gradients-frozen35-original.json build/pytorch-install.json \
  --job-status 'GITHUB_EXPRESSION'
