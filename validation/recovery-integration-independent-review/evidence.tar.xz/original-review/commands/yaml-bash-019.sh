sha256sum -c validation/stack-budget-package.sha256
python3 -I -S -B tools/stack_budget/rebuild.py \
  --source-root "$GITHUB_WORKSPACE/.toolchain/hepta" \
  --owned-build "$RUNNER_TEMP/hepta-owned-modules" \
  --session-build "$RUNNER_TEMP/hepta-owned-session-tools" \
  --borrowed-tools "$RUNNER_TEMP/hepta-modules-native" \
  --output "$RUNNER_TEMP/hepta-stack-budget"
