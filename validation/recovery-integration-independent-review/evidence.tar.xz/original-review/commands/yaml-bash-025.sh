make gradient-none tensor-rng-nullable test-gradient-none \
  HEPTA_SOURCE_ROOT="$GITHUB_WORKSPACE/.toolchain/hepta" \
  HEPTA_STACK_BUILD="$RUNNER_TEMP/hepta-stack-budget"
python3 -I -S -B tools/emit_ci_report.py build/hosted-gradient-none-native.json
