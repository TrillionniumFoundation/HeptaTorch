make owned-tensors test-owned-tensors owned-tensor-versions test-owned-tensor-versions \
  HEPTA_COMPILER="$RUNNER_TEMP/hepta-expanded/hia-native-compiler" \
  HEPTA_SOURCE_ROOT="$GITHUB_WORKSPACE/.toolchain/hepta" \
  HEPTA_OWNED_COMPILER="$RUNNER_TEMP/hepta-owned-modules/native/owned-module-compiler" \
  HEPTA_OWNED_SESSION_BUILD="$RUNNER_TEMP/hepta-owned-session-tools"
