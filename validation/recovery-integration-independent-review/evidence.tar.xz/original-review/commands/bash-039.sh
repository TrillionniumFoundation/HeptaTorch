status=0
make test-differentiable-view-reference14 || status=$?
if [ -f build/differentiable-view-reference14/report.json ]; then
  cp build/differentiable-view-reference14/report.json build/differentiable-view-reference14.json
  python3 -I -S -B tools/emit_ci_report.py build/differentiable-view-reference14.json
fi
exit "$status"

