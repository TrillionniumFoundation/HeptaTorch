echo '149b41c455444edeb8d25d0ad98045e29683e780f37f7e210e7985242d359597  tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py' | sha256sum -c -
status=0
python3 tests/dtype_frozen35_accounting/run_frozen35_accounted.py \
  --legacy-directory tests/tensor_object_oracle \
  --native-source build/native-dropout/runtime.hepta \
  --observer-output build/frozen35-dtype-node/523 \
  --observer-report build/pytorch-native-dropout-frozen35.json \
  -- build/native-dropout/tensor-dtype-dropout-session build/pytorch-native-dropout-frozen35-original.json \
  --owned-reference tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \
  --session-reference tests/pytorch_session_oracle.py --reference tests/pytorch_oracle.py \
  --lock compatibility/pytorch-oracle-lock.json --repo . \
  --trace-directory build/frozen35-dtype-node-wire/523 \
  --expected-native-sha256 830f0b4ef8d6ad8c6a105be56d383628b45c84e3e43905fee6812c7c52d35a51 || status=$?
if [ -f build/pytorch-native-dropout-frozen35.json ]; then
  python3 -I -S -B tools/emit_ci_report.py build/pytorch-native-dropout-frozen35.json
fi
if [ "$status" -eq 0 ]; then
  python3 -I -S -B tests/dtype_frozen35_accounting/check_frozen35_accounted.py \
    --observer-report build/pytorch-native-dropout-frozen35.json \
    --original-report build/pytorch-native-dropout-frozen35-original.json
fi
exit "$status"

