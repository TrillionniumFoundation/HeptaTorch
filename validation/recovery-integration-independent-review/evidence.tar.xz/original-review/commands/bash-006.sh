python3 -I -S -B tools/modules/tests/boundaries.py \
  --compiler "$RUNNER_TEMP/hepta-modules-native/module-compiler" \
  --linker "$RUNNER_TEMP/hepta-modules-native/module-linker" \
  --legacy-compiler "$RUNNER_TEMP/hepta-expanded/hia-native-compiler" \
  --output "$RUNNER_TEMP/hepta-module-review/boundaries"
python3 -I -S -B tools/modules/tests/contracts.py \
  --compiler "$RUNNER_TEMP/hepta-modules-native/module-compiler" \
  --linker "$RUNNER_TEMP/hepta-modules-native/module-linker" \
  --output "$RUNNER_TEMP/hepta-module-review/contracts"
python3 -I -S -B tools/modules/tests/capabilities.py \
  --compiler "$RUNNER_TEMP/hepta-modules-native/module-compiler" \
  --linker "$RUNNER_TEMP/hepta-modules-native/module-linker" \
  --output "$RUNNER_TEMP/hepta-module-review/capabilities"
python3 -I -S -B tools/modules/tests/abi.py \
  --compiler-image "$RUNNER_TEMP/hepta-modules-native/M2.image" \
  --linker-image "$RUNNER_TEMP/hepta-modules-native/module-linker.image" \
  --boundary-output "$RUNNER_TEMP/hepta-module-review/boundaries" \
  --runtime-request "$RUNNER_TEMP/hepta-runtime-native/link-request.bin" \
  --runtime-executable "$RUNNER_TEMP/hepta-runtime-native/application" \
  --output "$RUNNER_TEMP/hepta-module-review/abi"
python3 -I -S -B - <<'MODULE_GATES'
from pathlib import Path
import hashlib
import json
import os
temporary = Path(os.environ['RUNNER_TEMP'])
review = temporary / 'hepta-module-review'
recorded = json.loads(Path('validation/native-modules.json').read_text())
suites = [('boundary_tests', 'boundaries/report.json', 69),
          ('independent_contract_tests', 'contracts/report.json', 204),
          ('independent_capability_tests', 'capabilities/external-capability-review.json', 19),
          ('guarded_flat_abi_tests', 'abi/report.json', 18)]
results = []
for key, relative, count in suites:
    observed = json.loads((review / relative).read_text())
    assert observed['status'] == 'PASS'
    assert observed['cases'] == recorded['suite_counts'][key] == count
    assert all(row['status'] == 'PASS' for row in observed['rows'])
    assert {row['case'] for row in observed['rows']} == {row['case'] for row in recorded['reports'][key]['rows']}
    results.append({'suite': key, 'cases': count, 'status': 'PASS'})
partition = json.loads((temporary / 'hepta-runtime-units/split-manifest.json').read_text())
assert partition == recorded['current_runtime']['source_partition']
digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
native = temporary / 'hepta-runtime-native'
assert digest(native / 'application') == recorded['current_runtime']['linked_executable_sha256']
assert digest(native / 'link-request.bin') == recorded['current_runtime']['link_request_sha256']
for index, expected in enumerate(recorded['current_runtime']['objects']):
    assert digest(native / ('unit-' + str(index) + '.o')) == expected['object_sha256']
ordinary = json.loads((review / 'ordinary/report.json').read_text())
assert ordinary == recorded['reports']['ordinary_mode_equivalence']
print(json.dumps({'schema': 'heptatorch.hosted-native-module-gates.v1', 'status': 'PASS',
                  'source_sha256': partition['source_sha256'], 'suites': results,
                  'complete_source_partition_identical': True,
                  'linked_executable_sha256': digest(native / 'application'),
                  'current_complete_source_and_unhex_byte_identical': True}))
MODULE_GATES

