python3 -I -S -B tests/private_node_accounting/collect_private_node_journals.py \
  --build build --journal-root build/frozen35-mixed-integer-node --wire-root build/frozen35-mixed-integer-node-wire \
  --reports build/pytorch-mixed-integer-autograd-frozen35.json build/pytorch-mixed-integer-autograd-frozen35-original.json \
    build/pytorch-mixed-integer-autograd-frozen35-observer-controls.json build/mixed-integer-autograd-storage-tombstone.json \
    build/pytorch-mixed-integer-autograd-backward.json build/pytorch-install.json \
  --job-status 'GITHUB_EXPRESSION'
