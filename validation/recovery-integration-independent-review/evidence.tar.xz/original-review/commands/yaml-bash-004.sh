python3 -I -S -B - <<'PY'
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

root = Path('.toolchain/hepta').resolve()
output = Path(os.environ['RUNNER_TEMP']) / 'hepta-compiler'
output.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(root))
from tools.qualify_hia_selfhost import build_seed, compile_stage

expected_commit = 'f33d8da316de8fdf27b504371f1a5310997ff548'
expected_source = '388b182e42675f11435867dd99520e9452a4ff48e23c0766a3952b662acc7627'
expected_compiler = '87c247e4d1c3c9a449d2947fd4227fdc186d519bffd203a04cafce7861a4ed54'
head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
if head != expected_commit:
    raise RuntimeError('unexpected HIA source commit')
source = (root / 'examples/hia_bootstrap/selfhost.hepta').read_bytes()
if hashlib.sha256(source).hexdigest() != expected_source:
    raise RuntimeError('unexpected HIA compiler source digest')

# B0 is the external bootstrap boundary: Python assembler and GNU ld.
# B1 onward are compiled by preceding HIA machine code. The upstream
# stdlib child transports fixed ABI buffers; it does not compile them.
image, seed = build_seed(output, source)
generations = []
for label in ('B1', 'B2', 'B3'):
    image, receipt = compile_stage(
        output, label, image, source,
        image_format='seed-shared' if label == 'B1' else 'flat-x86-64')
    generations.append(receipt['produced_sha256'])
if len(set(generations)) != 1:
    raise RuntimeError('B1/B2/B3 compiler images differ')

old = b'hia-asm.v1 hepta.hia.program.v8 selfhost\n'
new = b'hia-asm.v1 hepta.hia.program.v8 selfhost_exec\n'
if not source.startswith(old):
    raise RuntimeError('unexpected compiler module header')
executable_source = new + source[len(old):]
compiler, receipt = compile_stage(
    output, 'native-compiler', image, executable_source,
    output_extension='')
compiler.chmod(0o755)
compiler_bytes = compiler.read_bytes()
if hashlib.sha256(compiler_bytes).hexdigest() != expected_compiler:
    raise RuntimeError('unexpected native compiler digest')

# The standalone compiler performs two further rebuilds with no PATH.
previous = compiler
for generation in (1, 2):
    result = subprocess.run(
        [str(previous)], input=executable_source, capture_output=True,
        timeout=20, env={'PATH': ''})
    if result.returncode or result.stderr or result.stdout != compiler_bytes:
        raise RuntimeError('standalone native compiler did not reproduce itself')
    previous = output / ('native-compiler-rebuilt-' + str(generation))
    previous.write_bytes(result.stdout)
    previous.chmod(0o755)

print(json.dumps({
    'status': 'PASS', 'hepta_commit': head,
    'compiler_source_sha256': expected_source,
    'B1_B2_B3_sha256': generations[0],
    'standalone_compiler_sha256': expected_compiler,
    'standalone_fixed_point_generations': 2,
    'B0_requires_Python_and_GNU_ld': True,
    'full_upstream_cold_qualification': False
}, indent=2))
PY
