status=0
make test-tensor-to-recovered-live32 HEPTA_STACK_BUILD="$RUNNER_TEMP/hepta-stack-budget" || status=$?
if [ -f build/pytorch-tensor-to-recovered-backward.json ]; then
  python3 -I -S -B tools/emit_ci_report.py build/pytorch-tensor-to-recovered-backward.json
fi
exit "$status"
