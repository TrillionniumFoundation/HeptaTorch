status=0
make test-differentiable-view-native14 \
  HEPTA_SOURCE_ROOT="$GITHUB_WORKSPACE/.toolchain/hepta" \
  HEPTA_STACK_BUILD="$RUNNER_TEMP/hepta-stack-budget" || status=$?
if [ -f build/differentiable-view-native14/report.json ]; then
  cp build/differentiable-view-native14/report.json build/differentiable-view-native14.json
  python3 -I -S -B tools/emit_ci_report.py build/differentiable-view-native14.json
fi
exit "$status"

