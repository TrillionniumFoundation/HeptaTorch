echo '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160  tests/pytorch_tensor_rng_backward_oracle.py' | sha256sum -c -
status=0
python3 tests/pytorch_tensor_rng_backward_oracle.py \
  --native build/gradient-adam-distributions/tensor-gradient-adam-distributions-session \
  --source build/gradient-adam-distributions/runtime.hepta \
  --expected-native-sha256 6773485896d961b6c2e62784ebb66320290df47128bd1331aecc0c8b7f6611fe \
  --expected-source-sha256 1fed8ea7ba5bf755a9df9ca1e61d34cfd4712cc2fd66e0728493091c81c24dae \
  --repo . --output build/pytorch-gradient-adam-distributions-backward.json > build/pytorch-gradient-adam-distributions-backward.stdout || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-gradient-adam-distributions-backward.json
exit "$status"
