echo '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160  tests/pytorch_tensor_rng_backward_oracle.py' | sha256sum -c -
status=0
python3 tests/pytorch_tensor_rng_backward_oracle.py \
  --native build/adam-distributions/tensor-adam-distributions-session \
  --source build/adam-distributions/runtime.hepta \
  --expected-native-sha256 3fc59ab7ed9c32dd75ff440ef9bfbec31756f50edd77715d665bdac098cc3f22 \
  --expected-source-sha256 5d3a3c047d024a3880d257a317a04c2166a2e87bbc6b248bef62649a88546873 \
  --repo . --output build/pytorch-adam-distributions-backward.json > build/pytorch-adam-distributions-backward.stdout || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-adam-distributions-backward.json
exit "$status"

