status=0
make test-tensor-to-recovered-tombstone HEPTA_STACK_BUILD="$RUNNER_TEMP/hepta-stack-budget" || status=$?
if [ -f build/frozen35-tensor-to-node/storage-tombstone/report.json ]; then
  cp build/frozen35-tensor-to-node/storage-tombstone/report.json build/tensor-to-recovered-storage-tombstone.json
  python3 -I -S -B tools/emit_ci_report.py build/tensor-to-recovered-storage-tombstone.json
fi
exit "$status"

