echo '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160  tests/pytorch_tensor_rng_backward_oracle.py' | sha256sum -c -
status=0
python3 tests/pytorch_tensor_rng_backward_oracle.py \
  --native build/native-dropout/tensor-dtype-dropout-session \
  --source build/native-dropout/runtime.hepta \
  --expected-native-sha256 830f0b4ef8d6ad8c6a105be56d383628b45c84e3e43905fee6812c7c52d35a51 \
  --expected-source-sha256 6ffe509afce28ff15705b4c7b269eaef8f8f89f9d8b2486d4d9fa45b6be66ef3 \
  --repo . --output build/pytorch-native-dropout-backward.json > build/pytorch-native-dropout-backward.stdout || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-native-dropout-backward.json
exit "$status"

