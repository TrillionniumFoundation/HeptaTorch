python3 -I -S -B tools/session/tests/flat_linker.py \
  --native-dir "$RUNNER_TEMP/hepta-session-native/flat" \
  --generated-dir "$RUNNER_TEMP/hepta-session-generated/flat" \
  --prior-review-dir "$RUNNER_TEMP/hepta-module-review/boundaries" \
  --prior-report "$RUNNER_TEMP/hepta-module-review/boundaries/report.json" \
  --abi-observer tools/modules/tests/observe_flat.py \
  --output "$RUNNER_TEMP/hepta-session-review/flat"
python3 -I -S -B tools/session/tests/packer.py \
  --executable "$RUNNER_TEMP/hepta-session-native/packer/session-packer" \
  --image "$RUNNER_TEMP/hepta-session-native/packer/session-packer.image" \
  --generated "$RUNNER_TEMP/hepta-session-generated/packer" \
  --output "$RUNNER_TEMP/hepta-session-review/packer"
python3 -I -S -B tools/session/tests/modular_capacity.py \
  --compiler "$RUNNER_TEMP/hepta-modules-native/module-compiler" \
  --legacy-compiler "$RUNNER_TEMP/hepta-expanded/hia-native-compiler" \
  --flat-linker "$RUNNER_TEMP/hepta-session-native/flat/flat-linker" \
  --packer "$RUNNER_TEMP/hepta-session-native/packer/session-packer" \
  --output "$RUNNER_TEMP/hepta-session-review/growth"

