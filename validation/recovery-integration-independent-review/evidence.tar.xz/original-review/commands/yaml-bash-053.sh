echo '3b9e1c9058776c67c00c4b07610a2a0d377dda16ca4a956d7e66c442bdfd4157  tests/pytorch_cpu_generator_oracle.py' | sha256sum -c -
status=0
python3 tests/pytorch_cpu_generator_oracle.py \
  --native build/cpu-generators/generator-session \
  --expected-native-sha256 ba344748d42f0def1cd5d88e5e27232a6dfa08e33ef4c42e6f00486f3ca08572 \
  --repo . --output build/pytorch-cpu-generators.json > build/pytorch-cpu-generators.stdout || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-cpu-generators.json
exit "$status"
