echo '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160  tests/pytorch_tensor_rng_backward_oracle.py' | sha256sum -c -
status=0
python3 tests/pytorch_tensor_rng_backward_oracle.py \
  --native build/cpu-distributions-partial/tensor-distributions-session \
  --source build/cpu-distributions-partial/runtime.hepta \
  --expected-native-sha256 bb4c25e35a170f08276d464db6b630cf03765ff816e6a9ca9aa1651360a1ccf4 \
  --expected-source-sha256 55ed0c6e16317add03974c01ffd85e38684fc535a3e5cb6423ed043f4217f05b \
  --repo . --output build/pytorch-cpu-distributions-backward.json > build/pytorch-cpu-distributions-backward.stdout || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-cpu-distributions-backward.json
exit "$status"

