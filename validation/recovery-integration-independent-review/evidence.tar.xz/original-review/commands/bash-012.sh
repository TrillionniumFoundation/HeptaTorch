python3 -I -S -B tools/owned_modules/qualify.py \
  --build "$RUNNER_TEMP/hepta-owned-modules" \
  --source-root "$GITHUB_WORKSPACE/.toolchain/hepta" \
  --borrowed-tools "$RUNNER_TEMP/hepta-modules-native" \
  --baseline-compiler "$RUNNER_TEMP/hepta-expanded/hia-native-compiler" \
  --repo-root "$GITHUB_WORKSPACE" \
  --output "$RUNNER_TEMP/hepta-owned-review"
python3 -I -S -B tests/check_owned_module_reports.py \
  --build "$RUNNER_TEMP/hepta-owned-modules" \
  --review "$RUNNER_TEMP/hepta-owned-review" \
  --output build/hosted-owned-module-gates.json

