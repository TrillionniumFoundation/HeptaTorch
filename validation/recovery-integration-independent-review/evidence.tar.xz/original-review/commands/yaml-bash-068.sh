status=0
python3 tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py \
  build/tensor-objects/abi2/tensor-object-session build/pytorch-tensor-objects-abi2.json \
  --owned-reference tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \
  --session-reference tests/pytorch_session_oracle.py --reference tests/pytorch_oracle.py \
  --lock compatibility/pytorch-oracle-lock.json --repo . \
  --expected-native-sha256 4bd22ab115a5428be6ee1ab77fd31a1e20baf14a80756eb38f000574cbad531f || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-tensor-objects-abi2.json
exit "$status"
