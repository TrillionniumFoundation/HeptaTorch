status=0
python3 tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py \
  build/owned-optimizers/tensor-optimizer-session build/pytorch-owned-optimizer-frozen35.json \
  --owned-reference tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \
  --session-reference tests/pytorch_session_oracle.py --reference tests/pytorch_oracle.py \
  --lock compatibility/pytorch-oracle-lock.json --repo . \
  --expected-native-sha256 b6634158e079512e797d8237cca12d65052db18df23b12b8414adeb8d0b4b0e1 || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-owned-optimizer-frozen35.json
exit "$status"

