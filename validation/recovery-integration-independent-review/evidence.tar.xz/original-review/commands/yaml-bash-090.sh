status=0
python3 -I -S -B tests/mixed_frozen35_accounting/check_owner_snapshots.py \
  --observer tests/mixed_frozen35_accounting/owner_accounting_mixed.py \
  --expected-profile mixed-integer-556-fixed35-F32-Saved \
  --journals build/frozen35-mixed-integer-node/556/owners \
  --output build/frozen35-mixed-integer-node/556/copied-controls || status=$?
if [ -f build/frozen35-mixed-integer-node/556/copied-controls/report.json ]; then
  cp build/frozen35-mixed-integer-node/556/copied-controls/report.json build/pytorch-mixed-integer-autograd-frozen35-observer-controls.json
  python3 -I -S -B tools/emit_ci_report.py build/pytorch-mixed-integer-autograd-frozen35-observer-controls.json
fi
exit "$status"
