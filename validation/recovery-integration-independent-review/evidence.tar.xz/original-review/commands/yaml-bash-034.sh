status=0
python3 -I -S -B tests/dtype_frozen35_accounting/test_storage_tombstone.py \
  --binary build/native-dropout/tensor-dtype-dropout-session \
  --source build/native-dropout/runtime.hepta \
  --protocol tests/retained_nonleaf_review/protocol.py \
  --output build/frozen35-dtype-node/storage-tombstone || status=$?
if [ -f build/frozen35-dtype-node/storage-tombstone/report.json ]; then
  cp build/frozen35-dtype-node/storage-tombstone/report.json build/native-dropout-storage-tombstone.json
  python3 -I -S -B tools/emit_ci_report.py build/native-dropout-storage-tombstone.json
fi
exit "$status"
