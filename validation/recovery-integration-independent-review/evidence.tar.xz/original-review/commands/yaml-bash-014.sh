sha256sum -c validation/owned-module-package.sha256
python3 -I -S -B tools/owned_modules/rebuild.py \
  --source-root "$GITHUB_WORKSPACE/.toolchain/hepta" \
  --capacity-adaptation "$RUNNER_TEMP/hepta-profile-sources/adaptation.json" \
  --borrowed-tools "$RUNNER_TEMP/hepta-modules-native" \
  --output "$RUNNER_TEMP/hepta-owned-modules"
