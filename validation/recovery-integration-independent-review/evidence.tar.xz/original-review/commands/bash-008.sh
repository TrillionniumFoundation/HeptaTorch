python3 -I -S -B tools/session/build_flat_linker.py \
  --source-root "$GITHUB_WORKSPACE/.toolchain/hepta" \
  --capacity-adaptation "$RUNNER_TEMP/hepta-profile-sources/adaptation.json" \
  --output "$RUNNER_TEMP/hepta-session-generated/flat"
python3 -I -S -B tools/session/build_packer.py \
  --source-root "$GITHUB_WORKSPACE/.toolchain/hepta" \
  --capacity-adaptation "$RUNNER_TEMP/hepta-profile-sources/adaptation.json" \
  --output "$RUNNER_TEMP/hepta-session-generated/packer"
python3 -I -S -B tools/session/rebuild_flat_linker.py \
  --compiler "$RUNNER_TEMP/hepta-expanded/hia-native-compiler" \
  --module-compiler "$RUNNER_TEMP/hepta-modules-native/module-compiler" \
  --generated "$RUNNER_TEMP/hepta-session-generated/flat" \
  --output "$RUNNER_TEMP/hepta-session-native/flat"
python3 -I -S -B tools/session/rebuild_packer.py \
  --compiler "$RUNNER_TEMP/hepta-expanded/hia-native-compiler" \
  --module-compiler "$RUNNER_TEMP/hepta-modules-native/module-compiler" \
  --generated "$RUNNER_TEMP/hepta-session-generated/packer" \
  --output "$RUNNER_TEMP/hepta-session-native/packer"

