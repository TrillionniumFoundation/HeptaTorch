make storage-objects test-storage-objects \
  HEPTA_SOURCE_ROOT="$GITHUB_WORKSPACE/.toolchain/hepta" \
  HEPTA_OWNED_COMPILER="$RUNNER_TEMP/hepta-owned-modules/native/owned-module-compiler" \
  HEPTA_OWNED_LINKER="$RUNNER_TEMP/hepta-owned-modules/native/linker-abi2-w1m" \
  HEPTA_OWNED_SESSION_BUILD="$RUNNER_TEMP/hepta-owned-session-tools"

