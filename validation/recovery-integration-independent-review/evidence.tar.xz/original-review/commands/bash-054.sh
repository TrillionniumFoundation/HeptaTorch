python3 tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \
  build/stack-tensors/owned-tensor-session build/pytorch-stack-tensor.json \
  --session-reference tests/pytorch_session_oracle.py \
  --reference tests/pytorch_oracle.py \
  --lock compatibility/pytorch-oracle-lock.json --repo . \
  --expected-native-sha256 e172bc81dfbe9ee2c9853cf9221ebf7236e8099a207947bccff66b0b01dc1f5f

