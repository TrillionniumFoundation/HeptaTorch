status=0
python3 -I -S -B tests/integer_frozen35_accounting/check_owner_snapshots.py \
  --observer tests/integer_frozen35_accounting/owner_accounting_int64.py \
  --expected-profile integer-tensor-544-fixed35-F32 \
  --journals build/frozen35-integer-node/544/owners \
  --output build/frozen35-integer-node/544/copied-controls || status=$?
if [ -f build/frozen35-integer-node/544/copied-controls/report.json ]; then
  cp build/frozen35-integer-node/544/copied-controls/report.json build/pytorch-integer-tensors-frozen35-observer-controls.json
  python3 -I -S -B tools/emit_ci_report.py build/pytorch-integer-tensors-frozen35-observer-controls.json
fi
exit "$status"

