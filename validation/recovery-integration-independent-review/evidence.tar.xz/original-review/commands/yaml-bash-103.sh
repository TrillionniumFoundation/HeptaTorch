python3 -I -S -B tests/private_node_accounting/collect_private_node_journals.py \
  --build build --journal-root build/frozen35-integer-node --wire-root build/frozen35-integer-node-wire \
  --reports build/pytorch-integer-tensors-frozen35.json build/pytorch-integer-tensors-frozen35-original.json \
    build/pytorch-integer-tensors-frozen35-observer-controls.json build/integer-tensors-storage-tombstone.json \
    build/pytorch-integer-tensors-backward.json build/pytorch-install.json \
  --job-status 'GITHUB_EXPRESSION'
