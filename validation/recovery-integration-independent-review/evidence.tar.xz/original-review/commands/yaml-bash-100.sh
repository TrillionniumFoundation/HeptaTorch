python3 -I -S -B tests/private_node_accounting/collect_private_node_journals.py \
  --build build --journal-root build/frozen35-dtype-node --wire-root build/frozen35-dtype-node-wire \
  --reports build/pytorch-native-dropout-frozen35.json build/pytorch-native-dropout-frozen35-original.json \
    build/pytorch-native-dropout-frozen35-observer-controls.json build/native-dropout-storage-tombstone.json \
    build/pytorch-native-dropout-backward.json build/pytorch-install.json \
  --job-status 'GITHUB_EXPRESSION'
