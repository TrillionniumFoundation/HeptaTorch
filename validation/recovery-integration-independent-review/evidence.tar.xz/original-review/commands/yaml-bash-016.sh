sha256sum -c validation/owned-session-package.sha256
python3 -I -S -B tools/owned_sessions/rebuild.py \
  --source-root "$GITHUB_WORKSPACE/.toolchain/hepta" \
  --owned-build "$RUNNER_TEMP/hepta-owned-modules" \
  --owned-profile tools/owned_modules/profile.json \
  --borrowed-tools "$RUNNER_TEMP/hepta-modules-native" \
  --output "$RUNNER_TEMP/hepta-owned-session-tools"
