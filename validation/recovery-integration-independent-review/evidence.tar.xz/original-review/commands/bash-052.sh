python3 tests/pytorch_object_lifetime_probe.py \
  --reference tests/pytorch_oracle.py --lock compatibility/pytorch-oracle-lock.json \
  --repo . --output build/pytorch-lifetime-observations.json
cat build/pytorch-lifetime-observations.json

