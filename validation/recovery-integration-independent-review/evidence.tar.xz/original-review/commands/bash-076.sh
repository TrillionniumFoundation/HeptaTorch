echo '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160  tests/pytorch_tensor_rng_backward_oracle.py' | sha256sum -c -
status=0
python3 tests/pytorch_tensor_rng_backward_oracle.py \
  --native build/mixed-integer-autograd/tensor-mixed-autograd-session \
  --source build/mixed-integer-autograd/runtime.hepta \
  --expected-native-sha256 69045063c00395d07fc6c0101ed1b8aba18376cb1daea54e0a01c2c5caeb49b6 \
  --expected-source-sha256 5f8ab1f7ca1593dc21b8b6a3537e210cfbc42b37ddefcb322239c5a316d88c49 \
  --repo . --output build/pytorch-mixed-integer-autograd-backward.json > build/pytorch-mixed-integer-autograd-backward.stdout || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-mixed-integer-autograd-backward.json
exit "$status"

