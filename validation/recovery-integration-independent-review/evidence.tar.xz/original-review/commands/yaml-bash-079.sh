echo '149b41c455444edeb8d25d0ad98045e29683e780f37f7e210e7985242d359597  tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py' | sha256sum -c -
status=0
python3 tests/private_node_accounting/run_frozen35_accounted.py \
  --legacy-directory tests/tensor_object_oracle \
  --native-source build/gradient-adam-distributions/runtime.hepta \
  --observer-output build/frozen35-private-node/428 \
  --observer-report build/pytorch-gradient-adam-distributions-frozen35.json \
  build/gradient-adam-distributions/tensor-gradient-adam-distributions-session build/pytorch-gradient-adam-distributions-frozen35-original.json \
  --owned-reference tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \
  --session-reference tests/pytorch_session_oracle.py --reference tests/pytorch_oracle.py \
  --lock compatibility/pytorch-oracle-lock.json --repo . \
  --trace-directory build/frozen35-private-node-wire/428 \
  --expected-native-sha256 6773485896d961b6c2e62784ebb66320290df47128bd1331aecc0c8b7f6611fe || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-gradient-adam-distributions-frozen35.json
if [ "$status" -eq 0 ]; then
  python3 -I -S -B tests/private_node_accounting/check_frozen35_accounted.py \
    --observer-report build/pytorch-gradient-adam-distributions-frozen35.json \
    --original-report build/pytorch-gradient-adam-distributions-frozen35-original.json
fi
exit "$status"
