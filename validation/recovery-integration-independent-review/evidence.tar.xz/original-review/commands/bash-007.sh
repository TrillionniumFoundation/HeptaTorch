make all monolithic \
  HEPTA_COMPILER="$RUNNER_TEMP/hepta-expanded/hia-native-compiler" \
  HEPTA_MODULE_COMPILER="$RUNNER_TEMP/hepta-modules-native/module-compiler" \
  HEPTA_MODULE_LINKER="$RUNNER_TEMP/hepta-modules-native/module-linker"
cmp build/heptatorch "$RUNNER_TEMP/hepta-runtime-native/application"
make test \
  HEPTA_COMPILER="$RUNNER_TEMP/hepta-expanded/hia-native-compiler" \
  HEPTA_MODULE_COMPILER="$RUNNER_TEMP/hepta-modules-native/module-compiler" \
  HEPTA_MODULE_LINKER="$RUNNER_TEMP/hepta-modules-native/module-linker" | tee build/native-linked-fixtures.log
make test-monolithic \
  HEPTA_COMPILER="$RUNNER_TEMP/hepta-expanded/hia-native-compiler" \
  HEPTA_MODULE_COMPILER="$RUNNER_TEMP/hepta-modules-native/module-compiler" \
  HEPTA_MODULE_LINKER="$RUNNER_TEMP/hepta-modules-native/module-linker" | tee build/monolithic-fixtures.log
python3 -I -S -B - <<'MANIFEST'
import hashlib
import json
import os
from pathlib import Path

digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest = json.loads(Path('validation/fixture-manifest.json').read_text())
evidence = json.loads(Path('validation/native-modules.json').read_text())
assert manifest['source_sha256'] == digest('src/heptatorch.hepta') == evidence['current_runtime']['source_partition']['source_sha256']
assert manifest['executables_sha256']['linked'] == digest('build/heptatorch') == evidence['current_runtime']['linked_executable_sha256']
assert manifest['executables_sha256']['monolithic'] == digest('build/heptatorch-monolithic')
ordinary = json.loads((Path(os.environ['RUNNER_TEMP']) / 'hepta-module-review/ordinary/report.json').read_text())
assert ordinary['rows'][0]['image_sha256'] == digest('build/heptatorch-monolithic')
assert ordinary['rows'][1]['image_sha256'] == digest('build/unhex')
paths = {entry['path'] for entry in manifest['files']}
assert len(paths) == len(manifest['files'])
assert paths == {str(p) for p in Path('tests/fixtures').glob('*.hex')}
assert manifest['fixture_pairs'] == len(paths) // 2 == 461
assert evidence['reports']['current_runtime_fixtures']['cases'] == 461
for entry in manifest['files']:
    assert Path(entry['path']).stat().st_size == entry['bytes']
    assert digest(entry['path']) == entry['sha256']
for mode in ('native-linked', 'monolithic'):
    log = Path('build/' + mode + '-fixtures.log').read_text()
    assert 'PASS: 461 native packet regression fixtures' in log
print(json.dumps({'schema': 'heptatorch.hosted-dual-build-fixtures.v1', 'status': 'PASS',
                  'source_sha256': manifest['source_sha256'], 'fixture_pairs_per_build': 461,
                  'native_linked_sha256': digest('build/heptatorch'),
                  'monolithic_sha256': digest('build/heptatorch-monolithic')}))
MANIFEST

