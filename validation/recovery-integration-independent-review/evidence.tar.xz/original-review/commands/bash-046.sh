echo '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160  tests/pytorch_tensor_rng_backward_oracle.py' | sha256sum -c -
status=0
python3 tests/pytorch_tensor_rng_backward_oracle.py \
  --native build/owned-optimizers/tensor-optimizer-session \
  --source build/owned-optimizers/runtime.hepta \
  --expected-native-sha256 b6634158e079512e797d8237cca12d65052db18df23b12b8414adeb8d0b4b0e1 \
  --expected-source-sha256 7c68a96b08aa9a21a52e2fd12be912c5f47dbde889e462f9a0dbb38cb3c09edf \
  --repo . --output build/pytorch-owned-optimizer-backward.json > build/pytorch-owned-optimizer-backward.stdout || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-owned-optimizer-backward.json
exit "$status"

