python3 - <<'PYTORCH_INSTALL'
from pathlib import Path
import json
import platform
import subprocess
import sys

lock = json.loads(Path('compatibility/pytorch-oracle-lock.json').read_text())
expected = lock['oracle']
if (sys.implementation.name != expected['python']['implementation']
        or list(sys.version_info[:2]) != expected['python']['version']
        or sys.platform != expected['platform']['sys_platform']
        or platform.machine() != expected['platform']['machine']):
    raise RuntimeError('Pinned PyTorch oracle requires CPython 3.12 on Linux x86_64')
report = Path(expected['install_report'])
report.parent.mkdir(parents=True, exist_ok=True)
wheel = expected['wheel']['url'] + '#sha256=' + expected['wheel']['sha256']
subprocess.run([sys.executable, '-m', 'pip', 'install',
                '--disable-pip-version-check', '--force-reinstall',
                '--index-url', 'https://download.pytorch.org/whl/cpu',
                '--report', str(report), wheel], check=True)
PYTORCH_INSTALL
