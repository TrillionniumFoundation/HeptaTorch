echo '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160  tests/pytorch_tensor_rng_backward_oracle.py' | sha256sum -c -
status=0
python3 tests/pytorch_tensor_rng_backward_oracle.py \
  --native build/tensor-rng-nullable/tensor-rng-session \
  --source build/tensor-rng-nullable/runtime.hepta \
  --expected-native-sha256 5baa9cd5e5625f0e2324941486982b714dcdedfe897f5c16686a3ac8882ce242 \
  --expected-source-sha256 490fc144160f6e4440aed001363f86ccff56c335f9781e38b058fc6106b1be09 \
  --repo . --output build/pytorch-nullable-rng-backward.json > build/pytorch-nullable-rng-backward.stdout || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-nullable-rng-backward.json
exit "$status"
