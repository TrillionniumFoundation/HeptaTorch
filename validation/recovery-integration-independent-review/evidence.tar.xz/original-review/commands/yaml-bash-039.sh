status=0
make check-tensor-to-recovered-source || status=$?
if [ -f build/tensor-to-recovered-source/source-check.json ]; then
  cp build/tensor-to-recovered-source/source-check.json build/tensor-to-recovered-source.json
  python3 -I -S -B tools/emit_ci_report.py build/tensor-to-recovered-source.json
fi
exit "$status"
