status=0
make test-mixed-integer-autograd \
  HEPTA_SOURCE_ROOT="$GITHUB_WORKSPACE/.toolchain/hepta" \
  HEPTA_STACK_BUILD="$RUNNER_TEMP/hepta-stack-budget" \
  HEPTA_COMPILER="$RUNNER_TEMP/hepta-expanded/hia-native-compiler" || status=$?
if [ -f build/hosted-mixed-integer-autograd-native.json ]; then
  python3 -I -S -B tools/emit_ci_report.py build/hosted-mixed-integer-autograd-native.json
fi
exit "$status"

