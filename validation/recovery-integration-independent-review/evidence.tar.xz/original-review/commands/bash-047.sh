echo '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160  tests/pytorch_tensor_rng_backward_oracle.py' | sha256sum -c -
status=0
python3 tests/pytorch_tensor_rng_backward_oracle.py \
  --native build/owned-adam/tensor-adam-session \
  --source build/owned-adam/runtime.hepta \
  --expected-native-sha256 fa92356954dbb9e0c454f2a58c2f78aa33950103d377c57e7b659ec9904183af \
  --expected-source-sha256 253438648a437a75ef2dbc77138eca74cb5fe6a6e2ea322c7c38e5a535e5d2a6 \
  --repo . --output build/pytorch-owned-adam-backward.json > build/pytorch-owned-adam-backward.stdout || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-owned-adam-backward.json
exit "$status"

