python3 -I -S -B - <<'MODULE_INPUTS'
from pathlib import Path
import hashlib
import json
recorded = json.loads(Path('validation/native-modules.json').read_text())
assert recorded['status'] == 'PASS'
for path, expected in recorded['packaged_tools_sha256'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected, path
profile = json.loads(Path('tools/modules/profile.json').read_text())
assert profile['profile'] == recorded['profile'] == 'heptatorch.hia.borrowed-modules.v1'
assert profile['upstream_commit'] == recorded['upstream_commit'] == 'f33d8da316de8fdf27b504371f1a5310997ff548'
print('PASS: exact module adaptation, native authoring additions and test-source pins')
MODULE_INPUTS
