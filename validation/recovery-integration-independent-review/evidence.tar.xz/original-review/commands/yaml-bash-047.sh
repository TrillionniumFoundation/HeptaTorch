echo '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160  tests/pytorch_tensor_rng_backward_oracle.py' | sha256sum -c -
status=0
python3 tests/pytorch_tensor_rng_backward_oracle.py \
  --native build/tensor-rng-composition/native/tensor-rng-session \
  --source build/tensor-rng-composition/native/runtime.hepta \
  --expected-native-sha256 cdcaebb2785639585de7fd2a4e1f98d41a56e885f1657c3485ce5f187f89d726 \
  --expected-source-sha256 7447c169d3b2cad1e55cb7b1b8970d67f4103c5866f6db0a60c0b4d05d02cc0b \
  --repo . --output build/pytorch-tensor-rng-backward.json > build/pytorch-tensor-rng-backward.stdout || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-tensor-rng-backward.json
exit "$status"
