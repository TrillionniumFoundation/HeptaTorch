status=0
make test-retained-gradients \
  HEPTA_SOURCE_ROOT="$GITHUB_WORKSPACE/.toolchain/hepta" \
  HEPTA_STACK_BUILD="$RUNNER_TEMP/hepta-stack-budget" || status=$?
if [ -f build/hosted-retained-gradients-native.json ]; then
  python3 -I -S -B tools/emit_ci_report.py build/hosted-retained-gradients-native.json
fi
exit "$status"

