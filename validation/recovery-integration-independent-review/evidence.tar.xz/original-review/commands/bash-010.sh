make session session-monolithic test-session test-session-monolithic \
  HEPTA_COMPILER="$RUNNER_TEMP/hepta-expanded/hia-native-compiler" \
  HEPTA_MODULE_COMPILER="$RUNNER_TEMP/hepta-modules-native/module-compiler" \
  HEPTA_FLAT_LINKER="$RUNNER_TEMP/hepta-session-native/flat/flat-linker" \
  HEPTA_SESSION_PACKER="$RUNNER_TEMP/hepta-session-native/packer/session-packer"
python3 -I -S -B tests/check_session_reports.py native \
  --review "$RUNNER_TEMP/hepta-session-review" \
  --output build/hosted-persistent-session-native.json

