status=0
python3 tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py \
  build/owned-adam/tensor-adam-session build/pytorch-owned-adam-frozen35.json \
  --owned-reference tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \
  --session-reference tests/pytorch_session_oracle.py --reference tests/pytorch_oracle.py \
  --lock compatibility/pytorch-oracle-lock.json --repo . \
  --expected-native-sha256 fa92356954dbb9e0c454f2a58c2f78aa33950103d377c57e7b659ec9904183af || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-owned-adam-frozen35.json
exit "$status"

