make tensor-objects test-tensor-objects \
  HEPTA_SOURCE_ROOT="$GITHUB_WORKSPACE/.toolchain/hepta" \
  HEPTA_OWNED_COMPILER="$RUNNER_TEMP/hepta-owned-modules/native/owned-module-compiler" \
  HEPTA_OWNED_SESSION_BUILD="$RUNNER_TEMP/hepta-owned-session-tools" \
  HEPTA_STACK_BUILD="$RUNNER_TEMP/hepta-stack-budget"

