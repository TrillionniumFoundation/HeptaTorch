python3 -I -S -B tools/modules/split_runtime.py \
  --source src/heptatorch.hepta --output "$RUNNER_TEMP/hepta-runtime-units"
bash tools/modules/compile_link.sh \
  "$RUNNER_TEMP/hepta-modules-native/module-compiler" \
  "$RUNNER_TEMP/hepta-modules-native/module-linker" \
  "$RUNNER_TEMP/hepta-runtime-native" entry \
  "$RUNNER_TEMP/hepta-runtime-units/ht_runtime.hepta" \
  "$RUNNER_TEMP/hepta-runtime-units/ht_kernel.hepta"
python3 -I -S -B tools/modules/tests/equivalence.py \
  --baseline-compiler "$RUNNER_TEMP/hepta-expanded/hia-native-compiler" \
  --module-compiler "$RUNNER_TEMP/hepta-modules-native/module-compiler" \
  --output "$RUNNER_TEMP/hepta-module-review/ordinary" \
  src/heptatorch.hepta tools/unhex.hepta

