python3 tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \
  build/owned-tensor-versions/owned-tensor-session build/pytorch-owned-tensor.json \
  --session-reference tests/pytorch_session_oracle.py \
  --reference tests/pytorch_oracle.py \
  --lock compatibility/pytorch-oracle-lock.json --repo . \
  --expected-native-sha256 57292dfc87acf88e1f94df70bdd4579ace4dbdeecd288f2d60113f7762837575
