python3 -I -S -B tools/check_acceptance.py
python3 -I -S -B tests/check_acceptance_negative.py
python3 -I -S -B tests/check_session_reports.py sources
