status=0
python3 tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py \
  build/tensor-objects/abi3/tensor-object-session build/pytorch-tensor-objects-abi3.json \
  --owned-reference tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \
  --session-reference tests/pytorch_session_oracle.py --reference tests/pytorch_oracle.py \
  --lock compatibility/pytorch-oracle-lock.json --repo . \
  --expected-native-sha256 2b39ff1a5a258c5fae7be1fbca5dcf0764787b43fa72ad8fdc3ab6fd119e2a91 || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-tensor-objects-abi3.json
exit "$status"
