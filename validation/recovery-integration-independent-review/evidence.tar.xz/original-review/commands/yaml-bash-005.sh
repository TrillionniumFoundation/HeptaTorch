python3 -I -S -B tools/compiler-profile/adapt.py \
  --source-root "$GITHUB_WORKSPACE/.toolchain/hepta" \
  --output "$RUNNER_TEMP/hepta-profile-sources"
python3 -I -S -B tools/compiler-profile/generate_packer.py \
  --source-root "$GITHUB_WORKSPACE/.toolchain/hepta" \
  --output "$RUNNER_TEMP/hepta-profile-sources"
bash tools/compiler-profile/rebuild.sh \
  "$RUNNER_TEMP/hepta-compiler/native-compiler" \
  "$RUNNER_TEMP/hepta-profile-sources" \
  "$RUNNER_TEMP/hepta-expanded"
python3 -I -S -B tools/compiler-profile/check_capacity.py \
  --compiler "$RUNNER_TEMP/hepta-expanded/hia-native-compiler" \
  --output "$RUNNER_TEMP/hepta-capacity-review"
python3 -I -S -B - <<'PROFILE'
from pathlib import Path
import hashlib
import json
import os
import subprocess
temporary = Path(os.environ['RUNNER_TEMP'])
profile = json.loads(Path('compatibility/hia-expanded-profile.json').read_text())
recorded = json.loads(Path('validation/compiler-profile.json').read_text())
digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
legacy = temporary / 'hepta-compiler/native-compiler'
expanded = temporary / 'hepta-expanded/hia-native-compiler'
generated = temporary / 'hepta-profile-sources'
assert digest(expanded) == profile['generated']['native_compiler']['sha256']
assert json.loads((generated / 'adaptation.json').read_text()) == recorded['source_adaptation']
assert json.loads((generated / 'packer-authoring.json').read_text()) == recorded['packer_authoring']
# The original 128-function compiler cannot compile the current
# runtime. Keep its byte witness at the exact previously qualified main.
historical = Path('.toolchain/heptatorch-legacy').resolve()
historical_commit = '31d5b1483714b32254730ba56787884c5c76e2fb'
assert subprocess.check_output(['git', '-C', str(historical), 'rev-parse', 'HEAD'], text=True).strip() == historical_commit
historical_source = historical / 'src/heptatorch.hepta'
historical_source_sha = '4c1d17240dd8616798e238cdd54641ee6f2e42c02635c82b3bdeea0a530b5ca5'
historical_image_sha = 'ecca265b088e0688df8ad963613f6bdf460efd324d0c480e6395e4ef67372779'
assert digest(historical_source) == historical_source_sha
comparisons = []
for name, source_path in [('historical-runtime', historical_source), ('current-unhex', Path('tools/unhex.hepta'))]:
    source = source_path.read_bytes()
    outputs = [subprocess.run([str(compiler)], input=source, capture_output=True,
                              timeout=30, env={'PATH': ''}) for compiler in (legacy, expanded)]
    assert all(p.returncode == 0 and not p.stderr for p in outputs)
    assert outputs[0].stdout == outputs[1].stdout
    image_sha = hashlib.sha256(outputs[0].stdout).hexdigest()
    if name == 'historical-runtime':
        assert image_sha == historical_image_sha
    comparisons.append({'witness': name, 'source_sha256': digest(source_path),
                        'image_sha256': image_sha, 'byte_identical': True})
capacity = json.loads((temporary / 'hepta-capacity-review/summary.json').read_text())
assert capacity['pass'] and capacity['passed'] == capacity['total'] == 16
print(json.dumps({'schema': 'heptatorch.hosted-compiler-profile.v2', 'status': 'PASS',
                  'profile': profile['profile'], 'native_compiler_sha256': digest(expanded),
                  'native_fixed_point_generations': 4,
                  'adaptation_receipts_match': True,
                  'legacy_runtime_witness_commit': historical_commit,
                  'legacy_comparisons': comparisons, 'capacity_review': capacity}))
PROFILE
