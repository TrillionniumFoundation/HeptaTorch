python3 -I -S -B tests/private_node_accounting/collect_private_node_journals.py \
  --build build --journal-root build/frozen35-tensor-to-node --wire-root build/frozen35-tensor-to-node-wire \
  --reports build/pytorch-tensor-to-recovered-frozen35.json build/pytorch-tensor-to-recovered-frozen35-original.json \
    build/pytorch-tensor-to-recovered-observer-controls.json build/tensor-to-recovered-storage-tombstone.json \
    build/pytorch-tensor-to-recovered-backward.json build/tensor-to-recovered-build.json \
    build/tensor-to-recovered-source.json build/pytorch-install.json \
  --job-status 'GITHUB_EXPRESSION'

