status=0
python3 tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py \
  build/tensor-rng-composition/native/tensor-rng-session build/pytorch-tensor-rng-frozen35.json \
  --owned-reference tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \
  --session-reference tests/pytorch_session_oracle.py --reference tests/pytorch_oracle.py \
  --lock compatibility/pytorch-oracle-lock.json --repo . \
  --expected-native-sha256 cdcaebb2785639585de7fd2a4e1f98d41a56e885f1657c3485ce5f187f89d726 || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-tensor-rng-frozen35.json
exit "$status"
