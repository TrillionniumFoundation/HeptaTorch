status=0
python3 -I -S -B tests/integer_frozen35_accounting/test_storage_tombstone.py \
  --binary build/integer-tensors/tensor-integer-session \
  --source build/integer-tensors/runtime.hepta \
  --protocol tests/retained_nonleaf_review/protocol.py \
  --output build/frozen35-integer-node/storage-tombstone || status=$?
if [ -f build/frozen35-integer-node/storage-tombstone/report.json ]; then
  cp build/frozen35-integer-node/storage-tombstone/report.json build/integer-tensors-storage-tombstone.json
  python3 -I -S -B tools/emit_ci_report.py build/integer-tensors-storage-tombstone.json
fi
exit "$status"

