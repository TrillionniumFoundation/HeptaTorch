status=0
python3 -I -S -B tests/dtype_frozen35_accounting/check_owner_snapshots.py \
  --observer tests/dtype_frozen35_accounting/owner_accounting523.py \
  --expected-profile dtype-native-dropout-523 \
  --journals build/frozen35-dtype-node/523/owners \
  --output build/frozen35-dtype-node/523/copied-controls || status=$?
if [ -f build/frozen35-dtype-node/523/copied-controls/report.json ]; then
  cp build/frozen35-dtype-node/523/copied-controls/report.json build/pytorch-native-dropout-frozen35-observer-controls.json
  python3 -I -S -B tools/emit_ci_report.py build/pytorch-native-dropout-frozen35-observer-controls.json
fi
exit "$status"
