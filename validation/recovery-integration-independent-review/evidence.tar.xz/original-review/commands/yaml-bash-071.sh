status=0
python3 tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py \
  build/tensor-rng-nullable/tensor-rng-session build/pytorch-nullable-rng-frozen35.json \
  --owned-reference tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \
  --session-reference tests/pytorch_session_oracle.py --reference tests/pytorch_oracle.py \
  --lock compatibility/pytorch-oracle-lock.json --repo . \
  --expected-native-sha256 5baa9cd5e5625f0e2324941486982b714dcdedfe897f5c16686a3ac8882ce242 || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-nullable-rng-frozen35.json
exit "$status"
