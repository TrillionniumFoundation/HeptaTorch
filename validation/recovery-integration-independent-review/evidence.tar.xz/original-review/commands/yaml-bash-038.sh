status=0
python3 -I -S -B tests/mixed_frozen35_accounting/test_storage_tombstone_legacy_refusal.py \
  --binary build/mixed-integer-autograd/tensor-mixed-autograd-session \
  --source build/mixed-integer-autograd/runtime.hepta \
  --protocol tests/retained_nonleaf_review/protocol.py \
  --output build/frozen35-mixed-integer-node/storage-tombstone || status=$?
if [ -f build/frozen35-mixed-integer-node/storage-tombstone/report.json ]; then
  cp build/frozen35-mixed-integer-node/storage-tombstone/report.json build/mixed-integer-autograd-storage-tombstone.json
  python3 -I -S -B tools/emit_ci_report.py build/mixed-integer-autograd-storage-tombstone.json
fi
exit "$status"
