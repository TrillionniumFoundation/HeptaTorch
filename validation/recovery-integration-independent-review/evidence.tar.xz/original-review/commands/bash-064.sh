echo '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160  tests/pytorch_tensor_rng_backward_oracle.py' | sha256sum -c -
status=0
python3 tests/pytorch_tensor_rng_backward_oracle.py \
  --native build/gradient-objects/tensor-gradient-object-session \
  --source build/gradient-objects/runtime.hepta \
  --expected-native-sha256 be18ab877f38a4027a527783db80a1418a137c7d6da91e5bc39e2af8c044cb6b \
  --expected-source-sha256 1b18da2cf9791e1b20982f9706434c1359ea194dd983dc6c66eb005f152e77b5 \
  --repo . --output build/pytorch-gradient-objects-backward.json > build/pytorch-gradient-objects-backward.stdout || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-gradient-objects-backward.json
exit "$status"

