echo '149b41c455444edeb8d25d0ad98045e29683e780f37f7e210e7985242d359597  tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py' | sha256sum -c -
status=0
python3 tests/integer_frozen35_accounting/run_frozen35_accounted.py \
  --legacy-directory tests/tensor_object_oracle \
  --native-source build/integer-tensors/runtime.hepta \
  --observer-output build/frozen35-integer-node/544 \
  --observer-report build/pytorch-integer-tensors-frozen35.json \
  -- build/integer-tensors/tensor-integer-session build/pytorch-integer-tensors-frozen35-original.json \
  --owned-reference tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \
  --session-reference tests/pytorch_session_oracle.py --reference tests/pytorch_oracle.py \
  --lock compatibility/pytorch-oracle-lock.json --repo . \
  --trace-directory build/frozen35-integer-node-wire/544 \
  --expected-native-sha256 b7324639bade3312981d1cbf9c2491b9fcff04fb6c3f808e9c5e1a7c2ca88f08 || status=$?
if [ -f build/pytorch-integer-tensors-frozen35.json ]; then
  python3 -I -S -B tools/emit_ci_report.py build/pytorch-integer-tensors-frozen35.json
fi
if [ "$status" -eq 0 ]; then
  python3 -I -S -B tests/integer_frozen35_accounting/check_frozen35_accounted.py \
    --observer-report build/pytorch-integer-tensors-frozen35.json \
    --original-report build/pytorch-integer-tensors-frozen35-original.json
fi
exit "$status"

