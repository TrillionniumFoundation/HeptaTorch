echo '149b41c455444edeb8d25d0ad98045e29683e780f37f7e210e7985242d359597  tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py' | sha256sum -c -
status=0
python3 tests/mixed_frozen35_accounting/run_frozen35_accounted.py \
  --legacy-directory tests/tensor_object_oracle \
  --native-source build/mixed-integer-autograd/runtime.hepta \
  --observer-output build/frozen35-mixed-integer-node/556 \
  --observer-report build/pytorch-mixed-integer-autograd-frozen35.json \
  -- build/mixed-integer-autograd/tensor-mixed-autograd-session build/pytorch-mixed-integer-autograd-frozen35-original.json \
  --owned-reference tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \
  --session-reference tests/pytorch_session_oracle.py --reference tests/pytorch_oracle.py \
  --lock compatibility/pytorch-oracle-lock.json --repo . \
  --trace-directory build/frozen35-mixed-integer-node-wire/556 \
  --expected-native-sha256 69045063c00395d07fc6c0101ed1b8aba18376cb1daea54e0a01c2c5caeb49b6 || status=$?
if [ -f build/pytorch-mixed-integer-autograd-frozen35.json ]; then
  python3 -I -S -B tools/emit_ci_report.py build/pytorch-mixed-integer-autograd-frozen35.json
fi
if [ "$status" -eq 0 ]; then
  python3 -I -S -B tests/mixed_frozen35_accounting/check_frozen35_accounted.py \
    --observer-report build/pytorch-mixed-integer-autograd-frozen35.json \
    --original-report build/pytorch-mixed-integer-autograd-frozen35-original.json
fi
exit "$status"

