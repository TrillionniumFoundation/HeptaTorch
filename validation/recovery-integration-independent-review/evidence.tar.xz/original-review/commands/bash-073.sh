echo '554671168c7a4a408dc1e1df89a19db15c3efcefcf4ae1a300af1b6dcae40160  tests/pytorch_tensor_rng_backward_oracle.py' | sha256sum -c -
status=0
python3 tests/pytorch_tensor_rng_backward_oracle.py \
  --native build/integer-tensors/tensor-integer-session \
  --source build/integer-tensors/runtime.hepta \
  --expected-native-sha256 b7324639bade3312981d1cbf9c2491b9fcff04fb6c3f808e9c5e1a7c2ca88f08 \
  --expected-source-sha256 adf6cae67666273aa6fb77989080ca3b1e3632188d2d7956a6d8b71808787e62 \
  --repo . --output build/pytorch-integer-tensors-backward.json > build/pytorch-integer-tensors-backward.stdout || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-integer-tensors-backward.json
exit "$status"

