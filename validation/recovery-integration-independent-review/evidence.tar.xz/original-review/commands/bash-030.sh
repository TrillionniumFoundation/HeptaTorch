status=0
make test-native-dropout \
  HEPTA_SOURCE_ROOT="$GITHUB_WORKSPACE/.toolchain/hepta" \
  HEPTA_STACK_BUILD="$RUNNER_TEMP/hepta-stack-budget" \
  HEPTA_COMPILER="$RUNNER_TEMP/hepta-expanded/hia-native-compiler" || status=$?
if [ -f build/hosted-native-dropout-native.json ]; then
  python3 -I -S -B tools/emit_ci_report.py build/hosted-native-dropout-native.json
fi
exit "$status"

