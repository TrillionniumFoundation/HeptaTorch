status=0
make tensor-to-recovered HEPTA_STACK_BUILD="$RUNNER_TEMP/hepta-stack-budget" || status=$?
if [ -f build/tensor-to-recovered/build.json ]; then
  cp build/tensor-to-recovered/build.json build/tensor-to-recovered-build.json
  python3 -I -S -B tools/emit_ci_report.py build/tensor-to-recovered-build.json
fi
exit "$status"
