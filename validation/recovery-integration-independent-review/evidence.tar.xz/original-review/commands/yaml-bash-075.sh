echo '149b41c455444edeb8d25d0ad98045e29683e780f37f7e210e7985242d359597  tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py' | sha256sum -c -
status=0
python3 tests/tensor_object_oracle/pytorch_tensor_objects_oracle.py \
  build/adam-distributions/tensor-adam-distributions-session build/pytorch-adam-distributions-frozen35.json \
  --owned-reference tests/owned_tensor_oracle/pytorch_owned_tensor_oracle.py \
  --session-reference tests/pytorch_session_oracle.py --reference tests/pytorch_oracle.py \
  --lock compatibility/pytorch-oracle-lock.json --repo . \
  --expected-native-sha256 3fc59ab7ed9c32dd75ff440ef9bfbec31756f50edd77715d665bdac098cc3f22 || status=$?
python3 -I -S -B tools/emit_ci_report.py build/pytorch-adam-distributions-frozen35.json
exit "$status"
