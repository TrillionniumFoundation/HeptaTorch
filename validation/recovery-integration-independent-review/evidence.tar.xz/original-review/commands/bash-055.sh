echo '1192de6e175407756b01028278446067b22b70fe2d820f0045f6f5d623d46aa3  tests/pytorch_backward_release_probe.py' | sha256sum -c -
python3 tests/pytorch_backward_release_probe.py \
  --reference tests/pytorch_oracle.py --lock compatibility/pytorch-oracle-lock.json \
  --repo . --output build/pytorch-backward-release-observations.json
cat build/pytorch-backward-release-observations.json

