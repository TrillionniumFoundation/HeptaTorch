status=0
make test-tensor-to-recovered-copied18 || status=$?
if [ -f build/frozen35-tensor-to-node/614/copied-controls/report.json ]; then
  cp build/frozen35-tensor-to-node/614/copied-controls/report.json build/pytorch-tensor-to-recovered-observer-controls.json
  python3 -I -S -B tools/emit_ci_report.py build/pytorch-tensor-to-recovered-observer-controls.json
fi
exit "$status"
