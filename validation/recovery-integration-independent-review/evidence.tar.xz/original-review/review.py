import ast, difflib, hashlib, json, os, re, stat, subprocess, sys, traceback
from pathlib import Path
R=Path('/home/qian-qi/heptatorch-continuation-20261116/runs/to-view-recovery-integration-01/repo')
D=Path('/home/qian-qi/heptatorch-continuation-20261116/runs/differentiable-view-integration-independent-review-01')
ROOT=R.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
def record(p):
 b=p.read_bytes();s=p.stat()
 return {'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(s.st_mode)}
def write(p,x):
 p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def cmd(name,argv,input=None):
 x={'argv':argv,'cwd':str(R),'native_execution':False,'torch_execution':False}
 (D/'commands').mkdir(exist_ok=True)
 with (D/'commands'/(name+'.stdout')).open('xb') as out,(D/'commands'/(name+'.stderr')).open('xb') as err:
  p=subprocess.run(argv,cwd=R,input=input,stdout=out,stderr=err,timeout=45)
 x['returncode']=p.returncode
 x['stdout']=record(D/'commands'/(name+'.stdout'));x['stderr']=record(D/'commands'/(name+'.stderr'))
 write(D/'commands'/(name+'.json'),x)
 assert p.returncode==0,(name,p.returncode,(D/'commands'/(name+'.stderr')).read_text()[-3000:])
 return (D/'commands'/(name+'.stdout')).read_bytes()
report={'schema':'heptatorch.recovery-integration-independent-review.v1','status':'RUNNING','native_executions':0,'torch_executions':0,'pure_reference_41095_reexecuted':False,'repo_modified':False,'checks':[]}
inputs={}
try:
 rels=['Makefile','.github/workflows/native.yml',
  'tools/tensor_to_native_recovered/rebuild.py','tools/tensor_to_native_recovered/self_check.py',
  'tools/tensor_to_native_recovered/profile.json','tools/tensor_to_native_recovered/package-manifest.json',
  'tools/differentiable_view_recovered_v2/build.py','tools/differentiable_view_recovered_v2/parent_emitter.py',
  'tools/differentiable_view_recovered_v2/profile.json','tools/differentiable_view_recovered_v2/package-manifest.json',
  'tools/owned_optimizers/compact_functions.py','tools/native_dropout/compact_functions.py']
 rels += [str(p.relative_to(R)) for p in sorted((R/'tests/differentiable_view_native_review').rglob('*')) if p.is_file()]
 for rel in rels:
  p=R/rel; inputs[rel]=record(p);dst=D/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(p.read_bytes());os.chmod(dst,inputs[rel]['mode'])
 head=cmd('git-head',['/usr/bin/git','rev-parse','HEAD']).decode().strip()
 tree=cmd('git-tree',['/usr/bin/git','rev-parse','HEAD^{tree}']).decode().strip()
 assert head=='ec21a0eadcaccd2f799c74a2d62b550f8e3af7fe',(head,tree)
 report['base']={'head':head,'tree':tree}
 oldmake=cmd('git-base-make',['/usr/bin/git','show',head+':Makefile'])
 oldwf=cmd('git-base-workflow',['/usr/bin/git','show',head+':.github/workflows/native.yml'])
 nowmake=(R/'Makefile').read_bytes();nowwf=(R/'.github/workflows/native.yml').read_bytes()
 assert nowmake.startswith(oldmake),'existing Makefile prefix differs'
 report['make_original_exact_prefix']=True
 a,b=oldwf.decode().splitlines(keepends=True),nowwf.decode().splitlines(keepends=True)
 sm=difflib.SequenceMatcher(a=a,b=b,autojunk=False)
 operations=sm.get_opcodes()
 assert all(op in ('equal','insert') for op,*_ in operations),operations
 restored=''.join(''.join(b[j1:j2]) for op,i1,i2,j1,j2 in operations if op=='equal').encode()
 assert restored==oldwf
 inserted=[{'old_after_line':i1,'new_start_line':j1+1,'new_end_line':j2,'bytes':len(''.join(b[j1:j2]).encode()),'sha256':sha(''.join(b[j1:j2]).encode())} for op,i1,i2,j1,j2 in operations if op=='insert']
 write(D/'workflow-exact-inverse.json',{'original':{'bytes':len(oldwf),'sha256':sha(oldwf)},'current':{'bytes':len(nowwf),'sha256':sha(nowwf)},'only_insertions':True,'restored_sha256':sha(restored),'insertions':inserted})
 def blocks(t):
  starts=[m.start() for m in re.finditer(r'^      - name: ',t,re.M)]
  return [(t[s:(starts+[len(t)])[i+1]].splitlines()[0].split('name: ',1)[1],t[s:(starts+[len(t)])[i+1]]) for i,s in enumerate(starts)]
 oldblocks=blocks(oldwf.decode());newblocks=blocks(nowwf.decode())
 assert len(oldblocks)==99,len(oldblocks)
 oldnames=[n for n,_ in oldblocks];newnames=[n for n,_ in newblocks]
 assert len(set(newnames))==len(newnames)
 assert [n for n in newnames if n in set(oldnames)]==oldnames
 report['workflow']={'old_steps':len(oldblocks),'current_steps':len(newblocks),'added_steps':[n for n in newnames if n not in set(oldnames)],'whole_source_exact_inverse':True}
 runlist=[]
 lines=nowwf.decode().splitlines(keepends=True)
 for i,l in enumerate(lines):
  if l=='        run: |\n':
   j=i+1
   while j<len(lines) and (not lines[j].strip() or lines[j].startswith('          ')):j+=1
   script=''.join(x[10:] if x.startswith('          ') else x for x in lines[i+1:j])
   script=re.sub(r'\$\{\{.*?\}\}','GITHUB_EXPRESSION',script,flags=re.S)
   name='bash-%03d'%len(runlist)
   (D/'commands').mkdir(exist_ok=True);(D/'commands'/(name+'.sh')).write_text(script)
   cmd(name,['/usr/bin/bash','-n'],script.encode());runlist.append(i+1)
 report['bash_run_blocks_passed']=len(runlist)
 assert not re.search(r'\$\((?:shell|MAKE)\b|^\s*-?include\b',nowmake.decode(),re.M)
 targets=['check-tensor-to-recovered-source','tensor-to-recovered','test-tensor-to-recovered-tombstone','test-tensor-to-recovered-live32','test-tensor-to-recovered-frozen35','test-tensor-to-recovered-copied18','test-differentiable-view-reference14','differentiable-view-recovered','test-differentiable-view-native14']
 stack=ROOT/'runs/dview-r1-fixed-toolchain-cold-02/hepta-stack-budget'
 upstream=ROOT/'toolchain'
 for t in targets:
  cmd('make-'+t,['/usr/bin/make','-n',t,'HEPTA_STACK_BUILD='+str(stack),'HEPTA_SOURCE_ROOT='+str(upstream)])
 report['make_dry_run_targets']=targets
 for rel in rels:
  if rel.endswith('.py'): ast.parse((R/rel).read_bytes(),filename=rel)
 report['python_ast_files']=sum(r.endswith('.py') for r in rels)
 manifest=json.loads((R/'tests/differentiable_view_native_review/package-manifest.json').read_bytes())
 for item in manifest['files']:
  got=record(R/item['path']);assert all(got[k]==item[k] for k in ('bytes','sha256','mode')),(item['path'],got,item)
 report['reader_manifest_payloads']=len(manifest['files'])
 assert (R/'tools/owned_optimizers/compact_functions.py').read_bytes()==(R/'tools/native_dropout/compact_functions.py').read_bytes()
 assert inputs['tools/owned_optimizers/compact_functions.py']['sha256']=='36730b55b58c29b210d921a426c62eab50d9f579ad5d7a1e4199b38799218f37'
 report['compactor_exact_alias']=True
 cmd('reader-help',['/usr/bin/python3','-I','-S','-B',str(R/'tests/differentiable_view_native_review/replay_direct_view14.py'),'--help'])
 cmd('builder-help',['/usr/bin/python3','-B',str(R/'tools/differentiable_view_recovered_v2/build.py'),'--help'])
 cmd('self-check-help',['/usr/bin/python3','-S','-B',str(R/'tools/tensor_to_native_recovered/self_check.py'),'--help'])
 imp="import importlib.util,json,sys\nfrom pathlib import Path\np=Path("+repr(str(R/'tests/differentiable_view_native_review'))+")\ndef load(f,n):\n s=importlib.util.spec_from_file_location(n,p/f);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m\nr=load('replay_direct_view14.py','pure_reader');o=r.load_module(p/'native_observer_direct02.py','pure_observer');w=o.wire(p/'protocol.py');assert hasattr(w,'Session') and hasattr(w.transport,'OwnerSession');assert 'torch' not in sys.modules;print(json.dumps({'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dynamic_chain_loaded':True,'native_instances':0,'torch_imported':False}))\n"
 cmd('isolated-dynamic-import-chain',['/usr/bin/python3','-I','-S','-B','-c',imp])
 actual=ROOT/'runs/differentiable-view-native-r2-r3-first/observed/report.json'
 ar=json.loads(actual.read_bytes());assert sha(actual.read_bytes())=='0b987fcb1d7fb74fe8a6d1edb994bed53851f07acbc3dfe6af6f754489e598d4'
 ref=next(Path(p) for p,h in ar['inputs_sha256'].items() if h=='2270d5ba925bcf91c56db94fac663695e69079c74edbf80aff8fa086e7c81665')
 probe=next(Path(p) for p,h in ar['inputs_sha256'].items() if h=='1ca74384675f4f5bbe1b477be827e1d405bf3ca04bc3eeaa22e4628dfe0cc1ac')
 native=ROOT/'runs/differentiable-view-r2-native-build-01/candidate-r2'
 cmd('reader-prepare-only',['/usr/bin/python3','-I','-S','-B',str(R/'tests/differentiable_view_native_review/replay_direct_view14.py'),
 '--binary',str(native/'tensor-differentiable-view-session'),'--source',str(native/'runtime.hepta'),'--build-report',str(native/'build.json'),
 '--protocol',str(R/'tests/differentiable_view_native_review/protocol.py'),'--observer',str(R/'tests/differentiable_view_native_review/native_observer_direct02.py'),
 '--reference',str(ref),'--probe',str(probe),'--expected-source-sha256','197bd52db4815f575ea3e9055d3f5556900314bd2f4fbb262e80cea76ea16ef2',
 '--expected-native-sha256','13cee2163e8f62081db35e831885714789ac5117fb80c030a1ccaf7194e0821c','--expected-observer-sha256','1e9c197867cab126ec6022e4316505288ab79e63cccc95fc9ecec02f8c884814',
 '--output',str(D/'prepared-only'),'--prepare-only'])
 pr=json.loads((D/'prepared-only/report.json').read_bytes());assert pr['status']=='PREPARED_NOT_RUN' and pr['native_executed'] is False and pr['all_inputs_unchanged']
 report['reader_prepare_only']=record(D/'prepared-only/report.json')
 report['unit_shape_source_only']=[]
 for n in [native,ROOT/'runs/differentiable-view-r1-native-build-01/parent09b']:
  build=json.loads((n/'build.json').read_bytes())
  assert build['status']=='PASS' and build['descriptor_bytes']==672 and build['functions']==614 and len(build['units'])==12
  for u in build['units']:
   for suffix,key in [('.hepta','source_sha256'),('.o','object_sha256')]: assert sha((n/(u['name']+suffix)).read_bytes())==u[key]
  report['unit_shape_source_only'].append({'path':str(n),'build':record(n/'build.json'),'units':12,'sources_and_objects_rehashed':True})
 report['all_input_files_unchanged']=all(record(R/r)==v for r,v in inputs.items())
 assert report['all_input_files_unchanged']
 report['inputs']=inputs
 report['findings']=[{'severity':'documentation','file':'tests/differentiable_view_native_review/README.md','detail':'README recommends observer01; actual Make is source-bound to observer02. Frozen README must not be silently rewritten.'}]
 report['status']='PASS_SOURCE_CLI_PREPARE_ONLY'
except BaseException:
 report['status']='FAIL_REVIEW';report['primary_error']=traceback.format_exc()
 report['inputs']=inputs
finally:
 write(D/'report.json',report)
 print(json.dumps({'status':report['status'],'report':str(D/'report.json'),'sha256':sha((D/'report.json').read_bytes()),'error':report.get('primary_error'),'workflow':report.get('workflow'),'bash':report.get('bash_run_blocks_passed'),'new_native':0,'new_torch':0}))
sys.exit(0 if report['status']=='PASS_SOURCE_CLI_PREPARE_ONLY' else 1)
