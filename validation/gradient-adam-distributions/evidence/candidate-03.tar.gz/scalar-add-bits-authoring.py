def scalar_add_preserving_bits(a:u64, b:u64) -> u64:
    am = a & 2147483647
    bm = b & 2147483647
    if bm > 2139095040:
        return b | 4194304
    if am > 2139095040:
        return a | 4194304
    if am == 2139095040 and bm == 2139095040 and ((a ^ b) & 2147483648) != 0:
        return 4290772992
    return addf(a,b)
