import ast,hashlib,json,re,subprocess
from pathlib import Path
R=Path("/home/qian-qi/heptatorch-continuation-20261116")
old=R/'runs/differentiable-view-r4-scalar-source-06'
new=R/'runs/differentiable-view-r4-scalar-source-07b'
out=R/'runs/differentiable-view-r4-scalar-prepare-07b'
sha=lambda b:hashlib.sha256(b).hexdigest()
pins={
'scalar_math.py':'b410bef7152009f98d58559598e223dfe0d0f84cbd0fc91a66e9f5a0354707f0',
'scalar_runtime.py':'939f12b65d88142971905d04d3f6a757e4854540637601fb1b7903a1ded92ad6',
'scalar_overlay.py':'af5ef899fdcef9951a68687aa8040be65746918b10a4b791c8c0582c09ac5a62',
'build.py':'9a5e9289bc5bed80c6f6babd4a9f380e888fc4eeac32b99f7ffafa42e79053af',
'parent_emitter.py':'bfe574ded8f30000e52b99425682c2d908d92c3e729c792f898d15a803815290',
'authoring_support.py':'805c3de5cf9ae94cb7dd1c1ed2c53933f2213bcabea69a979318ffe2d61a39f4',
'DESIGN.md':'992e126788218dfc78bf52b10d4b1f4206d9d7e6eda365886d38a4583c53dc95',
'PROTOCOL.md':'4688bbaa2962c43ce29ce6037058cff49f012d214c1dbaeae77a0b2b921e80db'}
raw={n:(old/n).read_bytes() for n in pins}
for n,b in raw.items():assert sha(b)==pins[n],(n,sha(b))
assert not new.exists() and not out.exists()
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a))
 return s.replace(a,b,1)
addition="def incoming_describe(w: mutbuf, source: u64, parent: u64, side: u64) -> u64:\n    described=scalar_previous_incoming_describe(w,source,parent,side)\n    if described==0 or side!=0:\n        return described\n    p=dptr(w,source)\n    other=getw(w,p+56)\n    if getw(w,p+40)!=3 or other==0:\n        return described\n    if tensor_dtype(w,other)!=3:\n        return described\n    if incoming_same_shape(w,source,parent)==0:\n        return terror(w,9)\n    memory_fill(w,3808,88,0)\n    putw(w,3840,parent)\n    putw(w,3848,2)\n    incoming_contiguous_layout(w,parent,3856)\n    order=retained_axis_order(w,source,other)\n    inverted=1\n    axis_position=0\n    while axis_position<getw(w,p):\n        axis=(order>>(8*axis_position))&255\n        if axis!=getw(w,p)-1-axis_position:\n            inverted=0\n        axis_position=axis_position+1\n    if inverted!=0:\n        return 1\n    stride=1\n    axis_position=0\n    while axis_position<getw(w,p):\n        axis=(order>>(8*axis_position))&255\n        putw(w,3856+8*axis,stride)\n        stride=stride*getw(w,p+96+8*axis)\n        axis_position=axis_position+1\n    return 1\n\ndef incoming_mark_preserve_targets(w: mutbuf, root: u64, epoch: u64) -> u64:\n    if scalar_previous_incoming_mark_preserve_targets(w,root,epoch)==0:\n        return 0\n    source=1\n    while source<=root:\n        p=dptr(w,source)\n        if getw(w,p+304)!=0 and getw(w,p+168)==epoch and getw(w,p+40)==3 and getw(w,p+8)!=0:\n            other=getw(w,p+56)\n            if other!=0 and tensor_dtype(w,other)==3:\n                parent=gradient_parent_at(w,source,0)\n                if parent!=0:\n                    q=dptr(w,parent)\n                    if getw(w,q+304)==0 or getw(w,q+168)!=epoch:\n                        return terror(w,9)\n                    putw(w,q+544,1)\n        source=source+1\n    return 1\n"
raw07=dict(raw)
raw07['scalar_runtime.py']=raw['scalar_runtime.py']+b'\n'+addition.encode()
o=raw['scalar_overlay.py'].decode();edits=[]
def edit(a,b):
 global o
 o=once(o,a,b);edits.append((a,b))
edit("RUNTIME_SHA='"+pins['scalar_runtime.py']+"'","RUNTIME_SHA='"+sha(raw07['scalar_runtime.py'])+"'")
edit("      'back_binary':'scalar_previous_back_binary',\n","      'back_binary':'scalar_previous_back_binary',\n      'incoming_describe':'scalar_previous_incoming_describe',\n      'incoming_mark_preserve_targets':'scalar_previous_incoming_mark_preserve_targets',\n")
edit('assert len(emitted)==19','assert len(emitted)==21')
patch="""    before=original['retained_apply']
    old_call=b'  v220:u64 = call(v219,v209) {"function":"addf"}\\n'
    new_call=b'  v220:u64 = call(v219,v209) {"function":"scalar_add_preserving_bits"}\\n'
    assert sha(original['scalar_add_preserving_bits'])=='b9d272f526920879e66970641f60cfcc0fc1d71aaf3c285e2781a5a909c6a436'
    body=once(before,old_call,new_call)
    assert once(body,new_call,old_call)==before
    combined['retained_apply']=body
    receipts.append({'kind':'retained-ieee-addition','function':'retained_apply',
        'parent_sha256':sha(before),'sha256':sha(body),'exact_inverse':True,
        'old':old_call.decode(),'new':new_call.decode(),'global_addf_unchanged':True})
"""
edit("    changed={n for n in original if original[n]!=combined[n]}\n",patch+"    changed={n for n in original if original[n]!=combined[n]}\n")
edit("assert changed==replacements|{'so_audit_records','entry','init_state','state_header','so_state_init','so_state_header'}","assert changed==replacements|{'retained_apply','so_audit_records','entry','init_state','state_header','so_state_init','so_state_header'}")
raw07['scalar_overlay.py']=o.encode()
raw07['DESIGN.md']+="\n\n## Source07: true wrapped-scalar backward layout and retained IEEE addition\n\nSource06 remains an overall FAIL: its unchanged full26 reader reports 24 PASS and\n2 FAIL (afe47e394b3334f22f503e606f806e6abc8b3eef32ad5c5884cb3051d0dec598), while\nfixed32 passes only that independent domain (21b0d01fc77ffdb7f503aa43575076c047e21a73f2d60b18c219fbbdae92c1f8).\nAll 26 source06 sessions exited zero; its original numerical/Version failures and\nthe separately diagnosed raw-address lifetime collision are preserved.\n\nThe old op3 incoming description unconditionally declared a fresh contiguous\nlayout. For an actual wrapped-F64 scalar multiply, grad * scalar is a real\npointwise result. Its layout follows the incoming gradient operand, with the\nrank-zero scalar contributing broadcast-zero strides. The new description is\nrestricted to op3, the original right operand dtype3, and the first AD edge. It\nuses the existing signed byte-stride TensorIterator ordering helper on the real\nincoming strides and real rank-zero scalar, creates dense output strides, and\nsets a fresh zero-offset incoming Storage description. An inverted axis permutation uses the existing contiguous layout; otherwise\ncompatible strides multiply each actual dimension, including zero. This follows\nTensorIterator allocate_or_resize_outputs rather than special-casing all empty\nTensors as contiguous. No recorded reference dimension or expected\nVersion is used to choose a branch.\n\nThe preflight wrapper marks this AD parent for actual private preserve allocation.\nExisting incoming_construct materializes the computed logical gradient into that\nreal physical layout, through the original allocation/trim/scatter/cleanup path.\nAccumulateGrad then naturally tests its existing layout contract: a transposed\nincoming gradient for a contiguous dense leaf goes through the existing fresh\nclone/copy path and its real Version increment. Neither Version values nor\npublic gradient IDs are directly overwritten by this revision.\n\nThe existing retained hook creates a fresh gradient on repeated use, matching\nfixed variable.cpp. Its one addition call now uses the already frozen\nscalar_add_preserving_bits primitive (b9d272f526920879e66970641f60cfcc0fc1d71aaf3c285e2781a5a909c6a436).\nThis preserves/quietens IEEE NaN sign and payload, gives the fixed negative NaN\nfor opposite infinities, and delegates ordinary finite addition to unchanged\naddf. The helper and global addf/mulf/divf bodies remain byte-identical; no seed,\ncase number, or expected output constant controls the retained call site.\n\nThe actual reference's released Saved float64 allocations can have their raw\nTensorImpl/StorageImpl addresses reused by later float32 gradients. This is an\nindependent comparison-lifetime issue under root review; production never\nrecycles an incarnation or changes retained allocation to chase an opaque address.\nThe source preparation runs no native semantic test or Torch. Public commands,\nowner layout, 672-byte descriptors and existing format tags remain unchanged.\n".encode()
inverse=o
for a,b in reversed(edits):inverse=once(inverse,b,a)
assert inverse.encode()==raw['scalar_overlay.py']
assert raw07['scalar_runtime.py'][:-len(addition.encode())-1]==raw['scalar_runtime.py']
for n,b in raw07.items():
 if n.endswith('.py'):ast.parse(b,filename=n)
new.mkdir()
for n,b in raw07.items():(new/n).write_bytes(b)
(new/'source06-to07b-inverse.json').write_text(json.dumps({'schema':'heptatorch.scalar07b.authoring-inverse.v1','files':[{'path':n,'before_sha256':sha(raw[n]),'after_sha256':sha(b),'unchanged':raw[n]==b,**({'before_hex':raw[n].hex(),'after_hex':b.hex()} if raw[n]!=b else {})} for n,b in raw07.items()],'runtime_append':addition,'overlay_edits':[{'before':a,'after':b} for a,b in edits],'exact_inverse':True,'native_executed':False,'torch_executed':False},indent=2)+'\n')
(new/'prepared07-source-only-history.json').write_text(json.dumps({
 'status':'SOURCE07_PREPARED_NOT_COMPILED',
 'source07_sha256':'c60cee1678a043ec119961275b8c5f68680ba61eca84fc8d8803be9814f1712b',
 'source07_directory':str(R/'runs/differentiable-view-r4-scalar-source-07'),
 'reason':'Fixed TensorIterator allocate_or_resize_outputs keeps default contiguous strides only for inverted permutation; other permutations use compatible_stride including zero dimensions.',
 'source07_native_or_compiler_started':False,
 'official_source_path':str(R/'runs/r4-scalar07-TensorIterator-a71a7e.cpp'),
 'official_source_sha256':'a71a7ec9ba0532bf1380aa8ebc92975e4acb31414cd4b8eeeba650afe9e4490c',
 'runtime_source07_to07b_before':"    if getw(w,p+8)==0:\n        return 1\n    order=retained_axis_order(w,source,other)\n    stride=1\n",
 'runtime_source07_to07b_after':"    order=retained_axis_order(w,source,other)\n    inverted=1\n    axis_position=0\n    while axis_position<getw(w,p):\n        axis=(order>>(8*axis_position))&255\n        if axis!=getw(w,p)-1-axis_position:\n            inverted=0\n        axis_position=axis_position+1\n    if inverted!=0:\n        return 1\n    stride=1\n"
},indent=2)+'\n')
(new/'source-inputs.json').write_text(json.dumps({'status':'AUTHOR_SOURCE_PREPARED_NOT_EMITTED','files':[{'path':str(new/n),'bytes':len(b),'sha256':sha(b)} for n,b in raw07.items()],'native_executed':False,'torch_executed':False},indent=2)+'\n')
cmd=json.loads((old/'prepare-command.json').read_text())
cmd['argv'][2]=str(new/'build.py');cmd['argv'][cmd['argv'].index('--output')+1]=str(out)
(new/'prepare-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
result=subprocess.run(cmd['argv'],cwd=cmd['cwd'],capture_output=True,timeout=300)
(new/'prepare.stdout').write_bytes(result.stdout);(new/'prepare.stderr').write_bytes(result.stderr)
unchanged=all((new/n).read_bytes()==b and (old/n).read_bytes()==raw[n] for n,b in raw07.items())
(new/'prepare-execution.json').write_text(json.dumps({'argv':cmd['argv'],'cwd':cmd['cwd'],'returncode':result.returncode,'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr),'inputs_unchanged':unchanged,'native_executed':False,'torch_executed':False},indent=2)+'\n')
assert unchanged
if result.returncode:
 print(result.stdout.decode(errors='replace'));print(result.stderr.decode(errors='replace'));raise SystemExit(result.returncode)
fn=lambda b:{m[1].decode():m[0] for m in re.finditer(rb'^fn ([A-Za-z0-9_]+)\(.*?^end\n',b,re.M|re.S)}
parent=(R/'runs/differentiable-view-r4-scalar06-native-build-01/candidate-r4-scalar06/runtime.hepta').read_bytes()
assert sha(parent)=='743c6de8c4f2e9ea6dbb880aca5a27c719c2b14ce05e7262020ece63b1ccd148'
current=(out/'runtime.hepta').read_bytes();oldfn,newfn=fn(parent),fn(current)
changed=[n for n in oldfn if oldfn[n]!=newfn[n]]
added=sorted(set(newfn)-set(oldfn))
assert set(changed)=={'retained_apply','incoming_describe','incoming_mark_preserve_targets'},changed
assert added==['scalar_previous_incoming_describe','scalar_previous_incoming_mark_preserve_targets'],added
diff={'source06_sha256':sha(parent),'source07b_sha256':sha(current),'unchanged_functions':len(oldfn)-len(changed),'changed':changed,'added':added,'source06_functions':len(oldfn),'source07b_functions':len(newfn),'details':[{'name':n,'before_sha256':sha(oldfn[n]),'after_sha256':sha(newfn[n]),'before_hex':oldfn[n].hex(),'after_hex':newfn[n].hex()} for n in changed],'native_executed':False,'torch_executed':False}
(new/'prepared-source-diff.json').write_text(json.dumps(diff,indent=2)+'\n')
report=json.loads((out/'build.json').read_text())
print(json.dumps({'source':str(new),'prepared':str(out),'files':[{ 'path':n,'sha256':sha(b),'bytes':len(b)}for n,b in raw07.items()],'source_sha256':report['source_sha256'],'functions':report['functions'],'blocks':report['blocks'],'instructions':report['instructions'],'units_planned':report['units_planned'],'changed':changed,'added':added,'native_executed':False},indent=2))
