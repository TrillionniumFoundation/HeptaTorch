def entry(s: readbuf, o: mutbuf, w: mutbuf, scratch: mutbuf) -> u32:
    if length(o) < 32:
        return 0
    reply_error(o, 0)
    error = frame_valid(s)
    if error != 0:
        reply_error(o, error)
        return 32
    putw(w, 0, 0)
    putw(w, 48, 0)
    putw(w, 56, 0)
    count = getr(s, 8)
    if count != 0:
        putw(w, 96, 8192)
    end = 32 + count * 64
    i = 0
    at = 32
    halted = 0
    while i < count and halted == 0:
        if at > length(o) - 32:
            putw(o, 24, 3)
            return at
        putw(w, 104, i)
        code = getr(s, 32 + i * 64)
        if code >= 60 and code <= 69:
            next = rng_command(s, o, w, scratch, 32 + i * 64, at, end)
        elif code >= 80 and code <= 89:
            if code == 86 or code == 87:
                next = dist_partial_command(s,o,w,scratch,32+i*64,at)
            else:
                next = dist_command(s,o,w,scratch,32+i*64,at)
        else:
            next = command(s, o, w, 32 + i * 64, at, end)
        error = getw(w, 0)
        if error != 0:
            putw(o, 24, error)
            return next
        putw(w, getw(w, 96) + i * 8, getw(o, at + 16))
        if (code == 58 or code == 86 or code == 87) and getw(o, at + 16) != 0:
            halted = 1
        at = next
        i = i + 1
        putw(o, 16, i)
    if count != 0:
        fill_range(w, 8192, count * 8, 0)
        putw(w, 96, 0)
        putw(w, 104, 0)
    putw(w, 80, 0)
    if getw(w, 0) != 0:
        reply_error(o, getw(w, 0))
        return 32
    return at

def dist_partial_fill(w: mutbuf, scratch: mutbuf, t: u64, probability: u64, data: u64, o: mutbuf, info: u64) -> u64:
    p = dptr(w,t)
    q = dptr(w,probability)
    n = getw(w,p+8)
    if n == 0:
        return 0
    rng_load_scratch(w,scratch,data)
    order = dist_pair_order(w,p,q)
    i = 0
    error = 0
    while i < n and error == 0:
        bound = get4(w,dist_probability_address(w,p,q,order,i))
        if dist_prob32_valid(bound) == 0:
            error = 7
        else:
            bound = bound & 2147483647
            unit = rng_unit32(rng_next(scratch))
            value = 0
            if unit < bound:
                value = 1065353216
            put4(w,rng_iteration_address(w,p,order,i),value)
            i = i+1
    rng_save_scratch(w,scratch,data)
    putw(o,info+16,i)
    putw(o,info+24,i)
    return error

def dist_partial_bernoulli(w: mutbuf, scratch: mutbuf, o: mutbuf, info: u64, id: u64, generator: u64, probability: u64, no_grad: u64) -> u64:
    t = public_node(w,id)
    source = public_node(w,probability)
    data = rng_object(w,generator)
    if t == 0 or source == 0 or data == 0:
        return 0
    p = dptr(w,t)
    q = dptr(w,source)
    if no_grad > 1:
        return terror(w,7)
    if no_grad == 0 and (getw(w,p+32) != 0 or getw(w,q+32) != 0):
        return terror(w,5)
    if getw(w,p+8) > 1000000:
        return terror(w,3)
    if version_can_bump(w,t,1) == 0 or dist_probability_admit(w,t,source) == 0:
        return 0
    putw(o,info+8,getw(w,p+192))
    error = dist_partial_fill(w,scratch,t,source,data,o,info)
    if error == 0:
        bump_version(w,t)
    return error

def dist_partial_noise(w: mutbuf, scratch: mutbuf, t: u64, data: u64, probability: u64) -> u64:
    p = dptr(w,t)
    noise = 0
    if probability == 4607182418800017408:
        noise = tnew(w,0,p+96,0)
        if noise == 0:
            return 0
        put4(w,taddr(w,noise,0),0)
    else:
        noise = tnew(w,getw(w,p),p+96,0)
        if noise == 0:
            return 0
        dist_dense_layout(w,noise,t,1)
        complement = dist_complement64(probability)
        scale = divf(1065353216,dist_probability_to32(complement))
        if dist_fill_scalar(w,scratch,noise,data,complement,scale) == 0:
            return 0
    bump_version(w,noise)
    bump_version(w,noise)
    return noise

def dist_partial_dropout_write(w: mutbuf, t: u64, noise: u64) -> u64:
    p = dptr(w,t)
    q = dptr(w,noise)
    order = dist_pair_order(w,p,q)
    i = 0
    while i < getw(w,p+8):
        destination = rng_iteration_address(w,p,order,i)
        mask_address = dist_probability_address(w,p,q,order,i)
        put4(w,destination,mulf(get4(w,destination),get4(w,mask_address)))
        i = i+1
    return bump_version(w,t)

def dist_partial_dropout(w: mutbuf, scratch: mutbuf, o: mutbuf, info: u64, id: u64, generator: u64, probability: u64, training: u64, no_grad: u64) -> u64:
    t = public_node(w,id)
    data = rng_object(w,generator)
    if t == 0 or data == 0:
        return 0
    if no_grad > 1 or training > 1 or dist_prob64_valid(probability) == 0:
        return terror(w,7)
    p = dptr(w,t)
    probability = probability & 9223372036854775807
    n = getw(w,p+8)
    putw(o,info+8,getw(w,p+192))
    if probability == 0 or training == 0 or n == 0:
        return 0
    if n > 1000000:
        return terror(w,3)
    tracked = 0
    if no_grad == 0 and getw(w,p+32) != 0:
        if getw(w,p+40) != 0:
            return terror(w,5)
        tracked = 1
    if tracked == 0 and version_can_bump(w,t,1) == 0:
        return 0
    noise = dist_partial_noise(w,scratch,t,data,probability)
    if noise == 0:
        return 0
    if probability != 4607182418800017408:
        putw(o,info+24,n*2)
    if tracked != 0:
        return 5
    if dist_no_internal_overlap(w,t) == 0:
        error = getw(w,0)
        if error == 2:
            putw(w,0,0)
            return 2
        return 0
    if dist_partial_dropout_write(w,t,noise) == 0:
        return 0
    putw(o,info+16,n)
    return 0

def dist_partial_command(s: readbuf, o: mutbuf, w: mutbuf, scratch: mutbuf, cp: u64, at: u64) -> u64:
    code = getr(s,cp)
    a = getr(s,cp+8)
    b = getr(s,cp+16)
    c = getr(s,cp+24)
    d = getr(s,cp+32)
    e = getr(s,cp+40)
    first = getw(w,8)
    result = 0
    payload = 0
    if code != 86 and code != 87:
        terror(w,4)
    if getr(s,cp+48) != 0 or getr(s,cp+56) != 0:
        terror(w,7)
    if code == 86 and e != 0:
        terror(w,7)
    if length(o)-at-32 < 32:
        terror(w,3)
    if getw(w,0) == 0:
        putw(o,at+32,0)
        putw(o,at+40,0)
        putw(o,at+48,0)
        putw(o,at+56,0)
        if code == 86:
            result = dist_partial_bernoulli(w,scratch,o,at+32,a,b,c,d)
        if code == 87:
            result = dist_partial_dropout(w,scratch,o,at+32,a,b,c,d,e)
        if getw(w,0) == 0:
            finish_command(w,first)
            putw(o,at+32,result)
            payload = 32
    status = getw(w,0)
    if status != 0:
        result = 0
        payload = 0
    putw(o,at,code)
    putw(o,at+8,status)
    putw(o,at+16,result)
    putw(o,at+24,payload)
    return at+32+payload
