def entry(s: readbuf, o: mutbuf, w: mutbuf, scratch: mutbuf) -> u32:
    if length(o) < 32:
        return 0
    reply_error(o, 0)
    error = frame_valid(s)
    if error != 0:
        reply_error(o, error)
        return 32
    putw(w, 0, 0)
    putw(w, 48, 0)
    putw(w, 56, 0)
    count = getr(s, 8)
    if count != 0:
        putw(w, 96, 8192)
    end = 32 + count * 64
    i = 0
    at = 32
    halted = 0
    while i < count and halted == 0:
        if at > length(o) - 32:
            putw(o, 24, 3)
            return at
        putw(w, 104, i)
        code = getr(s, 32 + i * 64)
        if code >= 60 and code <= 69:
            next = rng_command(s, o, w, scratch, 32 + i * 64, at, end)
        else:
            if code >= 80 and code <= 89:
                next = dist_command(s,o,w,scratch,32+i*64,at)
            else:
                next = command(s,o,w,32+i*64,at,end)
        error = getw(w, 0)
        if error != 0:
            putw(o, 24, error)
            return next
        putw(w, getw(w, 96) + i * 8, getw(o, at + 16))
        if getr(s, 32 + i * 64) == 58 and getw(o, at + 16) != 0:
            halted = 1
        at = next
        i = i + 1
        putw(o, 16, i)
    if count != 0:
        fill_range(w, 8192, count * 8, 0)
        putw(w, 96, 0)
        putw(w, 104, 0)
    putw(w, 80, 0)
    if getw(w, 0) != 0:
        reply_error(o, getw(w, 0))
        return 32
    return at

def gradient_direct(w: mutbuf, t: u64, parent: u64) -> u64:
    p = dptr(w, t)
    op = getw(w, p + 40)
    if op >= 1 and op <= 4:
        q = dptr(w, parent)
        rank = getw(w, p)
        if getw(w, q) != rank:
            return 0
        j = 0
        while j < rank:
            if getw(w, p + 96 + j * 8) != getw(w, q + 96 + j * 8):
                return 0
            j = j + 1
        return 1
    if op >= 5 and op <= 21:
        return 1
    if op >= 37 and op <= 41:
        return 1
    return 0

def partial_apply_node(w: mutbuf, t: u64) -> u64:
    p = dptr(w, t)
    op = getw(w, p + 40)
    if op == 0:
        present = getw(w, p + 360)
        j = 0
        n = getw(w, p + 8)
        dst = getw(w, p + 24)
        src = getw(w, p + 160)
        while j < n:
            value = get4(w, src + j * 4)
            if present != 0:
                value = addf(get4(w, dst + j * 4), value)
            put4(w, dst + j * 4, value)
            j = j + 1
        putw(w, p + 360, 1)
    if op >= 1 and op <= 4:
        back_binary(w, t)
    if op == 5 or op == 6 or op == 10 or (op >= 11 and op <= 17):
        back_unary(w, t)
    if op == 7 or op == 8:
        back_reduce(w, t)
    if op == 18 or op == 19:
        back_axis(w, t)
    if op == 20 or op == 21:
        back_softmax(w, t)
    if op >= 22 and op <= 24:
        back_spatial(w, t)
    if op == 25:
        back_matmul(w, t)
    if op == 26:
        back_index_select(w, t)
    if op == 27:
        back_gather(w, t)
    if op == 37 or op == 38:
        back_concat(w, t)
    if op == 39 or op == 40:
        back_indexed_add(w, t)
    if op == 41:
        dist_backward_bernoulli(w,t)
    return choose(getw(w, 0) == 0, 1, 0)

def dist_prob64_valid(p: u64) -> u64:
    magnitude = p & 9223372036854775807
    if magnitude > 4607182418800017408:
        return 0
    if p >> 63 != 0 and magnitude != 0:
        return 0
    return 1

def dist_prob32_valid(p: u64) -> u64:
    if p > 4294967295:
        return 0
    magnitude = p & 2147483647
    if magnitude > 1065353216:
        return 0
    if p >> 31 != 0 and magnitude != 0:
        return 0
    return 1

def dist_complement64(p: u64) -> u64:
    p = p & 9223372036854775807
    if p == 0:
        return 4607182418800017408
    if p == 4607182418800017408:
        return 0
    exponent = p >> 52
    significand = (p & 4503599627370495) | 4503599627370496
    removed = 0
    if exponent >= 1022:
        removed = significand
    else:
        if exponent >= 969:
            shift = 1022-exponent
            removed = significand >> shift
            remainder = significand & ((1 << shift)-1)
            midpoint = 1 << (shift-1)
            if remainder > midpoint or (remainder == midpoint and (removed & 1) != 0):
                removed = removed+1
    value = 9007199254740992-removed
    if value == 9007199254740992:
        return 4607182418800017408
    highest = 0
    temp = value
    while temp > 1:
        highest = highest+1
        temp = temp >> 1
    significand = value << (52-highest)
    return ((highest+970) << 52) | (significand & 4503599627370495)

def dist_probability_to32(p: u64) -> u64:
    exponent = p >> 52
    significand = (p & 4503599627370495) | 4503599627370496
    result = significand >> 29
    remainder = significand & 536870911
    if remainder > 268435456 or (remainder == 268435456 and (result & 1) != 0):
        result = result+1
    if result == 16777216:
        result = result >> 1
        exponent = exponent+1
    return ((exponent-896) << 23) | (result & 8388607)

def dist_no_internal_overlap(w: mutbuf, t: u64) -> u64:
    p = dptr(w,t)
    if getw(w,p+8) == 0:
        return 1
    i = 0
    while i < getw(w,p):
        if getw(w,p+96+i*8) > 1 and getw(w,p+128+i*8) == 0:
            return terror(w,2)
        i = i+1
    return 1

def dist_dense_layout(w: mutbuf, output: u64, source: u64, preserve: u64) -> u64:
    p = dptr(w,source)
    q = dptr(w,output)
    rank = getw(w,p)
    if preserve != 0 and is_dense(w,source) != 0:
        j = 0
        while j < rank:
            putw(w,q+128+j*8,getw(w,p+128+j*8))
            j = j+1
    else:
        order = rng_axis_order(w,p)
        stride = 1
        j = 0
        while j < rank:
            axis = (order >> (j*8)) & 255
            putw(w,q+128+axis*8,stride)
            dim = getw(w,p+96+axis*8)
            if dim > 1:
                stride = stride*dim
            j = j+1
    return 1

def dist_fill_scalar(w: mutbuf, scratch: mutbuf, t: u64, data: u64, probability: u64, scale: u64) -> u64:
    p = dptr(w,t)
    n = getw(w,p+8)
    if n == 0:
        return 1
    rng_load_scratch(w,scratch,data)
    order = rng_axis_order(w,p)
    probability = probability & 9223372036854775807
    i = 0
    while i < n:
        value = 0
        unit = rng_unit64(rng_next64(scratch))
        if unit < probability:
            value = scale
        put4(w,rng_iteration_address(w,p,order,i),value)
        i = i+1
    return rng_save_scratch(w,scratch,data)

def dist_bernoulli_scalar(w: mutbuf, scratch: mutbuf, id: u64, generator: u64, probability: u64, no_grad: u64) -> u64:
    t = public_node(w,id)
    data = rng_object(w,generator)
    if t == 0 or data == 0:
        return 0
    p = dptr(w,t)
    if no_grad > 1 or dist_prob64_valid(probability) == 0:
        return terror(w,7)
    if no_grad == 0 and getw(w,p+32) != 0:
        return terror(w,5)
    if getw(w,p+8) > 1000000:
        return terror(w,3)
    if version_can_bump(w,t,1) == 0 or dist_no_internal_overlap(w,t) == 0:
        return 0
    dist_fill_scalar(w,scratch,t,data,probability,1065353216)
    bump_version(w,t)
    return getw(w,p+192)

def dist_probability_stride(w: mutbuf, out: u64, prob: u64, axis: u64) -> u64:
    rank = getw(w,out)
    prank = getw(w,prob)
    if axis+prank < rank:
        return 0
    source_axis = axis+prank-rank
    if getw(w,prob+96+source_axis*8) == 1 and getw(w,out+96+axis*8) != 1:
        return 0
    return getw(w,prob+128+source_axis*8)

def dist_pair_order(w: mutbuf, p: u64, q: u64) -> u64:
    rank = getw(w,p)
    perm = 0
    i = 0
    while i < rank:
        perm = perm | ((rank-i-1) << (i*8))
        i = i+1
    i = 1
    while i < rank:
        anchor = i
        j = i
        done = 0
        while j > 0 and done == 0:
            j = j-1
            left = (perm >> (j*8)) & 255
            right = (perm >> (anchor*8)) & 255
            operand = 0
            comparison = 0
            while operand < 2 and comparison == 0:
                ls = getw(w,p+128+left*8)
                rs = getw(w,p+128+right*8)
                if operand == 1:
                    ls = dist_probability_stride(w,p,q,left)
                    rs = dist_probability_stride(w,p,q,right)
                if ls != 0 and rs != 0:
                    if ls < rs:
                        comparison = 1
                    if ls > rs or (ls == rs and getw(w,p+96+left*8) > getw(w,p+96+right*8)):
                        comparison = 2
                operand = operand+1
            if comparison == 2:
                difference = left ^ right
                perm = perm ^ (difference << (j*8)) ^ (difference << (anchor*8))
                anchor = j
            if comparison == 1:
                done = 1
        i = i+1
    return perm

def dist_probability_address(w: mutbuf, out: u64, prob: u64, order: u64, index: u64) -> u64:
    offset = 0
    j = 0
    while j < getw(w,out):
        axis = (order >> (j*8)) & 255
        dim = getw(w,out+96+axis*8)
        coordinate = index % dim
        index = index // dim
        offset = offset+coordinate*dist_probability_stride(w,out,prob,axis)
        j = j+1
    return getw(w,prob+16)+offset*4

def dist_probability_admit(w: mutbuf, t: u64, probability: u64) -> u64:
    p = dptr(w,t)
    q = dptr(w,probability)
    rank = getw(w,p)
    prank = getw(w,q)
    n = getw(w,p+8)
    if n == 0:
        return 1
    if prank > rank:
        return terror(w,2)
    j = 0
    while j < prank:
        dim = getw(w,q+96+j*8)
        if dim != 1 and dim != getw(w,p+96+(j+rank-prank)*8):
            return terror(w,2)
        j = j+1
    if dist_no_internal_overlap(w,t) == 0:
        return 0
    if t == probability or getw(w,p+216) != getw(w,q+216):
        return 1
    if is_dense(w,t) == 0 or is_dense(w,probability) == 0 or n != getw(w,q+8):
        return 1
    first = getw(w,p+16)
    second = getw(w,q+16)
    if first == second:
        j = 0
        while j < rank:
            if getw(w,p+128+j*8) != dist_probability_stride(w,p,q,j):
                return terror(w,2)
            j = j+1
    else:
        if first < second+n*4 and second < first+n*4:
            return terror(w,2)
    return 1

def dist_fill_probability(w: mutbuf, scratch: mutbuf, t: u64, probability: u64, data: u64) -> u64:
    p = dptr(w,t)
    q = dptr(w,probability)
    n = getw(w,p+8)
    if n == 0:
        return 1
    rng_load_scratch(w,scratch,data)
    order = dist_pair_order(w,p,q)
    i = 0
    while i < n:
        bound = get4(w,dist_probability_address(w,p,q,order,i))
        if dist_prob32_valid(bound) == 0:
            return terror(w,7)
        bound = bound & 2147483647
        value = 0
        unit = rng_unit32(rng_next(scratch))
        if unit < bound:
            value = 1065353216
        put4(w,rng_iteration_address(w,p,order,i),value)
        i = i+1
    return rng_save_scratch(w,scratch,data)

def dist_bernoulli_tensor(w: mutbuf, scratch: mutbuf, id: u64, generator: u64, probability: u64, no_grad: u64) -> u64:
    t = public_node(w,id)
    source = public_node(w,probability)
    data = rng_object(w,generator)
    if t == 0 or source == 0 or data == 0:
        return 0
    p = dptr(w,t)
    q = dptr(w,source)
    if no_grad > 1:
        return terror(w,7)
    if no_grad == 0 and (getw(w,p+32) != 0 or getw(w,q+32) != 0):
        return terror(w,5)
    if getw(w,p+8) > 1000000:
        return terror(w,3)
    if version_can_bump(w,t,1) == 0 or dist_probability_admit(w,t,source) == 0:
        return 0
    if dist_fill_probability(w,scratch,t,source,data) == 0:
        return 0
    bump_version(w,t)
    return getw(w,p+192)

def dist_bernoulli_functional(w: mutbuf, scratch: mutbuf, probability: u64, generator: u64, no_grad: u64) -> u64:
    source = public_node(w,probability)
    data = rng_object(w,generator)
    if source == 0 or data == 0:
        return 0
    if no_grad > 1:
        return terror(w,7)
    q = dptr(w,source)
    if getw(w,q+8) > 1000000:
        return terror(w,3)
    requires = 0
    if no_grad == 0:
        requires = getw(w,q+32)
    t = tnew(w,getw(w,q),q+96,requires)
    if t == 0:
        return 0
    if dist_probability_admit(w,t,source) == 0 or dist_fill_probability(w,scratch,t,source,data) == 0:
        return 0
    return record(w,t,41,source,0)

def dist_backward_bernoulli(w: mutbuf, t: u64) -> u64:
    p = dptr(w,t)
    parent = getw(w,p+48)
    i = 0
    while i < getw(w,p+8):
        gadd(w,parent,i,0)
        i = i+1
    return 1

def dist_dropout(w: mutbuf, scratch: mutbuf, id: u64, generator: u64, probability: u64, training: u64, no_grad: u64, inplace: u64) -> u64:
    t = public_node(w,id)
    data = rng_object(w,generator)
    if t == 0 or data == 0:
        return 0
    if no_grad > 1 or training > 1 or dist_prob64_valid(probability) == 0:
        return terror(w,7)
    p = dptr(w,t)
    probability = probability & 9223372036854775807
    n = getw(w,p+8)
    if probability == 0 or training == 0 or n == 0:
        return t
    if n > 1000000:
        return terror(w,3)
    if inplace != 0:
        if no_grad == 0 and getw(w,p+32) != 0:
            return terror(w,5)
        if version_can_bump(w,t,1) == 0 or dist_no_internal_overlap(w,t) == 0:
            return 0
    noise = 0
    if probability == 4607182418800017408:
        noise = tnew(w,0,p+96,0)
        if noise == 0:
            return 0
        put4(w,taddr(w,noise,0),0)
    else:
        noise = tnew(w,getw(w,p),p+96,0)
        if noise == 0:
            return 0
        dist_dense_layout(w,noise,t,1)
        complement = dist_complement64(probability)
        scale = divf(1065353216,dist_probability_to32(complement))
        if dist_fill_scalar(w,scratch,noise,data,complement,scale) == 0:
            return 0
    bump_version(w,noise)
    bump_version(w,noise)
    output = t
    if inplace == 0:
        requires = 0
        if no_grad == 0:
            requires = getw(w,p+32)
        output = tnew(w,getw(w,p),p+96,requires)
        if output == 0:
            return 0
        dist_dense_layout(w,output,t,0)
    i = 0
    while i < n:
        mask_index = i
        if probability == 4607182418800017408:
            mask_index = 0
        put4(w,taddr(w,output,i),mulf(tget(w,t,i),tget(w,noise,mask_index)))
        i = i+1
    if inplace != 0:
        bump_version(w,t)
        return t
    result = record(w,output,3,t,noise)
    putw(w,dptr(w,output)+176,1146244944)
    return result

def dist_saved_mask(w: mutbuf, id: u64) -> u64:
    t = public_node(w,id)
    if t == 0:
        return 0
    p = dptr(w,t)
    if getw(w,p+40) != 3 or getw(w,p+176) != 1146244944 or getw(w,p+288) == 0:
        return terror(w,5)
    saved = getw(w,p+288)
    if graph_saved_check(w,saved) == 0:
        return 0
    sp = so_saved_live(w,saved)
    if sp == 0:
        return terror(w,9)
    original = dptr(w,getw(w,p+56))
    result = descriptor(w,getw(w,original),original+96,0,0)
    if result == 0:
        return 0
    q = dptr(w,result)
    sid = so_uget(w,sp+16)
    vid = so_uget(w,sp+24)
    if so_storage_retain(w,sid) != 0 or so_version_retain(w,vid) != 0:
        return terror(w,9)
    record = so_slot_lookup(w,1,getw(w,q+192))
    so_uput(w,record+16,sid)
    so_uput(w,record+24,vid)
    so_uput(w,record+32,so_uget(w,sp+40))
    so_uput(w,record+40,so_uget(w,sp+48))
    putw(w,q+216,sid)
    putw(w,q+224,vid)
    putw(w,q+232,so_uget(w,sp+40))
    storage = so_storage_live(w,sid)
    putw(w,q+16,9223372036854775808+so_uget(w,storage+16)+so_uget(w,sp+40))
    j = 0
    while j < getw(w,original):
        putw(w,q+128+j*8,getw(w,original+128+j*8))
        j = j+1
    return result

def dist_command(s: readbuf, o: mutbuf, w: mutbuf, scratch: mutbuf, cp: u64, at: u64) -> u64:
    code = getr(s,cp)
    a = getr(s,cp+8)
    b = getr(s,cp+16)
    c = getr(s,cp+24)
    d = getr(s,cp+32)
    e = getr(s,cp+40)
    first = getw(w,8)
    result = 0
    if code > 85:
        terror(w,4)
    if getr(s,cp+48) != 0 or getr(s,cp+56) != 0:
        terror(w,7)
    if code != 83 and code != 84 and e != 0:
        terror(w,7)
    if code == 82 and d != 0:
        terror(w,7)
    if code == 85 and (b != 0 or c != 0 or d != 0):
        terror(w,7)
    if getw(w,0) == 0:
        if code == 80:
            result = dist_bernoulli_scalar(w,scratch,a,b,c,d)
        if code == 81:
            result = dist_bernoulli_tensor(w,scratch,a,b,c,d)
        if code == 82:
            result = dist_bernoulli_functional(w,scratch,a,b,c)
        if code == 83 or code == 84:
            result = dist_dropout(w,scratch,a,b,c,d,e,choose(code == 84,1,0))
        if code == 85:
            result = dist_saved_mask(w,a)
        if code >= 82 and getw(w,0) == 0:
            result = publish_tensor(w,result)
            finish_command(w,first)
    status = getw(w,0)
    if status != 0:
        result = 0
    putw(o,at,code)
    putw(o,at+8,status)
    putw(o,at+16,result)
    putw(o,at+24,0)
    return at+32
